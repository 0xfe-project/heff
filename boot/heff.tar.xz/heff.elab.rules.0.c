// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_Describe 2650
#define TAG_Escapes 7836
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MentionsError 719
#define TAG_MkChk 56962
#define TAG_MkEvidenceSearch 8362
#define TAG_MkSyn 7342
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_SError 24172
#define TAG_SLitFloat 3938
#define TAG_SLitInt 21439
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_UnequalTys 2248
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define TAG_Want 10361
#define LBL_aliases 1464806715
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_defaults 1389419502
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_evidence 1128105991
#define LBL_globals 352931696
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_matched 1072719718
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_named 305943379
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_values 1123329101
#define LBL_var 326049
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_el__ty__var[] = {LBL_el, LBL_ty, LBL_var};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names__locals__ctx__matched[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx, LBL_matched};
static uint32_t shape_scope__globals__elabFor__lams__self__insts__named__evidence[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts, LBL_named, LBL_evidence};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_array_2eempty_get(void);
V g_heff_2eelab_2ememoed_2eproj(V, V);
V g_heff_2eelab_2ememoed_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eproj_clo;
V g_heff_2eelab_2ememoed_2eprojAt(V, V, V);
V g_heff_2eelab_2ememoed_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eprojAt_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_clo;
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(V, V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
HeffT2 g_heff_2eelab_2erename_2erkOf_24cpr(V);
V g_heff_2eelab_2erules_2eandList(V);
V g_heff_2eelab_2erules_2eandList_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eandList_clo;
V g_heff_2eelab_2erules_2eannot(V, V);
V g_heff_2eelab_2erules_2eannot_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eannot_clo;
HeffT1 g_heff_2eelab_2erules_2eannot_24cpr(V, V);
V g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_24dps(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_24dps_clo;
V g_heff_2eelab_2erules_2eatFloat64_w(V, V, double, V, V);
V g_heff_2eelab_2erules_2eatFloat64(V, V, V, V, V);
V g_heff_2eelab_2erules_2eatFloat64_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat64_clo;
V g_heff_2eelab_2erules_2eatFloat64_24tok1_w(V, V, V, double, V, V);
V g_heff_2eelab_2erules_2eatFloat64_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eatFloat64_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat64_24tok1_clo;
V g_heff_2eelab_2erules_2echeckSetting(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckSetting_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckSetting_clo;
V g_heff_2eelab_2erules_2echeckSettings(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckSettings_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckSettings_clo;
V g_heff_2eelab_2erules_2ecodeAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecodeAt_clo;
V g_heff_2eelab_2erules_2edefaultCopy(V, V, V);
V g_heff_2eelab_2erules_2edefaultCopy_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultCopy_clo;
V g_heff_2eelab_2erules_2eeqBareStr(V, V, V, V);
V g_heff_2eelab_2erules_2eeqBareStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqBareStr_clo;
V g_heff_2eelab_2erules_2eeqElStr(V, V, V);
V g_heff_2eelab_2erules_2eeqElStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqElStr_clo;
V g_heff_2eelab_2erules_2eeqTyStr(V, V, V);
V g_heff_2eelab_2erules_2eeqTyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqTyStr_clo;
V g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242(V, V, V);
V g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242_clo;
V g_heff_2eelab_2erules_2eevidenceFound(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eevidenceFound_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceFound_clo;
V g_heff_2eelab_2erules_2eevidenceSearchF(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eevidenceSearchF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceSearchF_clo;
V g_heff_2eelab_2erules_2efieldIdxs(V, V);
V g_heff_2eelab_2erules_2efieldIdxs_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldIdxs_clo;
V g_heff_2eelab_2erules_2efieldIdxs_24dps(V, V, V);
V g_heff_2eelab_2erules_2efieldIdxs_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldIdxs_24dps_clo;
HeffT2 g_heff_2eelab_2erules_2efieldTyAt_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efieldsNote(V);
V g_heff_2eelab_2erules_2efieldsNote_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldsNote_clo;
V g_heff_2eelab_2erules_2efindPrim(V, V);
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efindPrim_clo;
HeffT1 g_heff_2eelab_2erules_2efindPrim_24cpr(V, V);
V g_heff_2eelab_2erules_2efreshMeta_24rec0_get(void);
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2erules_2eintAtFixed(V, V, V, V, V);
V g_heff_2eelab_2erules_2eintAtFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintAtFixed_clo;
V g_heff_2eelab_2erules_2eintAtFixed_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eintAtFixed_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintAtFixed_24tok1_clo;
V g_heff_2eelab_2erules_2elambdaChk(V, V, V, V);
V g_heff_2eelab_2erules_2elambdaChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elambdaChk_clo;
HeffT1 g_heff_2eelab_2erules_2elambdaChk_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2eliteralLeft_get(void);
HeffT2 g_heff_2eelab_2erules_2elookupP_24cpr(V, V);
V g_heff_2eelab_2erules_2ementionsLocal(V);
V g_heff_2eelab_2erules_2ementionsLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsLocal_clo;
HeffT3 g_heff_2eelab_2erules_2ementionsLocal_24cpr(V);
V g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133_clo;
V g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2erebottom(V, V);
V g_heff_2eelab_2erules_2erebottom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erebottom_clo;
V g_heff_2eelab_2erules_2eselfAdvance(V, V, V, V, V);
V g_heff_2eelab_2erules_2eselfAdvance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eselfAdvance_clo;
V g_heff_2eelab_2erules_2eselfAdvance_24generate0(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eselfAdvance_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eselfAdvance_24generate0_clo;
V g_heff_2eelab_2erules_2eselfAdvance_24map0(V, V, V, V, V);
V g_heff_2eelab_2erules_2eselfAdvance_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eselfAdvance_24map0_clo;
V g_heff_2eelab_2erules_2espineHasLocal(V, V);
V g_heff_2eelab_2erules_2espineHasLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2espineHasLocal_clo;
V g_heff_2eelab_2erules_2etagArgsGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2etagArgsGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagArgsGo_clo;
V g_heff_2eelab_2erules_2etyStrM(V, V);
V g_heff_2eelab_2erules_2etyStrM_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrM_clo;
V g_heff_2eelab_2erules_2etyStrZ_24tok1(V, V, V, V, V);
V g_heff_2eelab_2erules_2etyStrZ_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrZ_24tok1_clo;
V g_heff_2eelab_2erules_2eupdatedField(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdatedField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdatedField_clo;
V g_heff_2eelab_2erules_2evaluesGo_24dps(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_24dps_clo;
HeffT3 g_heff_2eelab_2erules_2evarGo_24cpr(V, V, V, V, V, V);
HeffT2 g_heff_2eelab_2eunify_2esubstOf_24cpr(V);
HeffT2 g_heff_2eelab_2eunify_2ezonker_24cpr(V);
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2eproj(V, V);
V g_heff_2eelab_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eproj_clo;
HeffT2 g_heff_2eelab_2evalue_2eprojTyWith_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo;
V g_list_2emap_24f783067987x1926181389(V, V, V, V, V);
V g_list_2emap_24f783067987x1926181389_entry(V self, V *a);
extern Clo g_list_2emap_24f783067987x1926181389_clo;
V g_list_2emap_24s258116700x992061112(V, V);
V g_list_2emap_24s258116700x992061112_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2eelab_2erules_2ementionsLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsLocal_entry, 1, 0};

V g_heff_2eelab_2erules_2ementionsLocal(V v_k_240) {
top: ;
  HeffT3 v_t_241 = (g_heff_2eelab_2erules_2ementionsLocal_24cpr(v_k_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    V v_field_244 = v_t_241.f[2];
    return heff_rec_n(3, shape_el__ty__var, (V[]){v_field_242, v_field_243, v_field_244});
  }
}
V g_heff_2eelab_2erules_2ementionsLocal_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ementionsLocal(a[0]);
}
V g_heff_2eelab_2erules_2etyStrM_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrM_entry, 2, 0};

V g_heff_2eelab_2erules_2etyStrM(V v_e_240, V v_m_241) {
top: ;
  V v_globals_242 = heff_take_field(v_e_240, 1);
  V v_scope_243 = heff_get_n(v_e_240, 0, 8);
  HeffT2 v_t_2411 = (g_heff_2eelab_2erename_2erkOf_24cpr(heff_clo_n(g_heff_2eelab_2erules_2etyStrM_lam0, 1, 1, (V[]){v_globals_242})));
  {
    V v_field_2413 = v_t_2411.f[1];
    heff_drop(v_t_2411.f[0]);
    V v_t_2414 = heff_tr(heff_call(v_field_2413, 1, (V[]){heff_get_n(v_m_241, 0, 2)}));
    return (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(g_heff_2eelab_2erules_2efreshMeta_24rec0_get()), MK_INT(0LL), heff_get_n(v_scope_243, 1, 5), v_t_2414));
  }
}
V g_heff_2eelab_2erules_2etyStrM_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etyStrM(a[0], a[1]);
}
V g_heff_2eelab_2erules_2etyStrM_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_globals_242 = heff_env(self)[0];
  V v_d_245 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_244)));
  heff_clo_take(self, 1);
  V v_t_246 = ({ V b_0 = heff_get_n(v_globals_242, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_247 = ({ V a_0 = v_t_246; V a_1 = v_x_244; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_t_246); heff_drop(v_x_244); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_d_245);
      V v_x_2410 = v_field_249;
      return v_x_2410;
    } else {
      heff_drop(v_field_249);
      return v_d_245;
    }
  }
}
V g_heff_2eelab_2erules_2eeqElStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eeqElStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeqElStr_entry, 3, 0};

V g_heff_2eelab_2erules_2eeqElStr(V v_g_240, V v_cs_241, V v_v_242) {
top: ;
  V v_len_243 = heff_take_field(v_cs_241, 0);
  V v_names_244 = heff_get_n(v_cs_241, 1, 2);
  V v_e_245 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_len_243, v_v_242));
  HeffT2 v_t_2413 = (g_heff_2eelab_2erename_2erkOf_24cpr(heff_clo_n(g_heff_2eelab_2erules_2eeqElStr_lam0, 1, 1, (V[]){v_g_240})));
  {
    V v_field_2414 = v_t_2413.f[0];
    heff_drop(v_t_2413.f[1]);
    V v_e_2416 = heff_tr(heff_call(v_field_2414, 1, (V[]){v_e_245}));
    return (g_heff_2esyntax_2esurfaceprint_2eelF_24s42825806x827400636(MK_INT(0LL), MK_INT(0LL), v_names_244, v_e_2416));
  }
}
V g_heff_2eelab_2erules_2eeqElStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eeqElStr(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eeqElStr_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_d_247 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_246)));
  heff_clo_take(self, 1);
  V v_t_248 = ({ V b_0 = heff_get_n(v_g_240, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_249 = ({ V a_0 = v_t_248; V a_1 = v_x_246; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_t_248); heff_drop(v_x_246); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      heff_drop(v_d_247);
      V v_x_2412 = v_field_2411;
      return v_x_2412;
    } else {
      heff_drop(v_field_2411);
      return v_d_247;
    }
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str0, 6, "types ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str1, 5, " and ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str2, 15, " are not equal ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str3, 9, "elements ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str4, 5, " and ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str5, 15, " are not equal ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str6, 9, "neutrals ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str7, 5, " and ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str8, 15, " are not equal ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str9, 47, "a solution would mention what did not elaborate");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str10, 61, "a solution would mention a variable outside where it is bound");
Clo g_heff_2eelab_2erules_2eprettyEqErr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprettyEqErr_entry, 2, 0};

V g_heff_2eelab_2erules_2eprettyEqErr(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_UnequalTys: {
    V v_cs_242 = heff_field(v_x2_241, 0);
    V v_a_243 = heff_field(v_x2_241, 1);
    V v_a2_244 = heff_field(v_x2_241, 2);
    V v_t_245 = (g_heff_2eelab_2erules_2eeqTyStr(heff_dup(v_g_240), heff_dup(v_cs_242), heff_dup(v_a_243)));
    V v_t_246 = (g_heff_2eelab_2erules_2eeqTyStr(v_g_240, heff_dup(v_cs_242), heff_dup(v_a2_244)));
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str0), v_t_245), ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str1));
    return heff_strAppend(heff_strAppend(v_t_247, v_t_246), ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str2));
  }
  case TAG_UnequalEls: {
    V v_cs_248 = heff_field(v_x2_241, 0);
    V v_a_249 = heff_field(v_x2_241, 1);
    V v_a2_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = (g_heff_2eelab_2erules_2eeqElStr(heff_dup(v_g_240), heff_dup(v_cs_248), heff_dup(v_a_249)));
    V v_t_2412 = (g_heff_2eelab_2erules_2eeqElStr(v_g_240, heff_dup(v_cs_248), heff_dup(v_a2_2410)));
    V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str3), v_t_2411), ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str4));
    return heff_strAppend(heff_strAppend(v_t_2413, v_t_2412), ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str5));
  }
  case TAG_UnequalNeus: {
    V v_cs_2414 = heff_field(v_x2_241, 0);
    V v_h_2415 = heff_field(v_x2_241, 1);
    V v_sp_2416 = heff_field(v_x2_241, 2);
    V v_h2_2417 = heff_field(v_x2_241, 3);
    V v_sp2_2418 = heff_field(v_x2_241, 4);
    V v_t_2419 = (g_heff_2eelab_2erules_2eeqBareStr(heff_dup(v_g_240), heff_dup(v_cs_2414), heff_dup(v_h_2415), heff_dup(v_sp_2416)));
    V v_t_2420 = (g_heff_2eelab_2erules_2eeqBareStr(v_g_240, heff_dup(v_cs_2414), heff_dup(v_h2_2417), heff_dup(v_sp2_2418)));
    V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str6), v_t_2419), ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str7));
    return heff_strAppend(heff_strAppend(v_t_2421, v_t_2420), ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str8));
  }
  case TAG_MentionsError: {
    heff_drop(v_g_240);
    return ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str9);
  }
  case TAG_Escapes: {
    heff_drop(v_g_240);
    return ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str10);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eprettyEqErr(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2echeckSettings_lam1(V self, V *args);
V g_heff_2eelab_2erules_2echeckSettings_lam2(V self, V *args);
V g_heff_2eelab_2erules_2echeckSettings_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2echeckSettings_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2echeckSettings_entry, 8, 0};

V g_heff_2eelab_2erules_2echeckSettings(V v_e_240, V v_sp_241, V v_w_242, V v_goal_243, V v_found_244, V v_x6_245, V v_p_246, V v_p_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_w_242);
    heff_drop(v_goal_243);
    heff_drop(v_found_244);
    heff_drop_rec(v_p_246, 3);
    return heff_tail(v_p_247, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_st_248 = heff_field(v_x6_245, 0);
    V v_rest_249 = heff_field(v_x6_245, 1);
    return ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_sp_241); V a_2 = heff_dup(v_w_242); V a_3 = heff_dup(v_goal_243); V a_4 = heff_dup(v_found_244); V b_5 = NTAG(TAG_False); V a_6 = v_st_248; V a_7 = heff_dup(v_p_246); V a_8 = heff_clo_n(g_heff_2eelab_2erules_2echeckSettings_lam0, 1, 9, (V[]){v_e_240, v_sp_241, v_w_242, v_goal_243, v_found_244, heff_dup(v_rest_249), v_p_246, v_p_247, heff_dup(v_st_248)}); V r_ = (g_heff_2eelab_2erules_2echeckSetting(a_0, a_1, a_2, a_3, a_4, b_5, a_6, a_7, a_8)); heff_drop(b_5); r_; });
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2eelab_2erules_2echeckSettings_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2eelab_2erules_2echeckSettings(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7]); heff_drop(a5); return r;
}
V g_heff_2eelab_2erules_2echeckSettings_lam1(V self, V *args) {
  V v_b_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_w_242 = heff_env(self)[2];
  V v_goal_243 = heff_env(self)[3];
  V v_found_244 = heff_env(self)[4];
  V v_st_248 = heff_env(self)[5];
  V v_p_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = v_w_242; V a_3 = v_goal_243; V a_4 = v_found_244; V a_5 = v_b_2411; V a_6 = v_st_248; V a_7 = heff_dup(v_p_246); V a_8 = heff_get_n(v_p_246, 0, 3); V r_ = (g_heff_2eelab_2erules_2echeckSetting(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_b_2411); heff_drop(v_st_248); r_; });
}
V g_heff_2eelab_2erules_2echeckSettings_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_w_242 = heff_env(self)[2];
  V v_goal_243 = heff_env(self)[3];
  V v_found_244 = heff_env(self)[4];
  V v_rest_249 = heff_env(self)[5];
  V v_p_246 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  heff_drop(v_x_2415);
  heff_clo_take(self, 8);
  return ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = v_w_242; V a_3 = v_goal_243; V a_4 = v_found_244; V a_5 = v_rest_249; V a_6 = v_p_246; V a_7 = v_p_247; V r_ = (g_heff_2eelab_2erules_2echeckSettings(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_rest_249); r_; });
}
V g_heff_2eelab_2erules_2echeckSettings_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_w_242 = heff_env(self)[2];
  V v_goal_243 = heff_env(self)[3];
  V v_found_244 = heff_env(self)[4];
  V v_rest_249 = heff_env(self)[5];
  V v_p_246 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  V v_st_248 = heff_env(self)[8];
  if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
    heff_drop(v_x_2410);
    heff_clo_take(self, 9);
    heff_drop(v_st_248);
    return ({ V a_0 = v_e_240; V a_1 = v_sp_241; V a_2 = v_w_242; V a_3 = v_goal_243; V a_4 = v_found_244; V a_5 = v_rest_249; V a_6 = v_p_246; V a_7 = v_p_247; V r_ = (g_heff_2eelab_2erules_2echeckSettings(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_rest_249); r_; });
  } else {
    heff_drop(v_x_2410);
    heff_clo_take(self, 9);
    V v_t_2412 = heff_tag_n(TAG_Want, 3, (V[]){heff_dup(v_sp_241), heff_clo_n(g_heff_2eelab_2erules_2echeckSettings_lam1, 1, 7, (V[]){heff_dup(v_e_240), heff_dup(v_sp_241), heff_dup(v_w_242), heff_dup(v_goal_243), heff_dup(v_found_244), v_st_248, heff_dup(v_p_246)}), NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_246, 2)), 1, (V[]){v_t_2413}));
    V f_ = heff_dup(heff_rfield(v_p_246, 1));
    heff_room[0] = v_t_2414;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2echeckSettings_lam2, 1, 8, (V[]){v_e_240, v_sp_241, v_w_242, v_goal_243, v_found_244, v_rest_249, v_p_246, v_p_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
Clo g_heff_2eelab_2erules_2elambdaChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elambdaChk_entry, 4, 0};

V g_heff_2eelab_2erules_2elambdaChk(V v_waits_240, V v_sp_241, V v_x_242, V v_body_243) {
top: ;
  HeffT1 v_t_244 = (g_heff_2eelab_2erules_2elambdaChk_24cpr(v_waits_240, v_sp_241, v_x_242, v_body_243));
  {
    V v_field_245 = v_t_244.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_245});
  }
}
V g_heff_2eelab_2erules_2elambdaChk_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2eelab_2erules_2elambdaChk(a0, a[1], a[2], a3); heff_drop(a0); heff_drop(a3); return r;
}
Clo g_heff_2eelab_2erules_2espineHasLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2espineHasLocal_entry, 2, 0};

V g_heff_2eelab_2erules_2espineHasLocal(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SpId: {
    heff_drop(v_l_240);
    return NTAG(TAG_False);
  }
  case TAG_SpApp: {
    V v_sp_242 = heff_field(v_x2_241, 0);
    V v_v_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_v_243)) {
    case TAG_VNeu: {
      V v_v1_244 = heff_field(v_v_243, 0);
      V v_v2_245 = heff_field(v_v_243, 1);
      switch (heff_tag_of(v_v1_244)) {
      case TAG_HLocal: {
        V v_l2_249 = heff_field(v_v1_244, 0);
        switch (heff_tag_of(v_v2_245)) {
        case TAG_SpId: {
          if (heff_intEq_c_lent(v_l2_249, v_l_240, 0)) {
            heff_drop(v_l_240);
            return NTAG(TAG_True);
          } else {
            V t_0 = v_l_240;
            V t_1 = v_sp_242;
            v_l_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        }
        case TAG_SpApp: {
          V t_0 = v_l_240;
          V t_1 = v_sp_242;
          v_l_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_SpProj: {
          V t_0 = v_l_240;
          V t_1 = v_sp_242;
          v_l_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_SpSpec: {
          V t_0 = v_l_240;
          V t_1 = v_sp_242;
          v_l_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_v2_245);
        }
      }
      case TAG_HGlobal: {
        V t_0 = v_l_240;
        V t_1 = v_sp_242;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_HMeta: {
        V t_0 = v_l_240;
        V t_1 = v_sp_242;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_HError: {
        V t_0 = v_l_240;
        V t_1 = v_sp_242;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_v1_244);
      }
    }
    case TAG_VCode: {
      V t_0 = v_l_240;
      V t_1 = v_sp_242;
      v_l_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_VLam: {
      V t_0 = v_l_240;
      V t_1 = v_sp_242;
      v_l_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_VCons: {
      V t_0 = v_l_240;
      V t_1 = v_sp_242;
      v_l_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_VOpaque: {
      V t_0 = v_l_240;
      V t_1 = v_sp_242;
      v_l_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_v_243);
    }
  }
  case TAG_SpProj: {
    V v_sp_2423 = heff_field(v_x2_241, 0);
    V t_0 = v_l_240;
    V t_1 = v_sp_2423;
    v_l_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_SpSpec: {
    V v_sp_2425 = heff_field(v_x2_241, 0);
    V t_0 = v_l_240;
    V t_1 = v_sp_2425;
    v_l_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2espineHasLocal_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2espineHasLocal(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2erules_2eannot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eannot_entry, 2, 0};

V g_heff_2eelab_2erules_2eannot(V v_typ_240, V v_chk_241) {
top: ;
  HeffT1 v_t_242 = (g_heff_2eelab_2erules_2eannot_24cpr(v_typ_240, v_chk_241));
  {
    V v_field_243 = v_t_242.f[0];
    return heff_tag_n(TAG_MkSyn, 1, (V[]){v_field_243});
  }
}
V g_heff_2eelab_2erules_2eannot_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2eannot(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eselfAdvance_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eselfAdvance_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eselfAdvance_lam0, 1, 0};
V g_heff_2eelab_2erules_2eselfAdvance_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2eselfAdvance_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eselfAdvance_lam2, 1, 0};
V g_heff_2eelab_2erules_2eselfAdvance_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eselfAdvance_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eselfAdvance_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eselfAdvance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eselfAdvance_entry, 5, 0};

V g_heff_2eelab_2erules_2eselfAdvance(V v_e_240, V v_a_241, V v_done_242, V v_p_243, V v_p_244) {
top: ;
  V v_malg_245 = heff_take_field(v_p_243, 2);
  V v_bind_246 = heff_get_n(v_p_243, 1, 3);
  V v_t_247 = heff_dup(heff_rfield(v_e_240, 2));
  switch (heff_tag_of(v_t_247)) {
  case TAG_ForNominative: {
    heff_drop(v_a_241);
    heff_drop(v_done_242);
    heff_drop(v_malg_245);
    heff_drop(v_bind_246);
    return heff_tail(v_p_244, 1, (V[]){v_e_240});
  }
  case TAG_ForDescriptive: {
    V v_elabFor1_248 = heff_field(v_t_247, 0);
    V v_elabFor2_249 = heff_field(v_t_247, 1);
    heff_take_n(v_t_247, 3ULL, 2);
    switch (heff_tag_of(v_elabFor1_248)) {
    case TAG_HLocal: {
      heff_take_n(v_elabFor1_248, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_done_242);
      heff_drop(v_malg_245);
      heff_drop(v_bind_246);
      heff_drop(v_elabFor2_249);
      return heff_tail(v_p_244, 1, (V[]){v_e_240});
    }
    case TAG_HGlobal: {
      V v_gk_2411 = heff_field(v_elabFor1_248, 0);
      V v_ru_24elabFor1_248_24HGlobal = heff_take_reuse_n(v_elabFor1_248, 1ULL, 1);
      switch (heff_tag_of(v_elabFor2_249)) {
      case TAG_SpId: {
        V v_t_2413 = heff_tag_at_n(v_ru_24elabFor1_248_24HGlobal, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eselfAdvance_lam0_clo)})});
        V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
        V v_t_2415 = heff_tr(heff_call(v_malg_245, 1, (V[]){v_t_2414}));
        return heff_tail(v_bind_246, 2, (V[]){v_t_2415, heff_clo_n(g_heff_2eelab_2erules_2eselfAdvance_lam1, 1, 5, (V[]){v_a_241, v_p_244, v_e_240, v_gk_2411, v_done_242})});
      }
      case TAG_SpApp: {
        heff_take_n(v_elabFor2_249, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop(v_done_242);
        heff_drop(v_malg_245);
        heff_drop(v_bind_246);
        heff_drop(v_gk_2411);
        heff_drop_cell(v_ru_24elabFor1_248_24HGlobal, 1);
        return heff_tail(v_p_244, 1, (V[]){v_e_240});
      }
      case TAG_SpProj: {
        heff_take_n(v_elabFor2_249, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop(v_done_242);
        heff_drop(v_malg_245);
        heff_drop(v_bind_246);
        heff_drop(v_gk_2411);
        heff_drop_cell(v_ru_24elabFor1_248_24HGlobal, 1);
        return heff_tail(v_p_244, 1, (V[]){v_e_240});
      }
      case TAG_SpSpec: {
        heff_take_n(v_elabFor2_249, 0ULL, 3);
        heff_drop(v_a_241);
        heff_drop(v_done_242);
        heff_drop(v_malg_245);
        heff_drop(v_bind_246);
        heff_drop(v_gk_2411);
        heff_drop_cell(v_ru_24elabFor1_248_24HGlobal, 1);
        return heff_tail(v_p_244, 1, (V[]){v_e_240});
      }
      default: return heff_nomatch(v_elabFor2_249);
      }
    }
    case TAG_HMeta: {
      heff_take_n(v_elabFor1_248, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_done_242);
      heff_drop(v_malg_245);
      heff_drop(v_bind_246);
      heff_drop(v_elabFor2_249);
      return heff_tail(v_p_244, 1, (V[]){v_e_240});
    }
    case TAG_HError: {
      heff_drop(v_a_241);
      heff_drop(v_done_242);
      heff_drop(v_malg_245);
      heff_drop(v_bind_246);
      heff_drop(v_elabFor2_249);
      return heff_tail(v_p_244, 1, (V[]){v_e_240});
    }
    default: return heff_nomatch(v_elabFor1_248);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eelab_2erules_2eselfAdvance_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eselfAdvance(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eselfAdvance_lam0(V self, V *args) {
  V v_c_2412 = args[0];
  return heff_get_n(v_c_2412, 7, 9);
}
V g_heff_2eelab_2erules_2eselfAdvance_lam2(V self, V *args) {
  V v_u_2434 = args[0];
  heff_drop(v_u_2434);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2eselfAdvance_lam3(V self, V *args) {
  V v_u_2440 = args[0];
  V v_a_2429 = heff_env(self)[0];
  heff_drop(v_u_2440);
  heff_clo_take(self, 1);
  return v_a_2429;
}
V g_heff_2eelab_2erules_2eselfAdvance_lam4(V self, V *args) {
  V v_u_2447 = args[0];
  V v_a_2429 = heff_env(self)[0];
  heff_drop(v_u_2447);
  heff_clo_take(self, 1);
  return v_a_2429;
}
V g_heff_2eelab_2erules_2eselfAdvance_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_a_241 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_gk_2411 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_t_2417 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_241)));
  switch (heff_tag_of(v_t_2417)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2417, 0ULL, 1);
    heff_drop(v_x_2416);
    heff_clo_take(self, 5);
    heff_drop(v_a_241);
    heff_drop(v_gk_2411);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2417, 0ULL, 4);
    heff_drop(v_x_2416);
    heff_clo_take(self, 5);
    heff_drop(v_a_241);
    heff_drop(v_gk_2411);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeRecord: {
    V v_fieldTypes_2425 = heff_field(v_t_2417, 2);
    heff_take_n(v_t_2417, 4ULL, 3);
    switch (heff_tag_of(v_x_2416)) {
    case TAG_Nothing: {
      heff_clo_take(self, 5);
      heff_drop(v_a_241);
      heff_drop(v_gk_2411);
      heff_drop(v_done_242);
      heff_drop(v_fieldTypes_2425);
      V f_ = v_p_244;
      args[0] = v_e_240;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_y_2426 = heff_field(v_x_2416, 0);
      V v_ru_24x_2416_24Just = heff_take_reuse_n(v_x_2416, 1ULL, 1);
      if (heff_strEq_c_lent(v_y_2426, v_gk_2411, 1)) {
        heff_clo_take(self, 5);
        V v_sc_2427 = heff_take_field(v_e_240, 0);
        V v_gk_2428 = v_gk_2411;
        V v_a_2429 = v_a_241;
        V v_fieldTypes_2430 = v_fieldTypes_2425;
        V v_done_2431 = v_done_242;
        V v_xs_2432 = heff_dup(heff_rfield(v_fieldTypes_2430, 0));
        V v_m_2433 = heff_arrayLength_lent(v_xs_2432, 0);
        V v_t_2444;
        if ((heff_peek_word(v_m_2433) <= ((int64_t)0ULL))) {
          heff_drop(v_done_2431);
          heff_drop(v_xs_2432);
          v_t_2444 = heff_arrayGenerate(v_m_2433, ((V)&g_heff_2eelab_2erules_2eselfAdvance_lam2_clo));
        } else {
          V v_f_2435 = heff_arrayIndex_lent(v_xs_2432, MK_INT(0LL), 2);
          HeffT2 v_t_2436 = (g_heff_2eelab_2erules_2elookupP_24cpr(v_done_2431, v_f_2435));
          {
            V v_field_2438 = v_t_2436.f[1];
            int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
            V v_y_2442;
            if ((v_tag_2437 == ((int64_t)0ULL))) {
              heff_drop(v_f_2435);
              V v_v_2439 = v_field_2438;
              v_y_2442 = heff_tag_n(TAG_Nom, 1, (V[]){v_v_2439});
            } else {
              heff_drop(v_field_2438);
              V v_t_2441 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_gk_2428)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eselfAdvance_lam3, 1, 1, (V[]){heff_dup(v_a_2429)}), NTAG(TAG_Nothing)));
              v_y_2442 = ({ V a_0 = v_t_2441; V a_1 = v_f_2435; V r_ = (g_heff_2eelab_2evalue_2eproj(a_0, a_1)); heff_drop(v_t_2441); heff_drop(v_f_2435); r_; });
            }
            V v_t_2443 = heff_arrayKeepsAs_lent(v_xs_2432, v_y_2442, 0);
            if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
              heff_drop(v_m_2433);
              heff_drop(v_t_2443);
              v_t_2444 = ({ V a_0 = v_done_2431; V a_1 = heff_dup(v_gk_2428); V a_2 = heff_dup(v_a_2429); V a_3 = MK_INT(1LL); V a_4 = heff_arraySet(v_xs_2432, MK_INT(0LL), v_y_2442); V r_ = (g_heff_2eelab_2erules_2eselfAdvance_24map0(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_done_2431); r_; });
            } else {
              heff_drop(v_t_2443);
              v_t_2444 = ({ V a_0 = v_xs_2432; V a_1 = v_done_2431; V a_2 = heff_dup(v_gk_2428); V a_3 = heff_dup(v_a_2429); V a_4 = MK_INT(1LL); V a_5 = heff_arrayReplicate(v_m_2433, v_y_2442); V r_ = (g_heff_2eelab_2erules_2eselfAdvance_24generate0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_xs_2432); heff_drop(v_done_2431); r_; });
            }
          }
        }
        V v_t_2445 = ({ V rv_2 = v_t_2444; V rr_ = heff_rec_reuse_nf(v_fieldTypes_2430, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2446 = heff_tag_at_n(v_ru_24x_2416_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_VCons, 1, (V[]){v_t_2445})});
        V v_v_2448 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_gk_2428}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eselfAdvance_lam4, 1, 1, (V[]){v_a_2429}), v_t_2446));
        V v_t_2449 = (g_heff_2eelab_2erules_2erebottom(v_v_2448, heff_take_field(v_sc_2427, 2)));
        V v_sc_2450 = ({ V rv_2 = v_t_2449; V rr_ = heff_rec_reuse_nf(v_sc_2427, 27ULL, 5, shape_len__names__locals__ctx__matched, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2451 = ({ V rv_0 = v_sc_2450; V rr_ = heff_rec_reuse_nf(v_e_240, 254ULL, 8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, 65532u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V f_ = v_p_244;
        args[0] = v_t_2451;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_clo_take(self, 5);
        heff_drop(v_a_241);
        heff_drop(v_gk_2411);
        heff_drop(v_done_242);
        heff_drop(v_fieldTypes_2425);
        heff_drop_cell(v_ru_24x_2416_24Just, 1);
        V f_ = v_p_244;
        args[0] = v_e_240;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_x_2416);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2417, 0ULL, 1);
    heff_drop(v_x_2416);
    heff_clo_take(self, 5);
    heff_drop(v_a_241);
    heff_drop(v_gk_2411);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2416);
    heff_clo_take(self, 5);
    heff_drop(v_a_241);
    heff_drop(v_gk_2411);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2416);
    heff_clo_take(self, 5);
    heff_drop(v_a_241);
    heff_drop(v_gk_2411);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeString: {
    heff_drop(v_x_2416);
    heff_clo_take(self, 5);
    heff_drop(v_a_241);
    heff_drop(v_gk_2411);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2416);
    heff_clo_take(self, 5);
    heff_drop(v_a_241);
    heff_drop(v_gk_2411);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2417, 0ULL, 1);
    heff_drop(v_x_2416);
    heff_clo_take(self, 5);
    heff_drop(v_a_241);
    heff_drop(v_gk_2411);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2417, 0ULL, 1);
    heff_drop(v_x_2416);
    heff_clo_take(self, 5);
    heff_drop(v_a_241);
    heff_drop(v_gk_2411);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_NoRules: {
    heff_drop(v_x_2416);
    heff_clo_take(self, 5);
    heff_drop(v_a_241);
    heff_drop(v_gk_2411);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2417);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str1, 2, ", ");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str3, 2, " (");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str4, 17, " may be left out)");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str5, 15, "the fields are ");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str6, 15, ", in this order");
Clo g_heff_2eelab_2erules_2efieldsNote_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efieldsNote_entry, 1, 0};

V g_heff_2eelab_2erules_2efieldsNote(V v_it_240) {
top: ;
  V v_keys_241 = heff_take_field(v_it_240, 2);
  V v_defaults_242 = heff_get_n(v_it_240, 3, 5);
  V v_t_243 = v_keys_241;
  V v_t_246;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2eelab_2erules_2efieldsNote_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_t_243, 0);
    V v_xs_245 = heff_field(v_t_243, 1);
    heff_take_n(v_t_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2efieldsNote_str1); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_247 = heff_arrayLength(heff_take_field(v_defaults_242, 2));
  V v_t_2410;
  if ((heff_unbox_word(v_t_247) == ((int64_t)0ULL))) {
    heff_drop_rec(v_defaults_242, 3);
    v_t_2410 = ((V)&g_heff_2eelab_2erules_2efieldsNote_str2);
  } else {
    V v_t_248 = heff_arrayToList(heff_get_n(v_defaults_242, 0, 3));
    V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2eelab_2erules_2eandList(a_0)); heff_drop(v_t_248); r_; });
    v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2efieldsNote_str3), v_t_249), ((V)&g_heff_2eelab_2erules_2efieldsNote_str4));
  }
  V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2efieldsNote_str5), v_t_246), ((V)&g_heff_2eelab_2erules_2efieldsNote_str6));
  return heff_strAppend(v_t_2411, v_t_2410);
}
V g_heff_2eelab_2erules_2efieldsNote_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efieldsNote(a[0]);
}
Clo g_heff_2eelab_2erules_2efieldIdxs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efieldIdxs_entry, 2, 0};

V g_heff_2eelab_2erules_2efieldIdxs(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Nothing: {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){MK_INT(0LL), heff_hole()});
      V v_u_245 = (g_heff_2eelab_2erules_2efieldIdxs_24dps(v_at_240, v_rest_243, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    case TAG_Just: {
      V v_p_246 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_247 = heff_intSub(heff_intSub_lent(v_at_240, MK_INT(1LL), 2), v_p_246);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_heff_2eelab_2erules_2efieldIdxs_24dps(v_at_240, v_rest_243, v_cell_248));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2efieldIdxs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efieldIdxs(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2evaluesGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2evaluesGo_24dps_entry, 6, 0};

V g_heff_2eelab_2erules_2evaluesGo_24dps(V v_n_240, V v_places_241, V v_x3_242, V v_x4_243, V v_i_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_places_241);
    heff_drop(v_x4_243);
    heff_drop(v_i_244);
    return heff_setField(heff_dup(v_d_245), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_m_246 = heff_field(v_x3_242, 0);
    V v_rest_247 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_n_240);
      heff_drop(v_places_241);
      heff_drop(v_i_244);
      heff_drop(v_m_246);
      heff_drop(v_rest_247);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return heff_setField(heff_dup(v_d_245), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_x41_248 = heff_field(v_x4_243, 0);
      V v_pls_249 = heff_field(v_x4_243, 1);
      V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_248)) {
      case TAG_Nothing: {
        heff_drop(v_m_246);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        V t_0 = v_n_240;
        V t_1 = v_places_241;
        V t_2 = v_rest_247;
        V t_3 = v_pls_249;
        V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
        V t_5 = v_d_245;
        v_n_240 = t_0;
        v_places_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        v_i_244 = t_4;
        v_d_245 = t_5;
        goto top;
      }
      case TAG_Just: {
        V v_p_2410 = heff_field(v_x41_248, 0);
        heff_take_n(v_x41_248, 1ULL, 1);
        V v_t_2411 = heff_tr(g_heff_2eelab_2erules_2ecodeAt(heff_dup(v_n_240), v_p_2410, heff_dup(v_places_241), heff_dup(v_m_246), heff_dup(v_i_244)));
        V v_cell_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_MkPair, 2, (V[]){v_m_246, v_t_2411}), heff_hole()});
        V v_u_2413 = heff_setFieldPeek(v_d_245, MK_INT(1LL), v_cell_2412);
        V t_0 = v_n_240;
        V t_1 = v_places_241;
        V t_2 = v_rest_247;
        V t_3 = v_pls_249;
        V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
        V t_5 = v_u_2413;
        v_n_240 = t_0;
        v_places_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        v_i_244 = t_4;
        v_d_245 = t_5;
        goto top;
      }
      default: return heff_nomatch(v_x41_248);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2evaluesGo_24dps_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2eelab_2erules_2evaluesGo_24dps(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
V g_heff_2eelab_2erules_2etagArgsGo_lam1(V self, V *args);
V g_heff_2eelab_2erules_2etagArgsGo_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etagArgsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagArgsGo_entry, 5, 0};

V g_heff_2eelab_2erules_2etagArgsGo(V v_e_240, V v_x2_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_z_243);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      heff_take_n(v_x3_242, 0ULL, 2);
      return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_Cons: {
    V v_c_247 = heff_field(v_x2_241, 0);
    V v_cs_248 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_e_240);
      heff_drop(v_z_243);
      heff_drop(v_c_247);
      heff_drop(v_cs_248);
      return heff_tail(v_z_244, 1, (V[]){NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      V v_t_249 = heff_field(v_x3_242, 0);
      V v_ts_2410 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_a_2411 = heff_tr(heff_call(v_t_249, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_c_2413;
      switch (heff_tag_of(v_c_247)) {
      case TAG_MkChk: {
        V v_f_2412 = heff_field(v_c_247, 0);
        heff_take_n(v_c_247, 1ULL, 1);
        v_c_2413 = heff_tr(heff_call(v_f_2412, 2, (V[]){heff_dup(v_e_240), v_a_2411}));
        break;
      }
      default: heff_nomatch(v_c_247);
      }
      return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2eelab_2erules_2etagArgsGo_lam0, 1, 5, (V[]){v_e_240, v_cs_248, v_ts_2410, v_z_243, v_z_244})});
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2etagArgsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etagArgsGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_244;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2414, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_cs_248 = heff_env(self)[1];
  V v_ts_2410 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2etagArgsGo(v_e_240, v_cs_248, v_ts_2410, v_z_243, heff_clo_n(g_heff_2eelab_2erules_2etagArgsGo_lam1, 1, 2, (V[]){v_z_244, v_x_2414})));
}
HEFF_LIT(g_heff_2eelab_2erules_2edefaultCopy_str0, 1, "_");
Clo g_heff_2eelab_2erules_2edefaultCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edefaultCopy_entry, 3, 0};

V g_heff_2eelab_2erules_2edefaultCopy(V v_n_240, V v_body_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_ts_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_list_2emap_24s258116700x992061112(((V)&g_heff_2eelab_2erules_2edefaultCopy_str0), heff_arrayToList(heff_dup(v_ts_244))));
    V v_k_246 = heff_arrayLength(v_ts_244);
    V v_t_2411;
    if ((heff_peek_word(v_k_246) == ((int64_t)0ULL))) {
      heff_drop(v_n_240);
      heff_drop(v_k_246);
      v_t_2411 = v_body_241;
    } else {
      V v_t_247 = (g_list_2emap_24f783067987x1926181389(heff_dup(v_n_240), MK_INT(1LL), v_k_246, MK_INT(0LL), heff_intSub(v_n_240, MK_INT(1LL))));
      HeffT2 v_t_248 = ({ V a_0 = v_t_247; HeffT2 r_ = (g_heff_2eelab_2eunify_2esubstOf_24cpr(a_0)); heff_drop(v_t_247); r_; });
      {
        V v_field_249 = v_t_248.f[0];
        heff_drop(v_t_248.f[1]);
        v_t_2411 = heff_tr(heff_call(v_field_249, 2, (V[]){MK_INT(0LL), v_body_241}));
      }
    }
    V v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_MkPair, 2, (V[]){heff_arrayFromList(v_t_245), v_t_2411});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_t_2412});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2edefaultCopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edefaultCopy(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eelab_2erules_2eliteralLeft_str0, 34, "the values other than this literal");

static V g_heff_2eelab_2erules_2eliteralLeft_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eliteralLeft_st;
static V g_heff_2eelab_2erules_2eliteralLeft_init(void) {
  return ((V)&g_heff_2eelab_2erules_2eliteralLeft_str0);
}
V g_heff_2eelab_2erules_2eliteralLeft_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eliteralLeft_st)) return g_heff_2eelab_2erules_2eliteralLeft_val;
  return heff_global(&g_heff_2eelab_2erules_2eliteralLeft_val, &g_heff_2eelab_2erules_2eliteralLeft_st, g_heff_2eelab_2erules_2eliteralLeft_init);
}
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str0, 34, "the record updated is out of scope");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str1, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str2, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str3, 18, "the type of field ");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str4, 77, " depends on the fields before it, and what the record's are is not known here");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str5, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str6, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str7, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str8, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str9, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str10, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str11, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str12, 53, "tried to update a value that was not of a record type");
V g_heff_2eelab_2erules_2eupdatedField_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam13(V self, V *args);
Clo g_heff_2eelab_2erules_2eupdatedField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdatedField_entry, 6, 0};

V g_heff_2eelab_2erules_2eupdatedField(V v_sp_240, V v_e_241, V v_r_242, V v_g_243, V v_a_244, V v_x_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 1, 5);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 3, 5);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 2, 5);
  HeffT3 v_t_249 = ({ V a_0 = v_r_242; V a_1 = v_t_246; V a_2 = v_t_247; V a_3 = v_t_248; V a_4 = MK_INT(0LL); V a_5 = MK_INT(0LL); HeffT3 r_ = (g_heff_2eelab_2erules_2evarGo_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_246); heff_drop(v_t_247); heff_drop(v_t_248); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    V v_field_2412 = v_t_249.f[2];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      heff_drop_rec(v_e_241, 8);
      heff_drop_rec(v_g_243, 2);
      heff_drop(v_a_244);
      heff_drop(v_x_245);
      heff_drop(v_field_2412);
      V v_it1_2413 = v_field_2411;
      heff_drop(v_it1_2413);
      return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam0, 2, 1, (V[]){v_sp_240});
    } else {
      V v_v_2422 = v_field_2411;
      V v_it12_2423 = v_field_2412;
      heff_drop(v_it12_2423);
      V v_bound_2424 = ({ V rv_1 = heff_dup(heff_rfield(v_g_243, 1)); V rr_ = heff_rec_reuse_nf(v_v_2422, 1ULL, 2, shape_stx__val, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2425 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_244)));
      switch (heff_tag_of(v_t_2425)) {
      case TAG_LikeU: {
        heff_take_n(v_t_2425, 0ULL, 1);
        heff_drop_rec(v_e_241, 8);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2424, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam1, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeFunction: {
        heff_take_n(v_t_2425, 0ULL, 4);
        heff_drop_rec(v_e_241, 8);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2424, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam2, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeRecord: {
        V v_capture_2448 = heff_field(v_t_2425, 1);
        V v_fieldTypes_2449 = heff_field(v_t_2425, 2);
        heff_take_n(v_t_2425, 6ULL, 3);
        V v_x1_2450 = heff_tr(heff_call(heff_get_n(v_g_243, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
        V v_v_2454;
        switch (heff_tag_of(v_x1_2450)) {
        case TAG_Nom: {
          V v_x_2451 = heff_field(v_x1_2450, 0);
          heff_take_n(v_x1_2450, 1ULL, 1);
          v_v_2454 = v_x_2451;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2450, 0ULL, 1);
          v_v_2454 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2453 = heff_field(v_x1_2450, 0);
          heff_take_n(v_x1_2450, 1ULL, 1);
          v_v_2454 = v_x_2453;
          break;
        }
        default: heff_nomatch(v_x1_2450);
        }
        V v_t_2455 = ({ V a_0 = v_v_2454; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop(v_v_2454); r_; });
        HeffT2 v_t_2456 = ({ V a_0 = v_a_244; V a_1 = v_t_2455; V a_2 = v_x_245; HeffT2 r_ = (g_heff_2eelab_2evalue_2eprojTyWith_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2455); r_; });
        {
          V v_field_2458 = v_t_2456.f[1];
          int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
          if ((v_tag_2457 == ((int64_t)0ULL))) {
            heff_drop(v_sp_240);
            heff_drop_rec(v_e_241, 8);
            heff_drop(v_capture_2448);
            heff_drop_rec(v_fieldTypes_2449, 3);
            V v_t_2459 = v_field_2458;
            return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam3, 2, 3, (V[]){v_bound_2424, v_x_245, v_t_2459});
          } else {
            heff_drop(v_field_2458);
            HeffT2 v_t_2463 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_fieldTypes_2449, 1), v_x_245));
            {
              V v_field_2465 = v_t_2463.f[1];
              int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
              V v_t_2467;
              if ((v_tag_2464 == ((int64_t)0ULL))) {
                V v_i_2466 = v_field_2465;
                v_t_2467 = v_i_2466;
              } else {
                heff_drop(v_field_2465);
                v_t_2467 = heff_abandon();
              }
              V v_t_2468 = heff_get_n(heff_get_n(v_e_241, 0, 8), 0, 5);
              HeffT2 v_t_2469 = (g_heff_2eelab_2erules_2efieldTyAt_24cpr(v_t_2468, v_capture_2448, v_fieldTypes_2449, v_t_2467, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
              {
                V v_field_2471 = v_t_2469.f[1];
                int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
                if ((v_tag_2470 == ((int64_t)0ULL))) {
                  heff_drop(v_sp_240);
                  V v_t_2472 = v_field_2471;
                  return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam4, 2, 3, (V[]){v_bound_2424, v_x_245, v_t_2472});
                } else {
                  heff_drop_rec(v_bound_2424, 2);
                  heff_drop(v_field_2471);
                  return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam5, 2, 2, (V[]){v_x_245, v_sp_240});
                }
              }
            }
          }
        }
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_2425, 0ULL, 1);
        heff_drop_rec(v_e_241, 8);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2424, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam6, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeInt: {
        heff_drop_rec(v_e_241, 8);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2424, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam7, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeFloat: {
        heff_drop_rec(v_e_241, 8);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2424, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam8, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeString: {
        heff_drop_rec(v_e_241, 8);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2424, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam9, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeRune: {
        heff_drop_rec(v_e_241, 8);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2424, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam10, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_2425, 0ULL, 1);
        heff_drop_rec(v_e_241, 8);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2424, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam11, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_2425, 0ULL, 1);
        heff_drop_rec(v_e_241, 8);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2424, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam12, 2, 1, (V[]){v_sp_240});
      }
      case TAG_NoRules: {
        heff_drop_rec(v_e_241, 8);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2424, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam13, 2, 1, (V[]){v_sp_240});
      }
      default: return heff_nomatch(v_t_2425);
      }
    }
  }
}
V g_heff_2eelab_2erules_2eupdatedField_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2eupdatedField(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2eupdatedField_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k2_2415 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_malg_2416 = heff_take_field(v_hd_2414, 2);
  V v_bind_2417 = heff_get_n(v_hd_2414, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(303LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_call(v_malg_2416, 1, (V[]){v_t_2420}));
  V f_ = v_bind_2417;
  args[0] = v_t_2421;
  args[1] = v_k2_2415;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam1(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k2_2428 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_malg_2429 = heff_take_field(v_hd_2427, 2);
  V v_bind_2430 = heff_get_n(v_hd_2427, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str1), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_call(v_malg_2429, 1, (V[]){v_t_2433}));
  V f_ = v_bind_2430;
  args[0] = v_t_2434;
  args[1] = v_k2_2428;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam2(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k2_2440 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_malg_2441 = heff_take_field(v_hd_2439, 2);
  V v_bind_2442 = heff_get_n(v_hd_2439, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2443 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str2), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tr(heff_call(v_malg_2441, 1, (V[]){v_t_2445}));
  V f_ = v_bind_2442;
  args[0] = v_t_2446;
  args[1] = v_k2_2440;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam3(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  V v_bound_2424 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_t_2459 = heff_env(self)[2];
  heff_drop(v_hd_2460);
  heff_clo_take(self, 3);
  V v_t_2462 = (g_heff_2eelab_2ememoed_2eproj(v_bound_2424, v_x_245));
  V f_ = v_k_2461;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2462, v_t_2459});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam4(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k_2474 = args[1];
  V v_bound_2424 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_t_2472 = heff_env(self)[2];
  heff_drop(v_hd_2473);
  heff_clo_take(self, 3);
  V v_t_2475 = (g_heff_2eelab_2ememoed_2eprojAt(v_bound_2424, v_x_245, heff_dup(v_t_2472)));
  V f_ = v_k_2474;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2475, v_t_2472});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam5(V self, V *args) {
  V v_hd_2476 = args[0];
  V v_k2_2477 = args[1];
  V v_x_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_malg_2478 = heff_take_field(v_hd_2476, 2);
  V v_bind_2479 = heff_get_n(v_hd_2476, 1, 3);
  heff_clo_take(self, 2);
  V v_t_2480 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eupdatedField_str3), v_x_245), ((V)&g_heff_2eelab_2erules_2eupdatedField_str4));
  V v_t_2481 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(332LL), NTAG(TAG_SError), v_t_2480, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tr(heff_call(v_malg_2478, 1, (V[]){v_t_2483}));
  V f_ = v_bind_2479;
  args[0] = v_t_2484;
  args[1] = v_k2_2477;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam6(V self, V *args) {
  V v_hd_2486 = args[0];
  V v_k2_2487 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_malg_2488 = heff_take_field(v_hd_2486, 2);
  V v_bind_2489 = heff_get_n(v_hd_2486, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2490 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str5), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2491 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tr(heff_call(v_malg_2488, 1, (V[]){v_t_2492}));
  V f_ = v_bind_2489;
  args[0] = v_t_2493;
  args[1] = v_k2_2487;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam7(V self, V *args) {
  V v_hd_2494 = args[0];
  V v_k2_2495 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_malg_2496 = heff_take_field(v_hd_2494, 2);
  V v_bind_2497 = heff_get_n(v_hd_2494, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2498 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str6), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tr(heff_call(v_malg_2496, 1, (V[]){v_t_24100}));
  V f_ = v_bind_2497;
  args[0] = v_t_24101;
  args[1] = v_k2_2495;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam8(V self, V *args) {
  V v_hd_24102 = args[0];
  V v_k2_24103 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_malg_24104 = heff_take_field(v_hd_24102, 2);
  V v_bind_24105 = heff_get_n(v_hd_24102, 1, 3);
  heff_clo_take(self, 1);
  V v_t_24106 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str7), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24107 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tr(heff_call(v_malg_24104, 1, (V[]){v_t_24108}));
  V f_ = v_bind_24105;
  args[0] = v_t_24109;
  args[1] = v_k2_24103;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam9(V self, V *args) {
  V v_hd_24110 = args[0];
  V v_k2_24111 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_malg_24112 = heff_take_field(v_hd_24110, 2);
  V v_bind_24113 = heff_get_n(v_hd_24110, 1, 3);
  heff_clo_take(self, 1);
  V v_t_24114 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str8), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24115 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24114})});
  V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24115})});
  V v_t_24117 = heff_tr(heff_call(v_malg_24112, 1, (V[]){v_t_24116}));
  V f_ = v_bind_24113;
  args[0] = v_t_24117;
  args[1] = v_k2_24111;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam10(V self, V *args) {
  V v_hd_24118 = args[0];
  V v_k2_24119 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_malg_24120 = heff_take_field(v_hd_24118, 2);
  V v_bind_24121 = heff_get_n(v_hd_24118, 1, 3);
  heff_clo_take(self, 1);
  V v_t_24122 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str9), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24123 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24122})});
  V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
  V v_t_24125 = heff_tr(heff_call(v_malg_24120, 1, (V[]){v_t_24124}));
  V f_ = v_bind_24121;
  args[0] = v_t_24125;
  args[1] = v_k2_24119;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam11(V self, V *args) {
  V v_hd_24127 = args[0];
  V v_k2_24128 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_malg_24129 = heff_take_field(v_hd_24127, 2);
  V v_bind_24130 = heff_get_n(v_hd_24127, 1, 3);
  heff_clo_take(self, 1);
  V v_t_24131 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str10), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24132 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24131})});
  V v_t_24133 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24132})});
  V v_t_24134 = heff_tr(heff_call(v_malg_24129, 1, (V[]){v_t_24133}));
  V f_ = v_bind_24130;
  args[0] = v_t_24134;
  args[1] = v_k2_24128;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam12(V self, V *args) {
  V v_hd_24136 = args[0];
  V v_k2_24137 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_malg_24138 = heff_take_field(v_hd_24136, 2);
  V v_bind_24139 = heff_get_n(v_hd_24136, 1, 3);
  heff_clo_take(self, 1);
  V v_t_24140 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str11), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24141 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24140})});
  V v_t_24142 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24141})});
  V v_t_24143 = heff_tr(heff_call(v_malg_24138, 1, (V[]){v_t_24142}));
  V f_ = v_bind_24139;
  args[0] = v_t_24143;
  args[1] = v_k2_24137;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam13(V self, V *args) {
  V v_hd_24144 = args[0];
  V v_k2_24145 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_malg_24146 = heff_take_field(v_hd_24144, 2);
  V v_bind_24147 = heff_get_n(v_hd_24144, 1, 3);
  heff_clo_take(self, 1);
  V v_t_24148 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str12), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24149 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24148})});
  V v_t_24150 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24149})});
  V v_t_24151 = heff_tr(heff_call(v_malg_24146, 1, (V[]){v_t_24150}));
  V f_ = v_bind_24147;
  args[0] = v_t_24151;
  args[1] = v_k2_24145;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2efindPrim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efindPrim_entry, 2, 0};

V g_heff_2eelab_2erules_2efindPrim(V v_sp_240, V v_p_241) {
top: ;
  HeffT1 v_t_242 = (g_heff_2eelab_2erules_2efindPrim_24cpr(v_sp_240, v_p_241));
  {
    V v_field_243 = v_t_242.f[0];
    return heff_tag_n(TAG_MkSyn, 1, (V[]){v_field_243});
  }
}
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efindPrim(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceSearchF_str0, 2, "p#");
V g_heff_2eelab_2erules_2eevidenceSearchF_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eevidenceSearchF_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eevidenceSearchF_lam0, 7, 0};
V g_heff_2eelab_2erules_2eevidenceSearchF_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eevidenceSearchF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eevidenceSearchF_entry, 9, 0};

V g_heff_2eelab_2erules_2eevidenceSearchF(V v_parts_240, V v_sp_241, V v_hm_242, V v_holeVal_243, V v_goal_244, V v_written_245, V v_final_246, V v_p_247, V v_p_248) {
top: ;
  V v_scope_249 = heff_take_field(v_parts_240, 0);
  V v_globals_2410 = heff_take_field(v_parts_240, 1);
  V v_lams_2411 = heff_take_field(v_parts_240, 3);
  V v_self_2412 = heff_take_field(v_parts_240, 4);
  V v_insts_2413 = heff_take_field(v_parts_240, 5);
  V v_named_2414 = heff_get_n(v_parts_240, 6, 7);
  V v_t_2415 = v_scope_249;
  V v_t_2416 = v_globals_2410;
  V v_t_2417 = v_lams_2411;
  V v_t_2418 = v_self_2412;
  V v_t_2419 = v_insts_2413;
  V v_t_2427 = heff_rec_n(8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, (V[]){v_t_2415, v_t_2416, NTAG(TAG_ForNominative), v_t_2417, v_t_2418, v_t_2419, v_named_2414, heff_tag_n(TAG_MkEvidenceSearch, 1, (V[]){((V)&g_heff_2eelab_2erules_2eevidenceSearchF_lam0_clo)})});
  return (g_heff_2eelab_2erules_2eevidenceFound(v_t_2427, heff_dup(v_sp_241), v_hm_242, v_holeVal_243, v_goal_244, heff_clo_n(g_heff_2eelab_2erules_2eevidenceSearchF_lam1, 2, 1, (V[]){v_sp_241}), v_written_245, v_final_246, v_p_247, v_p_248));
}
V g_heff_2eelab_2erules_2eevidenceSearchF_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V a6 = a[6]; V r = g_heff_2eelab_2erules_2eevidenceSearchF(a[0], a[1], a[2], a[3], a[4], a5, a6, a[7], a[8]); heff_drop(a5); heff_drop(a6); return r;
}
V g_heff_2eelab_2erules_2eevidenceSearchF_lam0(V self, V *args) {
  V v_parts2_2420 = args[0];
  V v_sp2_2421 = args[1];
  V v_hm2_2422 = args[2];
  V v_holeVal2_2423 = args[3];
  V v_goal2_2424 = args[4];
  V v_written2_2425 = args[5];
  V v_final2_2426 = args[6];
  V f_ = ((V)&g_heff_2eelab_2erules_2eevidenceSearchF_clo);
  args[0] = v_parts2_2420;
  args[1] = v_sp2_2421;
  args[2] = v_hm2_2422;
  args[3] = v_holeVal2_2423;
  args[4] = v_goal2_2424;
  args[5] = v_written2_2425;
  args[6] = v_final2_2426;
  if (heff_exact(f_, 7, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 7, args);
}
V g_heff_2eelab_2erules_2eevidenceSearchF_lam1(V self, V *args) {
  V v_path_2428 = args[0];
  V v_w_2429 = args[1];
  V v_sp_241 = heff_env(self)[0];
  V v_t_2430 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
  V v_x_2431 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eevidenceSearchF_str0), v_t_2430);
  V v_body_2432 = (g_heff_2eelab_2erules_2eevidenceCandidate_2edown_242(v_w_2429, heff_dup(v_sp_241), v_path_2428));
  heff_clo_take(self, 1);
  V v_t_2433 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_sp_241; V a_2 = v_x_2431; V a_3 = v_body_2432; V r_ = (g_heff_2eelab_2erules_2elambdaChk(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_body_2432); r_; });
  return ({ V a_0 = v_t_2433; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_t_2433); r_; });
}
V g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365_lam0, 1, 0};
Clo g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365_entry, 6, 0};

V g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365(V v_lit_240, V v_sp_241, V v_e_242, V v_a_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_243)));
  switch (heff_tag_of(v_t_246)) {
  case TAG_LikeU: {
    heff_take_n(v_t_246, 0ULL, 1);
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_246, 0ULL, 4);
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_246, 0ULL, 3);
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_246, 0ULL, 1);
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  case TAG_LikeInt: {
    heff_drop(v_sp_241);
    heff_drop(v_e_242);
    heff_drop(v_a_243);
    heff_drop(v_z_244);
    V v_t_2417 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitInt, 1, (V[]){v_lit_240}), ((V)&g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365_lam0_clo)});
    return heff_tail(v_z_245, 1, (V[]){v_t_2417});
  }
  case TAG_LikeFloat: {
    heff_drop(v_e_242);
    heff_drop(v_a_243);
    return (g_heff_2eelab_2erules_2eatFloat64_w(v_sp_241, heff_intShow(heff_dup(v_lit_240)), heff_from_int_f64(v_lit_240), v_z_244, v_z_245));
  }
  case TAG_LikeString: {
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  case TAG_LikeRune: {
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_246, 0ULL, 1);
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  case TAG_LikeFixed: {
    V v_w_2419 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24LikeFixed = heff_take_reuse_n(v_t_246, 1ULL, 1);
    heff_drop(v_e_242);
    heff_drop(v_a_243);
    HEFF_LAST return g_heff_2eelab_2erules_2eintAtFixed_24tok1(v_ru_24t_246_24LikeFixed, v_sp_241, v_w_2419, v_lit_240, v_z_244, v_z_245);
  }
  case TAG_NoRules: {
    HEFF_LAST return g_heff_2eelab_2erules_2enotANumber_24s494483907x1025599133(v_lit_240, v_sp_241, v_e_242, v_a_243, v_z_244, v_z_245);
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365_lam0(V self, V *args) {
  V v_u_2416 = args[0];
  heff_drop(v_u_2416);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
Clo g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_24dps_entry, 3, 0};

V g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_24dps(V v_ys_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_t_247 = v_a_246;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_x_2410;
    switch (heff_tag_of(v_t_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_t_247, 1);
      heff_take_n(v_t_247, 2ULL, 2);
      v_x_2410 = v_a_249;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_2410, heff_hole()});
    V v_u_2412 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2411);
    V t_0 = v_ys_240;
    V t_1 = v_xs_244;
    V t_2 = v_u_2412;
    v_ys_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2eatFloat64_24tok1_str0, 21, " is out of range for ");
HEFF_LIT(g_heff_2eelab_2erules_2eatFloat64_24tok1_str1, 49, "Float64, whose greatest is 1.7976931348623157e308");
V g_heff_2eelab_2erules_2eatFloat64_24tok1_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eatFloat64_24tok1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eatFloat64_24tok1_lam0, 1, 0};
Clo g_heff_2eelab_2erules_2eatFloat64_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eatFloat64_24tok1_entry, 6, 0};

V g_heff_2eelab_2erules_2eatFloat64_24tok1_w(V v_tok_240, V v_sp_241, V v_text_242, double v_x_243, V v_p_244, V v_p_245) {
top: ;
  V v_malg_246 = heff_take_field(v_p_244, 2);
  V v_bind_247 = heff_get_n(v_p_244, 1, 3);
  if (((v_x_243 - v_x_243) == (0.0))) {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_sp_241);
    heff_drop(v_text_242);
    heff_drop(v_malg_246);
    heff_drop(v_bind_247);
    V v_t_249 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_nf(TAG_SLitFloat, 1, 1u, (V[]){heff_word_f64(v_x_243)}), ((V)&g_heff_2eelab_2erules_2eatFloat64_24tok1_lam0_clo)});
    return heff_tail(v_p_245, 1, (V[]){v_t_249});
  } else {
    V v_t_2410 = heff_strAppend(heff_strAppend(v_text_242, ((V)&g_heff_2eelab_2erules_2eatFloat64_24tok1_str0)), ((V)&g_heff_2eelab_2erules_2eatFloat64_24tok1_str1));
    V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(346LL), NTAG(TAG_SError), v_t_2410, v_sp_241, NTAG(TAG_Nothing)});
    V v_t_2412 = heff_tag_at_n(v_tok_240, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(v_malg_246, 1, (V[]){v_t_2413}));
    return heff_tail(v_bind_247, 2, (V[]){v_t_2414, v_p_245});
  }
}
V g_heff_2eelab_2erules_2eatFloat64_24tok1(V v_tok_240, V v_sp_241, V v_text_242, V v_box_24x_243, V v_p_244, V v_p_245) {
  double v_x_243 = heff_unbox_f64(v_box_24x_243);
  return (g_heff_2eelab_2erules_2eatFloat64_24tok1_w(v_tok_240, v_sp_241, v_text_242, v_x_243, v_p_244, v_p_245));
}
V g_heff_2eelab_2erules_2eatFloat64_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eatFloat64_24tok1(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2eatFloat64_24tok1_lam0(V self, V *args) {
  V v_u_248 = args[0];
  heff_drop(v_u_248);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2etyStrZ_24tok1_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2etyStrZ_24tok1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrZ_24tok1_lam0, 1, 0};
V g_heff_2eelab_2erules_2etyStrZ_24tok1_lam2(V self, V *args);
V g_heff_2eelab_2erules_2etyStrZ_24tok1_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStrZ_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrZ_24tok1_entry, 5, 0};

V g_heff_2eelab_2erules_2etyStrZ_24tok1(V v_tok_240, V v_e_241, V v_t_242, V v_hd_243, V v_k_244) {
top: ;
  V v_malg_245 = heff_take_field(v_hd_243, 2);
  V v_bind_246 = heff_get_n(v_hd_243, 1, 3);
  V v_scope_247 = heff_take_field(v_e_241, 0);
  V v_globals_248 = heff_get_n(v_e_241, 1, 8);
  V v_t_2410 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2etyStrZ_24tok1_lam0_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(v_malg_245, 1, (V[]){v_t_2411}));
  return heff_tail(v_bind_246, 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2erules_2etyStrZ_24tok1_lam1, 1, 4, (V[]){v_t_242, v_scope_247, v_globals_248, v_k_244})});
}
V g_heff_2eelab_2erules_2etyStrZ_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etyStrZ_24tok1(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2etyStrZ_24tok1_lam0(V self, V *args) {
  V v_c_249 = args[0];
  return heff_get_n(v_c_249, 3, 9);
}
V g_heff_2eelab_2erules_2etyStrZ_24tok1_lam2(V self, V *args) {
  V v_x_2439 = args[0];
  V v_globals_248 = heff_env(self)[0];
  V v_d_2440 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2439)));
  heff_clo_take(self, 1);
  V v_t_2441 = ({ V b_0 = heff_get_n(v_globals_248, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2442 = ({ V a_0 = v_t_2441; V a_1 = v_x_2439; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_t_2441); heff_drop(v_x_2439); r_; });
  {
    V v_field_2444 = v_t_2442.f[1];
    int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
    if ((v_tag_2443 == ((int64_t)0ULL))) {
      heff_drop(v_d_2440);
      V v_x_2445 = v_field_2444;
      return v_x_2445;
    } else {
      heff_drop(v_field_2444);
      return v_d_2440;
    }
  }
}
V g_heff_2eelab_2erules_2etyStrZ_24tok1_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_t_242 = heff_env(self)[0];
  V v_scope_247 = heff_env(self)[1];
  V v_globals_248 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_t_2433;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_t_242)) {
  case TAG_VU: {
    v_t_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VDecode: {
    v_t_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFunction: {
    V v_folded_2425 = heff_dup(heff_field(v_t_242, 5));
    v_t_2433 = v_folded_2425;
    break;
  }
  case TAG_VRecord: {
    v_t_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VSum: {
    v_t_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimString: {
    v_t_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2433 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFixed: {
    v_t_2433 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_t_2434 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(heff_take_field(v_scope_247, 0), v_t_242, v_t_2433));
  HeffT2 v_t_2435 = ({ V a_0 = v_x_2413; HeffT2 r_ = (g_heff_2eelab_2eunify_2ezonker_24cpr(a_0)); heff_drop(v_x_2413); r_; });
  {
    V v_field_2437 = v_t_2435.f[1];
    heff_drop(v_t_2435.f[0]);
    V v_t_2438 = heff_tr(heff_call(v_field_2437, 1, (V[]){v_t_2434}));
    HeffT2 v_t_2446 = (g_heff_2eelab_2erename_2erkOf_24cpr(heff_clo_n(g_heff_2eelab_2erules_2etyStrZ_24tok1_lam2, 1, 1, (V[]){v_globals_248})));
    {
      V v_field_2448 = v_t_2446.f[1];
      heff_drop(v_t_2446.f[0]);
      V v_t_2449 = heff_tr(heff_call(v_field_2448, 1, (V[]){v_t_2438}));
      V v_x_2450 = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(heff_dup(g_heff_2eelab_2erules_2efreshMeta_24rec0_get()), MK_INT(0LL), heff_get_n(v_scope_247, 1, 5), v_t_2449));
      V f_ = v_k_244;
      args[0] = v_x_2450;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}