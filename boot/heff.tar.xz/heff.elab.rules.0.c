// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MentionsError 719
#define TAG_MkChk 56962
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Record 39342
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SGlobal 8650
#define TAG_SPrimArray 2913
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_UnequalTys 2248
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_VPrimArray 11892
#define LBL_aliases 1464806715
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_defaults 1389419502
#define LBL_depth 296830685
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_globals 352931696
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_large 304101205
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_var 326049
#define LBL_wantedBy 1134124532
#define LBL_written 1834876765
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_depth__wantedBy[] = {LBL_depth, LBL_wantedBy};
static uint32_t shape_el__ty__var[] = {LBL_el, LBL_ty, LBL_var};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_span__ty__keys__defaults__written[] = {LBL_span, LBL_ty, LBL_keys, LBL_defaults, LBL_written};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_array_2eempty_get(void);
V g_heff_2eelab_2ememoed_2eproj(V, V);
V g_heff_2eelab_2ememoed_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eproj_clo;
V g_heff_2eelab_2ememoed_2eprojAt(V, V, V);
V g_heff_2eelab_2ememoed_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eprojAt_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
V g_heff_2eelab_2erename_2efirstAliasOf(V, V);
V g_heff_2eelab_2erename_2efirstAliasOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2efirstAliasOf_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eadvanceSelf(V, V, V, V);
V g_heff_2eelab_2erules_2eadvanceSelf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eadvanceSelf_clo;
V g_heff_2eelab_2erules_2eandList(V);
V g_heff_2eelab_2erules_2eandList_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eandList_clo;
V g_heff_2eelab_2erules_2eannot(V, V);
V g_heff_2eelab_2erules_2eannot_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eannot_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
V g_heff_2eelab_2erules_2eapplyGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eapplyGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapplyGo_clo;
V g_heff_2eelab_2erules_2ecodeAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecodeAt_clo;
V g_heff_2eelab_2erules_2edescribedBound(V, V);
V g_heff_2eelab_2erules_2edescribedBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edescribedBound_clo;
V g_heff_2eelab_2erules_2edescribes(V);
V g_heff_2eelab_2erules_2edescribes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edescribes_clo;
V g_heff_2eelab_2erules_2eeqBareStr(V, V, V, V);
V g_heff_2eelab_2erules_2eeqBareStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqBareStr_clo;
V g_heff_2eelab_2erules_2eeqElStr(V, V, V);
V g_heff_2eelab_2erules_2eeqElStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqElStr_clo;
V g_heff_2eelab_2erules_2eeqTyStr(V, V, V);
V g_heff_2eelab_2erules_2eeqTyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqTyStr_clo;
V g_heff_2eelab_2erules_2efieldIdxs(V, V);
V g_heff_2eelab_2erules_2efieldIdxs_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldIdxs_clo;
V g_heff_2eelab_2erules_2efieldIdxs_24dps(V, V, V);
V g_heff_2eelab_2erules_2efieldIdxs_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldIdxs_24dps_clo;
V g_heff_2eelab_2erules_2efieldTyAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efieldTyAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldTyAt_clo;
V g_heff_2eelab_2erules_2efieldsNote(V);
V g_heff_2eelab_2erules_2efieldsNote_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldsNote_clo;
V g_heff_2eelab_2erules_2efindPrim(V, V);
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efindPrim_clo;
V g_heff_2eelab_2erules_2eformRecord(V, V);
V g_heff_2eelab_2erules_2eformRecord_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eformRecord_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2einstShown(V, V, V);
V g_heff_2eelab_2erules_2einstShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstShown_clo;
V g_heff_2eelab_2erules_2eintroGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eintroGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintroGo_clo;
V g_heff_2eelab_2erules_2eletted(V, V, V, V, V);
V g_heff_2eelab_2erules_2eletted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletted_clo;
V g_heff_2eelab_2erules_2ementionsLocal(V);
V g_heff_2eelab_2erules_2ementionsLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsLocal_clo;
V g_heff_2eelab_2erules_2ementionsTermF(V, V, V);
V g_heff_2eelab_2erules_2ementionsTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_clo;
V g_heff_2eelab_2erules_2ementionsTypeF(V, V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTypeF_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2eprimArray(V);
V g_heff_2eelab_2erules_2eprimArray_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprimArray_clo;
V g_heff_2eelab_2erules_2erebottom(V, V);
V g_heff_2eelab_2erules_2erebottom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erebottom_clo;
V g_heff_2eelab_2erules_2erecordIntro(V, V);
V g_heff_2eelab_2erules_2erecordIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordIntro_clo;
V g_heff_2eelab_2erules_2erecordOf(V, V);
V g_heff_2eelab_2erules_2erecordOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordOf_clo;
V g_heff_2eelab_2erules_2erecordTypeIntro(V, V);
V g_heff_2eelab_2erules_2erecordTypeIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTypeIntro_clo;
V g_heff_2eelab_2erules_2eselfAdvance(V, V, V, V, V);
V g_heff_2eelab_2erules_2eselfAdvance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eselfAdvance_clo;
V g_heff_2eelab_2erules_2etagArgsGo(V, V, V);
V g_heff_2eelab_2erules_2etagArgsGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagArgsGo_clo;
V g_heff_2eelab_2erules_2etopSearch_get(void);
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2etyStrM(V, V);
V g_heff_2eelab_2erules_2etyStrM_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrM_clo;
V g_heff_2eelab_2erules_2euniverseAt(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2euniverseAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseAt_clo;
V g_heff_2eelab_2erules_2eupdateInner(V);
V g_heff_2eelab_2erules_2eupdateInner_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdateInner_clo;
V g_heff_2eelab_2erules_2eupdatedField(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdatedField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdatedField_clo;
V g_heff_2eelab_2erules_2evaluesGo_24dps(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_24dps_clo;
V g_heff_2eelab_2erules_2evarGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2evarGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evarGo_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2eelab_2evalue_2edefaultsOf(V);
V g_heff_2eelab_2evalue_2edefaultsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edefaultsOf_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2eprojTyWith(V, V, V);
V g_heff_2eelab_2evalue_2eprojTyWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojTyWith_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2emap_24s1367173129x1257089258(V);
V g_list_2emap_24s1367173129x1257089258_entry(V self, V *a);
extern Clo g_list_2emap_24s1367173129x1257089258_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_heff_2eelab_2erules_2ementionsLocal_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsLocal_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ementionsLocal_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsLocal_entry, 1, 0};

V g_heff_2eelab_2erules_2ementionsLocal(V v_k_240) {
top: ;
  return heff_rec_n(3, shape_el__ty__var, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ementionsLocal_lam0, 2, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_heff_2eelab_2erules_2ementionsLocal_lam1, 2, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_heff_2eelab_2erules_2ementionsLocal_lam2, 2, 1, (V[]){v_k_240})});
}
V g_heff_2eelab_2erules_2ementionsLocal_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ementionsLocal(a[0]);
}
V g_heff_2eelab_2erules_2ementionsLocal_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eelab_2erules_2ementionsLocal(v_k_240));
  return ({ V a_0 = v_t_243; V a_1 = v_d_241; V a_2 = v_t_242; V r_ = (g_heff_2eelab_2erules_2ementionsTermF(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_heff_2eelab_2erules_2ementionsLocal_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2eelab_2erules_2ementionsLocal(v_k_240));
  return ({ V a_0 = v_t_246; V a_1 = v_d_244; V a_2 = v_t_245; V r_ = (g_heff_2eelab_2erules_2ementionsTypeF(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
}
V g_heff_2eelab_2erules_2ementionsLocal_lam2(V self, V *args) {
  V v_d_247 = args[0];
  V v_i_248 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intEq(v_i_248, heff_intAdd(v_d_247, v_k_240));
}
V g_heff_2eelab_2erules_2etyStrM_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrM_entry, 2, 0};

V g_heff_2eelab_2erules_2etyStrM(V v_e_240, V v_m_241) {
top: ;
  V v_t_248 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2etyStrM_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_249 = heff_tr(heff_call(heff_get_n(v_t_248, 1, 2), 1, (V[]){heff_get_n(v_m_241, 0, 2)}));
  V v_t_2410 = heff_get_n(heff_get_n(v_e_240, 0, 6), 1, 4);
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2410; V a_3 = v_t_249; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
}
V g_heff_2eelab_2erules_2etyStrM_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etyStrM(a[0], a[1]);
}
V g_heff_2eelab_2erules_2etyStrM_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_243 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_242)));
  V v_t_244 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 7);
  V v_t_245 = ({ V a_0 = v_t_244; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_x2_246 = ({ V a_0 = v_t_245; V a_1 = v_x_242; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_245); r_; });
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nothing: {
    return v_d_243;
  }
  case TAG_Just: {
    V v_x_247 = heff_field(v_x2_246, 0);
    heff_take_n(v_x2_246, 1ULL, 1);
    heff_drop(v_d_243);
    return v_x_247;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2eelab_2erules_2eeqElStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eeqElStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeqElStr_entry, 3, 0};

V g_heff_2eelab_2erules_2eeqElStr(V v_g_240, V v_cs_241, V v_v_242) {
top: ;
  V v_e_243 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_take_field(v_cs_241, 0), v_v_242));
  V v_t_249 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2eeqElStr_lam0, 1, 1, (V[]){v_g_240})));
  V v_e_2410 = heff_tr(heff_call(heff_get_n(v_t_249, 0, 2), 1, (V[]){v_e_243}));
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(MK_INT(0LL), MK_INT(0LL), heff_get_n(v_cs_241, 1, 2), v_e_2410));
}
V g_heff_2eelab_2erules_2eeqElStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eeqElStr(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eeqElStr_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_244)));
  V v_t_246 = ({ V b_0 = heff_get_n(v_g_240, 2, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_247 = ({ V a_0 = v_t_246; V a_1 = v_x_244; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_246); r_; });
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    return v_d_245;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    heff_drop(v_d_245);
    return v_x_248;
  }
  default: return heff_nomatch(v_x2_247);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str0, 5, " and ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str1, 15, " are not equal ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str2, 6, "types ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str3, 5, " and ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str4, 15, " are not equal ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str5, 9, "elements ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str6, 5, " and ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str7, 15, " are not equal ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str8, 9, "neutrals ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str9, 47, "a solution would mention what did not elaborate");
Clo g_heff_2eelab_2erules_2eprettyEqErr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprettyEqErr_entry, 2, 0};

V g_heff_2eelab_2erules_2eprettyEqErr(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_UnequalTys: {
    V v_cs_242 = heff_field(v_x2_241, 0);
    V v_a_243 = heff_field(v_x2_241, 1);
    V v_a2_244 = heff_field(v_x2_241, 2);
    V v_t_245 = (g_heff_2eelab_2erules_2eeqTyStr(heff_dup(v_g_240), heff_dup(v_cs_242), heff_dup(v_a_243)));
    V v_t_246 = (g_heff_2eelab_2erules_2eeqTyStr(v_g_240, heff_dup(v_cs_242), heff_dup(v_a2_244)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str0), heff_strAppend(v_t_246, ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str1)));
    return heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str2), heff_strAppend(v_t_245, v_t_247));
  }
  case TAG_UnequalEls: {
    V v_cs_248 = heff_field(v_x2_241, 0);
    V v_a_249 = heff_field(v_x2_241, 1);
    V v_a2_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = (g_heff_2eelab_2erules_2eeqElStr(heff_dup(v_g_240), heff_dup(v_cs_248), heff_dup(v_a_249)));
    V v_t_2412 = (g_heff_2eelab_2erules_2eeqElStr(v_g_240, heff_dup(v_cs_248), heff_dup(v_a2_2410)));
    V v_t_2413 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str3), heff_strAppend(v_t_2412, ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str4)));
    return heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str5), heff_strAppend(v_t_2411, v_t_2413));
  }
  case TAG_UnequalNeus: {
    V v_cs_2414 = heff_field(v_x2_241, 0);
    V v_h_2415 = heff_field(v_x2_241, 1);
    V v_sp_2416 = heff_field(v_x2_241, 2);
    V v_h2_2417 = heff_field(v_x2_241, 3);
    V v_sp2_2418 = heff_field(v_x2_241, 4);
    V v_t_2419 = (g_heff_2eelab_2erules_2eeqBareStr(heff_dup(v_g_240), heff_dup(v_cs_2414), heff_dup(v_h_2415), heff_dup(v_sp_2416)));
    V v_t_2420 = (g_heff_2eelab_2erules_2eeqBareStr(v_g_240, heff_dup(v_cs_2414), heff_dup(v_h2_2417), heff_dup(v_sp2_2418)));
    V v_t_2421 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str6), heff_strAppend(v_t_2420, ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str7)));
    return heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str8), heff_strAppend(v_t_2419, v_t_2421));
  }
  case TAG_MentionsError: {
    heff_drop(v_g_240);
    return ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str9);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eprettyEqErr(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2einstShown_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2einstShown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einstShown_entry, 3, 0};

V g_heff_2eelab_2erules_2einstShown(V v_e_240, V v_mc_241, V v_goal_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_244 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_243, v_goal_242));
  V v_t_245 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_t_246 = heff_tr(heff_call(heff_get_n(v_t_245, 1, 2), 1, (V[]){v_t_244}));
  V v_t_2413 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2einstShown_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2414 = heff_tr(heff_call(heff_get_n(v_t_2413, 1, 2), 1, (V[]){v_t_246}));
  V v_t_2415 = heff_get_n(heff_get_n(v_e_240, 0, 6), 1, 4);
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2415; V a_3 = v_t_2414; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
}
V g_heff_2eelab_2erules_2einstShown_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2einstShown(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2einstShown_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_248 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_247)));
  V v_t_249 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 7);
  V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_x2_2411 = ({ V a_0 = v_t_2410; V a_1 = v_x_247; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_2410); r_; });
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nothing: {
    return v_d_248;
  }
  case TAG_Just: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    heff_take_n(v_x2_2411, 1ULL, 1);
    heff_drop(v_d_248);
    return v_x_2412;
  }
  default: return heff_nomatch(v_x2_2411);
  }
}

static V g_heff_2eelab_2erules_2etopSearch_val;
static HEFF_ONCE g_heff_2eelab_2erules_2etopSearch_st;
static V g_heff_2eelab_2erules_2etopSearch_init(void) {
  return heff_rec_n(2, shape_depth__wantedBy, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2erules_2etopSearch_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2etopSearch_st)) return g_heff_2eelab_2erules_2etopSearch_val;
  return heff_global(&g_heff_2eelab_2erules_2etopSearch_val, &g_heff_2eelab_2erules_2etopSearch_st, g_heff_2eelab_2erules_2etopSearch_init);
}
V g_heff_2eelab_2erules_2eapply_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eapply_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eapply_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eapply_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eapply_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eapply_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eapply_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eapply_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapply_entry, 2, 0};

V g_heff_2eelab_2erules_2eapply(V v_sp_240, V v_syn_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eapply_lam0, 2, 2, (V[]){heff_dup(v_syn_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eapply(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eapply_lam3(V self, V *args) {
  V v_c_2411 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2411, 3, 8); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2eapply_lam5(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_m0_249 = heff_env(self)[0];
  V v_a1_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m0_249, v_a1_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eapply_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2eapplyGo(v_sp_240, v_e_242, v_x_2415, v_x_2432, v_hd_246, v_k_247));
}
V g_heff_2eelab_2erules_2eapply_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_m0_249 = heff_env(self)[0];
  V v_a1_2410 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2415)));
  V v_t_2428;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFunction: {
    V v_implicit_2421 = heff_field(v_t_2416, 3);
    heff_take_n(v_t_2416, 8ULL, 4);
    switch (heff_tag_of(v_implicit_2421)) {
    case TAG_Expl: {
      v_t_2428 = NTAG(TAG_False);
      break;
    }
    case TAG_Impl: {
      v_t_2428 = NTAG(TAG_True);
      break;
    }
    case TAG_Inst: {
      v_t_2428 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_implicit_2421);
    }
    break;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2416, 0ULL, 3);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeInt: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFloat: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeString: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeRune: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2416, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_NoRules: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V v_c_2431;
  if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
    heff_drop(v_t_2428);
    v_c_2431 = heff_clo_n(g_heff_2eelab_2erules_2eapply_lam5, 2, 2, (V[]){v_m0_249, v_a1_2410});
  } else {
    heff_drop(v_t_2428);
    v_c_2431 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2einsertImplicits_clo), 4, (V[]){heff_dup(v_e_242), heff_dup(v_sp_240), v_m0_249, v_a1_2410}));
  }
  V f_ = v_c_2431;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapply_lam6, 1, 5, (V[]){v_sp_240, v_e_242, v_x_2415, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eapply_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_a0_243 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_m0_249 = heff_field(v_x_248, 0);
    V v_a1_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eapply_lam3, 1, 1, (V[]){v_a0_243})})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2413}));
    V f_ = heff_dup(heff_rfield(v_hd_246, 1));
    heff_room[0] = v_t_2414;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eapply_lam4, 1, 6, (V[]){v_m0_249, v_a1_2410, v_e_242, v_sp_240, v_hd_246, v_k_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2eelab_2erules_2eapply_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_a0_243 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eapply_lam2, 1, 5, (V[]){v_a0_243, v_hd_246, v_e_242, v_sp_240, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eapply_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_syn_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_syn_241)) {
  case TAG_MkSyn: {
    V v_f_244 = heff_field(v_syn_241, 0);
    heff_take_n(v_syn_241, 1ULL, 1);
    v_c_245 = heff_tr(heff_call(v_f_244, 1, (V[]){heff_dup(v_e_242)}));
    break;
  }
  default: heff_nomatch(v_syn_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eapply_lam1, 2, 4, (V[]){v_c_245, v_a0_243, v_e_242, v_sp_240});
}
V g_heff_2eelab_2erules_2eannot_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eannot_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eannot_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eannot_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eannot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eannot_entry, 2, 0};

V g_heff_2eelab_2erules_2eannot(V v_typ_240, V v_chk_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eannot_lam0, 1, 2, (V[]){heff_dup(v_typ_240), heff_dup(v_chk_241)})});
}
V g_heff_2eelab_2erules_2eannot_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2eannot(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eannot_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2417 = heff_tr(heff_call(heff_get_n(v_x_248, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2421;
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nom: {
    V v_x_2418 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2418;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    v_t_2421 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2420 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x1_2417);
  }
  V v_x_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2416, v_t_2421});
  V f_ = v_k_247;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eannot_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_chk_241 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_248, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_2413;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nom: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_a_2413 = v_x_2410;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_a_2413 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2412 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_a_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  V v_c_2415;
  switch (heff_tag_of(v_chk_241)) {
  case TAG_MkChk: {
    V v_f_2414 = heff_field(v_chk_241, 0);
    heff_take_n(v_chk_241, 1ULL, 1);
    v_c_2415 = heff_tr(heff_call(v_f_2414, 2, (V[]){v_e_242, v_a_2413}));
    break;
  }
  default: heff_nomatch(v_chk_241);
  }
  V f_ = v_c_2415;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eannot_lam3, 1, 2, (V[]){v_x_248, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eannot_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_chk_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eannot_lam2, 1, 4, (V[]){v_chk_241, v_e_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eannot_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_typ_240 = heff_env(self)[0];
  V v_chk_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_typ_240)) {
  case TAG_MkTyp: {
    V v_f_243 = heff_field(v_typ_240, 0);
    heff_take_n(v_typ_240, 1ULL, 1);
    V v_t_244 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(heff_rfield(v_e_242, 0)), heff_dup(heff_rfield(v_e_242, 1)), NTAG(TAG_ForNominative), heff_dup(heff_rfield(v_e_242, 3)), heff_dup(heff_rfield(v_e_242, 4)), heff_dup(heff_rfield(v_e_242, 5))});
    v_c_245 = heff_tr(heff_call(v_f_243, 1, (V[]){v_t_244}));
    break;
  }
  default: heff_nomatch(v_typ_240);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eannot_lam1, 2, 3, (V[]){v_c_245, v_chk_241, v_e_242});
}
V g_heff_2eelab_2erules_2eprimArray_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eprimArray_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eprimArray_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eprimArray_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eprimArray_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimArray_entry, 1, 0};

V g_heff_2eelab_2erules_2eprimArray(V v_a_240) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eprimArray_lam0, 1, 1, (V[]){heff_dup(v_a_240)})});
}
V g_heff_2eelab_2erules_2eprimArray_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eprimArray(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2eprimArray_lam3(V self, V *args) {
  V v_u_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  V v_x1_249 = heff_tr(heff_call(heff_get_n(v_x_246, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2413;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nom: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_t_2413 = v_x_2410;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_t_2413 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2412 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_t_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_tag_n(TAG_VPrimArray, 1, (V[]){v_t_2413})});
}
V g_heff_2eelab_2erules_2eprimArray_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag_n(TAG_SPrimArray, 1, (V[]){heff_dup(heff_rfield(v_x_246, 0))});
  V f_ = v_k_245;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_247, heff_clo_n(g_heff_2eelab_2erules_2eprimArray_lam3, 1, 1, (V[]){v_x_246})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eprimArray_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_243;
  args[0] = v_hd_244;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eprimArray_lam2, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eprimArray_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_243;
  switch (heff_tag_of(v_a_240)) {
  case TAG_MkTyp: {
    V v_f_242 = heff_field(v_a_240, 0);
    heff_take_n(v_a_240, 1ULL, 1);
    v_c_243 = heff_tr(heff_call(v_f_242, 1, (V[]){v_e_241}));
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eprimArray_lam1, 2, 1, (V[]){v_c_243});
}
V g_heff_2eelab_2erules_2eselfAdvance_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eselfAdvance_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eselfAdvance_lam0, 1, 0};
V g_heff_2eelab_2erules_2eselfAdvance_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eselfAdvance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eselfAdvance_entry, 5, 0};

V g_heff_2eelab_2erules_2eselfAdvance(V v_e_240, V v_a_241, V v_done_242, V v_p_243, V v_p_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_e_240, 2));
  switch (heff_tag_of(v_t_245)) {
  case TAG_ForNominative: {
    heff_drop(v_a_241);
    heff_drop_rec(v_p_243, 3);
    return heff_tail(v_p_244, 1, (V[]){v_e_240});
  }
  case TAG_ForDescriptive: {
    V v_elabFor1_246 = heff_field(v_t_245, 0);
    V v_elabFor2_247 = heff_field(v_t_245, 1);
    heff_take_n(v_t_245, 3ULL, 2);
    switch (heff_tag_of(v_elabFor1_246)) {
    case TAG_HLocal: {
      heff_take_n(v_elabFor1_246, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop_rec(v_p_243, 3);
      heff_drop(v_elabFor2_247);
      return heff_tail(v_p_244, 1, (V[]){v_e_240});
    }
    case TAG_HGlobal: {
      V v_gk_249 = heff_field(v_elabFor1_246, 0);
      V v_ru_24elabFor1_246_24HGlobal = heff_take_reuse_n(v_elabFor1_246, 1ULL, 1);
      switch (heff_tag_of(v_elabFor2_247)) {
      case TAG_SpId: {
        V v_t_2411 = heff_tag_at_n(v_ru_24elabFor1_246_24HGlobal, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eselfAdvance_lam0_clo)})});
        V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
        V v_t_2413 = heff_tr(heff_call(heff_take_field(v_p_243, 2), 1, (V[]){v_t_2412}));
        return heff_tail(heff_get_n(v_p_243, 1, 3), 2, (V[]){v_t_2413, heff_clo_n(g_heff_2eelab_2erules_2eselfAdvance_lam1, 1, 5, (V[]){v_a_241, v_p_244, v_e_240, v_gk_249, heff_dup(v_done_242)})});
      }
      case TAG_SpApp: {
        heff_take_n(v_elabFor2_247, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop_rec(v_p_243, 3);
        heff_drop(v_gk_249);
        heff_drop_cell(v_ru_24elabFor1_246_24HGlobal, 1);
        return heff_tail(v_p_244, 1, (V[]){v_e_240});
      }
      case TAG_SpProj: {
        heff_take_n(v_elabFor2_247, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop_rec(v_p_243, 3);
        heff_drop(v_gk_249);
        heff_drop_cell(v_ru_24elabFor1_246_24HGlobal, 1);
        return heff_tail(v_p_244, 1, (V[]){v_e_240});
      }
      case TAG_SpSpec: {
        heff_take_n(v_elabFor2_247, 0ULL, 3);
        heff_drop(v_a_241);
        heff_drop_rec(v_p_243, 3);
        heff_drop(v_gk_249);
        heff_drop_cell(v_ru_24elabFor1_246_24HGlobal, 1);
        return heff_tail(v_p_244, 1, (V[]){v_e_240});
      }
      default: return heff_nomatch(v_elabFor2_247);
      }
    }
    case TAG_HMeta: {
      heff_take_n(v_elabFor1_246, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop_rec(v_p_243, 3);
      heff_drop(v_elabFor2_247);
      return heff_tail(v_p_244, 1, (V[]){v_e_240});
    }
    case TAG_HError: {
      heff_drop(v_a_241);
      heff_drop_rec(v_p_243, 3);
      heff_drop(v_elabFor2_247);
      return heff_tail(v_p_244, 1, (V[]){v_e_240});
    }
    default: return heff_nomatch(v_elabFor1_246);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eelab_2erules_2eselfAdvance_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2eselfAdvance(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2eselfAdvance_lam0(V self, V *args) {
  V v_c_2410 = args[0];
  return heff_get_n(v_c_2410, 7, 8);
}
V g_heff_2eelab_2erules_2eselfAdvance_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_a_241 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_gk_249 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_241)));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2415, 0ULL, 4);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeRecord: {
    V v_fieldTypes_2423 = heff_field(v_t_2415, 2);
    heff_take_n(v_t_2415, 4ULL, 3);
    V v_t_2425;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_Nothing: {
      v_t_2425 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_y_2424 = heff_field(v_x_2414, 0);
      heff_take_n(v_x_2414, 1ULL, 1);
      v_t_2425 = heff_strEq(v_y_2424, heff_dup(v_gk_249));
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
      heff_drop(v_t_2425);
      V v_sc_2426 = heff_take_field(v_e_240, 0);
      V v_v_2427 = ({ V a_0 = v_gk_249; V a_1 = v_a_241; V a_2 = v_fieldTypes_2423; V a_3 = v_done_242; V r_ = (g_heff_2eelab_2erules_2eadvanceSelf(a_0, a_1, a_2, a_3)); heff_drop(v_done_242); r_; });
      V v_t_2428 = (g_heff_2eelab_2erules_2erebottom(v_v_2427, heff_take_field(v_sc_2426, 2)));
      V v_sc_2429 = ({ V rv_2 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_sc_2426, 11ULL, 4, shape_len__names__locals__ctx, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2430 = ({ V rv_0 = v_sc_2429; V rr_ = heff_rec_reuse_nf(v_e_240, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V f_ = v_p_244;
      args[0] = v_t_2430;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_a_241);
      heff_drop(v_gk_249);
      heff_drop(v_done_242);
      heff_drop(v_fieldTypes_2423);
      heff_drop(v_t_2425);
      V f_ = v_p_244;
      args[0] = v_e_240;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeString: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_NoRules: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2415);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str1, 2, ", ");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str3, 2, " (");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str4, 17, " may be left out)");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str5, 15, ", in this order");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str6, 15, "the fields are ");
Clo g_heff_2eelab_2erules_2efieldsNote_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efieldsNote_entry, 1, 0};

V g_heff_2eelab_2erules_2efieldsNote(V v_it_240) {
top: ;
  V v_t_241 = heff_take_field(v_it_240, 2);
  V v_t_244;
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nil: {
    v_t_244 = ((V)&g_heff_2eelab_2erules_2efieldsNote_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_t_241, 0);
    V v_xs_243 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    v_t_244 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2efieldsNote_str1); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_it_240, 3)), 2, 3);
  V v_t_249;
  if (heff_intEq_c(heff_arrayLength(v_t_245), MK_INT(0LL))) {
    heff_drop_rec(v_it_240, 5);
    v_t_249 = ((V)&g_heff_2eelab_2erules_2efieldsNote_str2);
  } else {
    V v_t_247 = heff_get_n(heff_get_n(v_it_240, 3, 5), 0, 3);
    V v_t_248 = ({ V b_0 = heff_arrayToList(v_t_247); V r_ = (g_heff_2eelab_2erules_2eandList(b_0)); heff_drop(b_0); r_; });
    v_t_249 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efieldsNote_str3), heff_strAppend(v_t_248, ((V)&g_heff_2eelab_2erules_2efieldsNote_str4)));
  }
  V v_t_2410 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2eelab_2erules_2efieldsNote_str5), v_t_249));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2efieldsNote_str6), v_t_2410);
}
V g_heff_2eelab_2erules_2efieldsNote_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efieldsNote(a[0]);
}
Clo g_heff_2eelab_2erules_2efieldIdxs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efieldIdxs_entry, 2, 0};

V g_heff_2eelab_2erules_2efieldIdxs(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Nothing: {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){MK_INT(0LL), heff_hole()});
      V v_u_245 = (g_heff_2eelab_2erules_2efieldIdxs_24dps(v_at_240, v_rest_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    case TAG_Just: {
      V v_p_246 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_247 = heff_intSub(heff_intSub(heff_dup(v_at_240), MK_INT(1LL)), v_p_246);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_heff_2eelab_2erules_2efieldIdxs_24dps(v_at_240, v_rest_243, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2efieldIdxs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efieldIdxs(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2evaluesGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2evaluesGo_24dps_entry, 6, 0};

V g_heff_2eelab_2erules_2evaluesGo_24dps(V v_n_240, V v_places_241, V v_x3_242, V v_x4_243, V v_i_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_places_241);
    heff_drop(v_x4_243);
    heff_drop(v_i_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_m_246 = heff_field(v_x3_242, 0);
    V v_rest_247 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_n_240);
      heff_drop(v_places_241);
      heff_drop(v_i_244);
      heff_drop(v_m_246);
      heff_drop(v_rest_247);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_x41_248 = heff_field(v_x4_243, 0);
      V v_pls_249 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_248)) {
      case TAG_Nothing: {
        heff_drop(v_m_246);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_n_240;
        V t_1 = v_places_241;
        V t_2 = v_rest_247;
        V t_3 = v_pls_249;
        V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
        V t_5 = v_d_245;
        v_n_240 = t_0;
        v_places_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        v_i_244 = t_4;
        v_d_245 = t_5;
        goto top;
      }
      case TAG_Just: {
        V v_p_2410 = heff_field(v_x41_248, 0);
        heff_take_n(v_x41_248, 1ULL, 1);
        V v_t_2411 = heff_tr(g_heff_2eelab_2erules_2ecodeAt(heff_dup(v_n_240), v_p_2410, heff_dup(v_places_241), heff_dup(v_m_246), heff_dup(v_i_244)));
        V v_cell_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_246, v_t_2411}), heff_hole()});
        V v_u_2413 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2412));
        heff_drop(v_u_2413);
        V t_0 = v_n_240;
        V t_1 = v_places_241;
        V t_2 = v_rest_247;
        V t_3 = v_pls_249;
        V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
        V t_5 = v_cell_2412;
        v_n_240 = t_0;
        v_places_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        v_i_244 = t_4;
        v_d_245 = t_5;
        goto top;
      }
      default: return heff_nomatch(v_x41_248);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2evaluesGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2evaluesGo_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2eelab_2erules_2edescribedBound_str0, 13, "` to its name");
HEFF_LIT(g_heff_2eelab_2erules_2edescribedBound_str1, 107, "` is a type written in place, and a default this record is given names it: define the type apart, and set `");
HEFF_LIT(g_heff_2eelab_2erules_2edescribedBound_str2, 1, "`");
V g_heff_2eelab_2erules_2edescribedBound_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2edescribedBound_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edescribedBound_lam0, 2, 0};
V g_heff_2eelab_2erules_2edescribedBound_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2edescribedBound_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edescribedBound_lam1, 2, 0};
V g_heff_2eelab_2erules_2edescribedBound_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2edescribedBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edescribedBound_entry, 2, 0};

V g_heff_2eelab_2erules_2edescribedBound(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2erules_2edescribedBound_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return ((V)&g_heff_2eelab_2erules_2edescribedBound_lam1_clo);
    }
    case TAG_Cons: {
      V v_b_248 = heff_field(v_x2_241, 0);
      V v_bs_249 = heff_field(v_x2_241, 1);
      if ((heff_dup(v_b_248) == NTAG(TAG_True))) {
        V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_m_244, 2)), 0, 2);
        V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2eelab_2erules_2edescribes(a_0)); heff_drop(v_t_2410); r_; });
        if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
          heff_drop(v_t_2411);
          return heff_clo_n(g_heff_2eelab_2erules_2edescribedBound_lam2, 2, 1, (V[]){heff_dup(v_m_244)});
        } else {
          heff_drop(v_t_2411);
          V t_0 = v_rest_245;
          V t_1 = v_bs_249;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      } else {
        V t_0 = v_rest_245;
        V t_1 = v_bs_249;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2edescribedBound_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2edescribedBound(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2edescribedBound_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edescribedBound_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edescribedBound_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_m_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_strAppend(heff_dup(heff_rfield(v_m_244, 0)), ((V)&g_heff_2eelab_2erules_2edescribedBound_str0));
  V v_t_2415 = heff_strAppend(heff_take_field(v_m_244, 0), heff_strAppend(((V)&g_heff_2eelab_2erules_2edescribedBound_str1), v_t_2414));
  V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(344LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2erules_2edescribedBound_str2), v_t_2415), heff_get_n(v_m_244, 4, 5), NTAG(TAG_Nothing)});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2418}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  args[0] = v_t_2419;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_str0, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_str1, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_str2, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_str3, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_str4, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_str5, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_str6, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_str7, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_str8, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_str9, 55, "tried to check a record expression at a non-record type");
V g_heff_2eelab_2erules_2erecordIntro_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordIntro_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordIntro_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordIntro_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordIntro_entry, 2, 0};

V g_heff_2eelab_2erules_2erecordIntro(V v_sp_240, V v_fieldSettings_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_lam0, 4, 2, (V[]){v_sp_240, v_fieldSettings_241})});
}
V g_heff_2eelab_2erules_2erecordIntro_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordIntro(a[0], a[1]);
}
V g_heff_2eelab_2erules_2erecordIntro_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2erecordIntro_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_e0_242 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2erules_2eletted(v_e0_242, v_x_2410, v_x_2435, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2erecordIntro_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_fieldSettings_241 = heff_env(self)[3];
  V v_e0_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2410)));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_LikeU: {
    V v_ru_24t_2411_24LikeU = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag_at_n(v_ru_24t_2411_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2415}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2416;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2411, 0ULL, 4);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str1), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2423}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2424;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRecord: {
    V v_capture_2426 = heff_field(v_t_2411, 1);
    V v_fieldTypes_2427 = heff_field(v_t_2411, 2);
    heff_take_n(v_t_2411, 6ULL, 3);
    V v_t_2428 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2427, 0)));
    V v_t_2429 = (g_heff_2eelab_2evalue_2edefaultsOf(heff_dup(v_x_2410)));
    V v_t_2430 = (g_list_2emap_24s1367173129x1257089258(heff_dup(v_fieldSettings_241)));
    V v_t_2431 = heff_arrayToList(heff_take_field(v_fieldTypes_2427, 0));
    V v_t_2432 = heff_arrayToList(heff_get_n(v_fieldTypes_2427, 2, 3));
    V v_t_2433 = (g_heff_2eutil_2edict_2ezipKV(v_t_2431, v_t_2432));
    V v_c_2434 = (g_heff_2eelab_2erules_2eintroGo(heff_dup(v_e0_242), heff_rec_n(5, shape_span__ty__keys__defaults__written, (V[]){v_sp_240, heff_dup(v_x_2410), v_t_2428, v_t_2429, v_t_2430}), NTAG(TAG_Nil), v_capture_2426, v_fieldSettings_241, v_t_2433));
    V f_ = v_c_2434;
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_lam3, 1, 4, (V[]){v_e0_242, v_x_2410, v_hd_244, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2411_24LikeSum = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str2), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2438 = heff_tag_at_n(v_ru_24t_2411_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2439}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2440;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2441 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str3), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2443}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2444;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2447}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2448;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2449 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2451}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2452;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2453 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2455}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2456;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2411_24LikeArray = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2459 = heff_tag_at_n(v_ru_24t_2411_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2460}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2461;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2411_24LikeFixed = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2463 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2464 = heff_tag_at_n(v_ru_24t_2411_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2465}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2466;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2467 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2469}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2470;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2eelab_2erules_2erecordIntro_lam0(V self, V *args) {
  V v_e0_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_fieldSettings_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_lam2, 1, 5, (V[]){v_sp_240, v_hd_244, v_k_245, v_fieldSettings_241, v_e0_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2etagArgsGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagArgsGo_lam0, 2, 0};
V g_heff_2eelab_2erules_2etagArgsGo_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2etagArgsGo_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagArgsGo_lam1, 2, 0};
V g_heff_2eelab_2erules_2etagArgsGo_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2etagArgsGo_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagArgsGo_lam2, 2, 0};
V g_heff_2eelab_2erules_2etagArgsGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2etagArgsGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2etagArgsGo_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2etagArgsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagArgsGo_entry, 3, 0};

V g_heff_2eelab_2erules_2etagArgsGo(V v_e_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      return ((V)&g_heff_2eelab_2erules_2etagArgsGo_lam0_clo);
    }
    case TAG_Cons: {
      heff_take_n(v_x3_242, 0ULL, 2);
      return ((V)&g_heff_2eelab_2erules_2etagArgsGo_lam1_clo);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_Cons: {
    V v_c_249 = heff_field(v_x2_241, 0);
    V v_cs_2410 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_e_240);
      heff_drop(v_c_249);
      heff_drop(v_cs_2410);
      return ((V)&g_heff_2eelab_2erules_2etagArgsGo_lam2_clo);
    }
    case TAG_Cons: {
      V v_t_2413 = heff_field(v_x3_242, 0);
      V v_ts_2414 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_a_2415 = heff_tr(heff_call(v_t_2413, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_c_2417;
      switch (heff_tag_of(v_c_249)) {
      case TAG_MkChk: {
        V v_f_2416 = heff_field(v_c_249, 0);
        heff_take_n(v_c_249, 1ULL, 1);
        v_c_2417 = heff_tr(heff_call(v_f_2416, 2, (V[]){heff_dup(v_e_240), v_a_2415}));
        break;
      }
      default: heff_nomatch(v_c_249);
      }
      return heff_clo_n(g_heff_2eelab_2erules_2etagArgsGo_lam3, 2, 4, (V[]){v_c_2417, v_e_240, v_cs_2410, v_ts_2414});
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2etagArgsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etagArgsGo(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2420, v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_cs_2410 = heff_env(self)[1];
  V v_ts_2414 = heff_env(self)[2];
  V v_hd_2418 = heff_env(self)[3];
  V v_k_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2421 = (g_heff_2eelab_2erules_2etagArgsGo(v_e_240, v_cs_2410, v_ts_2414));
  V f_ = v_c_2421;
  heff_room[0] = v_hd_2418;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2etagArgsGo_lam5, 1, 2, (V[]){v_k_2419, v_x_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2etagArgsGo_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_cs_2410 = heff_env(self)[2];
  V v_ts_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2etagArgsGo_lam4, 1, 5, (V[]){v_e_240, v_cs_2410, v_ts_2414, v_hd_2418, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2eupdateInner_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdateInner_entry, 1, 0};

V g_heff_2eelab_2erules_2eupdateInner(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_UpdateTo: {
      return NTAG(TAG_Nothing);
    }
    case TAG_UpdateIn: {
      V v_fs_2410 = heff_field(v_x11_241, 3);
      V v_x2_2411 = (g_heff_2eelab_2erules_2eupdateInner(v_rest_242));
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_more_2412 = heff_field(v_x2_2411, 0);
        V v_ru_24x2_2411_24Just = heff_take_reuse_n(v_x2_2411, 1ULL, 1);
        V v_t_2413 = (g_heff_2eelab_2erules_2eappendP(heff_dup(v_fs_2410), v_more_2412));
        return heff_tag_at_n(v_ru_24x2_2411_24Just, TAG_Just, 1, (V[]){v_t_2413});
      }
      default: return heff_nomatch(v_x2_2411);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eupdateInner_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eupdateInner(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str0, 34, "the record updated is out of scope");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str1, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str2, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str3, 18, "the type of field ");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str4, 77, " depends on the fields before it, and what the record's are is not known here");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str5, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str6, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str7, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str8, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str9, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str10, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str11, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str12, 53, "tried to update a value that was not of a record type");
V g_heff_2eelab_2erules_2eupdatedField_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam13(V self, V *args);
Clo g_heff_2eelab_2erules_2eupdatedField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdatedField_entry, 6, 0};

V g_heff_2eelab_2erules_2eupdatedField(V v_sp_240, V v_e_241, V v_r_242, V v_g_243, V v_a_244, V v_x_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 1, 4);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 3, 4);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 2, 4);
  V v_it_249 = ({ V a_0 = v_r_242; V a_1 = v_t_246; V a_2 = v_t_247; V a_3 = v_t_248; V a_4 = MK_INT(0LL); V a_5 = MK_INT(0LL); V r_ = (g_heff_2eelab_2erules_2evarGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_247); r_; });
  switch (heff_tag_of(v_it_249)) {
  case TAG_Left: {
    heff_take_n(v_it_249, 0ULL, 1);
    heff_drop_rec(v_e_241, 6);
    heff_drop_rec(v_g_243, 2);
    heff_drop(v_a_244);
    heff_drop(v_x_245);
    return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam0, 2, 1, (V[]){v_sp_240});
  }
  case TAG_Right: {
    V v_it1_2417 = heff_field(v_it_249, 0);
    heff_take_n(v_it_249, 1ULL, 1);
    switch (heff_tag_of(v_it1_2417)) {
    case TAG_MkPair: {
      V v_v_2418 = heff_field(v_it1_2417, 0);
      heff_take_n(v_it1_2417, 1ULL, 2);
      V v_bound_2420 = ({ V rv_1 = heff_dup(heff_rfield(v_g_243, 1)); V rr_ = heff_rec_reuse_nf(v_v_2418, 1ULL, 2, shape_stx__val, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2421 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_244)));
      switch (heff_tag_of(v_t_2421)) {
      case TAG_LikeU: {
        heff_take_n(v_t_2421, 0ULL, 1);
        heff_drop_rec(v_e_241, 6);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2420, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam1, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeFunction: {
        heff_take_n(v_t_2421, 0ULL, 4);
        heff_drop_rec(v_e_241, 6);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2420, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam2, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeRecord: {
        V v_capture_2440 = heff_field(v_t_2421, 1);
        V v_fieldTypes_2441 = heff_field(v_t_2421, 2);
        heff_take_n(v_t_2421, 6ULL, 3);
        V v_x1_2442 = heff_tr(heff_call(heff_get_n(v_g_243, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
        V v_v_2446;
        switch (heff_tag_of(v_x1_2442)) {
        case TAG_Nom: {
          V v_x_2443 = heff_field(v_x1_2442, 0);
          heff_take_n(v_x1_2442, 1ULL, 1);
          v_v_2446 = v_x_2443;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2442, 0ULL, 1);
          v_v_2446 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2445 = heff_field(v_x1_2442, 0);
          heff_take_n(v_x1_2442, 1ULL, 1);
          v_v_2446 = v_x_2445;
          break;
        }
        default: heff_nomatch(v_x1_2442);
        }
        V v_t_2447 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_2446));
        V v_t_2448 = (g_heff_2eelab_2evalue_2eprojTyWith(v_a_244, v_t_2447, heff_dup(v_x_245)));
        switch (heff_tag_of(v_t_2448)) {
        case TAG_Nothing: {
          V v_t_2449 = heff_get_n(heff_get_n(v_e_241, 0, 6), 0, 4);
          V v_t_2450 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_245), heff_rfield(v_fieldTypes_2441, 1)));
          V v_t_2452;
          switch (heff_tag_of(v_t_2450)) {
          case TAG_Nothing: {
            v_t_2452 = heff_abandon();
            break;
          }
          case TAG_Just: {
            V v_i_2451 = heff_field(v_t_2450, 0);
            heff_take_n(v_t_2450, 1ULL, 1);
            v_t_2452 = v_i_2451;
            break;
          }
          default: heff_nomatch(v_t_2450);
          }
          V v_t_2453 = (g_heff_2eelab_2erules_2efieldTyAt(v_t_2449, v_capture_2440, v_fieldTypes_2441, v_t_2452, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
          switch (heff_tag_of(v_t_2453)) {
          case TAG_Nothing: {
            heff_drop_rec(v_bound_2420, 2);
            return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam3, 2, 2, (V[]){v_x_245, v_sp_240});
          }
          case TAG_Just: {
            V v_t_2461 = heff_field(v_t_2453, 0);
            heff_take_n(v_t_2453, 1ULL, 1);
            heff_drop(v_sp_240);
            return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam4, 2, 3, (V[]){v_bound_2420, v_x_245, v_t_2461});
          }
          default: return heff_nomatch(v_t_2453);
          }
        }
        case TAG_Just: {
          V v_t_2465 = heff_field(v_t_2448, 0);
          heff_take_n(v_t_2448, 1ULL, 1);
          heff_drop(v_sp_240);
          heff_drop_rec(v_e_241, 6);
          heff_drop(v_capture_2440);
          heff_drop_rec(v_fieldTypes_2441, 3);
          return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam5, 2, 3, (V[]){v_bound_2420, v_x_245, v_t_2465});
        }
        default: return heff_nomatch(v_t_2448);
        }
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_2421, 0ULL, 1);
        heff_drop_rec(v_e_241, 6);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2420, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam6, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeInt: {
        heff_drop_rec(v_e_241, 6);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2420, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam7, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeFloat: {
        heff_drop_rec(v_e_241, 6);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2420, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam8, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeString: {
        heff_drop_rec(v_e_241, 6);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2420, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam9, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeRune: {
        heff_drop_rec(v_e_241, 6);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2420, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam10, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_2421, 0ULL, 1);
        heff_drop_rec(v_e_241, 6);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2420, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam11, 2, 1, (V[]){v_sp_240});
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_2421, 0ULL, 1);
        heff_drop_rec(v_e_241, 6);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2420, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam12, 2, 1, (V[]){v_sp_240});
      }
      case TAG_NoRules: {
        heff_drop_rec(v_e_241, 6);
        heff_drop_rec(v_g_243, 2);
        heff_drop(v_a_244);
        heff_drop(v_x_245);
        heff_drop_rec(v_bound_2420, 2);
        return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam13, 2, 1, (V[]){v_sp_240});
      }
      default: return heff_nomatch(v_t_2421);
      }
    }
    default: return heff_nomatch(v_it1_2417);
    }
  }
  default: return heff_nomatch(v_it_249);
  }
}
V g_heff_2eelab_2erules_2eupdatedField_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eupdatedField(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2eupdatedField_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k2_2412 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(303LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_2411, 2), 1, (V[]){v_t_2415}));
  V f_ = heff_get_n(v_hd_2411, 1, 3);
  args[0] = v_t_2416;
  args[1] = v_k2_2412;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam1(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k2_2424 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str1), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(heff_take_field(v_hd_2423, 2), 1, (V[]){v_t_2427}));
  V f_ = heff_get_n(v_hd_2423, 1, 3);
  args[0] = v_t_2428;
  args[1] = v_k2_2424;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam2(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k2_2434 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str2), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_call(heff_take_field(v_hd_2433, 2), 1, (V[]){v_t_2437}));
  V f_ = heff_get_n(v_hd_2433, 1, 3);
  args[0] = v_t_2438;
  args[1] = v_k2_2434;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam3(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k2_2455 = args[1];
  V v_x_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2456 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eupdatedField_str3), heff_strAppend(v_x_245, ((V)&g_heff_2eelab_2erules_2eupdatedField_str4)));
  V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(332LL), NTAG(TAG_SError), v_t_2456, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tr(heff_call(heff_take_field(v_hd_2454, 2), 1, (V[]){v_t_2459}));
  V f_ = heff_get_n(v_hd_2454, 1, 3);
  args[0] = v_t_2460;
  args[1] = v_k2_2455;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam4(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_bound_2420 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_t_2461 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2462);
  V v_t_2464 = (g_heff_2eelab_2ememoed_2eprojAt(v_bound_2420, v_x_245, heff_dup(v_t_2461)));
  V f_ = v_k_2463;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2464, v_t_2461});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam5(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_bound_2420 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_t_2465 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2466);
  V v_t_2468 = (g_heff_2eelab_2ememoed_2eproj(v_bound_2420, v_x_245));
  V f_ = v_k_2467;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2468, v_t_2465});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam6(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k2_2471 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2472 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str5), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tr(heff_call(heff_take_field(v_hd_2470, 2), 1, (V[]){v_t_2474}));
  V f_ = heff_get_n(v_hd_2470, 1, 3);
  args[0] = v_t_2475;
  args[1] = v_k2_2471;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam7(V self, V *args) {
  V v_hd_2476 = args[0];
  V v_k2_2477 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2478 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str6), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tr(heff_call(heff_take_field(v_hd_2476, 2), 1, (V[]){v_t_2480}));
  V f_ = heff_get_n(v_hd_2476, 1, 3);
  args[0] = v_t_2481;
  args[1] = v_k2_2477;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam8(V self, V *args) {
  V v_hd_2482 = args[0];
  V v_k2_2483 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2484 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str7), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2485 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tr(heff_call(heff_take_field(v_hd_2482, 2), 1, (V[]){v_t_2486}));
  V f_ = heff_get_n(v_hd_2482, 1, 3);
  args[0] = v_t_2487;
  args[1] = v_k2_2483;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam9(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k2_2489 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2490 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str8), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2491 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tr(heff_call(heff_take_field(v_hd_2488, 2), 1, (V[]){v_t_2492}));
  V f_ = heff_get_n(v_hd_2488, 1, 3);
  args[0] = v_t_2493;
  args[1] = v_k2_2489;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam10(V self, V *args) {
  V v_hd_2494 = args[0];
  V v_k2_2495 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2496 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str9), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tr(heff_call(heff_take_field(v_hd_2494, 2), 1, (V[]){v_t_2498}));
  V f_ = heff_get_n(v_hd_2494, 1, 3);
  args[0] = v_t_2499;
  args[1] = v_k2_2495;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam11(V self, V *args) {
  V v_hd_24101 = args[0];
  V v_k2_24102 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24103 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str10), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24104 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tr(heff_call(heff_take_field(v_hd_24101, 2), 1, (V[]){v_t_24105}));
  V f_ = heff_get_n(v_hd_24101, 1, 3);
  args[0] = v_t_24106;
  args[1] = v_k2_24102;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam12(V self, V *args) {
  V v_hd_24108 = args[0];
  V v_k2_24109 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24110 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str11), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24111 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24110})});
  V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tr(heff_call(heff_take_field(v_hd_24108, 2), 1, (V[]){v_t_24112}));
  V f_ = heff_get_n(v_hd_24108, 1, 3);
  args[0] = v_t_24113;
  args[1] = v_k2_24109;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam13(V self, V *args) {
  V v_hd_24114 = args[0];
  V v_k2_24115 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24116 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str12), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24117 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24116})});
  V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
  V v_t_24119 = heff_tr(heff_call(heff_take_field(v_hd_24114, 2), 1, (V[]){v_t_24118}));
  V f_ = heff_get_n(v_hd_24114, 1, 3);
  args[0] = v_t_24119;
  args[1] = v_k2_24115;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2erecordTypeIntro_str0, 11, "its field `");
HEFF_LIT(g_heff_2eelab_2erules_2erecordTypeIntro_str1, 113, "` is no run-time data: a record with such a field is a theory -- declare it with `theory X where`, a field a line");
V g_heff_2eelab_2erules_2erecordTypeIntro_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordTypeIntro_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordTypeIntro_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordTypeIntro_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordTypeIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTypeIntro_entry, 2, 0};

V g_heff_2eelab_2erules_2erecordTypeIntro(V v_sp_240, V v_fieldTyps_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordTypeIntro_lam0, 4, 2, (V[]){v_fieldTyps_241, v_sp_240})});
}
V g_heff_2eelab_2erules_2erecordTypeIntro_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordTypeIntro(a[0], a[1]);
}
V g_heff_2eelab_2erules_2erecordTypeIntro_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2erecordTypeIntro_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_dup(heff_rfield(v_x_2412, 3));
  V v_t_2416;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    v_t_2416 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_field_2414 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24Just = heff_take_reuse_n(v_t_2413, 1ULL, 1);
    V v_t_2415 = heff_strAppend(((V)&g_heff_2eelab_2erules_2erecordTypeIntro_str0), heff_strAppend(v_field_2414, ((V)&g_heff_2eelab_2erules_2erecordTypeIntro_str1)));
    v_t_2416 = heff_tag_at_n(v_ru_24t_2413_24Just, TAG_Just, 1, (V[]){v_t_2415});
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  V v_t_2417 = (g_heff_2eelab_2erules_2erecordOf(heff_dup(v_e_242), v_x_2412));
  return (g_heff_2eelab_2erules_2euniverseAt(v_sp_240, v_t_2416, v_e_242, v_x_2410, v_t_2417, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2erecordTypeIntro_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_fieldTyps_241 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = (g_heff_2eelab_2erules_2eformRecord(heff_dup(v_e_242), v_fieldTyps_241));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordTypeIntro_lam3, 1, 5, (V[]){v_e_242, v_sp_240, v_x_2410, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2erecordTypeIntro_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_fieldTyps_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordTypeIntro_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordTypeIntro_lam2, 1, 5, (V[]){v_e_242, v_fieldTyps_241, v_hd_244, v_sp_240, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2efindPrim_str0, 17, "no such variable ");
HEFF_LIT(g_heff_2eelab_2erules_2efindPrim_str1, 9, " in scope");
V g_heff_2eelab_2erules_2efindPrim_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efindPrim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efindPrim_entry, 2, 0};

V g_heff_2eelab_2erules_2efindPrim(V v_sp_240, V v_p_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam0, 1, 2, (V[]){v_p_241, v_sp_240})});
}
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efindPrim(a[0], a[1]);
}
V g_heff_2eelab_2erules_2efindPrim_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k2_246 = args[1];
  V v_p_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efindPrim_str0), heff_strAppend(v_p_241, ((V)&g_heff_2eelab_2erules_2efindPrim_str1)));
  V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(308LL), NTAG(TAG_SError), v_t_247, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2410}));
  V f_ = heff_get_n(v_hd_245, 1, 3);
  args[0] = v_t_2411;
  args[1] = v_k2_246;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efindPrim_lam3(V self, V *args) {
  V v_u_2415 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_e_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2415);
  return (g_heff_2eelab_2erules_2etyStr(v_e_242, heff_get_n(v_e_2412, 3, 4)));
}
V g_heff_2eelab_2erules_2efindPrim_lam5(V self, V *args) {
  V v_u_2420 = args[0];
  V v_e_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2420);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_e_2412, 2, 4)});
}
V g_heff_2eelab_2erules_2efindPrim_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_e_2412 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2419);
  V v_t_2421 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_p_241}), heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam5, 1, 1, (V[]){heff_dup(v_e_2412)})});
  V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, heff_get_n(v_e_2412, 3, 4)});
  V f_ = v_k_2414;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efindPrim_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_e_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_240, heff_dup(v_p_241), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_241)}), NTAG(TAG_False), heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam3, 1, 2, (V[]){v_e_242, heff_dup(v_e_2412)})});
  V v_t_2417 = heff_tag_n(TAG_Record, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_2413, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})}));
  V f_ = heff_get_n(v_hd_2413, 1, 3);
  args[0] = v_t_2418;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam4, 1, 3, (V[]){v_p_241, v_e_2412, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efindPrim_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_242, 1)), 1, 7);
  V v_t_244 = ({ V a_0 = heff_dup(v_p_241); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_e_242, 6);
    return heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam1, 2, 2, (V[]){v_p_241, v_sp_240});
  }
  case TAG_Just: {
    V v_e_2412 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam2, 2, 4, (V[]){v_sp_240, v_p_241, v_e_242, v_e_2412});
  }
  default: return heff_nomatch(v_t_244);
  }
}