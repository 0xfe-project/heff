// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Become 65038
#define TAG_Describe 2650
#define TAG_Escapes 7836
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MentionsError 719
#define TAG_MkChk 56962
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Record 39342
#define TAG_SError 24172
#define TAG_SGlobal 8650
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_UnequalTys 2248
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_defaults 1389419502
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_globals 352931696
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_var 326049
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_el__ty__var[] = {LBL_el, LBL_ty, LBL_var};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_array_2eempty_get(void);
V g_heff_2eelab_2ememoed_2eproj(V, V);
V g_heff_2eelab_2ememoed_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eproj_clo;
V g_heff_2eelab_2ememoed_2eprojAt(V, V, V);
V g_heff_2eelab_2ememoed_2eprojAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eprojAt_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eadvanceSelf(V, V, V, V);
V g_heff_2eelab_2erules_2eadvanceSelf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eadvanceSelf_clo;
V g_heff_2eelab_2erules_2eandList(V);
V g_heff_2eelab_2erules_2eandList_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eandList_clo;
V g_heff_2eelab_2erules_2eannot(V, V);
V g_heff_2eelab_2erules_2eannot_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eannot_clo;
V g_heff_2eelab_2erules_2ecodeAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecodeAt_clo;
V g_heff_2eelab_2erules_2edelayChkOn(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkOn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkOn_clo;
V g_heff_2eelab_2erules_2eeqBareStr(V, V, V, V);
V g_heff_2eelab_2erules_2eeqBareStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqBareStr_clo;
V g_heff_2eelab_2erules_2eeqElStr(V, V, V);
V g_heff_2eelab_2erules_2eeqElStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqElStr_clo;
V g_heff_2eelab_2erules_2eeqTyStr(V, V, V);
V g_heff_2eelab_2erules_2eeqTyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqTyStr_clo;
V g_heff_2eelab_2erules_2efieldIdxs(V, V);
V g_heff_2eelab_2erules_2efieldIdxs_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldIdxs_clo;
V g_heff_2eelab_2erules_2efieldIdxs_24dps(V, V, V);
V g_heff_2eelab_2erules_2efieldIdxs_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldIdxs_24dps_clo;
HeffT2 g_heff_2eelab_2erules_2efieldTyAt_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efieldsNote(V);
V g_heff_2eelab_2erules_2efieldsNote_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldsNote_clo;
V g_heff_2eelab_2erules_2efindPrim(V, V);
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efindPrim_clo;
V g_heff_2eelab_2erules_2ementionsLocal(V);
V g_heff_2eelab_2erules_2ementionsLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsLocal_clo;
V g_heff_2eelab_2erules_2ementionsTermF(V, V, V);
V g_heff_2eelab_2erules_2ementionsTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_clo;
V g_heff_2eelab_2erules_2ementionsTypeF(V, V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTypeF_clo;
V g_heff_2eelab_2erules_2enumLitAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_clo;
HeffT1 g_heff_2eelab_2erules_2enumLitChk_24cpr(V, V);
V g_heff_2eelab_2erules_2enumLitWait(V, V, V);
V g_heff_2eelab_2erules_2enumLitWait_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitWait_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2erebottom(V, V);
V g_heff_2eelab_2erules_2erebottom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erebottom_clo;
V g_heff_2eelab_2erules_2eselfAdvance(V, V, V, V, V);
V g_heff_2eelab_2erules_2eselfAdvance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eselfAdvance_clo;
V g_heff_2eelab_2erules_2espineHasLocal(V, V);
V g_heff_2eelab_2erules_2espineHasLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2espineHasLocal_clo;
V g_heff_2eelab_2erules_2etagArgsGo(V, V, V);
V g_heff_2eelab_2erules_2etagArgsGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagArgsGo_clo;
V g_heff_2eelab_2erules_2etyStrIn(V, V, V);
V g_heff_2eelab_2erules_2etyStrIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrIn_clo;
V g_heff_2eelab_2erules_2etyStrM(V, V);
V g_heff_2eelab_2erules_2etyStrM_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStrM_clo;
V g_heff_2eelab_2erules_2eupdatedField(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdatedField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdatedField_clo;
V g_heff_2eelab_2erules_2evaluesGo_24dps(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_24dps_clo;
HeffT2 g_heff_2eelab_2erules_2evarGo_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
HeffT2 g_heff_2eelab_2evalue_2eprojTyWith_24cpr(V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_heff_2eelab_2erules_2ementionsLocal_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsLocal_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ementionsLocal_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsLocal_entry, 1, 0};

V g_heff_2eelab_2erules_2ementionsLocal(V v_k_240) {
top: ;
  return heff_rec_n(3, shape_el__ty__var, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ementionsLocal_lam0, 2, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_heff_2eelab_2erules_2ementionsLocal_lam1, 2, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_heff_2eelab_2erules_2ementionsLocal_lam2, 2, 1, (V[]){v_k_240})});
}
V g_heff_2eelab_2erules_2ementionsLocal_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ementionsLocal(a[0]);
}
V g_heff_2eelab_2erules_2ementionsLocal_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eelab_2erules_2ementionsLocal(v_k_240));
  return ({ V a_0 = v_t_243; V a_1 = v_d_241; V a_2 = v_t_242; V r_ = (g_heff_2eelab_2erules_2ementionsTermF(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_heff_2eelab_2erules_2ementionsLocal_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2eelab_2erules_2ementionsLocal(v_k_240));
  return ({ V a_0 = v_t_246; V a_1 = v_d_244; V a_2 = v_t_245; V r_ = (g_heff_2eelab_2erules_2ementionsTypeF(a_0, a_1, a_2)); heff_drop(v_t_245); r_; });
}
V g_heff_2eelab_2erules_2ementionsLocal_lam2(V self, V *args) {
  V v_d_247 = args[0];
  V v_i_248 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intEq(v_i_248, heff_intAdd(v_d_247, v_k_240));
}
V g_heff_2eelab_2erules_2etyStrM_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStrM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStrM_entry, 2, 0};

V g_heff_2eelab_2erules_2etyStrM(V v_e_240, V v_m_241) {
top: ;
  V v_t_2411 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2etyStrM_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2412 = heff_tr(heff_call(heff_get_n(v_t_2411, 1, 2), 1, (V[]){heff_get_n(v_m_241, 0, 2)}));
  V v_t_2413 = heff_get_n(heff_get_n(v_e_240, 0, 6), 1, 4);
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2413; V a_3 = v_t_2412; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
}
V g_heff_2eelab_2erules_2etyStrM_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etyStrM(a[0], a[1]);
}
V g_heff_2eelab_2erules_2etyStrM_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_243 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_242)));
  V v_t_244 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 8);
  V v_t_245 = ({ V a_0 = v_t_244; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_t_244); r_; });
  HeffT2 v_t_246 = ({ V a_0 = v_t_245; V a_1 = v_x_242; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_x_242); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_d_243);
      V v_x_2410 = v_field_248;
      return v_x_2410;
    } else {
      heff_drop(v_field_248);
      return v_d_243;
    }
  }
}
V g_heff_2eelab_2erules_2eeqElStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eeqElStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeqElStr_entry, 3, 0};

V g_heff_2eelab_2erules_2eeqElStr(V v_g_240, V v_cs_241, V v_v_242) {
top: ;
  V v_e_243 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(heff_take_field(v_cs_241, 0), v_v_242));
  V v_t_2412 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2eeqElStr_lam0, 1, 1, (V[]){v_g_240})));
  V v_e_2413 = heff_tr(heff_call(heff_get_n(v_t_2412, 0, 2), 1, (V[]){v_e_243}));
  return (g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(MK_INT(0LL), MK_INT(0LL), heff_get_n(v_cs_241, 1, 2), v_e_2413));
}
V g_heff_2eelab_2erules_2eeqElStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eeqElStr(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eeqElStr_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_244)));
  V v_t_246 = ({ V b_0 = heff_get_n(v_g_240, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_247 = ({ V a_0 = v_t_246; V a_1 = v_x_244; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_x_244); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_d_245);
      V v_x_2411 = v_field_249;
      return v_x_2411;
    } else {
      heff_drop(v_field_249);
      return v_d_245;
    }
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str0, 5, " and ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str1, 15, " are not equal ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str2, 6, "types ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str3, 5, " and ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str4, 15, " are not equal ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str5, 9, "elements ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str6, 5, " and ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str7, 15, " are not equal ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str8, 9, "neutrals ");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str9, 47, "a solution would mention what did not elaborate");
HEFF_LIT(g_heff_2eelab_2erules_2eprettyEqErr_str10, 61, "a solution would mention a variable outside where it is bound");
Clo g_heff_2eelab_2erules_2eprettyEqErr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprettyEqErr_entry, 2, 0};

V g_heff_2eelab_2erules_2eprettyEqErr(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_UnequalTys: {
    V v_cs_242 = heff_field(v_x2_241, 0);
    V v_a_243 = heff_field(v_x2_241, 1);
    V v_a2_244 = heff_field(v_x2_241, 2);
    V v_t_245 = (g_heff_2eelab_2erules_2eeqTyStr(heff_dup(v_g_240), heff_dup(v_cs_242), heff_dup(v_a_243)));
    V v_t_246 = (g_heff_2eelab_2erules_2eeqTyStr(v_g_240, heff_dup(v_cs_242), heff_dup(v_a2_244)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str0), heff_strAppend(v_t_246, ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str1)));
    return heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str2), heff_strAppend(v_t_245, v_t_247));
  }
  case TAG_UnequalEls: {
    V v_cs_248 = heff_field(v_x2_241, 0);
    V v_a_249 = heff_field(v_x2_241, 1);
    V v_a2_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = (g_heff_2eelab_2erules_2eeqElStr(heff_dup(v_g_240), heff_dup(v_cs_248), heff_dup(v_a_249)));
    V v_t_2412 = (g_heff_2eelab_2erules_2eeqElStr(v_g_240, heff_dup(v_cs_248), heff_dup(v_a2_2410)));
    V v_t_2413 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str3), heff_strAppend(v_t_2412, ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str4)));
    return heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str5), heff_strAppend(v_t_2411, v_t_2413));
  }
  case TAG_UnequalNeus: {
    V v_cs_2414 = heff_field(v_x2_241, 0);
    V v_h_2415 = heff_field(v_x2_241, 1);
    V v_sp_2416 = heff_field(v_x2_241, 2);
    V v_h2_2417 = heff_field(v_x2_241, 3);
    V v_sp2_2418 = heff_field(v_x2_241, 4);
    V v_t_2419 = (g_heff_2eelab_2erules_2eeqBareStr(heff_dup(v_g_240), heff_dup(v_cs_2414), heff_dup(v_h_2415), heff_dup(v_sp_2416)));
    V v_t_2420 = (g_heff_2eelab_2erules_2eeqBareStr(v_g_240, heff_dup(v_cs_2414), heff_dup(v_h2_2417), heff_dup(v_sp2_2418)));
    V v_t_2421 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str6), heff_strAppend(v_t_2420, ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str7)));
    return heff_strAppend(((V)&g_heff_2eelab_2erules_2eprettyEqErr_str8), heff_strAppend(v_t_2419, v_t_2421));
  }
  case TAG_MentionsError: {
    heff_drop(v_g_240);
    return ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str9);
  }
  case TAG_Escapes: {
    heff_drop(v_g_240);
    return ((V)&g_heff_2eelab_2erules_2eprettyEqErr_str10);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2eprettyEqErr(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2erules_2espineHasLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2espineHasLocal_entry, 2, 0};

V g_heff_2eelab_2erules_2espineHasLocal(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SpId: {
    heff_drop(v_l_240);
    return NTAG(TAG_False);
  }
  case TAG_SpApp: {
    V v_sp_242 = heff_field(v_x2_241, 0);
    V v_v_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_v_243)) {
    case TAG_VNeu: {
      V v_v1_244 = heff_field(v_v_243, 0);
      V v_v2_245 = heff_field(v_v_243, 1);
      switch (heff_tag_of(v_v1_244)) {
      case TAG_HLocal: {
        V v_l2_249 = heff_field(v_v1_244, 0);
        switch (heff_tag_of(v_v2_245)) {
        case TAG_SpId: {
          if (heff_intEq_c_lent(v_l2_249, v_l_240, 0)) {
            heff_drop(v_l_240);
            return NTAG(TAG_True);
          } else {
            V t_0 = v_l_240;
            V t_1 = v_sp_242;
            v_l_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        }
        case TAG_SpApp: {
          V t_0 = v_l_240;
          V t_1 = v_sp_242;
          v_l_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_SpProj: {
          V t_0 = v_l_240;
          V t_1 = v_sp_242;
          v_l_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        case TAG_SpSpec: {
          V t_0 = v_l_240;
          V t_1 = v_sp_242;
          v_l_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_v2_245);
        }
      }
      case TAG_HGlobal: {
        V t_0 = v_l_240;
        V t_1 = v_sp_242;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_HMeta: {
        V t_0 = v_l_240;
        V t_1 = v_sp_242;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_HError: {
        V t_0 = v_l_240;
        V t_1 = v_sp_242;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_v1_244);
      }
    }
    case TAG_VCode: {
      V t_0 = v_l_240;
      V t_1 = v_sp_242;
      v_l_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_VLam: {
      V t_0 = v_l_240;
      V t_1 = v_sp_242;
      v_l_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_VCons: {
      V t_0 = v_l_240;
      V t_1 = v_sp_242;
      v_l_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_VOpaque: {
      V t_0 = v_l_240;
      V t_1 = v_sp_242;
      v_l_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_v_243);
    }
  }
  case TAG_SpProj: {
    V v_sp_2424 = heff_field(v_x2_241, 0);
    V t_0 = v_l_240;
    V t_1 = v_sp_2424;
    v_l_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_SpSpec: {
    V v_sp_2426 = heff_field(v_x2_241, 0);
    V t_0 = v_l_240;
    V t_1 = v_sp_2426;
    v_l_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2espineHasLocal_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2espineHasLocal(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eannot_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eannot_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eannot_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eannot_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eannot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eannot_entry, 2, 0};

V g_heff_2eelab_2erules_2eannot(V v_typ_240, V v_chk_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2eannot_lam0, 1, 2, (V[]){heff_dup(v_typ_240), heff_dup(v_chk_241)})});
}
V g_heff_2eelab_2erules_2eannot_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erules_2eannot(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2eannot_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2417 = heff_tr(heff_call(heff_get_n(v_x_248, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2421;
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nom: {
    V v_x_2418 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2418;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    v_t_2421 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2420 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x1_2417);
  }
  V v_x_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2416, v_t_2421});
  V f_ = v_k_247;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eannot_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_chk_241 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_248, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_2413;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nom: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_a_2413 = v_x_2410;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_a_2413 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2412 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 1);
    v_a_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  V v_c_2415;
  switch (heff_tag_of(v_chk_241)) {
  case TAG_MkChk: {
    V v_f_2414 = heff_field(v_chk_241, 0);
    heff_take_n(v_chk_241, 1ULL, 1);
    v_c_2415 = heff_tr(heff_call(v_f_2414, 2, (V[]){v_e_242, v_a_2413}));
    break;
  }
  default: heff_nomatch(v_chk_241);
  }
  V f_ = v_c_2415;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eannot_lam3, 1, 2, (V[]){v_x_248, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eannot_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_chk_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eannot_lam2, 1, 4, (V[]){v_chk_241, v_e_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eannot_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_typ_240 = heff_env(self)[0];
  V v_chk_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_typ_240)) {
  case TAG_MkTyp: {
    V v_f_243 = heff_field(v_typ_240, 0);
    heff_take_n(v_typ_240, 1ULL, 1);
    V v_t_244 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(heff_rfield(v_e_242, 0)), heff_dup(heff_rfield(v_e_242, 1)), NTAG(TAG_ForNominative), heff_dup(heff_rfield(v_e_242, 3)), heff_dup(heff_rfield(v_e_242, 4)), heff_dup(heff_rfield(v_e_242, 5))});
    v_c_245 = heff_tr(heff_call(v_f_243, 1, (V[]){v_t_244}));
    break;
  }
  default: heff_nomatch(v_typ_240);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2eannot_lam1, 2, 3, (V[]){v_c_245, v_chk_241, v_e_242});
}
HEFF_LIT(g_heff_2eelab_2erules_2enumLitChk_24cpr_str0, 7, "literal");
V g_heff_2eelab_2erules_2enumLitChk_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitChk_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitChk_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2enumLitChk_24cpr(V v_sp_240, V v_lit_241) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_24cpr_lam0, 4, 2, (V[]){v_sp_240, v_lit_241})}});
}
V g_heff_2eelab_2erules_2enumLitChk_24cpr_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enumLitChk_24cpr_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_VU: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2412 = heff_dup(heff_field(v_x_2410, 0));
    switch (heff_tag_of(v_t1_2412)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2412, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2412, 0ULL, 1);
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2412, 0ULL, 1);
      v_t_2432 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_t_2432 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t1_2412);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2432 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
    heff_drop(v_t_2432);
    V v_c_2433 = (g_heff_2eelab_2erules_2enumLitWait(MK_INT(1LL), heff_dup(v_sp_240), v_lit_241));
    return ({ V a_0 = v_e_242; V a_1 = v_sp_240; V a_2 = ((V)&g_heff_2eelab_2erules_2enumLitChk_24cpr_str0); V a_3 = v_c_2433; V a_4 = heff_dup(v_x_2410); V a_5 = v_x_2410; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eelab_2erules_2edelayChkOn(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2433); r_; });
  } else {
    heff_drop(v_t_2432);
    return (g_heff_2eelab_2erules_2enumLitAt(v_sp_240, v_e_242, v_x_2410, v_lit_241, v_hd_244, v_k_245));
  }
}
V g_heff_2eelab_2erules_2enumLitChk_24cpr_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_24cpr_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_24cpr_lam2, 1, 5, (V[]){v_sp_240, v_lit_241, v_e_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eselfAdvance_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eselfAdvance_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eselfAdvance_lam0, 1, 0};
V g_heff_2eelab_2erules_2eselfAdvance_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eselfAdvance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eselfAdvance_entry, 5, 0};

V g_heff_2eelab_2erules_2eselfAdvance(V v_e_240, V v_a_241, V v_done_242, V v_p_243, V v_p_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_e_240, 2));
  switch (heff_tag_of(v_t_245)) {
  case TAG_ForNominative: {
    heff_drop(v_a_241);
    heff_drop(v_done_242);
    heff_drop_rec(v_p_243, 3);
    return heff_tail(v_p_244, 1, (V[]){v_e_240});
  }
  case TAG_ForDescriptive: {
    V v_elabFor1_246 = heff_field(v_t_245, 0);
    V v_elabFor2_247 = heff_field(v_t_245, 1);
    heff_take_n(v_t_245, 3ULL, 2);
    switch (heff_tag_of(v_elabFor1_246)) {
    case TAG_HLocal: {
      heff_take_n(v_elabFor1_246, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_done_242);
      heff_drop_rec(v_p_243, 3);
      heff_drop(v_elabFor2_247);
      return heff_tail(v_p_244, 1, (V[]){v_e_240});
    }
    case TAG_HGlobal: {
      V v_gk_249 = heff_field(v_elabFor1_246, 0);
      V v_ru_24elabFor1_246_24HGlobal = heff_take_reuse_n(v_elabFor1_246, 1ULL, 1);
      switch (heff_tag_of(v_elabFor2_247)) {
      case TAG_SpId: {
        V v_t_2411 = heff_tag_at_n(v_ru_24elabFor1_246_24HGlobal, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eselfAdvance_lam0_clo)})});
        V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
        V v_t_2413 = heff_tr(heff_call(heff_take_field(v_p_243, 2), 1, (V[]){v_t_2412}));
        return heff_tail(heff_get_n(v_p_243, 1, 3), 2, (V[]){v_t_2413, heff_clo_n(g_heff_2eelab_2erules_2eselfAdvance_lam1, 1, 5, (V[]){v_a_241, v_p_244, v_e_240, v_gk_249, v_done_242})});
      }
      case TAG_SpApp: {
        heff_take_n(v_elabFor2_247, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop(v_done_242);
        heff_drop_rec(v_p_243, 3);
        heff_drop(v_gk_249);
        heff_drop_cell(v_ru_24elabFor1_246_24HGlobal, 1);
        return heff_tail(v_p_244, 1, (V[]){v_e_240});
      }
      case TAG_SpProj: {
        heff_take_n(v_elabFor2_247, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop(v_done_242);
        heff_drop_rec(v_p_243, 3);
        heff_drop(v_gk_249);
        heff_drop_cell(v_ru_24elabFor1_246_24HGlobal, 1);
        return heff_tail(v_p_244, 1, (V[]){v_e_240});
      }
      case TAG_SpSpec: {
        heff_take_n(v_elabFor2_247, 0ULL, 3);
        heff_drop(v_a_241);
        heff_drop(v_done_242);
        heff_drop_rec(v_p_243, 3);
        heff_drop(v_gk_249);
        heff_drop_cell(v_ru_24elabFor1_246_24HGlobal, 1);
        return heff_tail(v_p_244, 1, (V[]){v_e_240});
      }
      default: return heff_nomatch(v_elabFor2_247);
      }
    }
    case TAG_HMeta: {
      heff_take_n(v_elabFor1_246, 0ULL, 1);
      heff_drop(v_a_241);
      heff_drop(v_done_242);
      heff_drop_rec(v_p_243, 3);
      heff_drop(v_elabFor2_247);
      return heff_tail(v_p_244, 1, (V[]){v_e_240});
    }
    case TAG_HError: {
      heff_drop(v_a_241);
      heff_drop(v_done_242);
      heff_drop_rec(v_p_243, 3);
      heff_drop(v_elabFor2_247);
      return heff_tail(v_p_244, 1, (V[]){v_e_240});
    }
    default: return heff_nomatch(v_elabFor1_246);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eelab_2erules_2eselfAdvance_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eselfAdvance(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2eselfAdvance_lam0(V self, V *args) {
  V v_c_2410 = args[0];
  return heff_get_n(v_c_2410, 7, 8);
}
V g_heff_2eelab_2erules_2eselfAdvance_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_a_241 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_gk_249 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_241)));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_LikeU: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2415, 0ULL, 4);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeRecord: {
    V v_fieldTypes_2423 = heff_field(v_t_2415, 2);
    heff_take_n(v_t_2415, 4ULL, 3);
    switch (heff_tag_of(v_x_2414)) {
    case TAG_Nothing: {
      heff_drop(v_a_241);
      heff_drop(v_gk_249);
      heff_drop(v_done_242);
      heff_drop(v_fieldTypes_2423);
      V f_ = v_p_244;
      args[0] = v_e_240;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Just: {
      V v_y_2424 = heff_field(v_x_2414, 0);
      heff_take_n(v_x_2414, 1ULL, 1);
      if (heff_strEq_c_lent(v_y_2424, v_gk_249, 1)) {
        V v_sc_2426 = heff_take_field(v_e_240, 0);
        V v_v_2427 = (g_heff_2eelab_2erules_2eadvanceSelf(v_gk_249, v_a_241, v_fieldTypes_2423, v_done_242));
        V v_t_2428 = (g_heff_2eelab_2erules_2erebottom(v_v_2427, heff_take_field(v_sc_2426, 2)));
        V v_sc_2429 = ({ V rv_2 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_sc_2426, 11ULL, 4, shape_len__names__locals__ctx, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2430 = ({ V rv_0 = v_sc_2429; V rr_ = heff_rec_reuse_nf(v_e_240, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V f_ = v_p_244;
        args[0] = v_t_2430;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_a_241);
        heff_drop(v_gk_249);
        heff_drop(v_done_242);
        heff_drop(v_fieldTypes_2423);
        V f_ = v_p_244;
        args[0] = v_e_240;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_x_2414);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeString: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2415, 0ULL, 1);
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_NoRules: {
    heff_drop(v_x_2414);
    heff_drop(v_a_241);
    heff_drop(v_gk_249);
    heff_drop(v_done_242);
    V f_ = v_p_244;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2415);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str1, 2, ", ");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str3, 2, " (");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str4, 17, " may be left out)");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str5, 15, ", in this order");
HEFF_LIT(g_heff_2eelab_2erules_2efieldsNote_str6, 15, "the fields are ");
Clo g_heff_2eelab_2erules_2efieldsNote_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efieldsNote_entry, 1, 0};

V g_heff_2eelab_2erules_2efieldsNote(V v_it_240) {
top: ;
  V v_t_241 = heff_take_field(v_it_240, 2);
  V v_t_244;
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nil: {
    v_t_244 = ((V)&g_heff_2eelab_2erules_2efieldsNote_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_t_241, 0);
    V v_xs_243 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    v_t_244 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2efieldsNote_str1); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_it_240, 3)), 2, 3);
  V v_t_249;
  if ((heff_unbox_word(heff_arrayLength(v_t_245)) == ((int64_t)0ULL))) {
    heff_drop_rec(v_it_240, 5);
    v_t_249 = ((V)&g_heff_2eelab_2erules_2efieldsNote_str2);
  } else {
    V v_t_247 = heff_get_n(heff_get_n(v_it_240, 3, 5), 0, 3);
    V v_t_248 = ({ V b_0 = heff_arrayToList(v_t_247); V r_ = (g_heff_2eelab_2erules_2eandList(b_0)); heff_drop(b_0); r_; });
    v_t_249 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efieldsNote_str3), heff_strAppend(v_t_248, ((V)&g_heff_2eelab_2erules_2efieldsNote_str4)));
  }
  V v_t_2410 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2eelab_2erules_2efieldsNote_str5), v_t_249));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2efieldsNote_str6), v_t_2410);
}
V g_heff_2eelab_2erules_2efieldsNote_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efieldsNote(a[0]);
}
Clo g_heff_2eelab_2erules_2efieldIdxs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efieldIdxs_entry, 2, 0};

V g_heff_2eelab_2erules_2efieldIdxs(V v_at_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_at_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Nothing: {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){MK_INT(0LL), heff_hole()});
      V v_u_245 = (g_heff_2eelab_2erules_2efieldIdxs_24dps(v_at_240, v_rest_243, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    case TAG_Just: {
      V v_p_246 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_247 = heff_intSub(heff_intSub(heff_dup(v_at_240), MK_INT(1LL)), v_p_246);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_heff_2eelab_2erules_2efieldIdxs_24dps(v_at_240, v_rest_243, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2efieldIdxs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efieldIdxs(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2evaluesGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2evaluesGo_24dps_entry, 6, 0};

V g_heff_2eelab_2erules_2evaluesGo_24dps(V v_n_240, V v_places_241, V v_x3_242, V v_x4_243, V v_i_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_places_241);
    heff_drop(v_x4_243);
    heff_drop(v_i_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_m_246 = heff_field(v_x3_242, 0);
    V v_rest_247 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_n_240);
      heff_drop(v_places_241);
      heff_drop(v_i_244);
      heff_drop(v_m_246);
      heff_drop(v_rest_247);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_x41_248 = heff_field(v_x4_243, 0);
      V v_pls_249 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_248)) {
      case TAG_Nothing: {
        heff_drop(v_m_246);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_n_240;
        V t_1 = v_places_241;
        V t_2 = v_rest_247;
        V t_3 = v_pls_249;
        V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
        V t_5 = v_d_245;
        v_n_240 = t_0;
        v_places_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        v_i_244 = t_4;
        v_d_245 = t_5;
        goto top;
      }
      case TAG_Just: {
        V v_p_2410 = heff_field(v_x41_248, 0);
        heff_take_n(v_x41_248, 1ULL, 1);
        V v_t_2411 = heff_tr(g_heff_2eelab_2erules_2ecodeAt(heff_dup(v_n_240), v_p_2410, heff_dup(v_places_241), heff_dup(v_m_246), heff_dup(v_i_244)));
        V v_cell_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_246, v_t_2411}), heff_hole()});
        V v_u_2413 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2412));
        heff_drop(v_u_2413);
        V t_0 = v_n_240;
        V t_1 = v_places_241;
        V t_2 = v_rest_247;
        V t_3 = v_pls_249;
        V t_4 = heff_intAdd(v_i_244, MK_INT(1LL));
        V t_5 = v_cell_2412;
        v_n_240 = t_0;
        v_places_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        v_i_244 = t_4;
        v_d_245 = t_5;
        goto top;
      }
      default: return heff_nomatch(v_x41_248);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2evaluesGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2evaluesGo_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2etagArgsGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagArgsGo_lam0, 2, 0};
V g_heff_2eelab_2erules_2etagArgsGo_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2etagArgsGo_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagArgsGo_lam1, 2, 0};
V g_heff_2eelab_2erules_2etagArgsGo_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2etagArgsGo_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagArgsGo_lam2, 2, 0};
V g_heff_2eelab_2erules_2etagArgsGo_lam5(V self, V *args);
V g_heff_2eelab_2erules_2etagArgsGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2etagArgsGo_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2etagArgsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etagArgsGo_entry, 3, 0};

V g_heff_2eelab_2erules_2etagArgsGo(V v_e_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      return ((V)&g_heff_2eelab_2erules_2etagArgsGo_lam0_clo);
    }
    case TAG_Cons: {
      heff_take_n(v_x3_242, 0ULL, 2);
      return ((V)&g_heff_2eelab_2erules_2etagArgsGo_lam1_clo);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_Cons: {
    V v_c_249 = heff_field(v_x2_241, 0);
    V v_cs_2410 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_e_240);
      heff_drop(v_c_249);
      heff_drop(v_cs_2410);
      return ((V)&g_heff_2eelab_2erules_2etagArgsGo_lam2_clo);
    }
    case TAG_Cons: {
      V v_t_2413 = heff_field(v_x3_242, 0);
      V v_ts_2414 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_a_2415 = heff_tr(heff_call(v_t_2413, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_c_2417;
      switch (heff_tag_of(v_c_249)) {
      case TAG_MkChk: {
        V v_f_2416 = heff_field(v_c_249, 0);
        heff_take_n(v_c_249, 1ULL, 1);
        v_c_2417 = heff_tr(heff_call(v_f_2416, 2, (V[]){heff_dup(v_e_240), v_a_2415}));
        break;
      }
      default: heff_nomatch(v_c_249);
      }
      return heff_clo_n(g_heff_2eelab_2erules_2etagArgsGo_lam3, 2, 4, (V[]){v_c_2417, v_e_240, v_cs_2410, v_ts_2414});
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2etagArgsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etagArgsGo(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2420, v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etagArgsGo_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_cs_2410 = heff_env(self)[1];
  V v_ts_2414 = heff_env(self)[2];
  V v_hd_2418 = heff_env(self)[3];
  V v_k_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2421 = (g_heff_2eelab_2erules_2etagArgsGo(v_e_240, v_cs_2410, v_ts_2414));
  V f_ = v_c_2421;
  heff_room[0] = v_hd_2418;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2etagArgsGo_lam5, 1, 2, (V[]){v_k_2419, v_x_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2etagArgsGo_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_cs_2410 = heff_env(self)[2];
  V v_ts_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2etagArgsGo_lam4, 1, 5, (V[]){v_e_240, v_cs_2410, v_ts_2414, v_hd_2418, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str0, 34, "the record updated is out of scope");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str1, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str2, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str3, 18, "the type of field ");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str4, 77, " depends on the fields before it, and what the record's are is not known here");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str5, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str6, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str7, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str8, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str9, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str10, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str11, 53, "tried to update a value that was not of a record type");
HEFF_LIT(g_heff_2eelab_2erules_2eupdatedField_str12, 53, "tried to update a value that was not of a record type");
V g_heff_2eelab_2erules_2eupdatedField_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam10(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam11(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam12(V self, V *args);
V g_heff_2eelab_2erules_2eupdatedField_lam13(V self, V *args);
Clo g_heff_2eelab_2erules_2eupdatedField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eupdatedField_entry, 6, 0};

V g_heff_2eelab_2erules_2eupdatedField(V v_sp_240, V v_e_241, V v_r_242, V v_g_243, V v_a_244, V v_x_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 1, 4);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 3, 4);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 2, 4);
  HeffT2 v_t_249 = ({ V a_0 = v_r_242; V a_1 = v_t_246; V a_2 = v_t_247; V a_3 = v_t_248; V a_4 = MK_INT(0LL); V a_5 = MK_INT(0LL); HeffT2 r_ = (g_heff_2eelab_2erules_2evarGo_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_247); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      heff_drop_rec(v_e_241, 6);
      heff_drop_rec(v_g_243, 2);
      heff_drop(v_a_244);
      heff_drop(v_x_245);
      V v_it1_2413 = v_field_2411;
      heff_drop(v_it1_2413);
      return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam0, 2, 1, (V[]){v_sp_240});
    } else {
      V v_it1_2420 = v_field_2411;
      switch (heff_tag_of(v_it1_2420)) {
      case TAG_MkPair: {
        V v_v_2421 = heff_field(v_it1_2420, 0);
        heff_take_n(v_it1_2420, 1ULL, 2);
        V v_bound_2423 = ({ V rv_1 = heff_dup(heff_rfield(v_g_243, 1)); V rr_ = heff_rec_reuse_nf(v_v_2421, 1ULL, 2, shape_stx__val, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2424 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_244)));
        switch (heff_tag_of(v_t_2424)) {
        case TAG_LikeU: {
          heff_take_n(v_t_2424, 0ULL, 1);
          heff_drop_rec(v_e_241, 6);
          heff_drop_rec(v_g_243, 2);
          heff_drop(v_a_244);
          heff_drop(v_x_245);
          heff_drop_rec(v_bound_2423, 2);
          return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam1, 2, 1, (V[]){v_sp_240});
        }
        case TAG_LikeFunction: {
          heff_take_n(v_t_2424, 0ULL, 4);
          heff_drop_rec(v_e_241, 6);
          heff_drop_rec(v_g_243, 2);
          heff_drop(v_a_244);
          heff_drop(v_x_245);
          heff_drop_rec(v_bound_2423, 2);
          return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam2, 2, 1, (V[]){v_sp_240});
        }
        case TAG_LikeRecord: {
          V v_capture_2443 = heff_field(v_t_2424, 1);
          V v_fieldTypes_2444 = heff_field(v_t_2424, 2);
          heff_take_n(v_t_2424, 6ULL, 3);
          V v_x1_2445 = heff_tr(heff_call(heff_get_n(v_g_243, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
          V v_v_2449;
          switch (heff_tag_of(v_x1_2445)) {
          case TAG_Nom: {
            V v_x_2446 = heff_field(v_x1_2445, 0);
            heff_take_n(v_x1_2445, 1ULL, 1);
            v_v_2449 = v_x_2446;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_2445, 0ULL, 1);
            v_v_2449 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_2448 = heff_field(v_x1_2445, 0);
            heff_take_n(v_x1_2445, 1ULL, 1);
            v_v_2449 = v_x_2448;
            break;
          }
          default: heff_nomatch(v_x1_2445);
          }
          V v_t_2450 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_2449));
          HeffT2 v_t_2451 = ({ V a_0 = v_a_244; V a_1 = v_t_2450; V a_2 = v_x_245; HeffT2 r_ = (g_heff_2eelab_2evalue_2eprojTyWith_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2450); r_; });
          {
            V v_field_2453 = v_t_2451.f[1];
            int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
            if ((v_tag_2452 == ((int64_t)0ULL))) {
              heff_drop(v_sp_240);
              heff_drop_rec(v_e_241, 6);
              heff_drop(v_capture_2443);
              heff_drop_rec(v_fieldTypes_2444, 3);
              V v_t_2455 = v_field_2453;
              return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam3, 2, 3, (V[]){v_bound_2423, v_x_245, v_t_2455});
            } else {
              heff_drop(v_field_2453);
              V v_t_2459 = heff_get_n(heff_get_n(v_e_241, 0, 6), 0, 4);
              HeffT2 v_t_2460 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_fieldTypes_2444, 1), v_x_245));
              V v_t_2465;
              {
                V v_field_2462 = v_t_2460.f[1];
                int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
                if ((v_tag_2461 == ((int64_t)0ULL))) {
                  V v_i_2464 = v_field_2462;
                  v_t_2465 = v_i_2464;
                } else {
                  heff_drop(v_field_2462);
                  v_t_2465 = heff_abandon();
                }
              }
              HeffT2 v_t_2466 = (g_heff_2eelab_2erules_2efieldTyAt_24cpr(v_t_2459, v_capture_2443, v_fieldTypes_2444, v_t_2465, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
              {
                V v_field_2468 = v_t_2466.f[1];
                int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
                if ((v_tag_2467 == ((int64_t)0ULL))) {
                  heff_drop(v_sp_240);
                  V v_t_2470 = v_field_2468;
                  return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam4, 2, 3, (V[]){v_bound_2423, v_x_245, v_t_2470});
                } else {
                  heff_drop_rec(v_bound_2423, 2);
                  heff_drop(v_field_2468);
                  return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam5, 2, 2, (V[]){v_x_245, v_sp_240});
                }
              }
            }
          }
        }
        case TAG_LikeSum: {
          heff_take_n(v_t_2424, 0ULL, 1);
          heff_drop_rec(v_e_241, 6);
          heff_drop_rec(v_g_243, 2);
          heff_drop(v_a_244);
          heff_drop(v_x_245);
          heff_drop_rec(v_bound_2423, 2);
          return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam6, 2, 1, (V[]){v_sp_240});
        }
        case TAG_LikeInt: {
          heff_drop_rec(v_e_241, 6);
          heff_drop_rec(v_g_243, 2);
          heff_drop(v_a_244);
          heff_drop(v_x_245);
          heff_drop_rec(v_bound_2423, 2);
          return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam7, 2, 1, (V[]){v_sp_240});
        }
        case TAG_LikeFloat: {
          heff_drop_rec(v_e_241, 6);
          heff_drop_rec(v_g_243, 2);
          heff_drop(v_a_244);
          heff_drop(v_x_245);
          heff_drop_rec(v_bound_2423, 2);
          return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam8, 2, 1, (V[]){v_sp_240});
        }
        case TAG_LikeString: {
          heff_drop_rec(v_e_241, 6);
          heff_drop_rec(v_g_243, 2);
          heff_drop(v_a_244);
          heff_drop(v_x_245);
          heff_drop_rec(v_bound_2423, 2);
          return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam9, 2, 1, (V[]){v_sp_240});
        }
        case TAG_LikeRune: {
          heff_drop_rec(v_e_241, 6);
          heff_drop_rec(v_g_243, 2);
          heff_drop(v_a_244);
          heff_drop(v_x_245);
          heff_drop_rec(v_bound_2423, 2);
          return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam10, 2, 1, (V[]){v_sp_240});
        }
        case TAG_LikeArray: {
          heff_take_n(v_t_2424, 0ULL, 1);
          heff_drop_rec(v_e_241, 6);
          heff_drop_rec(v_g_243, 2);
          heff_drop(v_a_244);
          heff_drop(v_x_245);
          heff_drop_rec(v_bound_2423, 2);
          return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam11, 2, 1, (V[]){v_sp_240});
        }
        case TAG_LikeFixed: {
          heff_take_n(v_t_2424, 0ULL, 1);
          heff_drop_rec(v_e_241, 6);
          heff_drop_rec(v_g_243, 2);
          heff_drop(v_a_244);
          heff_drop(v_x_245);
          heff_drop_rec(v_bound_2423, 2);
          return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam12, 2, 1, (V[]){v_sp_240});
        }
        case TAG_NoRules: {
          heff_drop_rec(v_e_241, 6);
          heff_drop_rec(v_g_243, 2);
          heff_drop(v_a_244);
          heff_drop(v_x_245);
          heff_drop_rec(v_bound_2423, 2);
          return heff_clo_n(g_heff_2eelab_2erules_2eupdatedField_lam13, 2, 1, (V[]){v_sp_240});
        }
        default: return heff_nomatch(v_t_2424);
        }
      }
      default: return heff_nomatch(v_it1_2420);
      }
    }
  }
}
V g_heff_2eelab_2erules_2eupdatedField_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2eupdatedField(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2eupdatedField_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k2_2415 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(303LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(heff_take_field(v_hd_2414, 2), 1, (V[]){v_t_2418}));
  V f_ = heff_get_n(v_hd_2414, 1, 3);
  args[0] = v_t_2419;
  args[1] = v_k2_2415;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam1(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k2_2427 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str1), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tr(heff_call(heff_take_field(v_hd_2426, 2), 1, (V[]){v_t_2430}));
  V f_ = heff_get_n(v_hd_2426, 1, 3);
  args[0] = v_t_2431;
  args[1] = v_k2_2427;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam2(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k2_2437 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str2), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tr(heff_call(heff_take_field(v_hd_2436, 2), 1, (V[]){v_t_2440}));
  V f_ = heff_get_n(v_hd_2436, 1, 3);
  args[0] = v_t_2441;
  args[1] = v_k2_2437;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam3(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_bound_2423 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_t_2455 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2456);
  V v_t_2458 = (g_heff_2eelab_2ememoed_2eproj(v_bound_2423, v_x_245));
  V f_ = v_k_2457;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2458, v_t_2455});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam4(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  V v_bound_2423 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_t_2470 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2471);
  V v_t_2473 = (g_heff_2eelab_2ememoed_2eprojAt(v_bound_2423, v_x_245, heff_dup(v_t_2470)));
  V f_ = v_k_2472;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2473, v_t_2470});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam5(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k2_2475 = args[1];
  V v_x_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2476 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eupdatedField_str3), heff_strAppend(v_x_245, ((V)&g_heff_2eelab_2erules_2eupdatedField_str4)));
  V v_t_2477 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(332LL), NTAG(TAG_SError), v_t_2476, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tr(heff_call(heff_take_field(v_hd_2474, 2), 1, (V[]){v_t_2479}));
  V f_ = heff_get_n(v_hd_2474, 1, 3);
  args[0] = v_t_2480;
  args[1] = v_k2_2475;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam6(V self, V *args) {
  V v_hd_2482 = args[0];
  V v_k2_2483 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2484 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str5), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2485 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tr(heff_call(heff_take_field(v_hd_2482, 2), 1, (V[]){v_t_2486}));
  V f_ = heff_get_n(v_hd_2482, 1, 3);
  args[0] = v_t_2487;
  args[1] = v_k2_2483;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam7(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k2_2489 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2490 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str6), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2491 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tr(heff_call(heff_take_field(v_hd_2488, 2), 1, (V[]){v_t_2492}));
  V f_ = heff_get_n(v_hd_2488, 1, 3);
  args[0] = v_t_2493;
  args[1] = v_k2_2489;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam8(V self, V *args) {
  V v_hd_2494 = args[0];
  V v_k2_2495 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2496 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str7), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tr(heff_call(heff_take_field(v_hd_2494, 2), 1, (V[]){v_t_2498}));
  V f_ = heff_get_n(v_hd_2494, 1, 3);
  args[0] = v_t_2499;
  args[1] = v_k2_2495;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam9(V self, V *args) {
  V v_hd_24100 = args[0];
  V v_k2_24101 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24102 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str8), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24102})});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tr(heff_call(heff_take_field(v_hd_24100, 2), 1, (V[]){v_t_24104}));
  V f_ = heff_get_n(v_hd_24100, 1, 3);
  args[0] = v_t_24105;
  args[1] = v_k2_24101;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam10(V self, V *args) {
  V v_hd_24106 = args[0];
  V v_k2_24107 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24108 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str9), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24109 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tr(heff_call(heff_take_field(v_hd_24106, 2), 1, (V[]){v_t_24110}));
  V f_ = heff_get_n(v_hd_24106, 1, 3);
  args[0] = v_t_24111;
  args[1] = v_k2_24107;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam11(V self, V *args) {
  V v_hd_24113 = args[0];
  V v_k2_24114 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24115 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str10), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24116 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24115})});
  V v_t_24117 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
  V v_t_24118 = heff_tr(heff_call(heff_take_field(v_hd_24113, 2), 1, (V[]){v_t_24117}));
  V f_ = heff_get_n(v_hd_24113, 1, 3);
  args[0] = v_t_24118;
  args[1] = v_k2_24114;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam12(V self, V *args) {
  V v_hd_24120 = args[0];
  V v_k2_24121 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24122 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str11), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24123 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24122})});
  V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
  V v_t_24125 = heff_tr(heff_call(heff_take_field(v_hd_24120, 2), 1, (V[]){v_t_24124}));
  V f_ = heff_get_n(v_hd_24120, 1, 3);
  args[0] = v_t_24125;
  args[1] = v_k2_24121;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eupdatedField_lam13(V self, V *args) {
  V v_hd_24126 = args[0];
  V v_k2_24127 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24128 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(306LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eupdatedField_str12), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_24129 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24128})});
  V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
  V v_t_24131 = heff_tr(heff_call(heff_take_field(v_hd_24126, 2), 1, (V[]){v_t_24130}));
  V f_ = heff_get_n(v_hd_24126, 1, 3);
  args[0] = v_t_24131;
  args[1] = v_k2_24127;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2efindPrim_str0, 17, "no such variable ");
HEFF_LIT(g_heff_2eelab_2erules_2efindPrim_str1, 9, " in scope");
V g_heff_2eelab_2erules_2efindPrim_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efindPrim_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2efindPrim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efindPrim_entry, 2, 0};

V g_heff_2eelab_2erules_2efindPrim(V v_sp_240, V v_p_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam0, 1, 2, (V[]){v_p_241, v_sp_240})});
}
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2efindPrim(a[0], a[1]);
}
V g_heff_2eelab_2erules_2efindPrim_lam2(V self, V *args) {
  V v_mc_2411 = args[0];
  V v_e_242 = heff_env(self)[0];
  V v_e_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_e_242; V a_1 = v_mc_2411; V a_2 = heff_get_n(v_e_248, 3, 4); V r_ = (g_heff_2eelab_2erules_2etyStrIn(a_0, a_1, a_2)); heff_drop(v_mc_2411); r_; });
}
V g_heff_2eelab_2erules_2efindPrim_lam4(V self, V *args) {
  V v_u_2416 = args[0];
  V v_e_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2416);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_e_248, 2, 4)});
}
V g_heff_2eelab_2erules_2efindPrim_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_e_248 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2415);
  V v_t_2417 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){v_p_241}), heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam4, 1, 1, (V[]){heff_dup(v_e_248)})});
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, heff_get_n(v_e_248, 3, 4)});
  V f_ = v_k_2410;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efindPrim_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_e_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_rec_n(5, shape_span__name__key__member__ty, (V[]){v_sp_240, heff_dup(v_p_241), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_241)}), NTAG(TAG_False), heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam2, 1, 2, (V[]){v_e_242, heff_dup(v_e_248)})});
  V v_t_2413 = heff_tag_n(TAG_Record, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})}));
  V f_ = heff_get_n(v_hd_249, 1, 3);
  args[0] = v_t_2414;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam3, 1, 3, (V[]){v_p_241, v_e_248, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efindPrim_lam5(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k2_2420 = args[1];
  V v_p_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_strAppend(((V)&g_heff_2eelab_2erules_2efindPrim_str0), heff_strAppend(v_p_241, ((V)&g_heff_2eelab_2erules_2efindPrim_str1)));
  V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(308LL), NTAG(TAG_SError), v_t_2421, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_2419, 2), 1, (V[]){v_t_2424}));
  V f_ = heff_get_n(v_hd_2419, 1, 3);
  args[0] = v_t_2425;
  args[1] = v_k2_2420;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efindPrim_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_e_242, 1)), 1, 8);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_p_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_e_248 = v_field_246;
      return heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam1, 2, 4, (V[]){v_sp_240, v_p_241, v_e_242, v_e_248});
    } else {
      heff_drop_rec(v_e_242, 6);
      heff_drop(v_field_246);
      return heff_clo_n(g_heff_2eelab_2erules_2efindPrim_lam5, 2, 2, (V[]){v_p_241, v_sp_240});
    }
  }
}