// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Value 50841
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_build 295453320
#define LBL_command 1182252425
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failure 1292767177
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_heff 9694020
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_labels 836724522
#define LBL_lib 316671
#define LBL_mod 317820
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_property 1899481104
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_style 311138763
#define LBL_timeout 1065429926
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_ended__out__err[] = {LBL_ended, LBL_out, LBL_err};
static uint32_t shape_lib__mod__cwd__style__heff[] = {LBL_lib, LBL_mod, LBL_cwd, LBL_style, LBL_heff};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256_clo;
V g_heff_2ebuild_2ecommands_2ebuildText_get(void);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo;
V g_heff_2ebuild_2ecommands_2elastLines(V, V);
V g_heff_2ebuild_2ecommands_2elastLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elastLines_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864(V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson(V, V);
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eoutcomeOfJson_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeVariable_get(void);
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2eranOutcome(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eranOutcome_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranOutcome_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502(V, V, V);
V g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_clo;
V g_heff_2ebuild_2ecommands_2etestsSaid(V);
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo;
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eproject_2ecompatible(V, V);
V g_heff_2ebuild_2eproject_2ecompatible_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ecompatible_clo;
HeffT2 g_heff_2ebuild_2eproject_2epseudoParts_24cpr(V);
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(V);
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_clo;
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(V);
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_clo;
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(V);
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_clo;
V g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160(V);
V g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160_clo;
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(V);
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_clo;
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(V, V);
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_clo;
HeffT2 g_json_2esteps_24cpr(V, V);
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
V g_list_2eany_24s529567056x880977707(V, V, V);
V g_list_2eany_24s529567056x880977707_entry(V self, V *a);
extern Clo g_list_2eany_24s529567056x880977707_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f435360079x232115340(V, V, V);
V g_list_2efoldl_24f435360079x232115340_entry(V self, V *a);
extern Clo g_list_2efoldl_24f435360079x232115340_clo;
V g_list_2efoldl_24f496521120x176206934(V, V, V);
V g_list_2efoldl_24f496521120x176206934_entry(V self, V *a);
extern Clo g_list_2efoldl_24f496521120x176206934_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s201362679x620001272(V, V);
V g_list_2ekeepIf_24s201362679x620001272_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s201362679x620001272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2edirFor(V);
V g_std_2eprocess_2edirFor_entry(V self, V *a);
extern Clo g_std_2eprocess_2edirFor_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str0, 2, "0.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str1, 15, " (the same 0.x)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str3, 19, ", and this heff is ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str4, 13, " is for heff ");

HeffT2 g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(V v_who_240, V v_wanted_241, V v_running_242, V v_x4_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_who_240);
    heff_drop(v_wanted_241);
    heff_drop(v_running_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_w_245 = heff_field(v_x4_243, 0);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nothing: {
      heff_drop(v_who_240);
      heff_drop(v_wanted_241);
      heff_drop(v_running_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_r_246 = heff_field(v_x5_244, 0);
      V v_t_247 = (g_heff_2ebuild_2eproject_2ecompatible(v_w_245, v_r_246));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_who_240);
        heff_drop(v_wanted_241);
        heff_drop(v_running_242);
        heff_drop(v_t_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        heff_drop(v_t_247);
        V v_t_249;
        if (heff_strEq_c(heff_strSlice_lent(v_wanted_241, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str0))) {
          v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str1);
        } else {
          v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str2);
        }
        V v_t_2410 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str3), v_running_242));
        V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str4), heff_strAppend(v_wanted_241, v_t_2410));
        V v_f_2412 = heff_strAppend(v_who_240, v_t_2411);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x5_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_243, v_seen_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_seen_240;
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_seen_240});
      V t_1 = v_rest_244;
      V t_2 = v_cell_246;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enubStrGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str2, 8, " skipped");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str5, 8, ", tests ");
Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2etestsSaid(V v_os_240) {
top: ;
  switch (heff_tag_of(v_os_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str0);
  }
  case TAG_Cons: {
    V v_t_243 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_244 = (g_list_2efoldl_24f435360079x232115340(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_245 = (g_list_2efoldl_24f496521120x176206934(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_246 = heff_intSub(heff_intSub(v_t_243, v_t_244), v_t_245);
    V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_n_248 = (g_list_2efoldl_24f496521120x176206934(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_2411;
    if (heff_intEq_c_lent(v_n_248, MK_INT(0LL), 2)) {
      heff_drop(v_n_248);
      v_t_2411 = ((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str1);
    } else {
      V v_t_2410 = heff_strAppend(heff_intShow(v_n_248), ((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str2));
      v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str3), v_t_2410);
    }
    V v_t_2412 = heff_strAppend(heff_intShow(v_t_247), v_t_2411);
    V v_t_2413 = heff_strAppend(heff_intShow(v_t_246), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str4), v_t_2412));
    return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str5), v_t_2413);
  }
  default: return heff_nomatch(v_os_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2etestsSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeVariable_str0, 17, "HEFF_TEST_OUTCOME");

static V g_heff_2ebuild_2ecommands_2eoutcomeVariable_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eoutcomeVariable_st;
static V g_heff_2ebuild_2ecommands_2eoutcomeVariable_init(void) {
  return ((V)&g_heff_2ebuild_2ecommands_2eoutcomeVariable_str0);
}
V g_heff_2ebuild_2ecommands_2eoutcomeVariable_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eoutcomeVariable_st)) return g_heff_2ebuild_2ecommands_2eoutcomeVariable_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eoutcomeVariable_val, &g_heff_2ebuild_2ecommands_2eoutcomeVariable_st, g_heff_2ebuild_2ecommands_2eoutcomeVariable_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str0, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str1, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str2, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str3, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str6, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str7, 33, ", and said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str8, 3, "it ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str9, 45, "what it said of how it went could not be read");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str10, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str11, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str12, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str13, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str16, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str17, 33, ", and said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str18, 3, "it ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str19, 45, "what it said of how it went could not be read");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str20, 11, " ms: killed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str21, 33, "took longer than its time limit, ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str22, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str23, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str24, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str25, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str27, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str28, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str29, 33, ", and said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str30, 3, "it ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str31, 45, "what it said of how it went could not be read");
Clo g_heff_2ebuild_2ecommands_2eranOutcome_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranOutcome_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eranOutcome(V v_name_240, V v_limit_241, V v_r_242, V v_said_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_r_242, 0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Exited: {
    V v_ru_24t_244_24Exited = heff_take_reuse_n(v_t_244, 0ULL, 1);
    heff_drop(v_limit_241);
    switch (heff_tag_of(v_said_243)) {
    case TAG_Nothing: {
      V v_t_246 = heff_take_field(v_r_242, 0);
      V v_t_249;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Exited: {
        V v_n_247 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str0), heff_intShow(v_n_247));
        break;
      }
      case TAG_Signalled: {
        V v_n_248 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str1), heff_intShow(v_n_248));
        break;
      }
      case TAG_TimedOut: {
        v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str2);
        break;
      }
      case TAG_NotRun: {
        v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str3);
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      V v_t_2412;
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_242, 2)), ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str4))) {
        heff_drop_rec(v_r_242, 3);
        v_t_2412 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str5);
      } else {
        V v_t_2411 = ({ V a_0 = MK_INT(20LL); V b_1 = heff_get_n(v_r_242, 2, 3); V r_ = (g_heff_2ebuild_2ecommands_2elastLines(a_0, b_1)); heff_drop(b_1); r_; });
        v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str6), v_t_2411);
      }
      V v_t_2413 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str7), v_t_2412));
      V v_why_2414 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str8), v_t_2413);
      V v_t_2415 = heff_tag_at_n(v_ru_24t_244_24Exited, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2414})});
      return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2415, MK_INT(0LL), NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_text_2416 = heff_field(v_said_243, 0);
      heff_take_n(v_said_243, 1ULL, 1);
      heff_drop_rec(v_r_242, 3);
      V v_t_2417 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2418 = ({ V a_0 = v_text_2416; V a_1 = v_t_2417; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_text_2416); r_; });
      {
        V v_field_2420 = v_t_2418.f[1];
        int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
        if ((v_tag_2419 == ((int64_t)0ULL))) {
          V v_why_2422 = v_field_2420;
          heff_drop(v_why_2422);
          V v_t_2423 = heff_tag_at_n(v_ru_24t_244_24Exited, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str9)})});
          return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2423, MK_INT(0LL), NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24t_244_24Exited, 1);
          V v_j_2424 = v_field_2420;
          return (g_heff_2ebuild_2ecommands_2eoutcomeOfJson(v_name_240, v_j_2424));
        }
      }
    }
    default: return heff_nomatch(v_said_243);
    }
  }
  case TAG_Signalled: {
    V v_ru_24t_244_24Signalled = heff_take_reuse_n(v_t_244, 0ULL, 1);
    heff_drop(v_limit_241);
    switch (heff_tag_of(v_said_243)) {
    case TAG_Nothing: {
      V v_t_2426 = heff_take_field(v_r_242, 0);
      V v_t_2429;
      switch (heff_tag_of(v_t_2426)) {
      case TAG_Exited: {
        V v_n_2427 = heff_field(v_t_2426, 0);
        heff_take_n(v_t_2426, 1ULL, 1);
        v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str10), heff_intShow(v_n_2427));
        break;
      }
      case TAG_Signalled: {
        V v_n_2428 = heff_field(v_t_2426, 0);
        heff_take_n(v_t_2426, 1ULL, 1);
        v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str11), heff_intShow(v_n_2428));
        break;
      }
      case TAG_TimedOut: {
        v_t_2429 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str12);
        break;
      }
      case TAG_NotRun: {
        v_t_2429 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str13);
        break;
      }
      default: heff_nomatch(v_t_2426);
      }
      V v_t_2432;
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_242, 2)), ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str14))) {
        heff_drop_rec(v_r_242, 3);
        v_t_2432 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str15);
      } else {
        V v_t_2431 = ({ V a_0 = MK_INT(20LL); V b_1 = heff_get_n(v_r_242, 2, 3); V r_ = (g_heff_2ebuild_2ecommands_2elastLines(a_0, b_1)); heff_drop(b_1); r_; });
        v_t_2432 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str16), v_t_2431);
      }
      V v_t_2433 = heff_strAppend(v_t_2429, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str17), v_t_2432));
      V v_why_2434 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str18), v_t_2433);
      V v_t_2435 = heff_tag_at_n(v_ru_24t_244_24Signalled, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2434})});
      return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2435, MK_INT(0LL), NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_text_2436 = heff_field(v_said_243, 0);
      heff_take_n(v_said_243, 1ULL, 1);
      heff_drop_rec(v_r_242, 3);
      V v_t_2437 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2438 = ({ V a_0 = v_text_2436; V a_1 = v_t_2437; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_text_2436); r_; });
      {
        V v_field_2440 = v_t_2438.f[1];
        int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
        if ((v_tag_2439 == ((int64_t)0ULL))) {
          V v_why_2442 = v_field_2440;
          heff_drop(v_why_2442);
          V v_t_2443 = heff_tag_at_n(v_ru_24t_244_24Signalled, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str19)})});
          return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2443, MK_INT(0LL), NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24t_244_24Signalled, 1);
          V v_j_2444 = v_field_2440;
          return (g_heff_2ebuild_2ecommands_2eoutcomeOfJson(v_name_240, v_j_2444));
        }
      }
    }
    default: return heff_nomatch(v_said_243);
    }
  }
  case TAG_TimedOut: {
    heff_drop_rec(v_r_242, 3);
    heff_drop(v_said_243);
    V v_t_2445 = heff_strAppend(heff_intShow(v_limit_241), ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str20));
    V v_t_2446 = heff_tag_n(TAG_FailBecause, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str21), v_t_2445)});
    return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_tag_n(TAG_Just, 1, (V[]){v_t_2446}), MK_INT(0LL), NTAG(TAG_Nil)});
  }
  case TAG_NotRun: {
    heff_drop(v_limit_241);
    switch (heff_tag_of(v_said_243)) {
    case TAG_Nothing: {
      V v_t_2447 = heff_take_field(v_r_242, 0);
      V v_t_2450;
      switch (heff_tag_of(v_t_2447)) {
      case TAG_Exited: {
        V v_n_2448 = heff_field(v_t_2447, 0);
        heff_take_n(v_t_2447, 1ULL, 1);
        v_t_2450 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str22), heff_intShow(v_n_2448));
        break;
      }
      case TAG_Signalled: {
        V v_n_2449 = heff_field(v_t_2447, 0);
        heff_take_n(v_t_2447, 1ULL, 1);
        v_t_2450 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str23), heff_intShow(v_n_2449));
        break;
      }
      case TAG_TimedOut: {
        v_t_2450 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str24);
        break;
      }
      case TAG_NotRun: {
        v_t_2450 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str25);
        break;
      }
      default: heff_nomatch(v_t_2447);
      }
      V v_t_2453;
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_242, 2)), ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str26))) {
        heff_drop_rec(v_r_242, 3);
        v_t_2453 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str27);
      } else {
        V v_t_2452 = ({ V a_0 = MK_INT(20LL); V b_1 = heff_get_n(v_r_242, 2, 3); V r_ = (g_heff_2ebuild_2ecommands_2elastLines(a_0, b_1)); heff_drop(b_1); r_; });
        v_t_2453 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str28), v_t_2452);
      }
      V v_t_2454 = heff_strAppend(v_t_2450, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str29), v_t_2453));
      V v_why_2455 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str30), v_t_2454);
      V v_t_2456 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2455})});
      return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2456, MK_INT(0LL), NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_text_2457 = heff_field(v_said_243, 0);
      V v_ru_24said_243_24Just = heff_take_reuse_n(v_said_243, 1ULL, 1);
      heff_drop_rec(v_r_242, 3);
      V v_t_2458 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2459 = ({ V a_0 = v_text_2457; V a_1 = v_t_2458; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_text_2457); r_; });
      {
        V v_field_2461 = v_t_2459.f[1];
        int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
        if ((v_tag_2460 == ((int64_t)0ULL))) {
          V v_why_2463 = v_field_2461;
          heff_drop(v_why_2463);
          V v_t_2464 = heff_tag_at_n(v_ru_24said_243_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str31)})});
          return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2464, MK_INT(0LL), NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24said_243_24Just, 1);
          V v_j_2465 = v_field_2461;
          return (g_heff_2ebuild_2ecommands_2eoutcomeOfJson(v_name_240, v_j_2465));
        }
      }
    }
    default: return heff_nomatch(v_said_243);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ebuild_2ecommands_2eranOutcome_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eranOutcome(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str1, 13, "build : Build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str2, 37, "build = { backend = C, run = \"main\" }");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str3, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str5, 21, "-- heff home with it.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str7, 69, "-- page's script of it.  A field `ships = [...]` would name files and");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str8, 69, "-- directories of the project's root for `heff install` to put in the");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str10, 69, "-- main.hf's `main`, compiled through C (by `zig cc`); `Page` makes a");

static V g_heff_2ebuild_2ecommands_2ebuildText_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2ebuildText_st;
static V g_heff_2ebuild_2ecommands_2ebuildText_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2ebuildText_str9); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2ebuildText_str10); V a_2 = v_t_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildText_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2ebuildText_st)) return g_heff_2ebuild_2ecommands_2ebuildText_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2ebuildText_val, &g_heff_2ebuild_2ecommands_2ebuildText_st, g_heff_2ebuild_2ecommands_2ebuildText_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str1, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str2, 6, "source");
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam3(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam8(V self, V *args) {
  V v_x_2432 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_244 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2433 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2415, v_x_2416));
  V v_t_2434 = ({ V a_0 = v_x_2425; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_x_2425); r_; });
  V v_t_2435 = ({ V a_0 = v_x_2432; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_x_2432); r_; });
  V v_t_2436 = (g_prelude_2e_2b_2b(v_t_2434, v_t_2435));
  V v_x_2437 = heff_rec_n(5, shape_lib__mod__cwd__style__heff, (V[]){v_x_242, v_x_243, v_x_244, v_st_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_t_2436})});
  V f_ = v_k_241;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_x_243 = heff_env(self)[5];
  V v_x_244 = heff_env(self)[6];
  V v_k_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2426 = (g_std_2epath_2eparse(v_st_2415, v_x_2417));
  V v_t_2427 = (g_std_2epath_2eparse(v_st_2415, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str2)));
  V v_t_2428 = (g_std_2epath_2ejoin(v_t_2426, v_t_2427));
  V v_s_2429 = ({ V a_0 = v_st_2415; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2428); r_; });
  V v_t_2430 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2429; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2431 = ({ V a_0 = v_t_2430; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_2430); r_; });
  V f_ = v_c_2431;
  heff_room[0] = v_hd_240;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam8, 1, 7, (V[]){v_st_2415, v_x_2416, v_x_2425, v_x_242, v_x_243, v_x_244, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam6(V self, V *args) {
  V v_x_2417 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_244 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_home_2418 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2415, heff_dup(v_x_2416)));
  V v_t_2419 = (g_std_2epath_2eparse(v_st_2415, v_home_2418));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_2415, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str1)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2415; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2422; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2424 = ({ V a_0 = v_t_2423; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_2423); r_; });
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam7, 1, 8, (V[]){v_st_2415, v_x_2417, v_hd_240, v_x_2416, v_x_242, v_x_243, v_x_244, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_st_2415 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_k_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam6, 1, 7, (V[]){v_st_2415, v_x_2416, v_hd_240, v_x_242, v_x_243, v_x_244, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2415;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str0))) {
    v_st_2415 = NTAG(TAG_Windows);
  } else {
    v_st_2415 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam5, 1, 6, (V[]){v_hd_240, v_st_2415, v_x_242, v_x_243, v_x_244, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam3_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s615738393x1686646143(v_t_2412, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam4, 1, 5, (V[]){v_hd_240, v_x_242, v_x_243, v_x_244, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam2, 1, 4, (V[]){v_hd_240, v_x_242, v_x_243, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam1, 1, 3, (V[]){v_hd_240, v_x_242, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str2, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str3, 3, "-O0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str4, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str5, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str6, 11, "ReleaseSafe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str7, 3, "-Os");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str8, 12, "ReleaseSmall");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str9, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str10, 3, "-O3");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str11, 11, "ReleaseFast");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str12, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str15, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str16, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str17, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str18, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str19, 3, "zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str20, 27, ": `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str21, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str22, 27, ": `zig cc` could not build ");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam7, 2, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535(V v_prog_240, V v_failed_241, V v_who_242, V v_st_243, V v_flags_244, V v_p_245, V v_dir_246, V v_out_247, V v_next_248) {
top: ;
  V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_dir_246); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2410 = (g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(v_t_249));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam0, 2, 10, (V[]){v_c_2410, heff_dup(v_st_243), v_dir_246, v_prog_240, v_p_245, v_flags_244, v_out_247, v_next_248, v_who_242, v_failed_241});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam2(V self, V *args) {
  V v_n_2417 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = (g_std_2epath_2eparse(v_st_243, v_dir_246));
  V v_t_2419 = (g_std_2epath_2eparse(v_st_243, v_n_2417));
  V v_t_2420 = (g_std_2epath_2ejoin(v_t_2418, v_t_2419));
  return ({ V a_0 = v_st_243; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_2420); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam3(V self, V *args) {
  V v_n_2425 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = (g_std_2epath_2eparse(v_st_243, v_dir_246));
  V v_t_2427 = (g_std_2epath_2eparse(v_st_243, v_n_2425));
  V v_t_2428 = (g_std_2epath_2ejoin(v_t_2426, v_t_2427));
  return ({ V a_0 = v_st_243; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_2428); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam4(V self, V *args) {
  V v_t_2433 = args[0];
  return v_t_2433;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam7(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  heff_drop(v_hd_2443);
  V v_t_2445 = heff_rec_n(3, shape_ended__out__err, (V[]){NTAG(TAG_NotRun), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str13), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str14)});
  V f_ = v_k_2444;
  args[0] = v_t_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam8(V self, V *args) {
  V v_r_2453 = args[0];
  return v_r_2453;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam12(V self, V *args) {
  V v_x_2480 = args[0];
  V v_who_242 = heff_env(self)[0];
  V v_out_247 = heff_env(self)[1];
  V v_failed_241 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2480);
  V v_t_2481 = heff_strAppend(v_who_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str22), v_out_247));
  V f_ = v_failed_241;
  heff_room[0] = v_t_2481;
  heff_room[1] = v_hd_2411;
  heff_room[2] = v_k_2412;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam11(V self, V *args) {
  V v_x_2471 = args[0];
  V v_who_242 = heff_env(self)[0];
  V v_out_247 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_failed_241 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2471);
  V v_t_2472 = heff_strAppend(heff_dup(v_who_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str20), heff_dup(v_out_247)));
  V v_t_2473 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2472, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str21)), NTAG(TAG_MkUnit)});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2479}), heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam12, 1, 5, (V[]){v_who_242, v_out_247, v_failed_241, v_hd_2411, v_k_2412})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam10(V self, V *args) {
  V v_x_2459 = args[0];
  V v_x_2456 = heff_env(self)[0];
  V v_next_248 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  V v_who_242 = heff_env(self)[4];
  V v_out_247 = heff_env(self)[5];
  V v_failed_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2459);
  V v_t_2460 = heff_take_field(v_x_2456, 0);
  V v_t_2463;
  switch (heff_tag_of(v_t_2460)) {
  case TAG_Exited: {
    V v_n_2461 = heff_field(v_t_2460, 0);
    heff_take_n(v_t_2460, 1ULL, 1);
    v_t_2463 = heff_intEq(v_n_2461, MK_INT(0LL));
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2460, 0ULL, 1);
    v_t_2463 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2463 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2463 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2460);
  }
  if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2456, 3);
    heff_drop(v_who_242);
    heff_drop(v_out_247);
    heff_drop(v_failed_241);
    heff_drop(v_t_2463);
    V f_ = v_next_248;
    heff_room[0] = v_hd_2411;
    heff_room[1] = v_k_2412;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_next_248);
    heff_drop(v_t_2463);
    V v_t_2464 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_get_n(v_x_2456, 2, 3), NTAG(TAG_MkUnit)});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2470}), heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam11, 1, 5, (V[]){v_who_242, v_out_247, v_hd_2411, v_failed_241, v_k_2412})));
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam9(V self, V *args) {
  V v_x_2456 = args[0];
  V v_x_2435 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_next_248 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  V v_who_242 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_failed_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2457 = heff_tag_n(TAG_End, 2, (V[]){v_x_2435, NTAG(TAG_MkUnit)});
  V v_t_2458 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2457}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2458, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam10, 1, 7, (V[]){v_x_2456, v_next_248, v_hd_2411, v_k_2412, v_who_242, v_out_247, v_failed_241})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam6(V self, V *args) {
  V v_x_2442 = args[0];
  V v_out_247 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_flags_244 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_x_2435 = heff_env(self)[4];
  V v_hd_2411 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2412 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_failed_241 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2455;
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Nothing: {
    heff_drop(v_x_2421);
    heff_drop(v_flags_244);
    v_c_2455 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam7_clo);
    break;
  }
  case TAG_Just: {
    V v_os_2446 = heff_field(v_x_2442, 0);
    heff_take_n(v_x_2442, 1ULL, 1);
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str15), NTAG(TAG_Nil)});
    V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str16), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_out_247), v_t_2447})});
    V v_t_2449 = (g_prelude_2e_2b_2b(v_os_2446, v_t_2448));
    V v_t_2450 = (g_prelude_2e_2b_2b(v_x_2421, v_t_2449));
    V v_t_2451 = (g_prelude_2e_2b_2b(v_flags_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str17), v_t_2450})));
    V v_argv_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str18), v_t_2451});
    V v_t_2454 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_2435), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str19), v_argv_2452, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam8_clo)})}));
    v_c_2455 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2454}));
    break;
  }
  default: heff_nomatch(v_x_2442);
  }
  V f_ = v_c_2455;
  heff_room[0] = heff_dup(v_hd_2411);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam9, 1, 8, (V[]){v_x_2435, v_prog_240, v_hd_2411, v_next_248, v_k_2412, v_who_242, v_out_247, v_failed_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_flags_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_out_247 = heff_env(self)[4];
  V v_x_2421 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2412 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_failed_241 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2436 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str3); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s2065989517x1307020881(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2440;
  if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
    heff_drop(v_t_2436);
    v_t_2440 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str4);
  } else {
    heff_drop(v_t_2436);
    V v_t_2437 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str5); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s2065989517x1307020881(b_0, a_1)); heff_drop(b_0); r_; });
    if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
      heff_drop(v_t_2437);
      v_t_2440 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str6);
    } else {
      heff_drop(v_t_2437);
      V v_t_2438 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str7); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s2065989517x1307020881(b_0, a_1)); heff_drop(b_0); r_; });
      if ((heff_dup(v_t_2438) == NTAG(TAG_True))) {
        heff_drop(v_t_2438);
        v_t_2440 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str8);
      } else {
        heff_drop(v_t_2438);
        V v_t_2439 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str9); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str10); V a_2 = v_flags_244; V r_ = (g_list_2eany_24s529567056x880977707(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
          heff_drop(v_t_2439);
          v_t_2440 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str11);
        } else {
          heff_drop(v_t_2439);
          v_t_2440 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str12);
        }
      }
    }
  }
  V v_c_2441 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571(heff_dup(v_prog_240), heff_dup(v_x_2435), v_t_2440, v_x_2429, NTAG(TAG_Nil)));
  V f_ = v_c_2441;
  heff_room[0] = heff_dup(v_hd_2411);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam6, 1, 10, (V[]){v_out_247, v_x_2421, v_flags_244, v_prog_240, v_x_2435, v_hd_2411, v_next_248, v_k_2412, v_who_242, v_failed_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_flags_244 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_k_2412 = heff_env(self)[8];
  V v_who_242 = heff_env(self)[9];
  V v_failed_241 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2415;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_dup(heff_field(v_x_2413, 0));
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2416 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str0); V a_1 = v_t_2415; V r_ = (g_list_2ekeepIf_24s201362679x620001272(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam2, 1, 2, (V[]){heff_dup(v_st_243), heff_dup(v_dir_246)}), v_t_2416));
  V v_t_2423;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    v_t_2423 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2422 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    v_t_2423 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2424 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str1); V a_1 = v_t_2423; V r_ = (g_list_2ekeepIf_24s201362679x620001272(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2429 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam3, 1, 2, (V[]){v_st_243, v_dir_246}), v_t_2424));
  V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2421));
  V v_t_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2429));
  V v_total_2432 = heff_intAdd(heff_intAdd(v_t_2430, v_t_2431), MK_INT(1LL));
  V v_t_2434 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_245, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str2), v_total_2432, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam4_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2434, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam5, 1, 10, (V[]){v_flags_244, v_prog_240, v_x_2429, v_hd_2411, v_out_247, v_x_2421, v_next_248, v_k_2412, v_who_242, v_failed_241})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_st_243 = heff_env(self)[1];
  V v_dir_246 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  V v_flags_244 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_failed_241 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam1, 1, 11, (V[]){v_st_243, v_dir_246, v_prog_240, v_p_245, v_hd_2411, v_flags_244, v_out_247, v_next_248, v_k_2412, v_who_242, v_failed_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str2, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str4, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      return (g_co_2eop_24s615738393x1686646143(v_t_2415, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam1, 1, 6, (V[]){v_dir_240, v_f_246, v_p_242, v_text_247, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam4(V self, V *args) {
  V v_x_2467 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2467);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam5(V self, V *args) {
  V v_x_2480 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2480);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam3(V self, V *args) {
  V v_x_2454 = args[0];
  V v_x_2437 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_st_2418 = heff_env(self)[5];
  V v_f_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  if ((heff_dup(v_x_2437) == NTAG(TAG_True))) {
    heff_drop(v_x_2437);
    if ((heff_dup(v_x_2454) == NTAG(TAG_True))) {
      heff_drop(v_x_2454);
      heff_drop(v_st_2418);
      heff_drop(v_f_246);
      return (g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641(v_dir_240, v_rest_245, v_p_242, v_p_243));
    } else {
      heff_drop(v_x_2454);
      heff_drop(v_rest_245);
      V v_t_2455 = (g_std_2epath_2eparse(v_st_2418, v_dir_240));
      V v_t_2456 = (g_std_2epath_2eparse(v_st_2418, v_f_246));
      V v_t_2457 = (g_std_2epath_2ejoin(v_t_2455, v_t_2456));
      V v_t_2458 = ({ V a_0 = v_st_2418; V a_1 = v_t_2457; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2457); r_; });
      V v_str_2459 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str2), v_t_2458);
      V v_t_2460 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2459, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str3)), NTAG(TAG_MkUnit)});
      V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
      V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
      V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
      V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
      V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
      V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2466}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam4, 1, 1, (V[]){v_p_243})));
    }
  } else {
    heff_drop(v_x_2454);
    heff_drop(v_x_2437);
    heff_drop(v_rest_245);
    V v_t_2468 = (g_std_2epath_2eparse(v_st_2418, v_dir_240));
    V v_t_2469 = (g_std_2epath_2eparse(v_st_2418, v_f_246));
    V v_t_2470 = (g_std_2epath_2ejoin(v_t_2468, v_t_2469));
    V v_t_2471 = ({ V a_0 = v_st_2418; V a_1 = v_t_2470; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2470); r_; });
    V v_str_2472 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str4), v_t_2471);
    V v_t_2473 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2472, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str5)), NTAG(TAG_MkUnit)});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2479}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam5, 1, 1, (V[]){v_p_243})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam2(V self, V *args) {
  V v_x_2437 = args[0];
  V v_st_2418 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2438 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_dir_240)));
  V v_t_2439 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_f_246)));
  V v_t_2440 = (g_std_2epath_2ejoin(v_t_2438, v_t_2439));
  V v_s_2441 = ({ V a_0 = v_st_2418; V a_1 = v_t_2440; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2440); r_; });
  V v_t_2442 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2441; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  int64_t v_t_2443 = (heff_unbox_word(heff_strLength_lent(v_f_246, 0)) - ((int64_t)3ULL));
  V v_t_2444 = heff_strSlice(heff_dup(v_f_246), heff_box_word(v_t_2443), heff_strLength_lent(v_f_246, 0));
  V v_t_2452;
  if (heff_strEq_c(v_t_2444, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str1))) {
    HeffT2 v_t_2446 = (g_heff_2esyntax_2eformat_2eformat_24cpr(heff_dup(v_text_247)));
    {
      V v_field_2448 = v_t_2446.f[1];
      int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
      if ((v_tag_2447 == ((int64_t)0ULL))) {
        V v_x_2450 = v_field_2448;
        heff_drop(v_x_2450);
        v_t_2452 = v_text_247;
      } else {
        heff_drop(v_text_247);
        V v_out_2451 = v_field_2448;
        v_t_2452 = v_out_2451;
      }
    }
  } else {
    v_t_2452 = v_text_247;
  }
  V v_c_2453 = ({ V a_0 = v_t_2442; V a_1 = v_t_2452; V r_ = (g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(a_0, a_1)); heff_drop(v_t_2442); r_; });
  V f_ = v_c_2453;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam3, 1, 7, (V[]){v_x_2437, v_dir_240, v_rest_245, v_p_242, v_p_243, v_st_2418, v_f_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2418;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_t_2419 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_dir_240)));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_f_246)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  HeffT3 v_t_2423 = (g_std_2epath_2eparse_24cpr(v_st_2418, v_s_2422));
  V v_t_2433;
  {
    V v_field_2424 = v_t_2423.f[0];
    V v_field_2425 = v_t_2423.f[1];
    V v_field_2426 = v_t_2423.f[2];
    V v_d_2427 = v_field_2424;
    V v_a_2428 = v_field_2425;
    V v_xs_2429 = v_field_2426;
    V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2429));
    V v_xs_2431 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2430; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2430); r_; });
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
    v_t_2433 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2427, v_a_2428, v_t_2432});
  }
  V v_s_2434 = ({ V a_0 = v_st_2418; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2433); r_; });
  V v_t_2435 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2434; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2436 = ({ V a_0 = v_t_2435; V r_ = (g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(a_0)); heff_drop(v_t_2435); r_; });
  V f_ = v_c_2436;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam2, 1, 7, (V[]){v_st_2418, v_dir_240, v_f_246, v_text_247, v_p_242, v_rest_245, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str0, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str2, 9, "fetching ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str3, 1, "-");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str4, 1, "-");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str5, 11, "HEAD^{tree}");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str6, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str7, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str8, 4, ".git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str9, 5, "tree:");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str10, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str12, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str13, 18, "heff get: fetched ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str15, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str16, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str17, 12, "cannot keep ");
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382(V v_prog_240, V v_ps_241, V v_path_242, V v_v_243) {
top: ;
  V v_x_244 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_242), heff_dup(v_v_243)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam0, 2, 5, (V[]){v_x_244, v_ps_241, v_path_242, v_v_243, v_prog_240});
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam4(V self, V *args) {
  V v_t_2430 = args[0];
  return v_t_2430;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam8(V self, V *args) {
  V v_r_2451 = args[0];
  return v_r_2451;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam13(V self, V *args) {
  V v_x_2494 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_2476 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2494);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2476});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam12(V self, V *args) {
  V v_x_2479 = args[0];
  V v_x_2459 = heff_env(self)[0];
  V v_x_2470 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_v_243 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  V v_x_2476 = heff_env(self)[6];
  V v_x_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2480 = heff_get_n(v_x_2459, 0, 3);
  V v_t_2484;
  switch (heff_tag_of(v_t_2480)) {
  case TAG_Exited: {
    V v_n_2481 = heff_field(v_t_2480, 0);
    heff_take_n(v_t_2480, 1ULL, 1);
    if (heff_intEq_c(v_n_2481, MK_INT(0LL))) {
      if ((heff_dup(v_x_2470) == NTAG(TAG_True))) {
        heff_drop(v_x_2470);
        v_t_2484 = v_x_2479;
      } else {
        heff_drop(v_x_2479);
        heff_drop(v_x_2470);
        v_t_2484 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_x_2479);
      heff_drop(v_x_2470);
      v_t_2484 = NTAG(TAG_False);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2480, 0ULL, 1);
    heff_drop(v_x_2479);
    heff_drop(v_x_2470);
    v_t_2484 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    heff_drop(v_x_2479);
    heff_drop(v_x_2470);
    v_t_2484 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    heff_drop(v_x_2479);
    heff_drop(v_x_2470);
    v_t_2484 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2480);
  }
  if ((heff_dup(v_t_2484) == NTAG(TAG_True))) {
    heff_drop(v_x_244);
    heff_drop(v_t_2484);
    V v_t_2485 = heff_strAppend(v_path_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str12), v_v_243));
    V v_t_2486 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str13), v_t_2485), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str14));
    V v_t_2487 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2486, NTAG(TAG_MkUnit)});
    V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
    V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
    V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
    V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2492})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2493}), v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam13, 1, 2, (V[]){v_k_246, v_x_2476})));
  } else {
    heff_drop(v_hd_245);
    heff_drop(v_x_2476);
    heff_drop(v_t_2484);
    V v_t_2495 = heff_strAppend(v_v_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str15), v_x_244));
    V v_t_2496 = heff_strAppend(v_path_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str16), v_t_2495));
    V v_t_2497 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str17), v_t_2496)});
    V f_ = v_k_246;
    args[0] = v_t_2497;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam11(V self, V *args) {
  V v_x_2470 = args[0];
  V v_x_2459 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_s_2471 = heff_dup(heff_rfield(v_x_2459, 1));
  V v_t_2472 = (g_prelude_2eskipSpaces(v_s_2471, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_2473 = (heff_unbox_word(heff_strLength_lent(v_s_2471, 0)) - ((int64_t)1ULL));
  V v_t_2474 = (g_prelude_2eskipSpaces(v_s_2471, heff_box_word(v_t_2473), MK_INT(-1LL)));
  V v_t_2475 = heff_strSlice(v_s_2471, v_t_2472, heff_intAdd(v_t_2474, MK_INT(1LL)));
  V v_x_2476 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str9), v_t_2475);
  V v_t_2477 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_strAppend(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str10)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2478 = ({ V a_0 = v_t_2477; V a_1 = heff_strAppend(heff_dup(v_x_2476), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str11)); V r_ = (g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(a_0, a_1)); heff_drop(v_t_2477); r_; });
  V f_ = v_c_2478;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam12, 1, 8, (V[]){v_x_2459, v_x_2470, v_path_242, v_v_243, v_hd_245, v_k_246, v_x_2476, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam10(V self, V *args) {
  V v_x_2467 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_x_2459 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2467);
  V v_t_2468 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_244); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2469 = ({ V a_0 = v_t_2468; V r_ = (g_heff_2eutil_2efiles_2ereadOnly_24s1629463395x577531160(a_0)); heff_drop(v_t_2468); r_; });
  V f_ = v_c_2469;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam11, 1, 6, (V[]){v_x_2459, v_x_244, v_hd_245, v_path_242, v_v_243, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam9(V self, V *args) {
  V v_x_2459 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2460 = heff_get_n(v_ps_241, 5, 6);
  V v_t_2461 = (g_std_2epath_2eparse(v_st_2460, heff_dup(v_x_244)));
  V v_t_2462 = (g_std_2epath_2eparse(v_st_2460, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str8)));
  V v_t_2463 = (g_std_2epath_2ejoin(v_t_2461, v_t_2462));
  V v_s_2464 = ({ V a_0 = v_st_2460; V a_1 = v_t_2463; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2460); heff_drop(v_t_2463); r_; });
  V v_t_2465 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2464; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2466 = ({ V a_0 = v_t_2465; V r_ = (g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(a_0)); heff_drop(v_t_2465); r_; });
  V f_ = v_c_2466;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam10, 1, 6, (V[]){v_x_244, v_hd_245, v_x_2459, v_path_242, v_v_243, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam14(V self, V *args) {
  V v_x_24101 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_why_2498 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24101);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_why_2498});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam7(V self, V *args) {
  V v_x_2446 = args[0];
  V v_x_2443 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_v_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2446);
  switch (heff_tag_of(v_x_2443)) {
  case TAG_Nothing: {
    V v_t_2447 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_244); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str5), NTAG(TAG_Nil)});
    V v_t_2449 = ({ V a_0 = v_t_2447; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_2447); r_; });
    V v_t_2450 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str7), v_t_2448}), v_t_2449, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_a_2452 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2450, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam8_clo)});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2458}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam9, 1, 6, (V[]){v_ps_241, v_x_244, v_hd_245, v_path_242, v_v_243, v_k_246})));
  }
  case TAG_Just: {
    V v_why_2498 = heff_field(v_x_2443, 0);
    heff_take_n(v_x_2443, 1ULL, 1);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_path_242);
    heff_drop(v_v_243);
    V v_t_2499 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_244; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_24100 = ({ V a_0 = v_t_2499; V r_ = (g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(a_0)); heff_drop(v_t_2499); r_; });
    V f_ = v_c_24100;
    heff_room[0] = v_hd_245;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam14, 1, 2, (V[]){v_k_246, v_why_2498});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2443);
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam6(V self, V *args) {
  V v_x_2443 = args[0];
  V v_x_2433 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_ps_241 = heff_env(self)[4];
  V v_path_242 = heff_env(self)[5];
  V v_v_243 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2444 = heff_tag_n(TAG_End, 2, (V[]){v_x_2433, NTAG(TAG_MkUnit)});
  V v_t_2445 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2444}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2445, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam7, 1, 7, (V[]){v_x_2443, v_x_244, v_hd_245, v_ps_241, v_path_242, v_v_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_v_243 = heff_env(self)[0];
  V v_path_242 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2434 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str3); V a_1 = v_v_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str4), v_v_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  HeffT2 v_t_2435 = (g_heff_2ebuild_2eproject_2epseudoParts_24cpr(v_t_2434));
  {
    V v_field_2437 = v_t_2435.f[1];
    int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
    V v_c_2442;
    if ((v_tag_2436 == ((int64_t)0ULL))) {
      V v_it1_2439 = v_field_2437;
      switch (heff_tag_of(v_it1_2439)) {
      case TAG_MkPair: {
        V v_time_2440 = heff_field(v_it1_2439, 0);
        V v_hash_2441 = heff_field(v_it1_2439, 1);
        heff_take_n(v_it1_2439, 3ULL, 2);
        v_c_2442 = (g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245(heff_dup(v_path_242), heff_dup(v_v_243), v_time_2440, v_hash_2441, heff_dup(v_x_244)));
        break;
      }
      default: heff_nomatch(v_it1_2439);
      }
    } else {
      heff_drop(v_field_2437);
      v_c_2442 = (g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502(heff_dup(v_path_242), heff_dup(v_v_243), heff_dup(v_x_244)));
    }
    V f_ = v_c_2442;
    heff_room[0] = heff_dup(v_hd_245);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam6, 1, 8, (V[]){v_x_2433, v_prog_240, v_hd_245, v_x_244, v_ps_241, v_path_242, v_v_243, v_k_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_v_243 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2428);
  V v_t_2429 = heff_strAppend(heff_dup(v_path_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str1), heff_dup(v_v_243)));
  V v_t_2431 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str2), v_t_2429), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam4_clo)});
  V v_t_2432 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2431}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2432, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam5, 1, 7, (V[]){v_v_243, v_path_242, v_x_244, v_hd_245, v_prog_240, v_ps_241, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2412);
  V v_st_2413 = heff_dup(heff_rfield(v_ps_241, 5));
  HeffT3 v_t_2414 = (g_std_2epath_2eparse_24cpr(v_st_2413, heff_dup(v_x_244)));
  V v_t_2424;
  {
    V v_field_2415 = v_t_2414.f[0];
    V v_field_2416 = v_t_2414.f[1];
    V v_field_2417 = v_t_2414.f[2];
    V v_d_2418 = v_field_2415;
    V v_a_2419 = v_field_2416;
    V v_xs_2420 = v_field_2417;
    V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2420));
    V v_xs_2422 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2421; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2421); r_; });
    V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2422));
    v_t_2424 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2418, v_a_2419, v_t_2423});
  }
  V v_s_2425 = ({ V a_0 = v_st_2413; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2413); heff_drop(v_t_2424); r_; });
  V v_t_2426 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2425; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2427 = ({ V a_0 = v_t_2426; V r_ = (g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(a_0)); heff_drop(v_t_2426); r_; });
  V f_ = v_c_2427;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam3, 1, 7, (V[]){v_path_242, v_v_243, v_prog_240, v_hd_245, v_x_244, v_ps_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    V v_t_2410 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_244); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(a_0)); heff_drop(v_t_2410); r_; });
    V f_ = v_c_2411;
    heff_room[0] = heff_dup(v_hd_245);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam2, 1, 7, (V[]){v_ps_241, v_x_244, v_hd_245, v_path_242, v_v_243, v_prog_240, v_k_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_h_24102 = heff_field(v_x_249, 0);
    V v_ru_24x_249_24Just = heff_take_reuse_n(v_x_249, 1ULL, 1);
    heff_drop(v_x_244);
    heff_drop(v_hd_245);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_path_242);
    heff_drop(v_v_243);
    heff_drop(v_prog_240);
    V v_t_24103 = (g_prelude_2eskipSpaces(v_h_24102, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_24104 = (heff_unbox_word(heff_strLength_lent(v_h_24102, 0)) - ((int64_t)1ULL));
    V v_t_24105 = (g_prelude_2eskipSpaces(v_h_24102, heff_box_word(v_t_24104), MK_INT(-1LL)));
    V v_t_24106 = heff_strSlice(v_h_24102, v_t_24103, heff_intAdd(v_t_24105, MK_INT(1LL)));
    V v_x_24107 = heff_tag_at_n(v_ru_24x_249_24Just, TAG_Right, 1, (V[]){v_t_24106});
    V f_ = v_k_246;
    args[0] = v_x_24107;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_v_243 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_strAppend(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str0)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_247); r_; });
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam1, 1, 7, (V[]){v_x_244, v_hd_245, v_ps_241, v_path_242, v_v_243, v_prog_240, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256(V v_rep_240, V v_prog_241, V v_st_242, V v_t_243, V v_bp_244, V v_done_245, V v_x5_246) {
top: ;
  switch (heff_tag_of(v_x5_246)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_t_243);
    heff_drop(v_bp_244);
    return v_done_245;
  }
  case TAG_Cons: {
    V v_a_247 = heff_field(v_x5_246, 0);
    V v_rest_248 = heff_field(v_x5_246, 1);
    V v_t_249 = (g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256(heff_dup(v_rep_240), heff_dup(v_prog_241), v_st_242, heff_dup(v_t_243), heff_dup(v_bp_244), v_done_245, v_rest_248));
    return (g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648(v_rep_240, v_prog_241, v_st_242, v_t_243, v_bp_244, heff_dup(heff_rfield(v_a_247, 0)), heff_dup(heff_rfield(v_a_247, 1)), v_t_249));
  }
  default: return heff_nomatch(v_x5_246);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256(a[0], a[1], a2, a[3], a[4], a[5], a6); heff_drop(a2); heff_drop(a6); return r;
}