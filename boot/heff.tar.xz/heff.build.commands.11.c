// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Value 50841
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_build 295453320
#define LBL_command 1182252425
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_discarded 1490202606
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failure 1292767177
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_heff 9694020
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_labels 836724522
#define LBL_lib 316671
#define LBL_malg 9839318
#define LBL_mod 317820
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_property 1899481104
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_style 311138763
#define LBL_timeout 1065429926
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_ended__out__err[] = {LBL_ended, LBL_out, LBL_err};
static uint32_t shape_lib__mod__cwd__style__heff[] = {LBL_lib, LBL_mod, LBL_cwd, LBL_style, LBL_heff};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256_clo;
V g_heff_2ebuild_2ecommands_2ebuildText_get(void);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo;
V g_heff_2ebuild_2ecommands_2elastLines(V, V);
V g_heff_2ebuild_2ecommands_2elastLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elastLines_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864(V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson(V, V);
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eoutcomeOfJson_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1(V, V, V);
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeVariable_get(void);
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2eranOutcome(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eranOutcome_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranOutcome_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502(V, V, V);
V g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502_clo;
V g_heff_2ebuild_2ecommands_2etestsSaid(V);
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo;
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eproject_2ecompatible(V, V);
V g_heff_2ebuild_2eproject_2ecompatible_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ecompatible_clo;
HeffT2 g_heff_2ebuild_2eproject_2epseudoParts_24cpr(V);
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
HeffT2 g_json_2esteps_24cpr(V, V);
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
V g_list_2eany_24s336998615x1317776977(V, V, V);
V g_list_2eany_24s336998615x1317776977_entry(V self, V *a);
extern Clo g_list_2eany_24s336998615x1317776977_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f1564248594x622634626(V, V, V);
V g_list_2efoldl_24f1564248594x622634626_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1564248594x622634626_clo;
V g_list_2efoldl_24f496521120x176206934(V, V, V);
V g_list_2efoldl_24f496521120x176206934_entry(V self, V *a);
extern Clo g_list_2efoldl_24f496521120x176206934_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1063601026x1972672043(V, V);
V g_list_2ekeepIf_24s1063601026x1972672043_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1063601026x1972672043_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(V);
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_clo;
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(V);
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_clo;
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo;
V g_std_2efilesystem_2ereadOnly_24s423320184x164941529(V);
V g_std_2efilesystem_2ereadOnly_24s423320184x164941529_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadOnly_24s423320184x164941529_clo;
V g_std_2efilesystem_2eremove_24s1441356369x419789784(V);
V g_std_2efilesystem_2eremove_24s1441356369x419789784_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eremove_24s1441356369x419789784_clo;
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(V, V);
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2edirFor(V);
V g_std_2eprocess_2edirFor_entry(V self, V *a);
extern Clo g_std_2eprocess_2edirFor_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str0, 2, "0.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str1, 15, " (the same 0.x)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str3, 19, ", and this heff is ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str4, 13, " is for heff ");

HeffT2 g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(V v_who_240, V v_wanted_241, V v_running_242, V v_x4_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_who_240);
    heff_drop(v_wanted_241);
    heff_drop(v_running_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_w_245 = heff_field(v_x4_243, 0);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nothing: {
      heff_drop(v_who_240);
      heff_drop(v_wanted_241);
      heff_drop(v_running_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_r_246 = heff_field(v_x5_244, 0);
      V v_t_247 = (g_heff_2ebuild_2eproject_2ecompatible(v_w_245, v_r_246));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_who_240);
        heff_drop(v_wanted_241);
        heff_drop(v_running_242);
        heff_drop(v_t_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        heff_drop(v_t_247);
        V v_t_248;
        if (heff_strEq_c(heff_strSlice_lent(v_wanted_241, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str0))) {
          v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str1);
        } else {
          v_t_248 = ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str2);
        }
        V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str3), v_running_242));
        V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str4), heff_strAppend(v_wanted_241, v_t_249));
        V v_f_2411 = heff_strAppend(v_who_240, v_t_2410);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x5_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_243, v_seen_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_seen_240;
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_seen_240});
      V t_1 = v_rest_244;
      V t_2 = v_cell_246;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enubStrGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str2, 8, " skipped");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str5, 8, ", tests ");
Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2etestsSaid(V v_os_240) {
top: ;
  switch (heff_tag_of(v_os_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str0);
  }
  case TAG_Cons: {
    V v_t_243 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_244 = (g_list_2efoldl_24f1564248594x622634626(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_245 = (g_list_2efoldl_24f496521120x176206934(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_246 = heff_intSub(heff_intSub(v_t_243, v_t_244), v_t_245);
    V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_n_248 = (g_list_2efoldl_24f496521120x176206934(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_2410;
    if (heff_intEq_c_lent(v_n_248, MK_INT(0LL), 2)) {
      heff_drop(v_n_248);
      v_t_2410 = ((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str1);
    } else {
      V v_t_249 = heff_strAppend(heff_intShow(v_n_248), ((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str2));
      v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str3), v_t_249);
    }
    V v_t_2411 = heff_strAppend(heff_intShow(v_t_247), v_t_2410);
    V v_t_2412 = heff_strAppend(heff_intShow(v_t_246), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str4), v_t_2411));
    return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str5), v_t_2412);
  }
  default: return heff_nomatch(v_os_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2etestsSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeVariable_str0, 17, "HEFF_TEST_OUTCOME");

static V g_heff_2ebuild_2ecommands_2eoutcomeVariable_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eoutcomeVariable_st;
static V g_heff_2ebuild_2ecommands_2eoutcomeVariable_init(void) {
  return ((V)&g_heff_2ebuild_2ecommands_2eoutcomeVariable_str0);
}
V g_heff_2ebuild_2ecommands_2eoutcomeVariable_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eoutcomeVariable_st)) return g_heff_2ebuild_2ecommands_2eoutcomeVariable_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eoutcomeVariable_val, &g_heff_2ebuild_2ecommands_2eoutcomeVariable_st, g_heff_2ebuild_2ecommands_2eoutcomeVariable_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str0, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str1, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str2, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str3, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str6, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str7, 33, ", and said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str8, 3, "it ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str9, 45, "what it said of how it went could not be read");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str10, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str11, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str12, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str13, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str16, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str17, 33, ", and said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str18, 3, "it ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str19, 45, "what it said of how it went could not be read");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str20, 11, " ms: killed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str21, 33, "took longer than its time limit, ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str22, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str23, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str24, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str25, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str27, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str28, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str29, 33, ", and said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str30, 3, "it ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str31, 45, "what it said of how it went could not be read");
Clo g_heff_2ebuild_2ecommands_2eranOutcome_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranOutcome_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eranOutcome(V v_name_240, V v_limit_241, V v_r_242, V v_said_243) {
top: ;
  V v_ended_244 = heff_take_field(v_r_242, 0);
  V v_err_245 = heff_get_n(v_r_242, 2, 3);
  switch (heff_tag_of(v_ended_244)) {
  case TAG_Exited: {
    heff_drop(v_limit_241);
    switch (heff_tag_of(v_said_243)) {
    case TAG_Nothing: {
      V v_t_249;
      switch (heff_tag_of(v_ended_244)) {
      case TAG_Exited: {
        V v_n_247 = heff_field(v_ended_244, 0);
        heff_take_n(v_ended_244, 1ULL, 1);
        v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str0), heff_intShow(v_n_247));
        break;
      }
      case TAG_Signalled: {
        V v_n_248 = heff_field(v_ended_244, 0);
        heff_take_n(v_ended_244, 1ULL, 1);
        v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str1), heff_intShow(v_n_248));
        break;
      }
      case TAG_TimedOut: {
        v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str2);
        break;
      }
      case TAG_NotRun: {
        v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str3);
        break;
      }
      default: heff_nomatch(v_ended_244);
      }
      V v_t_2411;
      if (heff_strEq_c_lent(v_err_245, ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str4), 2)) {
        heff_drop(v_err_245);
        v_t_2411 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str5);
      } else {
        V v_t_2410 = ({ V a_0 = MK_INT(20LL); V a_1 = v_err_245; V r_ = (g_heff_2ebuild_2ecommands_2elastLines(a_0, a_1)); heff_drop(v_err_245); r_; });
        v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str6), v_t_2410);
      }
      V v_t_2412 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str7), v_t_2411));
      V v_why_2413 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str8), v_t_2412);
      V v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2413})});
      return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2414, MK_INT(0LL), NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_text_2415 = heff_field(v_said_243, 0);
      V v_ru_24said_243_24Just = heff_take_reuse_n(v_said_243, 1ULL, 1);
      heff_drop_tag(v_ended_244, 1);
      heff_drop(v_err_245);
      V v_t_2416 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2417 = ({ V a_0 = v_text_2415; V a_1 = v_t_2416; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_text_2415); r_; });
      {
        V v_field_2419 = v_t_2417.f[1];
        int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
        if ((v_tag_2418 == ((int64_t)0ULL))) {
          V v_why_2420 = v_field_2419;
          heff_drop(v_why_2420);
          V v_t_2421 = heff_tag_at_n(v_ru_24said_243_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str9)})});
          return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2421, MK_INT(0LL), NTAG(TAG_Nil)});
        } else {
          V v_j_2422 = v_field_2419;
          return (g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1(v_ru_24said_243_24Just, v_name_240, v_j_2422));
        }
      }
    }
    default: return heff_nomatch(v_said_243);
    }
  }
  case TAG_Signalled: {
    heff_drop(v_limit_241);
    switch (heff_tag_of(v_said_243)) {
    case TAG_Nothing: {
      V v_t_2426;
      switch (heff_tag_of(v_ended_244)) {
      case TAG_Exited: {
        V v_n_2424 = heff_field(v_ended_244, 0);
        heff_take_n(v_ended_244, 1ULL, 1);
        v_t_2426 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str10), heff_intShow(v_n_2424));
        break;
      }
      case TAG_Signalled: {
        V v_n_2425 = heff_field(v_ended_244, 0);
        heff_take_n(v_ended_244, 1ULL, 1);
        v_t_2426 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str11), heff_intShow(v_n_2425));
        break;
      }
      case TAG_TimedOut: {
        v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str12);
        break;
      }
      case TAG_NotRun: {
        v_t_2426 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str13);
        break;
      }
      default: heff_nomatch(v_ended_244);
      }
      V v_t_2428;
      if (heff_strEq_c_lent(v_err_245, ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str14), 2)) {
        heff_drop(v_err_245);
        v_t_2428 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str15);
      } else {
        V v_t_2427 = ({ V a_0 = MK_INT(20LL); V a_1 = v_err_245; V r_ = (g_heff_2ebuild_2ecommands_2elastLines(a_0, a_1)); heff_drop(v_err_245); r_; });
        v_t_2428 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str16), v_t_2427);
      }
      V v_t_2429 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str17), v_t_2428));
      V v_why_2430 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str18), v_t_2429);
      V v_t_2431 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2430})});
      return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2431, MK_INT(0LL), NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_text_2432 = heff_field(v_said_243, 0);
      V v_ru_24said_243_24Just = heff_take_reuse_n(v_said_243, 1ULL, 1);
      heff_drop_tag(v_ended_244, 1);
      heff_drop(v_err_245);
      V v_t_2433 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2434 = ({ V a_0 = v_text_2432; V a_1 = v_t_2433; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_text_2432); r_; });
      {
        V v_field_2436 = v_t_2434.f[1];
        int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
        if ((v_tag_2435 == ((int64_t)0ULL))) {
          V v_why_2437 = v_field_2436;
          heff_drop(v_why_2437);
          V v_t_2438 = heff_tag_at_n(v_ru_24said_243_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str19)})});
          return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2438, MK_INT(0LL), NTAG(TAG_Nil)});
        } else {
          V v_j_2439 = v_field_2436;
          return (g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1(v_ru_24said_243_24Just, v_name_240, v_j_2439));
        }
      }
    }
    default: return heff_nomatch(v_said_243);
    }
  }
  case TAG_TimedOut: {
    heff_drop(v_said_243);
    heff_drop(v_err_245);
    V v_t_2440 = heff_strAppend(heff_intShow(v_limit_241), ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str20));
    V v_t_2441 = heff_tag_n(TAG_FailBecause, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str21), v_t_2440)});
    return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_tag_n(TAG_Just, 1, (V[]){v_t_2441}), MK_INT(0LL), NTAG(TAG_Nil)});
  }
  case TAG_NotRun: {
    heff_drop(v_limit_241);
    switch (heff_tag_of(v_said_243)) {
    case TAG_Nothing: {
      V v_t_2444;
      switch (heff_tag_of(v_ended_244)) {
      case TAG_Exited: {
        V v_n_2442 = heff_field(v_ended_244, 0);
        heff_take_n(v_ended_244, 1ULL, 1);
        v_t_2444 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str22), heff_intShow(v_n_2442));
        break;
      }
      case TAG_Signalled: {
        V v_n_2443 = heff_field(v_ended_244, 0);
        heff_take_n(v_ended_244, 1ULL, 1);
        v_t_2444 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str23), heff_intShow(v_n_2443));
        break;
      }
      case TAG_TimedOut: {
        v_t_2444 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str24);
        break;
      }
      case TAG_NotRun: {
        v_t_2444 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str25);
        break;
      }
      default: heff_nomatch(v_ended_244);
      }
      V v_t_2446;
      if (heff_strEq_c_lent(v_err_245, ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str26), 2)) {
        heff_drop(v_err_245);
        v_t_2446 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str27);
      } else {
        V v_t_2445 = ({ V a_0 = MK_INT(20LL); V a_1 = v_err_245; V r_ = (g_heff_2ebuild_2ecommands_2elastLines(a_0, a_1)); heff_drop(v_err_245); r_; });
        v_t_2446 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str28), v_t_2445);
      }
      V v_t_2447 = heff_strAppend(v_t_2444, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str29), v_t_2446));
      V v_why_2448 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str30), v_t_2447);
      V v_t_2449 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2448})});
      return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2449, MK_INT(0LL), NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_text_2450 = heff_field(v_said_243, 0);
      V v_ru_24said_243_24Just = heff_take_reuse_n(v_said_243, 1ULL, 1);
      heff_drop(v_err_245);
      V v_t_2451 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2452 = ({ V a_0 = v_text_2450; V a_1 = v_t_2451; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_text_2450); r_; });
      {
        V v_field_2454 = v_t_2452.f[1];
        int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
        if ((v_tag_2453 == ((int64_t)0ULL))) {
          V v_why_2455 = v_field_2454;
          heff_drop(v_why_2455);
          V v_t_2456 = heff_tag_at_n(v_ru_24said_243_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str31)})});
          return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2456, MK_INT(0LL), NTAG(TAG_Nil)});
        } else {
          V v_j_2457 = v_field_2454;
          return (g_heff_2ebuild_2ecommands_2eoutcomeOfJson_24tok1(v_ru_24said_243_24Just, v_name_240, v_j_2457));
        }
      }
    }
    default: return heff_nomatch(v_said_243);
    }
  }
  default: return heff_nomatch(v_ended_244);
  }
}
V g_heff_2ebuild_2ecommands_2eranOutcome_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eranOutcome(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str1, 13, "build : Build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str2, 37, "build = { backend = C, run = \"main\" }");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str3, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str5, 21, "-- heff home with it.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str7, 69, "-- page's script of it.  A field `ships = [...]` would name files and");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str8, 69, "-- directories of the project's root for `heff install` to put in the");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str10, 69, "-- main.hf's `main`, compiled through C (by `zig cc`); `Page` makes a");

static V g_heff_2ebuild_2ecommands_2ebuildText_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2ebuildText_st;
static V g_heff_2ebuild_2ecommands_2ebuildText_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2ebuildText_str9); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2ebuildText_str10); V a_2 = v_t_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildText_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2ebuildText_st)) return g_heff_2ebuild_2ecommands_2ebuildText_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2ebuildText_val, &g_heff_2ebuild_2ecommands_2ebuildText_st, g_heff_2ebuild_2ecommands_2ebuildText_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str1, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str2, 6, "source");
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam7, 3, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam9, 3, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2elibDir_24s1472330149x114881384(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam3(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2426 = args[1];
  V v_k_2427 = args[2];
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam9(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_2437 = args[1];
  V v_k_2438 = args[2];
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam10(V self, V *args) {
  V v_x_2440 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_244 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2441 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2415, v_x_2416));
  V v_t_2444;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    heff_take_n(v_x_2429, 0ULL, 1);
    v_t_2444 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2443 = heff_field(v_x_2429, 0);
    V v_ru_24x_2429_24Right = heff_take_reuse_n(v_x_2429, 1ULL, 1);
    v_t_2444 = heff_tag_at_n(v_ru_24x_2429_24Right, TAG_Just, 1, (V[]){v_y_2443});
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  V v_t_2445 = ({ V a_0 = v_t_2444; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_t_2444); r_; });
  V v_t_2448;
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Left: {
    heff_take_n(v_x_2440, 0ULL, 1);
    v_t_2448 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2447 = heff_field(v_x_2440, 0);
    V v_ru_24x_2440_24Right = heff_take_reuse_n(v_x_2440, 1ULL, 1);
    v_t_2448 = heff_tag_at_n(v_ru_24x_2440_24Right, TAG_Just, 1, (V[]){v_y_2447});
    break;
  }
  default: heff_nomatch(v_x_2440);
  }
  V v_t_2449 = ({ V a_0 = v_t_2448; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_t_2448); r_; });
  V v_t_2450 = (g_prelude_2e_2b_2b(v_t_2445, v_t_2449));
  V v_x_2451 = heff_rec_n(5, shape_lib__mod__cwd__style__heff, (V[]){v_x_242, v_x_243, v_x_244, v_st_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, v_t_2450})});
  V f_ = v_k_241;
  args[0] = v_x_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam8(V self, V *args) {
  V v_x_2429 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_x_243 = heff_env(self)[5];
  V v_x_244 = heff_env(self)[6];
  V v_k_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2430 = (g_std_2epath_2eparse(v_st_2415, v_x_2417));
  V v_t_2431 = (g_std_2epath_2eparse(v_st_2415, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str2)));
  V v_t_2432 = (g_std_2epath_2ejoin(v_t_2430, v_t_2431));
  V v_s_2433 = ({ V a_0 = v_st_2415; V a_1 = v_t_2432; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2432); r_; });
  V v_path_2434 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2433; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2435 = ({ V a_0 = v_path_2434; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2434); r_; });
  V v_c_2439 = heff_tr(heff_call(v_c_2435, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam9_clo)}));
  V f_ = v_c_2439;
  heff_room[0] = v_hd_240;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam10, 1, 7, (V[]){v_st_2415, v_x_2416, v_x_2429, v_x_242, v_x_243, v_x_244, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam6(V self, V *args) {
  V v_x_2417 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_244 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_home_2418 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2415, heff_dup(v_x_2416)));
  V v_t_2419 = (g_std_2epath_2eparse(v_st_2415, v_home_2418));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_2415, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str1)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2415; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_path_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2422; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2424 = ({ V a_0 = v_path_2423; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2423); r_; });
  V v_c_2428 = heff_tr(heff_call(v_c_2424, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam7_clo)}));
  V f_ = v_c_2428;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam8, 1, 8, (V[]){v_st_2415, v_x_2417, v_hd_240, v_x_2416, v_x_242, v_x_243, v_x_244, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_st_2415 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_k_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam6, 1, 7, (V[]){v_st_2415, v_x_2416, v_hd_240, v_x_242, v_x_243, v_x_244, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2415;
  if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_str0))) {
    v_st_2415 = NTAG(TAG_Windows);
  } else {
    v_st_2415 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam5, 1, 6, (V[]){v_hd_240, v_st_2415, v_x_242, v_x_243, v_x_244, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam3_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam4, 1, 5, (V[]){v_hd_240, v_x_242, v_x_243, v_x_244, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam2, 1, 4, (V[]){v_hd_240, v_x_242, v_x_243, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_lam1, 1, 3, (V[]){v_hd_240, v_x_242, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str2, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str3, 3, "-O0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str4, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str5, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str6, 11, "ReleaseSafe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str7, 3, "-Os");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str8, 12, "ReleaseSmall");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str9, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str10, 3, "-O3");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str11, 11, "ReleaseFast");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str12, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str15, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str16, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str17, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str18, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str19, 3, "zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str20, 27, ": `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str21, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str22, 27, ": `zig cc` could not build ");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam9, 2, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535(V v_prog_240, V v_failed_241, V v_who_242, V v_st_243, V v_flags_244, V v_p_245, V v_dir_246, V v_out_247, V v_next_248) {
top: ;
  V v_path_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_dir_246); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2410 = (g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(v_path_249));
  V v_c_2415 = heff_tr(heff_call(v_c_2410, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam2, 2, 10, (V[]){v_c_2415, heff_dup(v_st_243), v_dir_246, v_prog_240, v_p_245, v_flags_244, v_out_247, v_next_248, v_who_242, v_failed_241});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2412 = (g_list_2emap_24s219049803x1458391381(v_x_2411));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam1, 2, 1, (V[]){v_x_2412});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam4(V self, V *args) {
  V v_n_2425 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = (g_std_2epath_2eparse(v_st_243, v_dir_246));
  V v_t_2427 = (g_std_2epath_2eparse(v_st_243, v_n_2425));
  V v_t_2428 = (g_std_2epath_2ejoin(v_t_2426, v_t_2427));
  return ({ V a_0 = v_st_243; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_2428); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam5(V self, V *args) {
  V v_n_2433 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = (g_std_2epath_2eparse(v_st_243, v_dir_246));
  V v_t_2435 = (g_std_2epath_2eparse(v_st_243, v_n_2433));
  V v_t_2436 = (g_std_2epath_2ejoin(v_t_2434, v_t_2435));
  return ({ V a_0 = v_st_243; V a_1 = v_t_2436; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_2436); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam6(V self, V *args) {
  V v_t_2441 = args[0];
  return v_t_2441;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam9(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  heff_drop(v_hd_2451);
  V v_t_2453 = heff_rec_n(3, shape_ended__out__err, (V[]){NTAG(TAG_NotRun), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str13), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str14)});
  V f_ = v_k_2452;
  args[0] = v_t_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam10(V self, V *args) {
  V v_r_2461 = args[0];
  return v_r_2461;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam14(V self, V *args) {
  V v_x_2491 = args[0];
  V v_who_242 = heff_env(self)[0];
  V v_out_247 = heff_env(self)[1];
  V v_failed_241 = heff_env(self)[2];
  V v_hd_2416 = heff_env(self)[3];
  V v_k_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2491);
  V v_t_2492 = heff_strAppend(v_who_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str22), v_out_247));
  V f_ = v_failed_241;
  heff_room[0] = v_t_2492;
  heff_room[1] = v_hd_2416;
  heff_room[2] = v_k_2417;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam13(V self, V *args) {
  V v_x_2481 = args[0];
  V v_who_242 = heff_env(self)[0];
  V v_out_247 = heff_env(self)[1];
  V v_hd_2416 = heff_env(self)[2];
  V v_failed_241 = heff_env(self)[3];
  V v_k_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2481);
  V v_t_2482 = heff_strAppend(heff_dup(v_who_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str20), heff_dup(v_out_247)));
  V v_t_2483 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2482, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str21)), NTAG(TAG_MkUnit)});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2416, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2489})}));
  V f_ = heff_dup(heff_rfield(v_hd_2416, 1));
  heff_room[0] = v_t_2490;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam14, 1, 5, (V[]){v_who_242, v_out_247, v_failed_241, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam12(V self, V *args) {
  V v_x_2469 = args[0];
  V v_ended_2465 = heff_env(self)[0];
  V v_next_248 = heff_env(self)[1];
  V v_hd_2416 = heff_env(self)[2];
  V v_k_2417 = heff_env(self)[3];
  V v_err_2466 = heff_env(self)[4];
  V v_who_242 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_failed_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2469);
  V v_t_2472;
  switch (heff_tag_of(v_ended_2465)) {
  case TAG_Exited: {
    V v_n_2470 = heff_field(v_ended_2465, 0);
    heff_take_n(v_ended_2465, 1ULL, 1);
    v_t_2472 = heff_bool(heff_intEq_c_lent(v_n_2470, MK_INT(0LL), 2));
    heff_drop(v_n_2470);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2465, 0ULL, 1);
    v_t_2472 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2472 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2472 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_ended_2465);
  }
  if ((heff_dup(v_t_2472) == NTAG(TAG_True))) {
    heff_drop(v_err_2466);
    heff_drop(v_who_242);
    heff_drop(v_out_247);
    heff_drop(v_failed_241);
    heff_drop(v_t_2472);
    V f_ = v_next_248;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_next_248);
    heff_drop(v_t_2472);
    V v_t_2473 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_err_2466, NTAG(TAG_MkUnit)});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2416, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})}));
    V f_ = heff_dup(heff_rfield(v_hd_2416, 1));
    heff_room[0] = v_t_2480;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam13, 1, 5, (V[]){v_who_242, v_out_247, v_hd_2416, v_failed_241, v_k_2417});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam11(V self, V *args) {
  V v_x_2464 = args[0];
  V v_x_2443 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_2416 = heff_env(self)[2];
  V v_next_248 = heff_env(self)[3];
  V v_k_2417 = heff_env(self)[4];
  V v_who_242 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_failed_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_ended_2465 = heff_take_field(v_x_2464, 0);
  V v_err_2466 = heff_get_n(v_x_2464, 2, 3);
  V v_t_2467 = heff_tag_n(TAG_End, 2, (V[]){v_x_2443, NTAG(TAG_MkUnit)});
  V v_t_2468 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2467}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2468, heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam12, 1, 8, (V[]){v_ended_2465, v_next_248, v_hd_2416, v_k_2417, v_err_2466, v_who_242, v_out_247, v_failed_241})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam8(V self, V *args) {
  V v_x_2450 = args[0];
  V v_out_247 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_flags_244 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_x_2443 = heff_env(self)[4];
  V v_hd_2416 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2417 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_failed_241 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2463;
  switch (heff_tag_of(v_x_2450)) {
  case TAG_Nothing: {
    heff_drop(v_x_2429);
    heff_drop(v_flags_244);
    v_c_2463 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam9_clo);
    break;
  }
  case TAG_Just: {
    V v_os_2454 = heff_field(v_x_2450, 0);
    heff_take_n(v_x_2450, 1ULL, 1);
    V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str15), NTAG(TAG_Nil)});
    V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str16), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_out_247), v_t_2455})});
    V v_t_2457 = (g_prelude_2e_2b_2b(v_os_2454, v_t_2456));
    V v_t_2458 = (g_prelude_2e_2b_2b(v_x_2429, v_t_2457));
    V v_t_2459 = (g_prelude_2e_2b_2b(v_flags_244, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str17), v_t_2458})));
    V v_argv_2460 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str18), v_t_2459});
    V v_t_2462 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_2443), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str19), v_argv_2460, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam10_clo)})}));
    v_c_2463 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2462}));
    break;
  }
  default: heff_nomatch(v_x_2450);
  }
  V f_ = v_c_2463;
  heff_room[0] = heff_dup(v_hd_2416);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam11, 1, 8, (V[]){v_x_2443, v_prog_240, v_hd_2416, v_next_248, v_k_2417, v_who_242, v_out_247, v_failed_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_flags_244 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_x_2437 = heff_env(self)[2];
  V v_hd_2416 = heff_env(self)[3];
  V v_out_247 = heff_env(self)[4];
  V v_x_2429 = heff_env(self)[5];
  V v_next_248 = heff_env(self)[6];
  V v_k_2417 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_failed_241 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2444 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str3); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s1477604419x1568736711(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2448;
  if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
    heff_drop(v_t_2444);
    v_t_2448 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str4);
  } else {
    heff_drop(v_t_2444);
    V v_t_2445 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str5); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s1477604419x1568736711(b_0, a_1)); heff_drop(b_0); r_; });
    if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
      heff_drop(v_t_2445);
      v_t_2448 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str6);
    } else {
      heff_drop(v_t_2445);
      V v_t_2446 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str7); V a_1 = v_flags_244; V r_ = (g_list_2eany_24s1477604419x1568736711(b_0, a_1)); heff_drop(b_0); r_; });
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_t_2446);
        v_t_2448 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str8);
      } else {
        heff_drop(v_t_2446);
        V v_t_2447 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str9); V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str10); V a_2 = v_flags_244; V r_ = (g_list_2eany_24s336998615x1317776977(b_0, b_1, a_2)); heff_drop(b_0); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
          heff_drop(v_t_2447);
          v_t_2448 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str11);
        } else {
          heff_drop(v_t_2447);
          v_t_2448 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str12);
        }
      }
    }
  }
  V v_c_2449 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s1673197723x746847571(heff_dup(v_prog_240), heff_dup(v_x_2443), v_t_2448, v_x_2437, NTAG(TAG_Nil)));
  V f_ = v_c_2449;
  heff_room[0] = heff_dup(v_hd_2416);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam8, 1, 10, (V[]){v_out_247, v_x_2429, v_flags_244, v_prog_240, v_x_2443, v_hd_2416, v_next_248, v_k_2417, v_who_242, v_failed_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  V v_hd_2416 = heff_env(self)[4];
  V v_flags_244 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_k_2417 = heff_env(self)[8];
  V v_who_242 = heff_env(self)[9];
  V v_failed_241 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_x_2421;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    heff_take_n(v_x_2418, 0ULL, 1);
    v_x_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2420 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    v_x_2421 = heff_tag_at_n(v_ru_24x_2418_24Right, TAG_Just, 1, (V[]){v_y_2420});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V v_t_2423;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    v_t_2423 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2422 = heff_dup(heff_field(v_x_2421, 0));
    v_t_2423 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V v_t_2424 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str0); V a_1 = v_t_2423; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2429 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam4, 1, 2, (V[]){heff_dup(v_st_243), heff_dup(v_dir_246)}), v_t_2424));
  V v_t_2431;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    v_t_2431 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2430 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    v_t_2431 = v_x_2430;
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V v_t_2432 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str1); V a_1 = v_t_2431; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2437 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam5, 1, 2, (V[]){v_st_243, v_dir_246}), v_t_2432));
  V v_t_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2429));
  V v_t_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2437));
  V v_total_2440 = heff_intAdd(heff_intAdd(v_t_2438, v_t_2439), MK_INT(1LL));
  V v_t_2442 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_245, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_str2), v_total_2440, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam6_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2442, heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam7, 1, 10, (V[]){v_flags_244, v_prog_240, v_x_2437, v_hd_2416, v_out_247, v_x_2429, v_next_248, v_k_2417, v_who_242, v_failed_241})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_st_243 = heff_env(self)[1];
  V v_dir_246 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_p_245 = heff_env(self)[4];
  V v_flags_244 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_failed_241 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_lam3, 1, 11, (V[]){v_st_243, v_dir_246, v_prog_240, v_p_245, v_hd_2416, v_flags_244, v_out_247, v_next_248, v_k_2417, v_who_242, v_failed_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str2, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str4, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam2, 3, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam4, 3, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop_rec(v_p_242, 3);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_242, 2)), 1, (V[]){v_t_2415}));
      return heff_tail(heff_dup(heff_rfield(v_p_242, 1)), 2, (V[]){v_t_2416, heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam1, 1, 6, (V[]){v_dir_240, v_f_246, v_p_242, v_text_247, v_rest_245, v_p_243})});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam2(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_2438 = args[1];
  V v_k_2439 = args[2];
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam4(V self, V *args) {
  V v_x_2459 = args[0];
  V v_hd_2460 = args[1];
  V v_k_2461 = args[2];
  heff_drop(v_hd_2460);
  V f_ = v_k_2461;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2459});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam6(V self, V *args) {
  V v_x_2478 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2478);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam7(V self, V *args) {
  V v_x_2493 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2493);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam5(V self, V *args) {
  V v_x_2463 = args[0];
  V v_x_2444 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_st_2418 = heff_env(self)[5];
  V v_f_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2463)) {
  case TAG_Left: {
    V v_ru_24x_2463_24Left = heff_take_reuse_n(v_x_2463, 0ULL, 1);
    if (((heff_dup(v_x_2444) == NTAG(TAG_True)) && 0)) {
      heff_drop(v_x_2444);
      heff_drop(v_st_2418);
      heff_drop(v_f_246);
      heff_drop_cell(v_ru_24x_2463_24Left, 1);
      return (g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641(v_dir_240, v_rest_245, v_p_242, v_p_243));
    } else {
      heff_drop(v_x_2444);
      heff_drop(v_rest_245);
      V v_t_2465 = (g_std_2epath_2eparse(v_st_2418, v_dir_240));
      V v_t_2466 = (g_std_2epath_2eparse(v_st_2418, v_f_246));
      V v_t_2467 = (g_std_2epath_2ejoin(v_t_2465, v_t_2466));
      V v_t_2468 = ({ V a_0 = v_st_2418; V a_1 = v_t_2467; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2467); r_; });
      V v_str_2469 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str2), v_t_2468);
      V v_t_2470 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2469, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str3)), NTAG(TAG_MkUnit)});
      V v_t_2471 = heff_tag_at_n(v_ru_24x_2463_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
      V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
      V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
      V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
      V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
      V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
      V v_t_2477 = heff_tr(heff_call(heff_take_field(v_p_242, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})}));
      V f_ = heff_get_n(v_p_242, 1, 3);
      heff_room[0] = v_t_2477;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam6, 1, 1, (V[]){v_p_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Right: {
    V v_ru_24x_2463_24Right = heff_take_reuse_n(v_x_2463, 0ULL, 1);
    if ((heff_dup(v_x_2444) == NTAG(TAG_True))) {
      heff_drop(v_x_2444);
      heff_drop(v_st_2418);
      heff_drop(v_f_246);
      heff_drop_cell(v_ru_24x_2463_24Right, 1);
      return (g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641(v_dir_240, v_rest_245, v_p_242, v_p_243));
    } else {
      heff_drop(v_x_2444);
      heff_drop(v_rest_245);
      V v_t_2480 = (g_std_2epath_2eparse(v_st_2418, v_dir_240));
      V v_t_2481 = (g_std_2epath_2eparse(v_st_2418, v_f_246));
      V v_t_2482 = (g_std_2epath_2ejoin(v_t_2480, v_t_2481));
      V v_t_2483 = ({ V a_0 = v_st_2418; V a_1 = v_t_2482; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2482); r_; });
      V v_str_2484 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str4), v_t_2483);
      V v_t_2485 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2484, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str5)), NTAG(TAG_MkUnit)});
      V v_t_2486 = heff_tag_at_n(v_ru_24x_2463_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
      V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
      V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
      V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
      V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
      V v_t_2491 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})});
      V v_t_2492 = heff_tr(heff_call(heff_take_field(v_p_242, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})}));
      V f_ = heff_get_n(v_p_242, 1, 3);
      heff_room[0] = v_t_2492;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam7, 1, 1, (V[]){v_p_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_x_2463);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam3(V self, V *args) {
  V v_x_2441 = args[0];
  V v_st_2418 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x_2444;
  switch (heff_tag_of(v_x_2441)) {
  case TAG_Left: {
    heff_take_n(v_x_2441, 0ULL, 1);
    v_x_2444 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2441, 0ULL, 1);
    v_x_2444 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2441);
  }
  V v_t_2445 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_dir_240)));
  V v_t_2446 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_f_246)));
  V v_t_2447 = (g_std_2epath_2ejoin(v_t_2445, v_t_2446));
  V v_s_2448 = ({ V a_0 = v_st_2418; V a_1 = v_t_2447; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2447); r_; });
  V v_path_2449 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2448; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  int64_t v_t_2450 = (heff_unbox_word(heff_strLength_lent(v_f_246, 0)) - ((int64_t)3ULL));
  V v_t_2451 = heff_strSlice(heff_dup(v_f_246), heff_box_word(v_t_2450), heff_strLength_lent(v_f_246, 0));
  V v_text_2457;
  if (heff_strEq_c(v_t_2451, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str1))) {
    HeffT2 v_t_2452 = (g_heff_2esyntax_2eformat_2eformat_24cpr(heff_dup(v_text_247)));
    {
      V v_field_2454 = v_t_2452.f[1];
      int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
      if ((v_tag_2453 == ((int64_t)0ULL))) {
        V v_x_2455 = v_field_2454;
        heff_drop(v_x_2455);
        v_text_2457 = v_text_247;
      } else {
        heff_drop(v_text_247);
        V v_out_2456 = v_field_2454;
        v_text_2457 = v_out_2456;
      }
    }
  } else {
    v_text_2457 = v_text_247;
  }
  V v_c_2458 = ({ V a_0 = v_path_2449; V a_1 = v_text_2457; V r_ = (g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(a_0, a_1)); heff_drop(v_path_2449); r_; });
  V v_c_2462 = heff_tr(heff_call(v_c_2458, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam4_clo)}));
  V f_ = v_c_2462;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam5, 1, 7, (V[]){v_x_2444, v_dir_240, v_rest_245, v_p_242, v_p_243, v_st_2418, v_f_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2418;
  if (heff_strEq_c(v_x_2417, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_t_2419 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_dir_240)));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_f_246)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  HeffT3 v_t_2423 = (g_std_2epath_2eparse_24cpr(v_st_2418, v_s_2422));
  V v_t_2433;
  {
    V v_field_2424 = v_t_2423.f[0];
    V v_field_2425 = v_t_2423.f[1];
    V v_field_2426 = v_t_2423.f[2];
    V v_d_2427 = v_field_2424;
    V v_a_2428 = v_field_2425;
    V v_xs_2429 = v_field_2426;
    V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2429));
    V v_xs_2431 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2430; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2430); r_; });
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
    v_t_2433 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2427, v_a_2428, v_t_2432});
  }
  V v_s_2434 = ({ V a_0 = v_st_2418; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2433); r_; });
  V v_path_2435 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2434; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2436 = ({ V a_0 = v_path_2435; V r_ = (g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(a_0)); heff_drop(v_path_2435); r_; });
  V v_c_2440 = heff_tr(heff_call(v_c_2436, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam2_clo)}));
  V f_ = v_c_2440;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_lam3, 1, 7, (V[]){v_st_2418, v_dir_240, v_f_246, v_text_247, v_p_242, v_rest_245, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str0, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str2, 9, "fetching ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str3, 1, "-");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str4, 1, "-");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str5, 11, "HEAD^{tree}");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str6, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str7, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str8, 4, ".git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str9, 5, "tree:");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str10, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str12, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str13, 18, "heff get: fetched ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str15, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str16, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str17, 12, "cannot keep ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str18, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str19, 18, "heff get: fetched ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str20, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str21, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str22, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str23, 12, "cannot keep ");
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam5, 3, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam11, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam13, 3, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam15(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam15, 3, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam17(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam17, 3, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam20(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam21(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam21, 3, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam22(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382(V v_prog_240, V v_ps_241, V v_path_242, V v_v_243) {
top: ;
  V v_x_244 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_242), heff_dup(v_v_243)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam0, 2, 5, (V[]){v_x_244, v_ps_241, v_path_242, v_v_243, v_prog_240});
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_2410 = args[1];
  V v_k_2411 = args[2];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_2418 = args[1];
  V v_k_2419 = args[2];
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_2438 = args[1];
  V v_k_2439 = args[2];
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam7(V self, V *args) {
  V v_t_2443 = args[0];
  return v_t_2443;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam11(V self, V *args) {
  V v_r_2463 = args[0];
  return v_r_2463;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam13(V self, V *args) {
  V v_x_2482 = args[0];
  V v_hd_2483 = args[1];
  V v_k_2484 = args[2];
  heff_drop(v_hd_2483);
  V f_ = v_k_2484;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2482});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam15(V self, V *args) {
  V v_x_2489 = args[0];
  V v_hd_2490 = args[1];
  V v_k_2491 = args[2];
  heff_drop(v_hd_2490);
  V f_ = v_k_2491;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2489});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam17(V self, V *args) {
  V v_x_24105 = args[0];
  V v_hd_24106 = args[1];
  V v_k_24107 = args[2];
  heff_drop(v_hd_24106);
  V f_ = v_k_24107;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24105});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam19(V self, V *args) {
  V v_x_24124 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_24102 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24124);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24102});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam20(V self, V *args) {
  V v_x_24142 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_24102 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24142);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24102});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam18(V self, V *args) {
  V v_x_24109 = args[0];
  V v_ended_2474 = heff_env(self)[0];
  V v_x_2496 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_v_243 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  V v_x_24102 = heff_env(self)[6];
  V v_x_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_24109)) {
  case TAG_Left: {
    V v_ru_24x_24109_24Left = heff_take_reuse_n(v_x_24109, 0ULL, 1);
    V v_t_24113;
    switch (heff_tag_of(v_ended_2474)) {
    case TAG_Exited: {
      V v_n_24111 = heff_field(v_ended_2474, 0);
      heff_take_n(v_ended_2474, 1ULL, 1);
      v_t_24113 = heff_bool(heff_intEq_c_lent(v_n_24111, MK_INT(0LL), 2));
      heff_drop(v_n_24111);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_ended_2474, 0ULL, 1);
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_TimedOut: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_NotRun: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_ended_2474);
    }
    if (((heff_dup(v_t_24113) == NTAG(TAG_True)) && ((heff_dup(v_x_2496) == NTAG(TAG_True)) && 0))) {
      heff_drop(v_x_2496);
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x_24109_24Left, 1);
      heff_drop(v_t_24113);
      V v_t_24114 = heff_strAppend(v_path_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str12), v_v_243));
      V v_t_24115 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str13), v_t_24114), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str14));
      V v_t_24116 = heff_tag_n(TAG_Write, 2, (V[]){v_t_24115, NTAG(TAG_MkUnit)});
      V v_t_24117 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
      V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
      V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
      V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
      V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
      V v_t_24122 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24121})});
      V v_t_24123 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24122})}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_24123;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam19, 1, 2, (V[]){v_k_246, v_x_24102});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x_2496);
      heff_drop_rec(v_hd_245, 3);
      heff_drop(v_x_24102);
      heff_drop(v_t_24113);
      V v_t_24125 = heff_strAppend(v_v_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str15), v_x_244));
      V v_t_24126 = heff_strAppend(v_path_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str16), v_t_24125));
      V v_t_24127 = heff_tag_at_n(v_ru_24x_24109_24Left, TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str17), v_t_24126)});
      V f_ = v_k_246;
      args[0] = v_t_24127;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  case TAG_Right: {
    V v_ru_24x_24109_24Right = heff_take_reuse_n(v_x_24109, 0ULL, 1);
    V v_t_24131;
    switch (heff_tag_of(v_ended_2474)) {
    case TAG_Exited: {
      V v_n_24129 = heff_field(v_ended_2474, 0);
      heff_take_n(v_ended_2474, 1ULL, 1);
      v_t_24131 = heff_bool(heff_intEq_c_lent(v_n_24129, MK_INT(0LL), 2));
      heff_drop(v_n_24129);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_ended_2474, 0ULL, 1);
      v_t_24131 = NTAG(TAG_False);
      break;
    }
    case TAG_TimedOut: {
      v_t_24131 = NTAG(TAG_False);
      break;
    }
    case TAG_NotRun: {
      v_t_24131 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_ended_2474);
    }
    if (((heff_dup(v_t_24131) == NTAG(TAG_True)) && (heff_dup(v_x_2496) == NTAG(TAG_True)))) {
      heff_drop(v_x_2496);
      heff_drop(v_x_244);
      heff_drop(v_t_24131);
      V v_t_24132 = heff_strAppend(v_path_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str18), v_v_243));
      V v_t_24133 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str19), v_t_24132), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str20));
      V v_t_24134 = heff_tag_n(TAG_Write, 2, (V[]){v_t_24133, NTAG(TAG_MkUnit)});
      V v_t_24135 = heff_tag_at_n(v_ru_24x_24109_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
      V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
      V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
      V v_t_24138 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24137})});
      V v_t_24139 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24138})});
      V v_t_24140 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24139})});
      V v_t_24141 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24140})}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_24141;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam20, 1, 2, (V[]){v_k_246, v_x_24102});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x_2496);
      heff_drop_rec(v_hd_245, 3);
      heff_drop(v_x_24102);
      heff_drop(v_t_24131);
      V v_t_24143 = heff_strAppend(v_v_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str21), v_x_244));
      V v_t_24144 = heff_strAppend(v_path_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str22), v_t_24143));
      V v_t_24145 = heff_tag_at_n(v_ru_24x_24109_24Right, TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str23), v_t_24144)});
      V f_ = v_k_246;
      args[0] = v_t_24145;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  default: return heff_nomatch(v_x_24109);
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam16(V self, V *args) {
  V v_x_2493 = args[0];
  V v_out_2473 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_ended_2474 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_v_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x_2496;
  switch (heff_tag_of(v_x_2493)) {
  case TAG_Left: {
    heff_take_n(v_x_2493, 0ULL, 1);
    v_x_2496 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2493, 0ULL, 1);
    v_x_2496 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2493);
  }
  V v_s_2497 = v_out_2473;
  V v_t_2498 = (g_prelude_2eskipSpaces(v_s_2497, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_2499 = (heff_unbox_word(heff_strLength_lent(v_s_2497, 0)) - ((int64_t)1ULL));
  V v_t_24100 = (g_prelude_2eskipSpaces(v_s_2497, heff_box_word(v_t_2499), MK_INT(-1LL)));
  V v_t_24101 = heff_strSlice(v_s_2497, v_t_2498, heff_intAdd(v_t_24100, MK_INT(1LL)));
  V v_x_24102 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str9), v_t_24101);
  V v_path_24103 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_strAppend(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str10)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_24104 = ({ V a_0 = v_path_24103; V a_1 = heff_strAppend(heff_dup(v_x_24102), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str11)); V r_ = (g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(a_0, a_1)); heff_drop(v_path_24103); r_; });
  V v_c_24108 = heff_tr(heff_call(v_c_24104, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam17_clo)}));
  V f_ = v_c_24108;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam18, 1, 8, (V[]){v_ended_2474, v_x_2496, v_path_242, v_v_243, v_hd_245, v_k_246, v_x_24102, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam14(V self, V *args) {
  V v_x_2486 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_out_2473 = heff_env(self)[2];
  V v_ended_2474 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_v_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2486);
  V v_path_2487 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_244); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2488 = ({ V a_0 = v_path_2487; V r_ = (g_std_2efilesystem_2ereadOnly_24s423320184x164941529(a_0)); heff_drop(v_path_2487); r_; });
  V v_c_2492 = heff_tr(heff_call(v_c_2488, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam15_clo)}));
  V f_ = v_c_2492;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam16, 1, 7, (V[]){v_out_2473, v_x_244, v_hd_245, v_ended_2474, v_path_242, v_v_243, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam12(V self, V *args) {
  V v_x_2472 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_out_2473 = heff_take_field(v_x_2472, 1);
  V v_ended_2474 = heff_get_n(v_x_2472, 0, 3);
  V v_st_2475 = heff_get_n(v_ps_241, 5, 6);
  V v_t_2476 = (g_std_2epath_2eparse(v_st_2475, heff_dup(v_x_244)));
  V v_t_2477 = (g_std_2epath_2eparse(v_st_2475, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str8)));
  V v_t_2478 = (g_std_2epath_2ejoin(v_t_2476, v_t_2477));
  V v_s_2479 = ({ V a_0 = v_st_2475; V a_1 = v_t_2478; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2475); heff_drop(v_t_2478); r_; });
  V v_path_2480 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2479; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2481 = ({ V a_0 = v_path_2480; V r_ = (g_std_2efilesystem_2eremove_24s1441356369x419789784(a_0)); heff_drop(v_path_2480); r_; });
  V v_c_2485 = heff_tr(heff_call(v_c_2481, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam13_clo)}));
  V f_ = v_c_2485;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam14, 1, 7, (V[]){v_x_244, v_hd_245, v_out_2473, v_ended_2474, v_path_242, v_v_243, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam21(V self, V *args) {
  V v_x_24149 = args[0];
  V v_hd_24150 = args[1];
  V v_k_24151 = args[2];
  heff_drop(v_hd_24150);
  V f_ = v_k_24151;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24149});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam22(V self, V *args) {
  V v_x_24153 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_why_24146 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24153);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_why_24146});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam10(V self, V *args) {
  V v_x_2458 = args[0];
  V v_x_2455 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_v_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2458);
  switch (heff_tag_of(v_x_2455)) {
  case TAG_Nothing: {
    V v_t_2459 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_244); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str5), NTAG(TAG_Nil)});
    V v_t_2461 = ({ V a_0 = v_t_2459; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_t_2459); r_; });
    V v_t_2462 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str7), v_t_2460}), v_t_2461, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_a_2464 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2462, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam11_clo)});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})}));
    V f_ = heff_dup(heff_rfield(v_hd_245, 1));
    heff_room[0] = v_t_2471;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam12, 1, 6, (V[]){v_ps_241, v_x_244, v_hd_245, v_path_242, v_v_243, v_k_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_why_24146 = heff_field(v_x_2455, 0);
    heff_take_n(v_x_2455, 1ULL, 1);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_path_242);
    heff_drop(v_v_243);
    V v_path_24147 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_244; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_24148 = ({ V a_0 = v_path_24147; V r_ = (g_std_2efilesystem_2eremove_24s1441356369x419789784(a_0)); heff_drop(v_path_24147); r_; });
    V v_c_24152 = heff_tr(heff_call(v_c_24148, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam21_clo)}));
    V f_ = v_c_24152;
    heff_room[0] = v_hd_245;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam22, 1, 2, (V[]){v_k_246, v_why_24146});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2455);
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam9(V self, V *args) {
  V v_x_2455 = args[0];
  V v_x_2446 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_ps_241 = heff_env(self)[4];
  V v_path_242 = heff_env(self)[5];
  V v_v_243 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2456 = heff_tag_n(TAG_End, 2, (V[]){v_x_2446, NTAG(TAG_MkUnit)});
  V v_t_2457 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2456}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2457, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam10, 1, 7, (V[]){v_x_2455, v_x_244, v_hd_245, v_ps_241, v_path_242, v_v_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam8(V self, V *args) {
  V v_x_2446 = args[0];
  V v_v_243 = heff_env(self)[0];
  V v_path_242 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2447 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str3); V a_1 = v_v_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str4), v_v_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  HeffT2 v_t_2448 = (g_heff_2ebuild_2eproject_2epseudoParts_24cpr(v_t_2447));
  {
    V v_field_2450 = v_t_2448.f[1];
    int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
    V v_c_2454;
    if ((v_tag_2449 == ((int64_t)0ULL))) {
      V v_it1_2451 = v_field_2450;
      switch (heff_tag_of(v_it1_2451)) {
      case TAG_MkPair: {
        V v_time_2452 = heff_field(v_it1_2451, 0);
        V v_hash_2453 = heff_field(v_it1_2451, 1);
        heff_take_n(v_it1_2451, 3ULL, 2);
        v_c_2454 = (g_heff_2ebuild_2ecommands_2ecommitCloned_24s386708181x988473245(heff_dup(v_path_242), heff_dup(v_v_243), v_time_2452, v_hash_2453, heff_dup(v_x_244)));
        break;
      }
      default: heff_nomatch(v_it1_2451);
      }
    } else {
      heff_drop(v_field_2450);
      v_c_2454 = (g_heff_2ebuild_2ecommands_2etagCloned_24s1835977851x1880031502(heff_dup(v_path_242), heff_dup(v_v_243), heff_dup(v_x_244)));
    }
    V f_ = v_c_2454;
    heff_room[0] = heff_dup(v_hd_245);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam9, 1, 8, (V[]){v_x_2446, v_prog_240, v_hd_245, v_x_244, v_ps_241, v_path_242, v_v_243, v_k_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam6(V self, V *args) {
  V v_x_2441 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_v_243 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2441);
  V v_t_2442 = heff_strAppend(heff_dup(v_path_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str1), heff_dup(v_v_243)));
  V v_t_2444 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str2), v_t_2442), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam7_clo)});
  V v_t_2445 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2444}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2445, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam8, 1, 7, (V[]){v_v_243, v_path_242, v_x_244, v_hd_245, v_prog_240, v_ps_241, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2421);
  V v_st_2422 = heff_dup(heff_rfield(v_ps_241, 5));
  HeffT3 v_t_2423 = (g_std_2epath_2eparse_24cpr(v_st_2422, heff_dup(v_x_244)));
  V v_t_2433;
  {
    V v_field_2424 = v_t_2423.f[0];
    V v_field_2425 = v_t_2423.f[1];
    V v_field_2426 = v_t_2423.f[2];
    V v_d_2427 = v_field_2424;
    V v_a_2428 = v_field_2425;
    V v_xs_2429 = v_field_2426;
    V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2429));
    V v_xs_2431 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2430; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2430); r_; });
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
    v_t_2433 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2427, v_a_2428, v_t_2432});
  }
  V v_s_2434 = ({ V a_0 = v_st_2422; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); heff_drop(v_t_2433); r_; });
  V v_path_2435 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2434; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2436 = ({ V a_0 = v_path_2435; V r_ = (g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(a_0)); heff_drop(v_path_2435); r_; });
  V v_c_2440 = heff_tr(heff_call(v_c_2436, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam5_clo)}));
  V f_ = v_c_2440;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam6, 1, 7, (V[]){v_path_242, v_v_243, v_prog_240, v_hd_245, v_x_244, v_ps_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_v_243 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    heff_take_n(v_x_2413, 0ULL, 1);
    V v_path_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_244); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2416 = ({ V a_0 = v_path_2415; V r_ = (g_std_2efilesystem_2eremove_24s1441356369x419789784(a_0)); heff_drop(v_path_2415); r_; });
    V v_c_2420 = heff_tr(heff_call(v_c_2416, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam3_clo)}));
    V f_ = v_c_2420;
    heff_room[0] = heff_dup(v_hd_245);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam4, 1, 7, (V[]){v_ps_241, v_x_244, v_hd_245, v_path_242, v_v_243, v_prog_240, v_k_246});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_24154 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Right = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    heff_drop(v_x_244);
    heff_drop_rec(v_hd_245, 3);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_path_242);
    heff_drop(v_v_243);
    heff_drop(v_prog_240);
    V v_t_24155 = (g_prelude_2eskipSpaces(v_y_24154, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_24156 = (heff_unbox_word(heff_strLength_lent(v_y_24154, 0)) - ((int64_t)1ULL));
    V v_t_24157 = (g_prelude_2eskipSpaces(v_y_24154, heff_box_word(v_t_24156), MK_INT(-1LL)));
    V v_t_24158 = heff_strSlice(v_y_24154, v_t_24155, heff_intAdd(v_t_24157, MK_INT(1LL)));
    V v_x_24159 = heff_tag_at_n(v_ru_24x_2413_24Right, TAG_Right, 1, (V[]){v_t_24158});
    V f_ = v_k_246;
    args[0] = v_x_24159;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_path_242 = heff_env(self)[2];
  V v_v_243 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_strAppend(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_str0)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_248 = ({ V a_0 = v_path_247; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_247); r_; });
  V v_c_2412 = heff_tr(heff_call(v_c_248, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam1_clo)}));
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_lam2, 1, 7, (V[]){v_x_244, v_hd_245, v_ps_241, v_path_242, v_v_243, v_prog_240, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256(V v_rep_240, V v_prog_241, V v_st_242, V v_t_243, V v_bp_244, V v_done_245, V v_x5_246) {
top: ;
  switch (heff_tag_of(v_x5_246)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop(v_t_243);
    heff_drop(v_bp_244);
    return v_done_245;
  }
  case TAG_Cons: {
    V v_a_247 = heff_field(v_x5_246, 0);
    V v_rest_248 = heff_field(v_x5_246, 1);
    V v_name_249 = heff_dup(heff_rfield(v_a_247, 0));
    V v_build_2410 = heff_dup(heff_rfield(v_a_247, 1));
    V v_t_2411 = (g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256(heff_dup(v_rep_240), heff_dup(v_prog_241), v_st_242, heff_dup(v_t_243), heff_dup(v_bp_244), v_done_245, v_rest_248));
    return (g_heff_2ebuild_2ecommands_2ebuildApp_24s1894098726x1861155648(v_rep_240, v_prog_241, v_st_242, v_t_243, v_bp_244, v_name_249, v_build_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x5_246);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ebuildEach_24s752747370x1138374256(a[0], a[1], a2, a[3], a[4], a[5], a6); heff_drop(a2); heff_drop(a6); return r;
}