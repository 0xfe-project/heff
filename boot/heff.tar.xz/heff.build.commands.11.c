// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_Copy 17796
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_Left 13886
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Replace 14236
#define TAG_Right 62770
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Value 50841
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_discarded 1490202606
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_failure 1292767177
#define LBL_goldens 436112074
#define LBL_labels 836724522
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_opt 319789
#define LBL_paths 307797256
#define LBL_property 1899481104
#define LBL_root 10001833
#define LBL_runs 10007567
#define LBL_said 10017968
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_style 311138763
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_co_2eop_24s695421809x762051105(V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s695421809x762051105_entry(V self, V *a);
extern Clo g_co_2eop_24s695421809x762051105_clo;
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildText_get(void);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128(V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_clo;
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589(V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s1540841479x2031353608(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s1540841479x2031353608_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s1540841479x2031353608_clo;
V g_heff_2ebuild_2ecommands_2elastLines(V, V);
V g_heff_2ebuild_2ecommands_2elastLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elastLines_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson(V, V);
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eoutcomeOfJson_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeVariable_get(void);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_clo;
V g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_clo;
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_clo;
V g_heff_2ebuild_2ecommands_2eranOutcome(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eranOutcome_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranOutcome_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1757241500x34779154(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1757241500x34779154_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1757241500x34779154_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_clo;
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(V, V);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_clo;
V g_heff_2ebuild_2ecommands_2etestsSaid(V);
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo;
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098(V, V);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eversionSaid_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924_clo;
V g_heff_2ebuild_2ecommands_2ezigCc_24s686886594x1158882511(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigCc_24s686886594x1158882511_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigCc_24s686886594x1158882511_clo;
V g_heff_2ebuild_2edocpages_2epage(V);
V g_heff_2ebuild_2edocpages_2epage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2epage_clo;
V g_heff_2ebuild_2eload_2eisRoot_24s1548130457x1539794246(V, V);
V g_heff_2ebuild_2eload_2eisRoot_24s1548130457x1539794246_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eisRoot_24s1548130457x1539794246_clo;
V g_heff_2ebuild_2eload_2eownDir_24s478002771x576026510(V, V);
V g_heff_2ebuild_2eload_2eownDir_24s478002771x576026510_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s478002771x576026510_clo;
V g_heff_2ebuild_2eproject_2ecompatible(V, V);
V g_heff_2ebuild_2eproject_2ecompatible_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ecompatible_clo;
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
HeffT2 g_json_2esteps_24cpr(V, V);
V g_list_2efilter_24s2101000672x961294372(V, V, V, V);
V g_list_2efilter_24s2101000672x961294372_entry(V self, V *a);
extern Clo g_list_2efilter_24s2101000672x961294372_clo;
V g_list_2efoldl_24f1189266312x1583313228(V, V, V);
V g_list_2efoldl_24f1189266312x1583313228_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1189266312x1583313228_clo;
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24f1824632076x1202317442(V, V, V);
V g_list_2efoldl_24f1824632076x1202317442_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1824632076x1202317442_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str0, 2, "0.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str1, 15, " (the same 0.x)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str3, 19, ", and this heff is ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str4, 13, " is for heff ");

HeffT2 g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(V v_who_240, V v_wanted_241, V v_running_242, V v_x4_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_who_240);
    heff_drop(v_wanted_241);
    heff_drop(v_running_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_w_245 = heff_field(v_x4_243, 0);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nothing: {
      heff_drop(v_who_240);
      heff_drop(v_wanted_241);
      heff_drop(v_running_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_r_246 = heff_field(v_x5_244, 0);
      V v_t_247 = (g_heff_2ebuild_2eproject_2ecompatible(v_w_245, v_r_246));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_who_240);
        heff_drop(v_wanted_241);
        heff_drop(v_running_242);
        heff_drop(v_t_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        heff_drop(v_t_247);
        V v_t_249;
        if (heff_strEq_c(heff_strSlice_lent(v_wanted_241, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str0))) {
          v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str1);
        } else {
          v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str2);
        }
        V v_t_2410 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str3), v_running_242));
        V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str4), heff_strAppend(v_wanted_241, v_t_2410));
        V v_f_2412 = heff_strAppend(v_who_240, v_t_2411);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x5_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_243, v_seen_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_seen_240;
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_seen_240});
      V t_1 = v_rest_244;
      V t_2 = v_cell_246;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enubStrGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str2, 8, " skipped");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str5, 8, ", tests ");
Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2etestsSaid(V v_os_240) {
top: ;
  switch (heff_tag_of(v_os_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str0);
  }
  case TAG_Cons: {
    V v_t_243 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_244 = (g_list_2efoldl_24f1189266312x1583313228(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_245 = (g_list_2efoldl_24f1824632076x1202317442(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_246 = heff_intSub(heff_intSub(v_t_243, v_t_244), v_t_245);
    V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_n_248 = (g_list_2efoldl_24f1824632076x1202317442(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_2411;
    if (heff_intEq_c_lent(v_n_248, MK_INT(0LL), 2)) {
      heff_drop(v_n_248);
      v_t_2411 = ((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str1);
    } else {
      V v_t_2410 = heff_strAppend(heff_intShow(v_n_248), ((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str2));
      v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str3), v_t_2410);
    }
    V v_t_2412 = heff_strAppend(heff_intShow(v_t_247), v_t_2411);
    V v_t_2413 = heff_strAppend(heff_intShow(v_t_246), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str4), v_t_2412));
    return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str5), v_t_2413);
  }
  default: return heff_nomatch(v_os_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2etestsSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeVariable_str0, 17, "HEFF_TEST_OUTCOME");

static V g_heff_2ebuild_2ecommands_2eoutcomeVariable_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eoutcomeVariable_st;
static V g_heff_2ebuild_2ecommands_2eoutcomeVariable_init(void) {
  return ((V)&g_heff_2ebuild_2ecommands_2eoutcomeVariable_str0);
}
V g_heff_2ebuild_2ecommands_2eoutcomeVariable_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eoutcomeVariable_st)) return g_heff_2ebuild_2ecommands_2eoutcomeVariable_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eoutcomeVariable_val, &g_heff_2ebuild_2ecommands_2eoutcomeVariable_st, g_heff_2ebuild_2ecommands_2eoutcomeVariable_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str0, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str1, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str2, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str3, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str6, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str7, 33, ", and said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str8, 3, "it ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str9, 45, "what it said of how it went could not be read");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str10, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str11, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str12, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str13, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str16, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str17, 33, ", and said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str18, 3, "it ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str19, 45, "what it said of how it went could not be read");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str20, 11, " ms: killed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str21, 33, "took longer than its time limit, ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str22, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str23, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str24, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str25, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str27, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str28, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str29, 33, ", and said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str30, 3, "it ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str31, 45, "what it said of how it went could not be read");
Clo g_heff_2ebuild_2ecommands_2eranOutcome_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranOutcome_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eranOutcome(V v_name_240, V v_limit_241, V v_r_242, V v_said_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_r_242, 0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Exited: {
    V v_ru_24t_244_24Exited = heff_take_reuse_n(v_t_244, 0ULL, 1);
    heff_drop(v_limit_241);
    switch (heff_tag_of(v_said_243)) {
    case TAG_Nothing: {
      V v_t_246 = heff_take_field(v_r_242, 0);
      V v_t_249;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Exited: {
        V v_n_247 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str0), heff_intShow(v_n_247));
        break;
      }
      case TAG_Signalled: {
        V v_n_248 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str1), heff_intShow(v_n_248));
        break;
      }
      case TAG_TimedOut: {
        v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str2);
        break;
      }
      case TAG_NotRun: {
        v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str3);
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      V v_t_2412;
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_242, 2)), ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str4))) {
        heff_drop_rec(v_r_242, 3);
        v_t_2412 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str5);
      } else {
        V v_t_2411 = ({ V a_0 = MK_INT(20LL); V b_1 = heff_get_n(v_r_242, 2, 3); V r_ = (g_heff_2ebuild_2ecommands_2elastLines(a_0, b_1)); heff_drop(b_1); r_; });
        v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str6), v_t_2411);
      }
      V v_t_2413 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str7), v_t_2412));
      V v_why_2414 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str8), v_t_2413);
      V v_t_2415 = heff_tag_at_n(v_ru_24t_244_24Exited, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2414})});
      return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2415, MK_INT(0LL), NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_text_2416 = heff_field(v_said_243, 0);
      heff_take_n(v_said_243, 1ULL, 1);
      heff_drop_rec(v_r_242, 3);
      V v_t_2417 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2418 = ({ V a_0 = v_text_2416; V a_1 = v_t_2417; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_text_2416); r_; });
      {
        V v_field_2420 = v_t_2418.f[1];
        int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
        if ((v_tag_2419 == ((int64_t)0ULL))) {
          V v_why_2422 = v_field_2420;
          heff_drop(v_why_2422);
          V v_t_2423 = heff_tag_at_n(v_ru_24t_244_24Exited, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str9)})});
          return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2423, MK_INT(0LL), NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24t_244_24Exited, 1);
          V v_j_2424 = v_field_2420;
          return (g_heff_2ebuild_2ecommands_2eoutcomeOfJson(v_name_240, v_j_2424));
        }
      }
    }
    default: return heff_nomatch(v_said_243);
    }
  }
  case TAG_Signalled: {
    V v_ru_24t_244_24Signalled = heff_take_reuse_n(v_t_244, 0ULL, 1);
    heff_drop(v_limit_241);
    switch (heff_tag_of(v_said_243)) {
    case TAG_Nothing: {
      V v_t_2426 = heff_take_field(v_r_242, 0);
      V v_t_2429;
      switch (heff_tag_of(v_t_2426)) {
      case TAG_Exited: {
        V v_n_2427 = heff_field(v_t_2426, 0);
        heff_take_n(v_t_2426, 1ULL, 1);
        v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str10), heff_intShow(v_n_2427));
        break;
      }
      case TAG_Signalled: {
        V v_n_2428 = heff_field(v_t_2426, 0);
        heff_take_n(v_t_2426, 1ULL, 1);
        v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str11), heff_intShow(v_n_2428));
        break;
      }
      case TAG_TimedOut: {
        v_t_2429 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str12);
        break;
      }
      case TAG_NotRun: {
        v_t_2429 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str13);
        break;
      }
      default: heff_nomatch(v_t_2426);
      }
      V v_t_2432;
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_242, 2)), ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str14))) {
        heff_drop_rec(v_r_242, 3);
        v_t_2432 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str15);
      } else {
        V v_t_2431 = ({ V a_0 = MK_INT(20LL); V b_1 = heff_get_n(v_r_242, 2, 3); V r_ = (g_heff_2ebuild_2ecommands_2elastLines(a_0, b_1)); heff_drop(b_1); r_; });
        v_t_2432 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str16), v_t_2431);
      }
      V v_t_2433 = heff_strAppend(v_t_2429, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str17), v_t_2432));
      V v_why_2434 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str18), v_t_2433);
      V v_t_2435 = heff_tag_at_n(v_ru_24t_244_24Signalled, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2434})});
      return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2435, MK_INT(0LL), NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_text_2436 = heff_field(v_said_243, 0);
      heff_take_n(v_said_243, 1ULL, 1);
      heff_drop_rec(v_r_242, 3);
      V v_t_2437 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2438 = ({ V a_0 = v_text_2436; V a_1 = v_t_2437; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_text_2436); r_; });
      {
        V v_field_2440 = v_t_2438.f[1];
        int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
        if ((v_tag_2439 == ((int64_t)0ULL))) {
          V v_why_2442 = v_field_2440;
          heff_drop(v_why_2442);
          V v_t_2443 = heff_tag_at_n(v_ru_24t_244_24Signalled, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str19)})});
          return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2443, MK_INT(0LL), NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24t_244_24Signalled, 1);
          V v_j_2444 = v_field_2440;
          return (g_heff_2ebuild_2ecommands_2eoutcomeOfJson(v_name_240, v_j_2444));
        }
      }
    }
    default: return heff_nomatch(v_said_243);
    }
  }
  case TAG_TimedOut: {
    heff_drop_rec(v_r_242, 3);
    heff_drop(v_said_243);
    V v_t_2445 = heff_strAppend(heff_intShow(v_limit_241), ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str20));
    V v_t_2446 = heff_tag_n(TAG_FailBecause, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str21), v_t_2445)});
    return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_tag_n(TAG_Just, 1, (V[]){v_t_2446}), MK_INT(0LL), NTAG(TAG_Nil)});
  }
  case TAG_NotRun: {
    heff_drop(v_limit_241);
    switch (heff_tag_of(v_said_243)) {
    case TAG_Nothing: {
      V v_t_2447 = heff_take_field(v_r_242, 0);
      V v_t_2450;
      switch (heff_tag_of(v_t_2447)) {
      case TAG_Exited: {
        V v_n_2448 = heff_field(v_t_2447, 0);
        heff_take_n(v_t_2447, 1ULL, 1);
        v_t_2450 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str22), heff_intShow(v_n_2448));
        break;
      }
      case TAG_Signalled: {
        V v_n_2449 = heff_field(v_t_2447, 0);
        heff_take_n(v_t_2447, 1ULL, 1);
        v_t_2450 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str23), heff_intShow(v_n_2449));
        break;
      }
      case TAG_TimedOut: {
        v_t_2450 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str24);
        break;
      }
      case TAG_NotRun: {
        v_t_2450 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str25);
        break;
      }
      default: heff_nomatch(v_t_2447);
      }
      V v_t_2453;
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_242, 2)), ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str26))) {
        heff_drop_rec(v_r_242, 3);
        v_t_2453 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str27);
      } else {
        V v_t_2452 = ({ V a_0 = MK_INT(20LL); V b_1 = heff_get_n(v_r_242, 2, 3); V r_ = (g_heff_2ebuild_2ecommands_2elastLines(a_0, b_1)); heff_drop(b_1); r_; });
        v_t_2453 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str28), v_t_2452);
      }
      V v_t_2454 = heff_strAppend(v_t_2450, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str29), v_t_2453));
      V v_why_2455 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str30), v_t_2454);
      V v_t_2456 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2455})});
      return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2456, MK_INT(0LL), NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_text_2457 = heff_field(v_said_243, 0);
      V v_ru_24said_243_24Just = heff_take_reuse_n(v_said_243, 1ULL, 1);
      heff_drop_rec(v_r_242, 3);
      V v_t_2458 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2459 = ({ V a_0 = v_text_2457; V a_1 = v_t_2458; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_text_2457); r_; });
      {
        V v_field_2461 = v_t_2459.f[1];
        int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
        if ((v_tag_2460 == ((int64_t)0ULL))) {
          V v_why_2463 = v_field_2461;
          heff_drop(v_why_2463);
          V v_t_2464 = heff_tag_at_n(v_ru_24said_243_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str31)})});
          return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2464, MK_INT(0LL), NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24said_243_24Just, 1);
          V v_j_2465 = v_field_2461;
          return (g_heff_2ebuild_2ecommands_2eoutcomeOfJson(v_name_240, v_j_2465));
        }
      }
    }
    default: return heff_nomatch(v_said_243);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ebuild_2ecommands_2eranOutcome_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eranOutcome(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str1, 13, "build : Build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str2, 37, "build = { backend = C, run = \"main\" }");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str3, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str5, 21, "-- heff home with it.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str7, 69, "-- page's script of it.  A field `ships = [...]` would name files and");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str8, 69, "-- directories of the project's root for `heff install` to put in the");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str10, 69, "-- main.hf's `main`, compiled through C (by `zig cc`); `Page` makes a");

static V g_heff_2ebuild_2ecommands_2ebuildText_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2ebuildText_st;
static V g_heff_2ebuild_2ecommands_2ebuildText_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2ebuildText_str9); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2ebuildText_str10); V a_2 = v_t_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildText_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2ebuildText_st)) return g_heff_2ebuild_2ecommands_2ebuildText_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2ebuildText_val, &g_heff_2ebuild_2ecommands_2ebuildText_st, g_heff_2ebuild_2ecommands_2ebuildText_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716(V v_bi_240, V v_dir_241, V v_rt_242, V v_done_243, V v_c_244, V v_available_245, V v_r_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s695096959x894998799(heff_dup(heff_rfield(v_bi_240, 0)), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_lam0, 1, 9, (V[]){v_bi_240, v_hd_247, v_dir_241, v_rt_242, v_done_243, v_c_244, v_available_245, v_r_246, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_rt_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_hd_247 = heff_env(self)[8];
  V v_k_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_249, v_x_2415));
  return ({ V a_0 = v_bi_240; V a_1 = v_dir_241; V a_2 = v_rt_242; V a_3 = v_done_243; V a_4 = v_c_244; V a_5 = v_available_245; V a_6 = v_r_246; V a_7 = v_x_249; V a_8 = v_x_2415; V a_9 = v_t_2416; V a_10 = v_hd_247; V a_11 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ekeptWith_24s1540841479x2031353608(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_x_2415); r_; });
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_rt_242 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_k_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2414;
  if (heff_strEq_c_lent(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_str0), 2)) {
    v_c_2414 = ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_lam1_clo);
  } else {
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_str1), heff_dup(heff_rfield(v_bi_240, 2))});
    v_c_2414 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s1619380928x2083448660(heff_dup(heff_rfield(v_bi_240, 0)), v_t_2413));
  }
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_lam2, 1, 10, (V[]){v_x_249, v_bi_240, v_dir_241, v_rt_242, v_done_243, v_c_244, v_available_245, v_r_246, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_str2, 1, ".");
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam6, 2, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_MkPair: {
      V v_top_247 = heff_field(v_x11_245, 0);
      V v_p_248 = heff_field(v_x11_245, 1);
      heff_take_n(v_x11_245, 3ULL, 2);
      V v_path_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_p_248); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2410 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_249; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_249); r_; });
      V v_a_2412 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_ReadDirectory, 2, (V[]){v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam1_clo)});
      return heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam2, 2, 5, (V[]){v_a_2412, v_p_248, v_rest_246, v_acc_241, v_top_247});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam1(V self, V *args) {
  V v_ns_2411 = args[0];
  return v_ns_2411;
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam4(V self, V *args) {
  V v_s_2422 = args[0];
  return v_s_2422;
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam6(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  heff_drop(v_hd_2439);
  V f_ = v_k_2440;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam8(V self, V *args) {
  V v_n_2445 = args[0];
  V v_st_2432 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = (g_std_2epath_2eparse(v_st_2432, v_p_248));
  V v_t_2447 = (g_std_2epath_2eparse(v_st_2432, v_n_2445));
  V v_t_2448 = (g_std_2epath_2ejoin(v_t_2446, v_t_2447));
  V v_t_2449 = ({ V a_0 = v_st_2432; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2432); heff_drop(v_t_2448); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_t_2449});
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam7(V self, V *args) {
  V v_x_2442 = args[0];
  V v_rest_246 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  V v_ns_2438 = heff_env(self)[4];
  V v_st_2432 = heff_env(self)[5];
  V v_p_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  if ((heff_dup(v_x_2442) == NTAG(TAG_True))) {
    heff_drop(v_x_2442);
    heff_drop(v_ns_2438);
    heff_drop(v_st_2432);
    heff_drop(v_p_248);
    V v_t_2443 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(v_rest_246, v_acc_241));
    V f_ = v_t_2443;
    heff_room[0] = v_hd_2413;
    heff_room[1] = v_k_2414;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2442);
    V v_t_2444 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_str2); V a_3 = v_ns_2438; V r_ = (g_list_2efilter_24s2101000672x961294372(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
    V v_t_2450 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_246, heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam8, 1, 2, (V[]){v_st_2432, v_p_248}), v_t_2444));
    V v_t_2451 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(v_t_2450, v_acc_241));
    V f_ = v_t_2451;
    heff_room[0] = v_hd_2413;
    heff_room[1] = v_k_2414;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_2413 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  V v_top_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2432;
  if (heff_strEq_c(v_x_2430, ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_str0))) {
    v_st_2432 = NTAG(TAG_Windows);
  } else {
    v_st_2432 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    heff_drop(v_top_247);
    heff_drop(v_st_2432);
    int64_t v_t_2433 = (heff_unbox_word(heff_strLength_lent(v_p_248, 0)) - ((int64_t)3ULL));
    V v_t_2434 = heff_strSlice(heff_dup(v_p_248), heff_box_word(v_t_2433), heff_strLength_lent(v_p_248, 0));
    if (heff_strEq_c(v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_str1))) {
      V v_t_2436 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(v_rest_246, heff_tag_n(TAG_Cons, 2, (V[]){v_p_248, v_acc_241})));
      V f_ = v_t_2436;
      heff_room[0] = v_hd_2413;
      heff_room[1] = v_k_2414;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_248);
      V v_t_2437 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728(v_rest_246, v_acc_241));
      V f_ = v_t_2437;
      heff_room[0] = v_hd_2413;
      heff_room[1] = v_k_2414;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Just: {
    V v_ns_2438 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    V v_c_2441;
    if ((heff_dup(v_top_247) == NTAG(TAG_True))) {
      heff_drop(v_top_247);
      v_c_2441 = ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam6_clo);
    } else {
      heff_drop(v_top_247);
      v_c_2441 = (g_heff_2ebuild_2eload_2eisRoot_24s1548130457x1539794246(v_st_2432, heff_dup(v_p_248)));
    }
    V f_ = v_c_2441;
    heff_room[0] = heff_dup(v_hd_2413);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam7, 1, 7, (V[]){v_rest_246, v_acc_241, v_hd_2413, v_k_2414, v_ns_2438, v_st_2432, v_p_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  V v_top_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam4_clo)})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  return (g_co_2eop_24s495635622x733177935(v_t_2429, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam5, 1, 7, (V[]){v_x_2421, v_p_248, v_rest_246, v_acc_241, v_hd_2413, v_k_2414, v_top_247})));
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_a_2412 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_top_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s495635622x733177935(v_t_2420, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s1538760799x1547360728_lam3, 1, 6, (V[]){v_hd_2413, v_p_248, v_rest_246, v_acc_241, v_k_2414, v_top_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_str5, 3, ".md");
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_lam0_clo)})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s495635622x733177935(v_t_2413, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_lam1, 1, 5, (V[]){heff_dup(v_c_244), v_dir_240, v_p_242, heff_dup(v_rest_245), v_p_243})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_lam0(V self, V *args) {
  V v_s_246 = args[0];
  return v_s_246;
}
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2428);
  return ({ V a_0 = v_dir_240; V a_1 = v_rest_245; V a_2 = v_p_242; V a_3 = v_p_243; V r_ = (g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
}
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2416;
  if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_str0))) {
    v_st_2416 = NTAG(TAG_Windows);
  } else {
    v_st_2416 = NTAG(TAG_Posix);
  }
  V v_m_2417 = heff_dup(heff_rfield(v_c_244, 0));
  V v_x2_2418 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_str1); V a_1 = v_m_2417; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_str2), v_m_2417, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_m_2417); r_; });
  V v_t_2421;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    v_t_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_str4); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  V v_b_2422 = heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_str5));
  V v_t_2423 = (g_std_2epath_2eparse(v_st_2416, heff_dup(v_dir_240)));
  V v_t_2424 = (g_std_2epath_2eparse(v_st_2416, v_b_2422));
  V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
  V v_t_2426 = ({ V a_0 = v_st_2416; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); heff_drop(v_t_2425); r_; });
  V v_t_2427 = (g_heff_2ebuild_2edocpages_2epage(v_c_244));
  return (g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128(v_t_2426, v_t_2427, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_lam2, 1, 4, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_str0, 8, "build.hf");
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628(V v_prog_240, V v_st_241, V v_t_242, V v_rd_243, V v_acc_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop(v_t_242);
    heff_drop(v_rd_243);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_244, 0)));
    V v_x_247 = ({ V rv_0 = v_t_246; V rr_ = heff_rec_reuse_nf(v_acc_244, 2ULL, 2, shape_apps__bad, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam0, 2, 1, (V[]){v_x_247});
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x5_245, 0);
    V v_rest_2411 = heff_field(v_x5_245, 1);
    V v_ru_24x5_245_24Cons = heff_take_reuse_n(v_x5_245, 3ULL, 2);
    V v_s_2412 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_241, heff_dup(v_t_242), heff_dup(v_x_2410), ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_str0)));
    V v_path_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2412; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2414 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2413; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2413); r_; });
    V v_a_2416 = heff_tag_at_n(v_ru_24x5_245_24Cons, TAG_ReadFile, 2, (V[]){v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam1_clo)});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam2, 2, 8, (V[]){v_a_2416, heff_dup(v_st_241), v_t_242, v_acc_244, v_x_2410, v_rd_243, v_prog_240, v_rest_2411});
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam1(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_rd_243 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_rest_2411 = heff_env(self)[4];
  V v_hd_2417 = heff_env(self)[5];
  V v_k_2418 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2428 = heff_tag_n(TAG_Complete, 2, (V[]){heff_dup(v_rd_243), NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2428}));
  return ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_rd_243; V a_4 = v_x_2427; V a_5 = v_rest_2411; V a_6 = heff_dup(v_hd_2417); V a_7 = v_k_2418; V a_8 = v_t_2429; V a_9 = v_hd_2417; V r_ = (g_co_2eop_24s695421809x762051105(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_st_241); r_; });
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_acc_244 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_hd_2417 = heff_env(self)[4];
  V v_rd_243 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  V v_k_2418 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2426 = (g_heff_2ebuild_2ecommands_2eappRead_24s83494635x1850234390(v_st_241, heff_dup(v_t_242), v_acc_244, v_x_2410, v_x_2425));
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_2417);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam4, 1, 7, (V[]){v_rd_243, v_prog_240, v_st_241, v_t_242, v_rest_2411, v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_a_2416 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_acc_244 = heff_env(self)[3];
  V v_x_2410 = heff_env(self)[4];
  V v_rd_243 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_rest_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2416})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s495635622x733177935(v_t_2424, heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_lam3, 1, 9, (V[]){v_st_241, v_t_242, v_acc_244, v_x_2410, v_hd_2417, v_rd_243, v_prog_240, v_rest_2411, v_k_2418})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigCc_24s686886594x1158882511_str0, 10, "heff build");
Clo g_heff_2ebuild_2ecommands_2ezigCc_24s686886594x1158882511_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigCc_24s686886594x1158882511_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ezigCc_24s686886594x1158882511(V v_prog_240, V v_st_241, V v_t_242, V v_p_243, V v_x_244, V v_next_245) {
top: ;
  V v_dir_246 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_241, heff_dup(v_t_242), heff_dup(v_x_244)));
  V v_a_247 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_241, heff_dup(v_t_242), heff_dup(v_x_244)));
  V v_t_248 = (g_std_2epath_2eparse(v_st_241, v_a_247));
  V v_t_249 = (g_std_2epath_2eparse(v_st_241, v_x_244));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
  V v_out_2411 = ({ V a_0 = v_st_241; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_242, 5, 6), NTAG(TAG_Nil)});
  return (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1532147856x1363484924(MK_INT(1LL), v_prog_240, ((V)&g_heff_2ebuild_2ecommands_2ezigCc_24s686886594x1158882511_str0), v_st_241, v_t_2412, v_p_243, v_dir_246, v_out_2411, v_next_245));
}
V g_heff_2ebuild_2ecommands_2ezigCc_24s686886594x1158882511_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ezigCc_24s686886594x1158882511(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str4, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str5, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam10, 2, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam14(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam14, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975(V v_prog_240, V v_st_241, V v_t_242, V v_pl_243, V v_next_244, V v_x_245, V v_x6_246) {
top: ;
  switch (heff_tag_of(v_x6_246)) {
  case TAG_Nothing: {
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_x_245);
    V v_t_247 = heff_tag_n(TAG_Complete, 2, (V[]){v_pl_243, NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_247}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam0, 2, 2, (V[]){v_t_248, v_next_244});
  }
  case TAG_Just: {
    V v_n_2412 = heff_field(v_x6_246, 0);
    heff_take_n(v_x6_246, 1ULL, 1);
    V v_t_2414 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_pl_243, heff_dup(v_n_2412), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam2_clo)})}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam3, 2, 7, (V[]){v_t_2414, heff_dup(v_st_241), v_t_242, v_n_2412, v_x_245, v_prog_240, v_next_244});
  }
  default: return heff_nomatch(v_x6_246);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2411);
  V f_ = v_next_244;
  heff_room[0] = v_hd_249;
  heff_room[1] = v_k_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_t_248 = heff_env(self)[0];
  V v_next_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s495635622x733177935(v_t_248, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam1, 1, 3, (V[]){v_next_244, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam5(V self, V *args) {
  V v_ok_2425 = args[0];
  return v_ok_2425;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam7(V self, V *args) {
  V v_ok_2443 = args[0];
  return v_ok_2443;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam9(V self, V *args) {
  V v_ok_2460 = args[0];
  return v_ok_2460;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam10(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  heff_drop(v_hd_2468);
  V f_ = v_k_2469;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam13(V self, V *args) {
  V v_x_2487 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2487);
  V f_ = v_next_244;
  heff_room[0] = v_hd_2415;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam12(V self, V *args) {
  V v_x_2486 = args[0];
  V v_t_2477 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_next_244 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2486);
  return (g_co_2eop_24s495635622x733177935(v_t_2477, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam13, 1, 3, (V[]){v_next_244, v_hd_2415, v_k_2416})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam14(V self, V *args) {
  V v_ok_2490 = args[0];
  return v_ok_2490;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam16(V self, V *args) {
  V v_x_24118 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24118);
  V v_t_24119 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24119})});
  V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
  V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
  V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
  V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
  V v_t_24125 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24124})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24125}), v_hd_2415, v_k_2416));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam15(V self, V *args) {
  V v_x_2498 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_n_2412 = heff_env(self)[3];
  V v_hd_2415 = heff_env(self)[4];
  V v_k_2416 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2498);
  V v_a_2499 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_241, heff_dup(v_t_242), v_x_245));
  V v_t_24100 = (g_std_2epath_2eparse(v_st_241, v_a_2499));
  V v_t_24101 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_n_2412)));
  V v_t_24102 = (g_std_2epath_2ejoin(v_t_24100, v_t_24101));
  V v_t_24103 = ({ V a_0 = v_st_241; V a_1 = v_t_24102; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24102); r_; });
  V v_t_24104 = (g_std_2epath_2eparse(v_st_241, heff_get_n(v_t_242, 1, 6)));
  V v_t_24105 = (g_std_2epath_2eparse(v_st_241, v_n_2412));
  V v_t_24106 = (g_std_2epath_2ejoin(v_t_24104, v_t_24105));
  V v_t_24107 = ({ V a_0 = v_st_241; V a_1 = v_t_24106; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_24106); r_; });
  V v_t_24108 = heff_strAppend(v_t_24103, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str4), v_t_24107));
  V v_why_24109 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str5), v_t_24108);
  V v_t_24110 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str6), v_why_24109), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str7));
  V v_t_24111 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24110, NTAG(TAG_MkUnit)});
  V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
  V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
  V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
  V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24115})});
  V v_t_24117 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24116})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_24117}), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam16, 1, 2, (V[]){v_hd_2415, v_k_2416})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam11(V self, V *args) {
  V v_x_2471 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_2412 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_hd_2415 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  V v_k_2416 = heff_env(self)[7];
  V v_x_2422 = heff_env(self)[8];
  V v_x_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  if ((heff_dup(v_x_2471) == NTAG(TAG_True))) {
    heff_drop(v_x_2471);
    heff_drop(v_x_2422);
    heff_drop(v_x_245);
    V v_t_2472 = (g_std_2epath_2eparse(v_st_241, heff_take_field(v_t_242, 1)));
    V v_t_2473 = (g_std_2epath_2eparse(v_st_241, v_n_2412));
    V v_t_2474 = (g_std_2epath_2ejoin(v_t_2472, v_t_2473));
    V v_path_2475 = ({ V a_0 = v_st_241; V a_1 = v_t_2474; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2474); r_; });
    V v_t_2476 = heff_tag_n(TAG_End, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
    V v_t_2477 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2476}));
    V v_t_2478 = heff_strAppend(heff_get_n(v_t_242, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str2), v_path_2475));
    V v_t_2479 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2478, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str3)), NTAG(TAG_MkUnit)});
    V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
    V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
    V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
    V v_t_2485 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2485}), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam12, 1, 4, (V[]){v_t_2477, v_hd_2415, v_next_244, v_k_2416})));
  } else {
    heff_drop(v_x_2471);
    heff_drop(v_x_2417);
    heff_drop(v_prog_240);
    heff_drop(v_next_244);
    V v_path_2488 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_2422; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2489 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2488; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2488); r_; });
    V v_a_2491 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2489, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam14_clo)});
    V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2491})});
    V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
    V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
    V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
    V v_t_2496 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2496})});
    return (g_co_2eop_24s495635622x733177935(v_t_2497, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam15, 1, 6, (V[]){v_st_241, v_t_242, v_x_245, v_n_2412, v_hd_2415, v_k_2416})));
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam8(V self, V *args) {
  V v_x_2451 = args[0];
  V v_x_2422 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_n_2412 = heff_env(self)[3];
  V v_hd_2415 = heff_env(self)[4];
  V v_x_2417 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_next_244 = heff_env(self)[7];
  V v_k_2416 = heff_env(self)[8];
  V v_x_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2470;
  if ((heff_dup(v_x_2451) == NTAG(TAG_True))) {
    heff_drop(v_x_2451);
    V v_path_2452 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2422); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2453 = (g_std_2epath_2eparse(v_st_241, heff_dup(heff_rfield(v_t_242, 1))));
    V v_t_2454 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_n_2412)));
    V v_t_2455 = (g_std_2epath_2ejoin(v_t_2453, v_t_2454));
    V v_s_2456 = ({ V a_0 = v_st_241; V a_1 = v_t_2455; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2455); r_; });
    V v_to_2457 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2456; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2458 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2452; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2452); r_; });
    V v_t_2459 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2457; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2457); r_; });
    V v_a_2461 = heff_tag_n(TAG_Replace, 3, (V[]){v_t_2458, v_t_2459, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam9_clo)});
    V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2461})});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
    v_c_2470 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2467}));
  } else {
    heff_drop(v_x_2451);
    v_c_2470 = ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam10_clo);
  }
  V f_ = v_c_2470;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam11, 1, 10, (V[]){v_st_241, v_t_242, v_n_2412, v_x_2417, v_prog_240, v_hd_2415, v_next_244, v_k_2416, v_x_2422, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_n_2412 = heff_env(self)[3];
  V v_x_2422 = heff_env(self)[4];
  V v_hd_2415 = heff_env(self)[5];
  V v_x_2417 = heff_env(self)[6];
  V v_prog_240 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_2416 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2433);
  V v_a_2434 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_241, heff_dup(v_t_242), heff_dup(v_x_245)));
  V v_t_2435 = (g_std_2epath_2eparse(v_st_241, v_a_2434));
  V v_t_2436 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_n_2412)));
  V v_t_2437 = (g_std_2epath_2ejoin(v_t_2435, v_t_2436));
  V v_s_2438 = ({ V a_0 = v_st_241; V a_1 = v_t_2437; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2437); r_; });
  V v_path_2439 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2438; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_to_2440 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2422); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2441 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2439; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2439); r_; });
  V v_t_2442 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2440; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2440); r_; });
  V v_a_2444 = heff_tag_n(TAG_Copy, 3, (V[]){v_t_2441, v_t_2442, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam7_clo)});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s495635622x733177935(v_t_2450, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam8, 1, 10, (V[]){v_x_2422, v_st_241, v_t_242, v_n_2412, v_hd_2415, v_x_2417, v_prog_240, v_next_244, v_k_2416, v_x_245})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_2412 = heff_env(self)[2];
  V v_hd_2415 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  V v_k_2416 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2418 = (g_std_2epath_2eparse(v_st_241, heff_dup(heff_rfield(v_t_242, 1))));
  V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str0), heff_strAppend(heff_dup(v_n_2412), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_str1)));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_241, v_t_2419));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2418, v_t_2420));
  V v_x_2422 = ({ V a_0 = v_st_241; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_path_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2422); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2423; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2423); r_; });
  V v_a_2426 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam5_clo)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s495635622x733177935(v_t_2432, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam6, 1, 10, (V[]){v_st_241, v_t_242, v_x_245, v_n_2412, v_x_2422, v_hd_2415, v_x_2417, v_prog_240, v_next_244, v_k_2416})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_t_2414 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_n_2412 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s495635622x733177935(v_t_2414, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1370600575x2126186975_lam4, 1, 8, (V[]){v_st_241, v_t_242, v_n_2412, v_hd_2415, v_x_245, v_prog_240, v_next_244, v_k_2416})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_str0, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380(V v_prog_240, V v_st_241, V v_t_242, V v_progs_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_prog_240);
    heff_drop(v_t_242);
    heff_drop(v_progs_243);
    return ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam0_clo);
  }
  case TAG_Just: {
    V v_home_247 = heff_field(v_x5_244, 0);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_243)));
    V v_xs_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_total_2410 = (g_list_2efoldl_24f1425140065x1254143828(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_xs_249));
    V v_t_2412 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_str0), heff_dup(v_home_247)), v_total_2410, ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam1_clo)});
    V v_t_2413 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2412}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam2, 2, 6, (V[]){v_t_2413, v_prog_240, v_progs_243, heff_dup(v_st_241), v_t_242, heff_dup(v_home_247)});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380(a[0], a1, a[2], a[3], a4); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_a_246 = args[1];
  heff_drop(v_a_245);
  V f_ = v_a_246;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam1(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2424);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam4(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_t_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_co_2eop_24s495635622x733177935(v_t_2418, v_hd_2422, heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam5, 1, 1, (V[]){v_k_2423})));
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_progs_243 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_home_247 = heff_env(self)[4];
  V v_hd_2414 = heff_env(self)[5];
  V v_k_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2417 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2416), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2417}));
  V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_243));
  V v_xs_2420 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_t_2421 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2420));
  V v_t_2425 = ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_home_247; V a_4 = v_x_2416; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam4, 2, 1, (V[]){v_t_2418}); V a_6 = v_t_2421; V r_ = (g_heff_2ebuild_2ecommands_2eshipAll_24s1757241500x34779154(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_241); heff_drop(v_t_2421); r_; });
  V f_ = v_t_2425;
  heff_room[0] = v_hd_2414;
  heff_room[1] = v_k_2415;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_t_2413 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_progs_243 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_home_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_co_2eop_24s495635622x733177935(v_t_2413, heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1892160566x1816248380_lam3, 1, 7, (V[]){v_prog_240, v_progs_243, v_st_241, v_t_242, v_home_247, v_hd_2414, v_k_2415})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_str1, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_str3, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_str4, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_str6, 3, "src");
V g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406(V v_rep_240, V v_v_241, V v_l_242, V v_pk_243, V v_z_244, V v_z_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(heff_rfield(v_pk_243, 0)), heff_dup(v_v_241)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_rep_240);
      heff_drop(v_v_241);
      heff_drop_rec(v_l_242, 5);
      V v_why_2410 = v_field_248;
      V v_t_2411 = heff_strAppend(heff_get_n(v_pk_243, 0, 4), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_str0), v_why_2410));
      V v_t_2412 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_str1), v_t_2411), ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_str2));
      V v_t_2413 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_lam0, 1, 2, (V[]){v_z_244, v_z_245})));
    } else {
      heff_drop(v_field_248);
      V v_st_2428 = heff_get_n(heff_dup(heff_rfield(v_l_242, 2)), 5, 6);
      V v_t_2429 = heff_get_n(heff_dup(heff_rfield(v_l_242, 2)), 0, 6);
      V v_t_2430 = (g_std_2epath_2eparse(v_st_2428, v_t_2429));
      V v_t_2431 = (g_std_2epath_2eparse(v_st_2428, ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_str3)));
      V v_t_2432 = (g_std_2epath_2ejoin(v_t_2430, v_t_2431));
      V v_t_2433 = ({ V a_0 = v_st_2428; V a_1 = v_t_2432; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2428); heff_drop(v_t_2432); r_; });
      V v_c_2434 = (g_heff_2ebuild_2eload_2eownDir_24s478002771x576026510(heff_dup(heff_rfield(v_l_242, 2)), v_t_2433));
      return heff_tail(v_c_2434, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_lam1, 1, 6, (V[]){v_z_244, v_z_245, v_l_242, v_rep_240, v_v_241, v_pk_243})});
    }
  }
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2420);
  V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_lam2(V self, V *args) {
  V v_x_2445 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2445);
  V v_t_2446 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_lam1(V self, V *args) {
  V v_x_2435 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_l_242 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_v_241 = heff_env(self)[4];
  V v_pk_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2435)) {
  case TAG_Left: {
    V v_why_2436 = heff_field(v_x_2435, 0);
    V v_ru_24x_2435_24Left = heff_take_reuse_n(v_x_2435, 1ULL, 1);
    heff_drop_rec(v_l_242, 5);
    heff_drop(v_rep_240);
    heff_drop(v_v_241);
    heff_drop_rec(v_pk_243, 4);
    V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_str4), v_why_2436), ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_str5));
    V v_t_2438 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2437, NTAG(TAG_MkUnit)});
    V v_t_2439 = heff_tag_at_n(v_ru_24x_2435_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_lam2, 1, 2, (V[]){v_z_244, v_z_245})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2435, 0ULL, 1);
    V v_st_2454 = heff_get_n(heff_dup(heff_rfield(v_l_242, 2)), 5, 6);
    V v_t_2455 = heff_get_n(heff_get_n(v_l_242, 2, 5), 0, 6);
    V v_t_2456 = (g_std_2epath_2eparse(v_st_2454, v_t_2455));
    V v_t_2457 = (g_std_2epath_2eparse(v_st_2454, ((V)&g_heff_2ebuild_2ecommands_2epublishChecked_24s758972048x288033406_str6)));
    V v_t_2458 = (g_std_2epath_2ejoin(v_t_2456, v_t_2457));
    V v_t_2459 = ({ V a_0 = v_st_2454; V a_1 = v_t_2458; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2454); heff_drop(v_t_2458); r_; });
    return (g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552(v_rep_240, v_v_241, v_pk_243, v_t_2459, v_z_244, v_z_245));
  }
  default: return heff_nomatch(v_x_2435);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_str0, 14, "heff version: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2eownPackage_24s1928707501x1564512060(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_lam1(V self, V *args) {
  V v_t_245 = args[0];
  return v_t_245;
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2434}), v_hd_240, v_k_241));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2414 = ({ V a_0 = v_x_242; V a_1 = v_x_2413; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2eversionSaid_24cpr(a_0, a_1)); heff_drop(v_x_2413); r_; });
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_why_2418 = v_field_2416;
      V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_str0), v_why_2418), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_str1));
      V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2419, NTAG(TAG_MkUnit)});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
    } else {
      V v_line_2435 = v_field_2416;
      V v_t_2436 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_line_2435, ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_str2)), NTAG(TAG_MkUnit)});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_hd_240, v_k_241));
    }
  }
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_path_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_242); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_243; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_243); r_; });
  V v_a_246 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_lam1_clo)});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s495635622x733177935(v_t_2412, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s1900294235x2044946098_lam2, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})));
}