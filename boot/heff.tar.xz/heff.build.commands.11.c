// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_ErrColor 60683
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Value 50841
#define TAG_Windows 49101
#define TAG_WorkingDir 28879
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_backend 2032133329
#define LBL_copies 592412158
#define LBL_diags 296935042
#define LBL_discarded 1490202606
#define LBL_effect 641056956
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failure 1292767177
#define LBL_globals 352931696
#define LBL_goldens 436112074
#define LBL_hashes 722717031
#define LBL_key 315609
#define LBL_labels 836724522
#define LBL_limit 304334805
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_outcome 1272833429
#define LBL_owner 307523277
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_place 308106529
#define LBL_property 1899481104
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_run 322821
#define LBL_runs 10007567
#define LBL_said 10017968
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_source 1050636102
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_units 312791945
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_owner__place__outcome__next[] = {LBL_owner, LBL_place, LBL_outcome, LBL_next};
static uint32_t shape_units__copies[] = {LBL_units, LBL_copies};
V g_co_2eop_24s903439140x919002362(V, V, V);
V g_co_2eop_24s903439140x919002362_entry(V self, V *a);
extern Clo g_co_2eop_24s903439140x919002362_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_clo;
V g_heff_2ebuild_2ecommands_2ebuildText_get(void);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_clo;
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055_clo;
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113(V, V, V);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_clo;
V g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_clo;
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_clo;
V g_heff_2ebuild_2ecommands_2elastLines(V, V);
V g_heff_2ebuild_2ecommands_2elastLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elastLines_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(V);
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V, V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson(V, V);
V g_heff_2ebuild_2ecommands_2eoutcomeOfJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eoutcomeOfJson_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeVariable_get(void);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_clo;
V g_heff_2ebuild_2ecommands_2eranOutcome(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eranOutcome_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranOutcome_clo;
V g_heff_2ebuild_2ecommands_2eranSubtests(V);
V g_heff_2ebuild_2ecommands_2eranSubtests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranSubtests_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_clo;
V g_heff_2ebuild_2ecommands_2esubtestJobs(V, V, V, V);
V g_heff_2ebuild_2ecommands_2esubtestJobs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esubtestJobs_clo;
V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109(V, V, V);
V g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109_clo;
V g_heff_2ebuild_2ecommands_2etestsSaid(V);
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo;
V g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099(V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099_clo;
V g_heff_2ebuild_2eproject_2ecompatible(V, V);
V g_heff_2ebuild_2eproject_2ecompatible_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ecompatible_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ecompile_2eemit_2ecompileProgramKept(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ecompileProgramKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileProgramKept_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2erenderDiag(V, V, V);
V g_heff_2elsp_2erender_2erenderDiag_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erenderDiag_clo;
HeffT2 g_json_2esteps_24cpr(V, V);
V g_list_2efoldl_24f1189266312x1583313228(V, V, V);
V g_list_2efoldl_24f1189266312x1583313228_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1189266312x1583313228_clo;
V g_list_2efoldl_24f1824632076x1202317442(V, V, V);
V g_list_2efoldl_24f1824632076x1202317442_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1824632076x1202317442_clo;
V g_list_2efoldl_24f556306710x2087456230(V, V, V, V);
V g_list_2efoldl_24f556306710x2087456230_entry(V self, V *a);
extern Clo g_list_2efoldl_24f556306710x2087456230_clo;
V g_list_2efoldl_24s1002907040x997927369(V, V);
V g_list_2efoldl_24s1002907040x997927369_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1002907040x997927369_clo;
V g_list_2efoldl_24s1022228162x792599878(V, V);
V g_list_2efoldl_24s1022228162x792599878_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1022228162x792599878_clo;
V g_list_2efoldl_24s1032373580x351779613(V, V);
V g_list_2efoldl_24s1032373580x351779613_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1032373580x351779613_clo;
V g_list_2efoldl_24s489050722x1368997552(V, V);
V g_list_2efoldl_24s489050722x1368997552_entry(V self, V *a);
extern Clo g_list_2efoldl_24s489050722x1368997552_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s753718309x1738270184(V, V);
V g_list_2efoldl_24s753718309x1738270184_entry(V self, V *a);
extern Clo g_list_2efoldl_24s753718309x1738270184_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s2029274225x672412636(V, V, V, V);
V g_list_2emap_24s2029274225x672412636_entry(V self, V *a);
extern Clo g_list_2emap_24s2029274225x672412636_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_list_2esortBy_24s492793466x2081132734(V);
V g_list_2esortBy_24s492793466x2081132734_entry(V self, V *a);
extern Clo g_list_2esortBy_24s492793466x2081132734_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enormalize(V, V);
V g_std_2epath_2enormalize_entry(V self, V *a);
extern Clo g_std_2epath_2enormalize_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str0, 2, "0.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str1, 15, " (the same 0.x)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str3, 19, ", and this heff is ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str4, 13, " is for heff ");

HeffT2 g_heff_2ebuild_2ecommands_2eheffVersions_24cpr(V v_who_240, V v_wanted_241, V v_running_242, V v_x4_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_who_240);
    heff_drop(v_wanted_241);
    heff_drop(v_running_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_w_245 = heff_field(v_x4_243, 0);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nothing: {
      heff_drop(v_who_240);
      heff_drop(v_wanted_241);
      heff_drop(v_running_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_r_246 = heff_field(v_x5_244, 0);
      V v_t_247 = (g_heff_2ebuild_2eproject_2ecompatible(v_w_245, v_r_246));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_who_240);
        heff_drop(v_wanted_241);
        heff_drop(v_running_242);
        heff_drop(v_t_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        heff_drop(v_t_247);
        V v_t_249;
        if (heff_strEq_c(heff_strSlice_lent(v_wanted_241, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str0))) {
          v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str1);
        } else {
          v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str2);
        }
        V v_t_2410 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str3), v_running_242));
        V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffVersions_24cpr_str4), heff_strAppend(v_wanted_241, v_t_2410));
        V v_f_2412 = heff_strAppend(v_who_240, v_t_2411);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x5_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
Clo g_heff_2ebuild_2ecommands_2enubStrGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2enubStrGo_24dps(V v_seen_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2ecommands_2eelemStrM(v_x_243, v_seen_240));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_seen_240;
      V t_1 = v_rest_244;
      V t_2 = v_d_242;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_seen_240});
      V t_1 = v_rest_244;
      V t_2 = v_cell_246;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2enubStrGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enubStrGo_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str2, 8, " skipped");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str3, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsSaid_str5, 8, ", tests ");
Clo g_heff_2ebuild_2ecommands_2etestsSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2etestsSaid(V v_os_240) {
top: ;
  switch (heff_tag_of(v_os_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str0);
  }
  case TAG_Cons: {
    V v_t_243 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_244 = (g_list_2efoldl_24f1189266312x1583313228(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_245 = (g_list_2efoldl_24f1824632076x1202317442(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_246 = heff_intSub(heff_intSub(v_t_243, v_t_244), v_t_245);
    V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_n_248 = (g_list_2efoldl_24f1824632076x1202317442(MK_INT(1LL), MK_INT(0LL), v_os_240));
    V v_t_2411;
    if (heff_intEq_c_lent(v_n_248, MK_INT(0LL), 2)) {
      heff_drop(v_n_248);
      v_t_2411 = ((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str1);
    } else {
      V v_t_2410 = heff_strAppend(heff_intShow(v_n_248), ((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str2));
      v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str3), v_t_2410);
    }
    V v_t_2412 = heff_strAppend(heff_intShow(v_t_247), v_t_2411);
    V v_t_2413 = heff_strAppend(heff_intShow(v_t_246), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str4), v_t_2412));
    return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestsSaid_str5), v_t_2413);
  }
  default: return heff_nomatch(v_os_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestsSaid_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2etestsSaid(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eoutcomeVariable_str0, 17, "HEFF_TEST_OUTCOME");

static V g_heff_2ebuild_2ecommands_2eoutcomeVariable_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2eoutcomeVariable_st;
static V g_heff_2ebuild_2ecommands_2eoutcomeVariable_init(void) {
  return ((V)&g_heff_2ebuild_2ecommands_2eoutcomeVariable_str0);
}
V g_heff_2ebuild_2ecommands_2eoutcomeVariable_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2eoutcomeVariable_st)) return g_heff_2ebuild_2ecommands_2eoutcomeVariable_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2eoutcomeVariable_val, &g_heff_2ebuild_2ecommands_2eoutcomeVariable_st, g_heff_2ebuild_2ecommands_2eoutcomeVariable_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str0, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str1, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str2, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str3, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str6, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str7, 33, ", and said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str8, 3, "it ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str9, 45, "what it said of how it went could not be read");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str10, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str11, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str12, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str13, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str16, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str17, 33, ", and said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str18, 3, "it ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str19, 45, "what it said of how it went could not be read");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str20, 11, " ms: killed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str21, 33, "took longer than its time limit, ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str22, 12, "exited with ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str23, 20, "ended by the signal ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str24, 24, "killed at its time limit");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str25, 7, "not run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str27, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str28, 2, ":\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str29, 33, ", and said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str30, 3, "it ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranOutcome_str31, 45, "what it said of how it went could not be read");
Clo g_heff_2ebuild_2ecommands_2eranOutcome_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranOutcome_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eranOutcome(V v_name_240, V v_limit_241, V v_r_242, V v_said_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_r_242, 0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Exited: {
    V v_ru_24t_244_24Exited = heff_take_reuse_n(v_t_244, 0ULL, 1);
    heff_drop(v_limit_241);
    switch (heff_tag_of(v_said_243)) {
    case TAG_Nothing: {
      V v_t_246 = heff_take_field(v_r_242, 0);
      V v_t_249;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Exited: {
        V v_n_247 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str0), heff_intShow(v_n_247));
        break;
      }
      case TAG_Signalled: {
        V v_n_248 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str1), heff_intShow(v_n_248));
        break;
      }
      case TAG_TimedOut: {
        v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str2);
        break;
      }
      case TAG_NotRun: {
        v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str3);
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      V v_t_2412;
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_242, 2)), ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str4))) {
        heff_drop_rec(v_r_242, 3);
        v_t_2412 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str5);
      } else {
        V v_t_2411 = ({ V a_0 = MK_INT(20LL); V b_1 = heff_get_n(v_r_242, 2, 3); V r_ = (g_heff_2ebuild_2ecommands_2elastLines(a_0, b_1)); heff_drop(b_1); r_; });
        v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str6), v_t_2411);
      }
      V v_t_2413 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str7), v_t_2412));
      V v_why_2414 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str8), v_t_2413);
      V v_t_2415 = heff_tag_at_n(v_ru_24t_244_24Exited, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2414})});
      return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2415, MK_INT(0LL), NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_text_2416 = heff_field(v_said_243, 0);
      heff_take_n(v_said_243, 1ULL, 1);
      heff_drop_rec(v_r_242, 3);
      V v_t_2417 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2418 = ({ V a_0 = v_text_2416; V a_1 = v_t_2417; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_text_2416); r_; });
      {
        V v_field_2420 = v_t_2418.f[1];
        int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
        if ((v_tag_2419 == ((int64_t)0ULL))) {
          V v_why_2422 = v_field_2420;
          heff_drop(v_why_2422);
          V v_t_2423 = heff_tag_at_n(v_ru_24t_244_24Exited, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str9)})});
          return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2423, MK_INT(0LL), NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24t_244_24Exited, 1);
          V v_j_2424 = v_field_2420;
          return (g_heff_2ebuild_2ecommands_2eoutcomeOfJson(v_name_240, v_j_2424));
        }
      }
    }
    default: return heff_nomatch(v_said_243);
    }
  }
  case TAG_Signalled: {
    V v_ru_24t_244_24Signalled = heff_take_reuse_n(v_t_244, 0ULL, 1);
    heff_drop(v_limit_241);
    switch (heff_tag_of(v_said_243)) {
    case TAG_Nothing: {
      V v_t_2426 = heff_take_field(v_r_242, 0);
      V v_t_2429;
      switch (heff_tag_of(v_t_2426)) {
      case TAG_Exited: {
        V v_n_2427 = heff_field(v_t_2426, 0);
        heff_take_n(v_t_2426, 1ULL, 1);
        v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str10), heff_intShow(v_n_2427));
        break;
      }
      case TAG_Signalled: {
        V v_n_2428 = heff_field(v_t_2426, 0);
        heff_take_n(v_t_2426, 1ULL, 1);
        v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str11), heff_intShow(v_n_2428));
        break;
      }
      case TAG_TimedOut: {
        v_t_2429 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str12);
        break;
      }
      case TAG_NotRun: {
        v_t_2429 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str13);
        break;
      }
      default: heff_nomatch(v_t_2426);
      }
      V v_t_2432;
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_242, 2)), ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str14))) {
        heff_drop_rec(v_r_242, 3);
        v_t_2432 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str15);
      } else {
        V v_t_2431 = ({ V a_0 = MK_INT(20LL); V b_1 = heff_get_n(v_r_242, 2, 3); V r_ = (g_heff_2ebuild_2ecommands_2elastLines(a_0, b_1)); heff_drop(b_1); r_; });
        v_t_2432 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str16), v_t_2431);
      }
      V v_t_2433 = heff_strAppend(v_t_2429, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str17), v_t_2432));
      V v_why_2434 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str18), v_t_2433);
      V v_t_2435 = heff_tag_at_n(v_ru_24t_244_24Signalled, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2434})});
      return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2435, MK_INT(0LL), NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_text_2436 = heff_field(v_said_243, 0);
      heff_take_n(v_said_243, 1ULL, 1);
      heff_drop_rec(v_r_242, 3);
      V v_t_2437 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2438 = ({ V a_0 = v_text_2436; V a_1 = v_t_2437; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_text_2436); r_; });
      {
        V v_field_2440 = v_t_2438.f[1];
        int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
        if ((v_tag_2439 == ((int64_t)0ULL))) {
          V v_why_2442 = v_field_2440;
          heff_drop(v_why_2442);
          V v_t_2443 = heff_tag_at_n(v_ru_24t_244_24Signalled, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str19)})});
          return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2443, MK_INT(0LL), NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24t_244_24Signalled, 1);
          V v_j_2444 = v_field_2440;
          return (g_heff_2ebuild_2ecommands_2eoutcomeOfJson(v_name_240, v_j_2444));
        }
      }
    }
    default: return heff_nomatch(v_said_243);
    }
  }
  case TAG_TimedOut: {
    heff_drop_rec(v_r_242, 3);
    heff_drop(v_said_243);
    V v_t_2445 = heff_strAppend(heff_intShow(v_limit_241), ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str20));
    V v_t_2446 = heff_tag_n(TAG_FailBecause, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str21), v_t_2445)});
    return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_tag_n(TAG_Just, 1, (V[]){v_t_2446}), MK_INT(0LL), NTAG(TAG_Nil)});
  }
  case TAG_NotRun: {
    heff_drop(v_limit_241);
    switch (heff_tag_of(v_said_243)) {
    case TAG_Nothing: {
      V v_t_2447 = heff_take_field(v_r_242, 0);
      V v_t_2450;
      switch (heff_tag_of(v_t_2447)) {
      case TAG_Exited: {
        V v_n_2448 = heff_field(v_t_2447, 0);
        heff_take_n(v_t_2447, 1ULL, 1);
        v_t_2450 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str22), heff_intShow(v_n_2448));
        break;
      }
      case TAG_Signalled: {
        V v_n_2449 = heff_field(v_t_2447, 0);
        heff_take_n(v_t_2447, 1ULL, 1);
        v_t_2450 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str23), heff_intShow(v_n_2449));
        break;
      }
      case TAG_TimedOut: {
        v_t_2450 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str24);
        break;
      }
      case TAG_NotRun: {
        v_t_2450 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str25);
        break;
      }
      default: heff_nomatch(v_t_2447);
      }
      V v_t_2453;
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_242, 2)), ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str26))) {
        heff_drop_rec(v_r_242, 3);
        v_t_2453 = ((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str27);
      } else {
        V v_t_2452 = ({ V a_0 = MK_INT(20LL); V b_1 = heff_get_n(v_r_242, 2, 3); V r_ = (g_heff_2ebuild_2ecommands_2elastLines(a_0, b_1)); heff_drop(b_1); r_; });
        v_t_2453 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str28), v_t_2452);
      }
      V v_t_2454 = heff_strAppend(v_t_2450, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str29), v_t_2453));
      V v_why_2455 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str30), v_t_2454);
      V v_t_2456 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2455})});
      return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2456, MK_INT(0LL), NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_text_2457 = heff_field(v_said_243, 0);
      V v_ru_24said_243_24Just = heff_take_reuse_n(v_said_243, 1ULL, 1);
      heff_drop_rec(v_r_242, 3);
      V v_t_2458 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2459 = ({ V a_0 = v_text_2457; V a_1 = v_t_2458; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_text_2457); r_; });
      {
        V v_field_2461 = v_t_2459.f[1];
        int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
        if ((v_tag_2460 == ((int64_t)0ULL))) {
          V v_why_2463 = v_field_2461;
          heff_drop(v_why_2463);
          V v_t_2464 = heff_tag_at_n(v_ru_24said_243_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eranOutcome_str31)})});
          return heff_rec_n(12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, (V[]){v_name_240, NTAG(TAG_False), NTAG(TAG_Nothing), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2464, MK_INT(0LL), NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24said_243_24Just, 1);
          V v_j_2465 = v_field_2461;
          return (g_heff_2ebuild_2ecommands_2eoutcomeOfJson(v_name_240, v_j_2465));
        }
      }
    }
    default: return heff_nomatch(v_said_243);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ebuild_2ecommands_2eranOutcome_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eranOutcome(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str1, 13, "build : Build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str2, 37, "build = { backend = C, run = \"main\" }");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str3, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str5, 21, "-- heff home with it.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str7, 69, "-- page's script of it.  A field `ships = [...]` would name files and");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str8, 69, "-- directories of the project's root for `heff install` to put in the");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildText_str10, 69, "-- main.hf's `main`, compiled through C (by `zig cc`); `Page` makes a");

static V g_heff_2ebuild_2ecommands_2ebuildText_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2ebuildText_st;
static V g_heff_2ebuild_2ecommands_2ebuildText_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildText_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2ebuildText_str9); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2ebuildText_str10); V a_2 = v_t_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildText_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2ebuildText_st)) return g_heff_2ebuild_2ecommands_2ebuildText_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2ebuildText_val, &g_heff_2ebuild_2ecommands_2ebuildText_st, g_heff_2ebuild_2ecommands_2ebuildText_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_str1, 10, "package.hf");
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s94900133x232571340(v_t_248, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return v_s_242;
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  return v_s_2412;
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_st_2411 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2411, v_x_2419));
  V v_x_2421 = ({ V a_0 = v_st_2411; V a_1 = v_t_2420; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_str1); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2411); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_st_2411;
  if (heff_strEq_c(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_str0))) {
    v_st_2411 = NTAG(TAG_Windows);
  } else {
    v_st_2411 = NTAG(TAG_Posix);
  }
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam2_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s94900133x232571340(v_t_2418, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_lam3, 1, 2, (V[]){v_st_2411, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_str1, 2, "\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_str3, 0, "");
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ErrColor, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam0_clo)})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    HEFF_LAST return g_co_2eop_24s94900133x232571340(v_t_2410, heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam1, 1, 4, (V[]){v_c_243, v_p_241, v_rest_244, v_p_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam0(V self, V *args) {
  V v_b_245 = args[0];
  return v_b_245;
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam3(V self, V *args) {
  V v_d_2418 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_src_2417 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = (g_heff_2elsp_2erender_2ediagWhere(heff_get_n(v_c_243, 1, 14), v_src_2417, heff_dup(v_d_2418)));
  V v_t_2420 = ({ V a_0 = v_x_2411; V a_1 = v_src_2417; V a_2 = v_d_2418; V r_ = (g_heff_2elsp_2erender_2erenderDiag(a_0, a_1, a_2)); heff_drop(v_x_2411); heff_drop(v_src_2417); r_; });
  V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_str0), heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_str1)));
  return heff_strAppend(v_t_2419, v_t_2421);
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2433);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(v_rest_244, v_p_241, v_p_242));
}
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_dup(heff_rfield(v_c_243, 6));
  V v_c_2432;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nil: {
    heff_drop(v_x_2411);
    heff_drop_rec(v_c_243, 14);
    v_c_2432 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam2_clo);
    break;
  }
  case TAG_Cons: {
    V v_ru_24t_2412_24Cons = heff_take_reuse_n(v_t_2412, 0ULL, 2);
    V v_src_2417 = heff_dup(heff_rfield(v_c_243, 3));
    V v_x2_2422 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam3, 1, 3, (V[]){heff_dup(v_c_243), v_src_2417, v_x_2411}), heff_get_n(v_c_243, 6, 14)));
    V v_str_2425;
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      v_str_2425 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      v_str_2425 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_str3); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2422);
    }
    V v_t_2426 = heff_tag_at_n(v_ru_24t_2412_24Cons, TAG_WriteErr, 2, (V[]){v_str_2425, NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    v_c_2432 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})}));
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V f_ = v_c_2432;
  heff_room[0] = heff_dup(v_p_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_lam4, 1, 3, (V[]){v_rest_244, v_p_241, v_p_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_str1, 3, ".hb");
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278(V v_ps_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_ps_240, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_d_246 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_str0)));
    V v_d_247 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_246, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
    V v_path_248 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_247, heff_strAppend(heff_dup(v_m_244), ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_str1))));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam1, 2, 4, (V[]){v_path_248, v_ps_240, v_rest_245, v_m_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam2(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_m_244 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2421;
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nothing: {
    heff_drop(v_m_244);
    v_t_2421 = v_x_2419;
    break;
  }
  case TAG_Just: {
    V v_text_2420 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_244, v_text_2420}), v_x_2419});
    break;
  }
  default: heff_nomatch(v_x_2417);
  }
  V f_ = v_k_2410;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_m_244 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2418 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278(v_ps_240, v_rest_245));
  V f_ = v_c_2418;
  heff_room[0] = v_hd_249;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam4, 1, 3, (V[]){v_x_2417, v_m_244, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_path_248 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_m_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_248, ((V)&g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278_lam3, 1, 5, (V[]){v_ps_240, v_rest_245, v_hd_249, v_m_244, v_k_2410})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_str0, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_str1, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_str2, 3, " / ");
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011(V v_sel_240, V v_j_241, V v_dir_242, V v_ran_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_dir_242), ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam1, 1, 6, (V[]){v_dir_242, v_hd_244, v_j_241, v_ran_243, heff_dup(v_sel_240), v_k_245})));
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam0(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam4(V self, V *args) {
  V v_ok_2421 = args[0];
  return v_ok_2421;
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_j_241 = heff_env(self)[0];
  V v_ran_243 = heff_env(self)[1];
  V v_x_2420 = heff_env(self)[2];
  V v_sel_240 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2428);
  V v_t_2429 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_str2), heff_dup(heff_rfield(v_j_241, 3)), heff_rfield(v_j_241, 4)));
  V v_t_2430 = (g_heff_2ebuild_2ecommands_2eranOutcome(v_t_2429, heff_dup(heff_rfield(v_j_241, 5)), v_ran_243, heff_dup(v_x_2420)));
  V v_t_2431 = ({ V a_0 = v_x_2420; V r_ = (g_heff_2ebuild_2ecommands_2eranSubtests(a_0)); heff_drop(v_x_2420); r_; });
  V v_t_2432 = ({ V a_0 = v_sel_240; V a_1 = heff_dup(v_j_241); V a_2 = MK_INT(0LL); V a_3 = v_t_2431; V r_ = (g_heff_2ebuild_2ecommands_2esubtestJobs(a_0, a_1, a_2, a_3)); heff_drop(v_sel_240); r_; });
  V v_x_2433 = heff_rec_n(4, shape_owner__place__outcome__next, (V[]){heff_take_field(v_j_241, 0), heff_get_n(v_j_241, 2, 6), v_t_2430, v_t_2432});
  V f_ = v_k_245;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_dir_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_j_241 = heff_env(self)[2];
  V v_ran_243 = heff_env(self)[3];
  V v_sel_240 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2422 = heff_tag_n(TAG_Remove, 2, (V[]){heff_strAppend(v_dir_242, ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_str1)), ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam4_clo)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s94900133x232571340(v_t_2427, v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam5, 1, 5, (V[]){v_j_241, v_ran_243, v_x_2420, v_sel_240, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_dir_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_j_241 = heff_env(self)[2];
  V v_ran_243 = heff_env(self)[3];
  V v_sel_240 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2412);
  V v_t_2414 = heff_tag_n(TAG_ReadFile, 2, (V[]){heff_strAppend(heff_dup(v_dir_242), ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_str0)), ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam2_clo)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s94900133x232571340(v_t_2419, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eendedJob_24s1445416190x2145613011_lam3, 1, 6, (V[]){v_dir_242, v_hd_244, v_j_241, v_ran_243, v_sel_240, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965(V v_bi_240, V v_outPath_241, V v_done_242, V v_c_243, V v_available_244, V v_r_245, V v_hd_246, V v_k_247) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s1993165373x567953502(heff_dup(heff_rfield(v_bi_240, 0)), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_lam0, 1, 8, (V[]){v_bi_240, v_hd_246, v_c_243, v_available_244, v_r_245, v_outPath_241, v_done_242, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  V v_available_244 = heff_env(self)[2];
  V v_r_245 = heff_env(self)[3];
  V v_bi_240 = heff_env(self)[4];
  V v_outPath_241 = heff_env(self)[5];
  V v_done_242 = heff_env(self)[6];
  V v_hd_246 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2415 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_248, v_x_2414));
  V v_t_2416 = heff_get_n(heff_get_n(v_c_243, 5, 14), 0, 9);
  V v_m_2417 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_248, v_x_2414));
  V v_t_2418 = ({ V a_0 = v_m_2417; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2417); r_; });
  V v_bs_2419 = (g_list_2emap_24s1173914895x100384474(v_t_2418));
  V v_t_2420 = (g_list_2efoldl_24s1022228162x792599878(heff_dup(g_std_2emap_2eempty_get()), v_bs_2419));
  V v_t_2421 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_2419; V r_ = (g_list_2efoldl_24s1032373580x351779613(a_0, a_1)); heff_drop(v_bs_2419); r_; });
  V v_m_2422 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_248, v_x_2414));
  V v_t_2423 = ({ V a_0 = v_m_2422; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2422); r_; });
  V v_bs_2424 = (g_list_2emap_24s1173914895x100384474(v_t_2423));
  V v_t_2425 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_2424; V r_ = (g_list_2efoldl_24s753718309x1738270184(a_0, a_1)); heff_drop(v_bs_2424); r_; });
  V v_t_2426 = ({ V a_0 = v_available_244; V a_1 = v_t_2416; V a_2 = heff_take_field(v_r_245, 0); V a_3 = heff_get_n(v_r_245, 1, 2); V a_4 = heff_dup(heff_rfield(v_bi_240, 1)); V a_5 = heff_rec_n(2, shape_units__copies, (V[]){v_t_2420, v_t_2421}); V a_6 = v_t_2425; V r_ = (g_heff_2ecompile_2eemit_2ecompileProgramKept(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2425); r_; });
  return ({ V a_0 = v_bi_240; V a_1 = v_outPath_241; V a_2 = v_x_248; V a_3 = v_x_2414; V a_4 = v_t_2415; V a_5 = v_done_242; V a_6 = v_t_2426; V a_7 = v_hd_246; V a_8 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_x_2414); r_; });
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  V v_available_244 = heff_env(self)[3];
  V v_r_245 = heff_env(self)[4];
  V v_outPath_241 = heff_env(self)[5];
  V v_done_242 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2413;
  if (heff_strEq_c_lent(v_x_248, ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_str0), 2)) {
    v_c_2413 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_lam1_clo);
  } else {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_str1), heff_dup(heff_rfield(v_bi_240, 2))});
    v_c_2413 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s1886641896x1117535278(heff_dup(heff_rfield(v_bi_240, 0)), v_t_2412));
  }
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s1685137919x2104649965_lam2, 1, 9, (V[]){v_x_248, v_c_243, v_available_244, v_r_245, v_bi_240, v_outPath_241, v_done_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str3, 62, "heff get: package.hf does not read: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str4, 62, "heff get: package.hf does not read: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str5, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str8, 11, "the project");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str9, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str10, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str15, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str16, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str17, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str20, 8, "heff.sum");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str21, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str22, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str23, 8, "heff get");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str24, 27, " packages, heff.sum written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str25, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str26, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str27, 32, "heff get: cannot write heff.sum\012");
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam11, 2, 0};
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113(V v_prog_240, V v_z_241, V v_z_242) {
top: ;
  V v_c_243 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_clo);
  return heff_tail(v_c_243, 2, (V[]){heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam0, 1, 3, (V[]){v_z_241, v_z_242, v_prog_240})});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam2(V self, V *args) {
  V v_t_247 = args[0];
  return v_t_247;
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_z_241, v_z_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam5(V self, V *args) {
  V v_x_2446 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2446);
  V v_t_2447 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), v_z_241, v_z_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam7(V self, V *args) {
  V v_x_2464 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2464);
  V v_t_2465 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2470}), v_z_241, v_z_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam8(V self, V *args) {
  V v_by_2475 = args[0];
  V v_path_2476 = args[1];
  V v_v_2477 = args[2];
  V v_prog_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_root_2453 = heff_env(self)[2];
  V v_sums_2471 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2efetchedPkg_24s689019960x767081055(v_prog_240, v_x_246, v_root_2453, v_sums_2471, v_by_2475, v_path_2476, v_v_2477));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam11(V self, V *args) {
  V v_hd_2491 = args[0];
  V v_k_2492 = args[1];
  heff_drop(v_hd_2491);
  V f_ = v_k_2492;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam12(V self, V *args) {
  V v_ok_2498 = args[0];
  return v_ok_2498;
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam17(V self, V *args) {
  V v_x_24131 = args[0];
  V v_seen_24129 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_24131; V a_1 = v_seen_24129; V r_ = (g_list_2efoldl_24s1002907040x997927369(a_0, a_1)); heff_drop(v_seen_24129); r_; });
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam16(V self, V *args) {
  V v_x_24119 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_x_2479 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_intLt_c(MK_INT(0LL), v_x_24119)) {
    heff_drop(v_x_2479);
    V v_t_24121 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
    V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
    V v_t_24125 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24124})});
    V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24125})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24126}), v_z_241, v_z_242));
  } else {
    V v_seen_24129;
    switch (heff_tag_of(v_x_2479)) {
    case TAG_MkPair: {
      V v_x_24127 = heff_field(v_x_2479, 0);
      heff_take_n(v_x_2479, 1ULL, 2);
      v_seen_24129 = v_x_24127;
      break;
    }
    default: heff_nomatch(v_x_2479);
    }
    V v_t_24130 = (g_list_2efoldl_24s489050722x1368997552(NTAG(TAG_Nil), heff_dup(v_seen_24129)));
    V v_t_24132 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam17, 1, 1, (V[]){v_seen_24129}); V a_3 = v_t_24130; V r_ = (g_list_2efoldl_24f556306710x2087456230(a_0, a_1, a_2, a_3)); heff_drop(v_t_24130); r_; });
    V v_t_24133 = heff_strAppend(heff_intShow(v_t_24132), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str24));
    V v_str_24134 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str25), v_t_24133);
    V v_t_24135 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_24134, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str26)), NTAG(TAG_MkUnit)});
    V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
    V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
    V v_t_24138 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24137})});
    V v_t_24139 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24138})});
    V v_t_24140 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24139})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24140}), v_z_241, v_z_242));
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam15(V self, V *args) {
  V v_x_24118 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_x_2479 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str23), heff_get_n(v_x_24118, 1, 5), MK_INT(0LL), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam16, 1, 3, (V[]){v_z_241, v_z_242, v_x_2479})));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam18(V self, V *args) {
  V v_x_24147 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24147);
  V v_t_24148 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24149 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24148})});
  V v_t_24150 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24149})});
  V v_t_24151 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24150})});
  V v_t_24152 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24151})});
  V v_t_24153 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24152})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24153}), v_z_241, v_z_242));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam14(V self, V *args) {
  V v_x_24109 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_x_24105 = heff_env(self)[2];
  V v_x_2479 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_intLt_c(MK_INT(0LL), v_x_24109)) {
    heff_drop(v_x_24105);
    heff_drop(v_x_2479);
    V v_t_24111 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24111})});
    V v_t_24113 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
    V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
    V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
    V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24115})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24116}), v_z_241, v_z_242));
  } else {
    if ((heff_dup(v_x_24105) == NTAG(TAG_True))) {
      heff_drop(v_x_24105);
      V v_c_24117 = (g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str22)));
      V f_ = v_c_24117;
      heff_room[0] = heff_dup(v_z_241);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam15, 1, 3, (V[]){v_z_241, v_z_242, v_x_2479});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x_24105);
      heff_drop(v_x_2479);
      V v_t_24141 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str27), NTAG(TAG_MkUnit)});
      V v_t_24142 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24141})});
      V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
      V v_t_24144 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24143})});
      V v_t_24145 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24144})});
      V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24146}), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam18, 1, 2, (V[]){v_z_241, v_z_242})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam13(V self, V *args) {
  V v_x_24105 = args[0];
  V v_x_2479 = heff_env(self)[0];
  V v_z_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24108;
  switch (heff_tag_of(v_x_2479)) {
  case TAG_MkPair: {
    V v_y_24107 = heff_dup(heff_field(v_x_2479, 1));
    v_t_24108 = v_y_24107;
    break;
  }
  default: heff_nomatch(v_x_2479);
  }
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str21), v_t_24108, MK_INT(0LL), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam14, 1, 4, (V[]){v_z_241, v_z_242, v_x_24105, v_x_2479})));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam10(V self, V *args) {
  V v_x_2484 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_x_2479 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2485 = (g_list_2esortBy_24s492793466x2081132734(heff_dup(v_x_2484)));
  V v_x2_2486 = (g_list_2emap_24s2029274225x672412636(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str9), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str10), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str11), v_t_2485));
  V v_t_2489;
  switch (heff_tag_of(v_x2_2486)) {
  case TAG_Nil: {
    v_t_2489 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2487 = heff_field(v_x2_2486, 0);
    V v_xs_2488 = heff_field(v_x2_2486, 1);
    heff_take_n(v_x2_2486, 3ULL, 2);
    v_t_2489 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str13); V a_1 = v_x_2487; V a_2 = v_xs_2488; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2488); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2486);
  }
  V v_c_24104;
  if (heff_strEq_c(v_t_2489, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str14))) {
    heff_drop(v_x_2484);
    v_c_24104 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam11_clo);
  } else {
    V v_t_2493 = (g_list_2esortBy_24s492793466x2081132734(v_x_2484));
    V v_x2_2494 = (g_list_2emap_24s2029274225x672412636(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str15), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str16), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str17), v_t_2493));
    V v_str_2497;
    switch (heff_tag_of(v_x2_2494)) {
    case TAG_Nil: {
      v_str_2497 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2495 = heff_field(v_x2_2494, 0);
      V v_xs_2496 = heff_field(v_x2_2494, 1);
      heff_take_n(v_x2_2494, 3ULL, 2);
      v_str_2497 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str19); V a_1 = v_x_2495; V a_2 = v_xs_2496; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2496); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2494);
    }
    V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str20), v_str_2497, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam12_clo)})});
    V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
    V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
    V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
    V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
    v_c_24104 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24103})}));
  }
  V f_ = v_c_24104;
  heff_room[0] = heff_dup(v_z_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam13, 1, 3, (V[]){v_x_2479, v_z_241, v_z_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam9(V self, V *args) {
  V v_x_2479 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_root_2453 = heff_env(self)[1];
  V v_z_241 = heff_env(self)[2];
  V v_z_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2482;
  switch (heff_tag_of(v_x_2479)) {
  case TAG_MkPair: {
    V v_x_2480 = heff_dup(heff_field(v_x_2479, 0));
    v_t_2482 = v_x_2480;
    break;
  }
  default: heff_nomatch(v_x_2479);
  }
  V v_c_2483 = (g_heff_2ebuild_2ecommands_2esumsOf_24s698378557x2024332109(v_x_246, v_root_2453, v_t_2482));
  V f_ = v_c_2483;
  heff_room[0] = heff_dup(v_z_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam10, 1, 3, (V[]){v_z_241, v_x_2479, v_z_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam6(V self, V *args) {
  V v_x_2455 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_root_2453 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2455)) {
  case TAG_Left: {
    V v_why_2456 = heff_field(v_x_2455, 0);
    V v_ru_24x_2455_24Left = heff_take_reuse_n(v_x_2455, 1ULL, 1);
    heff_drop_rec(v_root_2453, 4);
    heff_drop(v_prog_240);
    heff_drop(v_x_246);
    V v_t_2457 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str5), v_why_2456), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str6));
    V v_t_2458 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2457, NTAG(TAG_MkUnit)});
    V v_t_2459 = heff_tag_at_n(v_ru_24x_2455_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
    V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2463}), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam7, 1, 2, (V[]){v_z_241, v_z_242})));
  }
  case TAG_Right: {
    V v_sums_2471 = heff_field(v_x_2455, 0);
    heff_take_n(v_x_2455, 1ULL, 1);
    V v_t_2473;
    if (heff_strEq_c(heff_dup(heff_rfield(v_root_2453, 0)), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str7))) {
      v_t_2473 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str8);
    } else {
      v_t_2473 = heff_dup(heff_rfield(v_root_2453, 0));
    }
    V v_t_2474 = (g_list_2emap_24s675147852x248982264(v_t_2473, heff_dup(heff_rfield(v_root_2453, 2))));
    V v_c_2478 = (g_heff_2ebuild_2eload_2eversionsGo_24s212599809x271458099(heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam8, 3, 4, (V[]){v_prog_240, heff_dup(v_x_246), heff_dup(v_root_2453), v_sums_2471}), heff_rfield(v_root_2453, 0), v_t_2474, NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V f_ = v_c_2478;
    heff_room[0] = heff_dup(v_z_241);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam9, 1, 4, (V[]){v_x_246, v_root_2453, v_z_241, v_z_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2455);
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    v_t_2415 = ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str2);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  HeffT2 v_t_2416 = ({ V a_0 = v_t_2415; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_t_2415); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      heff_drop(v_x_246);
      heff_drop(v_prog_240);
      V v_p_2420 = v_field_2418;
      heff_drop(v_p_2420);
      V v_t_2421 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str3), NTAG(TAG_MkUnit)});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam4, 1, 2, (V[]){v_z_241, v_z_242})));
    } else {
      V v_x_2434 = v_field_2418;
      HeffT2 v_t_2435 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2434));
      {
        V v_field_2437 = v_t_2435.f[1];
        int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
        if ((v_tag_2436 == ((int64_t)0ULL))) {
          heff_drop(v_x_246);
          heff_drop(v_prog_240);
          V v_x_2439 = v_field_2437;
          heff_drop(v_x_2439);
          V v_t_2440 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str4), NTAG(TAG_MkUnit)});
          V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
          V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
          V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
          V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
          V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
          return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2445}), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam5, 1, 2, (V[]){v_z_241, v_z_242})));
        } else {
          V v_root_2453 = v_field_2437;
          V v_c_2454 = (g_heff_2ebuild_2eload_2ereadSumAt_24s528813643x1739827053(heff_dup(v_x_246)));
          V f_ = v_c_2454;
          heff_room[0] = heff_dup(v_z_241);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam6, 1, 5, (V[]){v_z_241, v_z_242, v_root_2453, v_prog_240, v_x_246});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str1), ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_z_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam3, 1, 4, (V[]){v_z_241, v_z_242, v_x_246, v_prog_240})));
}
V g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(v_x_244, ((V)&g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_str0)));
  V f_ = v_c_245;
  heff_room[0] = heff_dup(v_z_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetAll_24s2021012992x1155286113_lam1, 1, 3, (V[]){v_z_241, v_z_242, v_prog_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str1, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str2, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str3, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str5, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str6, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str7, 20, "compiling for a page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str8, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str9, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str10, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str11, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str12, 3, ".js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str13, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str14, 7, "main.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str15, 12, "passed over ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str16, 32, ": a page's script, not a program");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str17, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam15(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam15, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam22(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam21(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam20(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225(V v_prog_240, V v_st_241, V v_t_242, V v_bp_243, V v_x_244, V v_a_245, V v_next_246) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_a_245, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str0))) {
    V v_t_249 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_243, heff_dup(v_x_244), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam0_clo)})}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam1, 2, 7, (V[]){v_t_249, v_prog_240, v_st_241, v_x_244, v_t_242, v_next_246, v_a_245});
  } else {
    V v_t_2437 = heff_dup(heff_rfield(v_t_242, 3));
    if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
      heff_drop(v_t_2437);
      V v_t_2439 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_bp_243, heff_dup(v_x_244), MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam10_clo)})}));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam11, 2, 7, (V[]){v_t_2439, v_prog_240, v_st_241, v_x_244, v_t_242, v_a_245, v_next_246});
    } else {
      heff_drop(v_st_241);
      heff_drop_rec(v_t_242, 6);
      heff_drop_rec(v_a_245, 3);
      heff_drop(v_t_2437);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam20, 2, 4, (V[]){v_x_244, v_bp_243, v_prog_240, v_next_246});
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam3(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_next_246 = heff_env(self)[0];
  V v_hd_2425 = heff_env(self)[1];
  V v_k_2426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2427);
  V f_ = v_next_246;
  heff_room[0] = v_hd_2425;
  heff_room[1] = v_k_2426;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam5(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_t_2424 = heff_env(self)[0];
  V v_next_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s94900133x232571340(v_t_2424, heff_dup(v_hd_2425), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam6, 1, 3, (V[]){v_next_246, v_hd_2425, v_k_2426})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam9(V self, V *args) {
  V v_x_2436 = args[0];
  V v_next_2428 = heff_env(self)[0];
  V v_hd_2434 = heff_env(self)[1];
  V v_k_2435 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2436);
  V f_ = v_next_2428;
  heff_room[0] = v_hd_2434;
  heff_room[1] = v_k_2435;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam8(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_t_2430 = heff_env(self)[0];
  V v_next_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s94900133x232571340(v_t_2430, heff_dup(v_hd_2434), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam9, 1, 3, (V[]){v_next_2428, v_hd_2434, v_k_2435})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam7(V self, V *args) {
  V v_x_2432 = args[0];
  V v_a_245 = heff_env(self)[0];
  V v_outPath_2419 = heff_env(self)[1];
  V v_file_2422 = heff_env(self)[2];
  V v_t_2430 = heff_env(self)[3];
  V v_next_2428 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_a_245, 1, 3)});
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622(MK_INT(1LL), v_x_2432, v_t_2433, v_outPath_2419, v_file_2422, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam8, 2, 2, (V[]){v_t_2430, v_next_2428}), v_hd_2410, v_k_2411));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_next_246 = heff_env(self)[5];
  V v_hd_2410 = heff_env(self)[6];
  V v_a_245 = heff_env(self)[7];
  V v_k_2411 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2416 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str2), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str3)));
  V v_p_2417 = (g_std_2epath_2ejoin(v_st_241, v_t_2416, heff_dup(v_x_244)));
  V v_t_2418 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_242, 0)), v_p_2417));
  V v_outPath_2419 = heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str4));
  V v_t_2420 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str5), heff_dup(v_x_244)));
  V v_p_2421 = (g_std_2epath_2ejoin(v_st_241, v_t_2420, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str6)));
  V v_file_2422 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_242, 0)), v_p_2421));
  V v_t_2423 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2412), NTAG(TAG_MkUnit)});
  V v_t_2424 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2423}));
  V v_next_2428 = heff_tr(g_heff_2ebuild_2ecommands_2ezigCc_24s652477639x618519716(heff_dup(v_prog_240), v_st_241, v_t_242, v_x_2412, v_x_244, heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam5, 2, 2, (V[]){v_t_2424, v_next_246})));
  V v_t_2429 = heff_tag_n(TAG_End, 2, (V[]){v_x_2415, NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2429}));
  V v_c_2431 = (g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(heff_dup(v_file_2422)));
  V f_ = v_c_2431;
  heff_room[0] = heff_dup(v_hd_2410);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam7, 1, 7, (V[]){v_a_245, v_outPath_2419, v_file_2422, v_t_2430, v_next_2428, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_next_246 = heff_env(self)[5];
  V v_a_245 = heff_env(self)[6];
  V v_k_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2412), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam3_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2414, heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam4, 1, 9, (V[]){v_st_241, v_x_244, v_t_242, v_x_2412, v_prog_240, v_next_246, v_hd_2410, v_a_245, v_k_2411})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_t_249 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_next_246 = heff_env(self)[5];
  V v_a_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s94900133x232571340(v_t_249, heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam2, 1, 8, (V[]){v_prog_240, v_hd_2410, v_st_241, v_x_244, v_t_242, v_next_246, v_a_245, v_k_2411})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam10(V self, V *args) {
  V v_t_2438 = args[0];
  return v_t_2438;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam13(V self, V *args) {
  V v_t_2443 = args[0];
  return v_t_2443;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam15(V self, V *args) {
  V v_ok_2449 = args[0];
  return v_ok_2449;
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam19(V self, V *args) {
  V v_x_2471 = args[0];
  V v_next_246 = heff_env(self)[0];
  V v_hd_2468 = heff_env(self)[1];
  V v_k_2469 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2471);
  V f_ = v_next_246;
  heff_room[0] = v_hd_2468;
  heff_room[1] = v_k_2469;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam18(V self, V *args) {
  V v_x_2470 = args[0];
  V v_t_2465 = heff_env(self)[0];
  V v_hd_2468 = heff_env(self)[1];
  V v_next_246 = heff_env(self)[2];
  V v_k_2469 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2470);
  return (g_co_2eop_24s94900133x232571340(v_t_2465, heff_dup(v_hd_2468), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam19, 1, 3, (V[]){v_next_246, v_hd_2468, v_k_2469})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam17(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  V v_t_2467 = heff_env(self)[0];
  V v_t_2465 = heff_env(self)[1];
  V v_next_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s94900133x232571340(v_t_2467, heff_dup(v_hd_2468), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam18, 1, 4, (V[]){v_t_2465, v_hd_2468, v_next_246, v_k_2469})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam16(V self, V *args) {
  V v_x_2455 = args[0];
  V v_a_245 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_x_2442 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_x_2445 = heff_env(self)[6];
  V v_next_246 = heff_env(self)[7];
  V v_hd_2440 = heff_env(self)[8];
  V v_k_2441 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2455);
  V v_t_2456 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_a_245, 1, 3)});
  V v_t_2457 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str10), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str11)));
  V v_p_2458 = (g_std_2epath_2ejoin(v_st_241, v_t_2457, heff_dup(v_x_244)));
  V v_t_2459 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_242, 0)), v_p_2458));
  V v_t_2460 = (g_std_2epath_2ejoin(v_st_241, v_t_2459, heff_strAppend(heff_dup(v_x_244), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str12))));
  V v_t_2461 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str13), v_x_244));
  V v_p_2462 = (g_std_2epath_2ejoin(v_st_241, v_t_2461, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str14)));
  V v_t_2463 = ({ V a_0 = v_st_241; V a_1 = heff_get_n(v_t_242, 0, 6); V a_2 = v_p_2462; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_241); r_; });
  V v_t_2464 = heff_tag_n(TAG_End, 2, (V[]){v_x_2442, NTAG(TAG_MkUnit)});
  V v_t_2465 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2464}));
  V v_t_2466 = heff_tag_n(TAG_End, 2, (V[]){v_x_2445, NTAG(TAG_MkUnit)});
  V v_t_2467 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2466}));
  V v_t_2472 = ({ V a_0 = v_t_2456; V a_1 = v_t_2460; V a_2 = v_t_2463; V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam17, 2, 3, (V[]){v_t_2467, v_t_2465, v_next_246}); V r_ = (g_heff_2ebuild_2ecommands_2ecompileThen_24s1283621183x1584650622(a_0, a_1, a_2, a_3)); heff_drop_tag(v_t_2456, 1); r_; });
  V f_ = v_t_2472;
  heff_room[0] = v_hd_2440;
  heff_room[1] = v_k_2441;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam14(V self, V *args) {
  V v_x_2445 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_hd_2440 = heff_env(self)[3];
  V v_a_245 = heff_env(self)[4];
  V v_x_2442 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_next_246 = heff_env(self)[7];
  V v_k_2441 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2446 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str8), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str9)));
  V v_p_2447 = (g_std_2epath_2ejoin(v_st_241, v_t_2446, heff_dup(v_x_244)));
  V v_path_2448 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_242, 0)), v_p_2447));
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_2448, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam15_clo)})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), heff_dup(v_hd_2440), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam16, 1, 10, (V[]){v_a_245, v_st_241, v_x_244, v_t_242, v_x_2442, v_prog_240, v_x_2445, v_next_246, v_hd_2440, v_k_2441})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam12(V self, V *args) {
  V v_x_2442 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_hd_2440 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_a_245 = heff_env(self)[5];
  V v_next_246 = heff_env(self)[6];
  V v_k_2441 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2444 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2442), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str7), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam13_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2444, heff_dup(v_hd_2440), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam14, 1, 9, (V[]){v_st_241, v_x_244, v_t_242, v_hd_2440, v_a_245, v_x_2442, v_prog_240, v_next_246, v_k_2441})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam11(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_t_2439 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_a_245 = heff_env(self)[5];
  V v_next_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s94900133x232571340(v_t_2439, heff_dup(v_hd_2440), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam12, 1, 8, (V[]){v_prog_240, v_hd_2440, v_st_241, v_x_244, v_t_242, v_a_245, v_next_246, v_k_2441})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam22(V self, V *args) {
  V v_x_2485 = args[0];
  V v_next_246 = heff_env(self)[0];
  V v_hd_2473 = heff_env(self)[1];
  V v_k_2474 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2485);
  V f_ = v_next_246;
  heff_room[0] = v_hd_2473;
  heff_room[1] = v_k_2474;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam21(V self, V *args) {
  V v_x_2482 = args[0];
  V v_bp_243 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_2473 = heff_env(self)[2];
  V v_next_246 = heff_env(self)[3];
  V v_k_2474 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2482);
  V v_t_2483 = heff_tag_n(TAG_Complete, 2, (V[]){v_bp_243, NTAG(TAG_MkUnit)});
  V v_t_2484 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2483}));
  return (g_co_2eop_24s94900133x232571340(v_t_2484, heff_dup(v_hd_2473), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam22, 1, 3, (V[]){v_next_246, v_hd_2473, v_k_2474})));
}
V g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam20(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k_2474 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_bp_243 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_next_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2475 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str15), heff_strAppend(v_x_244, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str16)));
  V v_t_2476 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2475, ((V)&g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_str17)), NTAG(TAG_MkUnit)});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2481}), heff_dup(v_hd_2473), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildApp_24s108678959x764856225_lam21, 1, 5, (V[]){v_bp_243, v_prog_240, v_hd_2473, v_next_246, v_k_2474})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str0, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str2, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str5, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str6, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str7, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524(V v_st_240, V v_t_241, V v_home_242, V v_dir_243, V v_next_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WorkingDir, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s94900133x232571340(v_t_2413, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam1, 1, 7, (V[]){heff_dup(v_st_240), v_home_242, v_dir_243, v_hd_245, v_t_241, v_next_244, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam2(V self, V *args) {
  V v_ok_2419 = args[0];
  return v_ok_2419;
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam4(V self, V *args) {
  V v_x_2434 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2434);
  V f_ = v_next_244;
  heff_room[0] = v_hd_245;
  heff_room[1] = v_k_246;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam5(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2444);
  V v_t_2445 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), v_hd_245, v_k_246));
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_next_244 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_dup(v_x_2425) == NTAG(TAG_True))) {
    heff_drop(v_x_2425);
    V v_path_2426 = ({ V a_0 = v_st_240; V a_1 = v_home_242; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str2); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
    V v_t_2427 = heff_strAppend(heff_get_n(v_t_241, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str3), v_path_2426));
    V v_t_2428 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str4)), NTAG(TAG_MkUnit)});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam4, 1, 3, (V[]){v_next_244, v_hd_245, v_k_246})));
  } else {
    heff_drop(v_x_2425);
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_next_244);
    V v_t_2435 = ({ V a_0 = v_st_240; V a_1 = v_home_242; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str5); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
    V v_why_2436 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str6), v_t_2435);
    V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str7), v_why_2436), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str8));
    V v_t_2438 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2437, NTAG(TAG_MkUnit)});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam5, 1, 2, (V[]){v_hd_245, v_k_246})));
  }
}
V g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_dir_243 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_next_244 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_path_2415 = (g_std_2epath_2ejoin(v_st_240, heff_dup(v_home_242), ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str0)));
  V v_t_2416 = (g_std_2epath_2ejoin(v_st_240, v_x_2414, v_dir_243));
  V v_t_2417 = (g_std_2epath_2enormalize(v_st_240, v_t_2416));
  V v_str_2418 = heff_strAppend(v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_str1));
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_2415, v_str_2418, ((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam2_clo)})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2esourceSaved_24s352682097x2054134524_lam3, 1, 6, (V[]){v_st_240, v_home_242, v_t_241, v_hd_245, v_next_244, v_k_246})));
}