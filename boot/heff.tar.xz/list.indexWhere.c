// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Flagged 28540
#define TAG_Many 40086
#define TAG_One 26866
#define TAG_Optional 11609
#define TAG_Picked 5619
#define TAG_Positional 16703
#define TAG_Rest 61983
#define TAG_Some 35658
#define TAG_Typed 36072
#define LBL_arity 294440695
#define LBL_input 301716452
#define LBL_part 9928890
#define LBL_required 351999471
#define LBL_text 10052084
HeffT2 g_list_2eindexWhere_2eindexFrom_240_24cpr(V, V, V);
HeffT2 g_list_2eindexWhere_2eindexFrom_240_24s1862090511x134883249_24cpr(V, V, V);
V g_list_2ekeepIf_24s2034497759x755284100(V, V);
V g_list_2ekeepIf_24s2034497759x755284100_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2034497759x755284100_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;

HeffT2 g_list_2eindexWhere_2eindexFrom_240_24cpr(V v_p_240, V v_i_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_242, 0);
    V v_ys_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_y_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_245);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
    } else {
      heff_drop(v_t_245);
      V t_0 = v_p_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_ys_244;
      v_p_240 = t_0;
      v_i_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_242)}});
  }
}
HEFF_LIT(g_list_2eindexWhere_2eindexFrom_240_24s1862090511x134883249_24cpr_str0, 0, "");

HeffT2 g_list_2eindexWhere_2eindexFrom_240_24s1862090511x134883249_24cpr(V v_lit_240, V v_i_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_242, 0);
    V v_ys_244 = heff_field(v_x2_242, 1);
    V v_fs_245 = heff_dup(v_lit_240);
    V v_s_246 = heff_dup(v_y_243);
    V v_part_247 = heff_take_field(v_s_246, 0);
    V v_input_248 = heff_get_n(v_s_246, 1, 2);
    V v_t_249 = v_part_247;
    V v_t_2426;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Positional: {
      V v_p_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      heff_drop(v_fs_245);
      V v_t_2411 = v_input_248;
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Typed: {
        V v_t_2412 = heff_field(v_t_2411, 0);
        heff_take_n(v_t_2411, 1ULL, 1);
        V v_t_2413 = heff_get_n(v_p_2410, 1, 3);
        V v_t_2414;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_One: {
          v_t_2414 = NTAG(TAG_True);
          break;
        }
        case TAG_Optional: {
          v_t_2414 = NTAG(TAG_False);
          break;
        }
        case TAG_Many: {
          v_t_2414 = NTAG(TAG_False);
          break;
        }
        case TAG_Some: {
          v_t_2414 = NTAG(TAG_True);
          break;
        }
        case TAG_Rest: {
          v_t_2414 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        v_t_2426 = heff_bool(((heff_dup(v_t_2414) == NTAG(TAG_True)) && ({ V v_s_2415 = heff_strOfRunes(heff_dup(heff_rfield(v_t_2412, 0))); int c_ = ({ V v_t_2416 = (g_prelude_2eskipSpaces(v_s_2415, MK_INT(0LL), MK_INT(1LL))); int c_ = ({ int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_s_2415, 0)) - ((int64_t)1ULL)); int c_ = ({ V v_t_2418 = (g_prelude_2eskipSpaces(v_s_2415, heff_box_word(v_t_2417), MK_INT(-1LL))); int c_ = ({ V v_t_2427 = heff_strSlice_lent(v_s_2415, v_t_2416, heff_intAdd_lent(v_t_2418, MK_INT(1LL), 2), 4); int c_ = heff_strEq_c_lent(v_t_2427, ((V)&g_list_2eindexWhere_2eindexFrom_240_24s1862090511x134883249_24cpr_str0), 2); heff_drop(v_t_2427); c_; }); heff_drop(v_t_2418); c_; }); c_; }); heff_drop(v_t_2416); c_; }); heff_drop(v_s_2415); c_; })));
        heff_drop_rec(v_t_2412, 2);
        heff_drop(v_t_2414);
        break;
      }
      case TAG_Picked: {
        heff_take_n(v_t_2411, 0ULL, 1);
        heff_drop_rec(v_p_2410, 3);
        v_t_2426 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      break;
    }
    case TAG_Flagged: {
      V v_f_2420 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      heff_drop(v_input_248);
      V v_t_2421 = heff_dup(heff_rfield(v_f_2420, 6));
      if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
        heff_drop(v_t_2421);
        V v_t_2422 = (g_list_2ekeepIf_24s2034497759x755284100(v_f_2420, v_fs_245));
        V v_x1_2423 = (g_list_2emap_24s1173914895x100384474(v_t_2422));
        switch (heff_tag_of(v_x1_2423)) {
        case TAG_Nil: {
          v_t_2426 = NTAG(TAG_True);
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x1_2423, 0ULL, 2);
          v_t_2426 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x1_2423);
        }
      } else {
        heff_drop(v_fs_245);
        heff_drop_rec(v_f_2420, 8);
        heff_drop(v_t_2421);
        v_t_2426 = NTAG(TAG_False);
      }
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
      heff_drop(v_lit_240);
      heff_drop(v_t_2426);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
    } else {
      heff_drop(v_t_2426);
      V t_0 = v_lit_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_ys_244;
      v_lit_240 = t_0;
      v_i_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_242)}});
  }
}