// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_m 327
#define LBL_n 328
#define LBL_xs 10594
static uint32_t shape_m__n__xs[] = {LBL_m, LBL_n, LBL_xs};
V g_heff_2ecompile_2ecycles_2eretail(V, V, V);
V g_heff_2ecompile_2ecycles_2eretail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2ecycles_2eretail_clo;
V g_heff_2ecompile_2efuse_2eendAt(V, V);
V g_heff_2ecompile_2efuse_2eendAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eendAt_clo;
V g_heff_2ecompile_2eir_2eallFields(V, V);
V g_heff_2ecompile_2eir_2eallFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallFields_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_24dps(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_24dps_clo;
V g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_clo;
V g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_24dps(V, V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_24dps_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
HeffT2 g_heff_2ecompile_2eir_2earmNamed_24cpr(V, V);
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
HeffT3 g_heff_2ecompile_2eir_2eboolArms_24cpr(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_clo;
V g_heff_2ecompile_2eir_2econdIf(V, V, V);
V g_heff_2ecompile_2eir_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdIf_clo;
V g_heff_2ecompile_2eir_2econdOf(V);
V g_heff_2ecompile_2eir_2econdOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOf_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2econdShaped(V);
V g_heff_2ecompile_2eir_2econdShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdShaped_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s106558534x2143835601(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s106558534x2143835601_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s106558534x2143835601_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269_clo;
V g_heff_2ecompile_2eir_2efoldArms(V, V, V);
V g_heff_2ecompile_2eir_2efoldArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldArms_clo;
V g_heff_2ecompile_2eir_2efoldFields(V, V, V);
V g_heff_2ecompile_2eir_2efoldFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldFields_clo;
V g_heff_2ecompile_2eir_2efoldList(V, V, V);
V g_heff_2ecompile_2eir_2efoldList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldList_clo;
V g_heff_2ecompile_2eir_2efoldParts(V, V, V);
V g_heff_2ecompile_2eir_2efoldParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldParts_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisRel(V);
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisRel_clo;
V g_heff_2ecompile_2eir_2epushArms_24dps(V, V, V);
V g_heff_2ecompile_2eir_2epushArms_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_24dps_clo;
V g_heff_2ecompile_2eir_2esurelyBool(V);
V g_heff_2ecompile_2eir_2esurelyBool_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esurelyBool_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267(V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423(V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_clo;
V g_heff_2ecompile_2eir_2ewaysMap(V, V);
V g_heff_2ecompile_2eir_2ewaysMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24dps(V, V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24dps_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936(V, V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_24dps(V, V, V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_24dps_clo;
V g_heff_2ecompile_2eir_2ewaysOut(V);
V g_heff_2ecompile_2eir_2ewaysOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOut_clo;
V g_heff_2ecompile_2emonadic_2enorm(V);
V g_heff_2ecompile_2emonadic_2enorm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enorm_clo;
V g_heff_2ecompile_2erematch_2ematchOf(V, V);
V g_heff_2ecompile_2erematch_2ematchOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_clo;
V g_heff_2ecompile_2erematch_2ematchOf_24tok2(V, V, V);
V g_heff_2ecompile_2erematch_2ematchOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erematch_2ematchOf_24tok2_clo;
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1544308498x936697067(V, V);
V g_list_2efoldl_24s1544308498x936697067_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1544308498x936697067_clo;
V g_list_2efoldl_24s690313412x1307839513(V, V);
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690313412x1307839513_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2etraverse_24s1024607077x497796552(V);
V g_prelude_2etraverse_24s1024607077x497796552_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1024607077x497796552_clo;
V g_prelude_2etraverse_24s1360711314x1560806682(V, V);
V g_prelude_2etraverse_24s1360711314x1560806682_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1360711314x1560806682_clo;
V g_prelude_2etraverse_24s1587080482x1917521257(V, V);
V g_prelude_2etraverse_24s1587080482x1917521257_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1587080482x1917521257_clo;
V g_prelude_2etraverse_24s1676309013x2015929738(V);
V g_prelude_2etraverse_24s1676309013x2015929738_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1676309013x2015929738_clo;
V g_prelude_2etraverse_24s215781391x848981957(V);
V g_prelude_2etraverse_24s215781391x848981957_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s215781391x848981957_clo;
V g_prelude_2etraverse_24s735647865x424372205(V, V);
V g_prelude_2etraverse_24s735647865x424372205_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s735647865x424372205_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2eir_2ebaseGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ebaseGo_entry, 2, 0};

V g_heff_2ecompile_2eir_2ebaseGo(V v_x_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) <= v_i_241)) {
    return v_x_240;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_x_240, heff_box_word(v_i_241), 2)) == ((int64_t)36ULL))) {
      return heff_strSlice(v_x_240, MK_INT(0LL), heff_box_word(v_i_241));
    } else {
      V t_0 = v_x_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_x_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ebaseGo(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2epushArms_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushArms_24dps_entry, 3, 0};

V g_heff_2ecompile_2eir_2epushArms_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_args_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_a_243)) {
    case TAG_MkArm: {
      V v_b_247 = heff_field(v_a_243, 2);
      heff_take_n(v_a_243, 4ULL, 3);
      v_t_248 = v_b_247;
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_args_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_249;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushArms_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushArms_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam7(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam8(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam9(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam12(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam11(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam10(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam13(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam14(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam15(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam16(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam17(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam18(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam19(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam20(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam21(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam22(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam23(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam24(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam25(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam26(V self, V *args);
Clo g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_entry, 2, 0};

V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam0, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam1, 1, 1, (V[]){v_x2_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_246), v_b_247}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_g_2413 = heff_field(v_x2_241, 0);
    V v_args_2414 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2415 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_g_2413}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam3, 1, 3, (V[]){v_m_2415, v_f_240, v_args_2414});
  }
  case TAG_ELet: {
    V v_x_2425 = heff_field(v_x2_241, 0);
    V v_a_2426 = heff_field(v_x2_241, 1);
    V v_b_2427 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2428 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_2426}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam4, 1, 4, (V[]){v_m_2428, v_x_2425, v_f_240, v_b_2427});
  }
  case TAG_ERecord: {
    V v_fs_2438 = heff_field(v_x2_241, 0);
    V v_ts_2439 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2448 = (g_prelude_2etraverse_24s1587080482x1917521257(heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam5, 1, 1, (V[]){v_f_240}), v_fs_2438));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam7, 1, 2, (V[]){v_m_2448, v_ts_2439});
  }
  case TAG_EProj: {
    V v_e_2453 = heff_field(v_x2_241, 0);
    V v_l_2454 = heff_field(v_x2_241, 1);
    V v_sh_2455 = heff_field(v_x2_241, 2);
    V v_t_2456 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_2457 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2453}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam8, 1, 4, (V[]){v_m_2457, v_l_2454, v_sh_2455, v_t_2456});
  }
  case TAG_ETag: {
    V v_t_2462 = heff_field(v_x2_241, 0);
    V v_args_2463 = heff_field(v_x2_241, 1);
    V v_ts_2464 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2465 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2466 = (g_prelude_2etraverse_24s1587080482x1917521257(v_t_2465, v_args_2463));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam9, 1, 3, (V[]){v_m_2466, v_t_2462, v_ts_2464});
  }
  case TAG_EMatch: {
    V v_s_2471 = heff_field(v_x2_241, 0);
    V v_arms_2472 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2473 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_s_2471}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam10, 1, 3, (V[]){v_m_2473, v_f_240, v_arms_2472});
  }
  case TAG_EPrim: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam13, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EPrimCall: {
    V v_p_2493 = heff_field(v_x2_241, 0);
    V v_args_2494 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2495 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2496 = (g_prelude_2etraverse_24s1587080482x1917521257(v_t_2495, v_args_2494));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam14, 1, 2, (V[]){v_m_2496, v_p_2493});
  }
  case TAG_ECall: {
    V v_g_24101 = heff_field(v_x2_241, 0);
    V v_args_24102 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24103 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24104 = (g_prelude_2etraverse_24s1587080482x1917521257(v_t_24103, v_args_24102));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam15, 1, 2, (V[]){v_m_24104, v_g_24101});
  }
  case TAG_EInt: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam16, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam17, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EStr: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam18, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBytes: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam19, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFixed: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam20, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam21, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam22, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBool: {
    V v_c_24123 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24124 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24125 = (g_heff_2ecompile_2eir_2econdTraverse_24s477707003x1647077269(v_t_24124, v_c_24123));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam23, 1, 1, (V[]){v_m_24125});
  }
  case TAG_ESet: {
    V v_xs_24130 = heff_field(v_x2_241, 0);
    V v_a_24131 = heff_field(v_x2_241, 1);
    V v_b_24132 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24133 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_24131}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam24, 1, 4, (V[]){v_m_24133, v_f_240, v_xs_24130, v_b_24132});
  }
  case TAG_EValues: {
    V v_es_24142 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24143 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24144 = (g_prelude_2etraverse_24s1587080482x1917521257(v_t_24143, v_es_24142));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam25, 1, 1, (V[]){v_m_24144});
  }
  case TAG_EFix: {
    V v_x_24149 = heff_field(v_x2_241, 0);
    V v_b_24150 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EFix = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_24151 = heff_tag_at_n(v_ru_24x2_241_24EFix, TAG_Cons, 2, (V[]){heff_dup(v_x_24149), NTAG(TAG_Nil)});
    V v_m_24152 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_24151, v_b_24150}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam26, 1, 2, (V[]){v_m_24152, v_x_24149});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_243});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_245});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam2(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_x_2411}), v_n_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam3(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_args_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2420 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2421 = (g_prelude_2etraverse_24s1587080482x1917521257(v_t_2420, v_args_2414));
    V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_n_2419}));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_MkPair: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_n_2424 = heff_field(v_x2_2422, 1);
      V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_EApp, 2, (V[]){v_x_2418, v_x_2423}), v_n_2424});
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam4(V self, V *args) {
  V v_n_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_f_240 = heff_env(self)[2];
  V v_b_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_n_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_n_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2425), NTAG(TAG_Nil)});
    V v_m_2434 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_2433, v_b_2427}));
    V v_x2_2435 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_n_2432}));
    switch (heff_tag_of(v_x2_2435)) {
    case TAG_MkPair: {
      V v_x_2436 = heff_field(v_x2_2435, 0);
      V v_n_2437 = heff_field(v_x2_2435, 1);
      heff_take_n(v_x2_2435, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2425, v_x_2431, v_x_2436}), v_n_2437});
    }
    default: return heff_nomatch(v_x2_2435);
    }
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam6(V self, V *args) {
  V v_n_2444 = args[0];
  V v_m_2443 = heff_env(self)[0];
  V v_l_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2445 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_n_2444}));
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    V v_n_2447 = heff_field(v_x2_2445, 1);
    V v_ru_24x2_2445_24MkPair = heff_take_reuse_n(v_x2_2445, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2445_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2441, v_x_2446}), v_n_2447});
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam5(V self, V *args) {
  V v_x2_2440 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkPair: {
    V v_l_2441 = heff_field(v_x2_2440, 0);
    V v_e_2442 = heff_field(v_x2_2440, 1);
    heff_take_n(v_x2_2440, 3ULL, 2);
    V v_m_2443 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2442}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam6, 1, 2, (V[]){v_m_2443, v_l_2441});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam7(V self, V *args) {
  V v_n_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_ts_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_n_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_n_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2451, v_ts_2439}), v_n_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam8(V self, V *args) {
  V v_n_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_l_2454 = heff_env(self)[1];
  V v_sh_2455 = heff_env(self)[2];
  V v_t_2456 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_n_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_n_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2460, v_l_2454, v_sh_2455, v_t_2456}), v_n_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam9(V self, V *args) {
  V v_n_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_t_2462 = heff_env(self)[1];
  V v_ts_2464 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_n_2467}));
  switch (heff_tag_of(v_x2_2468)) {
  case TAG_MkPair: {
    V v_x_2469 = heff_field(v_x2_2468, 0);
    V v_n_2470 = heff_field(v_x2_2468, 1);
    V v_ru_24x2_2468_24MkPair = heff_take_reuse_n(v_x2_2468, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2462, v_x_2469, v_ts_2464}), v_n_2470});
  }
  default: return heff_nomatch(v_x2_2468);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam12(V self, V *args) {
  V v_n_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_t_2479 = heff_env(self)[1];
  V v_vs_2480 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2484 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_n_2483}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_n_2486 = heff_field(v_x2_2484, 1);
    V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2479, v_vs_2480, v_x_2485}), v_n_2486});
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam11(V self, V *args) {
  V v_x2_2478 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkArm: {
    V v_t_2479 = heff_field(v_x2_2478, 0);
    V v_vs_2480 = heff_field(v_x2_2478, 1);
    V v_b_2481 = heff_field(v_x2_2478, 2);
    heff_take_n(v_x2_2478, 7ULL, 3);
    V v_m_2482 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_vs_2480), v_b_2481}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam12, 1, 3, (V[]){v_m_2482, v_t_2479, v_vs_2480});
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam10(V self, V *args) {
  V v_n_2474 = args[0];
  V v_m_2473 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_arms_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2475 = heff_tr(heff_call(v_m_2473, 1, (V[]){v_n_2474}));
  switch (heff_tag_of(v_x2_2475)) {
  case TAG_MkPair: {
    V v_x_2476 = heff_field(v_x2_2475, 0);
    V v_n_2477 = heff_field(v_x2_2475, 1);
    V v_ru_24x2_2475_24MkPair = heff_take_reuse_n(v_x2_2475, 3ULL, 2);
    V v_m_2487 = (g_prelude_2etraverse_24s1587080482x1917521257(heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam11, 1, 1, (V[]){v_f_240}), v_arms_2472));
    V v_x2_2488 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_n_2477}));
    switch (heff_tag_of(v_x2_2488)) {
    case TAG_MkPair: {
      V v_x_2489 = heff_field(v_x2_2488, 0);
      V v_n_2490 = heff_field(v_x2_2488, 1);
      V v_ru_24x2_2488_24MkPair = heff_take_reuse_n(v_x2_2488, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2488_24MkPair, TAG_EMatch, 2, (V[]){v_x_2476, v_x_2489}), v_n_2490});
    }
    default: return heff_nomatch(v_x2_2488);
    }
  }
  default: return heff_nomatch(v_x2_2475);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam13(V self, V *args) {
  V v_n_2492 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_2492});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam14(V self, V *args) {
  V v_n_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  V v_p_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2498 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_n_2497}));
  switch (heff_tag_of(v_x2_2498)) {
  case TAG_MkPair: {
    V v_x_2499 = heff_field(v_x2_2498, 0);
    V v_n_24100 = heff_field(v_x2_2498, 1);
    V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2498_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2493, v_x_2499}), v_n_24100});
  }
  default: return heff_nomatch(v_x2_2498);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam15(V self, V *args) {
  V v_n_24105 = args[0];
  V v_m_24104 = heff_env(self)[0];
  V v_g_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24106 = heff_tr(heff_call(v_m_24104, 1, (V[]){v_n_24105}));
  switch (heff_tag_of(v_x2_24106)) {
  case TAG_MkPair: {
    V v_x_24107 = heff_field(v_x2_24106, 0);
    V v_n_24108 = heff_field(v_x2_24106, 1);
    V v_ru_24x2_24106_24MkPair = heff_take_reuse_n(v_x2_24106, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24106_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24101, v_x_24107}), v_n_24108});
  }
  default: return heff_nomatch(v_x2_24106);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam16(V self, V *args) {
  V v_n_24110 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24110});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam17(V self, V *args) {
  V v_n_24112 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24112});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam18(V self, V *args) {
  V v_n_24114 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24114});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam19(V self, V *args) {
  V v_n_24116 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24116});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam20(V self, V *args) {
  V v_n_24119 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24119});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam21(V self, V *args) {
  V v_n_24121 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24121});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam22(V self, V *args) {
  V v_n_24122 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24122});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam23(V self, V *args) {
  V v_n_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_n_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_n_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24127_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24128}), v_n_24129});
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam24(V self, V *args) {
  V v_n_24134 = args[0];
  V v_m_24133 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_24130 = heff_env(self)[2];
  V v_b_24132 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24135 = heff_tr(heff_call(v_m_24133, 1, (V[]){v_n_24134}));
  switch (heff_tag_of(v_x2_24135)) {
  case TAG_MkPair: {
    V v_x_24136 = heff_field(v_x2_24135, 0);
    V v_n_24137 = heff_field(v_x2_24135, 1);
    V v_ru_24x2_24135_24MkPair = heff_take_reuse_n(v_x2_24135, 3ULL, 2);
    V v_m_24138 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_24130), v_b_24132}));
    V v_x2_24139 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_n_24137}));
    switch (heff_tag_of(v_x2_24139)) {
    case TAG_MkPair: {
      V v_x_24140 = heff_field(v_x2_24139, 0);
      V v_n_24141 = heff_field(v_x2_24139, 1);
      heff_take_n(v_x2_24139, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24135_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24130, v_x_24136, v_x_24140}), v_n_24141});
    }
    default: return heff_nomatch(v_x2_24139);
    }
  }
  default: return heff_nomatch(v_x2_24135);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam25(V self, V *args) {
  V v_n_24145 = args[0];
  V v_m_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24146 = heff_tr(heff_call(v_m_24144, 1, (V[]){v_n_24145}));
  switch (heff_tag_of(v_x2_24146)) {
  case TAG_MkPair: {
    V v_x_24147 = heff_field(v_x2_24146, 0);
    V v_n_24148 = heff_field(v_x2_24146, 1);
    V v_ru_24x2_24146_24MkPair = heff_take_reuse_n(v_x2_24146, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24147}), v_n_24148});
  }
  default: return heff_nomatch(v_x2_24146);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_lam26(V self, V *args) {
  V v_n_24153 = args[0];
  V v_m_24152 = heff_env(self)[0];
  V v_x_24149 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24154 = heff_tr(heff_call(v_m_24152, 1, (V[]){v_n_24153}));
  switch (heff_tag_of(v_x2_24154)) {
  case TAG_MkPair: {
    V v_x_24155 = heff_field(v_x2_24154, 0);
    V v_n_24156 = heff_field(v_x2_24154, 1);
    V v_ru_24x2_24154_24MkPair = heff_take_reuse_n(v_x2_24154, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24154_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24149, v_x_24155}), v_n_24156});
  }
  default: return heff_nomatch(v_x2_24154);
  }
}
Clo g_heff_2ecompile_2eir_2efoldParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efoldParts_entry, 3, 0};

V g_heff_2ecompile_2eir_2efoldParts(V v_f_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_241, 0);
    V v_b_246 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    return heff_tail(v_f_240, 3, (V[]){v_xs_245, v_b_246, v_acc_242});
  }
  case TAG_EApp: {
    V v_g_247 = heff_field(v_x2_241, 0);
    V v_args_248 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_249 = heff_tr(heff_call(heff_dup(v_f_240), 3, (V[]){NTAG(TAG_Nil), v_g_247, v_acc_242}));
    return ({ V a_0 = v_f_240; V a_1 = v_args_248; V a_2 = v_t_249; V r_ = (g_heff_2ecompile_2eir_2efoldList(a_0, a_1, a_2)); heff_drop(v_args_248); r_; });
  }
  case TAG_ELet: {
    V v_x_2410 = heff_field(v_x2_241, 0);
    V v_a_2411 = heff_field(v_x2_241, 1);
    V v_b_2412 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, NTAG(TAG_Nil)});
    V v_t_2414 = heff_tr(heff_call(heff_dup(v_f_240), 3, (V[]){NTAG(TAG_Nil), v_a_2411, v_acc_242}));
    return heff_tail(v_f_240, 3, (V[]){v_t_2413, v_b_2412, v_t_2414});
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    return ({ V a_0 = v_f_240; V a_1 = v_fs_2415; V a_2 = v_acc_242; V r_ = (g_heff_2ecompile_2eir_2efoldFields(a_0, a_1, a_2)); heff_drop(v_fs_2415); r_; });
  }
  case TAG_EProj: {
    V v_e_2417 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    return heff_tail(v_f_240, 3, (V[]){NTAG(TAG_Nil), v_e_2417, v_acc_242});
  }
  case TAG_ETag: {
    V v_args_2422 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    return ({ V a_0 = v_f_240; V a_1 = v_args_2422; V a_2 = v_acc_242; V r_ = (g_heff_2ecompile_2eir_2efoldList(a_0, a_1, a_2)); heff_drop(v_args_2422); r_; });
  }
  case TAG_EMatch: {
    V v_s_2424 = heff_field(v_x2_241, 0);
    V v_arms_2425 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2426 = heff_tr(heff_call(heff_dup(v_f_240), 3, (V[]){NTAG(TAG_Nil), v_s_2424, v_acc_242}));
    return ({ V a_0 = v_f_240; V a_1 = v_arms_2425; V a_2 = v_t_2426; V r_ = (g_heff_2ecompile_2eir_2efoldArms(a_0, a_1, a_2)); heff_drop(v_arms_2425); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_EPrimCall: {
    V v_args_2429 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    return ({ V a_0 = v_f_240; V a_1 = v_args_2429; V a_2 = v_acc_242; V r_ = (g_heff_2ecompile_2eir_2efoldList(a_0, a_1, a_2)); heff_drop(v_args_2429); r_; });
  }
  case TAG_ECall: {
    V v_args_2431 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    return ({ V a_0 = v_f_240; V a_1 = v_args_2431; V a_2 = v_acc_242; V r_ = (g_heff_2ecompile_2eir_2efoldList(a_0, a_1, a_2)); heff_drop(v_args_2431); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_EFloat: {
    heff_take_nf(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_EAbandon: {
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_EBool: {
    V v_c_2439 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2440 = ({ V a_0 = v_c_2439; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2439); r_; });
    return ({ V a_0 = v_f_240; V a_1 = v_t_2440; V a_2 = v_acc_242; V r_ = (g_heff_2ecompile_2eir_2efoldList(a_0, a_1, a_2)); heff_drop(v_t_2440); r_; });
  }
  case TAG_ESet: {
    V v_xs_2441 = heff_field(v_x2_241, 0);
    V v_a_2442 = heff_field(v_x2_241, 1);
    V v_b_2443 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2444 = heff_tr(heff_call(heff_dup(v_f_240), 3, (V[]){NTAG(TAG_Nil), v_a_2442, v_acc_242}));
    return heff_tail(v_f_240, 3, (V[]){v_xs_2441, v_b_2443, v_t_2444});
  }
  case TAG_EValues: {
    V v_es_2445 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    return ({ V a_0 = v_f_240; V a_1 = v_es_2445; V a_2 = v_acc_242; V r_ = (g_heff_2ecompile_2eir_2efoldList(a_0, a_1, a_2)); heff_drop(v_es_2445); r_; });
  }
  case TAG_EFix: {
    V v_x_2446 = heff_field(v_x2_241, 0);
    V v_b_2447 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EFix = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2448 = heff_tag_at_n(v_ru_24x2_241_24EFix, TAG_Cons, 2, (V[]){v_x_2446, NTAG(TAG_Nil)});
    return heff_tail(v_f_240, 3, (V[]){v_t_2448, v_b_2447, v_acc_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2efoldParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2efoldParts(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eir_2eallFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eallFields_entry, 2, 0};

V g_heff_2ecompile_2eir_2eallFields(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_fs_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_e_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), heff_dup(v_e_245)}));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V t_0 = v_f_240;
        V t_1 = v_fs_243;
        v_f_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_f_240);
        heff_drop(v_t_246);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2eallFields_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eir_2eallFields(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eir_2ewaysOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysOut_entry, 1, 0};

V g_heff_2ecompile_2eir_2ewaysOut(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_ELam: {
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24ELam, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EApp: {
    V v_ru_24e_240_24EApp = heff_take_reuse_n(v_e_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    V v_ru_24e_240_24ERecord = heff_take_reuse_n(v_e_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24ERecord, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 4);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_ETag: {
    V v_t_2416 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 3);
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, MK_INT(0LL)});
  }
  case TAG_EMatch: {
    V v_arms_2421 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EMatch = heff_take_reuse_n(v_e_240, 2ULL, 2);
    V v_t_2422 = heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    return (g_list_2efoldl_24s1544308498x936697067(v_t_2422, v_arms_2421));
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EPrimCall: {
    V v_ru_24e_240_24EPrimCall = heff_take_reuse_n(v_e_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_ECall: {
    V v_ru_24e_240_24ECall = heff_take_reuse_n(v_e_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EFixed: {
    V v_ru_24e_240_24EFixed = heff_take_reuse_n(v_e_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  }
  case TAG_EBool: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_ESet: {
    V v_b_2438 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_2438;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_EValues: {
    heff_take_n(v_e_240, 0ULL, 1);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  case TAG_EFix: {
    V v_ru_24e_240_24EFix = heff_take_reuse_n(v_e_240, 0ULL, 2);
    return heff_tag_at_n(v_ru_24e_240_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eir_2ewaysOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ewaysOut(a[0]);
}
V g_heff_2ecompile_2eir_2ewaysMap_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysMap_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysMap_24dps_entry, 3, 0};

V g_heff_2ecompile_2eir_2ewaysMap_24dps(V v_f_240, V v_e_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_t_244 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_244);
  }
  case TAG_EGlobal: {
    V v_t_246 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_246);
  }
  case TAG_ELam: {
    V v_t_249 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_249);
  }
  case TAG_EApp: {
    V v_t_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2412);
  }
  case TAG_ELet: {
    V v_x_2413 = heff_field(v_e_241, 0);
    V v_a_2414 = heff_field(v_e_241, 1);
    V v_b_2415 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2416 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2413, v_a_2414, heff_hole()});
    V v_u_2417 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_2416));
    heff_drop(v_u_2417);
    V t_0 = v_f_240;
    V t_1 = v_b_2415;
    V t_2 = v_cell_2416;
    v_f_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    V v_t_2420 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2420);
  }
  case TAG_EProj: {
    V v_t_2425 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2425);
  }
  case TAG_ETag: {
    V v_t_2429 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2429);
  }
  case TAG_EMatch: {
    V v_s_2430 = heff_field(v_e_241, 0);
    V v_arms_2431 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2437 = (g_list_2emap_24tok2(v_ru_24e_241_24EMatch, heff_clo_n(g_heff_2ecompile_2eir_2ewaysMap_24dps_lam0, 1, 1, (V[]){v_f_240}), v_arms_2431));
    return heff_setField(v_d_242, MK_INT(2LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2430, v_t_2437}));
  }
  case TAG_EPrim: {
    V v_t_2439 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2439);
  }
  case TAG_EPrimCall: {
    V v_t_2442 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2442);
  }
  case TAG_ECall: {
    V v_t_2445 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2445);
  }
  case TAG_EInt: {
    V v_t_2447 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2447);
  }
  case TAG_EFloat: {
    V v_t_2449 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2449);
  }
  case TAG_EStr: {
    V v_t_2451 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2451);
  }
  case TAG_EBytes: {
    V v_t_2453 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2453);
  }
  case TAG_EFixed: {
    V v_t_2456 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2456);
  }
  case TAG_EFloat32: {
    V v_t_2458 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2458);
  }
  case TAG_EAbandon: {
    V v_t_2459 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2459);
  }
  case TAG_EBool: {
    V v_t_2461 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2461);
  }
  case TAG_ESet: {
    V v_xs_2462 = heff_field(v_e_241, 0);
    V v_a_2463 = heff_field(v_e_241, 1);
    V v_b_2464 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2465 = heff_tag_at_n(v_ru_24e_241_24ESet, TAG_ESet, 3, (V[]){v_xs_2462, v_a_2463, heff_hole()});
    V v_u_2466 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_2465));
    heff_drop(v_u_2466);
    V t_0 = v_f_240;
    V t_1 = v_b_2464;
    V t_2 = v_cell_2465;
    v_f_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_EValues: {
    V v_t_2468 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2468);
  }
  case TAG_EFix: {
    V v_t_2471 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e_241}));
    return heff_setField(v_d_242, MK_INT(2LL), v_t_2471);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2ewaysMap_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ewaysMap_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eir_2ewaysMap_24dps_lam0(V self, V *args) {
  V v_x2_2432 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkArm: {
    V v_t_2433 = heff_field(v_x2_2432, 0);
    V v_vs_2434 = heff_field(v_x2_2432, 1);
    V v_b_2435 = heff_field(v_x2_2432, 2);
    V v_ru_24x2_2432_24MkArm = heff_take_reuse_n(v_x2_2432, 7ULL, 3);
    V v_t_2436 = heff_tr(g_heff_2ecompile_2eir_2ewaysMap(v_f_240, v_b_2435));
    return heff_tag_at_n(v_ru_24x2_2432_24MkArm, TAG_MkArm, 3, (V[]){v_t_2433, v_vs_2434, v_t_2436});
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
HEFF_LIT(g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr_str0, 1, "$");

HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V v_m_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EVar = heff_take_reuse_n(v_e_242, 1ULL, 1);
    HeffT2 v_t_244 = ({ V a_0 = v_m_240; V a_1 = v_x_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_m_240); r_; });
    V v_t_248;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        V v_y_247 = v_field_246;
        v_t_248 = v_y_247;
      } else {
        heff_drop(v_field_246);
        v_t_248 = v_x_243;
      }
    }
    V v_f_249 = heff_tag_at_n(v_ru_24e_242_24EVar, TAG_EVar, 1, (V[]){v_t_248});
    return ((HeffT2){{v_f_249, v_n_241}});
  }
  case TAG_EGlobal: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_ELam: {
    V v_xs_2411 = heff_field(v_e_242, 0);
    V v_b_2412 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2413 = heff_rec_n(3, shape_m__n__xs, (V[]){v_m_240, v_n_241, NTAG(TAG_Nil)});
    V v_v_2414 = (g_list_2efoldl_24s690313412x1307839513(v_t_2413, v_xs_2411));
    V v_m_2415 = heff_take_field(v_v_2414, 0);
    V v_n_2416 = heff_take_field(v_v_2414, 1);
    V v_xs_2417 = heff_get_n(v_v_2414, 2, 3);
    HeffT2 v_t_2418 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2415, v_n_2416, v_b_2412));
    {
      V v_field_2419 = v_t_2418.f[0];
      V v_field_2420 = v_t_2418.f[1];
      V v_b_27_2421 = v_field_2419;
      V v_n_27_2422 = v_field_2420;
      V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2417));
      V v_f_2424 = heff_tag_at_n(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_t_2423, v_b_27_2421});
      return ((HeffT2){{v_f_2424, v_n_27_2422}});
    }
  }
  case TAG_EApp: {
    V v_f_2425 = heff_field(v_e_242, 0);
    V v_args_2426 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2427 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_f_2425));
    {
      V v_field_2428 = v_t_2427.f[0];
      V v_field_2429 = v_t_2427.f[1];
      V v_f_27_2430 = v_field_2428;
      V v_n1_2431 = v_field_2429;
      HeffT2 v_t_2432 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n1_2431, v_args_2426));
      {
        V v_field_2433 = v_t_2432.f[0];
        V v_field_2434 = v_t_2432.f[1];
        V v_args_27_2435 = v_field_2433;
        V v_n2_2436 = v_field_2434;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){v_f_27_2430, v_args_27_2435}), v_n2_2436}});
      }
    }
  }
  case TAG_ELet: {
    V v_x_2437 = heff_field(v_e_242, 0);
    V v_a_2438 = heff_field(v_e_242, 1);
    V v_b_2439 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2440 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_a_2438));
    {
      V v_field_2441 = v_t_2440.f[0];
      V v_field_2442 = v_t_2440.f[1];
      V v_a_27_2443 = v_field_2441;
      V v_n1_2444 = v_field_2442;
      V v_base_2445 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_2437), MK_INT(0LL)));
      V v_x_27_2446 = heff_strAppend(heff_strAppend(v_base_2445, ((V)&g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr_str0)), heff_intShow(heff_dup(v_n1_2444)));
      V v_m_2447 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_240, v_x_2437, heff_dup(v_x_27_2446)));
      HeffT2 v_t_2448 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2447, heff_intAdd(v_n1_2444, MK_INT(1LL)), v_b_2439));
      {
        V v_field_2449 = v_t_2448.f[0];
        V v_field_2450 = v_t_2448.f[1];
        V v_b_27_2451 = v_field_2449;
        V v_n3_2452 = v_field_2450;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_27_2446, v_a_27_2443, v_b_27_2451}), v_n3_2452}});
      }
    }
  }
  case TAG_ERecord: {
    V v_fs_2453 = heff_field(v_e_242, 0);
    V v_ts_2454 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2455 = (g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24cpr(v_m_240, v_n_241, v_fs_2453));
    {
      V v_field_2456 = v_t_2455.f[0];
      V v_field_2457 = v_t_2455.f[1];
      V v_fs_27_2458 = v_field_2456;
      V v_n1_2459 = v_field_2457;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ERecord, TAG_ERecord, 2, (V[]){v_fs_27_2458, v_ts_2454}), v_n1_2459}});
    }
  }
  case TAG_EProj: {
    V v_e2_2460 = heff_field(v_e_242, 0);
    V v_l_2461 = heff_field(v_e_242, 1);
    V v_sh_2462 = heff_field(v_e_242, 2);
    V v_t_2463 = heff_field(v_e_242, 3);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 15ULL, 4);
    HeffT2 v_t_2464 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_240, v_n_241, v_e2_2460));
    {
      V v_field_2465 = v_t_2464.f[0];
      V v_field_2466 = v_t_2464.f[1];
      V v_e_27_2467 = v_field_2465;
      V v_n1_2468 = v_field_2466;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 4, (V[]){v_e_27_2467, v_l_2461, v_sh_2462, v_t_2463}), v_n1_2468}});
    }
  }
  case TAG_ETag: {
    V v_t_2469 = heff_field(v_e_242, 0);
    V v_args_2470 = heff_field(v_e_242, 1);
    V v_ts_2471 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2472 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n_241, v_args_2470));
    {
      V v_field_2473 = v_t_2472.f[0];
      V v_field_2474 = v_t_2472.f[1];
      V v_args_27_2475 = v_field_2473;
      V v_n1_2476 = v_field_2474;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ETag, TAG_ETag, 3, (V[]){v_t_2469, v_args_27_2475, v_ts_2471}), v_n1_2476}});
    }
  }
  case TAG_EMatch: {
    V v_s_2477 = heff_field(v_e_242, 0);
    V v_arms_2478 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2479 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_s_2477));
    {
      V v_field_2480 = v_t_2479.f[0];
      V v_field_2481 = v_t_2479.f[1];
      V v_s_27_2482 = v_field_2480;
      V v_n1_2483 = v_field_2481;
      HeffT2 v_t_2484 = (g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(v_m_240, v_n1_2483, v_arms_2478));
      {
        V v_field_2485 = v_t_2484.f[0];
        V v_field_2486 = v_t_2484.f[1];
        V v_arms_27_2487 = v_field_2485;
        V v_n2_2488 = v_field_2486;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_27_2482, v_arms_27_2487}), v_n2_2488}});
      }
    }
  }
  case TAG_EPrim: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EPrimCall: {
    V v_p_2490 = heff_field(v_e_242, 0);
    V v_args_2491 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2492 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n_241, v_args_2491));
    {
      V v_field_2493 = v_t_2492.f[0];
      V v_field_2494 = v_t_2492.f[1];
      V v_args_27_2495 = v_field_2493;
      V v_n1_2496 = v_field_2494;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2490, v_args_27_2495}), v_n1_2496}});
    }
  }
  case TAG_ECall: {
    V v_g_2497 = heff_field(v_e_242, 0);
    V v_args_2498 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2499 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n_241, v_args_2498));
    {
      V v_field_24100 = v_t_2499.f[0];
      V v_field_24101 = v_t_2499.f[1];
      V v_args_27_24102 = v_field_24100;
      V v_n1_24103 = v_field_24101;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_g_2497, v_args_27_24102}), v_n1_24103}});
    }
  }
  case TAG_EInt: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EFloat: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EStr: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EBytes: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EFixed: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EFloat32: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EAbandon: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EBool: {
    V v_c_24111 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EBool = heff_take_reuse_n(v_e_242, 1ULL, 1);
    HeffT2 v_t_24112 = (g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(v_m_240, v_n_241, v_c_24111));
    {
      V v_field_24113 = v_t_24112.f[0];
      V v_field_24114 = v_t_24112.f[1];
      V v_c_27_24115 = v_field_24113;
      V v_n1_24116 = v_field_24114;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EBool, TAG_EBool, 1, (V[]){v_c_27_24115}), v_n1_24116}});
    }
  }
  case TAG_ESet: {
    V v_xs_24117 = heff_field(v_e_242, 0);
    V v_a_24118 = heff_field(v_e_242, 1);
    V v_b_24119 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ESet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_24120 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_a_24118));
    {
      V v_field_24121 = v_t_24120.f[0];
      V v_field_24122 = v_t_24120.f[1];
      V v_a_27_24123 = v_field_24121;
      V v_n1_24124 = v_field_24122;
      V v_t_24125 = heff_rec_n(3, shape_m__n__xs, (V[]){v_m_240, v_n1_24124, NTAG(TAG_Nil)});
      V v_v_24126 = (g_list_2efoldl_24s690313412x1307839513(v_t_24125, v_xs_24117));
      V v_m_24127 = heff_take_field(v_v_24126, 0);
      V v_n_24128 = heff_take_field(v_v_24126, 1);
      V v_xs_24129 = heff_get_n(v_v_24126, 2, 3);
      HeffT2 v_t_24130 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_24127, v_n_24128, v_b_24119));
      {
        V v_field_24131 = v_t_24130.f[0];
        V v_field_24132 = v_t_24130.f[1];
        V v_b_27_24133 = v_field_24131;
        V v_n2_24134 = v_field_24132;
        V v_t_24135 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24129));
        V v_f_24136 = heff_tag_at_n(v_ru_24e_242_24ESet, TAG_ESet, 3, (V[]){v_t_24135, v_a_27_24123, v_b_27_24133});
        return ((HeffT2){{v_f_24136, v_n2_24134}});
      }
    }
  }
  case TAG_EValues: {
    V v_es_24137 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EValues = heff_take_reuse_n(v_e_242, 1ULL, 1);
    HeffT2 v_t_24138 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n_241, v_es_24137));
    {
      V v_field_24139 = v_t_24138.f[0];
      V v_field_24140 = v_t_24138.f[1];
      V v_es_27_24141 = v_field_24139;
      V v_n1_24142 = v_field_24140;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EValues, TAG_EValues, 1, (V[]){v_es_27_24141}), v_n1_24142}});
    }
  }
  case TAG_EFix: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
Clo g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_entry, 1, 0};

V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(v_xs_242));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eir_2eboolArms_24cpr_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2eboolArms_24cpr_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eir_2eboolArms_24cpr_str2, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eir_2eboolArms_24cpr_str3, 5, "False");

HeffT3 g_heff_2ecompile_2eir_2eboolArms_24cpr(V v_arms_240) {
top: ;
  switch (heff_tag_of(v_arms_240)) {
  case TAG_Nil: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_a_241 = heff_field(v_arms_240, 0);
    V v_arms2_242 = heff_field(v_arms_240, 1);
    V v_ru_24arms_240_24Cons = heff_take_reuse_n(v_arms_240, 3ULL, 2);
    switch (heff_tag_of(v_arms2_242)) {
    case TAG_Nil: {
      heff_drop(v_a_241);
      heff_drop_cell(v_ru_24arms_240_24Cons, 2);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_b_243 = heff_field(v_arms2_242, 0);
      V v_arms22_244 = heff_field(v_arms2_242, 1);
      V v_ru_24arms2_242_24Cons = heff_take_reuse_n(v_arms2_242, 3ULL, 2);
      switch (heff_tag_of(v_arms22_244)) {
      case TAG_Nil: {
        V v_t_245 = heff_tag_at_n(v_ru_24arms_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
        HeffT2 v_t_246 = ({ V b_0 = ((V)&g_heff_2ecompile_2eir_2eboolArms_24cpr_str0); V b_1 = heff_tag_at_n(v_ru_24arms2_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_a_241), v_t_245}); HeffT2 r_ = (g_heff_2ecompile_2eir_2earmNamed_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
        {
          V v_field_248 = v_t_246.f[1];
          int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
          if ((v_tag_247 == ((int64_t)0ULL))) {
            V v_t_249 = v_field_248;
            switch (heff_tag_of(v_a_241)) {
            case TAG_MkArm: {
              V v_t2_2410 = heff_field(v_a_241, 0);
              V v_vs_2411 = heff_field(v_a_241, 1);
              V v_b_2412 = heff_field(v_a_241, 2);
              heff_take_n(v_a_241, 7ULL, 3);
              if (heff_strEq_c(v_t2_2410, ((V)&g_heff_2ecompile_2eir_2eboolArms_24cpr_str1))) {
                switch (heff_tag_of(v_vs_2411)) {
                case TAG_Nil: {
                  heff_drop(v_b_243);
                  return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_t_249, v_b_2412}});
                }
                case TAG_Cons: {
                  V v_ru_24vs_2411_24Cons = heff_take_reuse_n(v_vs_2411, 0ULL, 2);
                  heff_drop(v_b_2412);
                  V v_t_2415 = heff_tag_at_n(v_ru_24vs_2411_24Cons, TAG_Cons, 2, (V[]){v_b_243, NTAG(TAG_Nil)});
                  HeffT2 v_t_2416 = ({ V b_0 = ((V)&g_heff_2ecompile_2eir_2eboolArms_24cpr_str2); V a_1 = v_t_2415; HeffT2 r_ = (g_heff_2ecompile_2eir_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_t_2415, 2); r_; });
                  {
                    V v_field_2418 = v_t_2416.f[1];
                    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                    if ((v_tag_2417 == ((int64_t)0ULL))) {
                      V v_f_2419 = v_field_2418;
                      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_t_249, v_f_2419}});
                    } else {
                      heff_drop(v_t_249);
                      heff_drop(v_field_2418);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                }
                default: return ((HeffT3){{heff_nomatch(v_vs_2411)}});
                }
              } else {
                heff_drop(v_vs_2411);
                heff_drop(v_b_2412);
                V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_243, NTAG(TAG_Nil)});
                HeffT2 v_t_2421 = ({ V b_0 = ((V)&g_heff_2ecompile_2eir_2eboolArms_24cpr_str3); V a_1 = v_t_2420; HeffT2 r_ = (g_heff_2ecompile_2eir_2earmNamed_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_t_2420, 2); r_; });
                {
                  V v_field_2423 = v_t_2421.f[1];
                  int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
                  if ((v_tag_2422 == ((int64_t)0ULL))) {
                    V v_f_2424 = v_field_2423;
                    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_t_249, v_f_2424}});
                  } else {
                    heff_drop(v_t_249);
                    heff_drop(v_field_2423);
                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                  }
                }
              }
            }
            default: return ((HeffT3){{heff_nomatch(v_a_241)}});
            }
          } else {
            heff_drop(v_a_241);
            heff_drop(v_b_243);
            heff_drop(v_field_248);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_arms22_244, 0ULL, 2);
        heff_drop(v_a_241);
        heff_drop_cell(v_ru_24arms_240_24Cons, 2);
        heff_drop(v_b_243);
        heff_drop_cell(v_ru_24arms2_242_24Cons, 2);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
      default: return ((HeffT3){{heff_nomatch(v_arms22_244)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_arms2_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_arms_240)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eir_2econdOf_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdOf_str1, 5, "False");
Clo g_heff_2ecompile_2eir_2econdOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdOf_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdOf(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_ELam: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_ETag: {
    V v_e2_2417 = heff_dup(heff_field(v_e_240, 1));
    switch (heff_tag_of(v_e2_2417)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_e_240)) {
      case TAG_ETag: {
        V v_t_2419 = heff_field(v_e_240, 0);
        V v_ts_2421 = heff_field(v_e_240, 2);
        V v_ru_24e_240_24ETag = heff_take_reuse_n(v_e_240, 5ULL, 3);
        if (heff_strEq_c_lent(v_t_2419, ((V)&g_heff_2ecompile_2eir_2econdOf_str0), 2)) {
          heff_drop(v_t_2419);
          heff_drop(v_ts_2421);
          heff_drop_cell(v_ru_24e_240_24ETag, 3);
          return NTAG(TAG_CTrue);
        } else {
          if (heff_strEq_c_lent(v_t_2419, ((V)&g_heff_2ecompile_2eir_2econdOf_str1), 2)) {
            heff_drop(v_t_2419);
            heff_drop(v_ts_2421);
            heff_drop_cell(v_ru_24e_240_24ETag, 3);
            return NTAG(TAG_CFalse);
          } else {
            V v_t_2422 = heff_tag_at_n(v_ru_24e_240_24ETag, TAG_ETag, 3, (V[]){v_t_2419, NTAG(TAG_Nil), v_ts_2421});
            return heff_tag_n(TAG_CTest, 1, (V[]){v_t_2422});
          }
        }
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_e2_2417, 0ULL, 2);
      return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
    }
    default: return heff_nomatch(v_e2_2417);
    }
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_e_240, 0);
    V v_arms_2426 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EMatch = heff_take_reuse_n(v_e_240, 3ULL, 2);
    HeffT3 v_t_2427 = (g_heff_2ecompile_2eir_2eboolArms_24cpr(heff_dup(v_arms_2426)));
    {
      V v_field_2429 = v_t_2427.f[1];
      V v_field_2430 = v_t_2427.f[2];
      int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
      if ((v_tag_2428 == ((int64_t)0ULL))) {
        V v_t_2431 = v_field_2429;
        V v_f_2432 = v_field_2430;
        V v_t_2433 = (g_heff_2ecompile_2eir_2econdShaped(heff_dup(v_t_2431)));
        if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
          heff_drop(v_t_2433);
          V v_t_2434 = (g_heff_2ecompile_2eir_2econdShaped(heff_dup(v_f_2432)));
          if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
            heff_drop(v_t_2434);
            V v_t_2435 = (g_heff_2ecompile_2eir_2esurelyBool(heff_dup(v_t_2431)));
            if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
              heff_drop(v_arms_2426);
              heff_drop_cell(v_ru_24e_240_24EMatch, 2);
              heff_drop(v_t_2435);
              V v_t_2436 = (g_heff_2ecompile_2eir_2econdOf(v_s_2425));
              V v_t_2437 = (g_heff_2ecompile_2eir_2econdOf(v_t_2431));
              V v_t_2438 = (g_heff_2ecompile_2eir_2econdOf(v_f_2432));
              return (g_heff_2ecompile_2eir_2econdIf(v_t_2436, v_t_2437, v_t_2438));
            } else {
              heff_drop(v_t_2435);
              V v_t_2439 = (g_heff_2ecompile_2eir_2esurelyBool(heff_dup(v_f_2432)));
              if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
                heff_drop(v_arms_2426);
                heff_drop_cell(v_ru_24e_240_24EMatch, 2);
                heff_drop(v_t_2439);
                V v_t_2440 = (g_heff_2ecompile_2eir_2econdOf(v_s_2425));
                V v_t_2441 = (g_heff_2ecompile_2eir_2econdOf(v_t_2431));
                V v_t_2442 = (g_heff_2ecompile_2eir_2econdOf(v_f_2432));
                return (g_heff_2ecompile_2eir_2econdIf(v_t_2440, v_t_2441, v_t_2442));
              } else {
                heff_drop(v_t_2431);
                heff_drop(v_f_2432);
                heff_drop(v_t_2439);
                return heff_tag_n(TAG_CTest, 1, (V[]){heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_EMatch, 2, (V[]){v_s_2425, v_arms_2426})});
              }
            }
          } else {
            heff_drop(v_t_2431);
            heff_drop(v_f_2432);
            heff_drop(v_t_2434);
            return heff_tag_n(TAG_CTest, 1, (V[]){heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_EMatch, 2, (V[]){v_s_2425, v_arms_2426})});
          }
        } else {
          heff_drop(v_t_2431);
          heff_drop(v_f_2432);
          heff_drop(v_t_2433);
          return heff_tag_n(TAG_CTest, 1, (V[]){heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_EMatch, 2, (V[]){v_s_2425, v_arms_2426})});
        }
      } else {
        heff_drop(v_field_2429);
        heff_drop(v_field_2430);
        return heff_tag_n(TAG_CTest, 1, (V[]){heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_EMatch, 2, (V[]){v_s_2425, v_arms_2426})});
      }
    }
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EPrimCall: {
    V v_p_2444 = heff_dup(heff_field(v_e_240, 0));
    V v_e2_2445 = heff_dup(heff_field(v_e_240, 1));
    switch (heff_tag_of(v_e2_2445)) {
    case TAG_Nil: {
      heff_drop(v_p_2444);
      return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
    }
    case TAG_Cons: {
      V v_a_2446 = heff_field(v_e2_2445, 0);
      V v_e22_2447 = heff_field(v_e2_2445, 1);
      V v_ru_24e2_2445_24Cons = heff_take_reuse_n(v_e2_2445, 3ULL, 2);
      switch (heff_tag_of(v_e22_2447)) {
      case TAG_Nil: {
        heff_drop(v_p_2444);
        heff_drop(v_a_2446);
        heff_drop_cell(v_ru_24e2_2445_24Cons, 2);
        return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
      }
      case TAG_Cons: {
        V v_b_2448 = heff_field(v_e22_2447, 0);
        V v_e222_2449 = heff_field(v_e22_2447, 1);
        V v_ru_24e22_2447_24Cons = heff_take_reuse_n(v_e22_2447, 3ULL, 2);
        switch (heff_tag_of(v_e222_2449)) {
        case TAG_Nil: {
          heff_drop_tag(v_e_240, 2);
          V v_t_2450 = (g_heff_2ecompile_2eir_2eisRel(v_p_2444));
          if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24e2_2445_24Cons, 2);
            heff_drop_cell(v_ru_24e22_2447_24Cons, 2);
            heff_drop(v_t_2450);
            return heff_tag_n(TAG_CRel, 3, (V[]){v_p_2444, v_a_2446, v_b_2448});
          } else {
            heff_drop(v_t_2450);
            V v_t_2451 = heff_tag_at_n(v_ru_24e2_2445_24Cons, TAG_Cons, 2, (V[]){v_b_2448, NTAG(TAG_Nil)});
            V v_t_2452 = heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2444, heff_tag_at_n(v_ru_24e22_2447_24Cons, TAG_Cons, 2, (V[]){v_a_2446, v_t_2451})});
            return heff_tag_n(TAG_CTest, 1, (V[]){v_t_2452});
          }
        }
        case TAG_Cons: {
          heff_take_n(v_e222_2449, 0ULL, 2);
          heff_drop(v_p_2444);
          heff_drop(v_a_2446);
          heff_drop_cell(v_ru_24e2_2445_24Cons, 2);
          heff_drop(v_b_2448);
          heff_drop_cell(v_ru_24e22_2447_24Cons, 2);
          return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
        }
        default: return heff_nomatch(v_e222_2449);
        }
      }
      default: return heff_nomatch(v_e22_2447);
      }
    }
    default: return heff_nomatch(v_e2_2445);
    }
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EBool: {
    V v_c_2464 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    return v_c_2464;
  }
  case TAG_ESet: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EValues: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_CTest, 1, (V[]){v_e_240});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eir_2econdOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdOf(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914(V v_x2_27_240) {
top: ;
  switch (heff_tag_of(v_x2_27_240)) {
  case TAG_CTrue: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam0_clo);
  }
  case TAG_CFalse: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x2_27_240, 0);
    V v_x_244 = heff_field(v_x2_27_240, 1);
    V v_y_245 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_m_246 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_x_244));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam2, 1, 3, (V[]){v_m_246, v_y_245, v_p_243});
  }
  case TAG_CTest: {
    V v_x_2415 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_m_2416 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_x_2415));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam3, 1, 1, (V[]){v_m_2416});
  }
  case TAG_CNot: {
    V v_c_2421 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_m_2422 = (g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914(v_c_2421));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam4, 1, 1, (V[]){v_m_2422});
  }
  case TAG_CIf: {
    V v_a_2427 = heff_field(v_x2_27_240, 0);
    V v_b_2428 = heff_field(v_x2_27_240, 1);
    V v_c_2429 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_m_2430 = (g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914(v_a_2427));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam5, 1, 3, (V[]){v_m_2430, v_b_2428, v_c_2429});
  }
  default: return heff_nomatch(v_x2_27_240);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam0(V self, V *args) {
  V v_s_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_s_241});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam1(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_s_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam2(V self, V *args) {
  V v_s_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_y_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_s_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_m_2411 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_y_245));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_243, v_x_249, v_x_2413}), v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam3(V self, V *args) {
  V v_s_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2419}), v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam4(V self, V *args) {
  V v_s_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_s_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_s_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2425}), v_s_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914_lam5(V self, V *args) {
  V v_s_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_b_2428 = heff_env(self)[1];
  V v_c_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_s_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_s_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_m_2435 = (g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914(v_b_2428));
    V v_x2_2436 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_s_2434}));
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_MkPair: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_s_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      V v_m_2439 = (g_heff_2ecompile_2eir_2econdTraverse_24s184584695x1587900914(v_c_2429));
      V v_x2_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_s_2438}));
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_MkPair: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_s_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2433, v_x_2437, v_x_2441}), v_s_2442});
      }
      default: return heff_nomatch(v_x2_2440);
      }
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam0_clo);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam2, 1, 4, (V[]){v_m_247, v_f_240, v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226(heff_dup(v_f_240), v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam5, 1, 4, (V[]){v_m_2431, v_f_240, v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_acc_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam1(V self, V *args) {
  V v_acc_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_acc_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam2(V self, V *args) {
  V v_acc_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_acc_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_acc_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_acc_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_acc_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_acc_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam3(V self, V *args) {
  V v_acc_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_acc_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_acc_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_acc_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam4(V self, V *args) {
  V v_acc_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_acc_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_acc_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_acc_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_lam5(V self, V *args) {
  V v_acc_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_acc_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_acc_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226(heff_dup(v_f_240), v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_acc_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_acc_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_m_2440 = (g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226(v_f_240, v_c_2430));
      V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_acc_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_acc_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_acc_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam7(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam8(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam9(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam12(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam11(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam10(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam13(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam14(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam15(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam16(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam17(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam18(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam19(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam20(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam21(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam22(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam23(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam24(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam25(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam26(V self, V *args);
Clo g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_entry, 2, 0};

V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam0, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam1, 1, 1, (V[]){v_x2_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_246), v_b_247}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_g_2413 = heff_field(v_x2_241, 0);
    V v_args_2414 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2415 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_g_2413}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam3, 1, 3, (V[]){v_m_2415, v_f_240, v_args_2414});
  }
  case TAG_ELet: {
    V v_x_2425 = heff_field(v_x2_241, 0);
    V v_a_2426 = heff_field(v_x2_241, 1);
    V v_b_2427 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2428 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_2426}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam4, 1, 4, (V[]){v_m_2428, v_x_2425, v_f_240, v_b_2427});
  }
  case TAG_ERecord: {
    V v_fs_2438 = heff_field(v_x2_241, 0);
    V v_ts_2439 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2448 = (g_prelude_2etraverse_24s735647865x424372205(heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam5, 1, 1, (V[]){v_f_240}), v_fs_2438));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam7, 1, 2, (V[]){v_m_2448, v_ts_2439});
  }
  case TAG_EProj: {
    V v_e_2453 = heff_field(v_x2_241, 0);
    V v_l_2454 = heff_field(v_x2_241, 1);
    V v_sh_2455 = heff_field(v_x2_241, 2);
    V v_t_2456 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_2457 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2453}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam8, 1, 4, (V[]){v_m_2457, v_l_2454, v_sh_2455, v_t_2456});
  }
  case TAG_ETag: {
    V v_t_2462 = heff_field(v_x2_241, 0);
    V v_args_2463 = heff_field(v_x2_241, 1);
    V v_ts_2464 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2465 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2466 = (g_prelude_2etraverse_24s735647865x424372205(v_t_2465, v_args_2463));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam9, 1, 3, (V[]){v_m_2466, v_t_2462, v_ts_2464});
  }
  case TAG_EMatch: {
    V v_s_2471 = heff_field(v_x2_241, 0);
    V v_arms_2472 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2473 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_s_2471}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam10, 1, 3, (V[]){v_m_2473, v_f_240, v_arms_2472});
  }
  case TAG_EPrim: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam13, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EPrimCall: {
    V v_p_2493 = heff_field(v_x2_241, 0);
    V v_args_2494 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2495 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2496 = (g_prelude_2etraverse_24s735647865x424372205(v_t_2495, v_args_2494));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam14, 1, 2, (V[]){v_m_2496, v_p_2493});
  }
  case TAG_ECall: {
    V v_g_24101 = heff_field(v_x2_241, 0);
    V v_args_24102 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24103 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24104 = (g_prelude_2etraverse_24s735647865x424372205(v_t_24103, v_args_24102));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam15, 1, 2, (V[]){v_m_24104, v_g_24101});
  }
  case TAG_EInt: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam16, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam17, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EStr: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam18, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBytes: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam19, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFixed: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam20, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam21, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam22, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBool: {
    V v_c_24123 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24124 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24125 = (g_heff_2ecompile_2eir_2econdTraverse_24s1405536026x348628337(v_t_24124, v_c_24123));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam23, 1, 1, (V[]){v_m_24125});
  }
  case TAG_ESet: {
    V v_xs_24130 = heff_field(v_x2_241, 0);
    V v_a_24131 = heff_field(v_x2_241, 1);
    V v_b_24132 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24133 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_24131}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam24, 1, 4, (V[]){v_m_24133, v_f_240, v_xs_24130, v_b_24132});
  }
  case TAG_EValues: {
    V v_es_24142 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_24143 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24144 = (g_prelude_2etraverse_24s735647865x424372205(v_t_24143, v_es_24142));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam25, 1, 1, (V[]){v_m_24144});
  }
  case TAG_EFix: {
    V v_x_24149 = heff_field(v_x2_241, 0);
    V v_b_24150 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EFix = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_24151 = heff_tag_at_n(v_ru_24x2_241_24EFix, TAG_Cons, 2, (V[]){heff_dup(v_x_24149), NTAG(TAG_Nil)});
    V v_m_24152 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_24151, v_b_24150}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam26, 1, 2, (V[]){v_m_24152, v_x_24149});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_243});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_245});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_s_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_x_2411}), v_s_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam3(V self, V *args) {
  V v_s_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_args_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2420 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2421 = (g_prelude_2etraverse_24s735647865x424372205(v_t_2420, v_args_2414));
    V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_s_2419}));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_MkPair: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_s_2424 = heff_field(v_x2_2422, 1);
      V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_EApp, 2, (V[]){v_x_2418, v_x_2423}), v_s_2424});
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam4(V self, V *args) {
  V v_s_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_f_240 = heff_env(self)[2];
  V v_b_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_s_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2425), NTAG(TAG_Nil)});
    V v_m_2434 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_2433, v_b_2427}));
    V v_x2_2435 = heff_tr(heff_call(v_m_2434, 1, (V[]){v_s_2432}));
    switch (heff_tag_of(v_x2_2435)) {
    case TAG_MkPair: {
      V v_x_2436 = heff_field(v_x2_2435, 0);
      V v_s_2437 = heff_field(v_x2_2435, 1);
      heff_take_n(v_x2_2435, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2425, v_x_2431, v_x_2436}), v_s_2437});
    }
    default: return heff_nomatch(v_x2_2435);
    }
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam6(V self, V *args) {
  V v_s_2444 = args[0];
  V v_m_2443 = heff_env(self)[0];
  V v_l_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2445 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_s_2444}));
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_MkPair: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    V v_s_2447 = heff_field(v_x2_2445, 1);
    V v_ru_24x2_2445_24MkPair = heff_take_reuse_n(v_x2_2445, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2445_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2441, v_x_2446}), v_s_2447});
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam5(V self, V *args) {
  V v_x2_2440 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkPair: {
    V v_l_2441 = heff_field(v_x2_2440, 0);
    V v_e_2442 = heff_field(v_x2_2440, 1);
    heff_take_n(v_x2_2440, 3ULL, 2);
    V v_m_2443 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2442}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam6, 1, 2, (V[]){v_m_2443, v_l_2441});
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam7(V self, V *args) {
  V v_s_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_ts_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_s_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_s_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2451, v_ts_2439}), v_s_2452});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam8(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_l_2454 = heff_env(self)[1];
  V v_sh_2455 = heff_env(self)[2];
  V v_t_2456 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2460, v_l_2454, v_sh_2455, v_t_2456}), v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam9(V self, V *args) {
  V v_s_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_t_2462 = heff_env(self)[1];
  V v_ts_2464 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_s_2467}));
  switch (heff_tag_of(v_x2_2468)) {
  case TAG_MkPair: {
    V v_x_2469 = heff_field(v_x2_2468, 0);
    V v_s_2470 = heff_field(v_x2_2468, 1);
    V v_ru_24x2_2468_24MkPair = heff_take_reuse_n(v_x2_2468, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2462, v_x_2469, v_ts_2464}), v_s_2470});
  }
  default: return heff_nomatch(v_x2_2468);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam12(V self, V *args) {
  V v_s_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_t_2479 = heff_env(self)[1];
  V v_vs_2480 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2484 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_s_2483}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_s_2486 = heff_field(v_x2_2484, 1);
    V v_ru_24x2_2484_24MkPair = heff_take_reuse_n(v_x2_2484, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2479, v_vs_2480, v_x_2485}), v_s_2486});
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam11(V self, V *args) {
  V v_x2_2478 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkArm: {
    V v_t_2479 = heff_field(v_x2_2478, 0);
    V v_vs_2480 = heff_field(v_x2_2478, 1);
    V v_b_2481 = heff_field(v_x2_2478, 2);
    heff_take_n(v_x2_2478, 7ULL, 3);
    V v_m_2482 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_vs_2480), v_b_2481}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam12, 1, 3, (V[]){v_m_2482, v_t_2479, v_vs_2480});
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam10(V self, V *args) {
  V v_s_2474 = args[0];
  V v_m_2473 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_arms_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2475 = heff_tr(heff_call(v_m_2473, 1, (V[]){v_s_2474}));
  switch (heff_tag_of(v_x2_2475)) {
  case TAG_MkPair: {
    V v_x_2476 = heff_field(v_x2_2475, 0);
    V v_s_2477 = heff_field(v_x2_2475, 1);
    V v_ru_24x2_2475_24MkPair = heff_take_reuse_n(v_x2_2475, 3ULL, 2);
    V v_m_2487 = (g_prelude_2etraverse_24s735647865x424372205(heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam11, 1, 1, (V[]){v_f_240}), v_arms_2472));
    V v_x2_2488 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_s_2477}));
    switch (heff_tag_of(v_x2_2488)) {
    case TAG_MkPair: {
      V v_x_2489 = heff_field(v_x2_2488, 0);
      V v_s_2490 = heff_field(v_x2_2488, 1);
      V v_ru_24x2_2488_24MkPair = heff_take_reuse_n(v_x2_2488, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2488_24MkPair, TAG_EMatch, 2, (V[]){v_x_2476, v_x_2489}), v_s_2490});
    }
    default: return heff_nomatch(v_x2_2488);
    }
  }
  default: return heff_nomatch(v_x2_2475);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam13(V self, V *args) {
  V v_s_2492 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_2492});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam14(V self, V *args) {
  V v_s_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  V v_p_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2498 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_s_2497}));
  switch (heff_tag_of(v_x2_2498)) {
  case TAG_MkPair: {
    V v_x_2499 = heff_field(v_x2_2498, 0);
    V v_s_24100 = heff_field(v_x2_2498, 1);
    V v_ru_24x2_2498_24MkPair = heff_take_reuse_n(v_x2_2498, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2498_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2493, v_x_2499}), v_s_24100});
  }
  default: return heff_nomatch(v_x2_2498);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam15(V self, V *args) {
  V v_s_24105 = args[0];
  V v_m_24104 = heff_env(self)[0];
  V v_g_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24106 = heff_tr(heff_call(v_m_24104, 1, (V[]){v_s_24105}));
  switch (heff_tag_of(v_x2_24106)) {
  case TAG_MkPair: {
    V v_x_24107 = heff_field(v_x2_24106, 0);
    V v_s_24108 = heff_field(v_x2_24106, 1);
    V v_ru_24x2_24106_24MkPair = heff_take_reuse_n(v_x2_24106, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24106_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24101, v_x_24107}), v_s_24108});
  }
  default: return heff_nomatch(v_x2_24106);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam16(V self, V *args) {
  V v_s_24110 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24110});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam17(V self, V *args) {
  V v_s_24112 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24112});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam18(V self, V *args) {
  V v_s_24114 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24114});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam19(V self, V *args) {
  V v_s_24116 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24116});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam20(V self, V *args) {
  V v_s_24119 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24119});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam21(V self, V *args) {
  V v_s_24121 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24121});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam22(V self, V *args) {
  V v_s_24122 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_s_24122});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam23(V self, V *args) {
  V v_s_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_s_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_s_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24127_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24128}), v_s_24129});
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam24(V self, V *args) {
  V v_s_24134 = args[0];
  V v_m_24133 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_24130 = heff_env(self)[2];
  V v_b_24132 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24135 = heff_tr(heff_call(v_m_24133, 1, (V[]){v_s_24134}));
  switch (heff_tag_of(v_x2_24135)) {
  case TAG_MkPair: {
    V v_x_24136 = heff_field(v_x2_24135, 0);
    V v_s_24137 = heff_field(v_x2_24135, 1);
    V v_ru_24x2_24135_24MkPair = heff_take_reuse_n(v_x2_24135, 3ULL, 2);
    V v_m_24138 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_24130), v_b_24132}));
    V v_x2_24139 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_s_24137}));
    switch (heff_tag_of(v_x2_24139)) {
    case TAG_MkPair: {
      V v_x_24140 = heff_field(v_x2_24139, 0);
      V v_s_24141 = heff_field(v_x2_24139, 1);
      heff_take_n(v_x2_24139, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24135_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24130, v_x_24136, v_x_24140}), v_s_24141});
    }
    default: return heff_nomatch(v_x2_24139);
    }
  }
  default: return heff_nomatch(v_x2_24135);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam25(V self, V *args) {
  V v_s_24145 = args[0];
  V v_m_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24146 = heff_tr(heff_call(v_m_24144, 1, (V[]){v_s_24145}));
  switch (heff_tag_of(v_x2_24146)) {
  case TAG_MkPair: {
    V v_x_24147 = heff_field(v_x2_24146, 0);
    V v_s_24148 = heff_field(v_x2_24146, 1);
    V v_ru_24x2_24146_24MkPair = heff_take_reuse_n(v_x2_24146, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24147}), v_s_24148});
  }
  default: return heff_nomatch(v_x2_24146);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s1757615010x1201297863_lam26(V self, V *args) {
  V v_s_24153 = args[0];
  V v_m_24152 = heff_env(self)[0];
  V v_x_24149 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24154 = heff_tr(heff_call(v_m_24152, 1, (V[]){v_s_24153}));
  switch (heff_tag_of(v_x2_24154)) {
  case TAG_MkPair: {
    V v_x_24155 = heff_field(v_x2_24154, 0);
    V v_s_24156 = heff_field(v_x2_24154, 1);
    V v_ru_24x2_24154_24MkPair = heff_take_reuse_n(v_x2_24154, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24154_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24149, v_x_24155}), v_s_24156});
  }
  default: return heff_nomatch(v_x2_24154);
  }
}
V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_lam0(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_entry, 3, 0};

V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936(V v_lit_240, V v_lit_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_cell_2412 = heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_249, v_a_2410, heff_hole()});
    V v_u_2413 = (g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_24dps(v_lit_240, v_lit_241, v_b_2411, heff_dup(v_cell_2412)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EMatch: {
    V v_s_2423 = heff_field(v_e_242, 0);
    V v_arms_2424 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_lam0, 1, 2, (V[]){v_lit_240, v_lit_241}), v_arms_2424));
    return heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2423, v_t_2430});
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EBool: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ESet: {
    V v_xs_2444 = heff_field(v_e_242, 0);
    V v_a_2445 = heff_field(v_e_242, 1);
    V v_b_2446 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ESet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_cell_2447 = heff_tag_at_n(v_ru_24e_242_24ESet, TAG_ESet, 3, (V[]){v_xs_2444, v_a_2445, heff_hole()});
    V v_u_2448 = (g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_24dps(v_lit_240, v_lit_241, v_b_2446, heff_dup(v_cell_2447)));
    heff_drop(v_u_2448);
    return v_cell_2447;
  }
  case TAG_EValues: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_lam0(V self, V *args) {
  V v_x2_2425 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkArm: {
    V v_t_2426 = heff_field(v_x2_2425, 0);
    V v_vs_2427 = heff_field(v_x2_2425, 1);
    V v_b_2428 = heff_field(v_x2_2425, 2);
    V v_ru_24x2_2425_24MkArm = heff_take_reuse_n(v_x2_2425, 7ULL, 3);
    V v_t_2429 = (g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936(v_lit_240, v_lit_241, v_b_2428));
    return heff_tag_at_n(v_ru_24x2_2425_24MkArm, TAG_MkArm, 3, (V[]){v_t_2426, v_vs_2427, v_t_2429});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_24dps_entry, 4, 0};

V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_24dps(V v_lit_240, V v_lit_241, V v_e_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_t_245 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_245);
  }
  case TAG_EGlobal: {
    V v_t_247 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_247);
  }
  case TAG_ELam: {
    V v_t_2410 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2410);
  }
  case TAG_EApp: {
    V v_t_2413 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2413);
  }
  case TAG_ELet: {
    V v_x_2414 = heff_field(v_e_242, 0);
    V v_a_2415 = heff_field(v_e_242, 1);
    V v_b_2416 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_cell_2417 = heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_2414, v_a_2415, heff_hole()});
    V v_u_2418 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_b_2416;
    V t_3 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    V v_t_2421 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2421);
  }
  case TAG_EProj: {
    V v_t_2426 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2426);
  }
  case TAG_ETag: {
    V v_t_2430 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2430);
  }
  case TAG_EMatch: {
    V v_s_2431 = heff_field(v_e_242, 0);
    V v_arms_2432 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2438 = (g_list_2emap_24tok2(v_ru_24e_242_24EMatch, heff_clo_n(g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_24dps_lam0, 1, 2, (V[]){v_lit_240, v_lit_241}), v_arms_2432));
    return heff_setField(v_d_243, MK_INT(2LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2431, v_t_2438}));
  }
  case TAG_EPrim: {
    V v_t_2440 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2440);
  }
  case TAG_EPrimCall: {
    V v_t_2443 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2443);
  }
  case TAG_ECall: {
    V v_t_2446 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2446);
  }
  case TAG_EInt: {
    V v_t_2448 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2448);
  }
  case TAG_EFloat: {
    V v_t_2450 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2450);
  }
  case TAG_EStr: {
    V v_t_2452 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2452);
  }
  case TAG_EBytes: {
    V v_t_2454 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2454);
  }
  case TAG_EFixed: {
    V v_t_2457 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2457);
  }
  case TAG_EFloat32: {
    V v_t_2459 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2459);
  }
  case TAG_EAbandon: {
    V v_t_2460 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2460);
  }
  case TAG_EBool: {
    V v_t_2462 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2462);
  }
  case TAG_ESet: {
    V v_xs_2463 = heff_field(v_e_242, 0);
    V v_a_2464 = heff_field(v_e_242, 1);
    V v_b_2465 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ESet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_cell_2466 = heff_tag_at_n(v_ru_24e_242_24ESet, TAG_ESet, 3, (V[]){v_xs_2463, v_a_2464, heff_hole()});
    V v_u_2467 = heff_setField(v_d_243, MK_INT(2LL), heff_dup(v_cell_2466));
    heff_drop(v_u_2467);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_b_2465;
    V t_3 = v_cell_2466;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_e_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  case TAG_EValues: {
    V v_t_2469 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2469);
  }
  case TAG_EFix: {
    V v_t_2472 = (g_heff_2ecompile_2ecycles_2eretail(v_lit_240, v_lit_241, v_e_242));
    return heff_setField(v_d_243, MK_INT(2LL), v_t_2472);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936_24dps_lam0(V self, V *args) {
  V v_x2_2433 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkArm: {
    V v_t_2434 = heff_field(v_x2_2433, 0);
    V v_vs_2435 = heff_field(v_x2_2433, 1);
    V v_b_2436 = heff_field(v_x2_2433, 2);
    V v_ru_24x2_2433_24MkArm = heff_take_reuse_n(v_x2_2433, 7ULL, 3);
    V v_t_2437 = (g_heff_2ecompile_2eir_2ewaysMap_24s1736183504x197167936(v_lit_240, v_lit_241, v_b_2436));
    return heff_tag_at_n(v_ru_24x2_2433_24MkArm, TAG_MkArm, 3, (V[]){v_t_2434, v_vs_2435, v_t_2437});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_lam4(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_entry, 2, 0};

V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423(V v_lit_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2411 = (g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423(v_lit_240, v_b_2410));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_lam0, 1, 3, (V[]){v_m_2411, v_x_248, v_a_249});
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_e_241, 0);
    V v_arms_2426 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2436 = (g_prelude_2etraverse_24s1360711314x1560806682(heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_lam1, 1, 1, (V[]){v_lit_240}), v_arms_2426));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_lam3, 1, 2, (V[]){v_m_2436, v_s_2425});
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_EBool: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_ESet: {
    V v_xs_2454 = heff_field(v_e_241, 0);
    V v_a_2455 = heff_field(v_e_241, 1);
    V v_b_2456 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2457 = (g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423(v_lit_240, v_b_2456));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_lam4, 1, 3, (V[]){v_m_2457, v_xs_2454, v_a_2455});
  }
  case TAG_EValues: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2efuse_2eendAt(v_lit_240, v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_lam0(V self, V *args) {
  V v_s_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_a_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_248, v_a_249, v_x_2414}), v_s_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_lam2(V self, V *args) {
  V v_s_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_t_2428 = heff_env(self)[1];
  V v_vs_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_s_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2428, v_vs_2429, v_x_2434}), v_s_2435});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_lam1(V self, V *args) {
  V v_x2_2427 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkArm: {
    V v_t_2428 = heff_field(v_x2_2427, 0);
    V v_vs_2429 = heff_field(v_x2_2427, 1);
    V v_b_2430 = heff_field(v_x2_2427, 2);
    heff_take_n(v_x2_2427, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423(v_lit_240, v_b_2430));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_lam2, 1, 3, (V[]){v_m_2431, v_t_2428, v_vs_2429});
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_lam3(V self, V *args) {
  V v_s_2437 = args[0];
  V v_m_2436 = heff_env(self)[0];
  V v_s_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2438 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_s_2437}));
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x2_2438, 0);
    V v_s_2440 = heff_field(v_x2_2438, 1);
    V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2425, v_x_2439}), v_s_2440});
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s819751518x1306860423_lam4(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_xs_2454 = heff_env(self)[1];
  V v_a_2455 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2454, v_a_2455, v_x_2460}), v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam0_clo);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam2, 1, 4, (V[]){v_m_247, v_f_240, v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890(heff_dup(v_f_240), v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam5, 1, 4, (V[]){v_m_2431, v_f_240, v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_n_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam1(V self, V *args) {
  V v_n_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_n_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_n_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam3(V self, V *args) {
  V v_n_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_n_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_n_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam4(V self, V *args) {
  V v_n_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_n_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_n_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_n_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890_lam5(V self, V *args) {
  V v_n_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890(heff_dup(v_f_240), v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_n_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_m_2440 = (g_heff_2ecompile_2eir_2econdTraverse_24s1900725661x1469630890(v_f_240, v_c_2430));
      V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_n_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_n_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam5(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam6(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam7(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam8(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam9(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam10(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam11(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam12(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam13(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam14(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam15(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam16(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam17(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam18(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam19(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam20(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam21(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam22(V self, V *args);
Clo g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_entry, 1, 0};

V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_EVar: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam0, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EGlobal: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam1, 1, 1, (V[]){v_x2_240});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_240, 0);
    V v_b_246 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_247 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_b_246));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam2, 1, 2, (V[]){v_m_247, v_xs_245});
  }
  case TAG_EApp: {
    V v_g_2412 = heff_field(v_x2_240, 0);
    V v_args_2413 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2414 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_g_2412));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam3, 1, 2, (V[]){v_m_2414, v_args_2413});
  }
  case TAG_ELet: {
    V v_x_2423 = heff_field(v_x2_240, 0);
    V v_a_2424 = heff_field(v_x2_240, 1);
    V v_b_2425 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_2426 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_a_2424));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam4, 1, 3, (V[]){v_m_2426, v_b_2425, v_x_2423});
  }
  case TAG_ERecord: {
    V v_fs_2435 = heff_field(v_x2_240, 0);
    V v_ts_2436 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2437 = (g_prelude_2etraverse_24s215781391x848981957(v_fs_2435));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam5, 1, 2, (V[]){v_m_2437, v_ts_2436});
  }
  case TAG_EProj: {
    V v_e_2442 = heff_field(v_x2_240, 0);
    V v_l_2443 = heff_field(v_x2_240, 1);
    V v_sh_2444 = heff_field(v_x2_240, 2);
    V v_t_2445 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_m_2446 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_e_2442));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam6, 1, 4, (V[]){v_m_2446, v_l_2443, v_sh_2444, v_t_2445});
  }
  case TAG_ETag: {
    V v_t_2451 = heff_field(v_x2_240, 0);
    V v_args_2452 = heff_field(v_x2_240, 1);
    V v_ts_2453 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_2454 = (g_prelude_2etraverse_24s1024607077x497796552(v_args_2452));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam7, 1, 3, (V[]){v_m_2454, v_t_2451, v_ts_2453});
  }
  case TAG_EMatch: {
    V v_s_2459 = heff_field(v_x2_240, 0);
    V v_arms_2460 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2461 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_s_2459));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam8, 1, 2, (V[]){v_m_2461, v_arms_2460});
  }
  case TAG_EPrim: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam9, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EPrimCall: {
    V v_p_2472 = heff_field(v_x2_240, 0);
    V v_args_2473 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2474 = (g_prelude_2etraverse_24s1024607077x497796552(v_args_2473));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam10, 1, 2, (V[]){v_m_2474, v_p_2472});
  }
  case TAG_ECall: {
    V v_g_2479 = heff_field(v_x2_240, 0);
    V v_args_2480 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_2481 = (g_prelude_2etraverse_24s1024607077x497796552(v_args_2480));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam11, 1, 2, (V[]){v_m_2481, v_g_2479});
  }
  case TAG_EInt: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam12, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFloat: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam13, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EStr: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam14, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EBytes: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam15, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFixed: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam16, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EFloat32: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam17, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EAbandon: {
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam18, 1, 1, (V[]){v_x2_240});
  }
  case TAG_EBool: {
    V v_c_24100 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_m_24101 = (g_heff_2ecompile_2eir_2econdTraverse_24s106558534x2143835601(v_c_24100));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam19, 1, 1, (V[]){v_m_24101});
  }
  case TAG_ESet: {
    V v_xs_24106 = heff_field(v_x2_240, 0);
    V v_a_24107 = heff_field(v_x2_240, 1);
    V v_b_24108 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_m_24109 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_a_24107));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam20, 1, 3, (V[]){v_m_24109, v_b_24108, v_xs_24106});
  }
  case TAG_EValues: {
    V v_es_24118 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_m_24119 = (g_prelude_2etraverse_24s1024607077x497796552(v_es_24118));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam21, 1, 1, (V[]){v_m_24119});
  }
  case TAG_EFix: {
    V v_x_24124 = heff_field(v_x2_240, 0);
    V v_b_24125 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_24126 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_b_24125));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam22, 1, 2, (V[]){v_m_24126, v_x_24124});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054(a[0]);
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_242});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_244});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_245, v_x_2410}), v_n_2411});
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam3(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_args_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_n_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    V v_m_2419 = (g_prelude_2etraverse_24s1024607077x497796552(v_args_2413));
    V v_x2_2420 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_n_2418}));
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_MkPair: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_n_2422 = heff_field(v_x2_2420, 1);
      V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_EApp, 2, (V[]){v_x_2417, v_x_2421}), v_n_2422});
    }
    default: return heff_nomatch(v_x2_2420);
    }
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam4(V self, V *args) {
  V v_n_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  V v_b_2425 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_n_2427}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    V v_n_2430 = heff_field(v_x2_2428, 1);
    V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
    V v_m_2431 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_b_2425));
    V v_x2_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2430}));
    switch (heff_tag_of(v_x2_2432)) {
    case TAG_MkPair: {
      V v_x_2433 = heff_field(v_x2_2432, 0);
      V v_n_2434 = heff_field(v_x2_2432, 1);
      heff_take_n(v_x2_2432, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2423, v_x_2429, v_x_2433}), v_n_2434});
    }
    default: return heff_nomatch(v_x2_2432);
    }
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam5(V self, V *args) {
  V v_n_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_ts_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_n_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_n_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2440, v_ts_2436}), v_n_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam6(V self, V *args) {
  V v_n_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_l_2443 = heff_env(self)[1];
  V v_sh_2444 = heff_env(self)[2];
  V v_t_2445 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2448 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_n_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkPair: {
    V v_x_2449 = heff_field(v_x2_2448, 0);
    V v_n_2450 = heff_field(v_x2_2448, 1);
    V v_ru_24x2_2448_24MkPair = heff_take_reuse_n(v_x2_2448, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2449, v_l_2443, v_sh_2444, v_t_2445}), v_n_2450});
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam7(V self, V *args) {
  V v_n_2455 = args[0];
  V v_m_2454 = heff_env(self)[0];
  V v_t_2451 = heff_env(self)[1];
  V v_ts_2453 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2456 = heff_tr(heff_call(v_m_2454, 1, (V[]){v_n_2455}));
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_MkPair: {
    V v_x_2457 = heff_field(v_x2_2456, 0);
    V v_n_2458 = heff_field(v_x2_2456, 1);
    V v_ru_24x2_2456_24MkPair = heff_take_reuse_n(v_x2_2456, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2456_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2451, v_x_2457, v_ts_2453}), v_n_2458});
  }
  default: return heff_nomatch(v_x2_2456);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam8(V self, V *args) {
  V v_n_2462 = args[0];
  V v_m_2461 = heff_env(self)[0];
  V v_arms_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2463 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_n_2462}));
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_MkPair: {
    V v_x_2464 = heff_field(v_x2_2463, 0);
    V v_n_2465 = heff_field(v_x2_2463, 1);
    V v_ru_24x2_2463_24MkPair = heff_take_reuse_n(v_x2_2463, 3ULL, 2);
    V v_m_2466 = (g_prelude_2etraverse_24s1676309013x2015929738(v_arms_2460));
    V v_x2_2467 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_n_2465}));
    switch (heff_tag_of(v_x2_2467)) {
    case TAG_MkPair: {
      V v_x_2468 = heff_field(v_x2_2467, 0);
      V v_n_2469 = heff_field(v_x2_2467, 1);
      V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2463_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2467_24MkPair, TAG_EMatch, 2, (V[]){v_x_2464, v_x_2468}), v_n_2469});
    }
    default: return heff_nomatch(v_x2_2467);
    }
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam9(V self, V *args) {
  V v_n_2471 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2471});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam10(V self, V *args) {
  V v_n_2475 = args[0];
  V v_m_2474 = heff_env(self)[0];
  V v_p_2472 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2476 = heff_tr(heff_call(v_m_2474, 1, (V[]){v_n_2475}));
  switch (heff_tag_of(v_x2_2476)) {
  case TAG_MkPair: {
    V v_x_2477 = heff_field(v_x2_2476, 0);
    V v_n_2478 = heff_field(v_x2_2476, 1);
    V v_ru_24x2_2476_24MkPair = heff_take_reuse_n(v_x2_2476, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2472, v_x_2477}), v_n_2478});
  }
  default: return heff_nomatch(v_x2_2476);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam11(V self, V *args) {
  V v_n_2482 = args[0];
  V v_m_2481 = heff_env(self)[0];
  V v_g_2479 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2483 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_n_2482}));
  switch (heff_tag_of(v_x2_2483)) {
  case TAG_MkPair: {
    V v_x_2484 = heff_field(v_x2_2483, 0);
    V v_n_2485 = heff_field(v_x2_2483, 1);
    V v_ru_24x2_2483_24MkPair = heff_take_reuse_n(v_x2_2483, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2483_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2479, v_x_2484}), v_n_2485});
  }
  default: return heff_nomatch(v_x2_2483);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam12(V self, V *args) {
  V v_n_2487 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2487});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam13(V self, V *args) {
  V v_n_2489 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2489});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam14(V self, V *args) {
  V v_n_2491 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2491});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam15(V self, V *args) {
  V v_n_2493 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2493});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam16(V self, V *args) {
  V v_n_2496 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2496});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam17(V self, V *args) {
  V v_n_2498 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2498});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam18(V self, V *args) {
  V v_n_2499 = args[0];
  V v_x2_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_240, v_n_2499});
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam19(V self, V *args) {
  V v_n_24102 = args[0];
  V v_m_24101 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24103 = heff_tr(heff_call(v_m_24101, 1, (V[]){v_n_24102}));
  switch (heff_tag_of(v_x2_24103)) {
  case TAG_MkPair: {
    V v_x_24104 = heff_field(v_x2_24103, 0);
    V v_n_24105 = heff_field(v_x2_24103, 1);
    V v_ru_24x2_24103_24MkPair = heff_take_reuse_n(v_x2_24103, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24103_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBool, 1, (V[]){v_x_24104}), v_n_24105});
  }
  default: return heff_nomatch(v_x2_24103);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam20(V self, V *args) {
  V v_n_24110 = args[0];
  V v_m_24109 = heff_env(self)[0];
  V v_b_24108 = heff_env(self)[1];
  V v_xs_24106 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24111 = heff_tr(heff_call(v_m_24109, 1, (V[]){v_n_24110}));
  switch (heff_tag_of(v_x2_24111)) {
  case TAG_MkPair: {
    V v_x_24112 = heff_field(v_x2_24111, 0);
    V v_n_24113 = heff_field(v_x2_24111, 1);
    V v_ru_24x2_24111_24MkPair = heff_take_reuse_n(v_x2_24111, 3ULL, 2);
    V v_m_24114 = heff_tr(g_heff_2ecompile_2emonadic_2enorm(v_b_24108));
    V v_x2_24115 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_n_24113}));
    switch (heff_tag_of(v_x2_24115)) {
    case TAG_MkPair: {
      V v_x_24116 = heff_field(v_x2_24115, 0);
      V v_n_24117 = heff_field(v_x2_24115, 1);
      heff_take_n(v_x2_24115, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24111_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24106, v_x_24112, v_x_24116}), v_n_24117});
    }
    default: return heff_nomatch(v_x2_24115);
    }
  }
  default: return heff_nomatch(v_x2_24111);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam21(V self, V *args) {
  V v_n_24120 = args[0];
  V v_m_24119 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24121 = heff_tr(heff_call(v_m_24119, 1, (V[]){v_n_24120}));
  switch (heff_tag_of(v_x2_24121)) {
  case TAG_MkPair: {
    V v_x_24122 = heff_field(v_x2_24121, 0);
    V v_n_24123 = heff_field(v_x2_24121, 1);
    V v_ru_24x2_24121_24MkPair = heff_take_reuse_n(v_x2_24121, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24121_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EValues, 1, (V[]){v_x_24122}), v_n_24123});
  }
  default: return heff_nomatch(v_x2_24121);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s439513781x1878650054_lam22(V self, V *args) {
  V v_n_24127 = args[0];
  V v_m_24126 = heff_env(self)[0];
  V v_x_24124 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24128 = heff_tr(heff_call(v_m_24126, 1, (V[]){v_n_24127}));
  switch (heff_tag_of(v_x2_24128)) {
  case TAG_MkPair: {
    V v_x_24129 = heff_field(v_x2_24128, 0);
    V v_n_24130 = heff_field(v_x2_24128, 1);
    V v_ru_24x2_24128_24MkPair = heff_take_reuse_n(v_x2_24128, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24128_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24124, v_x_24129}), v_n_24130});
  }
  default: return heff_nomatch(v_x2_24128);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284(V v_x2_27_240) {
top: ;
  switch (heff_tag_of(v_x2_27_240)) {
  case TAG_CTrue: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam0_clo);
  }
  case TAG_CFalse: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x2_27_240, 0);
    V v_x_244 = heff_field(v_x2_27_240, 1);
    V v_y_245 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_a_246 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_x_244));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam2, 1, 3, (V[]){v_a_246, v_y_245, v_p_243});
  }
  case TAG_CTest: {
    V v_x_2421 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_a_2422 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_x_2421));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam3, 1, 1, (V[]){v_a_2422});
  }
  case TAG_CNot: {
    V v_c_2430 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284(v_c_2430));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam4, 1, 1, (V[]){v_m_2431});
  }
  case TAG_CIf: {
    V v_a_2436 = heff_field(v_x2_27_240, 0);
    V v_b_2437 = heff_field(v_x2_27_240, 1);
    V v_c_2438 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_m_2439 = (g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284(v_a_2436));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam5, 1, 3, (V[]){v_m_2439, v_b_2437, v_c_2438});
  }
  default: return heff_nomatch(v_x2_27_240);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_n_241});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam1(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_n_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam2(V self, V *args) {
  V v_n_247 = args[0];
  V v_a_246 = heff_env(self)[0];
  V v_y_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_a_248 = heff_tr(heff_call(v_a_246, 1, (V[]){v_n_247}));
  V v_x2_2411;
  switch (heff_tag_of(v_a_248)) {
  case TAG_MkPair: {
    V v_a_249 = heff_field(v_a_248, 0);
    V v_a_2410 = heff_field(v_a_248, 1);
    V v_ru_24a_248_24MkPair = heff_take_reuse_n(v_a_248, 3ULL, 2);
    v_x2_2411 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24a_248_24MkPair, v_a_249, v_a_2410));
    break;
  }
  default: heff_nomatch(v_a_248);
  }
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_n_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    V v_a_2414 = (g_heff_2ecompile_2eir_2etraversePartsM_24s918583443x65542255(v_y_245));
    V v_a_2415 = heff_tr(heff_call(v_a_2414, 1, (V[]){v_n_2413}));
    V v_x2_2418;
    switch (heff_tag_of(v_a_2415)) {
    case TAG_MkPair: {
      V v_a_2416 = heff_field(v_a_2415, 0);
      V v_a_2417 = heff_field(v_a_2415, 1);
      V v_ru_24a_2415_24MkPair = heff_take_reuse_n(v_a_2415, 3ULL, 2);
      v_x2_2418 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24a_2415_24MkPair, v_a_2416, v_a_2417));
      break;
    }
    default: heff_nomatch(v_a_2415);
    }
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_n_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_243, v_x_2412, v_x_2419}), v_n_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam3(V self, V *args) {
  V v_n_2423 = args[0];
  V v_a_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_a_2424 = heff_tr(heff_call(v_a_2422, 1, (V[]){v_n_2423}));
  V v_x2_2427;
  switch (heff_tag_of(v_a_2424)) {
  case TAG_MkPair: {
    V v_a_2425 = heff_field(v_a_2424, 0);
    V v_a_2426 = heff_field(v_a_2424, 1);
    V v_ru_24a_2424_24MkPair = heff_take_reuse_n(v_a_2424, 3ULL, 2);
    v_x2_2427 = (g_heff_2ecompile_2erematch_2ematchOf_24tok2(v_ru_24a_2424_24MkPair, v_a_2425, v_a_2426));
    break;
  }
  default: heff_nomatch(v_a_2424);
  }
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_field(v_x2_2427, 0);
    V v_n_2429 = heff_field(v_x2_2427, 1);
    V v_ru_24x2_2427_24MkPair = heff_take_reuse_n(v_x2_2427, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2428}), v_n_2429});
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam4(V self, V *args) {
  V v_n_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2434}), v_n_2435});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284_lam5(V self, V *args) {
  V v_n_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_b_2437 = heff_env(self)[1];
  V v_c_2438 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_n_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_n_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    V v_m_2444 = (g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284(v_b_2437));
    V v_x2_2445 = heff_tr(heff_call(v_m_2444, 1, (V[]){v_n_2443}));
    switch (heff_tag_of(v_x2_2445)) {
    case TAG_MkPair: {
      V v_x_2446 = heff_field(v_x2_2445, 0);
      V v_n_2447 = heff_field(v_x2_2445, 1);
      heff_take_n(v_x2_2445, 3ULL, 2);
      V v_m_2448 = (g_heff_2ecompile_2eir_2econdTraverse_24s1374841266x1883638284(v_c_2438));
      V v_x2_2449 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_n_2447}));
      switch (heff_tag_of(v_x2_2449)) {
      case TAG_MkPair: {
        V v_x_2450 = heff_field(v_x2_2449, 0);
        V v_n_2451 = heff_field(v_x2_2449, 1);
        heff_take_n(v_x2_2449, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2442, v_x_2446, v_x_2450}), v_n_2451});
      }
      default: return heff_nomatch(v_x2_2449);
      }
    }
    default: return heff_nomatch(v_x2_2445);
    }
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_lam4(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_entry, 2, 0};

V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267(V v_f_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EApp: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2411 = heff_tr(g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267(v_f_240, v_b_2410));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_lam0, 1, 3, (V[]){v_m_2411, v_x_248, v_a_249});
  }
  case TAG_ERecord: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EProj: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ETag: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EMatch: {
    V v_s_2425 = heff_field(v_e_241, 0);
    V v_arms_2426 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2436 = (g_prelude_2etraverse_24s1587080482x1917521257(heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_lam1, 1, 1, (V[]){v_f_240}), v_arms_2426));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_lam3, 1, 2, (V[]){v_m_2436, v_s_2425});
  }
  case TAG_EPrim: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ECall: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EBool: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ESet: {
    V v_xs_2454 = heff_field(v_e_241, 0);
    V v_a_2455 = heff_field(v_e_241, 1);
    V v_b_2456 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2457 = heff_tr(g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267(v_f_240, v_b_2456));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_lam4, 1, 3, (V[]){v_m_2457, v_xs_2454, v_a_2455});
  }
  case TAG_EValues: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_lam0(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_a_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_248, v_a_249, v_x_2414}), v_n_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_lam2(V self, V *args) {
  V v_n_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_t_2428 = heff_env(self)[1];
  V v_vs_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2428, v_vs_2429, v_x_2434}), v_n_2435});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_lam1(V self, V *args) {
  V v_x2_2427 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkArm: {
    V v_t_2428 = heff_field(v_x2_2427, 0);
    V v_vs_2429 = heff_field(v_x2_2427, 1);
    V v_b_2430 = heff_field(v_x2_2427, 2);
    heff_take_n(v_x2_2427, 7ULL, 3);
    V v_m_2431 = heff_tr(g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267(v_f_240, v_b_2430));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_lam2, 1, 3, (V[]){v_m_2431, v_t_2428, v_vs_2429});
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_lam3(V self, V *args) {
  V v_n_2437 = args[0];
  V v_m_2436 = heff_env(self)[0];
  V v_s_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2438 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2437}));
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x2_2438, 0);
    V v_n_2440 = heff_field(v_x2_2438, 1);
    V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2425, v_x_2439}), v_n_2440});
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1286122565x321595267_lam4(V self, V *args) {
  V v_n_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_xs_2454 = heff_env(self)[1];
  V v_a_2455 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_n_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_n_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2454, v_a_2455, v_x_2460}), v_n_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
Clo g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_entry, 3, 0};

V g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568(V v_ys_240, V v_x_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x2_242, 0);
    V v_argv_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2444;
    switch (heff_tag_of(v_a_243)) {
    case TAG_EVar: {
      V v_y_245 = heff_dup(heff_field(v_a_243, 0));
      v_t_2444 = heff_bool(heff_strEq_c_lent(v_x_241, v_y_245, 0));
      heff_drop(v_y_245);
      break;
    }
    case TAG_EGlobal: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2444 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
      heff_drop(v_a_243);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_2444);
      V t_0 = v_ys_240;
      V t_1 = v_x_241;
      V t_2 = v_argv_244;
      v_ys_240 = t_0;
      v_x_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_2444);
      V v_cell_2445 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_a_243, heff_hole()});
      V v_u_2446 = (g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_24dps(v_ys_240, v_x_241, v_argv_244, heff_dup(v_cell_2445)));
      heff_drop(v_u_2446);
      return v_cell_2445;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_24dps_entry, 4, 0};

V g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_24dps(V v_ys_240, V v_x_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x2_242, 0);
    V v_argv_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_2445;
    switch (heff_tag_of(v_a_244)) {
    case TAG_EVar: {
      V v_y_246 = heff_dup(heff_field(v_a_244, 0));
      v_t_2445 = heff_bool(heff_strEq_c_lent(v_x_241, v_y_246, 0));
      heff_drop(v_y_246);
      break;
    }
    case TAG_EGlobal: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
      heff_drop(v_a_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_2445);
      V t_0 = v_ys_240;
      V t_1 = v_x_241;
      V t_2 = v_argv_245;
      V t_3 = v_d_243;
      v_ys_240 = t_0;
      v_x_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2445);
      V v_cell_2446 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_a_244, heff_hole()});
      V v_u_2447 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2446));
      heff_drop(v_u_2447);
      V t_0 = v_ys_240;
      V t_1 = v_x_241;
      V t_2 = v_argv_245;
      V t_3 = v_cell_2446;
      v_ys_240 = t_0;
      v_x_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_24dps(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_24dps_entry, 3, 0};

V g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V v_t_247 = ({ V a_0 = v_x_243; V a_1 = v_xs_244; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_243); r_; });
    V t_0 = v_ys_240;
    V t_1 = v_t_247;
    V t_2 = v_cell_245;
    v_ys_240 = t_0;
    v_x1_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eappendI_24f1052028844x337821012_24dps(a[0], a[1], a[2]);
}