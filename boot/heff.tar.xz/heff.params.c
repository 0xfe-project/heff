// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
Clo g_heff_2eparams_2eeqLevel_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eparams_2eeqLevel_entry, 2, 0};

V g_heff_2eparams_2eeqLevel(V v_a_240, V v_b_241) {
top: ;
  switch (heff_tag_of(v_a_240)) {
  case TAG_Small: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_Small: {
      return NTAG(TAG_True);
    }
    case TAG_Large: {
      switch (heff_tag_of(v_a_240)) {
      case TAG_Small: {
        return NTAG(TAG_False);
      }
      case TAG_Large: {
        return NTAG(TAG_True);
      }
      case TAG_TopL: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_a_240);
      }
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_a_240)) {
      case TAG_Small: {
        return NTAG(TAG_False);
      }
      case TAG_Large: {
        return NTAG(TAG_False);
      }
      case TAG_TopL: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_a_240);
      }
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  case TAG_Large: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_Small: {
      return NTAG(TAG_False);
    }
    case TAG_Large: {
      switch (heff_tag_of(v_b_241)) {
      case TAG_Small: {
        return NTAG(TAG_True);
      }
      case TAG_Large: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_True);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      case TAG_TopL: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_False);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_b_241)) {
      case TAG_Small: {
        return NTAG(TAG_True);
      }
      case TAG_Large: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_True);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      case TAG_TopL: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_False);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  case TAG_TopL: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_Small: {
      return NTAG(TAG_False);
    }
    case TAG_Large: {
      return NTAG(TAG_False);
    }
    case TAG_TopL: {
      switch (heff_tag_of(v_b_241)) {
      case TAG_Small: {
        return NTAG(TAG_True);
      }
      case TAG_Large: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_True);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      case TAG_TopL: {
        switch (heff_tag_of(v_a_240)) {
        case TAG_Small: {
          return NTAG(TAG_False);
        }
        case TAG_Large: {
          return NTAG(TAG_False);
        }
        case TAG_TopL: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_a_240);
        }
      }
      default: return heff_nomatch(v_b_241);
      }
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  default: return heff_nomatch(v_a_240);
  }
}
V g_heff_2eparams_2eeqLevel_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eparams_2eeqLevel(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}

static V g_heff_2eparams_2enoSpan_val;
static int g_heff_2eparams_2enoSpan_st;
static V g_heff_2eparams_2enoSpan_init(void) {
  return heff_rec(2, shape_320_83, (V[]){MK_INT(0LL), MK_INT(0LL)});
}
V g_heff_2eparams_2enoSpan_get(void) {
  if (g_heff_2eparams_2enoSpan_st == 2) return g_heff_2eparams_2enoSpan_val;
  if (g_heff_2eparams_2enoSpan_st == 1) heff_fail("defined by itself");
  g_heff_2eparams_2enoSpan_st = 1;
  g_heff_2eparams_2enoSpan_val = heff_tr(g_heff_2eparams_2enoSpan_init());
  g_heff_2eparams_2enoSpan_st = 2;
  return g_heff_2eparams_2enoSpan_val;
}

static V g_heff_2eparams_2eemptyShape_val;
static int g_heff_2eparams_2eemptyShape_st;
static V g_heff_2eparams_2eemptyShape_init(void) {
  return heff_rec(2, shape_168_200, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
}
V g_heff_2eparams_2eemptyShape_get(void) {
  if (g_heff_2eparams_2eemptyShape_st == 2) return g_heff_2eparams_2eemptyShape_val;
  if (g_heff_2eparams_2eemptyShape_st == 1) heff_fail("defined by itself");
  g_heff_2eparams_2eemptyShape_st = 1;
  g_heff_2eparams_2eemptyShape_val = heff_tr(g_heff_2eparams_2eemptyShape_init());
  g_heff_2eparams_2eemptyShape_st = 2;
  return g_heff_2eparams_2eemptyShape_val;
}
V g_heff_2eparams_2evariantsMap_24s303_lam2(V self, V *args);
V g_heff_2eparams_2evariantsMap_24s303_lam1(V self, V *args);
V g_heff_2eparams_2evariantsMap_24s303_lam0(V self, V *args);
Clo g_heff_2eparams_2evariantsMap_24s303_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eparams_2evariantsMap_24s303_entry, 1, 0};

V g_heff_2eparams_2evariantsMap_24s303(V v_vs_240) {
top: ;
  V v_xs_241 = heff_get(heff_dup(v_vs_240), LBL_values);
  V v_t_2411 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_241)), heff_clo(g_heff_2eparams_2evariantsMap_24s303_lam0, 1, 1, (V[]){v_xs_241}));
  return heff_rec(3, shape_153_35_368, (V[]){heff_get(heff_dup(v_vs_240), LBL_keys), heff_get(v_vs_240, LBL_byName), v_t_2411});
}
V g_heff_2eparams_2evariantsMap_24s303_entry(V self, V *a) {
  (void)self;
  return g_heff_2eparams_2evariantsMap_24s303(a[0]);
}
V g_heff_2eparams_2evariantsMap_24s303_lam2(V self, V *args) {
  V v_u2_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_246);
  V v_x1_247 = heff_tr(heff_apply(heff_get(v_m_245, LBL_val), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Nom: {
    V v_x_248 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 1);
    return v_x_248;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_247, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2410 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 1);
    return v_x_2410;
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2eparams_2evariantsMap_24s303_lam1(V self, V *args) {
  V v_i_244 = args[0];
  V v_xs_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_245 = heff_arrayIndex(v_xs_243, v_i_244);
  return heff_clo(g_heff_2eparams_2evariantsMap_24s303_lam2, 1, 1, (V[]){v_m_245});
}
V g_heff_2eparams_2evariantsMap_24s303_lam0(V self, V *args) {
  V v_i_242 = args[0];
  V v_xs_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_243 = heff_arrayIndex(v_xs_241, v_i_242);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_243)), heff_clo(g_heff_2eparams_2evariantsMap_24s303_lam1, 1, 1, (V[]){v_xs_243}));
}