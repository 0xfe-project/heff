// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_arity 294440695
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_consumers 1203455020
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_fresh 299054408
#define LBL_go 10063
#define LBL_goes 9673821
#define LBL_key 315609
#define LBL_left 9813198
#define LBL_made 9839068
#define LBL_name 9869138
#define LBL_params 951713969
#define LBL_producers 572620898
#define LBL_rest 9992347
#define LBL_safe 10017876
#define LBL_supply 1056026650
#define LBL_tags 10047712
#define LBL_total 311908190
#define LBL_underLam 296337946
#define LBL_x 338
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_defs__supply[] = {LBL_defs, LBL_supply};
static uint32_t shape_go[] = {LBL_go};
static uint32_t shape_key__arity__at__rest[] = {LBL_key, LBL_arity, LBL_at, LBL_rest};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_params__body__tags[] = {LBL_params, LBL_body, LBL_tags};
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_supply__consumers__producers__made__fresh__left[] = {LBL_supply, LBL_consumers, LBL_producers, LBL_made, LBL_fresh, LBL_left};
V g_heff_2ecompile_2efuse_2earmKind(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2earmKind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2earmKind_clo;
V g_heff_2ecompile_2efuse_2earmKindR(V, V);
V g_heff_2ecompile_2efuse_2earmKindR_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2earmKindR_clo;
V g_heff_2ecompile_2efuse_2earmWorks(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2earmWorks_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2earmWorks_clo;
V g_heff_2ecompile_2efuse_2ecallOf(V, V, V);
V g_heff_2ecompile_2efuse_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ecallOf_clo;
V g_heff_2ecompile_2efuse_2econsumerOf(V, V);
V g_heff_2ecompile_2efuse_2econsumerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2econsumerOf_clo;
V g_heff_2ecompile_2efuse_2econsumerWith(V, V, V, V, V);
V g_heff_2ecompile_2efuse_2econsumerWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2econsumerWith_clo;
V g_heff_2ecompile_2efuse_2eelemF(V, V);
V g_heff_2ecompile_2efuse_2eelemF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eelemF_clo;
V g_heff_2ecompile_2efuse_2efindArm(V, V);
V g_heff_2ecompile_2efuse_2efindArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efindArm_clo;
V g_heff_2ecompile_2efuse_2efuseNew(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2efuse_2efuseNew_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseNew_clo;
V g_heff_2ecompile_2efuse_2efuseProgram(V, V);
V g_heff_2ecompile_2efuse_2efuseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2efuseProgram_clo;
V g_heff_2ecompile_2efuse_2eglobalCall(V);
V g_heff_2ecompile_2efuse_2eglobalCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eglobalCall_clo;
V g_heff_2ecompile_2efuse_2egoesOf(V);
V g_heff_2ecompile_2efuse_2egoesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2egoesOf_clo;
V g_heff_2ecompile_2efuse_2egoesOf_24dps(V, V);
V g_heff_2ecompile_2efuse_2egoesOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2egoesOf_24dps_clo;
V g_heff_2ecompile_2efuse_2einitF_24dps(V, V);
V g_heff_2ecompile_2efuse_2einitF_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2einitF_24dps_clo;
V g_heff_2ecompile_2efuse_2ekidsF(V, V);
V g_heff_2ecompile_2efuse_2ekidsF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ekidsF_clo;
V g_heff_2ecompile_2efuse_2elastF(V);
V g_heff_2ecompile_2efuse_2elastF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2elastF_clo;
V g_heff_2ecompile_2efuse_2emakeFused(V, V, V, V);
V g_heff_2ecompile_2efuse_2emakeFused_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2emakeFused_clo;
V g_heff_2ecompile_2efuse_2epathCalls(V, V);
V g_heff_2ecompile_2efuse_2epathCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2epathCalls_clo;
V g_heff_2ecompile_2efuse_2eplugArgs(V, V, V, V);
V g_heff_2ecompile_2efuse_2eplugArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eplugArgs_clo;
V g_heff_2ecompile_2efuse_2eplugGo(V, V, V, V);
V g_heff_2ecompile_2efuse_2eplugGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eplugGo_clo;
V g_heff_2ecompile_2efuse_2eplugK(V);
V g_heff_2ecompile_2efuse_2eplugK_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eplugK_clo;
V g_heff_2ecompile_2efuse_2eposF(V, V, V);
V g_heff_2ecompile_2efuse_2eposF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eposF_clo;
V g_heff_2ecompile_2efuse_2eproducerOf(V, V);
V g_heff_2ecompile_2efuse_2eproducerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eproducerOf_clo;
V g_heff_2ecompile_2efuse_2eremoveAt(V, V);
V g_heff_2ecompile_2efuse_2eremoveAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eremoveAt_clo;
V g_heff_2ecompile_2efuse_2eremoveAt_24dps(V, V, V);
V g_heff_2ecompile_2efuse_2eremoveAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eremoveAt_24dps_clo;
V g_heff_2ecompile_2efuse_2eselfCalls(V, V, V);
V g_heff_2ecompile_2efuse_2eselfCalls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfCalls_clo;
V g_heff_2ecompile_2efuse_2eselfOut(V, V);
V g_heff_2ecompile_2efuse_2eselfOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfOut_clo;
V g_heff_2ecompile_2efuse_2eselfOut_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2eselfOut_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eselfOut_24dps_clo;
V g_heff_2ecompile_2efuse_2esetAt(V, V, V);
V g_heff_2ecompile_2efuse_2esetAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esetAt_clo;
V g_heff_2ecompile_2efuse_2esetAt_24dps(V, V, V, V);
V g_heff_2ecompile_2efuse_2esetAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esetAt_24dps_clo;
V g_heff_2ecompile_2efuse_2esites(V, V);
V g_heff_2ecompile_2efuse_2esites_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2esites_clo;
V g_heff_2ecompile_2efuse_2etailsOf(V);
V g_heff_2ecompile_2efuse_2etailsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2etailsOf_clo;
V g_heff_2ecompile_2efuse_2etraverseF(V, V);
V g_heff_2ecompile_2efuse_2etraverseF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2etraverseF_clo;
V g_heff_2ecompile_2efuse_2etraverseF_24s847914641x1886275130(V, V);
V g_heff_2ecompile_2efuse_2etraverseF_24s847914641x1886275130_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2etraverseF_24s847914641x1886275130_clo;
V g_heff_2ecompile_2efuse_2evarAt(V, V, V);
V g_heff_2ecompile_2efuse_2evarAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2evarAt_clo;
V g_heff_2ecompile_2efuse_2ewithMade(V, V, V, V);
V g_heff_2ecompile_2efuse_2ewithMade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2ewithMade_clo;
V g_heff_2ecompile_2efuse_2eworkPure(V, V);
V g_heff_2ecompile_2efuse_2eworkPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eworkPure_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s78130935x581779089(V, V, V);
V g_list_2eany_24s78130935x581779089_entry(V self, V *a);
extern Clo g_list_2eany_24s78130935x581779089_clo;
V g_list_2efoldl_24s1200572259x609044042(V, V);
V g_list_2efoldl_24s1200572259x609044042_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1200572259x609044042_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2002556150x421739076(V, V);
V g_list_2efoldl_24s2002556150x421739076_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2002556150x421739076_clo;
V g_list_2efoldl_24s316188476x878636287(V, V);
V g_list_2efoldl_24s316188476x878636287_entry(V self, V *a);
extern Clo g_list_2efoldl_24s316188476x878636287_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s890299851x180637966(V, V);
V g_list_2efoldl_24s890299851x180637966_entry(V self, V *a);
extern Clo g_list_2efoldl_24s890299851x180637966_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1229912102x1467950109(V, V);
V g_list_2emap_24f1229912102x1467950109_entry(V self, V *a);
extern Clo g_list_2emap_24f1229912102x1467950109_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24s866308031x234213482(V, V, V, V, V);
V g_list_2emap_24s866308031x234213482_entry(V self, V *a);
extern Clo g_list_2emap_24s866308031x234213482_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s738847920x410598254(V, V);
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_clo;
V g_map_2eempty_get(void);
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f677743828x1026746250(V, V, V);
V g_prelude_2e_2b_2b_24f677743828x1026746250_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f677743828x1026746250_clo;
Clo g_heff_2ecompile_2efuse_2eremoveAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eremoveAt_24dps_entry, 3, 0};

V g_heff_2ecompile_2efuse_2eremoveAt_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_xs_244);
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2eremoveAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eremoveAt_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2efuse_2esetAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2esetAt_entry, 3, 0};

V g_heff_2ecompile_2efuse_2esetAt(V v_i_240, V v_y_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_y_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      heff_drop(v_x_243);
      return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_241, v_xs_244});
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2efuse_2esetAt_24dps(heff_intSub(v_i_240, MK_INT(1LL)), v_y_241, v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2esetAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2esetAt(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2efuse_2einitF_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2einitF_24dps_entry, 2, 0};

V g_heff_2ecompile_2efuse_2einitF_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_x12_243;
      V t_1 = v_cell_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2einitF_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2einitF_24dps(a[0], a[1]);
}
Clo g_heff_2ecompile_2efuse_2ecallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ecallOf_entry, 3, 0};

V g_heff_2ecompile_2efuse_2ecallOf(V v_g_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    V v_x31_247 = heff_field(v_x3_242, 0);
    V v_as_248 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_247)) {
    case TAG_EVar: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      V v_h_2410 = heff_field(v_x31_247, 0);
      if (heff_strEq_c_lent(v_g_240, v_h_2410, 1)) {
        V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_248));
        if (heff_intEq_c(v_t_2412, v_n_241)) {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_as_248)});
        } else {
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_n_241);
        return NTAG(TAG_Nothing);
      }
    }
    case TAG_ELam: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_drop(v_g_240);
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x31_247);
    }
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    V v_h_2463 = heff_field(v_x3_242, 0);
    V v_as_2464 = heff_field(v_x3_242, 1);
    if (heff_strEq_c_lent(v_g_240, v_h_2463, 1)) {
      V v_t_2466 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2464));
      if (heff_intEq_c(v_t_2466, v_n_241)) {
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_as_2464)});
      } else {
        return NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_n_241);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EBytes: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2efuse_2ecallOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2efuse_2ecallOf(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2efuse_2eglobalCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eglobalCall_entry, 1, 0};

V g_heff_2ecompile_2efuse_2eglobalCall(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    V v_as_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_EVar: {
      heff_take_n(v_x11_245, 0ULL, 1);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      V v_g_248 = heff_field(v_x11_245, 0);
      V v_ru_24x11_245_24EGlobal = heff_take_reuse_n(v_x11_245, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x11_245_24EGlobal, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_MkPair, 2, (V[]){v_g_248, v_as_246})});
    }
    case TAG_ELam: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x11_245, 0ULL, 3);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x11_245, 0ULL, 4);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x11_245, 0ULL, 3);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x11_245, 0ULL, 1);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_x11_245, 0ULL, 1);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_na(v_x11_245, 0ULL, 1);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_x11_245, 0ULL, 1);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_take_n(v_x11_245, 0ULL, 1);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x11_245, 0ULL, 1);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x11_245, 0ULL, 2);
      heff_drop(v_as_246);
      heff_drop_cell(v_ru_24x1_240_24EApp, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    V v_g_2458 = heff_field(v_x1_240, 0);
    V v_as_2459 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_MkPair, 2, (V[]){v_g_2458, v_as_2459})});
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2eglobalCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eglobalCall(a[0]);
}
V g_heff_2ecompile_2efuse_2eselfCalls_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eselfCalls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eselfCalls_entry, 3, 0};

V g_heff_2ecompile_2efuse_2eselfCalls(V v_me_240, V v_g_241, V v_as_242) {
top: ;
  if (heff_strEq_c(v_g_241, heff_dup(heff_rfield(v_me_240, 0)))) {
    V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_242));
    if (heff_intEq_c(v_t_244, heff_dup(heff_rfield(v_me_240, 1)))) {
      V v_t_246 = (g_heff_2ecompile_2efuse_2evarAt(heff_dup(heff_rfield(v_me_240, 2)), heff_dup(heff_rfield(v_me_240, 3)), v_as_242));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_x1_2410 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2efuse_2eselfCalls_lam0, 1, 1, (V[]){v_me_240}), v_as_242));
        if ((heff_dup(v_x1_2410) == NTAG(TAG_True))) {
          heff_drop(v_x1_2410);
          return NTAG(TAG_Nothing);
        } else {
          heff_drop(v_x1_2410);
          return heff_tag_n(TAG_Just, 1, (V[]){MK_INT(1LL)});
        }
      } else {
        heff_drop_rec(v_me_240, 4);
        heff_drop(v_t_246);
        return NTAG(TAG_Nothing);
      }
    } else {
      heff_drop_rec(v_me_240, 4);
      return NTAG(TAG_Nothing);
    }
  } else {
    heff_drop_rec(v_me_240, 4);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2efuse_2eselfCalls_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2efuse_2eselfCalls(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2efuse_2eselfCalls_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_me_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2ecompile_2eir_2eglobalsGo(v_e_247));
  V v_t_249 = (g_heff_2ecompile_2eir_2enubI(v_t_248));
  return ({ V a_0 = heff_get_n(v_me_240, 0, 4); V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2efuse_2eelemF(a_0, a_1)); heff_drop(v_t_249); r_; });
}
HEFF_LIT(g_heff_2ecompile_2efuse_2eselfOut_24dps_str0, 5, "$self");
HEFF_LIT(g_heff_2ecompile_2efuse_2eselfOut_24dps_str1, 5, "$self");
V g_heff_2ecompile_2efuse_2eselfOut_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2eselfOut_24dps_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eselfOut_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eselfOut_24dps_entry, 4, 0};

V g_heff_2ecompile_2efuse_2eselfOut_24dps(V v_me_240, V v_e_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_me_240, 4);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_me_240, 4);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_cell_248 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_xs_246, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_me_240;
    V t_1 = v_b_247;
    V t_2 = v_cell_248;
    V t_3 = MK_INT(1LL);
    v_me_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EApp: {
    V v_e1_2410 = heff_field(v_e_241, 0);
    V v_as_2411 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_e1_2410)) {
    case TAG_EVar: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_2413 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2415 = (g_list_2emap(v_t_2414, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2413, v_t_2415}));
    }
    case TAG_EGlobal: {
      V v_g_2416 = heff_field(v_e1_2410, 0);
      heff_take_n(v_e1_2410, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_g_2416), heff_dup(heff_rfield(v_me_240, 0)))) {
        V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_2411));
        if (heff_intEq_c(v_t_2418, heff_dup(heff_rfield(v_me_240, 1)))) {
          V v_t_2420 = (g_heff_2ecompile_2efuse_2evarAt(heff_dup(heff_rfield(v_me_240, 2)), heff_dup(heff_rfield(v_me_240, 3)), v_as_2411));
          if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24e_241_24EApp, 2);
            heff_drop(v_g_2416);
            heff_drop(v_t_2420);
            V v_t_2421 = (g_heff_2ecompile_2efuse_2eremoveAt(heff_dup(heff_rfield(v_me_240, 2)), heff_dup(v_as_2411)));
            V v_t_2422 = (g_list_2emap_24f1229912102x1467950109(heff_get_n(v_me_240, 2, 4), v_as_2411));
            return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2efuse_2eselfOut_24dps_str0), v_t_2421, v_t_2422}));
          } else {
            heff_drop(v_t_2420);
            V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
            V v_t_2424 = (g_list_2emap(v_t_2423, v_as_2411));
            V v_t_2425 = heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2416}), v_t_2424});
            return heff_setField(v_d_242, v_i_243, v_t_2425);
          }
        } else {
          V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
          V v_t_2427 = (g_list_2emap(v_t_2426, v_as_2411));
          V v_t_2428 = heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2416}), v_t_2427});
          return heff_setField(v_d_242, v_i_243, v_t_2428);
        }
      } else {
        V v_t_2429 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
        V v_t_2430 = (g_list_2emap(v_t_2429, v_as_2411));
        V v_t_2431 = heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2416}), v_t_2430});
        return heff_setField(v_d_242, v_i_243, v_t_2431);
      }
    }
    case TAG_ELam: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_2434 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_2435 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2436 = (g_list_2emap(v_t_2435, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2434, v_t_2436}));
    }
    case TAG_EApp: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_2439 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_2440 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2441 = (g_list_2emap(v_t_2440, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2439, v_t_2441}));
    }
    case TAG_ELet: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_2445 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_2446 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2447 = (g_list_2emap(v_t_2446, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2445, v_t_2447}));
    }
    case TAG_ERecord: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_2450 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_2451 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2452 = (g_list_2emap(v_t_2451, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2450, v_t_2452}));
    }
    case TAG_EProj: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_2457 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_2458 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2459 = (g_list_2emap(v_t_2458, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2457, v_t_2459}));
    }
    case TAG_ETag: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_2463 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_2464 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2465 = (g_list_2emap(v_t_2464, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2463, v_t_2465}));
    }
    case TAG_EMatch: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_2468 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_2469 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2470 = (g_list_2emap(v_t_2469, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2468, v_t_2470}));
    }
    case TAG_EPrim: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_2472 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_2473 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2474 = (g_list_2emap(v_t_2473, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2472, v_t_2474}));
    }
    case TAG_EPrimCall: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_2477 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_2478 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2479 = (g_list_2emap(v_t_2478, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2477, v_t_2479}));
    }
    case TAG_ECall: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_2482 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_2483 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2484 = (g_list_2emap(v_t_2483, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2482, v_t_2484}));
    }
    case TAG_EInt: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_2486 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_2487 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2488 = (g_list_2emap(v_t_2487, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2486, v_t_2488}));
    }
    case TAG_EFloat: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_2490 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_2491 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2492 = (g_list_2emap(v_t_2491, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2490, v_t_2492}));
    }
    case TAG_EStr: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_2494 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_2495 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_2496 = (g_list_2emap(v_t_2495, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2494, v_t_2496}));
    }
    case TAG_EBytes: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_2498 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_2499 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24100 = (g_list_2emap(v_t_2499, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2498, v_t_24100}));
    }
    case TAG_EFixed: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_24103 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_24104 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24105 = (g_list_2emap(v_t_24104, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_24103, v_t_24105}));
    }
    case TAG_EFloat32: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_24107 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_24108 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24109 = (g_list_2emap(v_t_24108, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_24107, v_t_24109}));
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_24110 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_24111 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24112 = (g_list_2emap(v_t_24111, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_24110, v_t_24112}));
    }
    case TAG_EFix: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      V v_t_24115 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_e1_2410));
      V v_t_24116 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24117 = (g_list_2emap(v_t_24116, v_as_2411));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_24115, v_t_24117}));
    }
    default: return heff_nomatch(v_e1_2410);
    }
  }
  case TAG_ELet: {
    V v_x_24118 = heff_field(v_e_241, 0);
    V v_a_24119 = heff_field(v_e_241, 1);
    V v_b_24120 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_24121 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_a_24119));
    V v_cell_24122 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_24118, v_t_24121, heff_hole()});
    V v_u_24123 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_24122));
    heff_drop(v_u_24123);
    V t_0 = v_me_240;
    V t_1 = v_b_24120;
    V t_2 = v_cell_24122;
    V t_3 = MK_INT(2LL);
    v_me_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_24124 = heff_field(v_e_241, 0);
    V v_ts_24125 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_24134 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2efuse_2eselfOut_24dps_lam0, 1, 1, (V[]){v_me_240}), v_fs_24124));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_24134, v_ts_24125}));
  }
  case TAG_EProj: {
    V v_e1_24135 = heff_field(v_e_241, 0);
    V v_l_24136 = heff_field(v_e_241, 1);
    V v_sh_24137 = heff_field(v_e_241, 2);
    V v_t_24138 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 15ULL, 4);
    V v_t_24139 = (g_heff_2ecompile_2efuse_2eselfOut(v_me_240, v_e1_24135));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EProj, 4, (V[]){v_t_24139, v_l_24136, v_sh_24137, v_t_24138}));
  }
  case TAG_ETag: {
    V v_t_24140 = heff_field(v_e_241, 0);
    V v_as_24141 = heff_field(v_e_241, 1);
    V v_ts_24142 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_t_24143 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
    V v_t_24144 = (g_list_2emap(v_t_24143, v_as_24141));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ETag, 3, (V[]){v_t_24140, v_t_24144, v_ts_24142}));
  }
  case TAG_EMatch: {
    V v_s_24145 = heff_field(v_e_241, 0);
    V v_arms_24146 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_24147 = (g_heff_2ecompile_2efuse_2eselfOut(heff_dup(v_me_240), v_s_24145));
    V v_f_24148 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
    V v_t_24154 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2efuse_2eselfOut_24dps_lam1, 1, 1, (V[]){v_f_24148}), v_arms_24146));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_24147, v_t_24154}));
  }
  case TAG_EPrim: {
    heff_drop_rec(v_me_240, 4);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EPrimCall: {
    V v_p_24156 = heff_field(v_e_241, 0);
    V v_as_24157 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_24158 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
    V v_t_24159 = (g_list_2emap(v_t_24158, v_as_24157));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_24156, v_t_24159}));
  }
  case TAG_ECall: {
    V v_g_24160 = heff_field(v_e_241, 0);
    V v_as_24161 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_24160), heff_dup(heff_rfield(v_me_240, 0)))) {
      V v_t_24163 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_as_24161));
      if (heff_intEq_c(v_t_24163, heff_dup(heff_rfield(v_me_240, 1)))) {
        V v_t_24165 = (g_heff_2ecompile_2efuse_2evarAt(heff_dup(heff_rfield(v_me_240, 2)), heff_dup(heff_rfield(v_me_240, 3)), v_as_24161));
        if ((heff_dup(v_t_24165) == NTAG(TAG_True))) {
          heff_drop(v_g_24160);
          heff_drop(v_t_24165);
          V v_t_24166 = (g_heff_2ecompile_2efuse_2eremoveAt(heff_dup(heff_rfield(v_me_240, 2)), heff_dup(v_as_24161)));
          V v_t_24167 = (g_list_2emap_24f1229912102x1467950109(heff_get_n(v_me_240, 2, 4), v_as_24161));
          return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2efuse_2eselfOut_24dps_str1), v_t_24166, v_t_24167}));
        } else {
          heff_drop(v_t_24165);
          V v_t_24168 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
          V v_t_24169 = (g_list_2emap(v_t_24168, v_as_24161));
          return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ECall, 2, (V[]){v_g_24160, v_t_24169}));
        }
      } else {
        V v_t_24170 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
        V v_t_24171 = (g_list_2emap(v_t_24170, v_as_24161));
        return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ECall, 2, (V[]){v_g_24160, v_t_24171}));
      }
    } else {
      V v_t_24172 = heff_tr(heff_call(((V)&g_heff_2ecompile_2efuse_2eselfOut_clo), 1, (V[]){v_me_240}));
      V v_t_24173 = (g_list_2emap(v_t_24172, v_as_24161));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ECall, 2, (V[]){v_g_24160, v_t_24173}));
    }
  }
  case TAG_EInt: {
    heff_drop_rec(v_me_240, 4);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_me_240, 4);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EStr: {
    heff_drop_rec(v_me_240, 4);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_me_240, 4);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_me_240, 4);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_me_240, 4);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_me_240, 4);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFix: {
    heff_drop_rec(v_me_240, 4);
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2efuse_2eselfOut_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eselfOut_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2efuse_2eselfOut_24dps_lam0(V self, V *args) {
  V v_p_24126 = args[0];
  V v_me_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24129;
  switch (heff_tag_of(v_p_24126)) {
  case TAG_MkPair: {
    V v_x_24127 = heff_dup(heff_field(v_p_24126, 0));
    v_t_24129 = v_x_24127;
    break;
  }
  default: heff_nomatch(v_p_24126);
  }
  V v_t_24132;
  switch (heff_tag_of(v_p_24126)) {
  case TAG_MkPair: {
    V v_y_24131 = heff_field(v_p_24126, 1);
    heff_take_n(v_p_24126, 2ULL, 2);
    v_t_24132 = v_y_24131;
    break;
  }
  default: heff_nomatch(v_p_24126);
  }
  V v_t_24133 = (g_heff_2ecompile_2efuse_2eselfOut(v_me_240, v_t_24132));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24129, v_t_24133});
}
V g_heff_2ecompile_2efuse_2eselfOut_24dps_lam1(V self, V *args) {
  V v_x2_24149 = args[0];
  V v_f_24148 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_24149)) {
  case TAG_MkArm: {
    V v_t_24150 = heff_field(v_x2_24149, 0);
    V v_vs_24151 = heff_field(v_x2_24149, 1);
    V v_b_24152 = heff_field(v_x2_24149, 2);
    V v_ru_24x2_24149_24MkArm = heff_take_reuse_n(v_x2_24149, 7ULL, 3);
    V v_t_24153 = heff_tr(heff_call(v_f_24148, 1, (V[]){v_b_24152}));
    return heff_tag_at_n(v_ru_24x2_24149_24MkArm, TAG_MkArm, 3, (V[]){v_t_24150, v_vs_24151, v_t_24153});
  }
  default: return heff_nomatch(v_x2_24149);
  }
}
Clo g_heff_2ecompile_2efuse_2earmKindR_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2earmKindR_entry, 2, 0};

V g_heff_2ecompile_2efuse_2earmKindR(V v_me_240, V v_b_241) {
top: ;
  V v_it_242 = (g_heff_2ecompile_2efuse_2epathCalls(heff_dup(v_me_240), heff_dup(v_b_241)));
  switch (heff_tag_of(v_it_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_me_240, 4);
    heff_drop(v_b_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_it1_243 = heff_field(v_it_242, 0);
    V v_ru_24it_242_24Just = heff_take_reuse_n(v_it_242, 1ULL, 1);
    if (heff_intEq_c(v_it1_243, MK_INT(1LL))) {
      V v_x_245 = heff_dup(heff_rfield(v_me_240, 3));
      V v_e_246 = (g_heff_2ecompile_2efuse_2eselfOut(v_me_240, v_b_241));
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_e_246), NTAG(TAG_Nil)});
      V v_t_248 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_245), MK_INT(0LL), v_t_247));
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_246, NTAG(TAG_Nil)});
      V v_t_2410 = (g_heff_2ecompile_2eir_2elamW(v_x_245, v_t_249));
      V v_x_2411 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_248, v_t_2410}), 0, 2);
      if (heff_intLt_c(MK_INT(0LL), v_x_2411)) {
        heff_drop_cell(v_ru_24it_242_24Just, 1);
        return NTAG(TAG_Nothing);
      } else {
        return heff_tag_at_n(v_ru_24it_242_24Just, TAG_Just, 1, (V[]){NTAG(TAG_True)});
      }
    } else {
      heff_drop_rec(v_me_240, 4);
      heff_drop(v_b_241);
      heff_drop_cell(v_ru_24it_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2ecompile_2efuse_2earmKindR_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2earmKindR(a[0], a[1]);
}
Clo g_heff_2ecompile_2efuse_2earmKind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2earmKind_entry, 5, 0};

V g_heff_2ecompile_2efuse_2earmKind(V v_key_240, V v_n_241, V v_at_242, V v_l_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkArm: {
    V v_vs_246 = heff_field(v_x5_244, 1);
    V v_b_247 = heff_field(v_x5_244, 2);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_247), NTAG(TAG_Nil)});
    V v_t_249 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_l_243), MK_INT(0LL), v_t_248));
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_247), NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2ecompile_2eir_2elamW(v_l_243, v_t_2410));
    V v_x_2412 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_249, v_t_2411}), 0, 2);
    if (heff_intLt_c(MK_INT(0LL), v_x_2412)) {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      heff_drop(v_at_242);
      return NTAG(TAG_Nothing);
    } else {
      V v_t_2414 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_247)));
      V v_t_2415 = (g_heff_2ecompile_2eir_2enubI(v_t_2414));
      V v_x1_2416 = ({ V a_0 = heff_dup(v_key_240); V a_1 = v_t_2415; V r_ = (g_heff_2ecompile_2efuse_2eelemF(a_0, a_1)); heff_drop(v_t_2415); r_; });
      if ((heff_dup(v_x1_2416) == NTAG(TAG_True))) {
        heff_drop(v_x1_2416);
        V v_x3_2417 = (g_heff_2ecompile_2efuse_2elastF(v_vs_246));
        switch (heff_tag_of(v_x3_2417)) {
        case TAG_Nothing: {
          heff_drop(v_key_240);
          heff_drop(v_n_241);
          heff_drop(v_at_242);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x_2418 = heff_field(v_x3_2417, 0);
          heff_take_n(v_x3_2417, 1ULL, 1);
          return (g_heff_2ecompile_2efuse_2earmKindR(heff_rec_n(4, shape_key__arity__at__rest, (V[]){v_key_240, v_n_241, v_at_242, v_x_2418}), heff_dup(v_b_247)));
        }
        default: return heff_nomatch(v_x3_2417);
        }
      } else {
        heff_drop(v_key_240);
        heff_drop(v_n_241);
        heff_drop(v_at_242);
        heff_drop(v_x1_2416);
        return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2efuse_2earmKind_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2efuse_2earmKind(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
Clo g_heff_2ecompile_2efuse_2egoesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2egoesOf_entry, 1, 0};

V g_heff_2ecompile_2efuse_2egoesOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_field(v_x11_241, 0);
      V v_x112_244 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      switch (heff_tag_of(v_x112_244)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_243);
        V t_0 = v_rest_242;
        v_x1_240 = t_0;
        goto top;
      }
      case TAG_Just: {
        V v_x1121_245 = heff_field(v_x112_244, 0);
        heff_take_n(v_x112_244, 1ULL, 1);
        if ((heff_dup(v_x1121_245) == NTAG(TAG_True))) {
          heff_drop(v_x1121_245);
          V v_t_249;
          switch (heff_tag_of(v_a_243)) {
          case TAG_MkArm: {
            V v_t_246 = heff_field(v_a_243, 0);
            heff_take_n(v_a_243, 1ULL, 3);
            v_t_249 = v_t_246;
            break;
          }
          default: heff_nomatch(v_a_243);
          }
          V v_cell_2410 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
          V v_u_2411 = (g_heff_2ecompile_2efuse_2egoesOf_24dps(v_rest_242, heff_dup(v_cell_2410)));
          heff_drop(v_u_2411);
          return v_cell_2410;
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_a_243);
          heff_drop(v_x1121_245);
          V t_0 = v_rest_242;
          v_x1_240 = t_0;
          goto top;
        }
      }
      default: return heff_nomatch(v_x112_244);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2efuse_2egoesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2egoesOf(a[0]);
}
Clo g_heff_2ecompile_2efuse_2econsumerOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2econsumerOf_entry, 2, 0};

V g_heff_2ecompile_2efuse_2econsumerOf(V v_key_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    V v_ps_244 = heff_field(v_x2_241, 0);
    V v_x22_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_245)) {
    case TAG_EVar: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      V v_x221_2424 = heff_field(v_x22_245, 0);
      V v_arms_2425 = heff_field(v_x22_245, 1);
      switch (heff_tag_of(v_x221_2424)) {
      case TAG_EVar: {
        V v_l_2426 = heff_field(v_x221_2424, 0);
        V v_x5_2427 = (g_heff_2ecompile_2efuse_2eposF(heff_dup(v_l_2426), v_ps_244, MK_INT(0LL)));
        switch (heff_tag_of(v_x5_2427)) {
        case TAG_Nothing: {
          heff_drop(v_key_240);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_at_2428 = heff_field(v_x5_2427, 0);
          heff_take_n(v_x5_2427, 1ULL, 1);
          V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ps_244));
          V v_t_2430 = (g_list_2emap_24s866308031x234213482(heff_dup(v_key_240), v_t_2429, heff_dup(v_at_2428), heff_dup(v_l_2426), heff_dup(v_arms_2425)));
          return (g_heff_2ecompile_2efuse_2econsumerWith(v_key_240, heff_dup(v_ps_244), v_at_2428, heff_dup(v_arms_2425), v_t_2430));
        }
        default: return heff_nomatch(v_x5_2427);
        }
      }
      case TAG_EGlobal: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_ELam: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_EApp: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_ELet: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_ERecord: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_EProj: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_ETag: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_EMatch: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrim: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_EPrimCall: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_ECall: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_EInt: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_EStr: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_EBytes: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFixed: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFloat32: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_EAbandon: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_EFix: {
        heff_drop(v_key_240);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x221_2424);
      }
    }
    case TAG_EPrim: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_drop(v_key_240);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x22_245);
    }
  }
  case TAG_EApp: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EBytes: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2econsumerOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2econsumerOf(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2efuse_2eproducerOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eproducerOf_entry, 2, 0};

V g_heff_2ecompile_2efuse_2eproducerOf(V v_key_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    V v_qs_244 = heff_field(v_x2_241, 0);
    V v_b_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_qs_244));
    V v_t_247 = (g_heff_2ecompile_2efuse_2etailsOf(heff_dup(v_b_245)));
    V v_t_248 = ({ V a_0 = v_key_240; V a_1 = v_t_246; V a_2 = v_t_247; V r_ = (g_list_2eany_24s78130935x581779089(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_xs_249 = (g_heff_2ecompile_2efuse_2etailsOf(heff_dup(v_b_245)));
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
      V v_t_2411 = (g_list_2efoldl_24s2002556150x421739076(NTAG(TAG_Nil), v_t_2410));
      return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_params__body__tags, (V[]){heff_dup(v_qs_244), heff_dup(v_b_245), v_t_2411})});
    } else {
      heff_drop(v_t_248);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_EApp: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EBytes: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_drop(v_key_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2eproducerOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2eproducerOf(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2efuse_2etraverseF_lam0(V self, V *args); static Clo g_heff_2ecompile_2efuse_2etraverseF_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2etraverseF_lam0, 1, 0};
V g_heff_2ecompile_2efuse_2etraverseF_lam1(V self, V *args);
Clo g_heff_2ecompile_2efuse_2etraverseF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2etraverseF_entry, 2, 0};

V g_heff_2ecompile_2efuse_2etraverseF(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2efuse_2etraverseF_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_heff_2ecompile_2efuse_2etraverseF_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2etraverseF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2etraverseF(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2etraverseF_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_heff_2ecompile_2efuse_2etraverseF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2efuse_2etraverseF(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2efuse_2ekidsF_lam0(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam1(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam2(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam3(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam4(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam5(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam6(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam7(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam8(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam9(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam10(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam11(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam12(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam13(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam14(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam15(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam16(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam17(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam18(V self, V *args);
V g_heff_2ecompile_2efuse_2ekidsF_lam19(V self, V *args);
Clo g_heff_2ecompile_2efuse_2ekidsF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2ekidsF_entry, 2, 0};

V g_heff_2ecompile_2efuse_2ekidsF(V v_f_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam0, 1, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam1, 1, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(v_f_240, 1, (V[]){v_b_247}));
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_g_2413 = heff_field(v_e_241, 0);
    V v_as_2414 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2415 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_g_2413}));
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam3, 1, 3, (V[]){v_m_2415, v_f_240, v_as_2414});
  }
  case TAG_ELet: {
    V v_x_2424 = heff_field(v_e_241, 0);
    V v_a_2425 = heff_field(v_e_241, 1);
    V v_b_2426 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2427 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_a_2425}));
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam4, 1, 4, (V[]){v_m_2427, v_f_240, v_b_2426, v_x_2424});
  }
  case TAG_ERecord: {
    V v_fs_2436 = heff_field(v_e_241, 0);
    V v_ts_2437 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2438 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2436)));
    V v_m_2439 = (g_heff_2ecompile_2efuse_2etraverseF(v_f_240, v_t_2438));
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam5, 1, 3, (V[]){v_m_2439, v_fs_2436, v_ts_2437});
  }
  case TAG_EProj: {
    V v_e1_2446 = heff_field(v_e_241, 0);
    V v_l_2447 = heff_field(v_e_241, 1);
    V v_sh_2448 = heff_field(v_e_241, 2);
    V v_t_2449 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 15ULL, 4);
    V v_m_2450 = heff_tr(heff_call(v_f_240, 1, (V[]){v_e1_2446}));
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam6, 1, 4, (V[]){v_m_2450, v_l_2447, v_sh_2448, v_t_2449});
  }
  case TAG_ETag: {
    V v_t_2455 = heff_field(v_e_241, 0);
    V v_as_2456 = heff_field(v_e_241, 1);
    V v_ts_2457 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2458 = (g_heff_2ecompile_2efuse_2etraverseF(v_f_240, v_as_2456));
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam7, 1, 3, (V[]){v_m_2458, v_t_2455, v_ts_2457});
  }
  case TAG_EMatch: {
    V v_s_2463 = heff_field(v_e_241, 0);
    V v_arms_2464 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2465 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_s_2463}));
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam8, 1, 3, (V[]){v_m_2465, v_arms_2464, v_f_240});
  }
  case TAG_EPrim: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam9, 1, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    V v_p_2479 = heff_field(v_e_241, 0);
    V v_as_2480 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2481 = (g_heff_2ecompile_2efuse_2etraverseF(v_f_240, v_as_2480));
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam10, 1, 2, (V[]){v_m_2481, v_p_2479});
  }
  case TAG_ECall: {
    V v_g_2486 = heff_field(v_e_241, 0);
    V v_as_2487 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2488 = (g_heff_2ecompile_2efuse_2etraverseF(v_f_240, v_as_2487));
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam11, 1, 2, (V[]){v_m_2488, v_g_2486});
  }
  case TAG_EInt: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam12, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam13, 1, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam14, 1, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam15, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam16, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam17, 1, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_f_240);
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam18, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    V v_x_24107 = heff_field(v_e_241, 0);
    V v_b_24108 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24109 = heff_tr(heff_call(v_f_240, 1, (V[]){v_b_24108}));
    return heff_clo_n(g_heff_2ecompile_2efuse_2ekidsF_lam19, 1, 2, (V[]){v_m_24109, v_x_24107});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2efuse_2ekidsF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2ekidsF(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2ekidsF_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_243});
}
V g_heff_2ecompile_2efuse_2ekidsF_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_245});
}
V g_heff_2ecompile_2efuse_2ekidsF_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_s_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_x_2411}), v_s_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2efuse_2ekidsF_lam3(V self, V *args) {
  V v_s_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_as_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_m_2420 = (g_heff_2ecompile_2efuse_2etraverseF(v_f_240, v_as_2414));
    V v_x2_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_s_2419}));
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_s_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2418, v_x_2422}), v_s_2423});
    }
    default: return heff_nomatch(v_x2_2421);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2efuse_2ekidsF_lam4(V self, V *args) {
  V v_s_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2426 = heff_env(self)[2];
  V v_x_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_s_2428}));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_MkPair: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_s_2431 = heff_field(v_x2_2429, 1);
    V v_ru_24x2_2429_24MkPair = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
    V v_m_2432 = heff_tr(heff_call(v_f_240, 1, (V[]){v_b_2426}));
    V v_x2_2433 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_s_2431}));
    switch (heff_tag_of(v_x2_2433)) {
    case TAG_MkPair: {
      V v_x_2434 = heff_field(v_x2_2433, 0);
      V v_s_2435 = heff_field(v_x2_2433, 1);
      heff_take_n(v_x2_2433, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2424, v_x_2430, v_x_2434}), v_s_2435});
    }
    default: return heff_nomatch(v_x2_2433);
    }
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2ecompile_2efuse_2ekidsF_lam5(V self, V *args) {
  V v_s_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_fs_2436 = heff_env(self)[1];
  V v_ts_2437 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_s_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_s_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    V v_t_2444 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2436, v_x_2442));
    V v_x_2445 = heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2444, v_ts_2437});
    return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){v_x_2445, v_s_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2efuse_2ekidsF_lam6(V self, V *args) {
  V v_s_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  V v_l_2447 = heff_env(self)[1];
  V v_sh_2448 = heff_env(self)[2];
  V v_t_2449 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_s_2451}));
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_MkPair: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_s_2454 = heff_field(v_x2_2452, 1);
    V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2453, v_l_2447, v_sh_2448, v_t_2449}), v_s_2454});
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_heff_2ecompile_2efuse_2ekidsF_lam7(V self, V *args) {
  V v_s_2459 = args[0];
  V v_m_2458 = heff_env(self)[0];
  V v_t_2455 = heff_env(self)[1];
  V v_ts_2457 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2460 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_s_2459}));
  switch (heff_tag_of(v_x2_2460)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_field(v_x2_2460, 0);
    V v_s_2462 = heff_field(v_x2_2460, 1);
    V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2455, v_x_2461, v_ts_2457}), v_s_2462});
  }
  default: return heff_nomatch(v_x2_2460);
  }
}
V g_heff_2ecompile_2efuse_2ekidsF_lam8(V self, V *args) {
  V v_s_2466 = args[0];
  V v_m_2465 = heff_env(self)[0];
  V v_arms_2464 = heff_env(self)[1];
  V v_f_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2467 = heff_tr(heff_call(v_m_2465, 1, (V[]){v_s_2466}));
  switch (heff_tag_of(v_x2_2467)) {
  case TAG_MkPair: {
    V v_x_2468 = heff_field(v_x2_2467, 0);
    V v_s_2469 = heff_field(v_x2_2467, 1);
    V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
    V v_t_2470 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2464)));
    V v_m_2471 = (g_heff_2ecompile_2efuse_2etraverseF(v_f_240, v_t_2470));
    V v_x2_2472 = heff_tr(heff_call(v_m_2471, 1, (V[]){v_s_2469}));
    switch (heff_tag_of(v_x2_2472)) {
    case TAG_MkPair: {
      V v_x_2473 = heff_field(v_x2_2472, 0);
      V v_s_2474 = heff_field(v_x2_2472, 1);
      V v_ru_24x2_2472_24MkPair = heff_take_reuse_n(v_x2_2472, 3ULL, 2);
      V v_t_2475 = (g_list_2ezipWith_24s738847920x410598254(v_arms_2464, v_x_2473));
      V v_x_2476 = heff_tag_at_n(v_ru_24x2_2472_24MkPair, TAG_EMatch, 2, (V[]){v_x_2468, v_t_2475});
      return heff_tag_at_n(v_ru_24x2_2467_24MkPair, TAG_MkPair, 2, (V[]){v_x_2476, v_s_2474});
    }
    default: return heff_nomatch(v_x2_2472);
    }
  }
  default: return heff_nomatch(v_x2_2467);
  }
}
V g_heff_2ecompile_2efuse_2ekidsF_lam9(V self, V *args) {
  V v_s_2478 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_2478});
}
V g_heff_2ecompile_2efuse_2ekidsF_lam10(V self, V *args) {
  V v_s_2482 = args[0];
  V v_m_2481 = heff_env(self)[0];
  V v_p_2479 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2483 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_s_2482}));
  switch (heff_tag_of(v_x2_2483)) {
  case TAG_MkPair: {
    V v_x_2484 = heff_field(v_x2_2483, 0);
    V v_s_2485 = heff_field(v_x2_2483, 1);
    V v_ru_24x2_2483_24MkPair = heff_take_reuse_n(v_x2_2483, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2483_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2479, v_x_2484}), v_s_2485});
  }
  default: return heff_nomatch(v_x2_2483);
  }
}
V g_heff_2ecompile_2efuse_2ekidsF_lam11(V self, V *args) {
  V v_s_2489 = args[0];
  V v_m_2488 = heff_env(self)[0];
  V v_g_2486 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2490 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_s_2489}));
  switch (heff_tag_of(v_x2_2490)) {
  case TAG_MkPair: {
    V v_x_2491 = heff_field(v_x2_2490, 0);
    V v_s_2492 = heff_field(v_x2_2490, 1);
    V v_ru_24x2_2490_24MkPair = heff_take_reuse_n(v_x2_2490, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2486, v_x_2491}), v_s_2492});
  }
  default: return heff_nomatch(v_x2_2490);
  }
}
V g_heff_2ecompile_2efuse_2ekidsF_lam12(V self, V *args) {
  V v_s_2494 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_2494});
}
V g_heff_2ecompile_2efuse_2ekidsF_lam13(V self, V *args) {
  V v_s_2496 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_2496});
}
V g_heff_2ecompile_2efuse_2ekidsF_lam14(V self, V *args) {
  V v_s_2498 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_2498});
}
V g_heff_2ecompile_2efuse_2ekidsF_lam15(V self, V *args) {
  V v_s_24100 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24100});
}
V g_heff_2ecompile_2efuse_2ekidsF_lam16(V self, V *args) {
  V v_s_24103 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24103});
}
V g_heff_2ecompile_2efuse_2ekidsF_lam17(V self, V *args) {
  V v_s_24105 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24105});
}
V g_heff_2ecompile_2efuse_2ekidsF_lam18(V self, V *args) {
  V v_s_24106 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24106});
}
V g_heff_2ecompile_2efuse_2ekidsF_lam19(V self, V *args) {
  V v_s_24110 = args[0];
  V v_m_24109 = heff_env(self)[0];
  V v_x_24107 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24111 = heff_tr(heff_call(v_m_24109, 1, (V[]){v_s_24110}));
  switch (heff_tag_of(v_x2_24111)) {
  case TAG_MkPair: {
    V v_x_24112 = heff_field(v_x2_24111, 0);
    V v_s_24113 = heff_field(v_x2_24111, 1);
    V v_ru_24x2_24111_24MkPair = heff_take_reuse_n(v_x2_24111, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24111_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24107, v_x_24112}), v_s_24113});
  }
  default: return heff_nomatch(v_x2_24111);
  }
}
Clo g_heff_2ecompile_2efuse_2etraverseF_24s847914641x1886275130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2etraverseF_24s847914641x1886275130_entry, 2, 0};

V g_heff_2ecompile_2efuse_2etraverseF_24s847914641x1886275130(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_map_2eempty_get()), heff_take_field(v_p_241, 0), v_x_242));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_e_245 = heff_field(v_x2_244, 0);
      V v_n_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      V v_t_247 = ({ V rv_0 = v_n_246; V rr_ = heff_rec_reuse_nf(v_p_241, 62ULL, 6, shape_supply__consumers__producers__made__fresh__left, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_x2_248 = (g_heff_2ecompile_2efuse_2etraverseF_24s847914641x1886275130(v_xs_243, v_t_247));
      switch (heff_tag_of(v_x2_248)) {
      case TAG_MkPair: {
        V v_x_249 = heff_field(v_x2_248, 0);
        V v_s_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_e_245, v_x_249}), v_s_2410});
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2efuse_2etraverseF_24s847914641x1886275130_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2etraverseF_24s847914641x1886275130(a[0], a[1]);
}
Clo g_heff_2ecompile_2efuse_2efindArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efindArm_entry, 2, 0};

V g_heff_2ecompile_2efuse_2efindArm(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x2_241, 0);
    V v_as_243 = heff_field(v_x2_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_a_242)) {
    case TAG_MkArm: {
      V v_t_244 = heff_field(v_a_242, 0);
      v_t_247 = heff_dup(v_t_244);
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    if (heff_strEq_c_lent(v_t_247, v_t_240, 1)) {
      heff_drop(v_t_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_a_242)});
    } else {
      V t_0 = v_t_240;
      V t_1 = v_as_243;
      v_t_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2efuse_2efindArm_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2efuse_2efindArm(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2efuse_2earmWorks_str0, 0, "");
Clo g_heff_2ecompile_2efuse_2earmWorks_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2earmWorks_entry, 5, 0};

V g_heff_2ecompile_2efuse_2earmWorks(V v_sg_240, V v_c_241, V v_cs_242, V v_m_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkArm: {
    V v_t_245 = heff_field(v_x5_244, 0);
    V v_vs_246 = heff_field(v_x5_244, 1);
    V v_b_247 = heff_field(v_x5_244, 2);
    V v_x1_248 = (g_heff_2ecompile_2efuse_2eelemF(heff_dup(v_t_245), heff_rfield(v_cs_242, 3)));
    if ((heff_dup(v_x1_248) == NTAG(TAG_True))) {
      heff_drop(v_x1_248);
      V v_x2_249 = (g_heff_2ecompile_2efuse_2elastF(v_vs_246));
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_cs_242, 0)));
      V v_t_2412;
      switch (heff_tag_of(v_x2_249)) {
      case TAG_Nothing: {
        v_t_2412 = ((V)&g_heff_2ecompile_2efuse_2earmWorks_str0);
        break;
      }
      case TAG_Just: {
        V v_x_2411 = heff_field(v_x2_249, 0);
        heff_take_n(v_x2_249, 1ULL, 1);
        v_t_2412 = v_x_2411;
        break;
      }
      default: heff_nomatch(v_x2_249);
      }
      V v_t_2413 = heff_rec_n(4, shape_key__arity__at__rest, (V[]){v_c_241, v_t_2410, heff_get_n(v_cs_242, 1, 5), v_t_2412});
      V v_e_2414 = (g_heff_2ecompile_2efuse_2eselfOut(v_t_2413, heff_dup(v_b_247)));
      V v_t_2415 = (g_map_2esize(v_m_243));
      V v_t_2417;
      if (heff_intEq_c(v_t_2415, MK_INT(0LL))) {
        v_t_2417 = v_e_2414;
      } else {
        v_t_2417 = (g_heff_2ecompile_2eir_2esubstGo(v_m_243, v_e_2414));
      }
      return (g_heff_2ecompile_2efuse_2eworkPure(v_sg_240, v_t_2417));
    } else {
      heff_drop(v_sg_240);
      heff_drop(v_c_241);
      heff_drop_rec(v_cs_242, 5);
      heff_drop(v_x1_248);
      return NTAG(TAG_True);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2efuse_2earmWorks_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2efuse_2earmWorks(a[0], a[1], a[2], a3, a4); heff_drop(a3); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ecompile_2efuse_2efuseNew_str0, 1, " ");
HEFF_LIT(g_heff_2ecompile_2efuse_2efuseNew_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2efuse_2efuseNew_str2, 0, "");
Clo g_heff_2ecompile_2efuse_2efuseNew_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efuseNew_entry, 8, 0};

V g_heff_2ecompile_2efuse_2efuseNew(V v_c_240, V v_cs_241, V v_p_242, V v_ps_243, V v_as_244, V v_bs_245, V v_left_246, V v_z_247) {
top: ;
  if (heff_intLe_c(v_left_246, MK_INT(0LL))) {
    heff_drop(v_c_240);
    heff_drop_rec(v_cs_241, 5);
    heff_drop(v_p_242);
    heff_drop(v_ps_243);
    heff_drop(v_as_244);
    heff_drop(v_bs_245);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_247});
  } else {
    V v_m_249 = (g_heff_2ecompile_2efuse_2emakeFused(heff_dup(v_c_240), heff_dup(v_cs_241), heff_dup(v_p_242), v_ps_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_z_247}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      V v_t_2413 = heff_strAppend(v_c_240, heff_strAppend(((V)&g_heff_2ecompile_2efuse_2efuseNew_str0), v_p_242));
      V v_t_2415;
      switch (heff_tag_of(v_x_2411)) {
      case TAG_Nothing: {
        v_t_2415 = ((V)&g_heff_2ecompile_2efuse_2efuseNew_str1);
        break;
      }
      case TAG_Just: {
        V v_x_2414 = heff_dup(heff_field(v_x_2411, 0));
        v_t_2415 = heff_get_n(v_x_2414, 0, 3);
        break;
      }
      default: heff_nomatch(v_x_2411);
      }
      V v_t_2416 = (g_heff_2ecompile_2efuse_2ewithMade(v_t_2413, v_t_2415, v_x_2411, v_s_2412));
      V v_x2_2417 = heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2416});
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_MkPair: {
        V v_s_2419 = heff_field(v_x2_2417, 1);
        V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 2ULL, 2);
        V v_x_2425;
        switch (heff_tag_of(v_x_2411)) {
        case TAG_Nothing: {
          heff_drop_rec(v_cs_241, 5);
          heff_drop(v_as_244);
          heff_drop(v_bs_245);
          v_x_2425 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x_2420 = heff_field(v_x_2411, 0);
          V v_ru_24x_2411_24Just = heff_take_reuse_n(v_x_2411, 1ULL, 1);
          V v_k_2421 = heff_get_n(v_x_2420, 0, 3);
          if (heff_strEq_c_lent(v_k_2421, ((V)&g_heff_2ecompile_2efuse_2efuseNew_str2), 2)) {
            heff_drop_rec(v_cs_241, 5);
            heff_drop(v_as_244);
            heff_drop(v_bs_245);
            heff_drop_cell(v_ru_24x_2411_24Just, 1);
            heff_drop(v_k_2421);
            v_x_2425 = NTAG(TAG_Nothing);
          } else {
            V v_t_2423 = (g_prelude_2e_2b_2b_24f677743828x1026746250(v_bs_245, heff_get_n(v_cs_241, 1, 5), v_as_244));
            V v_t_2424 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_k_2421}), v_t_2423});
            v_x_2425 = heff_tag_at_n(v_ru_24x_2411_24Just, TAG_Just, 1, (V[]){v_t_2424});
          }
          break;
        }
        default: heff_nomatch(v_x_2411);
        }
        return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_x_2425, v_s_2419});
      }
      default: return heff_nomatch(v_x2_2417);
      }
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
}
V g_heff_2ecompile_2efuse_2efuseNew_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2efuseNew(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ecompile_2efuse_2eplugArgs_lam0(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugArgs_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugArgs_lam0, 1, 0};
V g_heff_2ecompile_2efuse_2eplugArgs_lam1(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugArgs_lam2(V self, V *args);
V g_heff_2ecompile_2efuse_2eplugArgs_lam3(V self, V *args); static Clo g_heff_2ecompile_2efuse_2eplugArgs_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugArgs_lam3, 1, 0};
Clo g_heff_2ecompile_2efuse_2eplugArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugArgs_entry, 4, 0};

V g_heff_2ecompile_2efuse_2eplugArgs(V v_sg_240, V v_k_241, V v_pl_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sg_240);
    heff_drop_rec(v_k_241, 1);
    heff_drop_rec(v_pl_242, 3);
    return ((V)&g_heff_2ecompile_2efuse_2eplugArgs_lam0_clo);
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_x_247 = heff_dup(heff_rfield(v_pl_242, 0));
    V v_t_248 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_a_245), NTAG(TAG_Nil)});
    V v_t_249 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_247), MK_INT(0LL), v_t_248));
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_245), NTAG(TAG_Nil)});
    V v_t_2411 = (g_heff_2ecompile_2eir_2elamW(v_x_247, v_t_2410));
    V v_x_2412 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_249, v_t_2411}), 0, 2);
    if (heff_intLt_c(MK_INT(0LL), v_x_2412)) {
      heff_drop(v_sg_240);
      V v_m_2414 = heff_tr(heff_call(heff_get_n(v_k_241, 0, 1), 2, (V[]){v_pl_242, v_a_245}));
      return heff_clo_n(g_heff_2ecompile_2efuse_2eplugArgs_lam1, 1, 2, (V[]){v_m_2414, v_rest_246});
    } else {
      V v_t_2421 = (g_heff_2ecompile_2efuse_2eworkPure(heff_dup(v_sg_240), heff_dup(v_a_245)));
      if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
        heff_drop(v_t_2421);
        V v_m_2422 = (g_heff_2ecompile_2efuse_2eplugArgs(v_sg_240, v_k_241, v_pl_242, v_rest_246));
        return heff_clo_n(g_heff_2ecompile_2efuse_2eplugArgs_lam2, 1, 2, (V[]){v_m_2422, v_a_245});
      } else {
        heff_drop(v_sg_240);
        heff_drop_rec(v_k_241, 1);
        heff_drop_rec(v_pl_242, 3);
        heff_drop(v_a_245);
        heff_drop(v_rest_246);
        heff_drop(v_t_2421);
        return ((V)&g_heff_2ecompile_2efuse_2eplugArgs_lam3_clo);
      }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2efuse_2eplugArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eplugArgs(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2efuse_2eplugArgs_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_244});
}
V g_heff_2ecompile_2efuse_2eplugArgs_lam1(V self, V *args) {
  V v_s_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_s_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_s_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    V v_t_2420;
    switch (heff_tag_of(v_x_2417)) {
    case TAG_Nothing: {
      heff_drop(v_rest_246);
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2419 = heff_field(v_x_2417, 0);
      V v_ru_24x_2417_24Just = heff_take_reuse_n(v_x_2417, 1ULL, 1);
      v_t_2420 = heff_tag_at_n(v_ru_24x_2417_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2419, v_rest_246})});
      break;
    }
    default: heff_nomatch(v_x_2417);
    }
    return heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){v_t_2420, v_s_2418});
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2efuse_2eplugArgs_lam2(V self, V *args) {
  V v_s_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  V v_a_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_s_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_s_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    V v_t_2428;
    switch (heff_tag_of(v_x_2425)) {
    case TAG_Nothing: {
      heff_drop(v_a_245);
      v_t_2428 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_as_2427 = heff_field(v_x_2425, 0);
      V v_ru_24x_2425_24Just = heff_take_reuse_n(v_x_2425, 1ULL, 1);
      v_t_2428 = heff_tag_at_n(v_ru_24x_2425_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_a_245, v_as_2427})});
      break;
    }
    default: heff_nomatch(v_x_2425);
    }
    return heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){v_t_2428, v_s_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2efuse_2eplugArgs_lam3(V self, V *args) {
  V v_s_2429 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_2429});
}
V g_heff_2ecompile_2efuse_2eplugK_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuse_2eplugK_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2eplugK_entry, 1, 0};

V g_heff_2ecompile_2efuse_2eplugK(V v_sg_240) {
top: ;
  return heff_rec_n(1, shape_go, (V[]){heff_clo_n(g_heff_2ecompile_2efuse_2eplugK_lam0, 2, 1, (V[]){v_sg_240})});
}
V g_heff_2ecompile_2efuse_2eplugK_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2eplugK(a[0]);
}
V g_heff_2ecompile_2efuse_2eplugK_lam0(V self, V *args) {
  V v_pl_241 = args[0];
  V v_e_242 = args[1];
  V v_sg_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2ecompile_2efuse_2eplugK(heff_dup(v_sg_240)));
  return (g_heff_2ecompile_2efuse_2eplugGo(v_sg_240, v_t_243, v_pl_241, v_e_242));
}
V g_heff_2ecompile_2efuse_2efuseProgram_lam1(V self, V *args);
V g_heff_2ecompile_2efuse_2efuseProgram_lam0(V self, V *args);
Clo g_heff_2ecompile_2efuse_2efuseProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2efuse_2efuseProgram_entry, 2, 0};

V g_heff_2ecompile_2efuse_2efuseProgram(V v_supply_240, V v_defs_241) {
top: ;
  V v_sg_242 = (g_list_2efoldl_24s890299851x180637966(heff_rec_n(2, shape_safe__total, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())}), v_defs_241));
  V v_t_2410 = (g_heff_2ecompile_2efuse_2etraverseF(heff_clo_n(g_heff_2ecompile_2efuse_2efuseProgram_lam0, 1, 1, (V[]){v_sg_242}), heff_dup(v_defs_241)));
  V v_t_2411 = (g_list_2efoldl_24s1200572259x609044042(heff_dup(g_map_2eempty_get()), v_defs_241));
  V v_t_2412 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_defs_241; V r_ = (g_list_2efoldl_24s316188476x878636287(a_0, a_1)); heff_drop(v_defs_241); r_; });
  V v_t_2413 = heff_rec_n(6, shape_supply__consumers__producers__made__fresh__left, (V[]){v_supply_240, v_t_2411, v_t_2412, heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), MK_INT(2000LL)});
  V v_x2_2414 = heff_tr(heff_call(v_t_2410, 1, (V[]){v_t_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_ds_2415 = heff_field(v_x2_2414, 0);
    V v_s_2416 = heff_field(v_x2_2414, 1);
    heff_take_n(v_x2_2414, 3ULL, 2);
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_s_2416, 4)));
    V v_t_2418 = (g_prelude_2e_2b_2b(v_ds_2415, v_t_2417));
    return heff_rec_n(2, shape_defs__supply, (V[]){v_t_2418, heff_get_n(v_s_2416, 0, 6)});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2efuse_2efuseProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2efuse_2efuseProgram(a[0], a[1]);
}
V g_heff_2ecompile_2efuse_2efuseProgram_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = ({ V rv_2 = v_x_247; V rr_ = heff_rec_reuse_nf(v_d_243, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_249, v_s_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2efuse_2efuseProgram_lam0(V self, V *args) {
  V v_d_243 = args[0];
  V v_sg_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_244 = (g_heff_2ecompile_2efuse_2esites(v_sg_242, heff_dup(heff_rfield(v_d_243, 2))));
  return heff_clo_n(g_heff_2ecompile_2efuse_2efuseProgram_lam1, 1, 2, (V[]){v_m_244, v_d_243});
}