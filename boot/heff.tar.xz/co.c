// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_co_2eplus_24s16_lam1(V self, V *args);
V g_co_2eplus_24s16_lam2(V self, V *args);
V g_co_2eplus_24s16_lam0(V self, V *args); static Clo g_co_2eplus_24s16_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s16_lam0, 3, 0};
V g_co_2eplus_24s16_lam4(V self, V *args);
V g_co_2eplus_24s16_lam3(V self, V *args); static Clo g_co_2eplus_24s16_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s16_lam3, 2, 0};

static V g_co_2eplus_24s16_val;
static int g_co_2eplus_24s16_st;
static V g_co_2eplus_24s16_init(void) {
  return heff_rec(2, shape_119_121, (V[]){((V)&g_co_2eplus_24s16_lam0_clo), ((V)&g_co_2eplus_24s16_lam3_clo)});
}
V g_co_2eplus_24s16_get(void) {
  if (g_co_2eplus_24s16_st == 2) return g_co_2eplus_24s16_val;
  if (g_co_2eplus_24s16_st == 1) heff_fail("defined by itself");
  g_co_2eplus_24s16_st = 1;
  g_co_2eplus_24s16_val = heff_tr(g_co_2eplus_24s16_init());
  g_co_2eplus_24s16_st = 2;
  return g_co_2eplus_24s16_val;
}
V g_co_2eplus_24s16_lam1(V self, V *args) {
  V v_st_245 = args[0];
  V v_k_244 = heff_dup(heff_env(self)[0]);
  V v_g_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_246 = heff_tr(heff_apply(v_k_244, 1, (V[]){v_st_245}));
  return heff_tail(v_g_241, 1, (V[]){v_t_246});
}
V g_co_2eplus_24s16_lam2(V self, V *args) {
  V v_s_2416 = args[0];
  V v_h_2414 = heff_dup(heff_env(self)[0]);
  V v_fm_240 = heff_dup(heff_env(self)[1]);
  V v_g_241 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  V v_t_2417 = heff_tr(heff_apply(v_h_2414, 1, (V[]){v_s_2416}));
  return heff_tail(v_fm_240, 2, (V[]){v_g_241, v_t_2417});
}
V g_co_2eplus_24s16_lam0(V self, V *args) {
  V v_fm_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(self);
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse(v_p_242, 1ULL);
    heff_drop(v_fm_240);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Get: {
      V v_k_244 = heff_field(v_x_243, 0);
      heff_take(v_x_243, 1ULL);
      v_t_2410 = heff_tag_at(v_ru_24p_242_24InL, TAG_Get, 1, (V[]){heff_clo(g_co_2eplus_24s16_lam1, 1, 2, (V[]){v_k_244, v_g_241})});
      break;
    }
    case TAG_Put: {
      V v_st_247 = heff_field(v_x_243, 0);
      V v_x_248 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Put = heff_take_reuse(v_x_243, 3ULL);
      heff_drop(v_ru_24p_242_24InL);
      V v_t_249 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_248}));
      v_t_2410 = heff_tag_at(v_ru_24x_243_24Put, TAG_Put, 2, (V[]){v_st_247, v_t_249});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag(TAG_InL, 1, (V[]){v_t_2410});
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse(v_p_242, 1ULL);
    V v_t_2418;
    switch (heff_tag_of(v_y_2411)) {
    case TAG_Throw: {
      V v_s_2412 = heff_field(v_y_2411, 0);
      heff_take(v_y_2411, 1ULL);
      heff_drop(v_fm_240);
      heff_drop(v_g_241);
      v_t_2418 = heff_tag_at(v_ru_24p_242_24InR, TAG_Throw, 1, (V[]){v_s_2412});
      break;
    }
    case TAG_Catch: {
      V v_c_2413 = heff_field(v_y_2411, 0);
      V v_h_2414 = heff_field(v_y_2411, 1);
      V v_ru_24y_2411_24Catch = heff_take_reuse(v_y_2411, 3ULL);
      heff_drop(v_ru_24p_242_24InR);
      V v_t_2415 = heff_tr(heff_apply(heff_dup(v_fm_240), 2, (V[]){heff_dup(v_g_241), v_c_2413}));
      v_t_2418 = heff_tag_at(v_ru_24y_2411_24Catch, TAG_Catch, 2, (V[]){v_t_2415, heff_clo(g_co_2eplus_24s16_lam2, 1, 3, (V[]){v_h_2414, v_fm_240, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_2411);
    }
    return heff_tag(TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s16_lam4(V self, V *args) {
  V v_s_2431 = args[0];
  V v_h_2429 = heff_dup(heff_env(self)[0]);
  V v_nt_2419 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2432 = heff_tr(heff_apply(v_h_2429, 1, (V[]){v_s_2431}));
  return heff_tail(v_nt_2419, 1, (V[]){v_t_2432});
}
V g_co_2eplus_24s16_lam3(V self, V *args) {
  V v_nt_2419 = args[0];
  V v_p_2420 = args[1];
  heff_drop(self);
  switch (heff_tag_of(v_p_2420)) {
  case TAG_InL: {
    V v_x_2421 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InL = heff_take_reuse(v_p_2420, 1ULL);
    heff_drop(v_nt_2419);
    V v_t_2425;
    switch (heff_tag_of(v_x_2421)) {
    case TAG_Get: {
      V v_k_2422 = heff_field(v_x_2421, 0);
      heff_take(v_x_2421, 1ULL);
      v_t_2425 = heff_tag_at(v_ru_24p_2420_24InL, TAG_Get, 1, (V[]){v_k_2422});
      break;
    }
    case TAG_Put: {
      V v_st_2423 = heff_field(v_x_2421, 0);
      V v_x_2424 = heff_field(v_x_2421, 1);
      V v_ru_24x_2421_24Put = heff_take_reuse(v_x_2421, 3ULL);
      heff_drop(v_ru_24p_2420_24InL);
      v_t_2425 = heff_tag_at(v_ru_24x_2421_24Put, TAG_Put, 2, (V[]){v_st_2423, v_x_2424});
      break;
    }
    default: heff_nomatch(v_x_2421);
    }
    return heff_tag(TAG_InL, 1, (V[]){v_t_2425});
  }
  case TAG_InR: {
    V v_y_2426 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InR = heff_take_reuse(v_p_2420, 1ULL);
    V v_t_2433;
    switch (heff_tag_of(v_y_2426)) {
    case TAG_Throw: {
      V v_s_2427 = heff_field(v_y_2426, 0);
      heff_take(v_y_2426, 1ULL);
      heff_drop(v_nt_2419);
      v_t_2433 = heff_tag_at(v_ru_24p_2420_24InR, TAG_Throw, 1, (V[]){v_s_2427});
      break;
    }
    case TAG_Catch: {
      V v_c_2428 = heff_field(v_y_2426, 0);
      V v_h_2429 = heff_field(v_y_2426, 1);
      V v_ru_24y_2426_24Catch = heff_take_reuse(v_y_2426, 3ULL);
      heff_drop(v_ru_24p_2420_24InR);
      V v_t_2430 = heff_tr(heff_apply(heff_dup(v_nt_2419), 1, (V[]){v_c_2428}));
      v_t_2433 = heff_tag_at(v_ru_24y_2426_24Catch, TAG_Catch, 2, (V[]){v_t_2430, heff_clo(g_co_2eplus_24s16_lam4, 1, 2, (V[]){v_h_2429, v_nt_2419})});
      break;
    }
    default: heff_nomatch(v_y_2426);
    }
    return heff_tag(TAG_InR, 1, (V[]){v_t_2433});
  }
  default: return heff_nomatch(v_p_2420);
  }
}
V g_co_2ebind_24s484_lam0(V self, V *args); static Clo g_co_2ebind_24s484_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s484_lam0, 1, 0};
V g_co_2ebind_24s484_lam1(V self, V *args);
Clo g_co_2ebind_24s484_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s484_entry, 3, 0};

V g_co_2ebind_24s484(V v_f_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_co_2ebind_24s484_lam0_clo)})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_co_2ebind_24s484_lam1, 1, 3, (V[]){v_f_240, v_hd_241, v_k_242})});
}
V g_co_2ebind_24s484_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s484(a[0], a[1], a[2]);
}
V g_co_2ebind_24s484_lam0(V self, V *args) {
  V v_c_243 = args[0];
  heff_drop(self);
  V v_t_244 = ({ V b_0 = heff_get(v_c_243, LBL_metas); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = (g_prelude_2emap_24s6(v_t_244));
  V v_xs_246 = (g_prelude_2efoldl_24s439(NTAG(TAG_Nil), v_t_245));
  return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_246));
}
V g_co_2ebind_24s484_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_240 = heff_dup(heff_env(self)[0]);
  V v_hd_241 = heff_dup(heff_env(self)[1]);
  V v_k_242 = heff_dup(heff_env(self)[2]);
  heff_drop(self);
  return heff_tail(v_f_240, 3, (V[]){v_x_2410, v_hd_241, v_k_242});
}
V g_co_2eplus_24s854_lam1(V self, V *args);
V g_co_2eplus_24s854_lam0(V self, V *args); static Clo g_co_2eplus_24s854_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s854_lam0, 3, 0};
V g_co_2eplus_24s854_lam2(V self, V *args); static Clo g_co_2eplus_24s854_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s854_lam2, 2, 0};

static V g_co_2eplus_24s854_val;
static int g_co_2eplus_24s854_st;
static V g_co_2eplus_24s854_init(void) {
  return heff_rec(2, shape_119_121, (V[]){((V)&g_co_2eplus_24s854_lam0_clo), ((V)&g_co_2eplus_24s854_lam2_clo)});
}
V g_co_2eplus_24s854_get(void) {
  if (g_co_2eplus_24s854_st == 2) return g_co_2eplus_24s854_val;
  if (g_co_2eplus_24s854_st == 1) heff_fail("defined by itself");
  g_co_2eplus_24s854_st = 1;
  g_co_2eplus_24s854_val = heff_tr(g_co_2eplus_24s854_init());
  g_co_2eplus_24s854_st = 2;
  return g_co_2eplus_24s854_val;
}
V g_co_2eplus_24s854_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_k_2410 = heff_dup(heff_env(self)[0]);
  V v_g_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2412 = heff_tr(heff_apply(v_k_2410, 1, (V[]){v_s_2411}));
  return heff_tail(v_g_241, 1, (V[]){v_t_2412});
}
V g_co_2eplus_24s854_lam0(V self, V *args) {
  V v_fm_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(self);
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse(v_p_242, 1ULL);
    heff_drop(v_fm_240);
    V v_t_2413;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Write: {
      V v_str_244 = heff_field(v_x_243, 0);
      V v_x_245 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Write = heff_take_reuse(v_x_243, 3ULL);
      heff_drop(v_ru_24p_242_24InL);
      V v_t_246 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_245}));
      v_t_2413 = heff_tag_at(v_ru_24x_243_24Write, TAG_Write, 2, (V[]){v_str_244, v_t_246});
      break;
    }
    case TAG_WriteErr: {
      V v_str_247 = heff_field(v_x_243, 0);
      V v_x_248 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24WriteErr = heff_take_reuse(v_x_243, 3ULL);
      heff_drop(v_ru_24p_242_24InL);
      V v_t_249 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_248}));
      v_t_2413 = heff_tag_at(v_ru_24x_243_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_247, v_t_249});
      break;
    }
    case TAG_ReadStdin: {
      V v_k_2410 = heff_field(v_x_243, 0);
      heff_take(v_x_243, 1ULL);
      v_t_2413 = heff_tag_at(v_ru_24p_242_24InL, TAG_ReadStdin, 1, (V[]){heff_clo(g_co_2eplus_24s854_lam1, 1, 2, (V[]){v_k_2410, v_g_241})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag(TAG_InL, 1, (V[]){v_t_2413});
  }
  case TAG_InR: {
    V v_y_2414 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse(v_p_242, 1ULL);
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(g_std_2eprocess_2eprocess_get()), LBL_hfmap), 3, (V[]){v_fm_240, v_g_241, v_y_2414}));
    return heff_tag_at(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2415});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s854_lam2(V self, V *args) {
  V v_nt_2416 = args[0];
  V v_p_2417 = args[1];
  heff_drop(self);
  heff_drop(v_nt_2416);
  switch (heff_tag_of(v_p_2417)) {
  case TAG_InL: {
    V v_x_2418 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InL = heff_take_reuse(v_p_2417, 1ULL);
    V v_t_2424;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_Write: {
      V v_str_2419 = heff_field(v_x_2418, 0);
      V v_x_2420 = heff_field(v_x_2418, 1);
      V v_ru_24x_2418_24Write = heff_take_reuse(v_x_2418, 3ULL);
      heff_drop(v_ru_24p_2417_24InL);
      v_t_2424 = heff_tag_at(v_ru_24x_2418_24Write, TAG_Write, 2, (V[]){v_str_2419, v_x_2420});
      break;
    }
    case TAG_WriteErr: {
      V v_str_2421 = heff_field(v_x_2418, 0);
      V v_x_2422 = heff_field(v_x_2418, 1);
      V v_ru_24x_2418_24WriteErr = heff_take_reuse(v_x_2418, 3ULL);
      heff_drop(v_ru_24p_2417_24InL);
      v_t_2424 = heff_tag_at(v_ru_24x_2418_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_2421, v_x_2422});
      break;
    }
    case TAG_ReadStdin: {
      V v_k_2423 = heff_field(v_x_2418, 0);
      heff_take(v_x_2418, 1ULL);
      v_t_2424 = heff_tag_at(v_ru_24p_2417_24InL, TAG_ReadStdin, 1, (V[]){v_k_2423});
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    return heff_tag(TAG_InL, 1, (V[]){v_t_2424});
  }
  case TAG_InR: {
    V v_y_2425 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InR = heff_take_reuse(v_p_2417, 1ULL);
    V v_t_2439;
    switch (heff_tag_of(v_y_2425)) {
    case TAG_Args: {
      V v_k_2426 = heff_field(v_y_2425, 0);
      heff_take(v_y_2425, 1ULL);
      v_t_2439 = heff_tag_at(v_ru_24p_2417_24InR, TAG_Args, 1, (V[]){v_k_2426});
      break;
    }
    case TAG_GetEnv: {
      V v_name_2427 = heff_field(v_y_2425, 0);
      V v_k_2428 = heff_field(v_y_2425, 1);
      V v_ru_24y_2425_24GetEnv = heff_take_reuse(v_y_2425, 3ULL);
      heff_drop(v_ru_24p_2417_24InR);
      v_t_2439 = heff_tag_at(v_ru_24y_2425_24GetEnv, TAG_GetEnv, 2, (V[]){v_name_2427, v_k_2428});
      break;
    }
    case TAG_ProgramPath: {
      V v_k_2429 = heff_field(v_y_2425, 0);
      heff_take(v_y_2425, 1ULL);
      v_t_2439 = heff_tag_at(v_ru_24p_2417_24InR, TAG_ProgramPath, 1, (V[]){v_k_2429});
      break;
    }
    case TAG_Platform: {
      V v_k_2430 = heff_field(v_y_2425, 0);
      heff_take(v_y_2425, 1ULL);
      v_t_2439 = heff_tag_at(v_ru_24p_2417_24InR, TAG_Platform, 1, (V[]){v_k_2430});
      break;
    }
    case TAG_Exit: {
      V v_code_2431 = heff_field(v_y_2425, 0);
      V v_x_2432 = heff_field(v_y_2425, 1);
      V v_ru_24y_2425_24Exit = heff_take_reuse(v_y_2425, 3ULL);
      heff_drop(v_ru_24p_2417_24InR);
      v_t_2439 = heff_tag_at(v_ru_24y_2425_24Exit, TAG_Exit, 2, (V[]){v_code_2431, v_x_2432});
      break;
    }
    case TAG_Exec: {
      V v_cmd_2433 = heff_field(v_y_2425, 0);
      V v_as_2434 = heff_field(v_y_2425, 1);
      V v_x_2435 = heff_field(v_y_2425, 2);
      V v_ru_24y_2425_24Exec = heff_take_reuse(v_y_2425, 7ULL);
      heff_drop(v_ru_24p_2417_24InR);
      v_t_2439 = heff_tag_at(v_ru_24y_2425_24Exec, TAG_Exec, 3, (V[]){v_cmd_2433, v_as_2434, v_x_2435});
      break;
    }
    case TAG_Run: {
      V v_cmd_2436 = heff_field(v_y_2425, 0);
      V v_as_2437 = heff_field(v_y_2425, 1);
      V v_k_2438 = heff_field(v_y_2425, 2);
      V v_ru_24y_2425_24Run = heff_take_reuse(v_y_2425, 7ULL);
      heff_drop(v_ru_24p_2417_24InR);
      v_t_2439 = heff_tag_at(v_ru_24y_2425_24Run, TAG_Run, 3, (V[]){v_cmd_2436, v_as_2437, v_k_2438});
      break;
    }
    default: heff_nomatch(v_y_2425);
    }
    return heff_tag(TAG_InR, 1, (V[]){v_t_2439});
  }
  default: return heff_nomatch(v_p_2417);
  }
}
V g_co_2eplus_24s855_lam1(V self, V *args);
V g_co_2eplus_24s855_lam0(V self, V *args); static Clo g_co_2eplus_24s855_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s855_lam0, 3, 0};
V g_co_2eplus_24s855_lam2(V self, V *args); static Clo g_co_2eplus_24s855_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s855_lam2, 2, 0};

static V g_co_2eplus_24s855_val;
static int g_co_2eplus_24s855_st;
static V g_co_2eplus_24s855_init(void) {
  return heff_rec(2, shape_119_121, (V[]){((V)&g_co_2eplus_24s855_lam0_clo), ((V)&g_co_2eplus_24s855_lam2_clo)});
}
V g_co_2eplus_24s855_get(void) {
  if (g_co_2eplus_24s855_st == 2) return g_co_2eplus_24s855_val;
  if (g_co_2eplus_24s855_st == 1) heff_fail("defined by itself");
  g_co_2eplus_24s855_st = 1;
  g_co_2eplus_24s855_val = heff_tr(g_co_2eplus_24s855_init());
  g_co_2eplus_24s855_st = 2;
  return g_co_2eplus_24s855_val;
}
V g_co_2eplus_24s855_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_k_2411 = heff_dup(heff_env(self)[0]);
  V v_g_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2413 = heff_tr(heff_apply(v_k_2411, 1, (V[]){v_s_2412}));
  return heff_tail(v_g_241, 1, (V[]){v_t_2413});
}
V g_co_2eplus_24s855_lam0(V self, V *args) {
  V v_fm_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(self);
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse(v_p_242, 1ULL);
    V v_t_2417;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InL = heff_take_reuse(v_x_243, 1ULL);
      heff_drop(v_fm_240);
      V v_t_2414;
      switch (heff_tag_of(v_x_244)) {
      case TAG_Write: {
        V v_str_245 = heff_field(v_x_244, 0);
        V v_x_246 = heff_field(v_x_244, 1);
        V v_ru_24x_244_24Write = heff_take_reuse(v_x_244, 3ULL);
        heff_drop(v_ru_24p_242_24InL);
        V v_t_247 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_246}));
        v_t_2414 = heff_tag_at(v_ru_24x_244_24Write, TAG_Write, 2, (V[]){v_str_245, v_t_247});
        break;
      }
      case TAG_WriteErr: {
        V v_str_248 = heff_field(v_x_244, 0);
        V v_x_249 = heff_field(v_x_244, 1);
        V v_ru_24x_244_24WriteErr = heff_take_reuse(v_x_244, 3ULL);
        heff_drop(v_ru_24p_242_24InL);
        V v_t_2410 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_249}));
        v_t_2414 = heff_tag_at(v_ru_24x_244_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_248, v_t_2410});
        break;
      }
      case TAG_ReadStdin: {
        V v_k_2411 = heff_field(v_x_244, 0);
        heff_take(v_x_244, 1ULL);
        v_t_2414 = heff_tag_at(v_ru_24p_242_24InL, TAG_ReadStdin, 1, (V[]){heff_clo(g_co_2eplus_24s855_lam1, 1, 2, (V[]){v_k_2411, v_g_241})});
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      v_t_2417 = heff_tag_at(v_ru_24x_243_24InL, TAG_InL, 1, (V[]){v_t_2414});
      break;
    }
    case TAG_InR: {
      V v_y_2415 = heff_field(v_x_243, 0);
      heff_take(v_x_243, 1ULL);
      V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(g_std_2eprocess_2eprocess_get()), LBL_hfmap), 3, (V[]){v_fm_240, v_g_241, v_y_2415}));
      v_t_2417 = heff_tag_at(v_ru_24p_242_24InL, TAG_InR, 1, (V[]){v_t_2416});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag(TAG_InL, 1, (V[]){v_t_2417});
  }
  case TAG_InR: {
    V v_y_2418 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse(v_p_242, 1ULL);
    V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(g_std_2efilesystem_2efs_get()), LBL_hfmap), 3, (V[]){v_fm_240, v_g_241, v_y_2418}));
    return heff_tag_at(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s855_lam2(V self, V *args) {
  V v_nt_2420 = args[0];
  V v_p_2421 = args[1];
  heff_drop(self);
  switch (heff_tag_of(v_p_2421)) {
  case TAG_InL: {
    V v_x_2422 = heff_field(v_p_2421, 0);
    V v_ru_24p_2421_24InL = heff_take_reuse(v_p_2421, 1ULL);
    V v_t_2423 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s854_get()), LBL_hmap), 2, (V[]){v_nt_2420, v_x_2422}));
    return heff_tag_at(v_ru_24p_2421_24InL, TAG_InL, 1, (V[]){v_t_2423});
  }
  case TAG_InR: {
    V v_y_2424 = heff_field(v_p_2421, 0);
    V v_ru_24p_2421_24InR = heff_take_reuse(v_p_2421, 1ULL);
    heff_drop(v_nt_2420);
    V v_t_2438;
    switch (heff_tag_of(v_y_2424)) {
    case TAG_ReadFile: {
      V v_path_2425 = heff_field(v_y_2424, 0);
      V v_k_2426 = heff_field(v_y_2424, 1);
      V v_ru_24y_2424_24ReadFile = heff_take_reuse(v_y_2424, 3ULL);
      v_t_2438 = heff_tag_at(v_ru_24y_2424_24ReadFile, TAG_ReadFile, 2, (V[]){v_path_2425, v_k_2426});
      break;
    }
    case TAG_WriteFile: {
      V v_path_2427 = heff_field(v_y_2424, 0);
      V v_str_2428 = heff_field(v_y_2424, 1);
      V v_k_2429 = heff_field(v_y_2424, 2);
      V v_ru_24y_2424_24WriteFile = heff_take_reuse(v_y_2424, 7ULL);
      v_t_2438 = heff_tag_at(v_ru_24y_2424_24WriteFile, TAG_WriteFile, 3, (V[]){v_path_2427, v_str_2428, v_k_2429});
      break;
    }
    case TAG_MkDir: {
      V v_path_2430 = heff_field(v_y_2424, 0);
      V v_k_2431 = heff_field(v_y_2424, 1);
      V v_ru_24y_2424_24MkDir = heff_take_reuse(v_y_2424, 3ULL);
      v_t_2438 = heff_tag_at(v_ru_24y_2424_24MkDir, TAG_MkDir, 2, (V[]){v_path_2430, v_k_2431});
      break;
    }
    case TAG_ReadDir: {
      V v_path_2432 = heff_field(v_y_2424, 0);
      V v_k_2433 = heff_field(v_y_2424, 1);
      V v_ru_24y_2424_24ReadDir = heff_take_reuse(v_y_2424, 3ULL);
      v_t_2438 = heff_tag_at(v_ru_24y_2424_24ReadDir, TAG_ReadDir, 2, (V[]){v_path_2432, v_k_2433});
      break;
    }
    case TAG_Remove: {
      V v_path_2434 = heff_field(v_y_2424, 0);
      V v_k_2435 = heff_field(v_y_2424, 1);
      V v_ru_24y_2424_24Remove = heff_take_reuse(v_y_2424, 3ULL);
      v_t_2438 = heff_tag_at(v_ru_24y_2424_24Remove, TAG_Remove, 2, (V[]){v_path_2434, v_k_2435});
      break;
    }
    case TAG_ReadOnly: {
      V v_path_2436 = heff_field(v_y_2424, 0);
      V v_k_2437 = heff_field(v_y_2424, 1);
      V v_ru_24y_2424_24ReadOnly = heff_take_reuse(v_y_2424, 3ULL);
      v_t_2438 = heff_tag_at(v_ru_24y_2424_24ReadOnly, TAG_ReadOnly, 2, (V[]){v_path_2436, v_k_2437});
      break;
    }
    default: heff_nomatch(v_y_2424);
    }
    return heff_tag_at(v_ru_24p_2421_24InR, TAG_InR, 1, (V[]){v_t_2438});
  }
  default: return heff_nomatch(v_p_2421);
  }
}
V g_co_2eplus_24s857_lam1(V self, V *args);
V g_co_2eplus_24s857_lam0(V self, V *args); static Clo g_co_2eplus_24s857_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s857_lam0, 3, 0};
V g_co_2eplus_24s857_lam2(V self, V *args); static Clo g_co_2eplus_24s857_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s857_lam2, 2, 0};

static V g_co_2eplus_24s857_val;
static int g_co_2eplus_24s857_st;
static V g_co_2eplus_24s857_init(void) {
  return heff_rec(2, shape_119_121, (V[]){((V)&g_co_2eplus_24s857_lam0_clo), ((V)&g_co_2eplus_24s857_lam2_clo)});
}
V g_co_2eplus_24s857_get(void) {
  if (g_co_2eplus_24s857_st == 2) return g_co_2eplus_24s857_val;
  if (g_co_2eplus_24s857_st == 1) heff_fail("defined by itself");
  g_co_2eplus_24s857_st = 1;
  g_co_2eplus_24s857_val = heff_tr(g_co_2eplus_24s857_init());
  g_co_2eplus_24s857_st = 2;
  return g_co_2eplus_24s857_val;
}
V g_co_2eplus_24s857_lam1(V self, V *args) {
  V v_b_248 = args[0];
  V v_k_247 = heff_dup(heff_env(self)[0]);
  V v_g_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_249 = heff_tr(heff_apply(v_k_247, 1, (V[]){v_b_248}));
  return heff_tail(v_g_241, 1, (V[]){v_t_249});
}
V g_co_2eplus_24s857_lam0(V self, V *args) {
  V v_fm_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(self);
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse(v_p_242, 1ULL);
    V v_t_2411;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      heff_take(v_x_243, 1ULL);
      V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s855_get()), LBL_hfmap), 3, (V[]){v_fm_240, v_g_241, v_x_244}));
      v_t_2411 = heff_tag_at(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_245});
      break;
    }
    case TAG_InR: {
      V v_y_246 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse(v_x_243, 1ULL);
      heff_drop(v_fm_240);
      V v_t_2410;
      switch (heff_tag_of(v_y_246)) {
      case TAG_UseColor: {
        V v_k_247 = heff_field(v_y_246, 0);
        heff_take(v_y_246, 1ULL);
        v_t_2410 = heff_tag_at(v_ru_24p_242_24InL, TAG_UseColor, 1, (V[]){heff_clo(g_co_2eplus_24s857_lam1, 1, 2, (V[]){v_k_247, v_g_241})});
        break;
      }
      default: heff_nomatch(v_y_246);
      }
      v_t_2411 = heff_tag_at(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2410});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag(TAG_InL, 1, (V[]){v_t_2411});
  }
  case TAG_InR: {
    V v_y_2412 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse(v_p_242, 1ULL);
    V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2erpc_2erpc_get()), LBL_hfmap), 3, (V[]){v_fm_240, v_g_241, v_y_2412}));
    return heff_tag_at(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2413});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s857_lam2(V self, V *args) {
  V v_nt_2414 = args[0];
  V v_p_2415 = args[1];
  heff_drop(self);
  switch (heff_tag_of(v_p_2415)) {
  case TAG_InL: {
    V v_x_2416 = heff_field(v_p_2415, 0);
    V v_ru_24p_2415_24InL = heff_take_reuse(v_p_2415, 1ULL);
    V v_t_2422;
    switch (heff_tag_of(v_x_2416)) {
    case TAG_InL: {
      V v_x_2417 = heff_field(v_x_2416, 0);
      heff_take(v_x_2416, 1ULL);
      V v_t_2418 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s855_get()), LBL_hmap), 2, (V[]){v_nt_2414, v_x_2417}));
      v_t_2422 = heff_tag_at(v_ru_24p_2415_24InL, TAG_InL, 1, (V[]){v_t_2418});
      break;
    }
    case TAG_InR: {
      V v_y_2419 = heff_field(v_x_2416, 0);
      V v_ru_24x_2416_24InR = heff_take_reuse(v_x_2416, 1ULL);
      heff_drop(v_nt_2414);
      V v_t_2421;
      switch (heff_tag_of(v_y_2419)) {
      case TAG_UseColor: {
        V v_k_2420 = heff_field(v_y_2419, 0);
        heff_take(v_y_2419, 1ULL);
        v_t_2421 = heff_tag_at(v_ru_24p_2415_24InL, TAG_UseColor, 1, (V[]){v_k_2420});
        break;
      }
      default: heff_nomatch(v_y_2419);
      }
      v_t_2422 = heff_tag_at(v_ru_24x_2416_24InR, TAG_InR, 1, (V[]){v_t_2421});
      break;
    }
    default: heff_nomatch(v_x_2416);
    }
    return heff_tag(TAG_InL, 1, (V[]){v_t_2422});
  }
  case TAG_InR: {
    V v_y_2423 = heff_field(v_p_2415, 0);
    V v_ru_24p_2415_24InR = heff_take_reuse(v_p_2415, 1ULL);
    heff_drop(v_nt_2414);
    V v_t_2440;
    switch (heff_tag_of(v_y_2423)) {
    case TAG_Await: {
      V v_t_2424 = heff_field(v_y_2423, 0);
      V v_k_2425 = heff_field(v_y_2423, 1);
      V v_ru_24y_2423_24Await = heff_take_reuse(v_y_2423, 3ULL);
      heff_drop(v_ru_24p_2415_24InR);
      v_t_2440 = heff_tag_at(v_ru_24y_2423_24Await, TAG_Await, 2, (V[]){v_t_2424, v_k_2425});
      break;
    }
    case TAG_Send: {
      V v_s_2426 = heff_field(v_y_2423, 0);
      V v_x_2427 = heff_field(v_y_2423, 1);
      V v_ru_24y_2423_24Send = heff_take_reuse(v_y_2423, 3ULL);
      heff_drop(v_ru_24p_2415_24InR);
      v_t_2440 = heff_tag_at(v_ru_24y_2423_24Send, TAG_Send, 2, (V[]){v_s_2426, v_x_2427});
      break;
    }
    case TAG_Log: {
      V v_s_2428 = heff_field(v_y_2423, 0);
      V v_x_2429 = heff_field(v_y_2423, 1);
      V v_ru_24y_2423_24Log = heff_take_reuse(v_y_2423, 3ULL);
      heff_drop(v_ru_24p_2415_24InR);
      v_t_2440 = heff_tag_at(v_ru_24y_2423_24Log, TAG_Log, 2, (V[]){v_s_2428, v_x_2429});
      break;
    }
    case TAG_Now: {
      V v_k_2430 = heff_field(v_y_2423, 0);
      heff_take(v_y_2423, 1ULL);
      v_t_2440 = heff_tag_at(v_ru_24p_2415_24InR, TAG_Now, 1, (V[]){v_k_2430});
      break;
    }
    case TAG_ProjectFiles: {
      V v_r_2431 = heff_field(v_y_2423, 0);
      V v_k_2432 = heff_field(v_y_2423, 1);
      V v_ru_24y_2423_24ProjectFiles = heff_take_reuse(v_y_2423, 3ULL);
      heff_drop(v_ru_24p_2415_24InR);
      v_t_2440 = heff_tag_at(v_ru_24y_2423_24ProjectFiles, TAG_ProjectFiles, 2, (V[]){v_r_2431, v_k_2432});
      break;
    }
    case TAG_UriPath: {
      V v_u_2433 = heff_field(v_y_2423, 0);
      V v_k_2434 = heff_field(v_y_2423, 1);
      V v_ru_24y_2423_24UriPath = heff_take_reuse(v_y_2423, 3ULL);
      heff_drop(v_ru_24p_2415_24InR);
      v_t_2440 = heff_tag_at(v_ru_24y_2423_24UriPath, TAG_UriPath, 2, (V[]){v_u_2433, v_k_2434});
      break;
    }
    case TAG_PathUri: {
      V v_p_2435 = heff_field(v_y_2423, 0);
      V v_k_2436 = heff_field(v_y_2423, 1);
      V v_ru_24y_2423_24PathUri = heff_take_reuse(v_y_2423, 3ULL);
      heff_drop(v_ru_24p_2415_24InR);
      v_t_2440 = heff_tag_at(v_ru_24y_2423_24PathUri, TAG_PathUri, 2, (V[]){v_p_2435, v_k_2436});
      break;
    }
    case TAG_AbsPath: {
      V v_p_2437 = heff_field(v_y_2423, 0);
      V v_k_2438 = heff_field(v_y_2423, 1);
      V v_ru_24y_2423_24AbsPath = heff_take_reuse(v_y_2423, 3ULL);
      heff_drop(v_ru_24p_2415_24InR);
      v_t_2440 = heff_tag_at(v_ru_24y_2423_24AbsPath, TAG_AbsPath, 2, (V[]){v_p_2437, v_k_2438});
      break;
    }
    case TAG_Quit: {
      V v_c_2439 = heff_field(v_y_2423, 0);
      heff_take(v_y_2423, 1ULL);
      v_t_2440 = heff_tag_at(v_ru_24p_2415_24InR, TAG_Quit, 1, (V[]){v_c_2439});
      break;
    }
    default: heff_nomatch(v_y_2423);
    }
    return heff_tag(TAG_InR, 1, (V[]){v_t_2440});
  }
  default: return heff_nomatch(v_p_2415);
  }
}