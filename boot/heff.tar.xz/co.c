// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Flush 26516
#define TAG_Get 18914
#define TAG_IsTerminal 53507
#define TAG_Left 13886
#define TAG_MkChk 56962
#define TAG_MkSt 48854
#define TAG_Monotonic 64960
#define TAG_NewKey 33294
#define TAG_Now 25954
#define TAG_Park 64043
#define TAG_RDone 16778
#define TAG_ReadStdin 20528
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_Sleep 25229
#define TAG_Spawn 10053
#define TAG_Throw 56084
#define TAG_Wake 10253
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_Yield 38529
#define LBL_bind 9519364
#define LBL_fmap 9641981
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_ret 322331
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_get(void);
V g_co_2e_3c_2b_3e_24s1267745919x482036999(V);
V g_co_2e_3c_2b_3e_24s1267745919x482036999_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s1267745919x482036999_clo;
V g_co_2e_3c_2b_3e_24s1404263853x1546533042(V);
V g_co_2e_3c_2b_3e_24s1404263853x1546533042_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s1404263853x1546533042_clo;
V g_co_2e_3c_2b_3e_24s1419042510x1098087825(V);
V g_co_2e_3c_2b_3e_24s1419042510x1098087825_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s1419042510x1098087825_clo;
V g_co_2e_3c_2b_3e_24s1585861108x1258949188(V);
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s1585861108x1258949188_clo;
V g_co_2e_3c_2b_3e_24s1611985049x766020670(V);
V g_co_2e_3c_2b_3e_24s1611985049x766020670_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s1611985049x766020670_clo;
V g_co_2e_3c_2b_3e_24s191044587x696072828(V);
V g_co_2e_3c_2b_3e_24s191044587x696072828_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s191044587x696072828_clo;
V g_co_2e_3c_2b_3e_24s199445780x454385136(V);
V g_co_2e_3c_2b_3e_24s199445780x454385136_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s199445780x454385136_clo;
V g_co_2e_3c_2b_3e_24s219000013x892923660(V);
V g_co_2e_3c_2b_3e_24s219000013x892923660_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s219000013x892923660_clo;
V g_co_2e_3c_2b_3e_24s965351493x1073186978(V);
V g_co_2e_3c_2b_3e_24s965351493x1073186978_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s965351493x1073186978_clo;
V g_co_2ebind_24s1421083649x484987773(V, V, V, V);
V g_co_2ebind_24s1421083649x484987773_entry(V self, V *a);
extern Clo g_co_2ebind_24s1421083649x484987773_clo;
V g_co_2ebind_24s1464300710x102529052(V, V, V);
V g_co_2ebind_24s1464300710x102529052_entry(V self, V *a);
extern Clo g_co_2ebind_24s1464300710x102529052_clo;
V g_co_2ebind_24s1831149655x1541910000(V, V, V);
V g_co_2ebind_24s1831149655x1541910000_entry(V self, V *a);
extern Clo g_co_2ebind_24s1831149655x1541910000_clo;
V g_co_2ebind_24s196996678x1811735276(V, V, V);
V g_co_2ebind_24s196996678x1811735276_entry(V self, V *a);
extern Clo g_co_2ebind_24s196996678x1811735276_clo;
V g_co_2ebind_24s491334399x268717303(V, V);
V g_co_2ebind_24s491334399x268717303_entry(V self, V *a);
extern Clo g_co_2ebind_24s491334399x268717303_clo;
V g_co_2eop(V, V, V, V, V);
V g_co_2eop_entry(V self, V *a);
extern Clo g_co_2eop_clo;
V g_co_2eop_24s1015281915x1399722043(V, V, V, V);
V g_co_2eop_24s1015281915x1399722043_entry(V self, V *a);
extern Clo g_co_2eop_24s1015281915x1399722043_clo;
V g_co_2eop_24s1549572115x1242285242(V, V, V, V);
V g_co_2eop_24s1549572115x1242285242_entry(V self, V *a);
extern Clo g_co_2eop_24s1549572115x1242285242_clo;
V g_co_2eop_24s1628839587x1321325607(V, V, V, V);
V g_co_2eop_24s1628839587x1321325607_entry(V self, V *a);
extern Clo g_co_2eop_24s1628839587x1321325607_clo;
V g_co_2eop_24s1701369613x1410211592(V, V, V, V);
V g_co_2eop_24s1701369613x1410211592_entry(V self, V *a);
extern Clo g_co_2eop_24s1701369613x1410211592_clo;
V g_co_2eop_24s1855546073x1099963660(V, V, V, V);
V g_co_2eop_24s1855546073x1099963660_entry(V self, V *a);
extern Clo g_co_2eop_24s1855546073x1099963660_clo;
V g_co_2eop_24s199044798x1745934964(V, V, V, V);
V g_co_2eop_24s199044798x1745934964_entry(V self, V *a);
extern Clo g_co_2eop_24s199044798x1745934964_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_co_2eop_24s942716005x1337691863(V, V, V, V);
V g_co_2eop_24s942716005x1337691863_entry(V self, V *a);
extern Clo g_co_2eop_24s942716005x1337691863_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_green_2egreen_get(void);
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2erules_2erecovering(V);
V g_heff_2eelab_2erules_2erecovering_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecovering_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s410120642x105714730(V, V);
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a);
extern Clo g_list_2efoldl_24s410120642x105714730_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_std_2enet_2enet_get(void);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
V g_std_2eprocess_2eprocess_get(void);
V g_std_2eprogress_2eprogress_get(void);
V g_std_2ereactor_2ereactor_get(void);
V g_std_2eterminal_2econsole_get(void);
V g_co_2eop_lam1(V self, V *args);
V g_co_2eop_lam0(V self, V *args); static Clo g_co_2eop_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_lam0, 4, 0};
V g_co_2eop_lam3(V self, V *args);
V g_co_2eop_lam2(V self, V *args);
V g_co_2eop_lam4(V self, V *args);
V g_co_2eop_lam5(V self, V *args);
Clo g_co_2eop_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_entry, 5, 0};

V g_co_2eop(V v_h_240, V v_p_241, V v_k_242, V v_hd_243, V v_k2_244) {
top: ;
  V v_t_2416 = heff_tr(heff_call(heff_get_n(v_h_240, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_lam2, 2, 1, (V[]){heff_dup(v_hd_243)})}), heff_clo_n(g_co_2eop_lam4, 1, 1, (V[]){heff_dup(v_hd_243)}), v_p_241}));
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2416}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_2417, heff_clo_n(g_co_2eop_lam5, 1, 3, (V[]){v_k_242, v_hd_243, v_k2_244})});
}
V g_co_2eop_entry(V self, V *a) {
  (void)self;
  return g_co_2eop(a[0], a[1], a[2], a[3], a[4]);
}
V g_co_2eop_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_x_2413}));
  V f_ = heff_get_n(v_hd_243, 0, 3);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_m_2412;
  args[1] = heff_clo_n(g_co_2eop_lam3, 1, 2, (V[]){v_g_2411, v_hd_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V v_hd_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_get_n(v_hd_243, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k2_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  heff_room[0] = v_x_2418;
  heff_room[1] = v_hd_243;
  heff_room[2] = v_k2_244;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eop_24s310169282x2049378029_lam1(V self, V *args);
V g_co_2eop_24s310169282x2049378029_lam0(V self, V *args); static Clo g_co_2eop_24s310169282x2049378029_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s310169282x2049378029_lam0, 4, 0};
V g_co_2eop_24s310169282x2049378029_lam3(V self, V *args);
V g_co_2eop_24s310169282x2049378029_lam2(V self, V *args);
V g_co_2eop_24s310169282x2049378029_lam4(V self, V *args);
Clo g_co_2eop_24s310169282x2049378029_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s310169282x2049378029_entry, 4, 0};

V g_co_2eop_24s310169282x2049378029(V v_h_240, V v_p_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2415 = heff_tr(heff_call(heff_get_n(v_h_240, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s310169282x2049378029_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s310169282x2049378029_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s310169282x2049378029_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_p_241}));
  V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2415}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2416, v_k2_243});
}
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s310169282x2049378029(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s310169282x2049378029_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s310169282x2049378029_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s310169282x2049378029_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s310169282x2049378029_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s310169282x2049378029_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s310169282x2049378029_lam3, 1, 2, (V[]){v_g_2410, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s310169282x2049378029_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1549572115x1242285242_lam1(V self, V *args);
V g_co_2eop_24s1549572115x1242285242_lam0(V self, V *args); static Clo g_co_2eop_24s1549572115x1242285242_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1549572115x1242285242_lam0, 4, 0};
V g_co_2eop_24s1549572115x1242285242_lam3(V self, V *args);
V g_co_2eop_24s1549572115x1242285242_lam2(V self, V *args);
V g_co_2eop_24s1549572115x1242285242_lam4(V self, V *args);
V g_co_2eop_24s1549572115x1242285242_lam5(V self, V *args);
Clo g_co_2eop_24s1549572115x1242285242_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1549572115x1242285242_entry, 4, 0};

V g_co_2eop_24s1549572115x1242285242(V v_h_240, V v_p_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2415 = heff_tr(heff_call(heff_get_n(v_h_240, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1549572115x1242285242_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1549572115x1242285242_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s1549572115x1242285242_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_p_241}));
  V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2415}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2416, heff_clo_n(g_co_2eop_24s1549572115x1242285242_lam5, 1, 1, (V[]){v_k2_243})});
}
V g_co_2eop_24s1549572115x1242285242_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1549572115x1242285242(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s1549572115x1242285242_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1549572115x1242285242_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s1549572115x1242285242_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1549572115x1242285242_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1549572115x1242285242_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s1549572115x1242285242_lam3, 1, 2, (V[]){v_g_2410, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1549572115x1242285242_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1549572115x1242285242_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k2_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_243;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2ebind_24s1831149655x1541910000_lam0(V self, V *args); static Clo g_co_2ebind_24s1831149655x1541910000_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1831149655x1541910000_lam0, 1, 0};
V g_co_2ebind_24s1831149655x1541910000_lam1(V self, V *args);
Clo g_co_2ebind_24s1831149655x1541910000_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1831149655x1541910000_entry, 3, 0};

V g_co_2ebind_24s1831149655x1541910000(V v_f_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_co_2ebind_24s1831149655x1541910000_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_249, heff_clo_n(g_co_2ebind_24s1831149655x1541910000_lam1, 1, 3, (V[]){v_f_240, v_hd_241, v_k_242})});
}
V g_co_2ebind_24s1831149655x1541910000_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s1831149655x1541910000(a[0], a[1], a[2]);
}
V g_co_2ebind_24s1831149655x1541910000_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_t_244 = ({ V b_0 = heff_get_n(v_c_243, 3, 9); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = (g_list_2emap_24s366344330x1145113647(v_t_244));
  V v_xs_246 = (g_list_2efoldl_24s410120642x105714730(NTAG(TAG_Nil), v_t_245));
  return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
}
V g_co_2ebind_24s1831149655x1541910000_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_f_240;
  heff_room[0] = v_x_2410;
  heff_room[1] = v_hd_241;
  heff_room[2] = v_k_242;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2ebind_24s1421083649x484987773_lam0(V self, V *args);
Clo g_co_2ebind_24s1421083649x484987773_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1421083649x484987773_entry, 4, 0};

V g_co_2ebind_24s1421083649x484987773(V v_c_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  return heff_tail(v_c_240, 2, (V[]){heff_dup(v_hd_242), heff_clo_n(g_co_2ebind_24s1421083649x484987773_lam0, 1, 3, (V[]){v_f_241, v_hd_242, v_k_243})});
}
V g_co_2ebind_24s1421083649x484987773_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s1421083649x484987773(a[0], a[1], a[2], a[3]);
}
V g_co_2ebind_24s1421083649x484987773_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_f_241;
  heff_room[0] = v_x_244;
  heff_room[1] = v_hd_242;
  heff_room[2] = v_k_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2ebind_24s196996678x1811735276_lam1(V self, V *args);
V g_co_2ebind_24s196996678x1811735276_lam0(V self, V *args);
Clo g_co_2ebind_24s196996678x1811735276_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s196996678x1811735276_entry, 3, 0};

V g_co_2ebind_24s196996678x1811735276(V v_c_240, V v_hd_241, V v_k_242) {
top: ;
  return heff_tail(v_c_240, 2, (V[]){v_hd_241, heff_clo_n(g_co_2ebind_24s196996678x1811735276_lam0, 1, 1, (V[]){v_k_242})});
}
V g_co_2ebind_24s196996678x1811735276_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s196996678x1811735276(a[0], a[1], a[2]);
}
V g_co_2ebind_24s196996678x1811735276_lam1(V self, V *args) {
  V v_a_245 = args[0];
  V v_a_246 = args[1];
  V v_a_247 = args[2];
  V v_a_248 = args[3];
  V v_a_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_245);
  heff_drop(v_a_246);
  V v_bind_249 = heff_take_field(v_a_247, 1);
  V v_malg_2410 = heff_get_n(v_a_247, 2, 3);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_a_244})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(v_malg_2410, 1, (V[]){v_t_2412}));
  V f_ = v_bind_249;
  args[0] = v_t_2413;
  args[1] = v_a_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2ebind_24s196996678x1811735276_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_243)) {
  case TAG_Left: {
    V v_a_244 = heff_field(v_x_243, 0);
    V v_ru_24x_243_24Left = heff_take_reuse_n(v_x_243, 1ULL, 1);
    V v_t_2414 = ({ V b_0 = heff_tag_at_n(v_ru_24x_243_24Left, TAG_MkChk, 1, (V[]){heff_clo_n(g_co_2ebind_24s196996678x1811735276_lam1, 4, 1, (V[]){v_a_244})}); V r_ = (g_heff_2eelab_2erules_2erecovering(b_0)); heff_drop(b_0); r_; });
    V f_ = v_k_242;
    args[0] = v_t_2414;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_a_2415 = heff_field(v_x_243, 0);
    heff_take_n(v_x_243, 1ULL, 1);
    V v_t_2416 = ({ V a_0 = v_a_2415; V r_ = (g_heff_2eelab_2erules_2erecovering(a_0)); heff_drop(v_a_2415); r_; });
    V f_ = v_k_242;
    args[0] = v_t_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_243);
  }
}
V g_co_2ebind_24s491334399x268717303_lam0(V self, V *args); static Clo g_co_2ebind_24s491334399x268717303_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s491334399x268717303_lam0, 2, 0};
Clo g_co_2ebind_24s491334399x268717303_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s491334399x268717303_entry, 2, 0};

V g_co_2ebind_24s491334399x268717303(V v_f_240, V v_st_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_c_242 = heff_dup(heff_field(v_st_241, 0));
    v_t_245 = v_c_242;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_t_246 = ({ V b_0 = heff_get_n(v_t_245, 3, 9); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_247 = (g_list_2emap_24s366344330x1145113647(v_t_246));
  V v_xs_248 = (g_list_2efoldl_24s410120642x105714730(NTAG(TAG_Nil), v_t_247));
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
  return heff_tail(v_f_240, 4, (V[]){v_t_249, heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), ((V)&g_co_2ebind_24s491334399x268717303_lam0_clo), v_st_241});
}
V g_co_2ebind_24s491334399x268717303_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s491334399x268717303(a[0], a[1]);
}
V g_co_2ebind_24s491334399x268717303_lam0(V self, V *args) {
  V v_a_2410 = args[0];
  V v_a_2411 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2410}), v_a_2411});
}
V g_co_2ebind_24s1464300710x102529052_lam1(V self, V *args); static Clo g_co_2ebind_24s1464300710x102529052_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1464300710x102529052_lam1, 2, 0};
V g_co_2ebind_24s1464300710x102529052_lam0(V self, V *args);
Clo g_co_2ebind_24s1464300710x102529052_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1464300710x102529052_entry, 3, 0};

V g_co_2ebind_24s1464300710x102529052(V v_c_240, V v_f_241, V v_z_242) {
top: ;
  return heff_tail(v_c_240, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_co_2ebind_24s1464300710x102529052_lam0, 1, 1, (V[]){v_f_241}), v_z_242});
}
V g_co_2ebind_24s1464300710x102529052_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s1464300710x102529052(a[0], a[1], a[2]);
}
V g_co_2ebind_24s1464300710x102529052_lam1(V self, V *args) {
  V v_a_244 = args[0];
  V v_a_245 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_244}), v_a_245});
}
V g_co_2ebind_24s1464300710x102529052_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_f_241;
  heff_room[0] = v_x_243;
  heff_room[1] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[2] = ((V)&g_co_2ebind_24s1464300710x102529052_lam1_clo);
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eop_24s1628839587x1321325607_lam0(V self, V *args);
V g_co_2eop_24s1628839587x1321325607_lam2(V self, V *args);
V g_co_2eop_24s1628839587x1321325607_lam1(V self, V *args); static Clo g_co_2eop_24s1628839587x1321325607_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1628839587x1321325607_lam1, 4, 0};
V g_co_2eop_24s1628839587x1321325607_lam4(V self, V *args);
V g_co_2eop_24s1628839587x1321325607_lam3(V self, V *args);
V g_co_2eop_24s1628839587x1321325607_lam5(V self, V *args);
Clo g_co_2eop_24s1628839587x1321325607_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1628839587x1321325607_entry, 4, 0};

V g_co_2eop_24s1628839587x1321325607(V v_lit_240, V v_p_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2425;
  switch (heff_tag_of(v_p_241)) {
  case TAG_InL: {
    V v_x_244 = heff_field(v_p_241, 0);
    V v_ru_24p_241_24InL = heff_take_reuse_n(v_p_241, 1ULL, 1);
    heff_drop_rec(v_lit_240, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_Throw: {
      V v_s_245 = heff_field(v_x_244, 0);
      V v_ru_24x_244_24Throw = heff_take_reuse_n(v_x_244, 1ULL, 1);
      v_t_2411 = heff_tag_at_n(v_ru_24x_244_24Throw, TAG_Throw, 1, (V[]){v_s_245});
      break;
    }
    case TAG_Catch: {
      V v_c_246 = heff_field(v_x_244, 0);
      V v_h_247 = heff_field(v_x_244, 1);
      V v_ru_24x_244_24Catch = heff_take_reuse_n(v_x_244, 3ULL, 2);
      V v_t_248 = heff_tr(heff_call(v_c_246, 2, (V[]){heff_dup(v_hd_242), heff_dup(heff_rfield(v_hd_242, 0))}));
      v_t_2411 = heff_tag_at_n(v_ru_24x_244_24Catch, TAG_Catch, 2, (V[]){v_t_248, heff_clo_n(g_co_2eop_24s1628839587x1321325607_lam0, 1, 2, (V[]){v_h_247, heff_dup(v_hd_242)})});
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    v_t_2425 = heff_tag_at_n(v_ru_24p_241_24InL, TAG_InL, 1, (V[]){v_t_2411});
    break;
  }
  case TAG_InR: {
    V v_y_2412 = heff_field(v_p_241, 0);
    V v_ru_24p_241_24InR = heff_take_reuse_n(v_p_241, 1ULL, 1);
    V v_t_2424 = heff_tr(heff_call(heff_get_n(v_lit_240, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1628839587x1321325607_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1628839587x1321325607_lam3, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s1628839587x1321325607_lam5, 1, 1, (V[]){heff_dup(v_hd_242)}), v_y_2412}));
    v_t_2425 = heff_tag_at_n(v_ru_24p_241_24InR, TAG_InR, 1, (V[]){v_t_2424});
    break;
  }
  default: heff_nomatch(v_p_241);
  }
  V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2425}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2426, v_k2_243});
}
V g_co_2eop_24s1628839587x1321325607_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1628839587x1321325607(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s1628839587x1321325607_lam0(V self, V *args) {
  V v_s_249 = args[0];
  V v_h_247 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2410 = heff_tr(heff_call(v_h_247, 1, (V[]){v_s_249}));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1628839587x1321325607_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_2413 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2418 = heff_tr(heff_call(v_g_2413, 1, (V[]){v_x_2417}));
  V f_ = v_k_2416;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1628839587x1321325607_lam1(V self, V *args) {
  V v_g_2413 = args[0];
  V v_c_2414 = args[1];
  V v_hd_2415 = args[2];
  V v_k_2416 = args[3];
  V f_ = v_c_2414;
  args[0] = v_hd_2415;
  args[1] = heff_clo_n(g_co_2eop_24s1628839587x1321325607_lam2, 1, 2, (V[]){v_g_2413, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1628839587x1321325607_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_2419 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tr(heff_call(v_g_2419, 1, (V[]){v_x_2421}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1628839587x1321325607_lam3(V self, V *args) {
  V v_g_2419 = args[0];
  V v_m_2420 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2420;
  args[1] = heff_clo_n(g_co_2eop_24s1628839587x1321325607_lam4, 1, 2, (V[]){v_g_2419, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1628839587x1321325607_lam5(V self, V *args) {
  V v_c_2423 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1855546073x1099963660_lam0(V self, V *args);
V g_co_2eop_24s1855546073x1099963660_lam2(V self, V *args);
V g_co_2eop_24s1855546073x1099963660_lam1(V self, V *args); static Clo g_co_2eop_24s1855546073x1099963660_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1855546073x1099963660_lam1, 4, 0};
V g_co_2eop_24s1855546073x1099963660_lam4(V self, V *args);
V g_co_2eop_24s1855546073x1099963660_lam3(V self, V *args);
V g_co_2eop_24s1855546073x1099963660_lam5(V self, V *args);
Clo g_co_2eop_24s1855546073x1099963660_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1855546073x1099963660_entry, 4, 0};

V g_co_2eop_24s1855546073x1099963660(V v_lit_240, V v_p_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2425;
  switch (heff_tag_of(v_p_241)) {
  case TAG_InL: {
    V v_x_244 = heff_field(v_p_241, 0);
    V v_ru_24p_241_24InL = heff_take_reuse_n(v_p_241, 1ULL, 1);
    heff_drop_rec(v_lit_240, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_Throw: {
      V v_s_245 = heff_field(v_x_244, 0);
      V v_ru_24x_244_24Throw = heff_take_reuse_n(v_x_244, 1ULL, 1);
      v_t_2411 = heff_tag_at_n(v_ru_24x_244_24Throw, TAG_Throw, 1, (V[]){v_s_245});
      break;
    }
    case TAG_Catch: {
      V v_c_246 = heff_field(v_x_244, 0);
      V v_h_247 = heff_field(v_x_244, 1);
      V v_ru_24x_244_24Catch = heff_take_reuse_n(v_x_244, 3ULL, 2);
      V v_t_248 = heff_tr(heff_call(v_c_246, 2, (V[]){heff_dup(v_hd_242), heff_dup(heff_rfield(v_hd_242, 0))}));
      v_t_2411 = heff_tag_at_n(v_ru_24x_244_24Catch, TAG_Catch, 2, (V[]){v_t_248, heff_clo_n(g_co_2eop_24s1855546073x1099963660_lam0, 1, 2, (V[]){v_h_247, heff_dup(v_hd_242)})});
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    v_t_2425 = heff_tag_at_n(v_ru_24p_241_24InL, TAG_InL, 1, (V[]){v_t_2411});
    break;
  }
  case TAG_InR: {
    V v_y_2412 = heff_field(v_p_241, 0);
    V v_ru_24p_241_24InR = heff_take_reuse_n(v_p_241, 1ULL, 1);
    V v_t_2424 = heff_tr(heff_call(heff_get_n(v_lit_240, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1855546073x1099963660_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1855546073x1099963660_lam3, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s1855546073x1099963660_lam5, 1, 1, (V[]){heff_dup(v_hd_242)}), v_y_2412}));
    v_t_2425 = heff_tag_at_n(v_ru_24p_241_24InR, TAG_InR, 1, (V[]){v_t_2424});
    break;
  }
  default: heff_nomatch(v_p_241);
  }
  V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2425}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2426, v_k2_243});
}
V g_co_2eop_24s1855546073x1099963660_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1855546073x1099963660(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s1855546073x1099963660_lam0(V self, V *args) {
  V v_s_249 = args[0];
  V v_h_247 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2410 = heff_tr(heff_call(v_h_247, 1, (V[]){v_s_249}));
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1855546073x1099963660_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_2413 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2418 = heff_tr(heff_call(v_g_2413, 1, (V[]){v_x_2417}));
  V f_ = v_k_2416;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1855546073x1099963660_lam1(V self, V *args) {
  V v_g_2413 = args[0];
  V v_c_2414 = args[1];
  V v_hd_2415 = args[2];
  V v_k_2416 = args[3];
  V f_ = v_c_2414;
  args[0] = v_hd_2415;
  args[1] = heff_clo_n(g_co_2eop_24s1855546073x1099963660_lam2, 1, 2, (V[]){v_g_2413, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1855546073x1099963660_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_2419 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tr(heff_call(v_g_2419, 1, (V[]){v_x_2421}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1855546073x1099963660_lam3(V self, V *args) {
  V v_g_2419 = args[0];
  V v_m_2420 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2420;
  args[1] = heff_clo_n(g_co_2eop_24s1855546073x1099963660_lam4, 1, 2, (V[]){v_g_2419, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1855546073x1099963660_lam5(V self, V *args) {
  V v_c_2423 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1015281915x1399722043_lam1(V self, V *args);
V g_co_2eop_24s1015281915x1399722043_lam0(V self, V *args); static Clo g_co_2eop_24s1015281915x1399722043_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1015281915x1399722043_lam0, 4, 0};
V g_co_2eop_24s1015281915x1399722043_lam3(V self, V *args);
V g_co_2eop_24s1015281915x1399722043_lam2(V self, V *args);
V g_co_2eop_24s1015281915x1399722043_lam4(V self, V *args);
V g_co_2eop_24s1015281915x1399722043_lam5(V self, V *args);
Clo g_co_2eop_24s1015281915x1399722043_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1015281915x1399722043_entry, 4, 0};

V g_co_2eop_24s1015281915x1399722043(V v_h_240, V v_p_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2415 = heff_tr(heff_call(heff_get_n(v_h_240, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1015281915x1399722043_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1015281915x1399722043_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s1015281915x1399722043_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_p_241}));
  V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2415}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2416, heff_clo_n(g_co_2eop_24s1015281915x1399722043_lam5, 1, 1, (V[]){v_k2_243})});
}
V g_co_2eop_24s1015281915x1399722043_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1015281915x1399722043(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s1015281915x1399722043_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1015281915x1399722043_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s1015281915x1399722043_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1015281915x1399722043_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1015281915x1399722043_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s1015281915x1399722043_lam3, 1, 2, (V[]){v_g_2410, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1015281915x1399722043_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1015281915x1399722043_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k2_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_243;
  args[0] = heff_tag_n(TAG_RDone, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam0(V self, V *args);
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam3(V self, V *args);
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam2(V self, V *args);
Clo g_co_2e_3c_2b_3e_24s1585861108x1258949188_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1585861108x1258949188_entry, 1, 0};

V g_co_2e_3c_2b_3e_24s1585861108x1258949188(V v_k_240) {
top: ;
  V v_hfmap_241 = heff_take_field(v_k_240, 0);
  V v_hmap_242 = heff_get_n(v_k_240, 1, 2);
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam0, 3, 1, (V[]){v_hfmap_241}), heff_clo_n(g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam2, 4, 1, (V[]){v_hmap_242})});
}
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_entry(V self, V *a) {
  (void)self;
  return g_co_2e_3c_2b_3e_24s1585861108x1258949188(a[0]);
}
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_h_249 = heff_env(self)[0];
  V v_m_243 = heff_env(self)[1];
  V v_g_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tr(heff_call(v_h_249, 1, (V[]){v_s_2411}));
  V f_ = heff_get_n(v_m_243, 0, 1);
  heff_room[0] = v_g_244;
  heff_room[1] = v_t_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_g_244 = args[1];
  V v_p_245 = args[2];
  V v_hfmap_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_InL: {
    V v_x_246 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InL = heff_take_reuse_n(v_p_245, 1ULL, 1);
    heff_drop(v_hfmap_241);
    V v_t_2413;
    switch (heff_tag_of(v_x_246)) {
    case TAG_Throw: {
      V v_s_247 = heff_field(v_x_246, 0);
      V v_ru_24x_246_24Throw = heff_take_reuse_n(v_x_246, 1ULL, 1);
      heff_drop_rec(v_m_243, 1);
      heff_drop(v_g_244);
      v_t_2413 = heff_tag_at_n(v_ru_24x_246_24Throw, TAG_Throw, 1, (V[]){v_s_247});
      break;
    }
    case TAG_Catch: {
      V v_c_248 = heff_field(v_x_246, 0);
      V v_h_249 = heff_field(v_x_246, 1);
      V v_ru_24x_246_24Catch = heff_take_reuse_n(v_x_246, 3ULL, 2);
      V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_243, 0)), 2, (V[]){heff_dup(v_g_244), v_c_248}));
      v_t_2413 = heff_tag_at_n(v_ru_24x_246_24Catch, TAG_Catch, 2, (V[]){v_t_2410, heff_clo_n(g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam1, 1, 3, (V[]){v_h_249, v_m_243, v_g_244})});
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    return heff_tag_at_n(v_ru_24p_245_24InL, TAG_InL, 1, (V[]){v_t_2413});
  }
  case TAG_InR: {
    V v_y_2414 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InR = heff_take_reuse_n(v_p_245, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(v_hfmap_241, 3, (V[]){v_m_243, v_g_244, v_y_2414}));
    return heff_tag_at_n(v_ru_24p_245_24InR, TAG_InR, 1, (V[]){v_t_2415});
  }
  default: return heff_nomatch(v_p_245);
  }
}
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam3(V self, V *args) {
  V v_s_2425 = args[0];
  V v_h_2423 = heff_env(self)[0];
  V v_nt_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = heff_tr(heff_call(v_h_2423, 1, (V[]){v_s_2425}));
  V f_ = v_nt_2418;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam2(V self, V *args) {
  V v_m_2416 = args[0];
  V v_n_2417 = args[1];
  V v_nt_2418 = args[2];
  V v_p_2419 = args[3];
  V v_hmap_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2419)) {
  case TAG_InL: {
    V v_x_2420 = heff_field(v_p_2419, 0);
    V v_ru_24p_2419_24InL = heff_take_reuse_n(v_p_2419, 1ULL, 1);
    heff_drop(v_m_2416);
    heff_drop(v_n_2417);
    heff_drop(v_hmap_242);
    V v_t_2427;
    switch (heff_tag_of(v_x_2420)) {
    case TAG_Throw: {
      V v_s_2421 = heff_field(v_x_2420, 0);
      V v_ru_24x_2420_24Throw = heff_take_reuse_n(v_x_2420, 1ULL, 1);
      heff_drop(v_nt_2418);
      v_t_2427 = heff_tag_at_n(v_ru_24x_2420_24Throw, TAG_Throw, 1, (V[]){v_s_2421});
      break;
    }
    case TAG_Catch: {
      V v_c_2422 = heff_field(v_x_2420, 0);
      V v_h_2423 = heff_field(v_x_2420, 1);
      V v_ru_24x_2420_24Catch = heff_take_reuse_n(v_x_2420, 3ULL, 2);
      V v_t_2424 = heff_tr(heff_call(heff_dup(v_nt_2418), 1, (V[]){v_c_2422}));
      v_t_2427 = heff_tag_at_n(v_ru_24x_2420_24Catch, TAG_Catch, 2, (V[]){v_t_2424, heff_clo_n(g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam3, 1, 2, (V[]){v_h_2423, v_nt_2418})});
      break;
    }
    default: heff_nomatch(v_x_2420);
    }
    return heff_tag_at_n(v_ru_24p_2419_24InL, TAG_InL, 1, (V[]){v_t_2427});
  }
  case TAG_InR: {
    V v_y_2428 = heff_field(v_p_2419, 0);
    V v_ru_24p_2419_24InR = heff_take_reuse_n(v_p_2419, 1ULL, 1);
    V v_t_2429 = heff_tr(heff_call(v_hmap_242, 4, (V[]){v_m_2416, v_n_2417, v_nt_2418, v_y_2428}));
    return heff_tag_at_n(v_ru_24p_2419_24InR, TAG_InR, 1, (V[]){v_t_2429});
  }
  default: return heff_nomatch(v_p_2419);
  }
}
V g_co_2e_3c_2b_3e_24s1404263853x1546533042_lam0(V self, V *args);
V g_co_2e_3c_2b_3e_24s1404263853x1546533042_lam1(V self, V *args);
Clo g_co_2e_3c_2b_3e_24s1404263853x1546533042_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1404263853x1546533042_entry, 1, 0};

V g_co_2e_3c_2b_3e_24s1404263853x1546533042(V v_k_240) {
top: ;
  V v_hfmap_241 = heff_take_field(v_k_240, 0);
  V v_hmap_242 = heff_get_n(v_k_240, 1, 2);
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1404263853x1546533042_lam0, 3, 1, (V[]){v_hfmap_241}), heff_clo_n(g_co_2e_3c_2b_3e_24s1404263853x1546533042_lam1, 4, 1, (V[]){v_hmap_242})});
}
V g_co_2e_3c_2b_3e_24s1404263853x1546533042_entry(V self, V *a) {
  (void)self;
  return g_co_2e_3c_2b_3e_24s1404263853x1546533042(a[0]);
}
V g_co_2e_3c_2b_3e_24s1404263853x1546533042_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_g_244 = args[1];
  V v_p_245 = args[2];
  V v_hfmap_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_InL: {
    V v_x_246 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InL = heff_take_reuse_n(v_p_245, 1ULL, 1);
    heff_drop(v_hfmap_241);
    V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_green_2egreen_get(), 0)), 3, (V[]){v_m_243, v_g_244, v_x_246}));
    return heff_tag_at_n(v_ru_24p_245_24InL, TAG_InL, 1, (V[]){v_t_247});
  }
  case TAG_InR: {
    V v_y_248 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InR = heff_take_reuse_n(v_p_245, 1ULL, 1);
    V v_t_249 = heff_tr(heff_call(v_hfmap_241, 3, (V[]){v_m_243, v_g_244, v_y_248}));
    return heff_tag_at_n(v_ru_24p_245_24InR, TAG_InR, 1, (V[]){v_t_249});
  }
  default: return heff_nomatch(v_p_245);
  }
}
V g_co_2e_3c_2b_3e_24s1404263853x1546533042_lam1(V self, V *args) {
  V v_m_2410 = args[0];
  V v_n_2411 = args[1];
  V v_nt_2412 = args[2];
  V v_p_2413 = args[3];
  V v_hmap_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2413)) {
  case TAG_InL: {
    V v_x_2414 = heff_field(v_p_2413, 0);
    V v_ru_24p_2413_24InL = heff_take_reuse_n(v_p_2413, 1ULL, 1);
    heff_drop(v_m_2410);
    heff_drop(v_n_2411);
    heff_drop(v_hmap_242);
    V v_t_2425;
    switch (heff_tag_of(v_x_2414)) {
    case TAG_Spawn: {
      V v_c_2415 = heff_field(v_x_2414, 0);
      V v_x_2416 = heff_field(v_x_2414, 1);
      V v_ru_24x_2414_24Spawn = heff_take_reuse_n(v_x_2414, 3ULL, 2);
      V v_t_2417 = heff_tr(heff_call(v_nt_2412, 1, (V[]){v_c_2415}));
      v_t_2425 = heff_tag_at_n(v_ru_24x_2414_24Spawn, TAG_Spawn, 2, (V[]){v_t_2417, v_x_2416});
      break;
    }
    case TAG_Yield: {
      V v_x_2418 = heff_field(v_x_2414, 0);
      V v_ru_24x_2414_24Yield = heff_take_reuse_n(v_x_2414, 1ULL, 1);
      heff_drop(v_nt_2412);
      v_t_2425 = heff_tag_at_n(v_ru_24x_2414_24Yield, TAG_Yield, 1, (V[]){v_x_2418});
      break;
    }
    case TAG_NewKey: {
      V v_k_2419 = heff_field(v_x_2414, 0);
      V v_ru_24x_2414_24NewKey = heff_take_reuse_n(v_x_2414, 1ULL, 1);
      heff_drop(v_nt_2412);
      v_t_2425 = heff_tag_at_n(v_ru_24x_2414_24NewKey, TAG_NewKey, 1, (V[]){v_k_2419});
      break;
    }
    case TAG_Wake: {
      V v_ch_2420 = heff_field(v_x_2414, 0);
      V v_v_2421 = heff_field(v_x_2414, 1);
      V v_x_2422 = heff_field(v_x_2414, 2);
      V v_ru_24x_2414_24Wake = heff_take_reuse_n(v_x_2414, 7ULL, 3);
      heff_drop(v_nt_2412);
      v_t_2425 = heff_tag_at_n(v_ru_24x_2414_24Wake, TAG_Wake, 3, (V[]){v_ch_2420, v_v_2421, v_x_2422});
      break;
    }
    case TAG_Park: {
      V v_ch_2423 = heff_field(v_x_2414, 0);
      V v_k_2424 = heff_field(v_x_2414, 1);
      V v_ru_24x_2414_24Park = heff_take_reuse_n(v_x_2414, 3ULL, 2);
      heff_drop(v_nt_2412);
      v_t_2425 = heff_tag_at_n(v_ru_24x_2414_24Park, TAG_Park, 2, (V[]){v_ch_2423, v_k_2424});
      break;
    }
    default: heff_nomatch(v_x_2414);
    }
    return heff_tag_at_n(v_ru_24p_2413_24InL, TAG_InL, 1, (V[]){v_t_2425});
  }
  case TAG_InR: {
    V v_y_2426 = heff_field(v_p_2413, 0);
    V v_ru_24p_2413_24InR = heff_take_reuse_n(v_p_2413, 1ULL, 1);
    V v_t_2427 = heff_tr(heff_call(v_hmap_242, 4, (V[]){v_m_2410, v_n_2411, v_nt_2412, v_y_2426}));
    return heff_tag_at_n(v_ru_24p_2413_24InR, TAG_InR, 1, (V[]){v_t_2427});
  }
  default: return heff_nomatch(v_p_2413);
  }
}
V g_co_2e_3c_2b_3e_24s965351493x1073186978_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s965351493x1073186978_lam0(V self, V *args);
V g_co_2e_3c_2b_3e_24s965351493x1073186978_lam2(V self, V *args);
Clo g_co_2e_3c_2b_3e_24s965351493x1073186978_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s965351493x1073186978_entry, 1, 0};

V g_co_2e_3c_2b_3e_24s965351493x1073186978(V v_h_240) {
top: ;
  V v_hfmap_241 = heff_take_field(v_h_240, 0);
  V v_hmap_242 = heff_get_n(v_h_240, 1, 2);
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s965351493x1073186978_lam0, 3, 1, (V[]){v_hfmap_241}), heff_clo_n(g_co_2e_3c_2b_3e_24s965351493x1073186978_lam2, 4, 1, (V[]){v_hmap_242})});
}
V g_co_2e_3c_2b_3e_24s965351493x1073186978_entry(V self, V *a) {
  (void)self;
  return g_co_2e_3c_2b_3e_24s965351493x1073186978(a[0]);
}
V g_co_2e_3c_2b_3e_24s965351493x1073186978_lam1(V self, V *args) {
  V v_r_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_r_2411}));
  V f_ = v_g_244;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s965351493x1073186978_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_g_244 = args[1];
  V v_p_245 = args[2];
  V v_hfmap_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_InL: {
    V v_x_246 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InL = heff_take_reuse_n(v_p_245, 1ULL, 1);
    V v_t_247 = heff_tr(heff_call(v_hfmap_241, 3, (V[]){v_m_243, v_g_244, v_x_246}));
    return heff_tag_at_n(v_ru_24p_245_24InL, TAG_InL, 1, (V[]){v_t_247});
  }
  case TAG_InR: {
    V v_y_248 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InR = heff_take_reuse_n(v_p_245, 1ULL, 1);
    heff_drop(v_m_243);
    heff_drop(v_hfmap_241);
    V v_t_2413;
    switch (heff_tag_of(v_y_248)) {
    case TAG_Send: {
      V v_rq_249 = heff_field(v_y_248, 0);
      V v_k_2410 = heff_field(v_y_248, 1);
      V v_ru_24y_248_24Send = heff_take_reuse_n(v_y_248, 3ULL, 2);
      v_t_2413 = heff_tag_at_n(v_ru_24y_248_24Send, TAG_Send, 2, (V[]){v_rq_249, heff_clo_n(g_co_2e_3c_2b_3e_24s965351493x1073186978_lam1, 1, 2, (V[]){v_k_2410, v_g_244})});
      break;
    }
    default: heff_nomatch(v_y_248);
    }
    return heff_tag_at_n(v_ru_24p_245_24InR, TAG_InR, 1, (V[]){v_t_2413});
  }
  default: return heff_nomatch(v_p_245);
  }
}
V g_co_2e_3c_2b_3e_24s965351493x1073186978_lam2(V self, V *args) {
  V v_m_2414 = args[0];
  V v_n_2415 = args[1];
  V v_nt_2416 = args[2];
  V v_p_2417 = args[3];
  V v_hmap_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2417)) {
  case TAG_InL: {
    V v_x_2418 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InL = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    V v_t_2419 = heff_tr(heff_call(v_hmap_242, 4, (V[]){v_m_2414, v_n_2415, v_nt_2416, v_x_2418}));
    return heff_tag_at_n(v_ru_24p_2417_24InL, TAG_InL, 1, (V[]){v_t_2419});
  }
  case TAG_InR: {
    V v_y_2420 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InR = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    heff_drop(v_m_2414);
    heff_drop(v_n_2415);
    heff_drop(v_nt_2416);
    heff_drop(v_hmap_242);
    return heff_tag_at_n(v_ru_24p_2417_24InR, TAG_InR, 1, (V[]){v_y_2420});
  }
  default: return heff_nomatch(v_p_2417);
  }
}
V g_co_2e_3c_2b_3e_24s199445780x454385136_lam0(V self, V *args);
V g_co_2e_3c_2b_3e_24s199445780x454385136_lam1(V self, V *args);
Clo g_co_2e_3c_2b_3e_24s199445780x454385136_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s199445780x454385136_entry, 1, 0};

V g_co_2e_3c_2b_3e_24s199445780x454385136(V v_h_240) {
top: ;
  V v_hfmap_241 = heff_take_field(v_h_240, 0);
  V v_hmap_242 = heff_get_n(v_h_240, 1, 2);
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s199445780x454385136_lam0, 3, 1, (V[]){v_hfmap_241}), heff_clo_n(g_co_2e_3c_2b_3e_24s199445780x454385136_lam1, 4, 1, (V[]){v_hmap_242})});
}
V g_co_2e_3c_2b_3e_24s199445780x454385136_entry(V self, V *a) {
  (void)self;
  return g_co_2e_3c_2b_3e_24s199445780x454385136(a[0]);
}
V g_co_2e_3c_2b_3e_24s199445780x454385136_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_g_244 = args[1];
  V v_p_245 = args[2];
  V v_hfmap_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_InL: {
    V v_x_246 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InL = heff_take_reuse_n(v_p_245, 1ULL, 1);
    V v_t_247 = heff_tr(heff_call(v_hfmap_241, 3, (V[]){v_m_243, v_g_244, v_x_246}));
    return heff_tag_at_n(v_ru_24p_245_24InL, TAG_InL, 1, (V[]){v_t_247});
  }
  case TAG_InR: {
    V v_y_248 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InR = heff_take_reuse_n(v_p_245, 1ULL, 1);
    heff_drop(v_hfmap_241);
    V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2ereactor_2ereactor_get(), 0)), 3, (V[]){v_m_243, v_g_244, v_y_248}));
    return heff_tag_at_n(v_ru_24p_245_24InR, TAG_InR, 1, (V[]){v_t_249});
  }
  default: return heff_nomatch(v_p_245);
  }
}
V g_co_2e_3c_2b_3e_24s199445780x454385136_lam1(V self, V *args) {
  V v_m_2410 = args[0];
  V v_n_2411 = args[1];
  V v_nt_2412 = args[2];
  V v_p_2413 = args[3];
  V v_hmap_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2413)) {
  case TAG_InL: {
    V v_x_2414 = heff_field(v_p_2413, 0);
    V v_ru_24p_2413_24InL = heff_take_reuse_n(v_p_2413, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(v_hmap_242, 4, (V[]){v_m_2410, v_n_2411, v_nt_2412, v_x_2414}));
    return heff_tag_at_n(v_ru_24p_2413_24InL, TAG_InL, 1, (V[]){v_t_2415});
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_2413, 0);
    V v_ru_24p_2413_24InR = heff_take_reuse_n(v_p_2413, 1ULL, 1);
    heff_drop(v_m_2410);
    heff_drop(v_n_2411);
    heff_drop(v_nt_2412);
    heff_drop(v_hmap_242);
    return heff_tag_at_n(v_ru_24p_2413_24InR, TAG_InR, 1, (V[]){v_y_2416});
  }
  default: return heff_nomatch(v_p_2413);
  }
}
V g_co_2e_3c_2b_3e_24s191044587x696072828_lam0(V self, V *args);
V g_co_2e_3c_2b_3e_24s191044587x696072828_lam1(V self, V *args);
Clo g_co_2e_3c_2b_3e_24s191044587x696072828_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s191044587x696072828_entry, 1, 0};

V g_co_2e_3c_2b_3e_24s191044587x696072828(V v_h_240) {
top: ;
  V v_hfmap_241 = heff_take_field(v_h_240, 0);
  V v_hmap_242 = heff_get_n(v_h_240, 1, 2);
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s191044587x696072828_lam0, 3, 1, (V[]){v_hfmap_241}), heff_clo_n(g_co_2e_3c_2b_3e_24s191044587x696072828_lam1, 4, 1, (V[]){v_hmap_242})});
}
V g_co_2e_3c_2b_3e_24s191044587x696072828_entry(V self, V *a) {
  (void)self;
  return g_co_2e_3c_2b_3e_24s191044587x696072828(a[0]);
}
V g_co_2e_3c_2b_3e_24s191044587x696072828_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_g_244 = args[1];
  V v_p_245 = args[2];
  V v_hfmap_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_InL: {
    V v_x_246 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InL = heff_take_reuse_n(v_p_245, 1ULL, 1);
    V v_t_247 = heff_tr(heff_call(v_hfmap_241, 3, (V[]){v_m_243, v_g_244, v_x_246}));
    return heff_tag_at_n(v_ru_24p_245_24InL, TAG_InL, 1, (V[]){v_t_247});
  }
  case TAG_InR: {
    V v_y_248 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InR = heff_take_reuse_n(v_p_245, 1ULL, 1);
    heff_drop(v_hfmap_241);
    V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2enet_2enet_get(), 0)), 3, (V[]){v_m_243, v_g_244, v_y_248}));
    return heff_tag_at_n(v_ru_24p_245_24InR, TAG_InR, 1, (V[]){v_t_249});
  }
  default: return heff_nomatch(v_p_245);
  }
}
V g_co_2e_3c_2b_3e_24s191044587x696072828_lam1(V self, V *args) {
  V v_m_2410 = args[0];
  V v_n_2411 = args[1];
  V v_nt_2412 = args[2];
  V v_p_2413 = args[3];
  V v_hmap_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2413)) {
  case TAG_InL: {
    V v_x_2414 = heff_field(v_p_2413, 0);
    V v_ru_24p_2413_24InL = heff_take_reuse_n(v_p_2413, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(v_hmap_242, 4, (V[]){v_m_2410, v_n_2411, v_nt_2412, v_x_2414}));
    return heff_tag_at_n(v_ru_24p_2413_24InL, TAG_InL, 1, (V[]){v_t_2415});
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_2413, 0);
    V v_ru_24p_2413_24InR = heff_take_reuse_n(v_p_2413, 1ULL, 1);
    heff_drop(v_m_2410);
    heff_drop(v_n_2411);
    heff_drop(v_nt_2412);
    heff_drop(v_hmap_242);
    return heff_tag_at_n(v_ru_24p_2413_24InR, TAG_InR, 1, (V[]){v_y_2416});
  }
  default: return heff_nomatch(v_p_2413);
  }
}
V g_co_2e_3c_2b_3e_24s219000013x892923660_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s219000013x892923660_lam2(V self, V *args);
V g_co_2e_3c_2b_3e_24s219000013x892923660_lam0(V self, V *args);
V g_co_2e_3c_2b_3e_24s219000013x892923660_lam3(V self, V *args);
Clo g_co_2e_3c_2b_3e_24s219000013x892923660_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s219000013x892923660_entry, 1, 0};

V g_co_2e_3c_2b_3e_24s219000013x892923660(V v_h_240) {
top: ;
  V v_hfmap_241 = heff_take_field(v_h_240, 0);
  V v_hmap_242 = heff_get_n(v_h_240, 1, 2);
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s219000013x892923660_lam0, 3, 1, (V[]){v_hfmap_241}), heff_clo_n(g_co_2e_3c_2b_3e_24s219000013x892923660_lam3, 4, 1, (V[]){v_hmap_242})});
}
V g_co_2e_3c_2b_3e_24s219000013x892923660_entry(V self, V *a) {
  (void)self;
  return g_co_2e_3c_2b_3e_24s219000013x892923660(a[0]);
}
V g_co_2e_3c_2b_3e_24s219000013x892923660_lam1(V self, V *args) {
  V v_t_2413 = args[0];
  V v_k_2412 = heff_env(self)[0];
  V v_g_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_k_2412, 1, (V[]){v_t_2413}));
  V f_ = v_g_244;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s219000013x892923660_lam2(V self, V *args) {
  V v_t_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_g_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_t_2416}));
  V f_ = v_g_244;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s219000013x892923660_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_g_244 = args[1];
  V v_p_245 = args[2];
  V v_hfmap_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_InL: {
    V v_x_246 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InL = heff_take_reuse_n(v_p_245, 1ULL, 1);
    V v_t_247 = heff_tr(heff_call(v_hfmap_241, 3, (V[]){v_m_243, v_g_244, v_x_246}));
    return heff_tag_at_n(v_ru_24p_245_24InL, TAG_InL, 1, (V[]){v_t_247});
  }
  case TAG_InR: {
    V v_y_248 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InR = heff_take_reuse_n(v_p_245, 1ULL, 1);
    heff_drop(v_m_243);
    heff_drop(v_hfmap_241);
    V v_t_2418;
    switch (heff_tag_of(v_y_248)) {
    case TAG_Sleep: {
      V v_ms_249 = heff_field(v_y_248, 0);
      V v_x_2410 = heff_field(v_y_248, 1);
      V v_ru_24y_248_24Sleep = heff_take_reuse_n(v_y_248, 3ULL, 2);
      V v_t_2411 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_2410}));
      v_t_2418 = heff_tag_at_n(v_ru_24y_248_24Sleep, TAG_Sleep, 2, (V[]){v_ms_249, v_t_2411});
      break;
    }
    case TAG_Now: {
      V v_k_2412 = heff_field(v_y_248, 0);
      V v_ru_24y_248_24Now = heff_take_reuse_n(v_y_248, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24y_248_24Now, TAG_Now, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s219000013x892923660_lam1, 1, 2, (V[]){v_k_2412, v_g_244})});
      break;
    }
    case TAG_Monotonic: {
      V v_k_2415 = heff_field(v_y_248, 0);
      V v_ru_24y_248_24Monotonic = heff_take_reuse_n(v_y_248, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24y_248_24Monotonic, TAG_Monotonic, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s219000013x892923660_lam2, 1, 2, (V[]){v_k_2415, v_g_244})});
      break;
    }
    default: heff_nomatch(v_y_248);
    }
    return heff_tag_at_n(v_ru_24p_245_24InR, TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_245);
  }
}
V g_co_2e_3c_2b_3e_24s219000013x892923660_lam3(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  V v_hmap_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2422)) {
  case TAG_InL: {
    V v_x_2423 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InL = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    V v_t_2424 = heff_tr(heff_call(v_hmap_242, 4, (V[]){v_m_2419, v_n_2420, v_nt_2421, v_x_2423}));
    return heff_tag_at_n(v_ru_24p_2422_24InL, TAG_InL, 1, (V[]){v_t_2424});
  }
  case TAG_InR: {
    V v_y_2425 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InR = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_m_2419);
    heff_drop(v_n_2420);
    heff_drop(v_nt_2421);
    heff_drop(v_hmap_242);
    return heff_tag_at_n(v_ru_24p_2422_24InR, TAG_InR, 1, (V[]){v_y_2425});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_co_2e_3c_2b_3e_24s1267745919x482036999_lam0(V self, V *args);
V g_co_2e_3c_2b_3e_24s1267745919x482036999_lam1(V self, V *args);
Clo g_co_2e_3c_2b_3e_24s1267745919x482036999_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1267745919x482036999_entry, 1, 0};

V g_co_2e_3c_2b_3e_24s1267745919x482036999(V v_h_240) {
top: ;
  V v_hfmap_241 = heff_take_field(v_h_240, 0);
  V v_hmap_242 = heff_get_n(v_h_240, 1, 2);
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1267745919x482036999_lam0, 3, 1, (V[]){v_hfmap_241}), heff_clo_n(g_co_2e_3c_2b_3e_24s1267745919x482036999_lam1, 4, 1, (V[]){v_hmap_242})});
}
V g_co_2e_3c_2b_3e_24s1267745919x482036999_entry(V self, V *a) {
  (void)self;
  return g_co_2e_3c_2b_3e_24s1267745919x482036999(a[0]);
}
V g_co_2e_3c_2b_3e_24s1267745919x482036999_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_g_244 = args[1];
  V v_p_245 = args[2];
  V v_hfmap_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_InL: {
    V v_x_246 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InL = heff_take_reuse_n(v_p_245, 1ULL, 1);
    V v_t_247 = heff_tr(heff_call(v_hfmap_241, 3, (V[]){v_m_243, v_g_244, v_x_246}));
    return heff_tag_at_n(v_ru_24p_245_24InL, TAG_InL, 1, (V[]){v_t_247});
  }
  case TAG_InR: {
    V v_y_248 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InR = heff_take_reuse_n(v_p_245, 1ULL, 1);
    heff_drop(v_hfmap_241);
    V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eterminal_2econsole_get(), 0)), 3, (V[]){v_m_243, v_g_244, v_y_248}));
    return heff_tag_at_n(v_ru_24p_245_24InR, TAG_InR, 1, (V[]){v_t_249});
  }
  default: return heff_nomatch(v_p_245);
  }
}
V g_co_2e_3c_2b_3e_24s1267745919x482036999_lam1(V self, V *args) {
  V v_m_2410 = args[0];
  V v_n_2411 = args[1];
  V v_nt_2412 = args[2];
  V v_p_2413 = args[3];
  V v_hmap_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2413)) {
  case TAG_InL: {
    V v_x_2414 = heff_field(v_p_2413, 0);
    V v_ru_24p_2413_24InL = heff_take_reuse_n(v_p_2413, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(v_hmap_242, 4, (V[]){v_m_2410, v_n_2411, v_nt_2412, v_x_2414}));
    return heff_tag_at_n(v_ru_24p_2413_24InL, TAG_InL, 1, (V[]){v_t_2415});
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_2413, 0);
    V v_ru_24p_2413_24InR = heff_take_reuse_n(v_p_2413, 1ULL, 1);
    heff_drop(v_m_2410);
    heff_drop(v_n_2411);
    heff_drop(v_nt_2412);
    heff_drop(v_hmap_242);
    return heff_tag_at_n(v_ru_24p_2413_24InR, TAG_InR, 1, (V[]){v_y_2416});
  }
  default: return heff_nomatch(v_p_2413);
  }
}
V g_co_2e_3c_2b_3e_24s1611985049x766020670_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s1611985049x766020670_lam2(V self, V *args);
V g_co_2e_3c_2b_3e_24s1611985049x766020670_lam0(V self, V *args);
V g_co_2e_3c_2b_3e_24s1611985049x766020670_lam3(V self, V *args);
Clo g_co_2e_3c_2b_3e_24s1611985049x766020670_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1611985049x766020670_entry, 1, 0};

V g_co_2e_3c_2b_3e_24s1611985049x766020670(V v_h_240) {
top: ;
  V v_hfmap_241 = heff_take_field(v_h_240, 0);
  V v_hmap_242 = heff_get_n(v_h_240, 1, 2);
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1611985049x766020670_lam0, 3, 1, (V[]){v_hfmap_241}), heff_clo_n(g_co_2e_3c_2b_3e_24s1611985049x766020670_lam3, 4, 1, (V[]){v_hmap_242})});
}
V g_co_2e_3c_2b_3e_24s1611985049x766020670_entry(V self, V *a) {
  (void)self;
  return g_co_2e_3c_2b_3e_24s1611985049x766020670(a[0]);
}
V g_co_2e_3c_2b_3e_24s1611985049x766020670_lam1(V self, V *args) {
  V v_b_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_g_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_tr(heff_call(v_k_249, 1, (V[]){v_b_2410}));
  V f_ = v_g_244;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1611985049x766020670_lam2(V self, V *args) {
  V v_r_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_g_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tr(heff_call(v_k_2418, 1, (V[]){v_r_2419}));
  V f_ = v_g_244;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1611985049x766020670_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_g_244 = args[1];
  V v_p_245 = args[2];
  V v_hfmap_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_InL: {
    V v_x_246 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InL = heff_take_reuse_n(v_p_245, 1ULL, 1);
    V v_t_247 = heff_tr(heff_call(v_hfmap_241, 3, (V[]){v_m_243, v_g_244, v_x_246}));
    return heff_tag_at_n(v_ru_24p_245_24InL, TAG_InL, 1, (V[]){v_t_247});
  }
  case TAG_InR: {
    V v_y_248 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InR = heff_take_reuse_n(v_p_245, 1ULL, 1);
    heff_drop(v_m_243);
    heff_drop(v_hfmap_241);
    V v_t_2421;
    switch (heff_tag_of(v_y_248)) {
    case TAG_IsTerminal: {
      V v_k_249 = heff_field(v_y_248, 0);
      V v_ru_24y_248_24IsTerminal = heff_take_reuse_n(v_y_248, 1ULL, 1);
      v_t_2421 = heff_tag_at_n(v_ru_24y_248_24IsTerminal, TAG_IsTerminal, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1611985049x766020670_lam1, 1, 2, (V[]){v_k_249, v_g_244})});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_2412 = heff_field(v_y_248, 0);
      V v_x_2413 = heff_field(v_y_248, 1);
      V v_ru_24y_248_24ShowLines = heff_take_reuse_n(v_y_248, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_2413}));
      v_t_2421 = heff_tag_at_n(v_ru_24y_248_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2412, v_t_2414});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2415 = heff_field(v_y_248, 0);
      V v_argv_2416 = heff_field(v_y_248, 1);
      V v_lines_2417 = heff_field(v_y_248, 2);
      V v_k_2418 = heff_field(v_y_248, 3);
      V v_ru_24y_248_24ShowRun = heff_take_reuse_n(v_y_248, 15ULL, 4);
      v_t_2421 = heff_tag_at_n(v_ru_24y_248_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2415, v_argv_2416, v_lines_2417, heff_clo_n(g_co_2e_3c_2b_3e_24s1611985049x766020670_lam2, 1, 2, (V[]){v_k_2418, v_g_244})});
      break;
    }
    default: heff_nomatch(v_y_248);
    }
    return heff_tag_at_n(v_ru_24p_245_24InR, TAG_InR, 1, (V[]){v_t_2421});
  }
  default: return heff_nomatch(v_p_245);
  }
}
V g_co_2e_3c_2b_3e_24s1611985049x766020670_lam3(V self, V *args) {
  V v_m_2422 = args[0];
  V v_n_2423 = args[1];
  V v_nt_2424 = args[2];
  V v_p_2425 = args[3];
  V v_hmap_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2425)) {
  case TAG_InL: {
    V v_x_2426 = heff_field(v_p_2425, 0);
    V v_ru_24p_2425_24InL = heff_take_reuse_n(v_p_2425, 1ULL, 1);
    V v_t_2427 = heff_tr(heff_call(v_hmap_242, 4, (V[]){v_m_2422, v_n_2423, v_nt_2424, v_x_2426}));
    return heff_tag_at_n(v_ru_24p_2425_24InL, TAG_InL, 1, (V[]){v_t_2427});
  }
  case TAG_InR: {
    V v_y_2428 = heff_field(v_p_2425, 0);
    V v_ru_24p_2425_24InR = heff_take_reuse_n(v_p_2425, 1ULL, 1);
    heff_drop(v_m_2422);
    heff_drop(v_n_2423);
    heff_drop(v_nt_2424);
    heff_drop(v_hmap_242);
    return heff_tag_at_n(v_ru_24p_2425_24InR, TAG_InR, 1, (V[]){v_y_2428});
  }
  default: return heff_nomatch(v_p_2425);
  }
}
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam2(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam2, 4, 0};

static V g_co_2e_3c_2b_3e_24s1037294805x1491904357_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1037294805x1491904357_st;
static V g_co_2e_3c_2b_3e_24s1037294805x1491904357_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam2_clo)});
}
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1037294805x1491904357_st)) return g_co_2e_3c_2b_3e_24s1037294805x1491904357_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1037294805x1491904357_val, &g_co_2e_3c_2b_3e_24s1037294805x1491904357_st, g_co_2e_3c_2b_3e_24s1037294805x1491904357_init);
}
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_s_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_m_240);
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Write: {
      V v_str_244 = heff_field(v_x_243, 0);
      V v_x_245 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Write = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_245}));
      v_t_2415 = heff_tag_at_n(v_ru_24x_243_24Write, TAG_Write, 2, (V[]){v_str_244, v_t_246});
      break;
    }
    case TAG_WriteErr: {
      V v_str_247 = heff_field(v_x_243, 0);
      V v_x_248 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24WriteErr = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_249 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_248}));
      v_t_2415 = heff_tag_at_n(v_ru_24x_243_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_247, v_t_249});
      break;
    }
    case TAG_ReadStdin: {
      V v_k_2410 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24ReadStdin = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2415 = heff_tag_at_n(v_ru_24x_243_24ReadStdin, TAG_ReadStdin, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam1, 1, 2, (V[]){v_k_2410, v_g_241})});
      break;
    }
    case TAG_Flush: {
      V v_x_2413 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Flush = heff_take_reuse_n(v_x_243, 1ULL, 1);
      V v_t_2414 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2413}));
      v_t_2415 = heff_tag_at_n(v_ru_24x_243_24Flush, TAG_Flush, 1, (V[]){v_t_2414});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2415});
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprocess_2eprocess_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2416}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2417});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam2(V self, V *args) {
  V v_m_2418 = args[0];
  V v_n_2419 = args[1];
  V v_nt_2420 = args[2];
  V v_p_2421 = args[3];
  heff_drop(v_m_2418);
  heff_drop(v_n_2419);
  heff_drop(v_nt_2420);
  return v_p_2421;
}
V g_co_2e_3c_2b_3e_24s1419042510x1098087825_lam0(V self, V *args);
V g_co_2e_3c_2b_3e_24s1419042510x1098087825_lam1(V self, V *args);
Clo g_co_2e_3c_2b_3e_24s1419042510x1098087825_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1419042510x1098087825_entry, 1, 0};

V g_co_2e_3c_2b_3e_24s1419042510x1098087825(V v_k_240) {
top: ;
  V v_hfmap_241 = heff_take_field(v_k_240, 0);
  V v_hmap_242 = heff_get_n(v_k_240, 1, 2);
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1419042510x1098087825_lam0, 3, 1, (V[]){v_hfmap_241}), heff_clo_n(g_co_2e_3c_2b_3e_24s1419042510x1098087825_lam1, 4, 1, (V[]){v_hmap_242})});
}
V g_co_2e_3c_2b_3e_24s1419042510x1098087825_entry(V self, V *a) {
  (void)self;
  return g_co_2e_3c_2b_3e_24s1419042510x1098087825(a[0]);
}
V g_co_2e_3c_2b_3e_24s1419042510x1098087825_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_g_244 = args[1];
  V v_p_245 = args[2];
  V v_hfmap_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_245)) {
  case TAG_InL: {
    V v_x_246 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InL = heff_take_reuse_n(v_p_245, 1ULL, 1);
    heff_drop(v_hfmap_241);
    V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprogress_2eprogress_get(), 0)), 3, (V[]){v_m_243, v_g_244, v_x_246}));
    return heff_tag_at_n(v_ru_24p_245_24InL, TAG_InL, 1, (V[]){v_t_247});
  }
  case TAG_InR: {
    V v_y_248 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InR = heff_take_reuse_n(v_p_245, 1ULL, 1);
    V v_t_249 = heff_tr(heff_call(v_hfmap_241, 3, (V[]){v_m_243, v_g_244, v_y_248}));
    return heff_tag_at_n(v_ru_24p_245_24InR, TAG_InR, 1, (V[]){v_t_249});
  }
  default: return heff_nomatch(v_p_245);
  }
}
V g_co_2e_3c_2b_3e_24s1419042510x1098087825_lam1(V self, V *args) {
  V v_m_2410 = args[0];
  V v_n_2411 = args[1];
  V v_nt_2412 = args[2];
  V v_p_2413 = args[3];
  V v_hmap_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2413)) {
  case TAG_InL: {
    V v_x_2414 = heff_field(v_p_2413, 0);
    V v_ru_24p_2413_24InL = heff_take_reuse_n(v_p_2413, 1ULL, 1);
    heff_drop(v_m_2410);
    heff_drop(v_n_2411);
    heff_drop(v_nt_2412);
    heff_drop(v_hmap_242);
    return heff_tag_at_n(v_ru_24p_2413_24InL, TAG_InL, 1, (V[]){v_x_2414});
  }
  case TAG_InR: {
    V v_y_2415 = heff_field(v_p_2413, 0);
    V v_ru_24p_2413_24InR = heff_take_reuse_n(v_p_2413, 1ULL, 1);
    V v_t_2416 = heff_tr(heff_call(v_hmap_242, 4, (V[]){v_m_2410, v_n_2411, v_nt_2412, v_y_2415}));
    return heff_tag_at_n(v_ru_24p_2413_24InR, TAG_InR, 1, (V[]){v_t_2416});
  }
  default: return heff_nomatch(v_p_2413);
  }
}
V g_co_2eop_24s1701369613x1410211592_lam1(V self, V *args);
V g_co_2eop_24s1701369613x1410211592_lam0(V self, V *args); static Clo g_co_2eop_24s1701369613x1410211592_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1701369613x1410211592_lam0, 4, 0};
V g_co_2eop_24s1701369613x1410211592_lam3(V self, V *args);
V g_co_2eop_24s1701369613x1410211592_lam2(V self, V *args); static Clo g_co_2eop_24s1701369613x1410211592_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1701369613x1410211592_lam2, 4, 0};
V g_co_2eop_24s1701369613x1410211592_lam5(V self, V *args); static Clo g_co_2eop_24s1701369613x1410211592_lam5_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1701369613x1410211592_lam5, 3, 0};
V g_co_2eop_24s1701369613x1410211592_lam4(V self, V *args);
V g_co_2eop_24s1701369613x1410211592_lam7(V self, V *args);
V g_co_2eop_24s1701369613x1410211592_lam6(V self, V *args);
Clo g_co_2eop_24s1701369613x1410211592_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1701369613x1410211592_entry, 4, 0};

V g_co_2eop_24s1701369613x1410211592(V v_lit_240, V v_h_241, V v_p_242, V v_k2_243) {
top: ;
  V v_t_244 = (g_exception_2eattempted(heff_dup(v_lit_240)));
  V v_t_2424 = heff_tr(heff_call(heff_get_n(v_h_241, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1701369613x1410211592_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1701369613x1410211592_lam2_clo)}), heff_clo_n(g_co_2eop_24s1701369613x1410211592_lam4, 1, 1, (V[]){v_lit_240}), v_p_242}));
  V v_m_2425 = heff_tr(heff_call(heff_get_n(v_t_244, 2, 3), 1, (V[]){v_t_2424}));
  return heff_clo_n(g_co_2eop_24s1701369613x1410211592_lam6, 2, 2, (V[]){v_m_2425, v_k2_243});
}
V g_co_2eop_24s1701369613x1410211592_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1701369613x1410211592(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s1701369613x1410211592_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1701369613x1410211592_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_24s1701369613x1410211592_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1701369613x1410211592_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  V v_g_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_x_2416 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    heff_drop(v_g_2411);
    V f_ = v_k_2414;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_2416});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2417 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    V v_x_2418 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_y_2417}));
    V f_ = v_k_2414;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2418});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_co_2eop_24s1701369613x1410211592_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_2413 = args[2];
  V v_k_2414 = args[3];
  V f_ = v_m_2412;
  args[0] = v_hd_2413;
  args[1] = heff_clo_n(g_co_2eop_24s1701369613x1410211592_lam3, 1, 2, (V[]){v_k_2414, v_g_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1701369613x1410211592_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2422 = args[1];
  V v_k_2423 = args[2];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1701369613x1410211592_lam4(V self, V *args) {
  V v_c_2419 = args[0];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420 = (g_exception_2eattempted(v_lit_240));
  V f_ = v_c_2419;
  heff_room[0] = v_t_2420;
  heff_room[1] = ((V)&g_co_2eop_24s1701369613x1410211592_lam5_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1701369613x1410211592_lam7(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2427 = heff_env(self)[0];
  V v_k2_243 = heff_env(self)[1];
  V v_hd_2426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2428)) {
  case TAG_Left: {
    V v_x_2429 = heff_field(v_x_2428, 0);
    heff_take_n(v_x_2428, 1ULL, 1);
    heff_drop(v_k2_243);
    heff_drop(v_hd_2426);
    V f_ = v_k_2427;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_2429});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2430 = heff_field(v_x_2428, 0);
    heff_take_n(v_x_2428, 1ULL, 1);
    V f_ = v_k2_243;
    heff_room[0] = v_y_2430;
    heff_room[1] = v_hd_2426;
    heff_room[2] = v_k_2427;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x_2428);
  }
}
V g_co_2eop_24s1701369613x1410211592_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_m_2425 = heff_env(self)[0];
  V v_k2_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_m_2425;
  args[0] = heff_dup(v_hd_2426);
  args[1] = heff_clo_n(g_co_2eop_24s1701369613x1410211592_lam7, 1, 3, (V[]){v_k_2427, v_k2_243, v_hd_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s942716005x1337691863_lam1(V self, V *args);
V g_co_2eop_24s942716005x1337691863_lam0(V self, V *args); static Clo g_co_2eop_24s942716005x1337691863_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s942716005x1337691863_lam0, 4, 0};
V g_co_2eop_24s942716005x1337691863_lam3(V self, V *args);
V g_co_2eop_24s942716005x1337691863_lam2(V self, V *args);
V g_co_2eop_24s942716005x1337691863_lam4(V self, V *args);
Clo g_co_2eop_24s942716005x1337691863_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s942716005x1337691863_entry, 4, 0};

V g_co_2eop_24s942716005x1337691863(V v_lit_240, V v_lit_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_lit_240})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_t_2421 = heff_tr(heff_call(heff_get_n(v_lit_241, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s942716005x1337691863_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s942716005x1337691863_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s942716005x1337691863_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_t_249}));
  V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2422, v_k2_243});
}
V g_co_2eop_24s942716005x1337691863_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s942716005x1337691863(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s942716005x1337691863_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2415 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2414}));
  V f_ = v_k_2413;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s942716005x1337691863_lam0(V self, V *args) {
  V v_g_2410 = args[0];
  V v_c_2411 = args[1];
  V v_hd_2412 = args[2];
  V v_k_2413 = args[3];
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_co_2eop_24s942716005x1337691863_lam1, 1, 2, (V[]){v_g_2410, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s942716005x1337691863_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_2416 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_g_2416, 1, (V[]){v_x_2418}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s942716005x1337691863_lam2(V self, V *args) {
  V v_g_2416 = args[0];
  V v_m_2417 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2417;
  args[1] = heff_clo_n(g_co_2eop_24s942716005x1337691863_lam3, 1, 2, (V[]){v_g_2416, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s942716005x1337691863_lam4(V self, V *args) {
  V v_c_2420 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s199044798x1745934964_lam1(V self, V *args);
V g_co_2eop_24s199044798x1745934964_lam0(V self, V *args); static Clo g_co_2eop_24s199044798x1745934964_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s199044798x1745934964_lam0, 4, 0};
V g_co_2eop_24s199044798x1745934964_lam3(V self, V *args);
V g_co_2eop_24s199044798x1745934964_lam2(V self, V *args);
V g_co_2eop_24s199044798x1745934964_lam4(V self, V *args);
Clo g_co_2eop_24s199044798x1745934964_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s199044798x1745934964_entry, 4, 0};

V g_co_2eop_24s199044798x1745934964(V v_lit_240, V v_lit_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_lit_240})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_t_2421 = heff_tr(heff_call(heff_get_n(v_lit_241, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s199044798x1745934964_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s199044798x1745934964_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s199044798x1745934964_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_t_249}));
  V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2422, v_k2_243});
}
V g_co_2eop_24s199044798x1745934964_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s199044798x1745934964(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s199044798x1745934964_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2415 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2414}));
  V f_ = v_k_2413;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s199044798x1745934964_lam0(V self, V *args) {
  V v_g_2410 = args[0];
  V v_c_2411 = args[1];
  V v_hd_2412 = args[2];
  V v_k_2413 = args[3];
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_co_2eop_24s199044798x1745934964_lam1, 1, 2, (V[]){v_g_2410, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s199044798x1745934964_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_2416 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_g_2416, 1, (V[]){v_x_2418}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s199044798x1745934964_lam2(V self, V *args) {
  V v_g_2416 = args[0];
  V v_m_2417 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2417;
  args[1] = heff_clo_n(g_co_2eop_24s199044798x1745934964_lam3, 1, 2, (V[]){v_g_2416, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s199044798x1745934964_lam4(V self, V *args) {
  V v_c_2420 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}