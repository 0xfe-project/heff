// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Asked 63168
#define TAG_Await 41810
#define TAG_Catch 6517
#define TAG_Current 21643
#define TAG_Dropped 56062
#define TAG_ErrColor 60683
#define TAG_Failed 62128
#define TAG_Flush 26516
#define TAG_Get 18914
#define TAG_Given 9359
#define TAG_IsTerminal 53507
#define TAG_Kept 49931
#define TAG_Left 13886
#define TAG_Log 24016
#define TAG_Made 39756
#define TAG_Managed 63889
#define TAG_MkChk 56962
#define TAG_MkRunning 3887
#define TAG_MkSt 48854
#define TAG_Monotonic 64960
#define TAG_Now 25954
#define TAG_Own 27154
#define TAG_ReadStdin 20528
#define TAG_Right 62770
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_ShutDown 12133
#define TAG_Sleep 25229
#define TAG_Throw 56084
#define TAG_Under 30640
#define TAG_UseColor 15915
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_bind 9519364
#define LBL_fmap 9641981
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_ret 322331
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244(V, V, V, V, V, V, V, V);
V g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244_clo;
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_get(void);
V g_co_2e_3c_2b_3e_24s1505336972x898038096_get(void);
V g_co_2e_3c_2b_3e_24s1509353391x420518254_get(void);
V g_co_2e_3c_2b_3e_24s1859862955x829236210_get(void);
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(void);
V g_co_2e_3c_2b_3e_24s269173423x1350998206_get(void);
V g_co_2e_3c_2b_3e_24s705698573x957367565_get(void);
V g_co_2ebind_24s1421083649x484987773(V, V, V, V);
V g_co_2ebind_24s1421083649x484987773_entry(V self, V *a);
extern Clo g_co_2ebind_24s1421083649x484987773_clo;
V g_co_2ebind_24s1464300710x102529052(V, V, V);
V g_co_2ebind_24s1464300710x102529052_entry(V self, V *a);
extern Clo g_co_2ebind_24s1464300710x102529052_clo;
V g_co_2ebind_24s1831149655x1541910000(V, V, V);
V g_co_2ebind_24s1831149655x1541910000_entry(V self, V *a);
extern Clo g_co_2ebind_24s1831149655x1541910000_clo;
V g_co_2ebind_24s196996678x1811735276(V, V, V);
V g_co_2ebind_24s196996678x1811735276_entry(V self, V *a);
extern Clo g_co_2ebind_24s196996678x1811735276_clo;
V g_co_2ebind_24s491334399x268717303(V, V);
V g_co_2ebind_24s491334399x268717303_entry(V self, V *a);
extern Clo g_co_2ebind_24s491334399x268717303_clo;
V g_co_2eop_24s1014403878x489449937(V, V, V, V, V);
V g_co_2eop_24s1014403878x489449937_entry(V self, V *a);
extern Clo g_co_2eop_24s1014403878x489449937_clo;
V g_co_2eop_24s1314008918x267595320(V, V, V);
V g_co_2eop_24s1314008918x267595320_entry(V self, V *a);
extern Clo g_co_2eop_24s1314008918x267595320_clo;
V g_co_2eop_24s1412293101x300983667(V, V, V);
V g_co_2eop_24s1412293101x300983667_entry(V self, V *a);
extern Clo g_co_2eop_24s1412293101x300983667_clo;
V g_co_2eop_24s1525053243x1115082286(V, V, V, V, V);
V g_co_2eop_24s1525053243x1115082286_entry(V self, V *a);
extern Clo g_co_2eop_24s1525053243x1115082286_clo;
V g_co_2eop_24s1673054648x994021533(V, V, V);
V g_co_2eop_24s1673054648x994021533_entry(V self, V *a);
extern Clo g_co_2eop_24s1673054648x994021533_clo;
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s197845728x1944963205(V, V, V);
V g_co_2eop_24s197845728x1944963205_entry(V self, V *a);
extern Clo g_co_2eop_24s197845728x1944963205_clo;
V g_co_2eop_24s2022167152x294629972(V, V, V);
V g_co_2eop_24s2022167152x294629972_entry(V self, V *a);
extern Clo g_co_2eop_24s2022167152x294629972_clo;
V g_co_2eop_24s2022167152x294629972_24rec0_get(void);
V g_co_2eop_24s204600452x2025369236(V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s204600452x2025369236_entry(V self, V *a);
extern Clo g_co_2eop_24s204600452x2025369236_clo;
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_co_2eop_24s582347324x1305505939(V, V, V, V);
V g_co_2eop_24s582347324x1305505939_entry(V self, V *a);
extern Clo g_co_2eop_24s582347324x1305505939_clo;
V g_co_2eop_24s677923597x1834241003(V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s677923597x1834241003_entry(V self, V *a);
extern Clo g_co_2eop_24s677923597x1834241003_clo;
V g_co_2eop_24s774411652x2032095250(V, V, V, V, V, V, V, V);
V g_co_2eop_24s774411652x2032095250_entry(V self, V *a);
extern Clo g_co_2eop_24s774411652x2032095250_clo;
V g_co_2eop_24s973071017x1608150717(V);
V g_co_2eop_24s973071017x1608150717_entry(V self, V *a);
extern Clo g_co_2eop_24s973071017x1608150717_clo;
V g_co_2eop_24s973071017x1608150717_24rec0_get(void);
V g_co_2eop_24s981909385x709882350(V, V, V, V, V);
V g_co_2eop_24s981909385x709882350_entry(V self, V *a);
extern Clo g_co_2eop_24s981909385x709882350_clo;
V g_exception_2eattempted_24s588401679x1225922520_get(void);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2erules_2erecovering(V);
V g_heff_2eelab_2erules_2erecovering_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecovering_clo;
HeffT2 g_heff_2elsp_2erpc_2eeventOf_24cpr(V);
V g_heff_2elsp_2erpc_2erpc_get(void);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s410120642x105714730(V, V);
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a);
extern Clo g_list_2efoldl_24s410120642x105714730_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_std_2efilesystem_2efilesystem_get(void);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
V g_std_2eprocess_2eprocess_get(void);
V g_std_2eprogress_2eprogress_get(void);
V g_std_2ereactor_2ereactor_get(void);
V g_std_2eterminal_2econsole_get(void);
V g_co_2ebind_24s1831149655x1541910000_lam0(V self, V *args); static Clo g_co_2ebind_24s1831149655x1541910000_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1831149655x1541910000_lam0, 1, 0};
V g_co_2ebind_24s1831149655x1541910000_lam1(V self, V *args);
Clo g_co_2ebind_24s1831149655x1541910000_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1831149655x1541910000_entry, 3, 0};

V g_co_2ebind_24s1831149655x1541910000(V v_f_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_co_2ebind_24s1831149655x1541910000_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_249, heff_clo_n(g_co_2ebind_24s1831149655x1541910000_lam1, 1, 3, (V[]){v_f_240, v_hd_241, v_k_242})});
}
V g_co_2ebind_24s1831149655x1541910000_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s1831149655x1541910000(a[0], a[1], a[2]);
}
V g_co_2ebind_24s1831149655x1541910000_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_t_244 = ({ V b_0 = heff_get_n(v_c_243, 3, 9); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = (g_list_2emap_24s366344330x1145113647(v_t_244));
  V v_xs_246 = (g_list_2efoldl_24s410120642x105714730(NTAG(TAG_Nil), v_t_245));
  return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
}
V g_co_2ebind_24s1831149655x1541910000_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_f_240;
  heff_room[0] = v_x_2410;
  heff_room[1] = v_hd_241;
  heff_room[2] = v_k_242;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2ebind_24s1421083649x484987773_lam0(V self, V *args);
Clo g_co_2ebind_24s1421083649x484987773_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1421083649x484987773_entry, 4, 0};

V g_co_2ebind_24s1421083649x484987773(V v_c_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  return heff_tail(v_c_240, 2, (V[]){heff_dup(v_hd_242), heff_clo_n(g_co_2ebind_24s1421083649x484987773_lam0, 1, 3, (V[]){v_f_241, v_hd_242, v_k_243})});
}
V g_co_2ebind_24s1421083649x484987773_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s1421083649x484987773(a[0], a[1], a[2], a[3]);
}
V g_co_2ebind_24s1421083649x484987773_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_f_241;
  heff_room[0] = v_x_244;
  heff_room[1] = v_hd_242;
  heff_room[2] = v_k_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2ebind_24s196996678x1811735276_lam1(V self, V *args);
V g_co_2ebind_24s196996678x1811735276_lam0(V self, V *args);
Clo g_co_2ebind_24s196996678x1811735276_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s196996678x1811735276_entry, 3, 0};

V g_co_2ebind_24s196996678x1811735276(V v_c_240, V v_hd_241, V v_k_242) {
top: ;
  return heff_tail(v_c_240, 2, (V[]){v_hd_241, heff_clo_n(g_co_2ebind_24s196996678x1811735276_lam0, 1, 1, (V[]){v_k_242})});
}
V g_co_2ebind_24s196996678x1811735276_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s196996678x1811735276(a[0], a[1], a[2]);
}
V g_co_2ebind_24s196996678x1811735276_lam1(V self, V *args) {
  V v_a_245 = args[0];
  V v_a_246 = args[1];
  V v_a_247 = args[2];
  V v_a_248 = args[3];
  V v_a_244 = heff_env(self)[0];
  heff_drop(v_a_245);
  heff_drop(v_a_246);
  V v_malg_249 = heff_take_field(v_a_247, 2);
  V v_bind_2410 = heff_get_n(v_a_247, 1, 3);
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_a_244})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(v_malg_249, 1, (V[]){v_t_2412}));
  V f_ = v_bind_2410;
  args[0] = v_t_2413;
  args[1] = v_a_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2ebind_24s196996678x1811735276_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_k_242 = heff_env(self)[0];
  switch (heff_tag_of(v_x_243)) {
  case TAG_Left: {
    V v_a_244 = heff_field(v_x_243, 0);
    V v_ru_24x_243_24Left = heff_take_reuse_n(v_x_243, 1ULL, 1);
    V v_t_2414 = ({ V b_0 = heff_tag_at_n(v_ru_24x_243_24Left, TAG_MkChk, 1, (V[]){heff_clo_n(g_co_2ebind_24s196996678x1811735276_lam1, 4, 1, (V[]){v_a_244})}); V r_ = (g_heff_2eelab_2erules_2erecovering(b_0)); heff_drop(b_0); r_; });
    heff_clo_take(self, 1);
    V f_ = v_k_242;
    args[0] = v_t_2414;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_a_2415 = heff_field(v_x_243, 0);
    heff_take_n(v_x_243, 1ULL, 1);
    V v_t_2416 = ({ V a_0 = v_a_2415; V r_ = (g_heff_2eelab_2erules_2erecovering(a_0)); heff_drop(v_a_2415); r_; });
    heff_clo_take(self, 1);
    V f_ = v_k_242;
    args[0] = v_t_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_243);
  }
}
V g_co_2ebind_24s491334399x268717303_lam0(V self, V *args); static Clo g_co_2ebind_24s491334399x268717303_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s491334399x268717303_lam0, 2, 0};
Clo g_co_2ebind_24s491334399x268717303_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s491334399x268717303_entry, 2, 0};

V g_co_2ebind_24s491334399x268717303(V v_f_240, V v_st_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_c_242 = heff_dup(heff_field(v_st_241, 0));
    v_t_245 = v_c_242;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_t_246 = ({ V b_0 = heff_get_n(v_t_245, 3, 9); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_247 = (g_list_2emap_24s366344330x1145113647(v_t_246));
  V v_xs_248 = (g_list_2efoldl_24s410120642x105714730(NTAG(TAG_Nil), v_t_247));
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
  return heff_tail(v_f_240, 4, (V[]){v_t_249, heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), ((V)&g_co_2ebind_24s491334399x268717303_lam0_clo), v_st_241});
}
V g_co_2ebind_24s491334399x268717303_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s491334399x268717303(a[0], a[1]);
}
V g_co_2ebind_24s491334399x268717303_lam0(V self, V *args) {
  V v_a_2410 = args[0];
  V v_a_2411 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2410}), v_a_2411});
}
V g_co_2ebind_24s1464300710x102529052_lam1(V self, V *args); static Clo g_co_2ebind_24s1464300710x102529052_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1464300710x102529052_lam1, 2, 0};
V g_co_2ebind_24s1464300710x102529052_lam0(V self, V *args);
Clo g_co_2ebind_24s1464300710x102529052_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1464300710x102529052_entry, 3, 0};

V g_co_2ebind_24s1464300710x102529052(V v_c_240, V v_f_241, V v_z_242) {
top: ;
  return heff_tail(v_c_240, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_co_2ebind_24s1464300710x102529052_lam0, 1, 1, (V[]){v_f_241}), v_z_242});
}
V g_co_2ebind_24s1464300710x102529052_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s1464300710x102529052(a[0], a[1], a[2]);
}
V g_co_2ebind_24s1464300710x102529052_lam1(V self, V *args) {
  V v_a_244 = args[0];
  V v_a_245 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_244}), v_a_245});
}
V g_co_2ebind_24s1464300710x102529052_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_f_241;
  heff_room[0] = v_x_243;
  heff_room[1] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[2] = ((V)&g_co_2ebind_24s1464300710x102529052_lam1_clo);
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam2(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam2, 4, 0};

static V g_co_2e_3c_2b_3e_24s1037294805x1491904357_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1037294805x1491904357_st;
static V g_co_2e_3c_2b_3e_24s1037294805x1491904357_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam2_clo)});
}
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1037294805x1491904357_st)) return g_co_2e_3c_2b_3e_24s1037294805x1491904357_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1037294805x1491904357_val, &g_co_2e_3c_2b_3e_24s1037294805x1491904357_st, g_co_2e_3c_2b_3e_24s1037294805x1491904357_init);
}
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_s_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_m_240);
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Write: {
      V v_str_244 = heff_field(v_x_243, 0);
      V v_x_245 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Write = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_245}));
      v_t_2415 = heff_tag_re_n(v_ru_24x_243_24Write, TAG_Write, 2, 1ULL, (V[]){v_str_244, v_t_246});
      break;
    }
    case TAG_WriteErr: {
      V v_str_247 = heff_field(v_x_243, 0);
      V v_x_248 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24WriteErr = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_249 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_248}));
      v_t_2415 = heff_tag_re_n(v_ru_24x_243_24WriteErr, TAG_WriteErr, 2, 1ULL, (V[]){v_str_247, v_t_249});
      break;
    }
    case TAG_ReadStdin: {
      V v_k_2410 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24ReadStdin = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2415 = heff_tag_at_n(v_ru_24x_243_24ReadStdin, TAG_ReadStdin, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam1, 1, 2, (V[]){v_k_2410, v_g_241})});
      break;
    }
    case TAG_Flush: {
      V v_x_2413 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Flush = heff_take_reuse_n(v_x_243, 1ULL, 1);
      V v_t_2414 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2413}));
      v_t_2415 = heff_tag_at_n(v_ru_24x_243_24Flush, TAG_Flush, 1, (V[]){v_t_2414});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2415});
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprocess_2eprocess_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2416}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2417});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1037294805x1491904357_lam2(V self, V *args) {
  V v_m_2418 = args[0];
  V v_n_2419 = args[1];
  V v_nt_2420 = args[2];
  V v_p_2421 = args[3];
  heff_drop(v_m_2418);
  heff_drop(v_n_2419);
  heff_drop(v_nt_2420);
  return v_p_2421;
}
V g_co_2e_3c_2b_3e_24s705698573x957367565_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s705698573x957367565_lam2(V self, V *args);
V g_co_2e_3c_2b_3e_24s705698573x957367565_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s705698573x957367565_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s705698573x957367565_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s705698573x957367565_lam3(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s705698573x957367565_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s705698573x957367565_lam3, 4, 0};

static V g_co_2e_3c_2b_3e_24s705698573x957367565_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s705698573x957367565_st;
static V g_co_2e_3c_2b_3e_24s705698573x957367565_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s705698573x957367565_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s705698573x957367565_lam3_clo)});
}
V g_co_2e_3c_2b_3e_24s705698573x957367565_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s705698573x957367565_st)) return g_co_2e_3c_2b_3e_24s705698573x957367565_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s705698573x957367565_val, &g_co_2e_3c_2b_3e_24s705698573x957367565_st, g_co_2e_3c_2b_3e_24s705698573x957367565_init);
}
V g_co_2e_3c_2b_3e_24s705698573x957367565_lam1(V self, V *args) {
  V v_b_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_b_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s705698573x957367565_lam2(V self, V *args) {
  V v_b_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_k_2413, 1, (V[]){v_b_2414}));
  V f_ = v_g_241;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s705698573x957367565_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1037294805x1491904357_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_244}));
      v_t_248 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_245});
      break;
    }
    case TAG_InR: {
      V v_y_246 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efilesystem_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_246}));
      v_t_248 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_247});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_248});
  }
  case TAG_InR: {
    V v_y_249 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_m_240);
    V v_t_2416;
    switch (heff_tag_of(v_y_249)) {
    case TAG_UseColor: {
      V v_k_2410 = heff_field(v_y_249, 0);
      V v_ru_24y_249_24UseColor = heff_take_reuse_n(v_y_249, 1ULL, 1);
      v_t_2416 = heff_tag_at_n(v_ru_24y_249_24UseColor, TAG_UseColor, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s705698573x957367565_lam1, 1, 2, (V[]){v_k_2410, v_g_241})});
      break;
    }
    case TAG_ErrColor: {
      V v_k_2413 = heff_field(v_y_249, 0);
      V v_ru_24y_249_24ErrColor = heff_take_reuse_n(v_y_249, 1ULL, 1);
      v_t_2416 = heff_tag_at_n(v_ru_24y_249_24ErrColor, TAG_ErrColor, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s705698573x957367565_lam2, 1, 2, (V[]){v_k_2413, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_249);
    }
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2416});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s705698573x957367565_lam3(V self, V *args) {
  V v_m_2417 = args[0];
  V v_n_2418 = args[1];
  V v_nt_2419 = args[2];
  V v_p_2420 = args[3];
  heff_drop(v_m_2417);
  heff_drop(v_n_2418);
  heff_drop(v_nt_2419);
  return v_p_2420;
}
V g_co_2e_3c_2b_3e_24s1859862955x829236210_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s1859862955x829236210_lam2(V self, V *args);
V g_co_2e_3c_2b_3e_24s1859862955x829236210_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1859862955x829236210_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1859862955x829236210_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1859862955x829236210_lam3(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1859862955x829236210_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1859862955x829236210_lam3, 4, 0};

static V g_co_2e_3c_2b_3e_24s1859862955x829236210_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1859862955x829236210_st;
static V g_co_2e_3c_2b_3e_24s1859862955x829236210_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1859862955x829236210_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1859862955x829236210_lam3_clo)});
}
V g_co_2e_3c_2b_3e_24s1859862955x829236210_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1859862955x829236210_st)) return g_co_2e_3c_2b_3e_24s1859862955x829236210_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1859862955x829236210_val, &g_co_2e_3c_2b_3e_24s1859862955x829236210_st, g_co_2e_3c_2b_3e_24s1859862955x829236210_init);
}
V g_co_2e_3c_2b_3e_24s1859862955x829236210_lam1(V self, V *args) {
  V v_b_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_b_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1859862955x829236210_lam2(V self, V *args) {
  V v_r_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tr(heff_call(v_k_2419, 1, (V[]){v_r_2420}));
  V f_ = v_g_241;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1859862955x829236210_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s705698573x957367565_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_244}));
      v_t_248 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_245});
      break;
    }
    case TAG_InR: {
      V v_y_246 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_246}));
      v_t_248 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_247});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_248});
  }
  case TAG_InR: {
    V v_y_249 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_m_240);
    V v_t_2422;
    switch (heff_tag_of(v_y_249)) {
    case TAG_IsTerminal: {
      V v_k_2410 = heff_field(v_y_249, 0);
      V v_ru_24y_249_24IsTerminal = heff_take_reuse_n(v_y_249, 1ULL, 1);
      v_t_2422 = heff_tag_at_n(v_ru_24y_249_24IsTerminal, TAG_IsTerminal, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1859862955x829236210_lam1, 1, 2, (V[]){v_k_2410, v_g_241})});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_2413 = heff_field(v_y_249, 0);
      V v_x_2414 = heff_field(v_y_249, 1);
      V v_ru_24y_249_24ShowLines = heff_take_reuse_n(v_y_249, 3ULL, 2);
      V v_t_2415 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2414}));
      v_t_2422 = heff_tag_re_n(v_ru_24y_249_24ShowLines, TAG_ShowLines, 2, 1ULL, (V[]){v_ls_2413, v_t_2415});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2416 = heff_field(v_y_249, 0);
      V v_argv_2417 = heff_field(v_y_249, 1);
      V v_lines_2418 = heff_field(v_y_249, 2);
      V v_k_2419 = heff_field(v_y_249, 3);
      V v_ru_24y_249_24ShowRun = heff_take_reuse_n(v_y_249, 15ULL, 4);
      v_t_2422 = heff_tag_re_n(v_ru_24y_249_24ShowRun, TAG_ShowRun, 4, 7ULL, (V[]){v_cmd_2416, v_argv_2417, v_lines_2418, heff_clo_n(g_co_2e_3c_2b_3e_24s1859862955x829236210_lam2, 1, 2, (V[]){v_k_2419, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_249);
    }
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2422});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1859862955x829236210_lam3(V self, V *args) {
  V v_m_2423 = args[0];
  V v_n_2424 = args[1];
  V v_nt_2425 = args[2];
  V v_p_2426 = args[3];
  switch (heff_tag_of(v_p_2426)) {
  case TAG_InL: {
    V v_x_2427 = heff_field(v_p_2426, 0);
    V v_ru_24p_2426_24InL = heff_take_reuse_n(v_p_2426, 1ULL, 1);
    V v_t_2431;
    switch (heff_tag_of(v_x_2427)) {
    case TAG_InL: {
      V v_x_2428 = heff_field(v_x_2427, 0);
      heff_take_n(v_x_2427, 1ULL, 1);
      heff_drop(v_m_2423);
      heff_drop(v_n_2424);
      heff_drop(v_nt_2425);
      v_t_2431 = heff_tag_at_n(v_ru_24p_2426_24InL, TAG_InL, 1, (V[]){v_x_2428});
      break;
    }
    case TAG_InR: {
      V v_y_2429 = heff_field(v_x_2427, 0);
      V v_ru_24x_2427_24InR = heff_take_reuse_n(v_x_2427, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2426_24InL, 1);
      V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 1)), 4, (V[]){v_m_2423, v_n_2424, v_nt_2425, v_y_2429}));
      v_t_2431 = heff_tag_at_n(v_ru_24x_2427_24InR, TAG_InR, 1, (V[]){v_t_2430});
      break;
    }
    default: heff_nomatch(v_x_2427);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2431});
  }
  case TAG_InR: {
    V v_y_2432 = heff_field(v_p_2426, 0);
    V v_ru_24p_2426_24InR = heff_take_reuse_n(v_p_2426, 1ULL, 1);
    heff_drop(v_m_2423);
    heff_drop(v_n_2424);
    heff_drop(v_nt_2425);
    return heff_tag_re_n(v_ru_24p_2426_24InR, TAG_InR, 1, 1ULL, (V[]){v_y_2432});
  }
  default: return heff_nomatch(v_p_2426);
  }
}
V g_co_2e_3c_2b_3e_24s269173423x1350998206_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s269173423x1350998206_lam2(V self, V *args);
V g_co_2e_3c_2b_3e_24s269173423x1350998206_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s269173423x1350998206_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s269173423x1350998206_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s269173423x1350998206_lam3(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s269173423x1350998206_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s269173423x1350998206_lam3, 4, 0};

static V g_co_2e_3c_2b_3e_24s269173423x1350998206_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s269173423x1350998206_st;
static V g_co_2e_3c_2b_3e_24s269173423x1350998206_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s269173423x1350998206_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s269173423x1350998206_lam3_clo)});
}
V g_co_2e_3c_2b_3e_24s269173423x1350998206_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s269173423x1350998206_st)) return g_co_2e_3c_2b_3e_24s269173423x1350998206_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s269173423x1350998206_val, &g_co_2e_3c_2b_3e_24s269173423x1350998206_st, g_co_2e_3c_2b_3e_24s269173423x1350998206_init);
}
V g_co_2e_3c_2b_3e_24s269173423x1350998206_lam1(V self, V *args) {
  V v_t_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_k_2413, 1, (V[]){v_t_2414}));
  V f_ = v_g_241;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s269173423x1350998206_lam2(V self, V *args) {
  V v_t_2417 = args[0];
  V v_k_2416 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tr(heff_call(v_k_2416, 1, (V[]){v_t_2417}));
  V f_ = v_g_241;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s269173423x1350998206_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1859862955x829236210_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_244}));
      v_t_248 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_245});
      break;
    }
    case TAG_InR: {
      V v_y_246 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eterminal_2econsole_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_246}));
      v_t_248 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_247});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_248});
  }
  case TAG_InR: {
    V v_y_249 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_m_240);
    V v_t_2419;
    switch (heff_tag_of(v_y_249)) {
    case TAG_Sleep: {
      V v_ms_2410 = heff_field(v_y_249, 0);
      V v_x_2411 = heff_field(v_y_249, 1);
      V v_ru_24y_249_24Sleep = heff_take_reuse_n(v_y_249, 3ULL, 2);
      V v_t_2412 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2411}));
      v_t_2419 = heff_tag_re_n(v_ru_24y_249_24Sleep, TAG_Sleep, 2, 1ULL, (V[]){v_ms_2410, v_t_2412});
      break;
    }
    case TAG_Now: {
      V v_k_2413 = heff_field(v_y_249, 0);
      V v_ru_24y_249_24Now = heff_take_reuse_n(v_y_249, 1ULL, 1);
      v_t_2419 = heff_tag_at_n(v_ru_24y_249_24Now, TAG_Now, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s269173423x1350998206_lam1, 1, 2, (V[]){v_k_2413, v_g_241})});
      break;
    }
    case TAG_Monotonic: {
      V v_k_2416 = heff_field(v_y_249, 0);
      V v_ru_24y_249_24Monotonic = heff_take_reuse_n(v_y_249, 1ULL, 1);
      v_t_2419 = heff_tag_at_n(v_ru_24y_249_24Monotonic, TAG_Monotonic, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s269173423x1350998206_lam2, 1, 2, (V[]){v_k_2416, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_249);
    }
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s269173423x1350998206_lam3(V self, V *args) {
  V v_m_2420 = args[0];
  V v_n_2421 = args[1];
  V v_nt_2422 = args[2];
  V v_p_2423 = args[3];
  switch (heff_tag_of(v_p_2423)) {
  case TAG_InL: {
    V v_x_2424 = heff_field(v_p_2423, 0);
    V v_ru_24p_2423_24InL = heff_take_reuse_n(v_p_2423, 1ULL, 1);
    V v_t_2434;
    switch (heff_tag_of(v_x_2424)) {
    case TAG_InL: {
      V v_x_2425 = heff_field(v_x_2424, 0);
      V v_ru_24x_2424_24InL = heff_take_reuse_n(v_x_2424, 1ULL, 1);
      V v_t_2432;
      switch (heff_tag_of(v_x_2425)) {
      case TAG_InL: {
        V v_x_2426 = heff_field(v_x_2425, 0);
        V v_ru_24x_2425_24InL = heff_take_reuse_n(v_x_2425, 1ULL, 1);
        V v_t_2430;
        switch (heff_tag_of(v_x_2426)) {
        case TAG_InL: {
          V v_x_2427 = heff_field(v_x_2426, 0);
          heff_take_n(v_x_2426, 1ULL, 1);
          heff_drop(v_m_2420);
          heff_drop(v_n_2421);
          heff_drop(v_nt_2422);
          heff_drop_cell(v_ru_24x_2425_24InL, 1);
          v_t_2430 = heff_tag_at_n(v_ru_24p_2423_24InL, TAG_InL, 1, (V[]){v_x_2427});
          break;
        }
        case TAG_InR: {
          V v_y_2428 = heff_field(v_x_2426, 0);
          heff_take_n(v_x_2426, 1ULL, 1);
          heff_drop_cell(v_ru_24p_2423_24InL, 1);
          V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 1)), 4, (V[]){v_m_2420, v_n_2421, v_nt_2422, v_y_2428}));
          v_t_2430 = heff_tag_at_n(v_ru_24x_2425_24InL, TAG_InR, 1, (V[]){v_t_2429});
          break;
        }
        default: heff_nomatch(v_x_2426);
        }
        v_t_2432 = heff_tag_at_n(v_ru_24x_2424_24InL, TAG_InL, 1, (V[]){v_t_2430});
        break;
      }
      case TAG_InR: {
        V v_y_2431 = heff_field(v_x_2425, 0);
        V v_ru_24x_2425_24InR = heff_take_reuse_n(v_x_2425, 1ULL, 1);
        heff_drop(v_m_2420);
        heff_drop(v_n_2421);
        heff_drop(v_nt_2422);
        heff_drop_cell(v_ru_24p_2423_24InL, 1);
        heff_drop_cell(v_ru_24x_2424_24InL, 1);
        v_t_2432 = heff_tag_re_n(v_ru_24x_2425_24InR, TAG_InR, 1, 1ULL, (V[]){v_y_2431});
        break;
      }
      default: heff_nomatch(v_x_2425);
      }
      v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){v_t_2432});
      break;
    }
    case TAG_InR: {
      V v_y_2433 = heff_field(v_x_2424, 0);
      V v_ru_24x_2424_24InR = heff_take_reuse_n(v_x_2424, 1ULL, 1);
      heff_drop(v_m_2420);
      heff_drop(v_n_2421);
      heff_drop(v_nt_2422);
      heff_drop_cell(v_ru_24p_2423_24InL, 1);
      v_t_2434 = heff_tag_re_n(v_ru_24x_2424_24InR, TAG_InR, 1, 1ULL, (V[]){v_y_2433});
      break;
    }
    default: heff_nomatch(v_x_2424);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2434});
  }
  case TAG_InR: {
    V v_y_2435 = heff_field(v_p_2423, 0);
    V v_ru_24p_2423_24InR = heff_take_reuse_n(v_p_2423, 1ULL, 1);
    heff_drop(v_m_2420);
    heff_drop(v_n_2421);
    heff_drop(v_nt_2422);
    return heff_tag_re_n(v_ru_24p_2423_24InR, TAG_InR, 1, 1ULL, (V[]){v_y_2435});
  }
  default: return heff_nomatch(v_p_2423);
  }
}
V g_co_2e_3c_2b_3e_24s1505336972x898038096_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1505336972x898038096_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1505336972x898038096_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1505336972x898038096_lam1(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1505336972x898038096_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1505336972x898038096_lam1, 4, 0};

static V g_co_2e_3c_2b_3e_24s1505336972x898038096_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1505336972x898038096_st;
static V g_co_2e_3c_2b_3e_24s1505336972x898038096_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1505336972x898038096_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1505336972x898038096_lam1_clo)});
}
V g_co_2e_3c_2b_3e_24s1505336972x898038096_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1505336972x898038096_st)) return g_co_2e_3c_2b_3e_24s1505336972x898038096_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1505336972x898038096_val, &g_co_2e_3c_2b_3e_24s1505336972x898038096_st, g_co_2e_3c_2b_3e_24s1505336972x898038096_init);
}
V g_co_2e_3c_2b_3e_24s1505336972x898038096_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s269173423x1350998206_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2ereactor_2ereactor_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_245}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_246});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1505336972x898038096_lam1(V self, V *args) {
  V v_m_247 = args[0];
  V v_n_248 = args[1];
  V v_nt_249 = args[2];
  V v_p_2410 = args[3];
  switch (heff_tag_of(v_p_2410)) {
  case TAG_InL: {
    V v_x_2411 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InL = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    V v_t_2424;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_InL: {
      V v_x_2412 = heff_field(v_x_2411, 0);
      V v_ru_24x_2411_24InL = heff_take_reuse_n(v_x_2411, 1ULL, 1);
      V v_t_2422;
      switch (heff_tag_of(v_x_2412)) {
      case TAG_InL: {
        V v_x_2413 = heff_field(v_x_2412, 0);
        V v_ru_24x_2412_24InL = heff_take_reuse_n(v_x_2412, 1ULL, 1);
        V v_t_2420;
        switch (heff_tag_of(v_x_2413)) {
        case TAG_InL: {
          V v_x_2414 = heff_field(v_x_2413, 0);
          V v_ru_24x_2413_24InL = heff_take_reuse_n(v_x_2413, 1ULL, 1);
          V v_t_2418;
          switch (heff_tag_of(v_x_2414)) {
          case TAG_InL: {
            V v_x_2415 = heff_field(v_x_2414, 0);
            heff_take_n(v_x_2414, 1ULL, 1);
            heff_drop(v_m_247);
            heff_drop(v_n_248);
            heff_drop(v_nt_249);
            heff_drop_cell(v_ru_24x_2413_24InL, 1);
            v_t_2418 = heff_tag_at_n(v_ru_24p_2410_24InL, TAG_InL, 1, (V[]){v_x_2415});
            break;
          }
          case TAG_InR: {
            V v_y_2416 = heff_field(v_x_2414, 0);
            heff_take_n(v_x_2414, 1ULL, 1);
            heff_drop_cell(v_ru_24p_2410_24InL, 1);
            V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 1)), 4, (V[]){v_m_247, v_n_248, v_nt_249, v_y_2416}));
            v_t_2418 = heff_tag_at_n(v_ru_24x_2413_24InL, TAG_InR, 1, (V[]){v_t_2417});
            break;
          }
          default: heff_nomatch(v_x_2414);
          }
          v_t_2420 = heff_tag_at_n(v_ru_24x_2411_24InL, TAG_InL, 1, (V[]){v_t_2418});
          break;
        }
        case TAG_InR: {
          V v_y_2419 = heff_field(v_x_2413, 0);
          V v_ru_24x_2413_24InR = heff_take_reuse_n(v_x_2413, 1ULL, 1);
          heff_drop(v_m_247);
          heff_drop(v_n_248);
          heff_drop(v_nt_249);
          heff_drop_cell(v_ru_24p_2410_24InL, 1);
          heff_drop_cell(v_ru_24x_2411_24InL, 1);
          v_t_2420 = heff_tag_re_n(v_ru_24x_2413_24InR, TAG_InR, 1, 1ULL, (V[]){v_y_2419});
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        v_t_2422 = heff_tag_at_n(v_ru_24x_2412_24InL, TAG_InL, 1, (V[]){v_t_2420});
        break;
      }
      case TAG_InR: {
        V v_y_2421 = heff_field(v_x_2412, 0);
        V v_ru_24x_2412_24InR = heff_take_reuse_n(v_x_2412, 1ULL, 1);
        heff_drop(v_m_247);
        heff_drop(v_n_248);
        heff_drop(v_nt_249);
        heff_drop_cell(v_ru_24p_2410_24InL, 1);
        heff_drop_cell(v_ru_24x_2411_24InL, 1);
        v_t_2422 = heff_tag_re_n(v_ru_24x_2412_24InR, TAG_InR, 1, 1ULL, (V[]){v_y_2421});
        break;
      }
      default: heff_nomatch(v_x_2412);
      }
      v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){v_t_2422});
      break;
    }
    case TAG_InR: {
      V v_y_2423 = heff_field(v_x_2411, 0);
      V v_ru_24x_2411_24InR = heff_take_reuse_n(v_x_2411, 1ULL, 1);
      heff_drop(v_m_247);
      heff_drop(v_n_248);
      heff_drop(v_nt_249);
      heff_drop_cell(v_ru_24p_2410_24InL, 1);
      v_t_2424 = heff_tag_re_n(v_ru_24x_2411_24InR, TAG_InR, 1, 1ULL, (V[]){v_y_2423});
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2424});
  }
  case TAG_InR: {
    V v_y_2425 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InR = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    heff_drop(v_m_247);
    heff_drop(v_n_248);
    heff_drop(v_nt_249);
    return heff_tag_re_n(v_ru_24p_2410_24InR, TAG_InR, 1, 1ULL, (V[]){v_y_2425});
  }
  default: return heff_nomatch(v_p_2410);
  }
}
V g_co_2e_3c_2b_3e_24s1509353391x420518254_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s1509353391x420518254_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1509353391x420518254_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1509353391x420518254_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1509353391x420518254_lam3(V self, V *args);
V g_co_2e_3c_2b_3e_24s1509353391x420518254_lam2(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1509353391x420518254_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1509353391x420518254_lam2, 4, 0};

static V g_co_2e_3c_2b_3e_24s1509353391x420518254_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1509353391x420518254_st;
static V g_co_2e_3c_2b_3e_24s1509353391x420518254_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1509353391x420518254_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1509353391x420518254_lam2_clo)});
}
V g_co_2e_3c_2b_3e_24s1509353391x420518254_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1509353391x420518254_st)) return g_co_2e_3c_2b_3e_24s1509353391x420518254_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1509353391x420518254_val, &g_co_2e_3c_2b_3e_24s1509353391x420518254_st, g_co_2e_3c_2b_3e_24s1509353391x420518254_init);
}
V g_co_2e_3c_2b_3e_24s1509353391x420518254_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = heff_get_n(v_m_240, 0, 1);
  heff_room[0] = v_g_241;
  heff_room[1] = v_t_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2e_3c_2b_3e_24s1509353391x420518254_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_rec(v_m_240, 1);
      heff_drop(v_g_241);
      v_t_2410 = heff_tag_re_n(v_ru_24x_243_24Throw, TAG_Throw, 1, 1ULL, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 2, (V[]){heff_dup(v_g_241), v_c_245}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2e_3c_2b_3e_24s1509353391x420518254_lam1, 1, 3, (V[]){v_h_246, v_m_240, v_g_241})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2410});
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2420;
    switch (heff_tag_of(v_y_2411)) {
    case TAG_InL: {
      V v_x_2412 = heff_field(v_y_2411, 0);
      V v_ru_24y_2411_24InL = heff_take_reuse_n(v_y_2411, 1ULL, 1);
      heff_drop_cell(v_ru_24p_242_24InR, 1);
      V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprogress_2eprogress_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_2412}));
      v_t_2420 = heff_tag_at_n(v_ru_24y_2411_24InL, TAG_InL, 1, (V[]){v_t_2413});
      break;
    }
    case TAG_InR: {
      V v_y_2414 = heff_field(v_y_2411, 0);
      V v_ru_24y_2411_24InR = heff_take_reuse_n(v_y_2411, 1ULL, 1);
      V v_t_2419;
      switch (heff_tag_of(v_y_2414)) {
      case TAG_InL: {
        V v_x_2415 = heff_field(v_y_2414, 0);
        V v_ru_24y_2414_24InL = heff_take_reuse_n(v_y_2414, 1ULL, 1);
        heff_drop_cell(v_ru_24p_242_24InR, 1);
        V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s269173423x1350998206_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_2415}));
        v_t_2419 = heff_tag_at_n(v_ru_24y_2414_24InL, TAG_InL, 1, (V[]){v_t_2416});
        break;
      }
      case TAG_InR: {
        V v_y_2417 = heff_field(v_y_2414, 0);
        heff_take_n(v_y_2414, 1ULL, 1);
        V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2ereactor_2ereactor_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2417}));
        v_t_2419 = heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2418});
        break;
      }
      default: heff_nomatch(v_y_2414);
      }
      v_t_2420 = heff_tag_at_n(v_ru_24y_2411_24InR, TAG_InR, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_y_2411);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2420});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1509353391x420518254_lam3(V self, V *args) {
  V v_s_2430 = args[0];
  V v_h_2428 = heff_env(self)[0];
  V v_nt_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_tr(heff_call(v_h_2428, 1, (V[]){v_s_2430}));
  V f_ = v_nt_2423;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1509353391x420518254_lam2(V self, V *args) {
  V v_m_2421 = args[0];
  V v_n_2422 = args[1];
  V v_nt_2423 = args[2];
  V v_p_2424 = args[3];
  switch (heff_tag_of(v_p_2424)) {
  case TAG_InL: {
    V v_x_2425 = heff_field(v_p_2424, 0);
    V v_ru_24p_2424_24InL = heff_take_reuse_n(v_p_2424, 1ULL, 1);
    heff_drop(v_m_2421);
    heff_drop(v_n_2422);
    V v_t_2432;
    switch (heff_tag_of(v_x_2425)) {
    case TAG_Throw: {
      V v_s_2426 = heff_field(v_x_2425, 0);
      V v_ru_24x_2425_24Throw = heff_take_reuse_n(v_x_2425, 1ULL, 1);
      heff_drop(v_nt_2423);
      v_t_2432 = heff_tag_re_n(v_ru_24x_2425_24Throw, TAG_Throw, 1, 1ULL, (V[]){v_s_2426});
      break;
    }
    case TAG_Catch: {
      V v_c_2427 = heff_field(v_x_2425, 0);
      V v_h_2428 = heff_field(v_x_2425, 1);
      V v_ru_24x_2425_24Catch = heff_take_reuse_n(v_x_2425, 3ULL, 2);
      V v_t_2429 = heff_tr(heff_call(heff_dup(v_nt_2423), 1, (V[]){v_c_2427}));
      v_t_2432 = heff_tag_at_n(v_ru_24x_2425_24Catch, TAG_Catch, 2, (V[]){v_t_2429, heff_clo_n(g_co_2e_3c_2b_3e_24s1509353391x420518254_lam3, 1, 2, (V[]){v_h_2428, v_nt_2423})});
      break;
    }
    default: heff_nomatch(v_x_2425);
    }
    return heff_tag_at_n(v_ru_24p_2424_24InL, TAG_InL, 1, (V[]){v_t_2432});
  }
  case TAG_InR: {
    V v_y_2433 = heff_field(v_p_2424, 0);
    V v_ru_24p_2424_24InR = heff_take_reuse_n(v_p_2424, 1ULL, 1);
    V v_t_2437;
    switch (heff_tag_of(v_y_2433)) {
    case TAG_InL: {
      V v_x_2434 = heff_field(v_y_2433, 0);
      V v_ru_24y_2433_24InL = heff_take_reuse_n(v_y_2433, 1ULL, 1);
      heff_drop(v_m_2421);
      heff_drop(v_n_2422);
      heff_drop(v_nt_2423);
      heff_drop_cell(v_ru_24p_2424_24InR, 1);
      v_t_2437 = heff_tag_re_n(v_ru_24y_2433_24InL, TAG_InL, 1, 1ULL, (V[]){v_x_2434});
      break;
    }
    case TAG_InR: {
      V v_y_2435 = heff_field(v_y_2433, 0);
      heff_take_n(v_y_2433, 1ULL, 1);
      V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1505336972x898038096_get(), 1)), 4, (V[]){v_m_2421, v_n_2422, v_nt_2423, v_y_2435}));
      v_t_2437 = heff_tag_at_n(v_ru_24p_2424_24InR, TAG_InR, 1, (V[]){v_t_2436});
      break;
    }
    default: heff_nomatch(v_y_2433);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2437});
  }
  default: return heff_nomatch(v_p_2424);
  }
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam2(V self, V *args);
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam3(V self, V *args);
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam4(V self, V *args);
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam5(V self, V *args);
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam8(V self, V *args);
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam7(V self, V *args);
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam6(V self, V *args);
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam10(V self, V *args);
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam11(V self, V *args);
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam13(V self, V *args);
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam12(V self, V *args);
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam14(V self, V *args);
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam9(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam9_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam9, 4, 0};

static V g_co_2e_3c_2b_3e_24s2086886503x1354141756_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s2086886503x1354141756_st;
static V g_co_2e_3c_2b_3e_24s2086886503x1354141756_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam9_clo)});
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s2086886503x1354141756_st)) return g_co_2e_3c_2b_3e_24s2086886503x1354141756_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s2086886503x1354141756_val, &g_co_2e_3c_2b_3e_24s2086886503x1354141756_st, g_co_2e_3c_2b_3e_24s2086886503x1354141756_init);
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam1(V self, V *args) {
  V v_c_2410 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_g_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_tr(heff_call(v_k_249, 1, (V[]){v_c_2410}));
  V f_ = v_g_245;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam2(V self, V *args) {
  V v_ws_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_g_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_k_2413, 1, (V[]){v_ws_2414}));
  V f_ = v_g_245;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam3(V self, V *args) {
  V v_c_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_g_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_tr(heff_call(v_k_2425, 1, (V[]){v_c_2426}));
  V f_ = v_g_245;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam4(V self, V *args) {
  V v_b_2435 = args[0];
  V v_k_2434 = heff_env(self)[0];
  V v_g_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_tr(heff_call(v_k_2434, 1, (V[]){v_b_2435}));
  V f_ = v_g_2430;
  args[0] = v_t_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam5(V self, V *args) {
  V v_t_2439 = args[0];
  V v_k_2438 = heff_env(self)[0];
  V v_g_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_tr(heff_call(v_k_2438, 1, (V[]){v_t_2439}));
  V f_ = v_g_2430;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam8(V self, V *args) {
  V v_v_2447 = args[0];
  V v_k_2446 = heff_env(self)[0];
  V v_g_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2448 = heff_tr(heff_call(v_k_2446, 1, (V[]){v_v_2447}));
  V f_ = v_g_2430;
  args[0] = v_t_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam7(V self, V *args) {
  V v_v_2444 = args[0];
  V v_g_2430 = heff_env(self)[0];
  V v_use_2443 = heff_env(self)[1];
  V v_t_2449;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2444)) {
  case TAG_MkRunning: {
    V v_c_2445 = heff_field(v_v_2444, 0);
    V v_k_2446 = heff_field(v_v_2444, 1);
    V v_ru_24v_2444_24MkRunning = heff_take_reuse_n(v_v_2444, 3ULL, 2);
    v_t_2449 = heff_tag_re_n(v_ru_24v_2444_24MkRunning, TAG_MkRunning, 2, 1ULL, (V[]){v_c_2445, heff_clo_n(g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam8, 1, 2, (V[]){v_k_2446, v_g_2430})});
    break;
  }
  default: heff_nomatch(v_v_2444);
  }
  V f_ = v_use_2443;
  args[0] = v_t_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam6(V self, V *args) {
  V v_use_2443 = args[0];
  V v_s_2442 = heff_env(self)[0];
  V v_g_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_s_2442;
  args[0] = heff_clo_n(g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam7, 1, 2, (V[]){v_g_2430, v_use_2443});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_m_240);
    V v_t_2451;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Asked: {
      V v_q_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Asked = heff_take_reuse_n(v_x_243, 1ULL, 1);
      V v_g_245 = v_g_241;
      V v_x2_246 = v_q_244;
      V v_t_2428;
      switch (heff_tag_of(v_x2_246)) {
      case TAG_Made: {
        V v_p_247 = heff_field(v_x2_246, 0);
        V v_b_248 = heff_field(v_x2_246, 1);
        V v_k_249 = heff_field(v_x2_246, 2);
        V v_ru_24x2_246_24Made = heff_take_reuse_n(v_x2_246, 7ULL, 3);
        v_t_2428 = heff_tag_re_n(v_ru_24x2_246_24Made, TAG_Made, 3, 3ULL, (V[]){v_p_247, v_b_248, heff_clo_n(g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam1, 1, 2, (V[]){v_k_249, v_g_245})});
        break;
      }
      case TAG_ShutDown: {
        V v_c_2412 = heff_field(v_x2_246, 0);
        V v_k_2413 = heff_field(v_x2_246, 1);
        V v_ru_24x2_246_24ShutDown = heff_take_reuse_n(v_x2_246, 3ULL, 2);
        v_t_2428 = heff_tag_re_n(v_ru_24x2_246_24ShutDown, TAG_ShutDown, 2, 1ULL, (V[]){v_c_2412, heff_clo_n(g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam2, 1, 2, (V[]){v_k_2413, v_g_245})});
        break;
      }
      case TAG_Dropped: {
        V v_t_2416 = heff_field(v_x2_246, 0);
        V v_x_2417 = heff_field(v_x2_246, 1);
        V v_ru_24x2_246_24Dropped = heff_take_reuse_n(v_x2_246, 3ULL, 2);
        V v_t_2418 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_2417}));
        v_t_2428 = heff_tag_re_n(v_ru_24x2_246_24Dropped, TAG_Dropped, 2, 1ULL, (V[]){v_t_2416, v_t_2418});
        break;
      }
      case TAG_Own: {
        V v_s_2419 = heff_field(v_x2_246, 0);
        V v_x_2420 = heff_field(v_x2_246, 1);
        V v_ru_24x2_246_24Own = heff_take_reuse_n(v_x2_246, 3ULL, 2);
        V v_t_2421 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_2420}));
        v_t_2428 = heff_tag_re_n(v_ru_24x2_246_24Own, TAG_Own, 2, 1ULL, (V[]){v_s_2419, v_t_2421});
        break;
      }
      case TAG_Failed: {
        V v_why_2422 = heff_field(v_x2_246, 0);
        V v_x_2423 = heff_field(v_x2_246, 1);
        V v_ru_24x2_246_24Failed = heff_take_reuse_n(v_x2_246, 3ULL, 2);
        V v_t_2424 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_2423}));
        v_t_2428 = heff_tag_re_n(v_ru_24x2_246_24Failed, TAG_Failed, 2, 1ULL, (V[]){v_why_2422, v_t_2424});
        break;
      }
      case TAG_Current: {
        V v_k_2425 = heff_field(v_x2_246, 0);
        V v_ru_24x2_246_24Current = heff_take_reuse_n(v_x2_246, 1ULL, 1);
        v_t_2428 = heff_tag_at_n(v_ru_24x2_246_24Current, TAG_Current, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam3, 1, 2, (V[]){v_k_2425, v_g_245})});
        break;
      }
      default: heff_nomatch(v_x2_246);
      }
      v_t_2451 = heff_tag_at_n(v_ru_24x_243_24Asked, TAG_Asked, 1, (V[]){v_t_2428});
      break;
    }
    case TAG_Given: {
      V v_q_2429 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Given = heff_take_reuse_n(v_x_243, 1ULL, 1);
      V v_g_2430 = v_g_241;
      V v_x2_2431 = v_q_2429;
      V v_t_2450;
      switch (heff_tag_of(v_x2_2431)) {
      case TAG_Managed: {
        V v_c_2432 = heff_field(v_x2_2431, 0);
        V v_s_2433 = heff_field(v_x2_2431, 1);
        V v_k_2434 = heff_field(v_x2_2431, 2);
        V v_ru_24x2_2431_24Managed = heff_take_reuse_n(v_x2_2431, 7ULL, 3);
        v_t_2450 = heff_tag_re_n(v_ru_24x2_2431_24Managed, TAG_Managed, 3, 3ULL, (V[]){v_c_2432, v_s_2433, heff_clo_n(g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam4, 1, 2, (V[]){v_k_2434, v_g_2430})});
        break;
      }
      case TAG_Kept: {
        V v_r_2437 = heff_field(v_x2_2431, 0);
        V v_k_2438 = heff_field(v_x2_2431, 1);
        V v_ru_24x2_2431_24Kept = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
        v_t_2450 = heff_tag_re_n(v_ru_24x2_2431_24Kept, TAG_Kept, 2, 1ULL, (V[]){v_r_2437, heff_clo_n(g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam5, 1, 2, (V[]){v_k_2438, v_g_2430})});
        break;
      }
      case TAG_Under: {
        V v_c_2441 = heff_field(v_x2_2431, 0);
        V v_s_2442 = heff_field(v_x2_2431, 1);
        V v_ru_24x2_2431_24Under = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
        v_t_2450 = heff_tag_re_n(v_ru_24x2_2431_24Under, TAG_Under, 2, 1ULL, (V[]){v_c_2441, heff_clo_n(g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam6, 1, 2, (V[]){v_s_2442, v_g_2430})});
        break;
      }
      default: heff_nomatch(v_x2_2431);
      }
      v_t_2451 = heff_tag_at_n(v_ru_24x_243_24Given, TAG_Given, 1, (V[]){v_t_2450});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2451});
  }
  case TAG_InR: {
    V v_y_2452 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2453 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1509353391x420518254_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2452}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2453});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam10(V self, V *args) {
  V v_u_2466 = args[0];
  V v_s_2464 = heff_env(self)[0];
  V v_nt_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2467 = heff_tr(heff_call(v_s_2464, 1, (V[]){v_u_2466}));
  V f_ = v_nt_2461;
  args[0] = v_t_2467;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam11(V self, V *args) {
  V v_u_2470 = args[0];
  V v_r_2468 = heff_env(self)[0];
  V v_nt_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2471 = heff_tr(heff_call(v_r_2468, 1, (V[]){v_u_2470}));
  V f_ = v_nt_2461;
  args[0] = v_t_2471;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam13(V self, V *args) {
  V v_v_2475 = args[0];
  V v_nt_2461 = heff_env(self)[0];
  V v_use_2474 = heff_env(self)[1];
  V v_t_2479;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2475)) {
  case TAG_MkRunning: {
    V v_c_2476 = heff_field(v_v_2475, 0);
    V v_k_2477 = heff_field(v_v_2475, 1);
    V v_ru_24v_2475_24MkRunning = heff_take_reuse_n(v_v_2475, 3ULL, 2);
    V v_t_2478 = heff_tr(heff_call(v_nt_2461, 1, (V[]){v_c_2476}));
    v_t_2479 = heff_tag_re_n(v_ru_24v_2475_24MkRunning, TAG_MkRunning, 2, 2ULL, (V[]){v_t_2478, v_k_2477});
    break;
  }
  default: heff_nomatch(v_v_2475);
  }
  V f_ = v_use_2474;
  args[0] = v_t_2479;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam12(V self, V *args) {
  V v_use_2474 = args[0];
  V v_s_2473 = heff_env(self)[0];
  V v_nt_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_s_2473;
  args[0] = heff_clo_n(g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam13, 1, 2, (V[]){v_nt_2461, v_use_2474});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam14(V self, V *args) {
  V v_s_2488 = args[0];
  V v_h_2486 = heff_env(self)[0];
  V v_nt_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2489 = heff_tr(heff_call(v_h_2486, 1, (V[]){v_s_2488}));
  V f_ = v_nt_2456;
  args[0] = v_t_2489;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam9(V self, V *args) {
  V v_m_2454 = args[0];
  V v_n_2455 = args[1];
  V v_nt_2456 = args[2];
  V v_p_2457 = args[3];
  switch (heff_tag_of(v_p_2457)) {
  case TAG_InL: {
    V v_x_2458 = heff_field(v_p_2457, 0);
    V v_ru_24p_2457_24InL = heff_take_reuse_n(v_p_2457, 1ULL, 1);
    heff_drop(v_m_2454);
    heff_drop(v_n_2455);
    V v_t_2481;
    switch (heff_tag_of(v_x_2458)) {
    case TAG_Asked: {
      V v_q_2459 = heff_field(v_x_2458, 0);
      V v_ru_24x_2458_24Asked = heff_take_reuse_n(v_x_2458, 1ULL, 1);
      heff_drop(v_nt_2456);
      v_t_2481 = heff_tag_re_n(v_ru_24x_2458_24Asked, TAG_Asked, 1, 1ULL, (V[]){v_q_2459});
      break;
    }
    case TAG_Given: {
      V v_q_2460 = heff_field(v_x_2458, 0);
      V v_ru_24x_2458_24Given = heff_take_reuse_n(v_x_2458, 1ULL, 1);
      V v_nt_2461 = v_nt_2456;
      V v_x2_2462 = v_q_2460;
      V v_t_2480;
      switch (heff_tag_of(v_x2_2462)) {
      case TAG_Managed: {
        V v_c_2463 = heff_field(v_x2_2462, 0);
        V v_s_2464 = heff_field(v_x2_2462, 1);
        V v_k_2465 = heff_field(v_x2_2462, 2);
        V v_ru_24x2_2462_24Managed = heff_take_reuse_n(v_x2_2462, 7ULL, 3);
        v_t_2480 = heff_tag_re_n(v_ru_24x2_2462_24Managed, TAG_Managed, 3, 5ULL, (V[]){v_c_2463, heff_clo_n(g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam10, 1, 2, (V[]){v_s_2464, v_nt_2461}), v_k_2465});
        break;
      }
      case TAG_Kept: {
        V v_r_2468 = heff_field(v_x2_2462, 0);
        V v_k_2469 = heff_field(v_x2_2462, 1);
        V v_ru_24x2_2462_24Kept = heff_take_reuse_n(v_x2_2462, 3ULL, 2);
        v_t_2480 = heff_tag_re_n(v_ru_24x2_2462_24Kept, TAG_Kept, 2, 2ULL, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam11, 1, 2, (V[]){v_r_2468, v_nt_2461}), v_k_2469});
        break;
      }
      case TAG_Under: {
        V v_c_2472 = heff_field(v_x2_2462, 0);
        V v_s_2473 = heff_field(v_x2_2462, 1);
        V v_ru_24x2_2462_24Under = heff_take_reuse_n(v_x2_2462, 3ULL, 2);
        v_t_2480 = heff_tag_re_n(v_ru_24x2_2462_24Under, TAG_Under, 2, 1ULL, (V[]){v_c_2472, heff_clo_n(g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam12, 1, 2, (V[]){v_s_2473, v_nt_2461})});
        break;
      }
      default: heff_nomatch(v_x2_2462);
      }
      v_t_2481 = heff_tag_at_n(v_ru_24x_2458_24Given, TAG_Given, 1, (V[]){v_t_2480});
      break;
    }
    default: heff_nomatch(v_x_2458);
    }
    return heff_tag_at_n(v_ru_24p_2457_24InL, TAG_InL, 1, (V[]){v_t_2481});
  }
  case TAG_InR: {
    V v_y_2482 = heff_field(v_p_2457, 0);
    V v_ru_24p_2457_24InR = heff_take_reuse_n(v_p_2457, 1ULL, 1);
    V v_t_2496;
    switch (heff_tag_of(v_y_2482)) {
    case TAG_InL: {
      V v_x_2483 = heff_field(v_y_2482, 0);
      V v_ru_24y_2482_24InL = heff_take_reuse_n(v_y_2482, 1ULL, 1);
      heff_drop(v_m_2454);
      heff_drop(v_n_2455);
      heff_drop_cell(v_ru_24p_2457_24InR, 1);
      V v_t_2490;
      switch (heff_tag_of(v_x_2483)) {
      case TAG_Throw: {
        V v_s_2484 = heff_field(v_x_2483, 0);
        V v_ru_24x_2483_24Throw = heff_take_reuse_n(v_x_2483, 1ULL, 1);
        heff_drop(v_nt_2456);
        v_t_2490 = heff_tag_re_n(v_ru_24x_2483_24Throw, TAG_Throw, 1, 1ULL, (V[]){v_s_2484});
        break;
      }
      case TAG_Catch: {
        V v_c_2485 = heff_field(v_x_2483, 0);
        V v_h_2486 = heff_field(v_x_2483, 1);
        V v_ru_24x_2483_24Catch = heff_take_reuse_n(v_x_2483, 3ULL, 2);
        V v_t_2487 = heff_tr(heff_call(heff_dup(v_nt_2456), 1, (V[]){v_c_2485}));
        v_t_2490 = heff_tag_at_n(v_ru_24x_2483_24Catch, TAG_Catch, 2, (V[]){v_t_2487, heff_clo_n(g_co_2e_3c_2b_3e_24s2086886503x1354141756_lam14, 1, 2, (V[]){v_h_2486, v_nt_2456})});
        break;
      }
      default: heff_nomatch(v_x_2483);
      }
      v_t_2496 = heff_tag_at_n(v_ru_24y_2482_24InL, TAG_InL, 1, (V[]){v_t_2490});
      break;
    }
    case TAG_InR: {
      V v_y_2491 = heff_field(v_y_2482, 0);
      V v_ru_24y_2482_24InR = heff_take_reuse_n(v_y_2482, 1ULL, 1);
      V v_t_2495;
      switch (heff_tag_of(v_y_2491)) {
      case TAG_InL: {
        V v_x_2492 = heff_field(v_y_2491, 0);
        V v_ru_24y_2491_24InL = heff_take_reuse_n(v_y_2491, 1ULL, 1);
        heff_drop(v_m_2454);
        heff_drop(v_n_2455);
        heff_drop(v_nt_2456);
        heff_drop_cell(v_ru_24p_2457_24InR, 1);
        v_t_2495 = heff_tag_re_n(v_ru_24y_2491_24InL, TAG_InL, 1, 1ULL, (V[]){v_x_2492});
        break;
      }
      case TAG_InR: {
        V v_y_2493 = heff_field(v_y_2491, 0);
        heff_take_n(v_y_2491, 1ULL, 1);
        V v_t_2494 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1505336972x898038096_get(), 1)), 4, (V[]){v_m_2454, v_n_2455, v_nt_2456, v_y_2493}));
        v_t_2495 = heff_tag_at_n(v_ru_24p_2457_24InR, TAG_InR, 1, (V[]){v_t_2494});
        break;
      }
      default: heff_nomatch(v_y_2491);
      }
      v_t_2496 = heff_tag_at_n(v_ru_24y_2482_24InR, TAG_InR, 1, (V[]){v_t_2495});
      break;
    }
    default: heff_nomatch(v_y_2482);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2496});
  }
  default: return heff_nomatch(v_p_2457);
  }
}
V g_co_2eop_24s2022167152x294629972_24rec0_lam1(V self, V *args);
V g_co_2eop_24s2022167152x294629972_24rec0_lam0(V self, V *args); static Clo g_co_2eop_24s2022167152x294629972_24rec0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s2022167152x294629972_24rec0_lam0, 4, 0};

static V g_co_2eop_24s2022167152x294629972_24rec0_val;
static HEFF_ONCE g_co_2eop_24s2022167152x294629972_24rec0_st;
static V g_co_2eop_24s2022167152x294629972_24rec0_init(void) {
  return heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s2022167152x294629972_24rec0_lam0_clo)});
}
V g_co_2eop_24s2022167152x294629972_24rec0_get(void) {
  if (HEFF_DONE(g_co_2eop_24s2022167152x294629972_24rec0_st)) return g_co_2eop_24s2022167152x294629972_24rec0_val;
  return heff_global(&g_co_2eop_24s2022167152x294629972_24rec0_val, &g_co_2eop_24s2022167152x294629972_24rec0_st, g_co_2eop_24s2022167152x294629972_24rec0_init);
}
V g_co_2eop_24s2022167152x294629972_24rec0_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_245 = heff_tr(heff_call(v_g_240, 1, (V[]){v_x_244}));
  V f_ = v_k_243;
  args[0] = v_x_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s2022167152x294629972_24rec0_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_c_241 = args[1];
  V v_hd_242 = args[2];
  V v_k_243 = args[3];
  V f_ = v_c_241;
  args[0] = v_hd_242;
  args[1] = heff_clo_n(g_co_2eop_24s2022167152x294629972_24rec0_lam1, 1, 2, (V[]){v_g_240, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s2022167152x294629972_lam1(V self, V *args);
V g_co_2eop_24s2022167152x294629972_lam0(V self, V *args);
V g_co_2eop_24s2022167152x294629972_lam2(V self, V *args);
Clo g_co_2eop_24s2022167152x294629972_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s2022167152x294629972_entry, 3, 0};

V g_co_2eop_24s2022167152x294629972(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1505336972x898038096_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s2022167152x294629972_lam0, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s2022167152x294629972_lam2, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_248}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_249, v_k2_242});
}
V g_co_2eop_24s2022167152x294629972_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s2022167152x294629972(a[0], a[1], a[2]);
}
V g_co_2eop_24s2022167152x294629972_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_245}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s2022167152x294629972_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_m_244 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_244;
  args[1] = heff_clo_n(g_co_2eop_24s2022167152x294629972_lam1, 1, 2, (V[]){v_g_243, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s2022167152x294629972_lam2(V self, V *args) {
  V v_c_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s582347324x1305505939_lam1(V self, V *args);
V g_co_2eop_24s582347324x1305505939_lam0(V self, V *args);
V g_co_2eop_24s582347324x1305505939_lam2(V self, V *args);
V g_co_2eop_24s582347324x1305505939_lam3(V self, V *args);
Clo g_co_2eop_24s582347324x1305505939_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s582347324x1305505939_entry, 4, 0};

V g_co_2eop_24s582347324x1305505939(V v_p_240, V v_k_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1505336972x898038096_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s582347324x1305505939_lam0, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s582347324x1305505939_lam2, 1, 1, (V[]){heff_dup(v_hd_242)}), v_p_240}));
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_co_2eop_24s582347324x1305505939_lam3, 1, 3, (V[]){v_k_241, v_hd_242, v_k2_243})});
}
V g_co_2eop_24s582347324x1305505939_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s582347324x1305505939(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s582347324x1305505939_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_246}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s582347324x1305505939_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_m_245 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_245;
  args[1] = heff_clo_n(g_co_2eop_24s582347324x1305505939_lam1, 1, 2, (V[]){v_g_244, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s582347324x1305505939_lam2(V self, V *args) {
  V v_c_248 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_248;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s582347324x1305505939_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k2_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  heff_room[0] = v_x_2411;
  heff_room[1] = v_hd_242;
  heff_room[2] = v_k2_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eop_24s1673054648x994021533_lam1(V self, V *args);
V g_co_2eop_24s1673054648x994021533_lam0(V self, V *args);
V g_co_2eop_24s1673054648x994021533_lam2(V self, V *args);
Clo g_co_2eop_24s1673054648x994021533_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1673054648x994021533_entry, 3, 0};

V g_co_2eop_24s1673054648x994021533(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1505336972x898038096_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1673054648x994021533_lam0, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1673054648x994021533_lam2, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_248}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_249, v_k2_242});
}
V g_co_2eop_24s1673054648x994021533_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1673054648x994021533(a[0], a[1], a[2]);
}
V g_co_2eop_24s1673054648x994021533_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_245}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1673054648x994021533_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_m_244 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_244;
  args[1] = heff_clo_n(g_co_2eop_24s1673054648x994021533_lam1, 1, 2, (V[]){v_g_243, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1673054648x994021533_lam2(V self, V *args) {
  V v_c_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s535099379x685970669_lam1(V self, V *args);
V g_co_2eop_24s535099379x685970669_lam0(V self, V *args);
V g_co_2eop_24s535099379x685970669_lam2(V self, V *args);
Clo g_co_2eop_24s535099379x685970669_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s535099379x685970669_entry, 3, 0};

V g_co_2eop_24s535099379x685970669(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s535099379x685970669_lam0, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s535099379x685970669_lam2, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_248}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_249, v_k2_242});
}
V g_co_2eop_24s535099379x685970669_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s535099379x685970669(a[0], a[1], a[2]);
}
V g_co_2eop_24s535099379x685970669_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_245}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s535099379x685970669_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_m_244 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_244;
  args[1] = heff_clo_n(g_co_2eop_24s535099379x685970669_lam1, 1, 2, (V[]){v_g_243, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s535099379x685970669_lam2(V self, V *args) {
  V v_c_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1896221640x2141527803_lam1(V self, V *args);
V g_co_2eop_24s1896221640x2141527803_lam0(V self, V *args);
V g_co_2eop_24s1896221640x2141527803_lam2(V self, V *args);
V g_co_2eop_24s1896221640x2141527803_lam3(V self, V *args);
Clo g_co_2eop_24s1896221640x2141527803_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1896221640x2141527803_entry, 3, 0};

V g_co_2eop_24s1896221640x2141527803(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1896221640x2141527803_lam0, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1896221640x2141527803_lam2, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_248}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_249, heff_clo_n(g_co_2eop_24s1896221640x2141527803_lam3, 1, 1, (V[]){v_k2_242})});
}
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1896221640x2141527803(a[0], a[1], a[2]);
}
V g_co_2eop_24s1896221640x2141527803_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_245}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1896221640x2141527803_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_m_244 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_244;
  args[1] = heff_clo_n(g_co_2eop_24s1896221640x2141527803_lam1, 1, 2, (V[]){v_g_243, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1896221640x2141527803_lam2(V self, V *args) {
  V v_c_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1896221640x2141527803_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_242;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s973071017x1608150717_24rec0_lam1(V self, V *args);
V g_co_2eop_24s973071017x1608150717_24rec0_lam0(V self, V *args); static Clo g_co_2eop_24s973071017x1608150717_24rec0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s973071017x1608150717_24rec0_lam0, 4, 0};

static V g_co_2eop_24s973071017x1608150717_24rec0_val;
static HEFF_ONCE g_co_2eop_24s973071017x1608150717_24rec0_st;
static V g_co_2eop_24s973071017x1608150717_24rec0_init(void) {
  return heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s973071017x1608150717_24rec0_lam0_clo)});
}
V g_co_2eop_24s973071017x1608150717_24rec0_get(void) {
  if (HEFF_DONE(g_co_2eop_24s973071017x1608150717_24rec0_st)) return g_co_2eop_24s973071017x1608150717_24rec0_val;
  return heff_global(&g_co_2eop_24s973071017x1608150717_24rec0_val, &g_co_2eop_24s973071017x1608150717_24rec0_st, g_co_2eop_24s973071017x1608150717_24rec0_init);
}
V g_co_2eop_24s973071017x1608150717_24rec0_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  switch (heff_tag_of(v_x_244)) {
  case TAG_Left: {
    V v_x_245 = heff_field(v_x_244, 0);
    heff_take_n(v_x_244, 1ULL, 1);
    heff_clo_take(self, 2);
    heff_drop(v_g_240);
    V f_ = v_k_243;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_245});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_246 = heff_field(v_x_244, 0);
    heff_take_n(v_x_244, 1ULL, 1);
    heff_clo_take(self, 2);
    V v_x_247 = heff_tr(heff_call(v_g_240, 1, (V[]){v_y_246}));
    V f_ = v_k_243;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_247});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_244);
  }
}
V g_co_2eop_24s973071017x1608150717_24rec0_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_m_241 = args[1];
  V v_hd_242 = args[2];
  V v_k_243 = args[3];
  V f_ = v_m_241;
  args[0] = v_hd_242;
  args[1] = heff_clo_n(g_co_2eop_24s973071017x1608150717_24rec0_lam1, 1, 2, (V[]){v_k_243, v_g_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s973071017x1608150717_lam0(V self, V *args);
V g_co_2eop_24s973071017x1608150717_lam1(V self, V *args); static Clo g_co_2eop_24s973071017x1608150717_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s973071017x1608150717_lam1, 1, 0};
V g_co_2eop_24s973071017x1608150717_lam3(V self, V *args);
V g_co_2eop_24s973071017x1608150717_lam2(V self, V *args);
Clo g_co_2eop_24s973071017x1608150717_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s973071017x1608150717_entry, 1, 0};

V g_co_2eop_24s973071017x1608150717(V v_p_240) {
top: ;
  V v_t_2412;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_241 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_Throw: {
      V v_s_242 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24Throw = heff_take_reuse_n(v_x_241, 1ULL, 1);
      v_t_248 = heff_tag_re_n(v_ru_24x_241_24Throw, TAG_Throw, 1, 1ULL, (V[]){v_s_242});
      break;
    }
    case TAG_Catch: {
      V v_c_243 = heff_field(v_x_241, 0);
      V v_h_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24Catch = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_245 = heff_tr(heff_call(v_c_243, 2, (V[]){heff_dup(g_exception_2eattempted_24s588401679x1225922520_get()), heff_dup(heff_rfield(g_exception_2eattempted_24s588401679x1225922520_get(), 0))}));
      v_t_248 = heff_tag_at_n(v_ru_24x_241_24Catch, TAG_Catch, 2, (V[]){v_t_245, heff_clo_n(g_co_2eop_24s973071017x1608150717_lam0, 1, 1, (V[]){v_h_244})});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    v_t_2412 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_248});
    break;
  }
  case TAG_InR: {
    V v_y_249 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_dup(g_co_2eop_24s973071017x1608150717_24rec0_get()), ((V)&g_co_2eop_24s973071017x1608150717_lam1_clo), v_y_249}));
    v_t_2412 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2411});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_m_2413 = heff_tr(heff_call(heff_dup(heff_rfield(g_exception_2eattempted_24s588401679x1225922520_get(), 2)), 1, (V[]){v_t_2412}));
  return heff_clo_n(g_co_2eop_24s973071017x1608150717_lam2, 2, 1, (V[]){v_m_2413});
}
V g_co_2eop_24s973071017x1608150717_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s973071017x1608150717(a[0]);
}
V g_co_2eop_24s973071017x1608150717_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_h_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_247 = heff_tr(heff_call(v_h_244, 1, (V[]){v_s_246}));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(g_exception_2eattempted_24s588401679x1225922520_get());
  heff_room[1] = heff_dup(heff_rfield(g_exception_2eattempted_24s588401679x1225922520_get(), 0));
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s973071017x1608150717_lam1(V self, V *args) {
  V v_c_2410 = args[0];
  V f_ = v_c_2410;
  heff_room[0] = heff_dup(g_exception_2eattempted_24s588401679x1225922520_get());
  heff_room[1] = heff_dup(heff_rfield(g_exception_2eattempted_24s588401679x1225922520_get(), 0));
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s973071017x1608150717_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_x_2417 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_2415;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_2417});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2418 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    switch (heff_tag_of(v_y_2418)) {
    case TAG_Left: {
      V v_a_2419 = heff_field(v_y_2418, 0);
      heff_take_n(v_y_2418, 1ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2415;
      args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_a_2419});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_a_2420 = heff_field(v_y_2418, 0);
      heff_take_n(v_y_2418, 1ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_2415;
      args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_a_2420});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2418);
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_co_2eop_24s973071017x1608150717_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_m_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_m_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_co_2eop_24s973071017x1608150717_lam3, 1, 1, (V[]){v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_co_2eop_24s774411652x2032095250_str0, 2, ": ");
HEFF_LIT(g_co_2eop_24s774411652x2032095250_str1, 1, "\012");
V g_co_2eop_24s774411652x2032095250_lam1(V self, V *args);
V g_co_2eop_24s774411652x2032095250_lam0(V self, V *args);
V g_co_2eop_24s774411652x2032095250_lam2(V self, V *args);
V g_co_2eop_24s774411652x2032095250_lam3(V self, V *args);
Clo g_co_2eop_24s774411652x2032095250_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s774411652x2032095250_entry, 8, 0};

V g_co_2eop_24s774411652x2032095250(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_p_246, V v_hd_247) {
top: ;
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s774411652x2032095250_lam0, 2, 1, (V[]){heff_dup(v_hd_247)})}), heff_clo_n(g_co_2eop_24s774411652x2032095250_lam2, 1, 1, (V[]){heff_dup(v_hd_247)}), v_p_246}));
  V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2413}));
  return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2414, heff_clo_n(g_co_2eop_24s774411652x2032095250_lam3, 1, 6, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})});
}
V g_co_2eop_24s774411652x2032095250_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s774411652x2032095250(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_co_2eop_24s774411652x2032095250_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_248 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_tr(heff_call(v_g_248, 1, (V[]){v_x_2410}));
  V f_ = heff_get_n(v_hd_247, 0, 3);
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s774411652x2032095250_lam0(V self, V *args) {
  V v_g_248 = args[0];
  V v_m_249 = args[1];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  args[0] = v_m_249;
  args[1] = heff_clo_n(g_co_2eop_24s774411652x2032095250_lam1, 1, 2, (V[]){v_g_248, v_hd_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s774411652x2032095250_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_get_n(v_hd_247, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s774411652x2032095250_lam3(V self, V *args) {
  V v_a_2415 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  heff_drop(v_a_2415);
  heff_clo_take(self, 6);
  V v_m_2416 = v_lit_240;
  V v_x2_2417 = v_lit_241;
  V v_n_2418 = heff_intAdd(v_lit_242, v_lit_243);
  V v_p_2419 = v_lit_244;
  V v_p_2420 = v_lit_245;
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nil: {
    heff_drop(v_m_2416);
    heff_drop(v_p_2419);
    V f_ = v_p_2420;
    args[0] = v_n_2418;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_l_2421 = heff_field(v_x2_2417, 0);
    V v_rest_2422 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24Cons = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2423 = heff_strAppend(heff_strAppend(heff_dup(v_m_2416), ((V)&g_co_2eop_24s774411652x2032095250_str0)), v_l_2421);
    V v_t_2424 = heff_tag_at_n(v_ru_24x2_2417_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2423, ((V)&g_co_2eop_24s774411652x2032095250_str1)), NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s774411652x2032095250(v_m_2416, v_rest_2422, v_n_2418, MK_INT(1LL), heff_dup(v_p_2419), v_p_2420, heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), v_p_2419));
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_co_2eop_24s297957795x1045074450_lam1(V self, V *args);
V g_co_2eop_24s297957795x1045074450_lam0(V self, V *args);
V g_co_2eop_24s297957795x1045074450_lam2(V self, V *args);
Clo g_co_2eop_24s297957795x1045074450_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s297957795x1045074450_entry, 3, 0};

V g_co_2eop_24s297957795x1045074450(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s297957795x1045074450_lam0, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s297957795x1045074450_lam2, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_248}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_249, v_k2_242});
}
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s297957795x1045074450(a[0], a[1], a[2]);
}
V g_co_2eop_24s297957795x1045074450_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_245}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s297957795x1045074450_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_m_244 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_244;
  args[1] = heff_clo_n(g_co_2eop_24s297957795x1045074450_lam1, 1, 2, (V[]){v_g_243, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s297957795x1045074450_lam2(V self, V *args) {
  V v_c_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_co_2eop_24s1014403878x489449937_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_co_2eop_24s1014403878x489449937_str1, 1, "\012");
V g_co_2eop_24s1014403878x489449937_lam1(V self, V *args);
V g_co_2eop_24s1014403878x489449937_lam0(V self, V *args);
V g_co_2eop_24s1014403878x489449937_lam2(V self, V *args);
V g_co_2eop_24s1014403878x489449937_lam3(V self, V *args);
Clo g_co_2eop_24s1014403878x489449937_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1014403878x489449937_entry, 5, 0};

V g_co_2eop_24s1014403878x489449937(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_hd_244) {
top: ;
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1014403878x489449937_lam0, 2, 1, (V[]){heff_dup(v_hd_244)})}), heff_clo_n(g_co_2eop_24s1014403878x489449937_lam2, 1, 1, (V[]){heff_dup(v_hd_244)}), v_p_243}));
  V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2410}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2411, heff_clo_n(g_co_2eop_24s1014403878x489449937_lam3, 1, 3, (V[]){v_lit_240, v_lit_241, v_lit_242})});
}
V g_co_2eop_24s1014403878x489449937_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1014403878x489449937(a[0], a[1], a[2], a[3], a[4]);
}
V g_co_2eop_24s1014403878x489449937_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_247}));
  V f_ = heff_get_n(v_hd_244, 0, 3);
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1014403878x489449937_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_m_246 = args[1];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_m_246;
  args[1] = heff_clo_n(g_co_2eop_24s1014403878x489449937_lam1, 1, 2, (V[]){v_g_245, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1014403878x489449937_lam2(V self, V *args) {
  V v_c_249 = args[0];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1014403878x489449937_lam3(V self, V *args) {
  V v_a_2412 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_drop(v_a_2412);
  heff_clo_take(self, 3);
  V v_x1_2413 = v_lit_240;
  V v_p_2414 = v_lit_241;
  V v_p_2415 = v_lit_242;
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_Nil: {
    heff_drop(v_p_2414);
    V f_ = v_p_2415;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_e_2416 = heff_field(v_x1_2413, 0);
    V v_rest_2417 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24Cons = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_co_2eop_24s1014403878x489449937_str0), v_e_2416), ((V)&g_co_2eop_24s1014403878x489449937_str1));
    V v_t_2419 = heff_tag_at_n(v_ru_24x1_2413_24Cons, TAG_WriteErr, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s1014403878x489449937(v_rest_2417, heff_dup(v_p_2414), v_p_2415, heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_p_2414));
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
V g_co_2eop_24s197845728x1944963205_lam0(V self, V *args);
V g_co_2eop_24s197845728x1944963205_lam2(V self, V *args);
V g_co_2eop_24s197845728x1944963205_lam1(V self, V *args);
V g_co_2eop_24s197845728x1944963205_lam3(V self, V *args);
Clo g_co_2eop_24s197845728x1944963205_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s197845728x1944963205_entry, 3, 0};

V g_co_2eop_24s197845728x1944963205(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2418;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2410 = heff_tag_re_n(v_ru_24x_243_24Throw, TAG_Throw, 1, 1ULL, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2eop_24s197845728x1944963205_lam0, 1, 2, (V[]){v_h_246, heff_dup(v_hd_241)})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2418 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2410});
    break;
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s197845728x1944963205_lam1, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s197845728x1944963205_lam3, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_2411}));
    v_t_2418 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2417});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2419 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2418}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2419, v_k2_242});
}
V g_co_2eop_24s197845728x1944963205_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s197845728x1944963205(a[0], a[1], a[2]);
}
V g_co_2eop_24s197845728x1944963205_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s197845728x1944963205_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2414}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s197845728x1944963205_lam1(V self, V *args) {
  V v_g_2412 = args[0];
  V v_m_2413 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2413;
  args[1] = heff_clo_n(g_co_2eop_24s197845728x1944963205_lam2, 1, 2, (V[]){v_g_2412, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s197845728x1944963205_lam3(V self, V *args) {
  V v_c_2416 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_co_2eop_24s981909385x709882350_str0, 1, "\012");
V g_co_2eop_24s981909385x709882350_lam1(V self, V *args);
V g_co_2eop_24s981909385x709882350_lam0(V self, V *args);
V g_co_2eop_24s981909385x709882350_lam2(V self, V *args);
V g_co_2eop_24s981909385x709882350_lam3(V self, V *args);
Clo g_co_2eop_24s981909385x709882350_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s981909385x709882350_entry, 5, 0};

V g_co_2eop_24s981909385x709882350(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_hd_244) {
top: ;
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s981909385x709882350_lam0, 2, 1, (V[]){heff_dup(v_hd_244)})}), heff_clo_n(g_co_2eop_24s981909385x709882350_lam2, 1, 1, (V[]){heff_dup(v_hd_244)}), v_p_243}));
  V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2410}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2411, heff_clo_n(g_co_2eop_24s981909385x709882350_lam3, 1, 3, (V[]){v_lit_240, v_lit_241, v_lit_242})});
}
V g_co_2eop_24s981909385x709882350_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s981909385x709882350(a[0], a[1], a[2], a[3], a[4]);
}
V g_co_2eop_24s981909385x709882350_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_247}));
  V f_ = heff_get_n(v_hd_244, 0, 3);
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s981909385x709882350_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_m_246 = args[1];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_m_246;
  args[1] = heff_clo_n(g_co_2eop_24s981909385x709882350_lam1, 1, 2, (V[]){v_g_245, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s981909385x709882350_lam2(V self, V *args) {
  V v_c_249 = args[0];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s981909385x709882350_lam3(V self, V *args) {
  V v_a_2412 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_drop(v_a_2412);
  heff_clo_take(self, 3);
  V v_x1_2413 = v_lit_240;
  V v_p_2414 = v_lit_241;
  V v_p_2415 = v_lit_242;
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_Nil: {
    heff_drop(v_p_2414);
    V f_ = v_p_2415;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_l_2416 = heff_field(v_x1_2413, 0);
    V v_rest_2417 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24Cons = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    V v_t_2418 = heff_tag_at_n(v_ru_24x1_2413_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_2416, ((V)&g_co_2eop_24s981909385x709882350_str0)), NTAG(TAG_MkUnit)});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s981909385x709882350(v_rest_2417, heff_dup(v_p_2414), v_p_2415, heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_p_2414));
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
Clo g_co_2eop_24s1412293101x300983667_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1412293101x300983667_entry, 3, 0};

V g_co_2eop_24s1412293101x300983667(V v_lit_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_malg_243 = heff_take_field(v_hd_241, 2);
  V v_bind_244 = heff_get_n(v_hd_241, 1, 3);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_lit_240})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(v_malg_243, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})}));
  return heff_tail(v_bind_244, 2, (V[]){v_t_2410, v_k2_242});
}
V g_co_2eop_24s1412293101x300983667_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1412293101x300983667(a[0], a[1], a[2]);
}
V g_co_2eop_24s677923597x1834241003_lam1(V self, V *args);
V g_co_2eop_24s677923597x1834241003_lam0(V self, V *args);
V g_co_2eop_24s677923597x1834241003_lam2(V self, V *args);
V g_co_2eop_24s677923597x1834241003_lam3(V self, V *args);
Clo g_co_2eop_24s677923597x1834241003_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s677923597x1834241003_entry, 9, 0};

V g_co_2eop_24s677923597x1834241003(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_p_247, V v_hd_248) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s677923597x1834241003_lam0, 2, 1, (V[]){heff_dup(v_hd_248)})}), heff_clo_n(g_co_2eop_24s677923597x1834241003_lam2, 1, 1, (V[]){heff_dup(v_hd_248)}), v_p_247}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_248, 1, 3), 2, (V[]){v_t_2415, heff_clo_n(g_co_2eop_24s677923597x1834241003_lam3, 1, 7, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246})});
}
V g_co_2eop_24s677923597x1834241003_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s677923597x1834241003(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_co_2eop_24s677923597x1834241003_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_248, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s677923597x1834241003_lam0(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_248, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s677923597x1834241003_lam1, 1, 2, (V[]){v_g_249, v_hd_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s677923597x1834241003_lam2(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_248);
  heff_room[1] = heff_get_n(v_hd_248, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s677923597x1834241003_lam3(V self, V *args) {
  V v_a_2416 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  V v_lit_246 = heff_env(self)[6];
  heff_drop(v_a_2416);
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eappsIn_24s1787642458x1317218323(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246));
}
HEFF_LIT(g_co_2eop_24s1525053243x1115082286_str0, 10, "not JSON, ");
V g_co_2eop_24s1525053243x1115082286_lam1(V self, V *args);
V g_co_2eop_24s1525053243x1115082286_lam0(V self, V *args);
V g_co_2eop_24s1525053243x1115082286_lam2(V self, V *args);
V g_co_2eop_24s1525053243x1115082286_lam4(V self, V *args); static Clo g_co_2eop_24s1525053243x1115082286_lam4_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1525053243x1115082286_lam4, 1, 0};
V g_co_2eop_24s1525053243x1115082286_lam5(V self, V *args);
V g_co_2eop_24s1525053243x1115082286_lam3(V self, V *args);
Clo g_co_2eop_24s1525053243x1115082286_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1525053243x1115082286_entry, 5, 0};

V g_co_2eop_24s1525053243x1115082286(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_hd_244) {
top: ;
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1525053243x1115082286_lam0, 2, 1, (V[]){heff_dup(v_hd_244)})}), heff_clo_n(g_co_2eop_24s1525053243x1115082286_lam2, 1, 1, (V[]){heff_dup(v_hd_244)}), v_p_243}));
  V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2410}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2411, heff_clo_n(g_co_2eop_24s1525053243x1115082286_lam3, 1, 3, (V[]){v_lit_240, v_lit_241, v_lit_242})});
}
V g_co_2eop_24s1525053243x1115082286_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1525053243x1115082286(a[0], a[1], a[2], a[3], a[4]);
}
V g_co_2eop_24s1525053243x1115082286_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_247}));
  V f_ = heff_get_n(v_hd_244, 0, 3);
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1525053243x1115082286_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_m_246 = args[1];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_m_246;
  args[1] = heff_clo_n(g_co_2eop_24s1525053243x1115082286_lam1, 1, 2, (V[]){v_g_245, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1525053243x1115082286_lam2(V self, V *args) {
  V v_c_249 = args[0];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1525053243x1115082286_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  return v_x_2418;
}
V g_co_2eop_24s1525053243x1115082286_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_ms_2413 = heff_env(self)[0];
  V v_p_2414 = heff_env(self)[1];
  V v_p_2415 = heff_env(self)[2];
  HeffT2 v_t_2424 = (g_heff_2elsp_2erpc_2eeventOf_24cpr(v_x_2423));
  {
    V v_field_2426 = v_t_2424.f[1];
    int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
    if ((v_tag_2425 == ((int64_t)0ULL))) {
      V v_x_2427 = v_field_2426;
      V v_t_2428 = heff_tag_n(TAG_Log, 2, (V[]){heff_strAppend(((V)&g_co_2eop_24s1525053243x1115082286_str0), v_x_2427), NTAG(TAG_MkUnit)});
      V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
      heff_clo_take(self, 3);
      return (g_co_2eop_24s1525053243x1115082286(v_ms_2413, heff_dup(v_p_2414), v_p_2415, v_t_2432, v_p_2414));
    } else {
      heff_clo_take(self, 3);
      heff_drop(v_ms_2413);
      heff_drop(v_p_2414);
      V v_y_2433 = v_field_2426;
      V f_ = v_p_2415;
      args[0] = v_y_2433;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_co_2eop_24s1525053243x1115082286_lam3(V self, V *args) {
  V v_a_2412 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_drop(v_a_2412);
  heff_clo_take(self, 3);
  V v_ms_2413 = v_lit_240;
  V v_p_2414 = v_lit_241;
  V v_p_2415 = v_lit_242;
  V v_t_2417;
  switch (heff_tag_of(v_ms_2413)) {
  case TAG_Nothing: {
    v_t_2417 = MK_INT(-1LL);
    break;
  }
  case TAG_Just: {
    V v_x_2416 = heff_dup(heff_field(v_ms_2413, 0));
    v_t_2417 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_ms_2413);
  }
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Await, 2, (V[]){v_t_2417, ((V)&g_co_2eop_24s1525053243x1115082286_lam4_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_p_2414), heff_clo_n(g_co_2eop_24s1525053243x1115082286_lam5, 1, 3, (V[]){v_ms_2413, v_p_2414, v_p_2415})));
}
V g_co_2eop_24s204600452x2025369236_lam1(V self, V *args);
V g_co_2eop_24s204600452x2025369236_lam0(V self, V *args);
V g_co_2eop_24s204600452x2025369236_lam2(V self, V *args);
V g_co_2eop_24s204600452x2025369236_lam3(V self, V *args);
Clo g_co_2eop_24s204600452x2025369236_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s204600452x2025369236_entry, 10, 0};

V g_co_2eop_24s204600452x2025369236(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_p_248, V v_hd_249) {
top: ;
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s204600452x2025369236_lam0, 2, 1, (V[]){heff_dup(v_hd_249)})}), heff_clo_n(g_co_2eop_24s204600452x2025369236_lam2, 1, 1, (V[]){heff_dup(v_hd_249)}), v_p_248}));
  V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2415}));
  return heff_tail(heff_get_n(v_hd_249, 1, 3), 2, (V[]){v_t_2416, heff_clo_n(g_co_2eop_24s204600452x2025369236_lam3, 1, 8, (V[]){v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_246, v_lit_247})});
}
V g_co_2eop_24s204600452x2025369236_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s204600452x2025369236(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_co_2eop_24s204600452x2025369236_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_249, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s204600452x2025369236_lam0(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_249, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s204600452x2025369236_lam1, 1, 2, (V[]){v_g_2410, v_hd_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s204600452x2025369236_lam2(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_get_n(v_hd_249, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s204600452x2025369236_lam3(V self, V *args) {
  V v_a_2417 = args[0];
  V v_lit_245 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  V v_lit_244 = heff_env(self)[5];
  V v_lit_246 = heff_env(self)[6];
  V v_lit_247 = heff_env(self)[7];
  V v_t_2419;
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_a_2417)) {
  case TAG_Nothing: {
    v_t_2419 = v_lit_245;
    break;
  }
  case TAG_Just: {
    V v_a_2418 = heff_field(v_a_2417, 0);
    heff_take_n(v_a_2417, 1ULL, 1);
    heff_drop(v_lit_245);
    v_t_2419 = v_a_2418;
    break;
  }
  default: heff_nomatch(v_a_2417);
  }
  return (g_app_2eheff_2emain_2echosenTo_24s1200348956x1843385244(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_t_2419, v_lit_246, v_lit_247));
}
V g_co_2eop_24s1314008918x267595320_lam1(V self, V *args);
V g_co_2eop_24s1314008918x267595320_lam0(V self, V *args);
V g_co_2eop_24s1314008918x267595320_lam2(V self, V *args);
V g_co_2eop_24s1314008918x267595320_lam3(V self, V *args);
Clo g_co_2eop_24s1314008918x267595320_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1314008918x267595320_entry, 3, 0};

V g_co_2eop_24s1314008918x267595320(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2411;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    v_t_2411 = heff_tag_re_n(v_ru_24p_240_24InL, TAG_InL, 1, 1ULL, (V[]){v_x_243});
    break;
  }
  case TAG_InR: {
    V v_y_244 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1505336972x898038096_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1314008918x267595320_lam0, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1314008918x267595320_lam2, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_244}));
    v_t_2411 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2410});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2412 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2411}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2412, heff_clo_n(g_co_2eop_24s1314008918x267595320_lam3, 1, 1, (V[]){v_k2_242})});
}
V g_co_2eop_24s1314008918x267595320_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1314008918x267595320(a[0], a[1], a[2]);
}
V g_co_2eop_24s1314008918x267595320_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_247}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1314008918x267595320_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_m_246 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_246;
  args[1] = heff_clo_n(g_co_2eop_24s1314008918x267595320_lam1, 1, 2, (V[]){v_g_245, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1314008918x267595320_lam2(V self, V *args) {
  V v_c_249 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1314008918x267595320_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_242;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}