// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Args 26338
#define TAG_Await 41810
#define TAG_Catch 6517
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_ErrColor 60683
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_Get 18914
#define TAG_GetEnv 43934
#define TAG_IsTerminal 53507
#define TAG_Log 24016
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_Platform 55558
#define TAG_ProgramPath 46819
#define TAG_ProjectFiles 9175
#define TAG_Put 28059
#define TAG_Quit 47258
#define TAG_ReadStdin 20528
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_Send 26077
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_UriPath 39251
#define TAG_UseColor 15915
#define TAG_WorkingDir 28879
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_bind 9519364
#define LBL_fmap 9641981
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_ret 322331
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
V g_co_2ebind_24s1601686549x58384075(V, V, V, V);
V g_co_2ebind_24s1601686549x58384075_entry(V self, V *a);
extern Clo g_co_2ebind_24s1601686549x58384075_clo;
V g_co_2ebind_24s935789828x1526377372(V, V, V);
V g_co_2ebind_24s935789828x1526377372_entry(V self, V *a);
extern Clo g_co_2ebind_24s935789828x1526377372_clo;
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s1106850457x559991957(V, V, V);
V g_co_2eop_24s1106850457x559991957_entry(V self, V *a);
extern Clo g_co_2eop_24s1106850457x559991957_clo;
V g_co_2eop_24s1279463522x45159155(V, V, V, V);
V g_co_2eop_24s1279463522x45159155_entry(V self, V *a);
extern Clo g_co_2eop_24s1279463522x45159155_clo;
V g_co_2eop_24s1289826976x294500243(V, V, V);
V g_co_2eop_24s1289826976x294500243_entry(V self, V *a);
extern Clo g_co_2eop_24s1289826976x294500243_clo;
V g_co_2eop_24s1344776583x1328086698(V, V);
V g_co_2eop_24s1344776583x1328086698_entry(V self, V *a);
extern Clo g_co_2eop_24s1344776583x1328086698_clo;
V g_co_2eop_24s15141126x503873151(V, V, V, V);
V g_co_2eop_24s15141126x503873151_entry(V self, V *a);
extern Clo g_co_2eop_24s15141126x503873151_clo;
V g_co_2eop_24s1532701784x592895222(V, V, V);
V g_co_2eop_24s1532701784x592895222_entry(V self, V *a);
extern Clo g_co_2eop_24s1532701784x592895222_clo;
V g_co_2eop_24s1802027244x918867378(V, V, V);
V g_co_2eop_24s1802027244x918867378_entry(V self, V *a);
extern Clo g_co_2eop_24s1802027244x918867378_clo;
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_co_2eop_24s322634793x1879077828(V, V, V);
V g_co_2eop_24s322634793x1879077828_entry(V self, V *a);
extern Clo g_co_2eop_24s322634793x1879077828_clo;
V g_co_2eop_24s384550787x906982552(V, V, V);
V g_co_2eop_24s384550787x906982552_entry(V self, V *a);
extern Clo g_co_2eop_24s384550787x906982552_clo;
V g_co_2eop_24s504905999x685316098(V, V, V);
V g_co_2eop_24s504905999x685316098_entry(V self, V *a);
extern Clo g_co_2eop_24s504905999x685316098_clo;
V g_co_2eop_24s635711115x1057317164(V, V);
V g_co_2eop_24s635711115x1057317164_entry(V self, V *a);
extern Clo g_co_2eop_24s635711115x1057317164_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_co_2eplus_24s1100180636x1646925226_get(void);
V g_co_2eplus_24s1472866478x1491968207_get(void);
V g_co_2eplus_24s1578688711x396965871_get(void);
V g_co_2eplus_24s645371449x668519272_get(void);
V g_co_2eplus_24s704070075x794314310_get(void);
V g_co_2eplus_24s892172295x222364517_get(void);
V g_heff_2elsp_2erpc_2erpc_get(void);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s410120642x105714730(V, V);
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a);
extern Clo g_list_2efoldl_24s410120642x105714730_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_std_2efilesystem_2efs_get(void);
V g_std_2eprocess_2eprocess_get(void);
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_get(void);
V g_std_2eprogress_2eprogress_get(void);
V g_std_2eprogress_2equietly_24s1392860441x1460275359(V);
V g_std_2eprogress_2equietly_24s1392860441x1460275359_entry(V self, V *a);
extern Clo g_std_2eprogress_2equietly_24s1392860441x1460275359_clo;
V g_co_2eop_24s310169282x2049378029_lam1(V self, V *args);
V g_co_2eop_24s310169282x2049378029_lam0(V self, V *args); static Clo g_co_2eop_24s310169282x2049378029_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s310169282x2049378029_lam0, 4, 0};
V g_co_2eop_24s310169282x2049378029_lam3(V self, V *args);
V g_co_2eop_24s310169282x2049378029_lam2(V self, V *args);
V g_co_2eop_24s310169282x2049378029_lam4(V self, V *args);
Clo g_co_2eop_24s310169282x2049378029_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s310169282x2049378029_entry, 4, 0};

V g_co_2eop_24s310169282x2049378029(V v_h_240, V v_p_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2415 = heff_tr(heff_call(heff_get_n(v_h_240, 1, 2), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s310169282x2049378029_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s310169282x2049378029_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s310169282x2049378029_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_p_241}));
  V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2415}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2416, v_k2_243});
}
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s310169282x2049378029(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s310169282x2049378029_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s310169282x2049378029_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s310169282x2049378029_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s310169282x2049378029_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s310169282x2049378029_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s310169282x2049378029_lam3, 1, 2, (V[]){v_g_2410, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s310169282x2049378029_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1802027244x918867378_lam0(V self, V *args);
Clo g_co_2eop_24s1802027244x918867378_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1802027244x918867378_entry, 3, 0};

V g_co_2eop_24s1802027244x918867378(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2416;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Get: {
      V v_k_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      v_t_247 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_Get, 1, (V[]){v_k_244});
      break;
    }
    case TAG_Put: {
      V v_st_245 = heff_field(v_x_243, 0);
      V v_x_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Put = heff_take_reuse_n(v_x_243, 3ULL, 2);
      heff_drop_cell(v_ru_24p_240_24InL, 1);
      v_t_247 = heff_tag_at_n(v_ru_24x_243_24Put, TAG_Put, 2, (V[]){v_st_245, v_x_246});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){v_t_247});
    break;
  }
  case TAG_InR: {
    V v_y_248 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2415;
    switch (heff_tag_of(v_y_248)) {
    case TAG_Throw: {
      V v_s_249 = heff_field(v_y_248, 0);
      heff_take_n(v_y_248, 1ULL, 1);
      v_t_2415 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_Throw, 1, (V[]){v_s_249});
      break;
    }
    case TAG_Catch: {
      V v_c_2410 = heff_field(v_y_248, 0);
      V v_h_2411 = heff_field(v_y_248, 1);
      V v_ru_24y_248_24Catch = heff_take_reuse_n(v_y_248, 3ULL, 2);
      heff_drop_cell(v_ru_24p_240_24InR, 1);
      V v_t_2412 = heff_tr(heff_call(v_c_2410, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2415 = heff_tag_at_n(v_ru_24y_248_24Catch, TAG_Catch, 2, (V[]){v_t_2412, heff_clo_n(g_co_2eop_24s1802027244x918867378_lam0, 1, 2, (V[]){v_h_2411, heff_dup(v_hd_241)})});
      break;
    }
    default: heff_nomatch(v_y_248);
    }
    v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2415});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2417, v_k2_242});
}
V g_co_2eop_24s1802027244x918867378_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1802027244x918867378(a[0], a[1], a[2]);
}
V g_co_2eop_24s1802027244x918867378_lam0(V self, V *args) {
  V v_s_2413 = args[0];
  V v_h_2411 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2414 = heff_tr(heff_call(v_h_2411, 1, (V[]){v_s_2413}));
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1532701784x592895222_lam0(V self, V *args);
Clo g_co_2eop_24s1532701784x592895222_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1532701784x592895222_entry, 3, 0};

V g_co_2eop_24s1532701784x592895222(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2416;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Get: {
      V v_k_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      v_t_247 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_Get, 1, (V[]){v_k_244});
      break;
    }
    case TAG_Put: {
      V v_st_245 = heff_field(v_x_243, 0);
      V v_x_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Put = heff_take_reuse_n(v_x_243, 3ULL, 2);
      heff_drop_cell(v_ru_24p_240_24InL, 1);
      v_t_247 = heff_tag_at_n(v_ru_24x_243_24Put, TAG_Put, 2, (V[]){v_st_245, v_x_246});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){v_t_247});
    break;
  }
  case TAG_InR: {
    V v_y_248 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2415;
    switch (heff_tag_of(v_y_248)) {
    case TAG_Throw: {
      V v_s_249 = heff_field(v_y_248, 0);
      heff_take_n(v_y_248, 1ULL, 1);
      v_t_2415 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_Throw, 1, (V[]){v_s_249});
      break;
    }
    case TAG_Catch: {
      V v_c_2410 = heff_field(v_y_248, 0);
      V v_h_2411 = heff_field(v_y_248, 1);
      V v_ru_24y_248_24Catch = heff_take_reuse_n(v_y_248, 3ULL, 2);
      heff_drop_cell(v_ru_24p_240_24InR, 1);
      V v_t_2412 = heff_tr(heff_call(v_c_2410, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2415 = heff_tag_at_n(v_ru_24y_248_24Catch, TAG_Catch, 2, (V[]){v_t_2412, heff_clo_n(g_co_2eop_24s1532701784x592895222_lam0, 1, 2, (V[]){v_h_2411, heff_dup(v_hd_241)})});
      break;
    }
    default: heff_nomatch(v_y_248);
    }
    v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2415});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2417, v_k2_242});
}
V g_co_2eop_24s1532701784x592895222_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1532701784x592895222(a[0], a[1], a[2]);
}
V g_co_2eop_24s1532701784x592895222_lam0(V self, V *args) {
  V v_s_2413 = args[0];
  V v_h_2411 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2414 = heff_tr(heff_call(v_h_2411, 1, (V[]){v_s_2413}));
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eplus_24s645371449x668519272_lam1(V self, V *args);
V g_co_2eplus_24s645371449x668519272_lam2(V self, V *args);
V g_co_2eplus_24s645371449x668519272_lam0(V self, V *args); static Clo g_co_2eplus_24s645371449x668519272_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s645371449x668519272_lam0, 3, 0};
V g_co_2eplus_24s645371449x668519272_lam4(V self, V *args);
V g_co_2eplus_24s645371449x668519272_lam3(V self, V *args); static Clo g_co_2eplus_24s645371449x668519272_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s645371449x668519272_lam3, 4, 0};

static V g_co_2eplus_24s645371449x668519272_val;
static HEFF_ONCE g_co_2eplus_24s645371449x668519272_st;
static V g_co_2eplus_24s645371449x668519272_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s645371449x668519272_lam0_clo), ((V)&g_co_2eplus_24s645371449x668519272_lam3_clo)});
}
V g_co_2eplus_24s645371449x668519272_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s645371449x668519272_st)) return g_co_2eplus_24s645371449x668519272_val;
  return heff_global(&g_co_2eplus_24s645371449x668519272_val, &g_co_2eplus_24s645371449x668519272_st, g_co_2eplus_24s645371449x668519272_init);
}
V g_co_2eplus_24s645371449x668519272_lam1(V self, V *args) {
  V v_st_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_k_244, 1, (V[]){v_st_245}));
  V f_ = v_g_241;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s645371449x668519272_lam2(V self, V *args) {
  V v_s_2416 = args[0];
  V v_h_2414 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_tr(heff_call(v_h_2414, 1, (V[]){v_s_2416}));
  V f_ = heff_get_n(v_m_240, 0, 1);
  heff_room[0] = v_g_241;
  heff_room[1] = v_t_2417;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eplus_24s645371449x668519272_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop_rec(v_m_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Get: {
      V v_k_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_Get, 1, (V[]){heff_clo_n(g_co_2eplus_24s645371449x668519272_lam1, 1, 2, (V[]){v_k_244, v_g_241})});
      break;
    }
    case TAG_Put: {
      V v_st_247 = heff_field(v_x_243, 0);
      V v_x_248 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Put = heff_take_reuse_n(v_x_243, 3ULL, 2);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_249 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_248}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Put, TAG_Put, 2, (V[]){v_st_247, v_t_249});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2410});
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_y_2411)) {
    case TAG_Throw: {
      V v_s_2412 = heff_field(v_y_2411, 0);
      heff_take_n(v_y_2411, 1ULL, 1);
      heff_drop_rec(v_m_240, 1);
      heff_drop(v_g_241);
      v_t_2418 = heff_tag_at_n(v_ru_24p_242_24InR, TAG_Throw, 1, (V[]){v_s_2412});
      break;
    }
    case TAG_Catch: {
      V v_c_2413 = heff_field(v_y_2411, 0);
      V v_h_2414 = heff_field(v_y_2411, 1);
      V v_ru_24y_2411_24Catch = heff_take_reuse_n(v_y_2411, 3ULL, 2);
      heff_drop_cell(v_ru_24p_242_24InR, 1);
      V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 2, (V[]){heff_dup(v_g_241), v_c_2413}));
      v_t_2418 = heff_tag_at_n(v_ru_24y_2411_24Catch, TAG_Catch, 2, (V[]){v_t_2415, heff_clo_n(g_co_2eplus_24s645371449x668519272_lam2, 1, 3, (V[]){v_h_2414, v_m_240, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_2411);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s645371449x668519272_lam4(V self, V *args) {
  V v_s_2433 = args[0];
  V v_h_2431 = heff_env(self)[0];
  V v_nt_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_tr(heff_call(v_h_2431, 1, (V[]){v_s_2433}));
  V f_ = v_nt_2421;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s645371449x668519272_lam3(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  heff_drop(v_m_2419);
  heff_drop(v_n_2420);
  switch (heff_tag_of(v_p_2422)) {
  case TAG_InL: {
    V v_x_2423 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InL = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_nt_2421);
    V v_t_2427;
    switch (heff_tag_of(v_x_2423)) {
    case TAG_Get: {
      V v_k_2424 = heff_field(v_x_2423, 0);
      heff_take_n(v_x_2423, 1ULL, 1);
      v_t_2427 = heff_tag_at_n(v_ru_24p_2422_24InL, TAG_Get, 1, (V[]){v_k_2424});
      break;
    }
    case TAG_Put: {
      V v_st_2425 = heff_field(v_x_2423, 0);
      V v_x_2426 = heff_field(v_x_2423, 1);
      V v_ru_24x_2423_24Put = heff_take_reuse_n(v_x_2423, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2422_24InL, 1);
      v_t_2427 = heff_tag_at_n(v_ru_24x_2423_24Put, TAG_Put, 2, (V[]){v_st_2425, v_x_2426});
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2427});
  }
  case TAG_InR: {
    V v_y_2428 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InR = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    V v_t_2435;
    switch (heff_tag_of(v_y_2428)) {
    case TAG_Throw: {
      V v_s_2429 = heff_field(v_y_2428, 0);
      heff_take_n(v_y_2428, 1ULL, 1);
      heff_drop(v_nt_2421);
      v_t_2435 = heff_tag_at_n(v_ru_24p_2422_24InR, TAG_Throw, 1, (V[]){v_s_2429});
      break;
    }
    case TAG_Catch: {
      V v_c_2430 = heff_field(v_y_2428, 0);
      V v_h_2431 = heff_field(v_y_2428, 1);
      V v_ru_24y_2428_24Catch = heff_take_reuse_n(v_y_2428, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2422_24InR, 1);
      V v_t_2432 = heff_tr(heff_call(heff_dup(v_nt_2421), 1, (V[]){v_c_2430}));
      v_t_2435 = heff_tag_at_n(v_ru_24y_2428_24Catch, TAG_Catch, 2, (V[]){v_t_2432, heff_clo_n(g_co_2eplus_24s645371449x668519272_lam4, 1, 2, (V[]){v_h_2431, v_nt_2421})});
      break;
    }
    default: heff_nomatch(v_y_2428);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2435});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_co_2ebind_24s1601686549x58384075_lam0(V self, V *args);
Clo g_co_2ebind_24s1601686549x58384075_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1601686549x58384075_entry, 4, 0};

V g_co_2ebind_24s1601686549x58384075(V v_c_240, V v_f_241, V v_hd_242, V v_k_243) {
top: ;
  return heff_tail(v_c_240, 2, (V[]){heff_dup(v_hd_242), heff_clo_n(g_co_2ebind_24s1601686549x58384075_lam0, 1, 3, (V[]){v_f_241, v_hd_242, v_k_243})});
}
V g_co_2ebind_24s1601686549x58384075_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s1601686549x58384075(a[0], a[1], a[2], a[3]);
}
V g_co_2ebind_24s1601686549x58384075_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_f_241;
  heff_room[0] = v_x_244;
  heff_room[1] = v_hd_242;
  heff_room[2] = v_k_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2ebind_24s935789828x1526377372_lam0(V self, V *args); static Clo g_co_2ebind_24s935789828x1526377372_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s935789828x1526377372_lam0, 1, 0};
V g_co_2ebind_24s935789828x1526377372_lam1(V self, V *args);
Clo g_co_2ebind_24s935789828x1526377372_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s935789828x1526377372_entry, 3, 0};

V g_co_2ebind_24s935789828x1526377372(V v_f_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_co_2ebind_24s935789828x1526377372_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_249, heff_clo_n(g_co_2ebind_24s935789828x1526377372_lam1, 1, 3, (V[]){v_f_240, v_hd_241, v_k_242})});
}
V g_co_2ebind_24s935789828x1526377372_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s935789828x1526377372(a[0], a[1], a[2]);
}
V g_co_2ebind_24s935789828x1526377372_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_t_244 = ({ V b_0 = heff_get_n(v_c_243, 3, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = (g_list_2emap_24s366344330x1145113647(v_t_244));
  V v_xs_246 = (g_list_2efoldl_24s410120642x105714730(NTAG(TAG_Nil), v_t_245));
  return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
}
V g_co_2ebind_24s935789828x1526377372_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_f_240;
  heff_room[0] = v_x_2410;
  heff_room[1] = v_hd_241;
  heff_room[2] = v_k_242;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eplus_24s892172295x222364517_lam1(V self, V *args);
V g_co_2eplus_24s892172295x222364517_lam0(V self, V *args); static Clo g_co_2eplus_24s892172295x222364517_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s892172295x222364517_lam0, 3, 0};
V g_co_2eplus_24s892172295x222364517_lam2(V self, V *args); static Clo g_co_2eplus_24s892172295x222364517_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s892172295x222364517_lam2, 4, 0};

static V g_co_2eplus_24s892172295x222364517_val;
static HEFF_ONCE g_co_2eplus_24s892172295x222364517_st;
static V g_co_2eplus_24s892172295x222364517_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s892172295x222364517_lam0_clo), ((V)&g_co_2eplus_24s892172295x222364517_lam2_clo)});
}
V g_co_2eplus_24s892172295x222364517_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s892172295x222364517_st)) return g_co_2eplus_24s892172295x222364517_val;
  return heff_global(&g_co_2eplus_24s892172295x222364517_val, &g_co_2eplus_24s892172295x222364517_st, g_co_2eplus_24s892172295x222364517_init);
}
V g_co_2eplus_24s892172295x222364517_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_s_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s892172295x222364517_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_m_240);
    V v_t_2413;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Write: {
      V v_str_244 = heff_field(v_x_243, 0);
      V v_x_245 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Write = heff_take_reuse_n(v_x_243, 3ULL, 2);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_246 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_245}));
      v_t_2413 = heff_tag_at_n(v_ru_24x_243_24Write, TAG_Write, 2, (V[]){v_str_244, v_t_246});
      break;
    }
    case TAG_WriteErr: {
      V v_str_247 = heff_field(v_x_243, 0);
      V v_x_248 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24WriteErr = heff_take_reuse_n(v_x_243, 3ULL, 2);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_249 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_248}));
      v_t_2413 = heff_tag_at_n(v_ru_24x_243_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_247, v_t_249});
      break;
    }
    case TAG_ReadStdin: {
      V v_k_2410 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      v_t_2413 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_ReadStdin, 1, (V[]){heff_clo_n(g_co_2eplus_24s892172295x222364517_lam1, 1, 2, (V[]){v_k_2410, v_g_241})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2413});
  }
  case TAG_InR: {
    V v_y_2414 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprocess_2eprocess_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2414}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2415});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s892172295x222364517_lam2(V self, V *args) {
  V v_m_2416 = args[0];
  V v_n_2417 = args[1];
  V v_nt_2418 = args[2];
  V v_p_2419 = args[3];
  heff_drop(v_m_2416);
  heff_drop(v_n_2417);
  heff_drop(v_nt_2418);
  switch (heff_tag_of(v_p_2419)) {
  case TAG_InL: {
    V v_x_2420 = heff_field(v_p_2419, 0);
    V v_ru_24p_2419_24InL = heff_take_reuse_n(v_p_2419, 1ULL, 1);
    V v_t_2426;
    switch (heff_tag_of(v_x_2420)) {
    case TAG_Write: {
      V v_str_2421 = heff_field(v_x_2420, 0);
      V v_x_2422 = heff_field(v_x_2420, 1);
      V v_ru_24x_2420_24Write = heff_take_reuse_n(v_x_2420, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2419_24InL, 1);
      v_t_2426 = heff_tag_at_n(v_ru_24x_2420_24Write, TAG_Write, 2, (V[]){v_str_2421, v_x_2422});
      break;
    }
    case TAG_WriteErr: {
      V v_str_2423 = heff_field(v_x_2420, 0);
      V v_x_2424 = heff_field(v_x_2420, 1);
      V v_ru_24x_2420_24WriteErr = heff_take_reuse_n(v_x_2420, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2419_24InL, 1);
      v_t_2426 = heff_tag_at_n(v_ru_24x_2420_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_2423, v_x_2424});
      break;
    }
    case TAG_ReadStdin: {
      V v_k_2425 = heff_field(v_x_2420, 0);
      heff_take_n(v_x_2420, 1ULL, 1);
      v_t_2426 = heff_tag_at_n(v_ru_24p_2419_24InL, TAG_ReadStdin, 1, (V[]){v_k_2425});
      break;
    }
    default: heff_nomatch(v_x_2420);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2426});
  }
  case TAG_InR: {
    V v_y_2427 = heff_field(v_p_2419, 0);
    V v_ru_24p_2419_24InR = heff_take_reuse_n(v_p_2419, 1ULL, 1);
    V v_t_2442;
    switch (heff_tag_of(v_y_2427)) {
    case TAG_Args: {
      V v_k_2428 = heff_field(v_y_2427, 0);
      heff_take_n(v_y_2427, 1ULL, 1);
      v_t_2442 = heff_tag_at_n(v_ru_24p_2419_24InR, TAG_Args, 1, (V[]){v_k_2428});
      break;
    }
    case TAG_GetEnv: {
      V v_name_2429 = heff_field(v_y_2427, 0);
      V v_k_2430 = heff_field(v_y_2427, 1);
      V v_ru_24y_2427_24GetEnv = heff_take_reuse_n(v_y_2427, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2419_24InR, 1);
      v_t_2442 = heff_tag_at_n(v_ru_24y_2427_24GetEnv, TAG_GetEnv, 2, (V[]){v_name_2429, v_k_2430});
      break;
    }
    case TAG_ProgramPath: {
      V v_k_2431 = heff_field(v_y_2427, 0);
      heff_take_n(v_y_2427, 1ULL, 1);
      v_t_2442 = heff_tag_at_n(v_ru_24p_2419_24InR, TAG_ProgramPath, 1, (V[]){v_k_2431});
      break;
    }
    case TAG_WorkingDir: {
      V v_k_2432 = heff_field(v_y_2427, 0);
      heff_take_n(v_y_2427, 1ULL, 1);
      v_t_2442 = heff_tag_at_n(v_ru_24p_2419_24InR, TAG_WorkingDir, 1, (V[]){v_k_2432});
      break;
    }
    case TAG_Platform: {
      V v_k_2433 = heff_field(v_y_2427, 0);
      heff_take_n(v_y_2427, 1ULL, 1);
      v_t_2442 = heff_tag_at_n(v_ru_24p_2419_24InR, TAG_Platform, 1, (V[]){v_k_2433});
      break;
    }
    case TAG_Exit: {
      V v_code_2434 = heff_field(v_y_2427, 0);
      V v_x_2435 = heff_field(v_y_2427, 1);
      V v_ru_24y_2427_24Exit = heff_take_reuse_n(v_y_2427, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2419_24InR, 1);
      v_t_2442 = heff_tag_at_n(v_ru_24y_2427_24Exit, TAG_Exit, 2, (V[]){v_code_2434, v_x_2435});
      break;
    }
    case TAG_Exec: {
      V v_cmd_2436 = heff_field(v_y_2427, 0);
      V v_as_2437 = heff_field(v_y_2427, 1);
      V v_x_2438 = heff_field(v_y_2427, 2);
      V v_ru_24y_2427_24Exec = heff_take_reuse_n(v_y_2427, 7ULL, 3);
      heff_drop_cell(v_ru_24p_2419_24InR, 1);
      v_t_2442 = heff_tag_at_n(v_ru_24y_2427_24Exec, TAG_Exec, 3, (V[]){v_cmd_2436, v_as_2437, v_x_2438});
      break;
    }
    case TAG_Run: {
      V v_cmd_2439 = heff_field(v_y_2427, 0);
      V v_as_2440 = heff_field(v_y_2427, 1);
      V v_k_2441 = heff_field(v_y_2427, 2);
      V v_ru_24y_2427_24Run = heff_take_reuse_n(v_y_2427, 7ULL, 3);
      heff_drop_cell(v_ru_24p_2419_24InR, 1);
      v_t_2442 = heff_tag_at_n(v_ru_24y_2427_24Run, TAG_Run, 3, (V[]){v_cmd_2439, v_as_2440, v_k_2441});
      break;
    }
    default: heff_nomatch(v_y_2427);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2442});
  }
  default: return heff_nomatch(v_p_2419);
  }
}
V g_co_2eplus_24s1472866478x1491968207_lam1(V self, V *args);
V g_co_2eplus_24s1472866478x1491968207_lam0(V self, V *args); static Clo g_co_2eplus_24s1472866478x1491968207_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1472866478x1491968207_lam0, 3, 0};
V g_co_2eplus_24s1472866478x1491968207_lam2(V self, V *args); static Clo g_co_2eplus_24s1472866478x1491968207_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1472866478x1491968207_lam2, 4, 0};

static V g_co_2eplus_24s1472866478x1491968207_val;
static HEFF_ONCE g_co_2eplus_24s1472866478x1491968207_st;
static V g_co_2eplus_24s1472866478x1491968207_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1472866478x1491968207_lam0_clo), ((V)&g_co_2eplus_24s1472866478x1491968207_lam2_clo)});
}
V g_co_2eplus_24s1472866478x1491968207_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s1472866478x1491968207_st)) return g_co_2eplus_24s1472866478x1491968207_val;
  return heff_global(&g_co_2eplus_24s1472866478x1491968207_val, &g_co_2eplus_24s1472866478x1491968207_st, g_co_2eplus_24s1472866478x1491968207_init);
}
V g_co_2eplus_24s1472866478x1491968207_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_k_2411, 1, (V[]){v_s_2412}));
  V f_ = v_g_241;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1472866478x1491968207_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InL = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_m_240);
      V v_t_2414;
      switch (heff_tag_of(v_x_244)) {
      case TAG_Write: {
        V v_str_245 = heff_field(v_x_244, 0);
        V v_x_246 = heff_field(v_x_244, 1);
        V v_ru_24x_244_24Write = heff_take_reuse_n(v_x_244, 3ULL, 2);
        heff_drop_cell(v_ru_24p_242_24InL, 1);
        V v_t_247 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_246}));
        v_t_2414 = heff_tag_at_n(v_ru_24x_244_24Write, TAG_Write, 2, (V[]){v_str_245, v_t_247});
        break;
      }
      case TAG_WriteErr: {
        V v_str_248 = heff_field(v_x_244, 0);
        V v_x_249 = heff_field(v_x_244, 1);
        V v_ru_24x_244_24WriteErr = heff_take_reuse_n(v_x_244, 3ULL, 2);
        heff_drop_cell(v_ru_24p_242_24InL, 1);
        V v_t_2410 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_249}));
        v_t_2414 = heff_tag_at_n(v_ru_24x_244_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_248, v_t_2410});
        break;
      }
      case TAG_ReadStdin: {
        V v_k_2411 = heff_field(v_x_244, 0);
        heff_take_n(v_x_244, 1ULL, 1);
        v_t_2414 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_ReadStdin, 1, (V[]){heff_clo_n(g_co_2eplus_24s1472866478x1491968207_lam1, 1, 2, (V[]){v_k_2411, v_g_241})});
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      v_t_2417 = heff_tag_at_n(v_ru_24x_243_24InL, TAG_InL, 1, (V[]){v_t_2414});
      break;
    }
    case TAG_InR: {
      V v_y_2415 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprocess_2eprocess_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2415}));
      v_t_2417 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InR, 1, (V[]){v_t_2416});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2417});
  }
  case TAG_InR: {
    V v_y_2418 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efs_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2418}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1472866478x1491968207_lam2(V self, V *args) {
  V v_m_2420 = args[0];
  V v_n_2421 = args[1];
  V v_nt_2422 = args[2];
  V v_p_2423 = args[3];
  switch (heff_tag_of(v_p_2423)) {
  case TAG_InL: {
    V v_x_2424 = heff_field(v_p_2423, 0);
    V v_ru_24p_2423_24InL = heff_take_reuse_n(v_p_2423, 1ULL, 1);
    V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s892172295x222364517_get(), 1)), 4, (V[]){v_m_2420, v_n_2421, v_nt_2422, v_x_2424}));
    return heff_tag_at_n(v_ru_24p_2423_24InL, TAG_InL, 1, (V[]){v_t_2425});
  }
  case TAG_InR: {
    V v_y_2426 = heff_field(v_p_2423, 0);
    V v_ru_24p_2423_24InR = heff_take_reuse_n(v_p_2423, 1ULL, 1);
    V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efs_get(), 1)), 4, (V[]){v_m_2420, v_n_2421, v_nt_2422, v_y_2426}));
    return heff_tag_at_n(v_ru_24p_2423_24InR, TAG_InR, 1, (V[]){v_t_2427});
  }
  default: return heff_nomatch(v_p_2423);
  }
}
V g_co_2eplus_24s1100180636x1646925226_lam1(V self, V *args);
V g_co_2eplus_24s1100180636x1646925226_lam2(V self, V *args);
V g_co_2eplus_24s1100180636x1646925226_lam0(V self, V *args); static Clo g_co_2eplus_24s1100180636x1646925226_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1100180636x1646925226_lam0, 3, 0};
V g_co_2eplus_24s1100180636x1646925226_lam3(V self, V *args); static Clo g_co_2eplus_24s1100180636x1646925226_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1100180636x1646925226_lam3, 4, 0};

static V g_co_2eplus_24s1100180636x1646925226_val;
static HEFF_ONCE g_co_2eplus_24s1100180636x1646925226_st;
static V g_co_2eplus_24s1100180636x1646925226_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1100180636x1646925226_lam0_clo), ((V)&g_co_2eplus_24s1100180636x1646925226_lam3_clo)});
}
V g_co_2eplus_24s1100180636x1646925226_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s1100180636x1646925226_st)) return g_co_2eplus_24s1100180636x1646925226_val;
  return heff_global(&g_co_2eplus_24s1100180636x1646925226_val, &g_co_2eplus_24s1100180636x1646925226_st, g_co_2eplus_24s1100180636x1646925226_init);
}
V g_co_2eplus_24s1100180636x1646925226_lam1(V self, V *args) {
  V v_b_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tr(heff_call(v_k_247, 1, (V[]){v_b_248}));
  V f_ = v_g_241;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1100180636x1646925226_lam2(V self, V *args) {
  V v_b_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_b_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1100180636x1646925226_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1472866478x1491968207_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_244}));
      v_t_2414 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_245});
      break;
    }
    case TAG_InR: {
      V v_y_246 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_m_240);
      V v_t_2413;
      switch (heff_tag_of(v_y_246)) {
      case TAG_UseColor: {
        V v_k_247 = heff_field(v_y_246, 0);
        heff_take_n(v_y_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_UseColor, 1, (V[]){heff_clo_n(g_co_2eplus_24s1100180636x1646925226_lam1, 1, 2, (V[]){v_k_247, v_g_241})});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2410 = heff_field(v_y_246, 0);
        heff_take_n(v_y_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_ErrColor, 1, (V[]){heff_clo_n(g_co_2eplus_24s1100180636x1646925226_lam2, 1, 2, (V[]){v_k_2410, v_g_241})});
        break;
      }
      default: heff_nomatch(v_y_246);
      }
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2413});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2414});
  }
  case TAG_InR: {
    V v_y_2415 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2415}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2416});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1100180636x1646925226_lam3(V self, V *args) {
  V v_m_2417 = args[0];
  V v_n_2418 = args[1];
  V v_nt_2419 = args[2];
  V v_p_2420 = args[3];
  switch (heff_tag_of(v_p_2420)) {
  case TAG_InL: {
    V v_x_2421 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InL = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    V v_t_2432;
    switch (heff_tag_of(v_x_2421)) {
    case TAG_InL: {
      V v_x_2422 = heff_field(v_x_2421, 0);
      V v_ru_24x_2421_24InL = heff_take_reuse_n(v_x_2421, 1ULL, 1);
      V v_t_2427;
      switch (heff_tag_of(v_x_2422)) {
      case TAG_InL: {
        V v_x_2423 = heff_field(v_x_2422, 0);
        heff_take_n(v_x_2422, 1ULL, 1);
        V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s892172295x222364517_get(), 1)), 4, (V[]){v_m_2417, v_n_2418, v_nt_2419, v_x_2423}));
        v_t_2427 = heff_tag_at_n(v_ru_24p_2420_24InL, TAG_InL, 1, (V[]){v_t_2424});
        break;
      }
      case TAG_InR: {
        V v_y_2425 = heff_field(v_x_2422, 0);
        heff_take_n(v_x_2422, 1ULL, 1);
        V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efs_get(), 1)), 4, (V[]){v_m_2417, v_n_2418, v_nt_2419, v_y_2425}));
        v_t_2427 = heff_tag_at_n(v_ru_24p_2420_24InL, TAG_InR, 1, (V[]){v_t_2426});
        break;
      }
      default: heff_nomatch(v_x_2422);
      }
      v_t_2432 = heff_tag_at_n(v_ru_24x_2421_24InL, TAG_InL, 1, (V[]){v_t_2427});
      break;
    }
    case TAG_InR: {
      V v_y_2428 = heff_field(v_x_2421, 0);
      V v_ru_24x_2421_24InR = heff_take_reuse_n(v_x_2421, 1ULL, 1);
      heff_drop(v_m_2417);
      heff_drop(v_n_2418);
      heff_drop(v_nt_2419);
      V v_t_2431;
      switch (heff_tag_of(v_y_2428)) {
      case TAG_UseColor: {
        V v_k_2429 = heff_field(v_y_2428, 0);
        heff_take_n(v_y_2428, 1ULL, 1);
        v_t_2431 = heff_tag_at_n(v_ru_24p_2420_24InL, TAG_UseColor, 1, (V[]){v_k_2429});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2430 = heff_field(v_y_2428, 0);
        heff_take_n(v_y_2428, 1ULL, 1);
        v_t_2431 = heff_tag_at_n(v_ru_24p_2420_24InL, TAG_ErrColor, 1, (V[]){v_k_2430});
        break;
      }
      default: heff_nomatch(v_y_2428);
      }
      v_t_2432 = heff_tag_at_n(v_ru_24x_2421_24InR, TAG_InR, 1, (V[]){v_t_2431});
      break;
    }
    default: heff_nomatch(v_x_2421);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2432});
  }
  case TAG_InR: {
    V v_y_2433 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InR = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    heff_drop(v_m_2417);
    heff_drop(v_n_2418);
    heff_drop(v_nt_2419);
    V v_t_2450;
    switch (heff_tag_of(v_y_2433)) {
    case TAG_Await: {
      V v_t_2434 = heff_field(v_y_2433, 0);
      V v_k_2435 = heff_field(v_y_2433, 1);
      V v_ru_24y_2433_24Await = heff_take_reuse_n(v_y_2433, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2420_24InR, 1);
      v_t_2450 = heff_tag_at_n(v_ru_24y_2433_24Await, TAG_Await, 2, (V[]){v_t_2434, v_k_2435});
      break;
    }
    case TAG_Send: {
      V v_s_2436 = heff_field(v_y_2433, 0);
      V v_x_2437 = heff_field(v_y_2433, 1);
      V v_ru_24y_2433_24Send = heff_take_reuse_n(v_y_2433, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2420_24InR, 1);
      v_t_2450 = heff_tag_at_n(v_ru_24y_2433_24Send, TAG_Send, 2, (V[]){v_s_2436, v_x_2437});
      break;
    }
    case TAG_Log: {
      V v_s_2438 = heff_field(v_y_2433, 0);
      V v_x_2439 = heff_field(v_y_2433, 1);
      V v_ru_24y_2433_24Log = heff_take_reuse_n(v_y_2433, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2420_24InR, 1);
      v_t_2450 = heff_tag_at_n(v_ru_24y_2433_24Log, TAG_Log, 2, (V[]){v_s_2438, v_x_2439});
      break;
    }
    case TAG_Now: {
      V v_k_2440 = heff_field(v_y_2433, 0);
      heff_take_n(v_y_2433, 1ULL, 1);
      v_t_2450 = heff_tag_at_n(v_ru_24p_2420_24InR, TAG_Now, 1, (V[]){v_k_2440});
      break;
    }
    case TAG_ProjectFiles: {
      V v_r_2441 = heff_field(v_y_2433, 0);
      V v_k_2442 = heff_field(v_y_2433, 1);
      V v_ru_24y_2433_24ProjectFiles = heff_take_reuse_n(v_y_2433, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2420_24InR, 1);
      v_t_2450 = heff_tag_at_n(v_ru_24y_2433_24ProjectFiles, TAG_ProjectFiles, 2, (V[]){v_r_2441, v_k_2442});
      break;
    }
    case TAG_UriPath: {
      V v_u_2443 = heff_field(v_y_2433, 0);
      V v_k_2444 = heff_field(v_y_2433, 1);
      V v_ru_24y_2433_24UriPath = heff_take_reuse_n(v_y_2433, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2420_24InR, 1);
      v_t_2450 = heff_tag_at_n(v_ru_24y_2433_24UriPath, TAG_UriPath, 2, (V[]){v_u_2443, v_k_2444});
      break;
    }
    case TAG_PathUri: {
      V v_p_2445 = heff_field(v_y_2433, 0);
      V v_k_2446 = heff_field(v_y_2433, 1);
      V v_ru_24y_2433_24PathUri = heff_take_reuse_n(v_y_2433, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2420_24InR, 1);
      v_t_2450 = heff_tag_at_n(v_ru_24y_2433_24PathUri, TAG_PathUri, 2, (V[]){v_p_2445, v_k_2446});
      break;
    }
    case TAG_AbsPath: {
      V v_p_2447 = heff_field(v_y_2433, 0);
      V v_k_2448 = heff_field(v_y_2433, 1);
      V v_ru_24y_2433_24AbsPath = heff_take_reuse_n(v_y_2433, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2420_24InR, 1);
      v_t_2450 = heff_tag_at_n(v_ru_24y_2433_24AbsPath, TAG_AbsPath, 2, (V[]){v_p_2447, v_k_2448});
      break;
    }
    case TAG_Quit: {
      V v_c_2449 = heff_field(v_y_2433, 0);
      heff_take_n(v_y_2433, 1ULL, 1);
      v_t_2450 = heff_tag_at_n(v_ru_24p_2420_24InR, TAG_Quit, 1, (V[]){v_c_2449});
      break;
    }
    default: heff_nomatch(v_y_2433);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2450});
  }
  default: return heff_nomatch(v_p_2420);
  }
}
V g_co_2eop_24s504905999x685316098_lam1(V self, V *args);
V g_co_2eop_24s504905999x685316098_lam0(V self, V *args); static Clo g_co_2eop_24s504905999x685316098_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s504905999x685316098_lam0, 4, 0};
V g_co_2eop_24s504905999x685316098_lam3(V self, V *args);
V g_co_2eop_24s504905999x685316098_lam2(V self, V *args);
V g_co_2eop_24s504905999x685316098_lam4(V self, V *args);
Clo g_co_2eop_24s504905999x685316098_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s504905999x685316098_entry, 3, 0};

V g_co_2eop_24s504905999x685316098(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2425;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1100180636x1646925226_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s504905999x685316098_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s504905999x685316098_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s504905999x685316098_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_x_243}));
    v_t_2425 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2415});
    break;
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2424;
    switch (heff_tag_of(v_y_2416)) {
    case TAG_IsTerminal: {
      V v_k_2417 = heff_field(v_y_2416, 0);
      heff_take_n(v_y_2416, 1ULL, 1);
      v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_IsTerminal, 1, (V[]){v_k_2417});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_2418 = heff_field(v_y_2416, 0);
      V v_x_2419 = heff_field(v_y_2416, 1);
      V v_ru_24y_2416_24ShowLines = heff_take_reuse_n(v_y_2416, 3ULL, 2);
      heff_drop_cell(v_ru_24p_240_24InR, 1);
      v_t_2424 = heff_tag_at_n(v_ru_24y_2416_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2418, v_x_2419});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2420 = heff_field(v_y_2416, 0);
      V v_as_2421 = heff_field(v_y_2416, 1);
      V v_lines_2422 = heff_field(v_y_2416, 2);
      V v_k_2423 = heff_field(v_y_2416, 3);
      V v_ru_24y_2416_24ShowRun = heff_take_reuse_n(v_y_2416, 15ULL, 4);
      heff_drop_cell(v_ru_24p_240_24InR, 1);
      v_t_2424 = heff_tag_at_n(v_ru_24y_2416_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2420, v_as_2421, v_lines_2422, v_k_2423});
      break;
    }
    default: heff_nomatch(v_y_2416);
    }
    v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2424});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2425}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2426, v_k2_242});
}
V g_co_2eop_24s504905999x685316098_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s504905999x685316098(a[0], a[1], a[2]);
}
V g_co_2eop_24s504905999x685316098_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s504905999x685316098_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s504905999x685316098_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s504905999x685316098_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s504905999x685316098_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s504905999x685316098_lam3, 1, 2, (V[]){v_g_2410, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s504905999x685316098_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1279463522x45159155_lam1(V self, V *args);
V g_co_2eop_24s1279463522x45159155_lam0(V self, V *args); static Clo g_co_2eop_24s1279463522x45159155_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1279463522x45159155_lam0, 4, 0};
V g_co_2eop_24s1279463522x45159155_lam3(V self, V *args);
V g_co_2eop_24s1279463522x45159155_lam2(V self, V *args);
V g_co_2eop_24s1279463522x45159155_lam4(V self, V *args);
V g_co_2eop_24s1279463522x45159155_lam5(V self, V *args);
Clo g_co_2eop_24s1279463522x45159155_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1279463522x45159155_entry, 4, 0};

V g_co_2eop_24s1279463522x45159155(V v_p_240, V v_k_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2426;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_244 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1100180636x1646925226_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1279463522x45159155_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1279463522x45159155_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s1279463522x45159155_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_x_244}));
    v_t_2426 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2416});
    break;
  }
  case TAG_InR: {
    V v_y_2417 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2425;
    switch (heff_tag_of(v_y_2417)) {
    case TAG_IsTerminal: {
      V v_k_2418 = heff_field(v_y_2417, 0);
      heff_take_n(v_y_2417, 1ULL, 1);
      v_t_2425 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_IsTerminal, 1, (V[]){v_k_2418});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_2419 = heff_field(v_y_2417, 0);
      V v_x_2420 = heff_field(v_y_2417, 1);
      V v_ru_24y_2417_24ShowLines = heff_take_reuse_n(v_y_2417, 3ULL, 2);
      heff_drop_cell(v_ru_24p_240_24InR, 1);
      v_t_2425 = heff_tag_at_n(v_ru_24y_2417_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2419, v_x_2420});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2421 = heff_field(v_y_2417, 0);
      V v_as_2422 = heff_field(v_y_2417, 1);
      V v_lines_2423 = heff_field(v_y_2417, 2);
      V v_k_2424 = heff_field(v_y_2417, 3);
      V v_ru_24y_2417_24ShowRun = heff_take_reuse_n(v_y_2417, 15ULL, 4);
      heff_drop_cell(v_ru_24p_240_24InR, 1);
      v_t_2425 = heff_tag_at_n(v_ru_24y_2417_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2421, v_as_2422, v_lines_2423, v_k_2424});
      break;
    }
    default: heff_nomatch(v_y_2417);
    }
    v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2425});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2426}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_2427, heff_clo_n(g_co_2eop_24s1279463522x45159155_lam5, 1, 3, (V[]){v_k_241, v_hd_242, v_k2_243})});
}
V g_co_2eop_24s1279463522x45159155_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1279463522x45159155(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s1279463522x45159155_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1279463522x45159155_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_24s1279463522x45159155_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1279463522x45159155_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_x_2413}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1279463522x45159155_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2412;
  args[1] = heff_clo_n(g_co_2eop_24s1279463522x45159155_lam3, 1, 2, (V[]){v_g_2411, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1279463522x45159155_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1279463522x45159155_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k2_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  heff_room[0] = v_x_2428;
  heff_room[1] = v_hd_242;
  heff_room[2] = v_k2_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eplus_24s1578688711x396965871_lam1(V self, V *args);
V g_co_2eplus_24s1578688711x396965871_lam2(V self, V *args);
V g_co_2eplus_24s1578688711x396965871_lam0(V self, V *args); static Clo g_co_2eplus_24s1578688711x396965871_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1578688711x396965871_lam0, 3, 0};
V g_co_2eplus_24s1578688711x396965871_lam3(V self, V *args); static Clo g_co_2eplus_24s1578688711x396965871_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1578688711x396965871_lam3, 4, 0};

static V g_co_2eplus_24s1578688711x396965871_val;
static HEFF_ONCE g_co_2eplus_24s1578688711x396965871_st;
static V g_co_2eplus_24s1578688711x396965871_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1578688711x396965871_lam0_clo), ((V)&g_co_2eplus_24s1578688711x396965871_lam3_clo)});
}
V g_co_2eplus_24s1578688711x396965871_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s1578688711x396965871_st)) return g_co_2eplus_24s1578688711x396965871_val;
  return heff_global(&g_co_2eplus_24s1578688711x396965871_val, &g_co_2eplus_24s1578688711x396965871_st, g_co_2eplus_24s1578688711x396965871_init);
}
V g_co_2eplus_24s1578688711x396965871_lam1(V self, V *args) {
  V v_b_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_k_246, 1, (V[]){v_b_247}));
  V f_ = v_g_241;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1578688711x396965871_lam2(V self, V *args) {
  V v_r_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_r_2416}));
  V f_ = v_g_241;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1578688711x396965871_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1100180636x1646925226_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_m_240);
    V v_t_2418;
    switch (heff_tag_of(v_y_245)) {
    case TAG_IsTerminal: {
      V v_k_246 = heff_field(v_y_245, 0);
      heff_take_n(v_y_245, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24p_242_24InR, TAG_IsTerminal, 1, (V[]){heff_clo_n(g_co_2eplus_24s1578688711x396965871_lam1, 1, 2, (V[]){v_k_246, v_g_241})});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_249 = heff_field(v_y_245, 0);
      V v_x_2410 = heff_field(v_y_245, 1);
      V v_ru_24y_245_24ShowLines = heff_take_reuse_n(v_y_245, 3ULL, 2);
      heff_drop_cell(v_ru_24p_242_24InR, 1);
      V v_t_2411 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2410}));
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_249, v_t_2411});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2412 = heff_field(v_y_245, 0);
      V v_as_2413 = heff_field(v_y_245, 1);
      V v_lines_2414 = heff_field(v_y_245, 2);
      V v_k_2415 = heff_field(v_y_245, 3);
      V v_ru_24y_245_24ShowRun = heff_take_reuse_n(v_y_245, 15ULL, 4);
      heff_drop_cell(v_ru_24p_242_24InR, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2412, v_as_2413, v_lines_2414, heff_clo_n(g_co_2eplus_24s1578688711x396965871_lam2, 1, 2, (V[]){v_k_2415, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_245);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1578688711x396965871_lam3(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  switch (heff_tag_of(v_p_2422)) {
  case TAG_InL: {
    V v_x_2423 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InL = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1100180636x1646925226_get(), 1)), 4, (V[]){v_m_2419, v_n_2420, v_nt_2421, v_x_2423}));
    return heff_tag_at_n(v_ru_24p_2422_24InL, TAG_InL, 1, (V[]){v_t_2424});
  }
  case TAG_InR: {
    V v_y_2425 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InR = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_m_2419);
    heff_drop(v_n_2420);
    heff_drop(v_nt_2421);
    V v_t_2433;
    switch (heff_tag_of(v_y_2425)) {
    case TAG_IsTerminal: {
      V v_k_2426 = heff_field(v_y_2425, 0);
      heff_take_n(v_y_2425, 1ULL, 1);
      v_t_2433 = heff_tag_at_n(v_ru_24p_2422_24InR, TAG_IsTerminal, 1, (V[]){v_k_2426});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_2427 = heff_field(v_y_2425, 0);
      V v_x_2428 = heff_field(v_y_2425, 1);
      V v_ru_24y_2425_24ShowLines = heff_take_reuse_n(v_y_2425, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2422_24InR, 1);
      v_t_2433 = heff_tag_at_n(v_ru_24y_2425_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2427, v_x_2428});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2429 = heff_field(v_y_2425, 0);
      V v_as_2430 = heff_field(v_y_2425, 1);
      V v_lines_2431 = heff_field(v_y_2425, 2);
      V v_k_2432 = heff_field(v_y_2425, 3);
      V v_ru_24y_2425_24ShowRun = heff_take_reuse_n(v_y_2425, 15ULL, 4);
      heff_drop_cell(v_ru_24p_2422_24InR, 1);
      v_t_2433 = heff_tag_at_n(v_ru_24y_2425_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2429, v_as_2430, v_lines_2431, v_k_2432});
      break;
    }
    default: heff_nomatch(v_y_2425);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2433});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_co_2eplus_24s704070075x794314310_lam0(V self, V *args); static Clo g_co_2eplus_24s704070075x794314310_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s704070075x794314310_lam0, 3, 0};
V g_co_2eplus_24s704070075x794314310_lam1(V self, V *args); static Clo g_co_2eplus_24s704070075x794314310_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s704070075x794314310_lam1, 4, 0};

static V g_co_2eplus_24s704070075x794314310_val;
static HEFF_ONCE g_co_2eplus_24s704070075x794314310_st;
static V g_co_2eplus_24s704070075x794314310_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s704070075x794314310_lam0_clo), ((V)&g_co_2eplus_24s704070075x794314310_lam1_clo)});
}
V g_co_2eplus_24s704070075x794314310_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s704070075x794314310_st)) return g_co_2eplus_24s704070075x794314310_val;
  return heff_global(&g_co_2eplus_24s704070075x794314310_val, &g_co_2eplus_24s704070075x794314310_st, g_co_2eplus_24s704070075x794314310_init);
}
V g_co_2eplus_24s704070075x794314310_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprogress_2eprogress_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1578688711x396965871_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_245}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_246});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s704070075x794314310_lam1(V self, V *args) {
  V v_m_247 = args[0];
  V v_n_248 = args[1];
  V v_nt_249 = args[2];
  V v_p_2410 = args[3];
  switch (heff_tag_of(v_p_2410)) {
  case TAG_InL: {
    V v_x_2411 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InL = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    heff_drop(v_m_247);
    heff_drop(v_n_248);
    heff_drop(v_nt_249);
    V v_t_2424;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Start: {
      V v_parent_2412 = heff_field(v_x_2411, 0);
      V v_name_2413 = heff_field(v_x_2411, 1);
      V v_total_2414 = heff_field(v_x_2411, 2);
      V v_k_2415 = heff_field(v_x_2411, 3);
      V v_ru_24x_2411_24Start = heff_take_reuse_n(v_x_2411, 15ULL, 4);
      v_t_2424 = heff_tag_at_n(v_ru_24x_2411_24Start, TAG_Start, 4, (V[]){v_parent_2412, v_name_2413, v_total_2414, v_k_2415});
      break;
    }
    case TAG_Complete: {
      V v_t_2416 = heff_field(v_x_2411, 0);
      V v_x_2417 = heff_field(v_x_2411, 1);
      V v_ru_24x_2411_24Complete = heff_take_reuse_n(v_x_2411, 3ULL, 2);
      v_t_2424 = heff_tag_at_n(v_ru_24x_2411_24Complete, TAG_Complete, 2, (V[]){v_t_2416, v_x_2417});
      break;
    }
    case TAG_End: {
      V v_t_2418 = heff_field(v_x_2411, 0);
      V v_x_2419 = heff_field(v_x_2411, 1);
      V v_ru_24x_2411_24End = heff_take_reuse_n(v_x_2411, 3ULL, 2);
      v_t_2424 = heff_tag_at_n(v_ru_24x_2411_24End, TAG_End, 2, (V[]){v_t_2418, v_x_2419});
      break;
    }
    case TAG_RunUnder: {
      V v_t_2420 = heff_field(v_x_2411, 0);
      V v_cmd_2421 = heff_field(v_x_2411, 1);
      V v_as_2422 = heff_field(v_x_2411, 2);
      V v_k_2423 = heff_field(v_x_2411, 3);
      V v_ru_24x_2411_24RunUnder = heff_take_reuse_n(v_x_2411, 15ULL, 4);
      v_t_2424 = heff_tag_at_n(v_ru_24x_2411_24RunUnder, TAG_RunUnder, 4, (V[]){v_t_2420, v_cmd_2421, v_as_2422, v_k_2423});
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    return heff_tag_at_n(v_ru_24p_2410_24InL, TAG_InL, 1, (V[]){v_t_2424});
  }
  case TAG_InR: {
    V v_y_2425 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InR = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    V v_t_2437;
    switch (heff_tag_of(v_y_2425)) {
    case TAG_InL: {
      V v_x_2426 = heff_field(v_y_2425, 0);
      heff_take_n(v_y_2425, 1ULL, 1);
      V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1100180636x1646925226_get(), 1)), 4, (V[]){v_m_247, v_n_248, v_nt_249, v_x_2426}));
      v_t_2437 = heff_tag_at_n(v_ru_24p_2410_24InR, TAG_InL, 1, (V[]){v_t_2427});
      break;
    }
    case TAG_InR: {
      V v_y_2428 = heff_field(v_y_2425, 0);
      V v_ru_24y_2425_24InR = heff_take_reuse_n(v_y_2425, 1ULL, 1);
      heff_drop(v_m_247);
      heff_drop(v_n_248);
      heff_drop(v_nt_249);
      V v_t_2436;
      switch (heff_tag_of(v_y_2428)) {
      case TAG_IsTerminal: {
        V v_k_2429 = heff_field(v_y_2428, 0);
        heff_take_n(v_y_2428, 1ULL, 1);
        v_t_2436 = heff_tag_at_n(v_ru_24p_2410_24InR, TAG_IsTerminal, 1, (V[]){v_k_2429});
        break;
      }
      case TAG_ShowLines: {
        V v_ls_2430 = heff_field(v_y_2428, 0);
        V v_x_2431 = heff_field(v_y_2428, 1);
        V v_ru_24y_2428_24ShowLines = heff_take_reuse_n(v_y_2428, 3ULL, 2);
        heff_drop_cell(v_ru_24p_2410_24InR, 1);
        v_t_2436 = heff_tag_at_n(v_ru_24y_2428_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2430, v_x_2431});
        break;
      }
      case TAG_ShowRun: {
        V v_cmd_2432 = heff_field(v_y_2428, 0);
        V v_as_2433 = heff_field(v_y_2428, 1);
        V v_lines_2434 = heff_field(v_y_2428, 2);
        V v_k_2435 = heff_field(v_y_2428, 3);
        V v_ru_24y_2428_24ShowRun = heff_take_reuse_n(v_y_2428, 15ULL, 4);
        heff_drop_cell(v_ru_24p_2410_24InR, 1);
        v_t_2436 = heff_tag_at_n(v_ru_24y_2428_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2432, v_as_2433, v_lines_2434, v_k_2435});
        break;
      }
      default: heff_nomatch(v_y_2428);
      }
      v_t_2437 = heff_tag_at_n(v_ru_24y_2425_24InR, TAG_InR, 1, (V[]){v_t_2436});
      break;
    }
    default: heff_nomatch(v_y_2425);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2437});
  }
  default: return heff_nomatch(v_p_2410);
  }
}
V g_co_2eop_24s1289826976x294500243_lam1(V self, V *args);
V g_co_2eop_24s1289826976x294500243_lam0(V self, V *args); static Clo g_co_2eop_24s1289826976x294500243_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1289826976x294500243_lam0, 4, 0};
V g_co_2eop_24s1289826976x294500243_lam4(V self, V *args);
V g_co_2eop_24s1289826976x294500243_lam3(V self, V *args);
V g_co_2eop_24s1289826976x294500243_lam2(V self, V *args); static Clo g_co_2eop_24s1289826976x294500243_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1289826976x294500243_lam2, 3, 0};
V g_co_2eop_24s1289826976x294500243_lam5(V self, V *args); static Clo g_co_2eop_24s1289826976x294500243_lam5_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1289826976x294500243_lam5, 1, 0};
V g_co_2eop_24s1289826976x294500243_lam7(V self, V *args);
V g_co_2eop_24s1289826976x294500243_lam6(V self, V *args);
Clo g_co_2eop_24s1289826976x294500243_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1289826976x294500243_entry, 3, 0};

V g_co_2eop_24s1289826976x294500243(V v_p_240, V v_k2_241, V v_z_242) {
top: ;
  V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s704070075x794314310_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1289826976x294500243_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1289826976x294500243_lam2_clo)}), ((V)&g_co_2eop_24s1289826976x294500243_lam5_clo), v_p_240}));
  V v_m_2425 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprogress_2edrawing_24s1506381720x1028922836_get(), 2)), 1, (V[]){v_t_2424}));
  V v_c_2426 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_z_242}));
  return heff_clo_n(g_co_2eop_24s1289826976x294500243_lam6, 2, 2, (V[]){v_c_2426, v_k2_241});
}
V g_co_2eop_24s1289826976x294500243_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1289826976x294500243(a[0], a[1], a[2]);
}
V g_co_2eop_24s1289826976x294500243_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1289826976x294500243_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s1289826976x294500243_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1289826976x294500243_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2418;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_dup(heff_field(v_x_2415, 1));
    v_x_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_x_2419 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2418}));
  V v_ts_2422;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 2);
    v_ts_2422 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2422, v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1289826976x294500243_lam3(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_g_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2412;
  args[0] = v_hd_2413;
  args[1] = heff_clo_n(g_co_2eop_24s1289826976x294500243_lam4, 1, 2, (V[]){v_g_249, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1289826976x294500243_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_ts_2411 = args[2];
  V v_c_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_ts_2411}));
  return heff_clo_n(g_co_2eop_24s1289826976x294500243_lam3, 2, 2, (V[]){v_c_2412, v_g_249});
}
V g_co_2eop_24s1289826976x294500243_lam5(V self, V *args) {
  V v_c_2423 = args[0];
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(g_std_2eprogress_2edrawing_24s1506381720x1028922836_get());
  heff_room[1] = heff_dup(heff_rfield(g_std_2eprogress_2edrawing_24s1506381720x1028922836_get(), 0));
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1289826976x294500243_lam7(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k2_241 = heff_env(self)[0];
  V v_hd_2427 = heff_env(self)[1];
  V v_k_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2432;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_MkPair: {
    V v_y_2431 = heff_dup(heff_field(v_x_2429, 1));
    v_t_2432 = v_y_2431;
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  V v_t_2435;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 2);
    v_t_2435 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  V f_ = v_k2_241;
  heff_room[0] = v_t_2432;
  heff_room[1] = v_t_2435;
  heff_room[2] = v_hd_2427;
  heff_room[3] = v_k_2428;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_co_2eop_24s1289826976x294500243_lam6(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  V v_k2_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2426;
  args[0] = heff_dup(v_hd_2427);
  args[1] = heff_clo_n(g_co_2eop_24s1289826976x294500243_lam7, 1, 3, (V[]){v_k2_241, v_hd_2427, v_k_2428});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s954557541x749476273_lam1(V self, V *args);
V g_co_2eop_24s954557541x749476273_lam0(V self, V *args); static Clo g_co_2eop_24s954557541x749476273_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s954557541x749476273_lam0, 4, 0};
V g_co_2eop_24s954557541x749476273_lam3(V self, V *args);
V g_co_2eop_24s954557541x749476273_lam2(V self, V *args);
V g_co_2eop_24s954557541x749476273_lam4(V self, V *args);
Clo g_co_2eop_24s954557541x749476273_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s954557541x749476273_entry, 3, 0};

V g_co_2eop_24s954557541x749476273(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s704070075x794314310_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s954557541x749476273_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s954557541x749476273_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s954557541x749476273_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, v_k2_242});
}
V g_co_2eop_24s954557541x749476273_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s954557541x749476273(a[0], a[1], a[2]);
}
V g_co_2eop_24s954557541x749476273_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s954557541x749476273_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s954557541x749476273_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s954557541x749476273_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s954557541x749476273_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s954557541x749476273_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s954557541x749476273_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1084803226x1249263831_lam1(V self, V *args);
V g_co_2eop_24s1084803226x1249263831_lam0(V self, V *args); static Clo g_co_2eop_24s1084803226x1249263831_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1084803226x1249263831_lam0, 4, 0};
V g_co_2eop_24s1084803226x1249263831_lam3(V self, V *args);
V g_co_2eop_24s1084803226x1249263831_lam2(V self, V *args);
V g_co_2eop_24s1084803226x1249263831_lam4(V self, V *args);
Clo g_co_2eop_24s1084803226x1249263831_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1084803226x1249263831_entry, 3, 0};

V g_co_2eop_24s1084803226x1249263831(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s704070075x794314310_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1084803226x1249263831_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1084803226x1249263831_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1084803226x1249263831_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, v_k2_242});
}
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1084803226x1249263831(a[0], a[1], a[2]);
}
V g_co_2eop_24s1084803226x1249263831_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1084803226x1249263831_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s1084803226x1249263831_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1084803226x1249263831_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1084803226x1249263831_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s1084803226x1249263831_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1084803226x1249263831_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s384550787x906982552_lam1(V self, V *args);
V g_co_2eop_24s384550787x906982552_lam0(V self, V *args); static Clo g_co_2eop_24s384550787x906982552_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s384550787x906982552_lam0, 4, 0};
V g_co_2eop_24s384550787x906982552_lam3(V self, V *args);
V g_co_2eop_24s384550787x906982552_lam2(V self, V *args);
V g_co_2eop_24s384550787x906982552_lam4(V self, V *args);
Clo g_co_2eop_24s384550787x906982552_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s384550787x906982552_entry, 3, 0};

V g_co_2eop_24s384550787x906982552(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2425;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1100180636x1646925226_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s384550787x906982552_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s384550787x906982552_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s384550787x906982552_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_x_243}));
    v_t_2425 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2415});
    break;
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2424;
    switch (heff_tag_of(v_y_2416)) {
    case TAG_IsTerminal: {
      V v_k_2417 = heff_field(v_y_2416, 0);
      heff_take_n(v_y_2416, 1ULL, 1);
      v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_IsTerminal, 1, (V[]){v_k_2417});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_2418 = heff_field(v_y_2416, 0);
      V v_x_2419 = heff_field(v_y_2416, 1);
      V v_ru_24y_2416_24ShowLines = heff_take_reuse_n(v_y_2416, 3ULL, 2);
      heff_drop_cell(v_ru_24p_240_24InR, 1);
      v_t_2424 = heff_tag_at_n(v_ru_24y_2416_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2418, v_x_2419});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2420 = heff_field(v_y_2416, 0);
      V v_as_2421 = heff_field(v_y_2416, 1);
      V v_lines_2422 = heff_field(v_y_2416, 2);
      V v_k_2423 = heff_field(v_y_2416, 3);
      V v_ru_24y_2416_24ShowRun = heff_take_reuse_n(v_y_2416, 15ULL, 4);
      heff_drop_cell(v_ru_24p_240_24InR, 1);
      v_t_2424 = heff_tag_at_n(v_ru_24y_2416_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2420, v_as_2421, v_lines_2422, v_k_2423});
      break;
    }
    default: heff_nomatch(v_y_2416);
    }
    v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2424});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2425}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2426, v_k2_242});
}
V g_co_2eop_24s384550787x906982552_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s384550787x906982552(a[0], a[1], a[2]);
}
V g_co_2eop_24s384550787x906982552_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s384550787x906982552_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s384550787x906982552_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s384550787x906982552_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s384550787x906982552_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s384550787x906982552_lam3, 1, 2, (V[]){v_g_2410, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s384550787x906982552_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1344776583x1328086698_lam1(V self, V *args);
V g_co_2eop_24s1344776583x1328086698_lam0(V self, V *args); static Clo g_co_2eop_24s1344776583x1328086698_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1344776583x1328086698_lam0, 4, 0};
V g_co_2eop_24s1344776583x1328086698_lam3(V self, V *args);
V g_co_2eop_24s1344776583x1328086698_lam2(V self, V *args); static Clo g_co_2eop_24s1344776583x1328086698_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1344776583x1328086698_lam2, 4, 0};
V g_co_2eop_24s1344776583x1328086698_lam5(V self, V *args); static Clo g_co_2eop_24s1344776583x1328086698_lam5_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1344776583x1328086698_lam5, 3, 0};
V g_co_2eop_24s1344776583x1328086698_lam7(V self, V *args);
V g_co_2eop_24s1344776583x1328086698_lam6(V self, V *args); static Clo g_co_2eop_24s1344776583x1328086698_lam6_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1344776583x1328086698_lam6, 4, 0};
V g_co_2eop_24s1344776583x1328086698_lam8(V self, V *args); static Clo g_co_2eop_24s1344776583x1328086698_lam8_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1344776583x1328086698_lam8, 1, 0};
V g_co_2eop_24s1344776583x1328086698_lam9(V self, V *args); static Clo g_co_2eop_24s1344776583x1328086698_lam9_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1344776583x1328086698_lam9, 3, 0};
V g_co_2eop_24s1344776583x1328086698_lam4(V self, V *args); static Clo g_co_2eop_24s1344776583x1328086698_lam4_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1344776583x1328086698_lam4, 1, 0};
V g_co_2eop_24s1344776583x1328086698_lam11(V self, V *args);
V g_co_2eop_24s1344776583x1328086698_lam10(V self, V *args);
Clo g_co_2eop_24s1344776583x1328086698_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1344776583x1328086698_entry, 2, 0};

V g_co_2eop_24s1344776583x1328086698(V v_p_240, V v_k2_241) {
top: ;
  V v_a_2429 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s704070075x794314310_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1344776583x1328086698_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1344776583x1328086698_lam2_clo)}), ((V)&g_co_2eop_24s1344776583x1328086698_lam4_clo), v_p_240}));
  V v_a_2432;
  switch (heff_tag_of(v_a_2429)) {
  case TAG_InL: {
    V v_a_2430 = heff_field(v_a_2429, 0);
    heff_take_n(v_a_2429, 1ULL, 1);
    v_a_2432 = ({ V a_0 = v_a_2430; V r_ = (g_std_2eprogress_2equietly_24s1392860441x1460275359(a_0)); heff_drop(v_a_2430); r_; });
    break;
  }
  case TAG_InR: {
    V v_a_2431 = heff_field(v_a_2429, 0);
    heff_take_n(v_a_2429, 1ULL, 1);
    v_a_2432 = heff_tr(heff_call(((V)&g_co_2eop_24s384550787x906982552_clo), 1, (V[]){v_a_2431}));
    break;
  }
  default: heff_nomatch(v_a_2429);
  }
  return heff_clo_n(g_co_2eop_24s1344776583x1328086698_lam10, 2, 2, (V[]){v_a_2432, v_k2_241});
}
V g_co_2eop_24s1344776583x1328086698_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1344776583x1328086698(a[0], a[1]);
}
V g_co_2eop_24s1344776583x1328086698_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_242 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_247 = heff_tr(heff_call(v_g_242, 1, (V[]){v_x_246}));
  V f_ = v_k_245;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1344776583x1328086698_lam0(V self, V *args) {
  V v_g_242 = args[0];
  V v_c_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V f_ = v_c_243;
  args[0] = v_hd_244;
  args[1] = heff_clo_n(g_co_2eop_24s1344776583x1328086698_lam1, 1, 2, (V[]){v_g_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1344776583x1328086698_lam3(V self, V *args) {
  V v_a_2412 = args[0];
  V v_g_248 = heff_env(self)[0];
  V v_a_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2413 = heff_tr(heff_call(v_g_248, 1, (V[]){v_a_2412}));
  V f_ = v_a_2411;
  args[0] = v_a_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1344776583x1328086698_lam2(V self, V *args) {
  V v_g_248 = args[0];
  V v_m_249 = args[1];
  V v_a_2410 = args[2];
  V v_a_2411 = args[3];
  V f_ = v_m_249;
  args[0] = v_a_2410;
  args[1] = heff_clo_n(g_co_2eop_24s1344776583x1328086698_lam3, 1, 2, (V[]){v_g_248, v_a_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1344776583x1328086698_lam5(V self, V *args) {
  V v_a_2415 = args[0];
  V v_a_2416 = args[1];
  V v_a_2417 = args[2];
  heff_drop(v_a_2416);
  V f_ = v_a_2417;
  args[0] = v_a_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1344776583x1328086698_lam7(V self, V *args) {
  V v_a_2422 = args[0];
  V v_a_2419 = heff_env(self)[0];
  V v_a_2420 = heff_env(self)[1];
  V v_a_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_2419;
  heff_room[0] = v_a_2422;
  heff_room[1] = v_a_2420;
  heff_room[2] = v_a_2421;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eop_24s1344776583x1328086698_lam6(V self, V *args) {
  V v_a_2418 = args[0];
  V v_a_2419 = args[1];
  V v_a_2420 = args[2];
  V v_a_2421 = args[3];
  V f_ = v_a_2418;
  args[0] = heff_dup(v_a_2420);
  args[1] = heff_clo_n(g_co_2eop_24s1344776583x1328086698_lam7, 1, 3, (V[]){v_a_2419, v_a_2420, v_a_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1344776583x1328086698_lam8(V self, V *args) {
  V v_a_2423 = args[0];
  switch (heff_tag_of(v_a_2423)) {
  case TAG_InL: {
    V v_a_2424 = heff_field(v_a_2423, 0);
    heff_take_n(v_a_2423, 1ULL, 1);
    return ({ V a_0 = v_a_2424; V r_ = (g_std_2eprogress_2equietly_24s1392860441x1460275359(a_0)); heff_drop(v_a_2424); r_; });
  }
  case TAG_InR: {
    V v_a_2425 = heff_field(v_a_2423, 0);
    heff_take_n(v_a_2423, 1ULL, 1);
    V f_ = ((V)&g_co_2eop_24s384550787x906982552_clo);
    args[0] = v_a_2425;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_a_2423);
  }
}
V g_co_2eop_24s1344776583x1328086698_lam9(V self, V *args) {
  V v_a_2426 = args[0];
  V v_a_2427 = args[1];
  V v_a_2428 = args[2];
  heff_drop(v_a_2427);
  V f_ = v_a_2428;
  args[0] = v_a_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1344776583x1328086698_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V f_ = v_c_2414;
  heff_room[0] = heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_co_2eop_24s1344776583x1328086698_lam5_clo), ((V)&g_co_2eop_24s1344776583x1328086698_lam6_clo), ((V)&g_co_2eop_24s1344776583x1328086698_lam8_clo)});
  heff_room[1] = ((V)&g_co_2eop_24s1344776583x1328086698_lam9_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1344776583x1328086698_lam11(V self, V *args) {
  V v_a_2435 = args[0];
  V v_k2_241 = heff_env(self)[0];
  V v_a_2433 = heff_env(self)[1];
  V v_a_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k2_241;
  heff_room[0] = v_a_2435;
  heff_room[1] = v_a_2433;
  heff_room[2] = v_a_2434;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eop_24s1344776583x1328086698_lam10(V self, V *args) {
  V v_a_2433 = args[0];
  V v_a_2434 = args[1];
  V v_a_2432 = heff_env(self)[0];
  V v_k2_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2432;
  args[0] = heff_dup(v_a_2433);
  args[1] = heff_clo_n(g_co_2eop_24s1344776583x1328086698_lam11, 1, 3, (V[]){v_k2_241, v_a_2433, v_a_2434});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1106850457x559991957_lam1(V self, V *args);
V g_co_2eop_24s1106850457x559991957_lam0(V self, V *args); static Clo g_co_2eop_24s1106850457x559991957_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1106850457x559991957_lam0, 4, 0};
V g_co_2eop_24s1106850457x559991957_lam3(V self, V *args);
V g_co_2eop_24s1106850457x559991957_lam2(V self, V *args); static Clo g_co_2eop_24s1106850457x559991957_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1106850457x559991957_lam2, 4, 0};
V g_co_2eop_24s1106850457x559991957_lam5(V self, V *args); static Clo g_co_2eop_24s1106850457x559991957_lam5_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1106850457x559991957_lam5, 3, 0};
V g_co_2eop_24s1106850457x559991957_lam7(V self, V *args);
V g_co_2eop_24s1106850457x559991957_lam6(V self, V *args); static Clo g_co_2eop_24s1106850457x559991957_lam6_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1106850457x559991957_lam6, 4, 0};
V g_co_2eop_24s1106850457x559991957_lam8(V self, V *args); static Clo g_co_2eop_24s1106850457x559991957_lam8_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1106850457x559991957_lam8, 1, 0};
V g_co_2eop_24s1106850457x559991957_lam9(V self, V *args); static Clo g_co_2eop_24s1106850457x559991957_lam9_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1106850457x559991957_lam9, 3, 0};
V g_co_2eop_24s1106850457x559991957_lam4(V self, V *args); static Clo g_co_2eop_24s1106850457x559991957_lam4_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1106850457x559991957_lam4, 1, 0};
Clo g_co_2eop_24s1106850457x559991957_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1106850457x559991957_entry, 3, 0};

V g_co_2eop_24s1106850457x559991957(V v_p_240, V v_z_241, V v_z_242) {
top: ;
  V v_a_2430 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s704070075x794314310_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1106850457x559991957_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1106850457x559991957_lam2_clo)}), ((V)&g_co_2eop_24s1106850457x559991957_lam4_clo), v_p_240}));
  V v_a_2433;
  switch (heff_tag_of(v_a_2430)) {
  case TAG_InL: {
    V v_a_2431 = heff_field(v_a_2430, 0);
    heff_take_n(v_a_2430, 1ULL, 1);
    v_a_2433 = ({ V a_0 = v_a_2431; V r_ = (g_std_2eprogress_2equietly_24s1392860441x1460275359(a_0)); heff_drop(v_a_2431); r_; });
    break;
  }
  case TAG_InR: {
    V v_a_2432 = heff_field(v_a_2430, 0);
    heff_take_n(v_a_2430, 1ULL, 1);
    v_a_2433 = heff_tr(heff_call(((V)&g_co_2eop_24s384550787x906982552_clo), 1, (V[]){v_a_2432}));
    break;
  }
  default: heff_nomatch(v_a_2430);
  }
  return heff_tail(v_a_2433, 2, (V[]){v_z_241, v_z_242});
}
V g_co_2eop_24s1106850457x559991957_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1106850457x559991957(a[0], a[1], a[2]);
}
V g_co_2eop_24s1106850457x559991957_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1106850457x559991957_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s1106850457x559991957_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1106850457x559991957_lam3(V self, V *args) {
  V v_a_2413 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_a_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2414 = heff_tr(heff_call(v_g_249, 1, (V[]){v_a_2413}));
  V f_ = v_a_2412;
  args[0] = v_a_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1106850457x559991957_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_a_2411 = args[2];
  V v_a_2412 = args[3];
  V f_ = v_m_2410;
  args[0] = v_a_2411;
  args[1] = heff_clo_n(g_co_2eop_24s1106850457x559991957_lam3, 1, 2, (V[]){v_g_249, v_a_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1106850457x559991957_lam5(V self, V *args) {
  V v_a_2416 = args[0];
  V v_a_2417 = args[1];
  V v_a_2418 = args[2];
  heff_drop(v_a_2417);
  V f_ = v_a_2418;
  args[0] = v_a_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1106850457x559991957_lam7(V self, V *args) {
  V v_a_2423 = args[0];
  V v_a_2420 = heff_env(self)[0];
  V v_a_2421 = heff_env(self)[1];
  V v_a_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_2420;
  heff_room[0] = v_a_2423;
  heff_room[1] = v_a_2421;
  heff_room[2] = v_a_2422;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eop_24s1106850457x559991957_lam6(V self, V *args) {
  V v_a_2419 = args[0];
  V v_a_2420 = args[1];
  V v_a_2421 = args[2];
  V v_a_2422 = args[3];
  V f_ = v_a_2419;
  args[0] = heff_dup(v_a_2421);
  args[1] = heff_clo_n(g_co_2eop_24s1106850457x559991957_lam7, 1, 3, (V[]){v_a_2420, v_a_2421, v_a_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1106850457x559991957_lam8(V self, V *args) {
  V v_a_2424 = args[0];
  switch (heff_tag_of(v_a_2424)) {
  case TAG_InL: {
    V v_a_2425 = heff_field(v_a_2424, 0);
    heff_take_n(v_a_2424, 1ULL, 1);
    return ({ V a_0 = v_a_2425; V r_ = (g_std_2eprogress_2equietly_24s1392860441x1460275359(a_0)); heff_drop(v_a_2425); r_; });
  }
  case TAG_InR: {
    V v_a_2426 = heff_field(v_a_2424, 0);
    heff_take_n(v_a_2424, 1ULL, 1);
    V f_ = ((V)&g_co_2eop_24s384550787x906982552_clo);
    args[0] = v_a_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_a_2424);
  }
}
V g_co_2eop_24s1106850457x559991957_lam9(V self, V *args) {
  V v_a_2427 = args[0];
  V v_a_2428 = args[1];
  V v_a_2429 = args[2];
  heff_drop(v_a_2428);
  V f_ = v_a_2429;
  args[0] = v_a_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1106850457x559991957_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V f_ = v_c_2415;
  heff_room[0] = heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_co_2eop_24s1106850457x559991957_lam5_clo), ((V)&g_co_2eop_24s1106850457x559991957_lam6_clo), ((V)&g_co_2eop_24s1106850457x559991957_lam8_clo)});
  heff_room[1] = ((V)&g_co_2eop_24s1106850457x559991957_lam9_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s15141126x503873151_lam1(V self, V *args);
V g_co_2eop_24s15141126x503873151_lam0(V self, V *args); static Clo g_co_2eop_24s15141126x503873151_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s15141126x503873151_lam0, 4, 0};
V g_co_2eop_24s15141126x503873151_lam3(V self, V *args);
V g_co_2eop_24s15141126x503873151_lam2(V self, V *args); static Clo g_co_2eop_24s15141126x503873151_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s15141126x503873151_lam2, 4, 0};
V g_co_2eop_24s15141126x503873151_lam5(V self, V *args); static Clo g_co_2eop_24s15141126x503873151_lam5_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s15141126x503873151_lam5, 3, 0};
V g_co_2eop_24s15141126x503873151_lam7(V self, V *args);
V g_co_2eop_24s15141126x503873151_lam6(V self, V *args); static Clo g_co_2eop_24s15141126x503873151_lam6_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s15141126x503873151_lam6, 4, 0};
V g_co_2eop_24s15141126x503873151_lam8(V self, V *args); static Clo g_co_2eop_24s15141126x503873151_lam8_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s15141126x503873151_lam8, 1, 0};
V g_co_2eop_24s15141126x503873151_lam9(V self, V *args); static Clo g_co_2eop_24s15141126x503873151_lam9_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s15141126x503873151_lam9, 3, 0};
V g_co_2eop_24s15141126x503873151_lam4(V self, V *args); static Clo g_co_2eop_24s15141126x503873151_lam4_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s15141126x503873151_lam4, 1, 0};
V g_co_2eop_24s15141126x503873151_lam10(V self, V *args);
Clo g_co_2eop_24s15141126x503873151_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s15141126x503873151_entry, 4, 0};

V g_co_2eop_24s15141126x503873151(V v_lit_240, V v_p_241, V v_z_242, V v_z_243) {
top: ;
  V v_a_2431 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s704070075x794314310_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s15141126x503873151_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s15141126x503873151_lam2_clo)}), ((V)&g_co_2eop_24s15141126x503873151_lam4_clo), v_p_241}));
  V v_a_2434;
  switch (heff_tag_of(v_a_2431)) {
  case TAG_InL: {
    V v_a_2432 = heff_field(v_a_2431, 0);
    heff_take_n(v_a_2431, 1ULL, 1);
    v_a_2434 = ({ V a_0 = v_a_2432; V r_ = (g_std_2eprogress_2equietly_24s1392860441x1460275359(a_0)); heff_drop(v_a_2432); r_; });
    break;
  }
  case TAG_InR: {
    V v_a_2433 = heff_field(v_a_2431, 0);
    heff_take_n(v_a_2431, 1ULL, 1);
    v_a_2434 = heff_tr(heff_call(((V)&g_co_2eop_24s384550787x906982552_clo), 1, (V[]){v_a_2433}));
    break;
  }
  default: heff_nomatch(v_a_2431);
  }
  return heff_tail(v_a_2434, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_co_2eop_24s15141126x503873151_lam10, 1, 3, (V[]){v_lit_240, v_z_242, v_z_243})});
}
V g_co_2eop_24s15141126x503873151_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s15141126x503873151(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s15141126x503873151_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s15141126x503873151_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s15141126x503873151_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s15141126x503873151_lam3(V self, V *args) {
  V v_a_2414 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_a_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2415 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_a_2414}));
  V f_ = v_a_2413;
  args[0] = v_a_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s15141126x503873151_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_a_2412 = args[2];
  V v_a_2413 = args[3];
  V f_ = v_m_2411;
  args[0] = v_a_2412;
  args[1] = heff_clo_n(g_co_2eop_24s15141126x503873151_lam3, 1, 2, (V[]){v_g_2410, v_a_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s15141126x503873151_lam5(V self, V *args) {
  V v_a_2417 = args[0];
  V v_a_2418 = args[1];
  V v_a_2419 = args[2];
  heff_drop(v_a_2418);
  V f_ = v_a_2419;
  args[0] = v_a_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s15141126x503873151_lam7(V self, V *args) {
  V v_a_2424 = args[0];
  V v_a_2421 = heff_env(self)[0];
  V v_a_2422 = heff_env(self)[1];
  V v_a_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_a_2421;
  heff_room[0] = v_a_2424;
  heff_room[1] = v_a_2422;
  heff_room[2] = v_a_2423;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eop_24s15141126x503873151_lam6(V self, V *args) {
  V v_a_2420 = args[0];
  V v_a_2421 = args[1];
  V v_a_2422 = args[2];
  V v_a_2423 = args[3];
  V f_ = v_a_2420;
  args[0] = heff_dup(v_a_2422);
  args[1] = heff_clo_n(g_co_2eop_24s15141126x503873151_lam7, 1, 3, (V[]){v_a_2421, v_a_2422, v_a_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s15141126x503873151_lam8(V self, V *args) {
  V v_a_2425 = args[0];
  switch (heff_tag_of(v_a_2425)) {
  case TAG_InL: {
    V v_a_2426 = heff_field(v_a_2425, 0);
    heff_take_n(v_a_2425, 1ULL, 1);
    return ({ V a_0 = v_a_2426; V r_ = (g_std_2eprogress_2equietly_24s1392860441x1460275359(a_0)); heff_drop(v_a_2426); r_; });
  }
  case TAG_InR: {
    V v_a_2427 = heff_field(v_a_2425, 0);
    heff_take_n(v_a_2425, 1ULL, 1);
    V f_ = ((V)&g_co_2eop_24s384550787x906982552_clo);
    args[0] = v_a_2427;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_a_2425);
  }
}
V g_co_2eop_24s15141126x503873151_lam9(V self, V *args) {
  V v_a_2428 = args[0];
  V v_a_2429 = args[1];
  V v_a_2430 = args[2];
  heff_drop(v_a_2429);
  V f_ = v_a_2430;
  args[0] = v_a_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s15141126x503873151_lam4(V self, V *args) {
  V v_c_2416 = args[0];
  V f_ = v_c_2416;
  heff_room[0] = heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_co_2eop_24s15141126x503873151_lam5_clo), ((V)&g_co_2eop_24s15141126x503873151_lam6_clo), ((V)&g_co_2eop_24s15141126x503873151_lam8_clo)});
  heff_room[1] = ((V)&g_co_2eop_24s15141126x503873151_lam9_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s15141126x503873151_lam10(V self, V *args) {
  V v_a_2435 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_a_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s1106850457x559991957(v_t_2439, v_z_242, v_z_243));
}
V g_co_2eop_24s322634793x1879077828_lam1(V self, V *args);
V g_co_2eop_24s322634793x1879077828_lam0(V self, V *args); static Clo g_co_2eop_24s322634793x1879077828_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s322634793x1879077828_lam0, 4, 0};
V g_co_2eop_24s322634793x1879077828_lam3(V self, V *args);
V g_co_2eop_24s322634793x1879077828_lam2(V self, V *args); static Clo g_co_2eop_24s322634793x1879077828_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s322634793x1879077828_lam2, 3, 0};
V g_co_2eop_24s322634793x1879077828_lam5(V self, V *args); static Clo g_co_2eop_24s322634793x1879077828_lam5_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s322634793x1879077828_lam5, 2, 0};
V g_co_2eop_24s322634793x1879077828_lam7(V self, V *args);
V g_co_2eop_24s322634793x1879077828_lam6(V self, V *args); static Clo g_co_2eop_24s322634793x1879077828_lam6_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s322634793x1879077828_lam6, 3, 0};
V g_co_2eop_24s322634793x1879077828_lam8(V self, V *args); static Clo g_co_2eop_24s322634793x1879077828_lam8_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s322634793x1879077828_lam8, 2, 0};
V g_co_2eop_24s322634793x1879077828_lam9(V self, V *args); static Clo g_co_2eop_24s322634793x1879077828_lam9_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s322634793x1879077828_lam9, 2, 0};
V g_co_2eop_24s322634793x1879077828_lam4(V self, V *args); static Clo g_co_2eop_24s322634793x1879077828_lam4_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s322634793x1879077828_lam4, 1, 0};
V g_co_2eop_24s322634793x1879077828_lam10(V self, V *args);
Clo g_co_2eop_24s322634793x1879077828_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s322634793x1879077828_entry, 3, 0};

V g_co_2eop_24s322634793x1879077828(V v_p_240, V v_k2_241, V v_z_242) {
top: ;
  V v_a_2436;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1100180636x1646925226_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s322634793x1879077828_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s322634793x1879077828_lam2_clo)}), ((V)&g_co_2eop_24s322634793x1879077828_lam4_clo), v_x_243}));
    v_a_2436 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2426});
    break;
  }
  case TAG_InR: {
    V v_y_2427 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2435;
    switch (heff_tag_of(v_y_2427)) {
    case TAG_IsTerminal: {
      V v_k_2428 = heff_field(v_y_2427, 0);
      heff_take_n(v_y_2427, 1ULL, 1);
      v_t_2435 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_IsTerminal, 1, (V[]){v_k_2428});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_2429 = heff_field(v_y_2427, 0);
      V v_x_2430 = heff_field(v_y_2427, 1);
      V v_ru_24y_2427_24ShowLines = heff_take_reuse_n(v_y_2427, 3ULL, 2);
      heff_drop_cell(v_ru_24p_240_24InR, 1);
      v_t_2435 = heff_tag_at_n(v_ru_24y_2427_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2429, v_x_2430});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2431 = heff_field(v_y_2427, 0);
      V v_as_2432 = heff_field(v_y_2427, 1);
      V v_lines_2433 = heff_field(v_y_2427, 2);
      V v_k_2434 = heff_field(v_y_2427, 3);
      V v_ru_24y_2427_24ShowRun = heff_take_reuse_n(v_y_2427, 15ULL, 4);
      heff_drop_cell(v_ru_24p_240_24InR, 1);
      v_t_2435 = heff_tag_at_n(v_ru_24y_2427_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2431, v_as_2432, v_lines_2433, v_k_2434});
      break;
    }
    default: heff_nomatch(v_y_2427);
    }
    v_a_2436 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2435});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  return heff_perform(v_a_2436, heff_clo_n(g_co_2eop_24s322634793x1879077828_lam10, 1, 2, (V[]){v_k2_241, v_z_242}));
}
V g_co_2eop_24s322634793x1879077828_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s322634793x1879077828(a[0], a[1], a[2]);
}
V g_co_2eop_24s322634793x1879077828_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s322634793x1879077828_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s322634793x1879077828_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s322634793x1879077828_lam3(V self, V *args) {
  V v_a_2413 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_a_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2414 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_a_2413}));
  V f_ = v_a_2412;
  args[0] = v_a_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s322634793x1879077828_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_a_2412 = args[2];
  V f_ = v_m_2411;
  args[0] = heff_clo_n(g_co_2eop_24s322634793x1879077828_lam3, 1, 2, (V[]){v_g_2410, v_a_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s322634793x1879077828_lam5(V self, V *args) {
  V v_a_2416 = args[0];
  V v_a_2417 = args[1];
  V f_ = v_a_2417;
  args[0] = v_a_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s322634793x1879077828_lam7(V self, V *args) {
  V v_a_2421 = args[0];
  V v_a_2419 = heff_env(self)[0];
  V v_a_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2419;
  heff_room[0] = v_a_2421;
  heff_room[1] = v_a_2420;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s322634793x1879077828_lam6(V self, V *args) {
  V v_a_2418 = args[0];
  V v_a_2419 = args[1];
  V v_a_2420 = args[2];
  V f_ = v_a_2418;
  args[0] = heff_clo_n(g_co_2eop_24s322634793x1879077828_lam7, 1, 2, (V[]){v_a_2419, v_a_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s322634793x1879077828_lam8(V self, V *args) {
  V v_a_2422 = args[0];
  V v_a_2423 = args[1];
  return heff_perform(v_a_2422, v_a_2423);
}
V g_co_2eop_24s322634793x1879077828_lam9(V self, V *args) {
  V v_a_2424 = args[0];
  V v_a_2425 = args[1];
  V f_ = v_a_2425;
  args[0] = v_a_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s322634793x1879077828_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V f_ = v_c_2415;
  heff_room[0] = heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_co_2eop_24s322634793x1879077828_lam5_clo), ((V)&g_co_2eop_24s322634793x1879077828_lam6_clo), ((V)&g_co_2eop_24s322634793x1879077828_lam8_clo)});
  heff_room[1] = ((V)&g_co_2eop_24s322634793x1879077828_lam9_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s322634793x1879077828_lam10(V self, V *args) {
  V v_a_2437 = args[0];
  V v_k2_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k2_241;
  heff_room[0] = v_a_2437;
  heff_room[1] = v_z_242;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s635711115x1057317164_lam1(V self, V *args);
V g_co_2eop_24s635711115x1057317164_lam0(V self, V *args); static Clo g_co_2eop_24s635711115x1057317164_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s635711115x1057317164_lam0, 4, 0};
V g_co_2eop_24s635711115x1057317164_lam3(V self, V *args);
V g_co_2eop_24s635711115x1057317164_lam2(V self, V *args); static Clo g_co_2eop_24s635711115x1057317164_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s635711115x1057317164_lam2, 3, 0};
V g_co_2eop_24s635711115x1057317164_lam5(V self, V *args); static Clo g_co_2eop_24s635711115x1057317164_lam5_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s635711115x1057317164_lam5, 2, 0};
V g_co_2eop_24s635711115x1057317164_lam7(V self, V *args);
V g_co_2eop_24s635711115x1057317164_lam6(V self, V *args); static Clo g_co_2eop_24s635711115x1057317164_lam6_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s635711115x1057317164_lam6, 3, 0};
V g_co_2eop_24s635711115x1057317164_lam8(V self, V *args); static Clo g_co_2eop_24s635711115x1057317164_lam8_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s635711115x1057317164_lam8, 2, 0};
V g_co_2eop_24s635711115x1057317164_lam9(V self, V *args); static Clo g_co_2eop_24s635711115x1057317164_lam9_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s635711115x1057317164_lam9, 2, 0};
V g_co_2eop_24s635711115x1057317164_lam4(V self, V *args); static Clo g_co_2eop_24s635711115x1057317164_lam4_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s635711115x1057317164_lam4, 1, 0};
V g_co_2eop_24s635711115x1057317164_lam11(V self, V *args);
V g_co_2eop_24s635711115x1057317164_lam10(V self, V *args);
Clo g_co_2eop_24s635711115x1057317164_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s635711115x1057317164_entry, 2, 0};

V g_co_2eop_24s635711115x1057317164(V v_p_240, V v_k2_241) {
top: ;
  V v_a_2435;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_242 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1100180636x1646925226_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s635711115x1057317164_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s635711115x1057317164_lam2_clo)}), ((V)&g_co_2eop_24s635711115x1057317164_lam4_clo), v_x_242}));
    v_a_2435 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2425});
    break;
  }
  case TAG_InR: {
    V v_y_2426 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2434;
    switch (heff_tag_of(v_y_2426)) {
    case TAG_IsTerminal: {
      V v_k_2427 = heff_field(v_y_2426, 0);
      heff_take_n(v_y_2426, 1ULL, 1);
      v_t_2434 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_IsTerminal, 1, (V[]){v_k_2427});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_2428 = heff_field(v_y_2426, 0);
      V v_x_2429 = heff_field(v_y_2426, 1);
      V v_ru_24y_2426_24ShowLines = heff_take_reuse_n(v_y_2426, 3ULL, 2);
      heff_drop_cell(v_ru_24p_240_24InR, 1);
      v_t_2434 = heff_tag_at_n(v_ru_24y_2426_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2428, v_x_2429});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2430 = heff_field(v_y_2426, 0);
      V v_as_2431 = heff_field(v_y_2426, 1);
      V v_lines_2432 = heff_field(v_y_2426, 2);
      V v_k_2433 = heff_field(v_y_2426, 3);
      V v_ru_24y_2426_24ShowRun = heff_take_reuse_n(v_y_2426, 15ULL, 4);
      heff_drop_cell(v_ru_24p_240_24InR, 1);
      v_t_2434 = heff_tag_at_n(v_ru_24y_2426_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2430, v_as_2431, v_lines_2432, v_k_2433});
      break;
    }
    default: heff_nomatch(v_y_2426);
    }
    v_a_2435 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2434});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  return heff_clo_n(g_co_2eop_24s635711115x1057317164_lam10, 1, 2, (V[]){v_a_2435, v_k2_241});
}
V g_co_2eop_24s635711115x1057317164_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s635711115x1057317164(a[0], a[1]);
}
V g_co_2eop_24s635711115x1057317164_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s635711115x1057317164_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s635711115x1057317164_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s635711115x1057317164_lam3(V self, V *args) {
  V v_a_2412 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_a_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2413 = heff_tr(heff_call(v_g_249, 1, (V[]){v_a_2412}));
  V f_ = v_a_2411;
  args[0] = v_a_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s635711115x1057317164_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_a_2411 = args[2];
  V f_ = v_m_2410;
  args[0] = heff_clo_n(g_co_2eop_24s635711115x1057317164_lam3, 1, 2, (V[]){v_g_249, v_a_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s635711115x1057317164_lam5(V self, V *args) {
  V v_a_2415 = args[0];
  V v_a_2416 = args[1];
  V f_ = v_a_2416;
  args[0] = v_a_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s635711115x1057317164_lam7(V self, V *args) {
  V v_a_2420 = args[0];
  V v_a_2418 = heff_env(self)[0];
  V v_a_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2418;
  heff_room[0] = v_a_2420;
  heff_room[1] = v_a_2419;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s635711115x1057317164_lam6(V self, V *args) {
  V v_a_2417 = args[0];
  V v_a_2418 = args[1];
  V v_a_2419 = args[2];
  V f_ = v_a_2417;
  args[0] = heff_clo_n(g_co_2eop_24s635711115x1057317164_lam7, 1, 2, (V[]){v_a_2418, v_a_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s635711115x1057317164_lam8(V self, V *args) {
  V v_a_2421 = args[0];
  V v_a_2422 = args[1];
  return heff_perform(v_a_2421, v_a_2422);
}
V g_co_2eop_24s635711115x1057317164_lam9(V self, V *args) {
  V v_a_2423 = args[0];
  V v_a_2424 = args[1];
  V f_ = v_a_2424;
  args[0] = v_a_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s635711115x1057317164_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V f_ = v_c_2414;
  heff_room[0] = heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_co_2eop_24s635711115x1057317164_lam5_clo), ((V)&g_co_2eop_24s635711115x1057317164_lam6_clo), ((V)&g_co_2eop_24s635711115x1057317164_lam8_clo)});
  heff_room[1] = ((V)&g_co_2eop_24s635711115x1057317164_lam9_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s635711115x1057317164_lam11(V self, V *args) {
  V v_a_2437 = args[0];
  V v_k2_241 = heff_env(self)[0];
  V v_a_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k2_241;
  heff_room[0] = v_a_2437;
  heff_room[1] = v_a_2436;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s635711115x1057317164_lam10(V self, V *args) {
  V v_a_2436 = args[0];
  V v_a_2435 = heff_env(self)[0];
  V v_k2_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_perform(v_a_2435, heff_clo_n(g_co_2eop_24s635711115x1057317164_lam11, 1, 2, (V[]){v_k2_241, v_a_2436}));
}