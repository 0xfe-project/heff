// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Args 26338
#define TAG_Await 41810
#define TAG_Catch 6517
#define TAG_Complete 48856
#define TAG_Copy 17796
#define TAG_End 17255
#define TAG_ErrColor 60683
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_Get 18914
#define TAG_GetEnv 43934
#define TAG_IsTerminal 53507
#define TAG_Log 24016
#define TAG_MkDir 57961
#define TAG_Move 53768
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_Platform 55558
#define TAG_ProgramPath 46819
#define TAG_ProjectFiles 9175
#define TAG_Put 28059
#define TAG_Quit 47258
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_ReadOnly 17623
#define TAG_ReadStdin 20528
#define TAG_Remove 9747
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_Send 26077
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_UriPath 39251
#define TAG_UseColor 15915
#define TAG_WorkingDir 28879
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_bind 9519364
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_ret 322331
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
V g_co_2ebind_24s1940951783x1983570393(V, V, V);
V g_co_2ebind_24s1940951783x1983570393_entry(V self, V *a);
extern Clo g_co_2ebind_24s1940951783x1983570393_clo;
V g_co_2eplus_24s1437756810x1731313953_get(void);
V g_co_2eplus_24s1472866478x1491968207_get(void);
V g_co_2eplus_24s1499074119x1407181331_get(void);
V g_co_2eplus_24s1682480088x1491420330_get(void);
V g_co_2eplus_24s645371449x668519272_get(void);
V g_co_2eplus_24s892172295x222364517_get(void);
V g_co_2ethrough_24s1918455300x553827868_get(void);
V g_heff_2erpc_2erpc_get(void);
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2efoldl_24s1546929672x1472202881(V, V);
V g_prelude_2efoldl_24s1546929672x1472202881_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1546929672x1472202881_clo;
V g_prelude_2efoldl_24s2095412982x241182197(V, V);
V g_prelude_2efoldl_24s2095412982x241182197_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s2095412982x241182197_clo;
V g_prelude_2emap_24s531459667x996402587(V);
V g_prelude_2emap_24s531459667x996402587_entry(V self, V *a);
extern Clo g_prelude_2emap_24s531459667x996402587_clo;
V g_std_2efilesystem_2efs_get(void);
V g_std_2eprocess_2eprocess_get(void);
V g_std_2eprogress_2eprogress_get(void);
V g_std_2eprogress_2equietly_24s755065368x1740453353(V);
V g_std_2eprogress_2equietly_24s755065368x1740453353_entry(V self, V *a);
extern Clo g_std_2eprogress_2equietly_24s755065368x1740453353_clo;
V g_co_2eplus_24s645371449x668519272_lam1(V self, V *args);
V g_co_2eplus_24s645371449x668519272_lam2(V self, V *args);
V g_co_2eplus_24s645371449x668519272_lam0(V self, V *args); static Clo g_co_2eplus_24s645371449x668519272_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s645371449x668519272_lam0, 3, 0};
V g_co_2eplus_24s645371449x668519272_lam4(V self, V *args);
V g_co_2eplus_24s645371449x668519272_lam3(V self, V *args); static Clo g_co_2eplus_24s645371449x668519272_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s645371449x668519272_lam3, 2, 0};

static V g_co_2eplus_24s645371449x668519272_val;
static int g_co_2eplus_24s645371449x668519272_st;
static V g_co_2eplus_24s645371449x668519272_init(void) {
  return heff_rec(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s645371449x668519272_lam0_clo), ((V)&g_co_2eplus_24s645371449x668519272_lam3_clo)});
}
V g_co_2eplus_24s645371449x668519272_get(void) {
  if (g_co_2eplus_24s645371449x668519272_st == 2) return g_co_2eplus_24s645371449x668519272_val;
  if (g_co_2eplus_24s645371449x668519272_st == 1) heff_fail("defined by itself");
  g_co_2eplus_24s645371449x668519272_st = 1;
  g_co_2eplus_24s645371449x668519272_val = heff_tr(g_co_2eplus_24s645371449x668519272_init());
  g_co_2eplus_24s645371449x668519272_st = 2;
  return g_co_2eplus_24s645371449x668519272_val;
}
V g_co_2eplus_24s645371449x668519272_lam1(V self, V *args) {
  V v_st_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_apply(v_k_244, 1, (V[]){v_st_245}));
  V f_ = v_g_241;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s645371449x668519272_lam2(V self, V *args) {
  V v_s_2416 = args[0];
  V v_h_2414 = heff_env(self)[0];
  V v_fm_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_tr(heff_apply(v_h_2414, 1, (V[]){v_s_2416}));
  return heff_tail(v_fm_240, 2, (V[]){v_g_241, v_t_2417});
}
V g_co_2eplus_24s645371449x668519272_lam0(V self, V *args) {
  V v_fm_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_fm_240);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Get: {
      V v_k_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      v_t_2410 = heff_tag_at(v_ru_24p_242_24InL, TAG_Get, 1, (V[]){heff_clo(g_co_2eplus_24s645371449x668519272_lam1, 1, 2, (V[]){v_k_244, v_g_241})});
      break;
    }
    case TAG_Put: {
      V v_st_247 = heff_field(v_x_243, 0);
      V v_x_248 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Put = heff_take_reuse_n(v_x_243, 3ULL, 2);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_249 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_248}));
      v_t_2410 = heff_tag_at(v_ru_24x_243_24Put, TAG_Put, 2, (V[]){v_st_247, v_t_249});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag(TAG_InL, 1, (V[]){v_t_2410});
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_y_2411)) {
    case TAG_Throw: {
      V v_s_2412 = heff_field(v_y_2411, 0);
      heff_take_n(v_y_2411, 1ULL, 1);
      heff_drop(v_fm_240);
      heff_drop(v_g_241);
      v_t_2418 = heff_tag_at(v_ru_24p_242_24InR, TAG_Throw, 1, (V[]){v_s_2412});
      break;
    }
    case TAG_Catch: {
      V v_c_2413 = heff_field(v_y_2411, 0);
      V v_h_2414 = heff_field(v_y_2411, 1);
      V v_ru_24y_2411_24Catch = heff_take_reuse_n(v_y_2411, 3ULL, 2);
      heff_drop_cell(v_ru_24p_242_24InR, 1);
      V v_t_2415 = heff_tr(heff_apply(heff_dup(v_fm_240), 2, (V[]){heff_dup(v_g_241), v_c_2413}));
      v_t_2418 = heff_tag_at(v_ru_24y_2411_24Catch, TAG_Catch, 2, (V[]){v_t_2415, heff_clo(g_co_2eplus_24s645371449x668519272_lam2, 1, 3, (V[]){v_h_2414, v_fm_240, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_2411);
    }
    return heff_tag(TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s645371449x668519272_lam4(V self, V *args) {
  V v_s_2431 = args[0];
  V v_h_2429 = heff_env(self)[0];
  V v_nt_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_tr(heff_apply(v_h_2429, 1, (V[]){v_s_2431}));
  V f_ = v_nt_2419;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s645371449x668519272_lam3(V self, V *args) {
  V v_nt_2419 = args[0];
  V v_p_2420 = args[1];
  switch (heff_tag_of(v_p_2420)) {
  case TAG_InL: {
    V v_x_2421 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InL = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    heff_drop(v_nt_2419);
    V v_t_2425;
    switch (heff_tag_of(v_x_2421)) {
    case TAG_Get: {
      V v_k_2422 = heff_field(v_x_2421, 0);
      heff_take_n(v_x_2421, 1ULL, 1);
      v_t_2425 = heff_tag_at(v_ru_24p_2420_24InL, TAG_Get, 1, (V[]){v_k_2422});
      break;
    }
    case TAG_Put: {
      V v_st_2423 = heff_field(v_x_2421, 0);
      V v_x_2424 = heff_field(v_x_2421, 1);
      V v_ru_24x_2421_24Put = heff_take_reuse_n(v_x_2421, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2420_24InL, 1);
      v_t_2425 = heff_tag_at(v_ru_24x_2421_24Put, TAG_Put, 2, (V[]){v_st_2423, v_x_2424});
      break;
    }
    default: heff_nomatch(v_x_2421);
    }
    return heff_tag(TAG_InL, 1, (V[]){v_t_2425});
  }
  case TAG_InR: {
    V v_y_2426 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InR = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    V v_t_2433;
    switch (heff_tag_of(v_y_2426)) {
    case TAG_Throw: {
      V v_s_2427 = heff_field(v_y_2426, 0);
      heff_take_n(v_y_2426, 1ULL, 1);
      heff_drop(v_nt_2419);
      v_t_2433 = heff_tag_at(v_ru_24p_2420_24InR, TAG_Throw, 1, (V[]){v_s_2427});
      break;
    }
    case TAG_Catch: {
      V v_c_2428 = heff_field(v_y_2426, 0);
      V v_h_2429 = heff_field(v_y_2426, 1);
      V v_ru_24y_2426_24Catch = heff_take_reuse_n(v_y_2426, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2420_24InR, 1);
      V v_t_2430 = heff_tr(heff_apply(heff_dup(v_nt_2419), 1, (V[]){v_c_2428}));
      v_t_2433 = heff_tag_at(v_ru_24y_2426_24Catch, TAG_Catch, 2, (V[]){v_t_2430, heff_clo(g_co_2eplus_24s645371449x668519272_lam4, 1, 2, (V[]){v_h_2429, v_nt_2419})});
      break;
    }
    default: heff_nomatch(v_y_2426);
    }
    return heff_tag(TAG_InR, 1, (V[]){v_t_2433});
  }
  default: return heff_nomatch(v_p_2420);
  }
}
V g_co_2ebind_24s1940951783x1983570393_lam0(V self, V *args); static Clo g_co_2ebind_24s1940951783x1983570393_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1940951783x1983570393_lam0, 1, 0};
V g_co_2ebind_24s1940951783x1983570393_lam1(V self, V *args);
Clo g_co_2ebind_24s1940951783x1983570393_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1940951783x1983570393_entry, 3, 0};

V g_co_2ebind_24s1940951783x1983570393(V v_f_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_247 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_Get, 1, (V[]){((V)&g_co_2ebind_24s1940951783x1983570393_lam0_clo)})});
  V v_t_248 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_241), LBL_malg), 1, (V[]){v_t_248}));
  return heff_tail(heff_get(heff_dup(v_hd_241), LBL_bind), 2, (V[]){v_t_249, heff_clo(g_co_2ebind_24s1940951783x1983570393_lam1, 1, 3, (V[]){v_f_240, v_hd_241, v_k_242})});
}
V g_co_2ebind_24s1940951783x1983570393_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s1940951783x1983570393(a[0], a[1], a[2]);
}
V g_co_2ebind_24s1940951783x1983570393_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_t_244 = ({ V b_0 = heff_get(v_c_243, LBL_metas); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = (g_prelude_2emap_24s531459667x996402587(v_t_244));
  V v_xs_246 = (g_prelude_2efoldl_24s2095412982x241182197(NTAG(TAG_Nil), v_t_245));
  return (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_246));
}
V g_co_2ebind_24s1940951783x1983570393_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tail(v_f_240, 3, (V[]){v_x_2410, v_hd_241, v_k_242});
}
V g_co_2eplus_24s892172295x222364517_lam1(V self, V *args);
V g_co_2eplus_24s892172295x222364517_lam0(V self, V *args); static Clo g_co_2eplus_24s892172295x222364517_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s892172295x222364517_lam0, 3, 0};
V g_co_2eplus_24s892172295x222364517_lam2(V self, V *args); static Clo g_co_2eplus_24s892172295x222364517_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s892172295x222364517_lam2, 2, 0};

static V g_co_2eplus_24s892172295x222364517_val;
static int g_co_2eplus_24s892172295x222364517_st;
static V g_co_2eplus_24s892172295x222364517_init(void) {
  return heff_rec(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s892172295x222364517_lam0_clo), ((V)&g_co_2eplus_24s892172295x222364517_lam2_clo)});
}
V g_co_2eplus_24s892172295x222364517_get(void) {
  if (g_co_2eplus_24s892172295x222364517_st == 2) return g_co_2eplus_24s892172295x222364517_val;
  if (g_co_2eplus_24s892172295x222364517_st == 1) heff_fail("defined by itself");
  g_co_2eplus_24s892172295x222364517_st = 1;
  g_co_2eplus_24s892172295x222364517_val = heff_tr(g_co_2eplus_24s892172295x222364517_init());
  g_co_2eplus_24s892172295x222364517_st = 2;
  return g_co_2eplus_24s892172295x222364517_val;
}
V g_co_2eplus_24s892172295x222364517_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_apply(v_k_2410, 1, (V[]){v_s_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s892172295x222364517_lam0(V self, V *args) {
  V v_fm_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_fm_240);
    V v_t_2413;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Write: {
      V v_str_244 = heff_field(v_x_243, 0);
      V v_x_245 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Write = heff_take_reuse_n(v_x_243, 3ULL, 2);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_246 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_245}));
      v_t_2413 = heff_tag_at(v_ru_24x_243_24Write, TAG_Write, 2, (V[]){v_str_244, v_t_246});
      break;
    }
    case TAG_WriteErr: {
      V v_str_247 = heff_field(v_x_243, 0);
      V v_x_248 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24WriteErr = heff_take_reuse_n(v_x_243, 3ULL, 2);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_249 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_248}));
      v_t_2413 = heff_tag_at(v_ru_24x_243_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_247, v_t_249});
      break;
    }
    case TAG_ReadStdin: {
      V v_k_2410 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      v_t_2413 = heff_tag_at(v_ru_24p_242_24InL, TAG_ReadStdin, 1, (V[]){heff_clo(g_co_2eplus_24s892172295x222364517_lam1, 1, 2, (V[]){v_k_2410, v_g_241})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag(TAG_InL, 1, (V[]){v_t_2413});
  }
  case TAG_InR: {
    V v_y_2414 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(g_std_2eprocess_2eprocess_get()), LBL_hfmap), 3, (V[]){v_fm_240, v_g_241, v_y_2414}));
    return heff_tag_at(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2415});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s892172295x222364517_lam2(V self, V *args) {
  V v_nt_2416 = args[0];
  V v_p_2417 = args[1];
  heff_drop(v_nt_2416);
  switch (heff_tag_of(v_p_2417)) {
  case TAG_InL: {
    V v_x_2418 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InL = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    V v_t_2424;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_Write: {
      V v_str_2419 = heff_field(v_x_2418, 0);
      V v_x_2420 = heff_field(v_x_2418, 1);
      V v_ru_24x_2418_24Write = heff_take_reuse_n(v_x_2418, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2417_24InL, 1);
      v_t_2424 = heff_tag_at(v_ru_24x_2418_24Write, TAG_Write, 2, (V[]){v_str_2419, v_x_2420});
      break;
    }
    case TAG_WriteErr: {
      V v_str_2421 = heff_field(v_x_2418, 0);
      V v_x_2422 = heff_field(v_x_2418, 1);
      V v_ru_24x_2418_24WriteErr = heff_take_reuse_n(v_x_2418, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2417_24InL, 1);
      v_t_2424 = heff_tag_at(v_ru_24x_2418_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_2421, v_x_2422});
      break;
    }
    case TAG_ReadStdin: {
      V v_k_2423 = heff_field(v_x_2418, 0);
      heff_take_n(v_x_2418, 1ULL, 1);
      v_t_2424 = heff_tag_at(v_ru_24p_2417_24InL, TAG_ReadStdin, 1, (V[]){v_k_2423});
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    return heff_tag(TAG_InL, 1, (V[]){v_t_2424});
  }
  case TAG_InR: {
    V v_y_2425 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InR = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    V v_t_2440;
    switch (heff_tag_of(v_y_2425)) {
    case TAG_Args: {
      V v_k_2426 = heff_field(v_y_2425, 0);
      heff_take_n(v_y_2425, 1ULL, 1);
      v_t_2440 = heff_tag_at(v_ru_24p_2417_24InR, TAG_Args, 1, (V[]){v_k_2426});
      break;
    }
    case TAG_GetEnv: {
      V v_name_2427 = heff_field(v_y_2425, 0);
      V v_k_2428 = heff_field(v_y_2425, 1);
      V v_ru_24y_2425_24GetEnv = heff_take_reuse_n(v_y_2425, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2417_24InR, 1);
      v_t_2440 = heff_tag_at(v_ru_24y_2425_24GetEnv, TAG_GetEnv, 2, (V[]){v_name_2427, v_k_2428});
      break;
    }
    case TAG_ProgramPath: {
      V v_k_2429 = heff_field(v_y_2425, 0);
      heff_take_n(v_y_2425, 1ULL, 1);
      v_t_2440 = heff_tag_at(v_ru_24p_2417_24InR, TAG_ProgramPath, 1, (V[]){v_k_2429});
      break;
    }
    case TAG_WorkingDir: {
      V v_k_2430 = heff_field(v_y_2425, 0);
      heff_take_n(v_y_2425, 1ULL, 1);
      v_t_2440 = heff_tag_at(v_ru_24p_2417_24InR, TAG_WorkingDir, 1, (V[]){v_k_2430});
      break;
    }
    case TAG_Platform: {
      V v_k_2431 = heff_field(v_y_2425, 0);
      heff_take_n(v_y_2425, 1ULL, 1);
      v_t_2440 = heff_tag_at(v_ru_24p_2417_24InR, TAG_Platform, 1, (V[]){v_k_2431});
      break;
    }
    case TAG_Exit: {
      V v_code_2432 = heff_field(v_y_2425, 0);
      V v_x_2433 = heff_field(v_y_2425, 1);
      V v_ru_24y_2425_24Exit = heff_take_reuse_n(v_y_2425, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2417_24InR, 1);
      v_t_2440 = heff_tag_at(v_ru_24y_2425_24Exit, TAG_Exit, 2, (V[]){v_code_2432, v_x_2433});
      break;
    }
    case TAG_Exec: {
      V v_cmd_2434 = heff_field(v_y_2425, 0);
      V v_as_2435 = heff_field(v_y_2425, 1);
      V v_x_2436 = heff_field(v_y_2425, 2);
      V v_ru_24y_2425_24Exec = heff_take_reuse_n(v_y_2425, 7ULL, 3);
      heff_drop_cell(v_ru_24p_2417_24InR, 1);
      v_t_2440 = heff_tag_at(v_ru_24y_2425_24Exec, TAG_Exec, 3, (V[]){v_cmd_2434, v_as_2435, v_x_2436});
      break;
    }
    case TAG_Run: {
      V v_cmd_2437 = heff_field(v_y_2425, 0);
      V v_as_2438 = heff_field(v_y_2425, 1);
      V v_k_2439 = heff_field(v_y_2425, 2);
      V v_ru_24y_2425_24Run = heff_take_reuse_n(v_y_2425, 7ULL, 3);
      heff_drop_cell(v_ru_24p_2417_24InR, 1);
      v_t_2440 = heff_tag_at(v_ru_24y_2425_24Run, TAG_Run, 3, (V[]){v_cmd_2437, v_as_2438, v_k_2439});
      break;
    }
    default: heff_nomatch(v_y_2425);
    }
    return heff_tag(TAG_InR, 1, (V[]){v_t_2440});
  }
  default: return heff_nomatch(v_p_2417);
  }
}
V g_co_2eplus_24s1472866478x1491968207_lam1(V self, V *args);
V g_co_2eplus_24s1472866478x1491968207_lam0(V self, V *args); static Clo g_co_2eplus_24s1472866478x1491968207_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1472866478x1491968207_lam0, 3, 0};
V g_co_2eplus_24s1472866478x1491968207_lam2(V self, V *args); static Clo g_co_2eplus_24s1472866478x1491968207_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1472866478x1491968207_lam2, 2, 0};

static V g_co_2eplus_24s1472866478x1491968207_val;
static int g_co_2eplus_24s1472866478x1491968207_st;
static V g_co_2eplus_24s1472866478x1491968207_init(void) {
  return heff_rec(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1472866478x1491968207_lam0_clo), ((V)&g_co_2eplus_24s1472866478x1491968207_lam2_clo)});
}
V g_co_2eplus_24s1472866478x1491968207_get(void) {
  if (g_co_2eplus_24s1472866478x1491968207_st == 2) return g_co_2eplus_24s1472866478x1491968207_val;
  if (g_co_2eplus_24s1472866478x1491968207_st == 1) heff_fail("defined by itself");
  g_co_2eplus_24s1472866478x1491968207_st = 1;
  g_co_2eplus_24s1472866478x1491968207_val = heff_tr(g_co_2eplus_24s1472866478x1491968207_init());
  g_co_2eplus_24s1472866478x1491968207_st = 2;
  return g_co_2eplus_24s1472866478x1491968207_val;
}
V g_co_2eplus_24s1472866478x1491968207_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_apply(v_k_2411, 1, (V[]){v_s_2412}));
  V f_ = v_g_241;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1472866478x1491968207_lam0(V self, V *args) {
  V v_fm_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InL = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_fm_240);
      V v_t_2414;
      switch (heff_tag_of(v_x_244)) {
      case TAG_Write: {
        V v_str_245 = heff_field(v_x_244, 0);
        V v_x_246 = heff_field(v_x_244, 1);
        V v_ru_24x_244_24Write = heff_take_reuse_n(v_x_244, 3ULL, 2);
        heff_drop_cell(v_ru_24p_242_24InL, 1);
        V v_t_247 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_246}));
        v_t_2414 = heff_tag_at(v_ru_24x_244_24Write, TAG_Write, 2, (V[]){v_str_245, v_t_247});
        break;
      }
      case TAG_WriteErr: {
        V v_str_248 = heff_field(v_x_244, 0);
        V v_x_249 = heff_field(v_x_244, 1);
        V v_ru_24x_244_24WriteErr = heff_take_reuse_n(v_x_244, 3ULL, 2);
        heff_drop_cell(v_ru_24p_242_24InL, 1);
        V v_t_2410 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_249}));
        v_t_2414 = heff_tag_at(v_ru_24x_244_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_248, v_t_2410});
        break;
      }
      case TAG_ReadStdin: {
        V v_k_2411 = heff_field(v_x_244, 0);
        heff_take_n(v_x_244, 1ULL, 1);
        v_t_2414 = heff_tag_at(v_ru_24p_242_24InL, TAG_ReadStdin, 1, (V[]){heff_clo(g_co_2eplus_24s1472866478x1491968207_lam1, 1, 2, (V[]){v_k_2411, v_g_241})});
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      v_t_2417 = heff_tag_at(v_ru_24x_243_24InL, TAG_InL, 1, (V[]){v_t_2414});
      break;
    }
    case TAG_InR: {
      V v_y_2415 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(g_std_2eprocess_2eprocess_get()), LBL_hfmap), 3, (V[]){v_fm_240, v_g_241, v_y_2415}));
      v_t_2417 = heff_tag_at(v_ru_24p_242_24InL, TAG_InR, 1, (V[]){v_t_2416});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag(TAG_InL, 1, (V[]){v_t_2417});
  }
  case TAG_InR: {
    V v_y_2418 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2419 = heff_tr(heff_apply(heff_get(heff_dup(g_std_2efilesystem_2efs_get()), LBL_hfmap), 3, (V[]){v_fm_240, v_g_241, v_y_2418}));
    return heff_tag_at(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1472866478x1491968207_lam2(V self, V *args) {
  V v_nt_2420 = args[0];
  V v_p_2421 = args[1];
  switch (heff_tag_of(v_p_2421)) {
  case TAG_InL: {
    V v_x_2422 = heff_field(v_p_2421, 0);
    V v_ru_24p_2421_24InL = heff_take_reuse_n(v_p_2421, 1ULL, 1);
    V v_t_2423 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s892172295x222364517_get()), LBL_hmap), 2, (V[]){v_nt_2420, v_x_2422}));
    return heff_tag_at(v_ru_24p_2421_24InL, TAG_InL, 1, (V[]){v_t_2423});
  }
  case TAG_InR: {
    V v_y_2424 = heff_field(v_p_2421, 0);
    V v_ru_24p_2421_24InR = heff_take_reuse_n(v_p_2421, 1ULL, 1);
    heff_drop(v_nt_2420);
    V v_t_2444;
    switch (heff_tag_of(v_y_2424)) {
    case TAG_ReadFile: {
      V v_path_2425 = heff_field(v_y_2424, 0);
      V v_k_2426 = heff_field(v_y_2424, 1);
      V v_ru_24y_2424_24ReadFile = heff_take_reuse_n(v_y_2424, 3ULL, 2);
      v_t_2444 = heff_tag_at(v_ru_24y_2424_24ReadFile, TAG_ReadFile, 2, (V[]){v_path_2425, v_k_2426});
      break;
    }
    case TAG_WriteFile: {
      V v_path_2427 = heff_field(v_y_2424, 0);
      V v_str_2428 = heff_field(v_y_2424, 1);
      V v_k_2429 = heff_field(v_y_2424, 2);
      V v_ru_24y_2424_24WriteFile = heff_take_reuse_n(v_y_2424, 7ULL, 3);
      v_t_2444 = heff_tag_at(v_ru_24y_2424_24WriteFile, TAG_WriteFile, 3, (V[]){v_path_2427, v_str_2428, v_k_2429});
      break;
    }
    case TAG_MkDir: {
      V v_path_2430 = heff_field(v_y_2424, 0);
      V v_k_2431 = heff_field(v_y_2424, 1);
      V v_ru_24y_2424_24MkDir = heff_take_reuse_n(v_y_2424, 3ULL, 2);
      v_t_2444 = heff_tag_at(v_ru_24y_2424_24MkDir, TAG_MkDir, 2, (V[]){v_path_2430, v_k_2431});
      break;
    }
    case TAG_ReadDir: {
      V v_path_2432 = heff_field(v_y_2424, 0);
      V v_k_2433 = heff_field(v_y_2424, 1);
      V v_ru_24y_2424_24ReadDir = heff_take_reuse_n(v_y_2424, 3ULL, 2);
      v_t_2444 = heff_tag_at(v_ru_24y_2424_24ReadDir, TAG_ReadDir, 2, (V[]){v_path_2432, v_k_2433});
      break;
    }
    case TAG_Remove: {
      V v_path_2434 = heff_field(v_y_2424, 0);
      V v_k_2435 = heff_field(v_y_2424, 1);
      V v_ru_24y_2424_24Remove = heff_take_reuse_n(v_y_2424, 3ULL, 2);
      v_t_2444 = heff_tag_at(v_ru_24y_2424_24Remove, TAG_Remove, 2, (V[]){v_path_2434, v_k_2435});
      break;
    }
    case TAG_ReadOnly: {
      V v_path_2436 = heff_field(v_y_2424, 0);
      V v_k_2437 = heff_field(v_y_2424, 1);
      V v_ru_24y_2424_24ReadOnly = heff_take_reuse_n(v_y_2424, 3ULL, 2);
      v_t_2444 = heff_tag_at(v_ru_24y_2424_24ReadOnly, TAG_ReadOnly, 2, (V[]){v_path_2436, v_k_2437});
      break;
    }
    case TAG_Copy: {
      V v_path_2438 = heff_field(v_y_2424, 0);
      V v_to_2439 = heff_field(v_y_2424, 1);
      V v_k_2440 = heff_field(v_y_2424, 2);
      V v_ru_24y_2424_24Copy = heff_take_reuse_n(v_y_2424, 7ULL, 3);
      v_t_2444 = heff_tag_at(v_ru_24y_2424_24Copy, TAG_Copy, 3, (V[]){v_path_2438, v_to_2439, v_k_2440});
      break;
    }
    case TAG_Move: {
      V v_path_2441 = heff_field(v_y_2424, 0);
      V v_to_2442 = heff_field(v_y_2424, 1);
      V v_k_2443 = heff_field(v_y_2424, 2);
      V v_ru_24y_2424_24Move = heff_take_reuse_n(v_y_2424, 7ULL, 3);
      v_t_2444 = heff_tag_at(v_ru_24y_2424_24Move, TAG_Move, 3, (V[]){v_path_2441, v_to_2442, v_k_2443});
      break;
    }
    default: heff_nomatch(v_y_2424);
    }
    return heff_tag_at(v_ru_24p_2421_24InR, TAG_InR, 1, (V[]){v_t_2444});
  }
  default: return heff_nomatch(v_p_2421);
  }
}
V g_co_2eplus_24s1499074119x1407181331_lam1(V self, V *args);
V g_co_2eplus_24s1499074119x1407181331_lam2(V self, V *args);
V g_co_2eplus_24s1499074119x1407181331_lam0(V self, V *args); static Clo g_co_2eplus_24s1499074119x1407181331_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1499074119x1407181331_lam0, 3, 0};
V g_co_2eplus_24s1499074119x1407181331_lam3(V self, V *args); static Clo g_co_2eplus_24s1499074119x1407181331_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1499074119x1407181331_lam3, 2, 0};

static V g_co_2eplus_24s1499074119x1407181331_val;
static int g_co_2eplus_24s1499074119x1407181331_st;
static V g_co_2eplus_24s1499074119x1407181331_init(void) {
  return heff_rec(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1499074119x1407181331_lam0_clo), ((V)&g_co_2eplus_24s1499074119x1407181331_lam3_clo)});
}
V g_co_2eplus_24s1499074119x1407181331_get(void) {
  if (g_co_2eplus_24s1499074119x1407181331_st == 2) return g_co_2eplus_24s1499074119x1407181331_val;
  if (g_co_2eplus_24s1499074119x1407181331_st == 1) heff_fail("defined by itself");
  g_co_2eplus_24s1499074119x1407181331_st = 1;
  g_co_2eplus_24s1499074119x1407181331_val = heff_tr(g_co_2eplus_24s1499074119x1407181331_init());
  g_co_2eplus_24s1499074119x1407181331_st = 2;
  return g_co_2eplus_24s1499074119x1407181331_val;
}
V g_co_2eplus_24s1499074119x1407181331_lam1(V self, V *args) {
  V v_b_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tr(heff_apply(v_k_247, 1, (V[]){v_b_248}));
  V f_ = v_g_241;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1499074119x1407181331_lam2(V self, V *args) {
  V v_b_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_apply(v_k_2410, 1, (V[]){v_b_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1499074119x1407181331_lam0(V self, V *args) {
  V v_fm_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      V v_t_245 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s1472866478x1491968207_get()), LBL_hfmap), 3, (V[]){v_fm_240, v_g_241, v_x_244}));
      v_t_2414 = heff_tag_at(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_245});
      break;
    }
    case TAG_InR: {
      V v_y_246 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_fm_240);
      V v_t_2413;
      switch (heff_tag_of(v_y_246)) {
      case TAG_UseColor: {
        V v_k_247 = heff_field(v_y_246, 0);
        heff_take_n(v_y_246, 1ULL, 1);
        v_t_2413 = heff_tag_at(v_ru_24p_242_24InL, TAG_UseColor, 1, (V[]){heff_clo(g_co_2eplus_24s1499074119x1407181331_lam1, 1, 2, (V[]){v_k_247, v_g_241})});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2410 = heff_field(v_y_246, 0);
        heff_take_n(v_y_246, 1ULL, 1);
        v_t_2413 = heff_tag_at(v_ru_24p_242_24InL, TAG_ErrColor, 1, (V[]){heff_clo(g_co_2eplus_24s1499074119x1407181331_lam2, 1, 2, (V[]){v_k_2410, v_g_241})});
        break;
      }
      default: heff_nomatch(v_y_246);
      }
      v_t_2414 = heff_tag_at(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2413});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag(TAG_InL, 1, (V[]){v_t_2414});
  }
  case TAG_InR: {
    V v_y_2415 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2416 = heff_tr(heff_apply(heff_get(heff_dup(g_heff_2erpc_2erpc_get()), LBL_hfmap), 3, (V[]){v_fm_240, v_g_241, v_y_2415}));
    return heff_tag_at(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2416});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1499074119x1407181331_lam3(V self, V *args) {
  V v_nt_2417 = args[0];
  V v_p_2418 = args[1];
  switch (heff_tag_of(v_p_2418)) {
  case TAG_InL: {
    V v_x_2419 = heff_field(v_p_2418, 0);
    V v_ru_24p_2418_24InL = heff_take_reuse_n(v_p_2418, 1ULL, 1);
    V v_t_2426;
    switch (heff_tag_of(v_x_2419)) {
    case TAG_InL: {
      V v_x_2420 = heff_field(v_x_2419, 0);
      heff_take_n(v_x_2419, 1ULL, 1);
      V v_t_2421 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s1472866478x1491968207_get()), LBL_hmap), 2, (V[]){v_nt_2417, v_x_2420}));
      v_t_2426 = heff_tag_at(v_ru_24p_2418_24InL, TAG_InL, 1, (V[]){v_t_2421});
      break;
    }
    case TAG_InR: {
      V v_y_2422 = heff_field(v_x_2419, 0);
      V v_ru_24x_2419_24InR = heff_take_reuse_n(v_x_2419, 1ULL, 1);
      heff_drop(v_nt_2417);
      V v_t_2425;
      switch (heff_tag_of(v_y_2422)) {
      case TAG_UseColor: {
        V v_k_2423 = heff_field(v_y_2422, 0);
        heff_take_n(v_y_2422, 1ULL, 1);
        v_t_2425 = heff_tag_at(v_ru_24p_2418_24InL, TAG_UseColor, 1, (V[]){v_k_2423});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2424 = heff_field(v_y_2422, 0);
        heff_take_n(v_y_2422, 1ULL, 1);
        v_t_2425 = heff_tag_at(v_ru_24p_2418_24InL, TAG_ErrColor, 1, (V[]){v_k_2424});
        break;
      }
      default: heff_nomatch(v_y_2422);
      }
      v_t_2426 = heff_tag_at(v_ru_24x_2419_24InR, TAG_InR, 1, (V[]){v_t_2425});
      break;
    }
    default: heff_nomatch(v_x_2419);
    }
    return heff_tag(TAG_InL, 1, (V[]){v_t_2426});
  }
  case TAG_InR: {
    V v_y_2427 = heff_field(v_p_2418, 0);
    V v_ru_24p_2418_24InR = heff_take_reuse_n(v_p_2418, 1ULL, 1);
    heff_drop(v_nt_2417);
    V v_t_2444;
    switch (heff_tag_of(v_y_2427)) {
    case TAG_Await: {
      V v_t_2428 = heff_field(v_y_2427, 0);
      V v_k_2429 = heff_field(v_y_2427, 1);
      V v_ru_24y_2427_24Await = heff_take_reuse_n(v_y_2427, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2418_24InR, 1);
      v_t_2444 = heff_tag_at(v_ru_24y_2427_24Await, TAG_Await, 2, (V[]){v_t_2428, v_k_2429});
      break;
    }
    case TAG_Send: {
      V v_s_2430 = heff_field(v_y_2427, 0);
      V v_x_2431 = heff_field(v_y_2427, 1);
      V v_ru_24y_2427_24Send = heff_take_reuse_n(v_y_2427, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2418_24InR, 1);
      v_t_2444 = heff_tag_at(v_ru_24y_2427_24Send, TAG_Send, 2, (V[]){v_s_2430, v_x_2431});
      break;
    }
    case TAG_Log: {
      V v_s_2432 = heff_field(v_y_2427, 0);
      V v_x_2433 = heff_field(v_y_2427, 1);
      V v_ru_24y_2427_24Log = heff_take_reuse_n(v_y_2427, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2418_24InR, 1);
      v_t_2444 = heff_tag_at(v_ru_24y_2427_24Log, TAG_Log, 2, (V[]){v_s_2432, v_x_2433});
      break;
    }
    case TAG_Now: {
      V v_k_2434 = heff_field(v_y_2427, 0);
      heff_take_n(v_y_2427, 1ULL, 1);
      v_t_2444 = heff_tag_at(v_ru_24p_2418_24InR, TAG_Now, 1, (V[]){v_k_2434});
      break;
    }
    case TAG_ProjectFiles: {
      V v_r_2435 = heff_field(v_y_2427, 0);
      V v_k_2436 = heff_field(v_y_2427, 1);
      V v_ru_24y_2427_24ProjectFiles = heff_take_reuse_n(v_y_2427, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2418_24InR, 1);
      v_t_2444 = heff_tag_at(v_ru_24y_2427_24ProjectFiles, TAG_ProjectFiles, 2, (V[]){v_r_2435, v_k_2436});
      break;
    }
    case TAG_UriPath: {
      V v_u_2437 = heff_field(v_y_2427, 0);
      V v_k_2438 = heff_field(v_y_2427, 1);
      V v_ru_24y_2427_24UriPath = heff_take_reuse_n(v_y_2427, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2418_24InR, 1);
      v_t_2444 = heff_tag_at(v_ru_24y_2427_24UriPath, TAG_UriPath, 2, (V[]){v_u_2437, v_k_2438});
      break;
    }
    case TAG_PathUri: {
      V v_p_2439 = heff_field(v_y_2427, 0);
      V v_k_2440 = heff_field(v_y_2427, 1);
      V v_ru_24y_2427_24PathUri = heff_take_reuse_n(v_y_2427, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2418_24InR, 1);
      v_t_2444 = heff_tag_at(v_ru_24y_2427_24PathUri, TAG_PathUri, 2, (V[]){v_p_2439, v_k_2440});
      break;
    }
    case TAG_AbsPath: {
      V v_p_2441 = heff_field(v_y_2427, 0);
      V v_k_2442 = heff_field(v_y_2427, 1);
      V v_ru_24y_2427_24AbsPath = heff_take_reuse_n(v_y_2427, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2418_24InR, 1);
      v_t_2444 = heff_tag_at(v_ru_24y_2427_24AbsPath, TAG_AbsPath, 2, (V[]){v_p_2441, v_k_2442});
      break;
    }
    case TAG_Quit: {
      V v_c_2443 = heff_field(v_y_2427, 0);
      heff_take_n(v_y_2427, 1ULL, 1);
      v_t_2444 = heff_tag_at(v_ru_24p_2418_24InR, TAG_Quit, 1, (V[]){v_c_2443});
      break;
    }
    default: heff_nomatch(v_y_2427);
    }
    return heff_tag(TAG_InR, 1, (V[]){v_t_2444});
  }
  default: return heff_nomatch(v_p_2418);
  }
}
V g_co_2eplus_24s1437756810x1731313953_lam1(V self, V *args);
V g_co_2eplus_24s1437756810x1731313953_lam2(V self, V *args);
V g_co_2eplus_24s1437756810x1731313953_lam0(V self, V *args); static Clo g_co_2eplus_24s1437756810x1731313953_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1437756810x1731313953_lam0, 3, 0};
V g_co_2eplus_24s1437756810x1731313953_lam3(V self, V *args); static Clo g_co_2eplus_24s1437756810x1731313953_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1437756810x1731313953_lam3, 2, 0};

static V g_co_2eplus_24s1437756810x1731313953_val;
static int g_co_2eplus_24s1437756810x1731313953_st;
static V g_co_2eplus_24s1437756810x1731313953_init(void) {
  return heff_rec(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1437756810x1731313953_lam0_clo), ((V)&g_co_2eplus_24s1437756810x1731313953_lam3_clo)});
}
V g_co_2eplus_24s1437756810x1731313953_get(void) {
  if (g_co_2eplus_24s1437756810x1731313953_st == 2) return g_co_2eplus_24s1437756810x1731313953_val;
  if (g_co_2eplus_24s1437756810x1731313953_st == 1) heff_fail("defined by itself");
  g_co_2eplus_24s1437756810x1731313953_st = 1;
  g_co_2eplus_24s1437756810x1731313953_val = heff_tr(g_co_2eplus_24s1437756810x1731313953_init());
  g_co_2eplus_24s1437756810x1731313953_st = 2;
  return g_co_2eplus_24s1437756810x1731313953_val;
}
V g_co_2eplus_24s1437756810x1731313953_lam1(V self, V *args) {
  V v_b_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_apply(v_k_246, 1, (V[]){v_b_247}));
  V f_ = v_g_241;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1437756810x1731313953_lam2(V self, V *args) {
  V v_r_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_apply(v_k_2415, 1, (V[]){v_r_2416}));
  V f_ = v_g_241;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1437756810x1731313953_lam0(V self, V *args) {
  V v_fm_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s1499074119x1407181331_get()), LBL_hfmap), 3, (V[]){v_fm_240, v_g_241, v_x_243}));
    return heff_tag_at(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_fm_240);
    V v_t_2418;
    switch (heff_tag_of(v_y_245)) {
    case TAG_IsTerminal: {
      V v_k_246 = heff_field(v_y_245, 0);
      heff_take_n(v_y_245, 1ULL, 1);
      v_t_2418 = heff_tag_at(v_ru_24p_242_24InR, TAG_IsTerminal, 1, (V[]){heff_clo(g_co_2eplus_24s1437756810x1731313953_lam1, 1, 2, (V[]){v_k_246, v_g_241})});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_249 = heff_field(v_y_245, 0);
      V v_x_2410 = heff_field(v_y_245, 1);
      V v_ru_24y_245_24ShowLines = heff_take_reuse_n(v_y_245, 3ULL, 2);
      heff_drop_cell(v_ru_24p_242_24InR, 1);
      V v_t_2411 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_2410}));
      v_t_2418 = heff_tag_at(v_ru_24y_245_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_249, v_t_2411});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2412 = heff_field(v_y_245, 0);
      V v_as_2413 = heff_field(v_y_245, 1);
      V v_lines_2414 = heff_field(v_y_245, 2);
      V v_k_2415 = heff_field(v_y_245, 3);
      V v_ru_24y_245_24ShowRun = heff_take_reuse_n(v_y_245, 15ULL, 4);
      heff_drop_cell(v_ru_24p_242_24InR, 1);
      v_t_2418 = heff_tag_at(v_ru_24y_245_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2412, v_as_2413, v_lines_2414, heff_clo(g_co_2eplus_24s1437756810x1731313953_lam2, 1, 2, (V[]){v_k_2415, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_245);
    }
    return heff_tag(TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1437756810x1731313953_lam3(V self, V *args) {
  V v_nt_2419 = args[0];
  V v_p_2420 = args[1];
  switch (heff_tag_of(v_p_2420)) {
  case TAG_InL: {
    V v_x_2421 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InL = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    V v_t_2422 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s1499074119x1407181331_get()), LBL_hmap), 2, (V[]){v_nt_2419, v_x_2421}));
    return heff_tag_at(v_ru_24p_2420_24InL, TAG_InL, 1, (V[]){v_t_2422});
  }
  case TAG_InR: {
    V v_y_2423 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InR = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    heff_drop(v_nt_2419);
    V v_t_2431;
    switch (heff_tag_of(v_y_2423)) {
    case TAG_IsTerminal: {
      V v_k_2424 = heff_field(v_y_2423, 0);
      heff_take_n(v_y_2423, 1ULL, 1);
      v_t_2431 = heff_tag_at(v_ru_24p_2420_24InR, TAG_IsTerminal, 1, (V[]){v_k_2424});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_2425 = heff_field(v_y_2423, 0);
      V v_x_2426 = heff_field(v_y_2423, 1);
      V v_ru_24y_2423_24ShowLines = heff_take_reuse_n(v_y_2423, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2420_24InR, 1);
      v_t_2431 = heff_tag_at(v_ru_24y_2423_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2425, v_x_2426});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2427 = heff_field(v_y_2423, 0);
      V v_as_2428 = heff_field(v_y_2423, 1);
      V v_lines_2429 = heff_field(v_y_2423, 2);
      V v_k_2430 = heff_field(v_y_2423, 3);
      V v_ru_24y_2423_24ShowRun = heff_take_reuse_n(v_y_2423, 15ULL, 4);
      heff_drop_cell(v_ru_24p_2420_24InR, 1);
      v_t_2431 = heff_tag_at(v_ru_24y_2423_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2427, v_as_2428, v_lines_2429, v_k_2430});
      break;
    }
    default: heff_nomatch(v_y_2423);
    }
    return heff_tag(TAG_InR, 1, (V[]){v_t_2431});
  }
  default: return heff_nomatch(v_p_2420);
  }
}
V g_co_2eplus_24s1682480088x1491420330_lam0(V self, V *args); static Clo g_co_2eplus_24s1682480088x1491420330_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1682480088x1491420330_lam0, 3, 0};
V g_co_2eplus_24s1682480088x1491420330_lam1(V self, V *args); static Clo g_co_2eplus_24s1682480088x1491420330_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1682480088x1491420330_lam1, 2, 0};

static V g_co_2eplus_24s1682480088x1491420330_val;
static int g_co_2eplus_24s1682480088x1491420330_st;
static V g_co_2eplus_24s1682480088x1491420330_init(void) {
  return heff_rec(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1682480088x1491420330_lam0_clo), ((V)&g_co_2eplus_24s1682480088x1491420330_lam1_clo)});
}
V g_co_2eplus_24s1682480088x1491420330_get(void) {
  if (g_co_2eplus_24s1682480088x1491420330_st == 2) return g_co_2eplus_24s1682480088x1491420330_val;
  if (g_co_2eplus_24s1682480088x1491420330_st == 1) heff_fail("defined by itself");
  g_co_2eplus_24s1682480088x1491420330_st = 1;
  g_co_2eplus_24s1682480088x1491420330_val = heff_tr(g_co_2eplus_24s1682480088x1491420330_init());
  g_co_2eplus_24s1682480088x1491420330_st = 2;
  return g_co_2eplus_24s1682480088x1491420330_val;
}
V g_co_2eplus_24s1682480088x1491420330_lam0(V self, V *args) {
  V v_fm_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_apply(heff_get(heff_dup(g_std_2eprogress_2eprogress_get()), LBL_hfmap), 3, (V[]){v_fm_240, v_g_241, v_x_243}));
    return heff_tag_at(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s1437756810x1731313953_get()), LBL_hfmap), 3, (V[]){v_fm_240, v_g_241, v_y_245}));
    return heff_tag_at(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_246});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1682480088x1491420330_lam1(V self, V *args) {
  V v_nt_247 = args[0];
  V v_p_248 = args[1];
  switch (heff_tag_of(v_p_248)) {
  case TAG_InL: {
    V v_x_249 = heff_field(v_p_248, 0);
    V v_ru_24p_248_24InL = heff_take_reuse_n(v_p_248, 1ULL, 1);
    heff_drop(v_nt_247);
    V v_t_2422;
    switch (heff_tag_of(v_x_249)) {
    case TAG_Start: {
      V v_parent_2410 = heff_field(v_x_249, 0);
      V v_name_2411 = heff_field(v_x_249, 1);
      V v_total_2412 = heff_field(v_x_249, 2);
      V v_k_2413 = heff_field(v_x_249, 3);
      V v_ru_24x_249_24Start = heff_take_reuse_n(v_x_249, 15ULL, 4);
      v_t_2422 = heff_tag_at(v_ru_24x_249_24Start, TAG_Start, 4, (V[]){v_parent_2410, v_name_2411, v_total_2412, v_k_2413});
      break;
    }
    case TAG_Complete: {
      V v_t_2414 = heff_field(v_x_249, 0);
      V v_x_2415 = heff_field(v_x_249, 1);
      V v_ru_24x_249_24Complete = heff_take_reuse_n(v_x_249, 3ULL, 2);
      v_t_2422 = heff_tag_at(v_ru_24x_249_24Complete, TAG_Complete, 2, (V[]){v_t_2414, v_x_2415});
      break;
    }
    case TAG_End: {
      V v_t_2416 = heff_field(v_x_249, 0);
      V v_x_2417 = heff_field(v_x_249, 1);
      V v_ru_24x_249_24End = heff_take_reuse_n(v_x_249, 3ULL, 2);
      v_t_2422 = heff_tag_at(v_ru_24x_249_24End, TAG_End, 2, (V[]){v_t_2416, v_x_2417});
      break;
    }
    case TAG_RunUnder: {
      V v_t_2418 = heff_field(v_x_249, 0);
      V v_cmd_2419 = heff_field(v_x_249, 1);
      V v_as_2420 = heff_field(v_x_249, 2);
      V v_k_2421 = heff_field(v_x_249, 3);
      V v_ru_24x_249_24RunUnder = heff_take_reuse_n(v_x_249, 15ULL, 4);
      v_t_2422 = heff_tag_at(v_ru_24x_249_24RunUnder, TAG_RunUnder, 4, (V[]){v_t_2418, v_cmd_2419, v_as_2420, v_k_2421});
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    return heff_tag_at(v_ru_24p_248_24InL, TAG_InL, 1, (V[]){v_t_2422});
  }
  case TAG_InR: {
    V v_y_2423 = heff_field(v_p_248, 0);
    V v_ru_24p_248_24InR = heff_take_reuse_n(v_p_248, 1ULL, 1);
    V v_t_2435;
    switch (heff_tag_of(v_y_2423)) {
    case TAG_InL: {
      V v_x_2424 = heff_field(v_y_2423, 0);
      heff_take_n(v_y_2423, 1ULL, 1);
      V v_t_2425 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s1499074119x1407181331_get()), LBL_hmap), 2, (V[]){v_nt_247, v_x_2424}));
      v_t_2435 = heff_tag_at(v_ru_24p_248_24InR, TAG_InL, 1, (V[]){v_t_2425});
      break;
    }
    case TAG_InR: {
      V v_y_2426 = heff_field(v_y_2423, 0);
      V v_ru_24y_2423_24InR = heff_take_reuse_n(v_y_2423, 1ULL, 1);
      heff_drop(v_nt_247);
      V v_t_2434;
      switch (heff_tag_of(v_y_2426)) {
      case TAG_IsTerminal: {
        V v_k_2427 = heff_field(v_y_2426, 0);
        heff_take_n(v_y_2426, 1ULL, 1);
        v_t_2434 = heff_tag_at(v_ru_24p_248_24InR, TAG_IsTerminal, 1, (V[]){v_k_2427});
        break;
      }
      case TAG_ShowLines: {
        V v_ls_2428 = heff_field(v_y_2426, 0);
        V v_x_2429 = heff_field(v_y_2426, 1);
        V v_ru_24y_2426_24ShowLines = heff_take_reuse_n(v_y_2426, 3ULL, 2);
        heff_drop_cell(v_ru_24p_248_24InR, 1);
        v_t_2434 = heff_tag_at(v_ru_24y_2426_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2428, v_x_2429});
        break;
      }
      case TAG_ShowRun: {
        V v_cmd_2430 = heff_field(v_y_2426, 0);
        V v_as_2431 = heff_field(v_y_2426, 1);
        V v_lines_2432 = heff_field(v_y_2426, 2);
        V v_k_2433 = heff_field(v_y_2426, 3);
        V v_ru_24y_2426_24ShowRun = heff_take_reuse_n(v_y_2426, 15ULL, 4);
        heff_drop_cell(v_ru_24p_248_24InR, 1);
        v_t_2434 = heff_tag_at(v_ru_24y_2426_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2430, v_as_2431, v_lines_2432, v_k_2433});
        break;
      }
      default: heff_nomatch(v_y_2426);
      }
      v_t_2435 = heff_tag_at(v_ru_24y_2423_24InR, TAG_InR, 1, (V[]){v_t_2434});
      break;
    }
    default: heff_nomatch(v_y_2423);
    }
    return heff_tag(TAG_InR, 1, (V[]){v_t_2435});
  }
  default: return heff_nomatch(v_p_248);
  }
}
V g_co_2ethrough_24s1918455300x553827868_lam0(V self, V *args); static Clo g_co_2ethrough_24s1918455300x553827868_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2ethrough_24s1918455300x553827868_lam0, 3, 0};
V g_co_2ethrough_24s1918455300x553827868_lam2(V self, V *args);
V g_co_2ethrough_24s1918455300x553827868_lam1(V self, V *args); static Clo g_co_2ethrough_24s1918455300x553827868_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2ethrough_24s1918455300x553827868_lam1, 4, 0};
V g_co_2ethrough_24s1918455300x553827868_lam5(V self, V *args);
V g_co_2ethrough_24s1918455300x553827868_lam4(V self, V *args);
V g_co_2ethrough_24s1918455300x553827868_lam3(V self, V *args); static Clo g_co_2ethrough_24s1918455300x553827868_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2ethrough_24s1918455300x553827868_lam3, 1, 0};

static V g_co_2ethrough_24s1918455300x553827868_val;
static int g_co_2ethrough_24s1918455300x553827868_st;
static V g_co_2ethrough_24s1918455300x553827868_init(void) {
  return heff_rec(3, shape_ret__bind__malg, (V[]){((V)&g_co_2ethrough_24s1918455300x553827868_lam0_clo), ((V)&g_co_2ethrough_24s1918455300x553827868_lam1_clo), ((V)&g_co_2ethrough_24s1918455300x553827868_lam3_clo)});
}
V g_co_2ethrough_24s1918455300x553827868_get(void) {
  if (g_co_2ethrough_24s1918455300x553827868_st == 2) return g_co_2ethrough_24s1918455300x553827868_val;
  if (g_co_2ethrough_24s1918455300x553827868_st == 1) heff_fail("defined by itself");
  g_co_2ethrough_24s1918455300x553827868_st = 1;
  g_co_2ethrough_24s1918455300x553827868_val = heff_tr(g_co_2ethrough_24s1918455300x553827868_init());
  g_co_2ethrough_24s1918455300x553827868_st = 2;
  return g_co_2ethrough_24s1918455300x553827868_val;
}
V g_co_2ethrough_24s1918455300x553827868_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = v_x_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2ethrough_24s1918455300x553827868_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tail(v_k_244, 3, (V[]){v_x_247, v_hd_245, v_k_246});
}
V g_co_2ethrough_24s1918455300x553827868_lam1(V self, V *args) {
  V v_m_243 = args[0];
  V v_k_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_m_243;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo(g_co_2ethrough_24s1918455300x553827868_lam2, 1, 3, (V[]){v_k_244, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2ethrough_24s1918455300x553827868_lam5(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_hd_2411), heff_get(v_hd_2411, LBL_ret)});
}
V g_co_2ethrough_24s1918455300x553827868_lam4(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k2_2412 = args[1];
  V v_q_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425;
  switch (heff_tag_of(v_q_2410)) {
  case TAG_InL: {
    V v_x_2413 = heff_field(v_q_2410, 0);
    V v_ru_24q_2410_24InL = heff_take_reuse_n(v_q_2410, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s1499074119x1407181331_get()), LBL_hmap), 2, (V[]){heff_clo(g_co_2ethrough_24s1918455300x553827868_lam5, 1, 1, (V[]){heff_dup(v_hd_2411)}), v_x_2413}));
    v_t_2425 = heff_tag_at(v_ru_24q_2410_24InL, TAG_InL, 1, (V[]){v_t_2415});
    break;
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_q_2410, 0);
    V v_ru_24q_2410_24InR = heff_take_reuse_n(v_q_2410, 1ULL, 1);
    V v_t_2424;
    switch (heff_tag_of(v_y_2416)) {
    case TAG_IsTerminal: {
      V v_k_2417 = heff_field(v_y_2416, 0);
      heff_take_n(v_y_2416, 1ULL, 1);
      v_t_2424 = heff_tag_at(v_ru_24q_2410_24InR, TAG_IsTerminal, 1, (V[]){v_k_2417});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_2418 = heff_field(v_y_2416, 0);
      V v_x_2419 = heff_field(v_y_2416, 1);
      V v_ru_24y_2416_24ShowLines = heff_take_reuse_n(v_y_2416, 3ULL, 2);
      heff_drop_cell(v_ru_24q_2410_24InR, 1);
      v_t_2424 = heff_tag_at(v_ru_24y_2416_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2418, v_x_2419});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2420 = heff_field(v_y_2416, 0);
      V v_as_2421 = heff_field(v_y_2416, 1);
      V v_lines_2422 = heff_field(v_y_2416, 2);
      V v_k_2423 = heff_field(v_y_2416, 3);
      V v_ru_24y_2416_24ShowRun = heff_take_reuse_n(v_y_2416, 15ULL, 4);
      heff_drop_cell(v_ru_24q_2410_24InR, 1);
      v_t_2424 = heff_tag_at(v_ru_24y_2416_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2420, v_as_2421, v_lines_2422, v_k_2423});
      break;
    }
    default: heff_nomatch(v_y_2416);
    }
    v_t_2425 = heff_tag(TAG_InR, 1, (V[]){v_t_2424});
    break;
  }
  default: heff_nomatch(v_q_2410);
  }
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2411), LBL_malg), 1, (V[]){v_t_2425}));
  V f_ = heff_get(v_hd_2411, LBL_bind);
  args[0] = v_t_2426;
  args[1] = v_k2_2412;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2ethrough_24s1918455300x553827868_lam3(V self, V *args) {
  V v_p_248 = args[0];
  switch (heff_tag_of(v_p_248)) {
  case TAG_InL: {
    V v_t_249 = heff_field(v_p_248, 0);
    heff_take_n(v_p_248, 1ULL, 1);
    return ({ V a_0 = v_t_249; V r_ = (g_std_2eprogress_2equietly_24s755065368x1740453353(a_0)); heff_drop(v_t_249); r_; });
  }
  case TAG_InR: {
    V v_q_2410 = heff_field(v_p_248, 0);
    heff_take_n(v_p_248, 1ULL, 1);
    return heff_clo(g_co_2ethrough_24s1918455300x553827868_lam4, 2, 1, (V[]){v_q_2410});
  }
  default: return heff_nomatch(v_p_248);
  }
}