// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
Clo g_heff_2espec_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eelemS_entry, 2, 0};

V g_heff_2espec_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_strEq(heff_dup(v_x_240), heff_dup(v_y_242));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2eelemS_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2eelemS(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2espec_2eappendS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eappendS_entry, 2, 0};

V g_heff_2espec_2eappendS(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2espec_2eappendS(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2espec_2eappendS_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2eappendS(a[0], a[1]);
}
Clo g_heff_2espec_2eallS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eallS_entry, 2, 0};

V g_heff_2espec_2eallS(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_p_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2eallS_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2eallS(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2espec_2eclosedIn_lam0(V self, V *args);
Clo g_heff_2espec_2eclosedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eclosedIn_entry, 2, 0};

V g_heff_2espec_2eclosedIn(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    return ({ V a_0 = heff_dup(v_x_242); V a_1 = v_env_240; V r_ = (g_heff_2espec_2eelemS(a_0, a_1)); heff_drop(v_env_240); r_; });
  }
  case TAG_EGlobal: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_x2_241, 0);
    V v_b_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2espec_2eappendS(heff_dup(v_xs_244), v_env_240));
    V t_0 = v_t_246;
    V t_1 = v_b_245;
    v_env_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_247 = heff_field(v_x2_241, 0);
    V v_as_248 = heff_field(v_x2_241, 1);
    V v_t_249 = (g_heff_2espec_2eclosedIn(heff_dup(v_env_240), v_f_247));
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
      HEFF_LAST return g_heff_2espec_2eallS(v_t_2410, v_as_248);
    }
    case TAG_False: {
      heff_drop(v_env_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  case TAG_ELet: {
    V v_x_2411 = heff_field(v_x2_241, 0);
    V v_a_2412 = heff_field(v_x2_241, 1);
    V v_b_2413 = heff_field(v_x2_241, 2);
    V v_t_2414 = (g_heff_2espec_2eclosedIn(heff_dup(v_env_240), v_a_2412));
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      V t_0 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_2411), v_env_240});
      V t_1 = v_b_2413;
      v_env_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_env_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2414);
    }
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x2_241, 0);
    V v_t_2416 = heff_tr(heff_apply(((V)&g_heff_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    V v_t_2417 = (g_prelude_2emap_24s513(heff_dup(v_fs_2415)));
    return ({ V a_0 = v_t_2416; V a_1 = v_t_2417; V r_ = (g_heff_2espec_2eallS(a_0, a_1)); heff_drop(v_t_2417); r_; });
  }
  case TAG_EProj: {
    V v_e_2418 = heff_field(v_x2_241, 0);
    V t_0 = v_env_240;
    V t_1 = v_e_2418;
    v_env_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2421 = heff_field(v_x2_241, 1);
    V v_t_2422 = heff_tr(heff_apply(((V)&g_heff_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2espec_2eallS(v_t_2422, v_as_2421);
  }
  case TAG_EMatch: {
    V v_s_2423 = heff_field(v_x2_241, 0);
    V v_arms_2424 = heff_field(v_x2_241, 1);
    V v_t_2425 = (g_heff_2espec_2eclosedIn(heff_dup(v_env_240), v_s_2423));
    switch (heff_tag_of(v_t_2425)) {
    case TAG_True: {
      HEFF_LAST return g_heff_2espec_2eallS(heff_clo(g_heff_2espec_2eclosedIn_lam0, 1, 1, (V[]){v_env_240}), v_arms_2424);
    }
    case TAG_False: {
      heff_drop(v_env_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_as_2433 = heff_field(v_x2_241, 1);
    V v_t_2434 = heff_tr(heff_apply(((V)&g_heff_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2espec_2eallS(v_t_2434, v_as_2433);
  }
  case TAG_ECall: {
    V v_as_2436 = heff_field(v_x2_241, 1);
    V v_t_2437 = heff_tr(heff_apply(((V)&g_heff_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2espec_2eallS(v_t_2437, v_as_2436);
  }
  case TAG_EInt: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFix: {
    heff_drop(v_env_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2eclosedIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2eclosedIn(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2espec_2eclosedIn_lam0(V self, V *args) {
  V v_x3_2426 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2426)) {
  case TAG_MkArm: {
    V v_vs_2428 = heff_field(v_x3_2426, 1);
    V v_b_2429 = heff_field(v_x3_2426, 2);
    heff_take_n(v_x3_2426, 6ULL, 3);
    V v_t_2430 = (g_heff_2espec_2eappendS(v_vs_2428, v_env_240));
    return ({ V a_0 = v_t_2430; V a_1 = v_b_2429; V r_ = (g_heff_2espec_2eclosedIn(a_0, a_1)); heff_drop(v_b_2429); r_; });
  }
  default: return heff_nomatch(v_x3_2426);
  }
}
Clo g_heff_2espec_2eposGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eposGo_entry, 3, 0};

V g_heff_2espec_2eposGo(V v_x_240, V v_x2_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    heff_drop(v_i_242);
    return MK_INT(-1LL);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_ys_244 = heff_field(v_x2_241, 1);
    V v_t_245 = heff_strEq(heff_dup(v_x_240), heff_dup(v_y_243));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_x_240);
      return v_i_242;
    }
    case TAG_False: {
      V t_0 = v_x_240;
      V t_1 = v_ys_244;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2eposGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2eposGo(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2espec_2ekeyGo_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {65, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2espec_2ekeyGo_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {84, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2espec_2ekeyGo_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {82, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2espec_2ekeyGo_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {80, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str20 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {67}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {124}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str26 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2espec_2ekeyGo_str27 = {{0x80000000u, K_STR, 0}, 2, 2, {77, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str31 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {81}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str35 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {75}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str41 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str42 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str43 = {{0x80000000u, K_STR, 0}, 1, 1, {88}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str44 = {{0x80000000u, K_STR, 0}, 1, 1, {70}};
V g_heff_2espec_2ekeyGo_lam0(V self, V *args);
V g_heff_2espec_2ekeyGo_lam1(V self, V *args);
Clo g_heff_2espec_2ekeyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2ekeyGo_entry, 2, 0};

V g_heff_2espec_2ekeyGo(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_t_243 = ({ V a_0 = heff_dup(v_x_242); V a_1 = v_env_240; V a_2 = MK_INT(0LL); V r_ = (g_heff_2espec_2eposGo(a_0, a_1, a_2)); heff_drop(v_env_240); r_; });
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str0), heff_intShow(v_t_243));
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str1), heff_strAppend(heff_dup(v_g_244), ((V)&g_heff_2espec_2ekeyGo_str2)));
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_241, 0);
    V v_b_246 = heff_field(v_x2_241, 1);
    V v_t_247 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_245));
    V v_t_248 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_xs_245)));
    V v_t_249 = (g_heff_2espec_2eappendS(v_t_248, v_env_240));
    V v_t_2410 = (g_heff_2espec_2ekeyGo(v_t_249, v_b_246));
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str3), heff_strAppend(heff_intShow(v_t_247), heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str4), heff_strAppend(v_t_2410, ((V)&g_heff_2espec_2ekeyGo_str5)))));
  }
  case TAG_EApp: {
    V v_f_2411 = heff_field(v_x2_241, 0);
    V v_as_2412 = heff_field(v_x2_241, 1);
    V v_t_2413 = (g_heff_2espec_2ekeyGo(heff_dup(v_env_240), v_f_2411));
    V v_go_2414 = heff_tr(heff_apply(((V)&g_heff_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2415 = (g_prelude_2emap(v_go_2414, heff_dup(v_as_2412)));
    V v_t_2418;
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nil: {
      v_t_2418 = ((V)&g_heff_2espec_2ekeyGo_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_xs_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      v_t_2418 = ({ V a_0 = v_x_2416; V a_1 = v_xs_2417; V r_ = (g_prelude_2efoldl_24s514(a_0, a_1)); heff_drop(v_xs_2417); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2415);
    }
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str7), heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str8), heff_strAppend(v_t_2418, ((V)&g_heff_2espec_2ekeyGo_str9)))));
  }
  case TAG_ELet: {
    V v_x_2419 = heff_field(v_x2_241, 0);
    V v_a_2420 = heff_field(v_x2_241, 1);
    V v_b_2421 = heff_field(v_x2_241, 2);
    V v_t_2422 = (g_heff_2espec_2ekeyGo(heff_dup(v_env_240), v_a_2420));
    V v_t_2423 = (g_heff_2espec_2ekeyGo(heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_2419), v_env_240}), v_b_2421));
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str10), heff_strAppend(v_t_2422, heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str11), heff_strAppend(v_t_2423, ((V)&g_heff_2espec_2ekeyGo_str12)))));
  }
  case TAG_ERecord: {
    V v_fs_2424 = heff_field(v_x2_241, 0);
    V v_go_2425 = heff_tr(heff_apply(((V)&g_heff_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2430 = (g_prelude_2emap(heff_clo(g_heff_2espec_2ekeyGo_lam0, 1, 1, (V[]){v_go_2425}), heff_dup(v_fs_2424)));
    V v_t_2433;
    switch (heff_tag_of(v_x2_2430)) {
    case TAG_Nil: {
      v_t_2433 = ((V)&g_heff_2espec_2ekeyGo_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2431 = heff_field(v_x2_2430, 0);
      V v_xs_2432 = heff_field(v_x2_2430, 1);
      heff_take_n(v_x2_2430, 3ULL, 2);
      v_t_2433 = ({ V a_0 = v_x_2431; V a_1 = v_xs_2432; V r_ = (g_prelude_2efoldl_24s514(a_0, a_1)); heff_drop(v_xs_2432); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2430);
    }
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str15), heff_strAppend(v_t_2433, ((V)&g_heff_2espec_2ekeyGo_str16)));
  }
  case TAG_EProj: {
    V v_e_2434 = heff_field(v_x2_241, 0);
    V v_l_2435 = heff_field(v_x2_241, 1);
    V v_t_2436 = (g_heff_2espec_2ekeyGo(v_env_240, v_e_2434));
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str17), heff_strAppend(v_t_2436, heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str18), heff_strAppend(heff_dup(v_l_2435), ((V)&g_heff_2espec_2ekeyGo_str19)))));
  }
  case TAG_ETag: {
    V v_t_2437 = heff_field(v_x2_241, 0);
    V v_as_2438 = heff_field(v_x2_241, 1);
    V v_go_2439 = heff_tr(heff_apply(((V)&g_heff_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2440 = (g_prelude_2emap(v_go_2439, heff_dup(v_as_2438)));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2espec_2ekeyGo_str20);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = v_x_2441; V a_1 = v_xs_2442; V r_ = (g_prelude_2efoldl_24s514(a_0, a_1)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str21), heff_strAppend(heff_dup(v_t_2437), heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str22), heff_strAppend(v_t_2443, ((V)&g_heff_2espec_2ekeyGo_str23)))));
  }
  case TAG_EMatch: {
    V v_s_2444 = heff_field(v_x2_241, 0);
    V v_arms_2445 = heff_field(v_x2_241, 1);
    V v_t_2446 = (g_heff_2espec_2ekeyGo(heff_dup(v_env_240), v_s_2444));
    V v_x2_2454 = (g_prelude_2emap(heff_clo(g_heff_2espec_2ekeyGo_lam1, 1, 1, (V[]){v_env_240}), heff_dup(v_arms_2445)));
    V v_t_2457;
    switch (heff_tag_of(v_x2_2454)) {
    case TAG_Nil: {
      v_t_2457 = ((V)&g_heff_2espec_2ekeyGo_str26);
      break;
    }
    case TAG_Cons: {
      V v_x_2455 = heff_field(v_x2_2454, 0);
      V v_xs_2456 = heff_field(v_x2_2454, 1);
      heff_take_n(v_x2_2454, 3ULL, 2);
      v_t_2457 = ({ V a_0 = v_x_2455; V a_1 = v_xs_2456; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2456); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2454);
    }
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str27), heff_strAppend(v_t_2446, heff_strAppend(v_t_2457, ((V)&g_heff_2espec_2ekeyGo_str28))));
  }
  case TAG_EPrim: {
    V v_p_2458 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str29), heff_strAppend(heff_dup(v_p_2458), ((V)&g_heff_2espec_2ekeyGo_str30)));
  }
  case TAG_EPrimCall: {
    V v_p_2459 = heff_field(v_x2_241, 0);
    V v_as_2460 = heff_field(v_x2_241, 1);
    V v_go_2461 = heff_tr(heff_apply(((V)&g_heff_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2462 = (g_prelude_2emap(v_go_2461, heff_dup(v_as_2460)));
    V v_t_2465;
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_Nil: {
      v_t_2465 = ((V)&g_heff_2espec_2ekeyGo_str31);
      break;
    }
    case TAG_Cons: {
      V v_x_2463 = heff_field(v_x2_2462, 0);
      V v_xs_2464 = heff_field(v_x2_2462, 1);
      heff_take_n(v_x2_2462, 3ULL, 2);
      v_t_2465 = ({ V a_0 = v_x_2463; V a_1 = v_xs_2464; V r_ = (g_prelude_2efoldl_24s514(a_0, a_1)); heff_drop(v_xs_2464); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2462);
    }
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str32), heff_strAppend(heff_dup(v_p_2459), heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str33), heff_strAppend(v_t_2465, ((V)&g_heff_2espec_2ekeyGo_str34)))));
  }
  case TAG_ECall: {
    V v_g_2466 = heff_field(v_x2_241, 0);
    V v_as_2467 = heff_field(v_x2_241, 1);
    V v_go_2468 = heff_tr(heff_apply(((V)&g_heff_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2469 = (g_prelude_2emap(v_go_2468, heff_dup(v_as_2467)));
    V v_t_2472;
    switch (heff_tag_of(v_x2_2469)) {
    case TAG_Nil: {
      v_t_2472 = ((V)&g_heff_2espec_2ekeyGo_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2470 = heff_field(v_x2_2469, 0);
      V v_xs_2471 = heff_field(v_x2_2469, 1);
      heff_take_n(v_x2_2469, 3ULL, 2);
      v_t_2472 = ({ V a_0 = v_x_2470; V a_1 = v_xs_2471; V r_ = (g_prelude_2efoldl_24s514(a_0, a_1)); heff_drop(v_xs_2471); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2469);
    }
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str36), heff_strAppend(heff_dup(v_g_2466), heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str37), heff_strAppend(v_t_2472, ((V)&g_heff_2espec_2ekeyGo_str38)))));
  }
  case TAG_EInt: {
    V v_i_2473 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str39), heff_intShow(heff_dup(v_i_2473)));
  }
  case TAG_EFloat: {
    V v_x_2474 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str40), heff_floatShow(heff_dup(v_x_2474)));
  }
  case TAG_EStr: {
    V v_s_2475 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    V v_t_2476 = heff_intShow(heff_strLength(heff_dup(v_s_2475)));
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str41), heff_strAppend(v_t_2476, heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str42), heff_dup(v_s_2475))));
  }
  case TAG_EAbandon: {
    heff_drop(v_env_240);
    return ((V)&g_heff_2espec_2ekeyGo_str43);
  }
  case TAG_EFix: {
    heff_drop(v_env_240);
    return ((V)&g_heff_2espec_2ekeyGo_str44);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2ekeyGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2ekeyGo(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2espec_2ekeyGo_lam0(V self, V *args) {
  V v_x2_2426 = args[0];
  V v_go_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_MkPair: {
    V v_l_2427 = heff_field(v_x2_2426, 0);
    V v_v_2428 = heff_field(v_x2_2426, 1);
    heff_take_n(v_x2_2426, 3ULL, 2);
    V v_t_2429 = heff_tr(heff_apply(v_go_2425, 1, (V[]){v_v_2428}));
    return heff_strAppend(v_l_2427, heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str13), v_t_2429));
  }
  default: return heff_nomatch(v_x2_2426);
  }
}
V g_heff_2espec_2ekeyGo_lam1(V self, V *args) {
  V v_x3_2447 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2447)) {
  case TAG_MkArm: {
    V v_t_2448 = heff_field(v_x3_2447, 0);
    V v_vs_2449 = heff_field(v_x3_2447, 1);
    V v_b_2450 = heff_field(v_x3_2447, 2);
    heff_take_n(v_x3_2447, 7ULL, 3);
    V v_t_2451 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_vs_2449));
    V v_t_2452 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_vs_2449));
    V v_t_2453 = (g_heff_2espec_2eappendS(v_t_2452, v_env_240));
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str24), heff_strAppend(v_t_2448, heff_strAppend(heff_intShow(v_t_2451), heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str25), ({ V a_0 = v_t_2453; V a_1 = v_b_2450; V r_ = (g_heff_2espec_2ekeyGo(a_0, a_1)); heff_drop(v_b_2450); r_; })))));
  }
  default: return heff_nomatch(v_x3_2447);
  }
}
Clo g_heff_2espec_2eheadUses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eheadUses_entry, 2, 0};

V g_heff_2espec_2eheadUses(V v_go_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_f_241)) {
  case TAG_EVar: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EGlobal: {
    heff_take_n(v_f_241, 0ULL, 1);
    heff_drop(v_go_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EApp: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ELet: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ERecord: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EProj: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ETag: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EMatch: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EPrim: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EPrimCall: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ECall: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EInt: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFloat: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EStr: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EAbandon: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFix: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  default: return heff_nomatch(v_f_241);
  }
}
V g_heff_2espec_2eheadUses_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2eheadUses(a[0], a[1]);
}
V g_heff_2espec_2eusesOf_lam0(V self, V *args);
V g_heff_2espec_2eusesOf_lam1(V self, V *args);
V g_heff_2espec_2eusesOf_lam2(V self, V *args);
V g_heff_2espec_2eusesOf_lam3(V self, V *args);
V g_heff_2espec_2eusesOf_lam4(V self, V *args);
V g_heff_2espec_2eusesOf_lam5(V self, V *args);
Clo g_heff_2espec_2eusesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eusesOf_entry, 2, 0};

V g_heff_2espec_2eusesOf(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    V v_h_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_244 = heff_strEq(v_h_243, v_g_240);
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag(TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    }
    case TAG_False: {
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_ELam: {
    V v_b_246 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_g_240;
    V t_1 = v_b_246;
    v_g_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_247 = heff_field(v_x2_241, 0);
    V v_as_248 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2436;
    switch (heff_tag_of(v_f_247)) {
    case TAG_EVar: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EGlobal: {
      V v_h_2410 = heff_dup(heff_field(v_f_247, 0));
      V v_t_2411 = heff_strEq(v_h_2410, heff_dup(v_g_240));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        v_t_2436 = heff_tag_at(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){heff_tag(TAG_Just, 1, (V[]){heff_dup(v_as_248)}), NTAG(TAG_Nil)});
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x2_241_24EApp, 2);
        v_t_2436 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      break;
    }
    case TAG_ELam: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EApp: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ELet: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ERecord: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EProj: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ETag: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EMatch: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrim: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrimCall: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ECall: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EInt: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EStr: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFix: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2436 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_f_247);
    }
    V v_t_2437 = heff_tr(heff_apply(((V)&g_heff_2espec_2eusesOf_clo), 1, (V[]){heff_dup(v_g_240)}));
    V v_t_2438 = heff_tr(g_heff_2espec_2eheadUses(v_t_2437, v_f_247));
    V v_f_2439 = heff_tr(heff_apply(((V)&g_heff_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2440 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_as_248));
    V v_t_2444 = ({ V a_0 = heff_clo(g_heff_2espec_2eusesOf_lam0, 2, 1, (V[]){v_f_2439}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2440; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2440); r_; });
    V v_t_2445 = (g_heff_2espec_2eappendS(v_t_2438, v_t_2444));
    HEFF_LAST return g_heff_2espec_2eappendS(v_t_2436, v_t_2445);
  }
  case TAG_ELet: {
    V v_a_2447 = heff_field(v_x2_241, 1);
    V v_b_2448 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2449 = (g_heff_2espec_2eusesOf(heff_dup(v_g_240), v_a_2447));
    V v_t_2450 = (g_heff_2espec_2eusesOf(v_g_240, v_b_2448));
    HEFF_LAST return g_heff_2espec_2eappendS(v_t_2449, v_t_2450);
  }
  case TAG_ERecord: {
    V v_fs_2451 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_f_2452 = heff_tr(heff_apply(((V)&g_heff_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_xs_2453 = (g_prelude_2emap_24s513(v_fs_2451));
    V v_t_2454 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2453));
    return ({ V a_0 = heff_clo(g_heff_2espec_2eusesOf_lam1, 2, 1, (V[]){v_f_2452}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2454; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2454); r_; });
  }
  case TAG_EProj: {
    V v_e_2458 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    V t_0 = v_g_240;
    V t_1 = v_e_2458;
    v_g_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2461 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_f_2462 = heff_tr(heff_apply(((V)&g_heff_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2463 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_as_2461));
    return ({ V a_0 = heff_clo(g_heff_2espec_2eusesOf_lam2, 2, 1, (V[]){v_f_2462}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2463; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2463); r_; });
  }
  case TAG_EMatch: {
    V v_s_2467 = heff_field(v_x2_241, 0);
    V v_arms_2468 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2469 = (g_heff_2espec_2eusesOf(heff_dup(v_g_240), v_s_2467));
    V v_f_2470 = heff_tr(heff_apply(((V)&g_heff_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_xs_2471 = (g_prelude_2emap_24s515(v_arms_2468));
    V v_t_2472 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2471));
    V v_t_2476 = ({ V a_0 = heff_clo(g_heff_2espec_2eusesOf_lam3, 2, 1, (V[]){v_f_2470}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2472; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2472); r_; });
    HEFF_LAST return g_heff_2espec_2eappendS(v_t_2469, v_t_2476);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_as_2479 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_f_2480 = heff_tr(heff_apply(((V)&g_heff_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2481 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_as_2479));
    return ({ V a_0 = heff_clo(g_heff_2espec_2eusesOf_lam4, 2, 1, (V[]){v_f_2480}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2481; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2481); r_; });
  }
  case TAG_ECall: {
    V v_h_2485 = heff_field(v_x2_241, 0);
    V v_as_2486 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2487 = heff_strEq(v_h_2485, heff_dup(v_g_240));
    V v_t_2488;
    switch (heff_tag_of(v_t_2487)) {
    case TAG_True: {
      v_t_2488 = heff_tag_at(v_ru_24x2_241_24ECall, TAG_Cons, 2, (V[]){heff_tag(TAG_Just, 1, (V[]){heff_dup(v_as_2486)}), NTAG(TAG_Nil)});
      break;
    }
    case TAG_False: {
      heff_drop_cell(v_ru_24x2_241_24ECall, 2);
      v_t_2488 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_2487);
    }
    V v_f_2489 = heff_tr(heff_apply(((V)&g_heff_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2490 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_as_2486));
    V v_t_2494 = ({ V a_0 = heff_clo(g_heff_2espec_2eusesOf_lam5, 2, 1, (V[]){v_f_2489}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2490; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2490); r_; });
    HEFF_LAST return g_heff_2espec_2eappendS(v_t_2488, v_t_2494);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2eusesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2eusesOf(a[0], a[1]);
}
V g_heff_2espec_2eusesOf_lam0(V self, V *args) {
  V v_acc_2441 = args[0];
  V v_x_2442 = args[1];
  V v_f_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2443 = heff_tr(heff_apply(v_f_2439, 1, (V[]){v_x_2442}));
  return (g_prelude_2econcatList(v_t_2443, v_acc_2441));
}
V g_heff_2espec_2eusesOf_lam1(V self, V *args) {
  V v_acc_2455 = args[0];
  V v_x_2456 = args[1];
  V v_f_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2457 = heff_tr(heff_apply(v_f_2452, 1, (V[]){v_x_2456}));
  return (g_prelude_2econcatList(v_t_2457, v_acc_2455));
}
V g_heff_2espec_2eusesOf_lam2(V self, V *args) {
  V v_acc_2464 = args[0];
  V v_x_2465 = args[1];
  V v_f_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = heff_tr(heff_apply(v_f_2462, 1, (V[]){v_x_2465}));
  return (g_prelude_2econcatList(v_t_2466, v_acc_2464));
}
V g_heff_2espec_2eusesOf_lam3(V self, V *args) {
  V v_acc_2473 = args[0];
  V v_x_2474 = args[1];
  V v_f_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2475 = heff_tr(heff_apply(v_f_2470, 1, (V[]){v_x_2474}));
  return (g_prelude_2econcatList(v_t_2475, v_acc_2473));
}
V g_heff_2espec_2eusesOf_lam4(V self, V *args) {
  V v_acc_2482 = args[0];
  V v_x_2483 = args[1];
  V v_f_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2484 = heff_tr(heff_apply(v_f_2480, 1, (V[]){v_x_2483}));
  return (g_prelude_2econcatList(v_t_2484, v_acc_2482));
}
V g_heff_2espec_2eusesOf_lam5(V self, V *args) {
  V v_acc_2491 = args[0];
  V v_x_2492 = args[1];
  V v_f_2489 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2493 = heff_tr(heff_apply(v_f_2489, 1, (V[]){v_x_2492}));
  return (g_prelude_2econcatList(v_t_2493, v_acc_2491));
}
Clo g_heff_2espec_2enthS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2enthS_entry, 2, 0};

V g_heff_2espec_2enthS(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_240);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2enthS_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2enthS(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2espec_2ehandsOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2ehandsOn_entry, 3, 0};

V g_heff_2espec_2ehandsOn(V v_x_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_x_240);
    heff_drop(v_i_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_as_243 = heff_field(v_x3_242, 0);
    V v_x2_244 = (g_heff_2espec_2enthS(v_i_241, v_as_243));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nothing: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_x21_245 = heff_field(v_x2_244, 0);
      heff_take_n(v_x2_244, 1ULL, 1);
      switch (heff_tag_of(v_x21_245)) {
      case TAG_EVar: {
        V v_y_246 = heff_field(v_x21_245, 0);
        heff_take_n(v_x21_245, 1ULL, 1);
        return heff_strEq(v_x_240, v_y_246);
      }
      case TAG_EGlobal: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        heff_take_n(v_x21_245, 0ULL, 3);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_245);
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2espec_2ehandsOn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2ehandsOn(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2espec_2estaticGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2estaticGo_entry, 3, 0};

V g_heff_2espec_2estaticGo(V v_uses_240, V v_x2_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_apply(((V)&g_heff_2espec_2ehandsOn_clo), 2, (V[]){v_x_243, heff_dup(v_i_242)}));
    V v_t_246 = (g_heff_2espec_2eallS(v_t_245, v_uses_240));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_heff_2espec_2estaticGo(v_uses_240, v_xs_244, heff_intAdd(v_i_242, MK_INT(1LL))))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2estaticGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2estaticGo(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_heff_2espec_2edropAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2edropAt_entry, 2, 0};

V g_heff_2espec_2edropAt(V v_x1_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_as_241;
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x1_240, 0);
    V v_ds_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      heff_drop(v_d_242);
      heff_drop(v_ds_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_a_244 = heff_field(v_as_241, 0);
      V v_as2_245 = heff_field(v_as_241, 1);
      heff_take_n(v_as_241, 3ULL, 2);
      switch (heff_tag_of(v_d_242)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_244);
        V t_0 = v_ds_243;
        V t_1 = v_as2_245;
        v_x1_240 = t_0;
        v_as_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, (g_heff_2espec_2edropAt(v_ds_243, v_as2_245))});
      }
      default: return heff_nomatch(v_d_242);
      }
    }
    default: return heff_nomatch(v_as_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2espec_2edropAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2edropAt(a[0], a[1]);
}
Clo g_heff_2espec_2eselfHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eselfHead_entry, 4, 0};

V g_heff_2espec_2eselfHead(V v_go_240, V v_g_241, V v_h_242, V v_f_243) {
top: ;
  switch (heff_tag_of(v_f_243)) {
  case TAG_EVar: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EGlobal: {
    V v_k_245 = heff_field(v_f_243, 0);
    V v_ru_24f_243_24EGlobal = heff_take_reuse_n(v_f_243, 1ULL, 1);
    heff_drop(v_go_240);
    V v_t_246 = heff_strEq(heff_dup(v_k_245), v_g_241);
    V v_t_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_k_245);
      v_t_247 = v_h_242;
      break;
    }
    case TAG_False: {
      heff_drop(v_h_242);
      v_t_247 = v_k_245;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_at(v_ru_24f_243_24EGlobal, TAG_EGlobal, 1, (V[]){v_t_247});
  }
  case TAG_ELam: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EApp: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ELet: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ERecord: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EProj: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ETag: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EMatch: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EPrim: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ECall: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EInt: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFloat: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EStr: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EAbandon: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFix: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  default: return heff_nomatch(v_f_243);
  }
}
V g_heff_2espec_2eselfHead_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2eselfHead(a[0], a[1], a[2], a[3]);
}
V g_heff_2espec_2eselfTo_lam0(V self, V *args);
V g_heff_2espec_2eselfTo_lam1(V self, V *args);
Clo g_heff_2espec_2eselfTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eselfTo_entry, 4, 0};

V g_heff_2espec_2eselfTo(V v_g_240, V v_h_241, V v_ds_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_ds_242);
    return v_e_243;
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_ds_242);
    return v_e_243;
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_243, 0);
    V v_b_247 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ELam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    return heff_tag_at(v_ru_24e_243_24ELam, TAG_ELam, 2, (V[]){v_xs_246, (g_heff_2espec_2eselfTo(v_g_240, v_h_241, v_ds_242, v_b_247))});
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_e_243, 0);
    V v_as_249 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2espec_2eselfTo_clo), 3, (V[]){heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_ds_242)}));
    V v_t_2411 = heff_tr(g_heff_2espec_2eselfHead(v_t_2410, heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_f_248)));
    V v_t_2412 = heff_tr(heff_apply(((V)&g_heff_2espec_2eselfTo_clo), 3, (V[]){heff_dup(v_g_240), v_h_241, heff_dup(v_ds_242)}));
    V v_t_2440;
    switch (heff_tag_of(v_f_248)) {
    case TAG_EVar: {
      heff_take_n(v_f_248, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    case TAG_EGlobal: {
      V v_k_2414 = heff_field(v_f_248, 0);
      heff_take_n(v_f_248, 1ULL, 1);
      V v_t_2415 = heff_strEq(v_k_2414, v_g_240);
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        v_t_2440 = (g_heff_2espec_2edropAt(v_ds_242, v_as_249));
        break;
      }
      case TAG_False: {
        heff_drop(v_ds_242);
        v_t_2440 = v_as_249;
        break;
      }
      default: heff_nomatch(v_t_2415);
      }
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_f_248, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_f_248, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_f_248, 0ULL, 3);
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_f_248, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_f_248, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_f_248, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_f_248, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_f_248, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_f_248, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_f_248, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_f_248, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    case TAG_EFloat: {
      heff_take_n(v_f_248, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_f_248, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_f_248, 0ULL, 2);
      heff_drop(v_g_240);
      heff_drop(v_ds_242);
      v_t_2440 = v_as_249;
      break;
    }
    default: heff_nomatch(v_f_248);
    }
    return heff_tag_at(v_ru_24e_243_24EApp, TAG_EApp, 2, (V[]){v_t_2411, (g_prelude_2emap(v_t_2412, v_t_2440))});
  }
  case TAG_ELet: {
    V v_x_2441 = heff_field(v_e_243, 0);
    V v_a_2442 = heff_field(v_e_243, 1);
    V v_b_2443 = heff_field(v_e_243, 2);
    V v_ru_24e_243_24ELet = heff_take_reuse_n(v_e_243, 7ULL, 3);
    V v_t_2444 = (g_heff_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_ds_242), v_a_2442));
    return heff_tag_at(v_ru_24e_243_24ELet, TAG_ELet, 3, (V[]){v_x_2441, v_t_2444, (g_heff_2espec_2eselfTo(v_g_240, v_h_241, v_ds_242, v_b_2443))});
  }
  case TAG_ERecord: {
    V v_fs_2445 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24ERecord = heff_take_reuse_n(v_e_243, 1ULL, 1);
    V v_go_2446 = heff_tr(heff_apply(((V)&g_heff_2espec_2eselfTo_clo), 3, (V[]){v_g_240, v_h_241, v_ds_242}));
    return heff_tag_at(v_ru_24e_243_24ERecord, TAG_ERecord, 1, (V[]){(g_prelude_2emap(heff_clo(g_heff_2espec_2eselfTo_lam0, 1, 1, (V[]){v_go_2446}), v_fs_2445))});
  }
  case TAG_EProj: {
    V v_e1_2451 = heff_field(v_e_243, 0);
    V v_l_2452 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EProj = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2453 = (g_heff_2espec_2eselfTo(v_g_240, v_h_241, v_ds_242, v_e1_2451));
    return heff_tag_at(v_ru_24e_243_24EProj, TAG_EProj, 2, (V[]){v_t_2453, v_l_2452});
  }
  case TAG_ETag: {
    V v_t_2454 = heff_field(v_e_243, 0);
    V v_as_2455 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ETag = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2456 = heff_tr(heff_apply(((V)&g_heff_2espec_2eselfTo_clo), 3, (V[]){v_g_240, v_h_241, v_ds_242}));
    return heff_tag_at(v_ru_24e_243_24ETag, TAG_ETag, 2, (V[]){v_t_2454, (g_prelude_2emap(v_t_2456, v_as_2455))});
  }
  case TAG_EMatch: {
    V v_s_2457 = heff_field(v_e_243, 0);
    V v_arms_2458 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EMatch = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2459 = (g_heff_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_ds_242), v_s_2457));
    V v_go_2460 = heff_tr(heff_apply(((V)&g_heff_2espec_2eselfTo_clo), 3, (V[]){v_g_240, v_h_241, v_ds_242}));
    return heff_tag_at(v_ru_24e_243_24EMatch, TAG_EMatch, 2, (V[]){v_t_2459, (g_prelude_2emap(heff_clo(g_heff_2espec_2eselfTo_lam1, 1, 1, (V[]){v_go_2460}), v_arms_2458))});
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_ds_242);
    return v_e_243;
  }
  case TAG_EPrimCall: {
    V v_p_2467 = heff_field(v_e_243, 0);
    V v_as_2468 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EPrimCall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2469 = heff_tr(heff_apply(((V)&g_heff_2espec_2eselfTo_clo), 3, (V[]){v_g_240, v_h_241, v_ds_242}));
    return heff_tag_at(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2467, (g_prelude_2emap(v_t_2469, v_as_2468))});
  }
  case TAG_ECall: {
    V v_k_2470 = heff_field(v_e_243, 0);
    V v_as_2471 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ECall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2472 = heff_tr(heff_apply(((V)&g_heff_2espec_2eselfTo_clo), 3, (V[]){v_g_240, v_h_241, v_ds_242}));
    return heff_tag_at(v_ru_24e_243_24ECall, TAG_ECall, 2, (V[]){v_k_2470, (g_prelude_2emap(v_t_2472, v_as_2471))});
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_ds_242);
    return v_e_243;
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_ds_242);
    return v_e_243;
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_ds_242);
    return v_e_243;
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_ds_242);
    return v_e_243;
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_ds_242);
    return v_e_243;
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2espec_2eselfTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2eselfTo(a[0], a[1], a[2], a[3]);
}
V g_heff_2espec_2eselfTo_lam0(V self, V *args) {
  V v_x2_2447 = args[0];
  V v_go_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkPair: {
    V v_l_2448 = heff_field(v_x2_2447, 0);
    V v_v_2449 = heff_field(v_x2_2447, 1);
    V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
    V v_t_2450 = heff_tr(heff_apply(v_go_2446, 1, (V[]){v_v_2449}));
    return heff_tag_at(v_ru_24x2_2447_24MkPair, TAG_MkPair, 2, (V[]){v_l_2448, v_t_2450});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}
V g_heff_2espec_2eselfTo_lam1(V self, V *args) {
  V v_x2_2461 = args[0];
  V v_go_2460 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2461)) {
  case TAG_MkArm: {
    V v_t_2462 = heff_field(v_x2_2461, 0);
    V v_vs_2463 = heff_field(v_x2_2461, 1);
    V v_b_2464 = heff_field(v_x2_2461, 2);
    V v_ru_24x2_2461_24MkArm = heff_take_reuse_n(v_x2_2461, 7ULL, 3);
    V v_t_2465 = heff_tr(heff_apply(v_go_2460, 1, (V[]){v_b_2464}));
    return heff_tag_at(v_ru_24x2_2461_24MkArm, TAG_MkArm, 3, (V[]){v_t_2462, v_vs_2463, v_t_2465});
  }
  default: return heff_nomatch(v_x2_2461);
  }
}