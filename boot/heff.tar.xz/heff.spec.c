// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_holes 300818381
#define LBL_n 328
#define LBL_ren 322325
#define LBL_vars 10107635
static uint32_t shape_ren__vars__holes__n[] = {LBL_ren, LBL_vars, LBL_holes, LBL_n};
V g_heff_2espec_2eallS(V, V);
V g_heff_2espec_2eallS_entry(V self, V *a);
extern Clo g_heff_2espec_2eallS_clo;
V g_heff_2espec_2eappendS(V, V);
V g_heff_2espec_2eappendS_entry(V self, V *a);
extern Clo g_heff_2espec_2eappendS_clo;
V g_heff_2espec_2ebindOne(V, V);
V g_heff_2espec_2ebindOne_entry(V self, V *a);
extern Clo g_heff_2espec_2ebindOne_clo;
V g_heff_2espec_2eclosedIn(V, V);
V g_heff_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2espec_2eclosedIn_clo;
V g_heff_2espec_2edropAt(V, V);
V g_heff_2espec_2edropAt_entry(V self, V *a);
extern Clo g_heff_2espec_2edropAt_clo;
V g_heff_2espec_2eelemS(V, V);
V g_heff_2espec_2eelemS_entry(V self, V *a);
extern Clo g_heff_2espec_2eelemS_clo;
V g_heff_2espec_2ehandsOn(V, V, V);
V g_heff_2espec_2ehandsOn_entry(V self, V *a);
extern Clo g_heff_2espec_2ehandsOn_clo;
V g_heff_2espec_2ehashGo(V, V, V, V);
V g_heff_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2espec_2ehashGo_clo;
V g_heff_2espec_2eheadUses(V, V);
V g_heff_2espec_2eheadUses_entry(V self, V *a);
extern Clo g_heff_2espec_2eheadUses_clo;
V g_heff_2espec_2ekeyGo(V, V);
V g_heff_2espec_2ekeyGo_entry(V self, V *a);
extern Clo g_heff_2espec_2ekeyGo_clo;
V g_heff_2espec_2elabelsTo(V, V);
V g_heff_2espec_2elabelsTo_entry(V self, V *a);
extern Clo g_heff_2espec_2elabelsTo_clo;
V g_heff_2espec_2eletThen(V, V, V, V);
V g_heff_2espec_2eletThen_entry(V self, V *a);
extern Clo g_heff_2espec_2eletThen_clo;
V g_heff_2espec_2enthS(V, V);
V g_heff_2espec_2enthS_entry(V self, V *a);
extern Clo g_heff_2espec_2enthS_clo;
V g_heff_2espec_2eposGo(V, V, V);
V g_heff_2espec_2eposGo_entry(V self, V *a);
extern Clo g_heff_2espec_2eposGo_clo;
V g_heff_2espec_2eselfArgs(V, V, V, V, V);
V g_heff_2espec_2eselfArgs_entry(V self, V *a);
extern Clo g_heff_2espec_2eselfArgs_clo;
V g_heff_2espec_2eselfHead(V, V, V, V);
V g_heff_2espec_2eselfHead_entry(V self, V *a);
extern Clo g_heff_2espec_2eselfHead_clo;
V g_heff_2espec_2eselfTo(V, V, V, V, V);
V g_heff_2espec_2eselfTo_entry(V self, V *a);
extern Clo g_heff_2espec_2eselfTo_clo;
V g_heff_2espec_2eshapeArms(V, V, V);
V g_heff_2espec_2eshapeArms_entry(V self, V *a);
extern Clo g_heff_2espec_2eshapeArms_clo;
V g_heff_2espec_2eshapeGo(V, V);
V g_heff_2espec_2eshapeGo_entry(V self, V *a);
extern Clo g_heff_2espec_2eshapeGo_clo;
V g_heff_2espec_2eshapeMany(V, V, V);
V g_heff_2espec_2eshapeMany_entry(V self, V *a);
extern Clo g_heff_2espec_2eshapeMany_clo;
V g_heff_2espec_2estaticGo(V, V, V);
V g_heff_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2espec_2estaticGo_clo;
V g_heff_2espec_2eusesOf(V, V);
V g_heff_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2espec_2eusesOf_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2econcatList(V, V);
V g_prelude_2econcatList_entry(V self, V *a);
extern Clo g_prelude_2econcatList_clo;
V g_prelude_2efoldl(V, V, V);
V g_prelude_2efoldl_entry(V self, V *a);
extern Clo g_prelude_2efoldl_clo;
V g_prelude_2efoldl_24s1226147011x367015740(V, V, V);
V g_prelude_2efoldl_24s1226147011x367015740_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1226147011x367015740_clo;
V g_prelude_2efoldl_24s1546929672x1472202881(V, V);
V g_prelude_2efoldl_24s1546929672x1472202881_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1546929672x1472202881_clo;
V g_prelude_2efoldl_24s1939305664x1902528268(V, V, V);
V g_prelude_2efoldl_24s1939305664x1902528268_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1939305664x1902528268_clo;
V g_prelude_2efoldl_24s803210893x1036700122(V, V);
V g_prelude_2efoldl_24s803210893x1036700122_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s803210893x1036700122_clo;
V g_prelude_2emap(V, V);
V g_prelude_2emap_entry(V self, V *a);
extern Clo g_prelude_2emap_clo;
V g_prelude_2emap_24s1295898052x1915853031(V);
V g_prelude_2emap_24s1295898052x1915853031_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1295898052x1915853031_clo;
V g_prelude_2emap_24s1448703749x94773476(V);
V g_prelude_2emap_24s1448703749x94773476_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1448703749x94773476_clo;
Clo g_heff_2espec_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eelemS_entry, 2, 0};

V g_heff_2espec_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_strEq(heff_dup(v_x_240), heff_dup(v_y_242));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2eelemS_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2eelemS(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2espec_2eappendS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eappendS_entry, 2, 0};

V g_heff_2espec_2eappendS(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2espec_2eappendS(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2espec_2eappendS_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2eappendS(a[0], a[1]);
}
Clo g_heff_2espec_2eallS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eallS_entry, 2, 0};

V g_heff_2espec_2eallS(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_p_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2eallS_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2eallS(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2espec_2eclosedIn_lam0(V self, V *args);
Clo g_heff_2espec_2eclosedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eclosedIn_entry, 2, 0};

V g_heff_2espec_2eclosedIn(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    return ({ V a_0 = heff_dup(v_x_242); V a_1 = v_env_240; V r_ = (g_heff_2espec_2eelemS(a_0, a_1)); heff_drop(v_env_240); r_; });
  }
  case TAG_EGlobal: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_x2_241, 0);
    V v_b_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2espec_2eappendS(heff_dup(v_xs_244), v_env_240));
    V t_0 = v_t_246;
    V t_1 = v_b_245;
    v_env_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_247 = heff_field(v_x2_241, 0);
    V v_as_248 = heff_field(v_x2_241, 1);
    V v_t_249 = (g_heff_2espec_2eclosedIn(heff_dup(v_env_240), v_f_247));
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
      HEFF_LAST return g_heff_2espec_2eallS(v_t_2410, v_as_248);
    }
    case TAG_False: {
      heff_drop(v_env_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  case TAG_ELet: {
    V v_x_2411 = heff_field(v_x2_241, 0);
    V v_a_2412 = heff_field(v_x2_241, 1);
    V v_b_2413 = heff_field(v_x2_241, 2);
    V v_t_2414 = (g_heff_2espec_2eclosedIn(heff_dup(v_env_240), v_a_2412));
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      V t_0 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_2411), v_env_240});
      V t_1 = v_b_2413;
      v_env_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_env_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2414);
    }
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x2_241, 0);
    V v_t_2416 = heff_tr(heff_apply(((V)&g_heff_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    V v_t_2417 = (g_prelude_2emap_24s1448703749x94773476(heff_dup(v_fs_2415)));
    return ({ V a_0 = v_t_2416; V a_1 = v_t_2417; V r_ = (g_heff_2espec_2eallS(a_0, a_1)); heff_drop(v_t_2417); r_; });
  }
  case TAG_EProj: {
    V v_e_2418 = heff_field(v_x2_241, 0);
    V t_0 = v_env_240;
    V t_1 = v_e_2418;
    v_env_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2421 = heff_field(v_x2_241, 1);
    V v_t_2422 = heff_tr(heff_apply(((V)&g_heff_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2espec_2eallS(v_t_2422, v_as_2421);
  }
  case TAG_EMatch: {
    V v_s_2423 = heff_field(v_x2_241, 0);
    V v_arms_2424 = heff_field(v_x2_241, 1);
    V v_t_2425 = (g_heff_2espec_2eclosedIn(heff_dup(v_env_240), v_s_2423));
    switch (heff_tag_of(v_t_2425)) {
    case TAG_True: {
      HEFF_LAST return g_heff_2espec_2eallS(heff_clo(g_heff_2espec_2eclosedIn_lam0, 1, 1, (V[]){v_env_240}), v_arms_2424);
    }
    case TAG_False: {
      heff_drop(v_env_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_as_2433 = heff_field(v_x2_241, 1);
    V v_t_2434 = heff_tr(heff_apply(((V)&g_heff_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2espec_2eallS(v_t_2434, v_as_2433);
  }
  case TAG_ECall: {
    V v_as_2436 = heff_field(v_x2_241, 1);
    V v_t_2437 = heff_tr(heff_apply(((V)&g_heff_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2espec_2eallS(v_t_2437, v_as_2436);
  }
  case TAG_EInt: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFix: {
    heff_drop(v_env_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2eclosedIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2eclosedIn(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2espec_2eclosedIn_lam0(V self, V *args) {
  V v_x3_2426 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2426)) {
  case TAG_MkArm: {
    V v_vs_2428 = heff_field(v_x3_2426, 1);
    V v_b_2429 = heff_field(v_x3_2426, 2);
    heff_take_n(v_x3_2426, 6ULL, 3);
    V v_t_2430 = (g_heff_2espec_2eappendS(v_vs_2428, v_env_240));
    return ({ V a_0 = v_t_2430; V a_1 = v_b_2429; V r_ = (g_heff_2espec_2eclosedIn(a_0, a_1)); heff_drop(v_b_2429); r_; });
  }
  default: return heff_nomatch(v_x3_2426);
  }
}
Clo g_heff_2espec_2eposGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eposGo_entry, 3, 0};

V g_heff_2espec_2eposGo(V v_x_240, V v_x2_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    heff_drop(v_i_242);
    return MK_INT(-1LL);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_ys_244 = heff_field(v_x2_241, 1);
    V v_t_245 = heff_strEq(heff_dup(v_x_240), heff_dup(v_y_243));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_x_240);
      return v_i_242;
    }
    case TAG_False: {
      V t_0 = v_x_240;
      V t_1 = v_ys_244;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2eposGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2eposGo(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2espec_2ekeyGo_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {65, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2espec_2ekeyGo_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {84, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str15 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2espec_2ekeyGo_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {82, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2espec_2ekeyGo_str19 = {{0x80000000u, K_STR, 0}, 2, 2, {80, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str22 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {67}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {124}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str29 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str30 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2espec_2ekeyGo_str31 = {{0x80000000u, K_STR, 0}, 2, 2, {77, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str35 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {81}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str40 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str41 = {{0x80000000u, K_STR, 0}, 1, 1, {44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str42 = {{0x80000000u, K_STR, 0}, 1, 1, {75}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str43 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str44 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str45 = {{0x80000000u, K_STR, 0}, 1, 1, {105}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str47 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str48 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2espec_2ekeyGo_str49 = {{0x80000000u, K_STR, 0}, 2, 2, {73, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2espec_2ekeyGo_str50 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2espec_2ekeyGo_str51 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2espec_2ekeyGo_str52 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2espec_2ekeyGo_str53 = {{0x80000000u, K_STR, 0}, 2, 2, {85, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2espec_2ekeyGo_str54 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2espec_2ekeyGo_str55 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2espec_2ekeyGo_str56 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2espec_2ekeyGo_str57 = {{0x80000000u, K_STR, 0}, 3, 3, {70, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str58 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str59 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str60 = {{0x80000000u, K_STR, 0}, 1, 1, {121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str61 = {{0x80000000u, K_STR, 0}, 1, 1, {88}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ekeyGo_str62 = {{0x80000000u, K_STR, 0}, 1, 1, {70}};
V g_heff_2espec_2ekeyGo_lam0(V self, V *args);
V g_heff_2espec_2ekeyGo_lam1(V self, V *args);
Clo g_heff_2espec_2ekeyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2ekeyGo_entry, 2, 0};

V g_heff_2espec_2ekeyGo(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_t_243 = ({ V a_0 = heff_dup(v_x_242); V a_1 = v_env_240; V a_2 = MK_INT(0LL); V r_ = (g_heff_2espec_2eposGo(a_0, a_1, a_2)); heff_drop(v_env_240); r_; });
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str0), heff_intShow(v_t_243));
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str1), heff_strAppend(heff_dup(v_g_244), ((V)&g_heff_2espec_2ekeyGo_str2)));
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_241, 0);
    V v_b_246 = heff_field(v_x2_241, 1);
    V v_t_247 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_xs_245));
    V v_t_248 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), heff_dup(v_xs_245)));
    V v_t_249 = (g_heff_2espec_2eappendS(v_t_248, v_env_240));
    V v_t_2410 = (g_heff_2espec_2ekeyGo(v_t_249, v_b_246));
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str3), heff_strAppend(heff_intShow(v_t_247), heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str4), heff_strAppend(v_t_2410, ((V)&g_heff_2espec_2ekeyGo_str5)))));
  }
  case TAG_EApp: {
    V v_f_2411 = heff_field(v_x2_241, 0);
    V v_as_2412 = heff_field(v_x2_241, 1);
    V v_t_2413 = (g_heff_2espec_2ekeyGo(heff_dup(v_env_240), v_f_2411));
    V v_go_2414 = heff_tr(heff_apply(((V)&g_heff_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2415 = (g_prelude_2emap(v_go_2414, heff_dup(v_as_2412)));
    V v_t_2418;
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nil: {
      v_t_2418 = ((V)&g_heff_2espec_2ekeyGo_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_xs_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      v_t_2418 = ({ V a_0 = ((V)&g_heff_2espec_2ekeyGo_str7); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2415);
    }
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str8), heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str9), heff_strAppend(v_t_2418, ((V)&g_heff_2espec_2ekeyGo_str10)))));
  }
  case TAG_ELet: {
    V v_x_2419 = heff_field(v_x2_241, 0);
    V v_a_2420 = heff_field(v_x2_241, 1);
    V v_b_2421 = heff_field(v_x2_241, 2);
    V v_t_2422 = (g_heff_2espec_2ekeyGo(heff_dup(v_env_240), v_a_2420));
    V v_t_2423 = (g_heff_2espec_2ekeyGo(heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_2419), v_env_240}), v_b_2421));
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str11), heff_strAppend(v_t_2422, heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str12), heff_strAppend(v_t_2423, ((V)&g_heff_2espec_2ekeyGo_str13)))));
  }
  case TAG_ERecord: {
    V v_fs_2424 = heff_field(v_x2_241, 0);
    V v_go_2425 = heff_tr(heff_apply(((V)&g_heff_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2430 = (g_prelude_2emap(heff_clo(g_heff_2espec_2ekeyGo_lam0, 1, 1, (V[]){v_go_2425}), heff_dup(v_fs_2424)));
    V v_t_2433;
    switch (heff_tag_of(v_x2_2430)) {
    case TAG_Nil: {
      v_t_2433 = ((V)&g_heff_2espec_2ekeyGo_str15);
      break;
    }
    case TAG_Cons: {
      V v_x_2431 = heff_field(v_x2_2430, 0);
      V v_xs_2432 = heff_field(v_x2_2430, 1);
      heff_take_n(v_x2_2430, 3ULL, 2);
      v_t_2433 = ({ V a_0 = ((V)&g_heff_2espec_2ekeyGo_str16); V a_1 = v_x_2431; V a_2 = v_xs_2432; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2432); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2430);
    }
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str17), heff_strAppend(v_t_2433, ((V)&g_heff_2espec_2ekeyGo_str18)));
  }
  case TAG_EProj: {
    V v_e_2434 = heff_field(v_x2_241, 0);
    V v_l_2435 = heff_field(v_x2_241, 1);
    V v_t_2436 = (g_heff_2espec_2ekeyGo(v_env_240, v_e_2434));
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str19), heff_strAppend(v_t_2436, heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str20), heff_strAppend(heff_dup(v_l_2435), ((V)&g_heff_2espec_2ekeyGo_str21)))));
  }
  case TAG_ETag: {
    V v_t_2437 = heff_field(v_x2_241, 0);
    V v_as_2438 = heff_field(v_x2_241, 1);
    V v_go_2439 = heff_tr(heff_apply(((V)&g_heff_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2440 = (g_prelude_2emap(v_go_2439, heff_dup(v_as_2438)));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2espec_2ekeyGo_str22);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2espec_2ekeyGo_str23); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str24), heff_strAppend(heff_dup(v_t_2437), heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str25), heff_strAppend(v_t_2443, ((V)&g_heff_2espec_2ekeyGo_str26)))));
  }
  case TAG_EMatch: {
    V v_s_2444 = heff_field(v_x2_241, 0);
    V v_arms_2445 = heff_field(v_x2_241, 1);
    V v_t_2446 = (g_heff_2espec_2ekeyGo(heff_dup(v_env_240), v_s_2444));
    V v_x2_2454 = (g_prelude_2emap(heff_clo(g_heff_2espec_2ekeyGo_lam1, 1, 1, (V[]){v_env_240}), heff_dup(v_arms_2445)));
    V v_t_2457;
    switch (heff_tag_of(v_x2_2454)) {
    case TAG_Nil: {
      v_t_2457 = ((V)&g_heff_2espec_2ekeyGo_str29);
      break;
    }
    case TAG_Cons: {
      V v_x_2455 = heff_field(v_x2_2454, 0);
      V v_xs_2456 = heff_field(v_x2_2454, 1);
      heff_take_n(v_x2_2454, 3ULL, 2);
      v_t_2457 = ({ V a_0 = ((V)&g_heff_2espec_2ekeyGo_str30); V a_1 = v_x_2455; V a_2 = v_xs_2456; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2456); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2454);
    }
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str31), heff_strAppend(v_t_2446, heff_strAppend(v_t_2457, ((V)&g_heff_2espec_2ekeyGo_str32))));
  }
  case TAG_EPrim: {
    V v_p_2458 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str33), heff_strAppend(heff_dup(v_p_2458), ((V)&g_heff_2espec_2ekeyGo_str34)));
  }
  case TAG_EPrimCall: {
    V v_p_2459 = heff_field(v_x2_241, 0);
    V v_as_2460 = heff_field(v_x2_241, 1);
    V v_go_2461 = heff_tr(heff_apply(((V)&g_heff_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2462 = (g_prelude_2emap(v_go_2461, heff_dup(v_as_2460)));
    V v_t_2465;
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_Nil: {
      v_t_2465 = ((V)&g_heff_2espec_2ekeyGo_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2463 = heff_field(v_x2_2462, 0);
      V v_xs_2464 = heff_field(v_x2_2462, 1);
      heff_take_n(v_x2_2462, 3ULL, 2);
      v_t_2465 = ({ V a_0 = ((V)&g_heff_2espec_2ekeyGo_str36); V a_1 = v_x_2463; V a_2 = v_xs_2464; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2464); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2462);
    }
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str37), heff_strAppend(heff_dup(v_p_2459), heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str38), heff_strAppend(v_t_2465, ((V)&g_heff_2espec_2ekeyGo_str39)))));
  }
  case TAG_ECall: {
    V v_g_2466 = heff_field(v_x2_241, 0);
    V v_as_2467 = heff_field(v_x2_241, 1);
    V v_go_2468 = heff_tr(heff_apply(((V)&g_heff_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2469 = (g_prelude_2emap(v_go_2468, heff_dup(v_as_2467)));
    V v_t_2472;
    switch (heff_tag_of(v_x2_2469)) {
    case TAG_Nil: {
      v_t_2472 = ((V)&g_heff_2espec_2ekeyGo_str40);
      break;
    }
    case TAG_Cons: {
      V v_x_2470 = heff_field(v_x2_2469, 0);
      V v_xs_2471 = heff_field(v_x2_2469, 1);
      heff_take_n(v_x2_2469, 3ULL, 2);
      v_t_2472 = ({ V a_0 = ((V)&g_heff_2espec_2ekeyGo_str41); V a_1 = v_x_2470; V a_2 = v_xs_2471; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2471); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2469);
    }
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str42), heff_strAppend(heff_dup(v_g_2466), heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str43), heff_strAppend(v_t_2472, ((V)&g_heff_2espec_2ekeyGo_str44)))));
  }
  case TAG_EInt: {
    V v_i_2473 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str45), heff_intShow(heff_dup(v_i_2473)));
  }
  case TAG_EFloat: {
    V v_x_2474 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str46), heff_floatShow(heff_dup(v_x_2474)));
  }
  case TAG_EStr: {
    V v_s_2475 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    V v_t_2476 = heff_intShow(heff_strLength(heff_dup(v_s_2475)));
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str47), heff_strAppend(v_t_2476, heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str48), heff_dup(v_s_2475))));
  }
  case TAG_EFixed: {
    V v_w_2477 = heff_field(v_x2_241, 0);
    V v_n_2478 = heff_field(v_x2_241, 1);
    heff_drop(v_env_240);
    V v_t_2479;
    switch (heff_tag_of(v_w_2477)) {
    case TAG_I8: {
      v_t_2479 = ((V)&g_heff_2espec_2ekeyGo_str49);
      break;
    }
    case TAG_I16: {
      v_t_2479 = ((V)&g_heff_2espec_2ekeyGo_str50);
      break;
    }
    case TAG_I32: {
      v_t_2479 = ((V)&g_heff_2espec_2ekeyGo_str51);
      break;
    }
    case TAG_I64: {
      v_t_2479 = ((V)&g_heff_2espec_2ekeyGo_str52);
      break;
    }
    case TAG_U8: {
      v_t_2479 = ((V)&g_heff_2espec_2ekeyGo_str53);
      break;
    }
    case TAG_U16: {
      v_t_2479 = ((V)&g_heff_2espec_2ekeyGo_str54);
      break;
    }
    case TAG_U32: {
      v_t_2479 = ((V)&g_heff_2espec_2ekeyGo_str55);
      break;
    }
    case TAG_U64: {
      v_t_2479 = ((V)&g_heff_2espec_2ekeyGo_str56);
      break;
    }
    case TAG_F32: {
      v_t_2479 = ((V)&g_heff_2espec_2ekeyGo_str57);
      break;
    }
    default: heff_nomatch(v_w_2477);
    }
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str58), heff_strAppend(v_t_2479, heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str59), heff_intShow(heff_dup(v_n_2478)))));
  }
  case TAG_EFloat32: {
    V v_x_2480 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str60), heff_floatShow(heff_dup(v_x_2480)));
  }
  case TAG_EAbandon: {
    heff_drop(v_env_240);
    return ((V)&g_heff_2espec_2ekeyGo_str61);
  }
  case TAG_EFix: {
    heff_drop(v_env_240);
    return ((V)&g_heff_2espec_2ekeyGo_str62);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2ekeyGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2ekeyGo(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2espec_2ekeyGo_lam0(V self, V *args) {
  V v_x2_2426 = args[0];
  V v_go_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_MkPair: {
    V v_l_2427 = heff_field(v_x2_2426, 0);
    V v_v_2428 = heff_field(v_x2_2426, 1);
    heff_take_n(v_x2_2426, 3ULL, 2);
    V v_t_2429 = heff_tr(heff_apply(v_go_2425, 1, (V[]){v_v_2428}));
    return heff_strAppend(v_l_2427, heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str14), v_t_2429));
  }
  default: return heff_nomatch(v_x2_2426);
  }
}
V g_heff_2espec_2ekeyGo_lam1(V self, V *args) {
  V v_x3_2447 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2447)) {
  case TAG_MkArm: {
    V v_t_2448 = heff_field(v_x3_2447, 0);
    V v_vs_2449 = heff_field(v_x3_2447, 1);
    V v_b_2450 = heff_field(v_x3_2447, 2);
    heff_take_n(v_x3_2447, 7ULL, 3);
    V v_t_2451 = (g_prelude_2efoldl_24s1226147011x367015740(MK_INT(1LL), MK_INT(0LL), v_vs_2449));
    V v_t_2452 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_vs_2449));
    V v_t_2453 = (g_heff_2espec_2eappendS(v_t_2452, v_env_240));
    return heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str27), heff_strAppend(v_t_2448, heff_strAppend(heff_intShow(v_t_2451), heff_strAppend(((V)&g_heff_2espec_2ekeyGo_str28), ({ V a_0 = v_t_2453; V a_1 = v_b_2450; V r_ = (g_heff_2espec_2ekeyGo(a_0, a_1)); heff_drop(v_b_2450); r_; })))));
  }
  default: return heff_nomatch(v_x3_2447);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2espec_2ehashGo_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
Clo g_heff_2espec_2ehashGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2ehashGo_entry, 4, 0};

V g_heff_2espec_2ehashGo(V v_s_240, V v_i_241, V v_a_242, V v_b_243) {
top: ;
  V v_t_244 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return heff_strAppend(heff_intShow(v_a_242), heff_strAppend(((V)&g_heff_2espec_2ehashGo_str0), heff_intShow(v_b_243)));
  }
  case TAG_False: {
    V v_t_245 = heff_intAdd(heff_intMul(v_a_242, MK_INT(1000003LL)), heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_246 = heff_intMod(heff_intAdd(v_t_245, MK_INT(1LL)), MK_INT(2147483647LL));
    V v_t_247 = heff_intAdd(heff_intMul(v_b_243, MK_INT(999983LL)), heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_248 = heff_intMod(heff_intAdd(v_t_247, MK_INT(1LL)), MK_INT(2147483629LL));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_246;
    V t_3 = v_t_248;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2espec_2ehashGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2ehashGo(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2espec_2ebindOne_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {97, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2espec_2ebindOne_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {97, 36}};
Clo g_heff_2espec_2ebindOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2ebindOne_entry, 2, 0};

V g_heff_2espec_2ebindOne(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkPair: {
    V v_xs_242 = heff_field(v_x1_240, 0);
    V v_st_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24MkPair = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_intShow(heff_get(heff_dup(v_st_243), LBL_n));
    V v_t_245 = heff_tag_at(v_ru_24x1_240_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2espec_2ebindOne_str0), v_t_244), v_xs_242});
    V v_t_246 = heff_intShow(heff_get(heff_dup(v_st_243), LBL_n));
    V v_t_247 = (g_map_2einsert_24s1341440536x470972936(v_x_241, heff_strAppend(((V)&g_heff_2espec_2ebindOne_str1), v_t_246), heff_get(heff_dup(v_st_243), LBL_ren)));
    V v_t_248 = heff_intAdd(heff_get(heff_dup(v_st_243), LBL_n), MK_INT(1LL));
    V v_t_249 = heff_rec(4, shape_ren__vars__holes__n, (V[]){v_t_247, heff_get(heff_dup(v_st_243), LBL_vars), heff_get(v_st_243, LBL_holes), v_t_248});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_245, v_t_249});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2espec_2ebindOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2ebindOne(a[0], a[1]);
}
Clo g_heff_2espec_2eshapeMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eshapeMany_entry, 3, 0};

V g_heff_2espec_2eshapeMany(V v_go_240, V v_x2_241, V v_st_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_st_242});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_more_245 = heff_tr(heff_apply(((V)&g_heff_2espec_2eshapeMany_clo), 2, (V[]){heff_dup(v_go_240), v_rest_244}));
    V v_x2_246 = heff_tr(heff_apply(v_go_240, 2, (V[]){v_e_243, v_st_242}));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_e_247 = heff_field(v_x2_246, 0);
      V v_st_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      V v_x2_249 = heff_tr(heff_apply(v_more_245, 1, (V[]){v_st_248}));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_es_2410 = heff_field(v_x2_249, 0);
        V v_st_2411 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 3ULL, 2);
        return heff_tag_at(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_e_247, v_es_2410}), v_st_2411});
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2eshapeMany_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2eshapeMany(a[0], a[1], a[2]);
}
Clo g_heff_2espec_2eletThen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eletThen_entry, 4, 0};

V g_heff_2espec_2eletThen(V v_go_240, V v_x_241, V v_b_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_a_244 = heff_field(v_x4_243, 0);
    V v_st_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tag_at(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_st_245});
    V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_241), NTAG(TAG_Nil)});
    V v_t_248 = ({ V a_0 = v_t_246; V a_1 = v_t_247; V r_ = (g_prelude_2efoldl_24s803210893x1036700122(a_0, a_1)); heff_drop_tag(v_t_247, 2); r_; });
    V v_x4_2412;
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkPair: {
      V v_ys_249 = heff_field(v_t_248, 0);
      V v_st2_2410 = heff_field(v_t_248, 1);
      V v_ru_24t_248_24MkPair = heff_take_reuse_n(v_t_248, 3ULL, 2);
      V v_t_2411 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_ys_249));
      v_x4_2412 = heff_tag_at(v_ru_24t_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2411, v_st2_2410});
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    switch (heff_tag_of(v_x4_2412)) {
    case TAG_MkPair: {
      V v_ys_2413 = heff_field(v_x4_2412, 0);
      V v_st_2414 = heff_field(v_x4_2412, 1);
      V v_ru_24x4_2412_24MkPair = heff_take_reuse_n(v_x4_2412, 3ULL, 2);
      V v_x2_2415 = heff_tr(heff_apply(v_go_240, 2, (V[]){v_b_242, v_st_2414}));
      switch (heff_tag_of(v_x2_2415)) {
      case TAG_MkPair: {
        V v_e_2416 = heff_field(v_x2_2415, 0);
        V v_st_2417 = heff_field(v_x2_2415, 1);
        heff_take_n(v_x2_2415, 3ULL, 2);
        V v_t_2420;
        switch (heff_tag_of(v_ys_2413)) {
        case TAG_Nil: {
          v_t_2420 = v_x_241;
          break;
        }
        case TAG_Cons: {
          V v_y_2418 = heff_field(v_ys_2413, 0);
          heff_take_n(v_ys_2413, 1ULL, 2);
          heff_drop(v_x_241);
          v_t_2420 = v_y_2418;
          break;
        }
        default: heff_nomatch(v_ys_2413);
        }
        return heff_tag_at(v_ru_24x4_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_t_2420, v_a_244, v_e_2416}), v_st_2417});
      }
      default: return heff_nomatch(v_x2_2415);
      }
    }
    default: return heff_nomatch(v_x4_2412);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2espec_2eletThen_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2eletThen(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2espec_2elabelsTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2elabelsTo_entry, 2, 0};

V g_heff_2espec_2elabelsTo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_l_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 2);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Nil: {
        heff_drop(v_fs_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_l_244);
        return NTAG(TAG_Nil);
      }
      case TAG_Cons: {
        V v_e_246 = heff_field(v_x2_241, 0);
        V v_es_247 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 3ULL, 2);
        return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_l_244, v_e_246}), (g_heff_2espec_2elabelsTo(v_fs_243, v_es_247))});
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2espec_2elabelsTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2elabelsTo(a[0], a[1]);
}
Clo g_heff_2espec_2eshapeArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eshapeArms_entry, 3, 0};

V g_heff_2espec_2eshapeArms(V v_go_240, V v_x2_241, V v_st_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_st_242});
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkArm: {
      V v_t_245 = heff_field(v_x21_243, 0);
      V v_vs_246 = heff_field(v_x21_243, 1);
      V v_b_247 = heff_field(v_x21_243, 2);
      V v_ru_24x21_243_24MkArm = heff_take_reuse_n(v_x21_243, 7ULL, 3);
      V v_more_248 = heff_tr(heff_apply(((V)&g_heff_2espec_2eshapeArms_clo), 2, (V[]){heff_dup(v_go_240), v_rest_244}));
      V v_t_249 = heff_tag_at(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_st_242});
      V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_vs_246; V r_ = (g_prelude_2efoldl_24s803210893x1036700122(a_0, a_1)); heff_drop(v_vs_246); r_; });
      V v_x3_2414;
      switch (heff_tag_of(v_t_2410)) {
      case TAG_MkPair: {
        V v_ys_2411 = heff_field(v_t_2410, 0);
        V v_st2_2412 = heff_field(v_t_2410, 1);
        V v_ru_24t_2410_24MkPair = heff_take_reuse_n(v_t_2410, 3ULL, 2);
        V v_t_2413 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_ys_2411));
        v_x3_2414 = heff_tag_at(v_ru_24t_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_st2_2412});
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
      V v_x3_2418;
      switch (heff_tag_of(v_x3_2414)) {
      case TAG_MkPair: {
        V v_vs_2415 = heff_field(v_x3_2414, 0);
        V v_st_2416 = heff_field(v_x3_2414, 1);
        V v_ru_24x3_2414_24MkPair = heff_take_reuse_n(v_x3_2414, 3ULL, 2);
        V v_t_2417 = heff_tr(heff_apply(v_go_240, 2, (V[]){v_b_247, v_st_2416}));
        v_x3_2418 = heff_tag_at(v_ru_24x3_2414_24MkPair, TAG_MkPair, 2, (V[]){v_vs_2415, v_t_2417});
        break;
      }
      default: heff_nomatch(v_x3_2414);
      }
      switch (heff_tag_of(v_x3_2418)) {
      case TAG_MkPair: {
        V v_vs_2419 = heff_field(v_x3_2418, 0);
        V v_x32_2420 = heff_field(v_x3_2418, 1);
        V v_ru_24x3_2418_24MkPair = heff_take_reuse_n(v_x3_2418, 3ULL, 2);
        switch (heff_tag_of(v_x32_2420)) {
        case TAG_MkPair: {
          V v_b_2421 = heff_field(v_x32_2420, 0);
          V v_st_2422 = heff_field(v_x32_2420, 1);
          V v_ru_24x32_2420_24MkPair = heff_take_reuse_n(v_x32_2420, 3ULL, 2);
          V v_x2_2423 = heff_tr(heff_apply(v_more_248, 1, (V[]){v_st_2422}));
          switch (heff_tag_of(v_x2_2423)) {
          case TAG_MkPair: {
            V v_as_2424 = heff_field(v_x2_2423, 0);
            V v_st_2425 = heff_field(v_x2_2423, 1);
            heff_take_n(v_x2_2423, 3ULL, 2);
            V v_t_2426 = heff_tag_at(v_ru_24x3_2418_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at(v_ru_24x21_243_24MkArm, TAG_MkArm, 3, (V[]){v_t_245, v_vs_2419, v_b_2421}), v_as_2424});
            return heff_tag_at(v_ru_24x32_2420_24MkPair, TAG_MkPair, 2, (V[]){v_t_2426, v_st_2425});
          }
          default: return heff_nomatch(v_x2_2423);
          }
        }
        default: return heff_nomatch(v_x32_2420);
        }
      }
      default: return heff_nomatch(v_x3_2418);
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2eshapeArms_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2eshapeArms(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2espec_2eshapeGo_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {108, 105, 116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2espec_2eshapeGo_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {108, 105, 116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2espec_2eshapeGo_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {108, 105, 116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2espec_2eshapeGo_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {108, 105, 116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2espec_2eshapeGo_str4 = {{0x80000000u, K_STR, 0}, 4, 4, {108, 105, 116, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2espec_2eshapeGo_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {108, 105, 116, 36}};
Clo g_heff_2espec_2eshapeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eshapeGo_entry, 2, 0};

V g_heff_2espec_2eshapeGo(V v_e_240, V v_st_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EVar = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_x2_243 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get(heff_dup(v_st_241), LBL_ren); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_245;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nothing: {
      v_t_245 = v_x_242;
      break;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x2_243, 0);
      heff_take_n(v_x2_243, 1ULL, 1);
      heff_drop(v_x_242);
      v_t_245 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    return heff_tag(TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24e_240_24EVar, TAG_EVar, 1, (V[]){v_t_245}), v_st_241});
  }
  case TAG_EGlobal: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_240, 0);
    V v_b_248 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_249 = heff_tag_at(v_ru_24e_240_24ELam, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_st_241});
    V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_xs_247; V r_ = (g_prelude_2efoldl_24s803210893x1036700122(a_0, a_1)); heff_drop(v_xs_247); r_; });
    V v_x4_2414;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkPair: {
      V v_ys_2411 = heff_field(v_t_2410, 0);
      V v_st2_2412 = heff_field(v_t_2410, 1);
      V v_ru_24t_2410_24MkPair = heff_take_reuse_n(v_t_2410, 3ULL, 2);
      V v_t_2413 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_ys_2411));
      v_x4_2414 = heff_tag_at(v_ru_24t_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_st2_2412});
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    switch (heff_tag_of(v_x4_2414)) {
    case TAG_MkPair: {
      V v_ys_2415 = heff_field(v_x4_2414, 0);
      V v_st_2416 = heff_field(v_x4_2414, 1);
      V v_ru_24x4_2414_24MkPair = heff_take_reuse_n(v_x4_2414, 3ULL, 2);
      V v_x2_2417 = (g_heff_2espec_2eshapeGo(v_b_248, v_st_2416));
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_MkPair: {
        V v_e_2418 = heff_field(v_x2_2417, 0);
        V v_st_2419 = heff_field(v_x2_2417, 1);
        heff_take_n(v_x2_2417, 3ULL, 2);
        return heff_tag_at(v_ru_24x4_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_ys_2415, v_e_2418}), v_st_2419});
      }
      default: return heff_nomatch(v_x2_2417);
      }
    }
    default: return heff_nomatch(v_x4_2414);
    }
  }
  case TAG_EApp: {
    V v_f_2420 = heff_field(v_e_240, 0);
    V v_as_2421 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EApp = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x3_2422 = (g_heff_2espec_2eshapeGo(v_f_2420, v_st_241));
    switch (heff_tag_of(v_x3_2422)) {
    case TAG_MkPair: {
      V v_f_2423 = heff_field(v_x3_2422, 0);
      V v_st_2424 = heff_field(v_x3_2422, 1);
      heff_take_n(v_x3_2422, 3ULL, 2);
      V v_x2_2425 = (g_heff_2espec_2eshapeMany(((V)&g_heff_2espec_2eshapeGo_clo), v_as_2421, v_st_2424));
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_MkPair: {
        V v_es_2426 = heff_field(v_x2_2425, 0);
        V v_st_2427 = heff_field(v_x2_2425, 1);
        heff_take_n(v_x2_2425, 3ULL, 2);
        return heff_tag_at(v_ru_24e_240_24EApp, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_2423, v_es_2426}), v_st_2427});
      }
      default: return heff_nomatch(v_x2_2425);
      }
    }
    default: return heff_nomatch(v_x3_2422);
    }
  }
  case TAG_ELet: {
    V v_x_2428 = heff_field(v_e_240, 0);
    V v_a_2429 = heff_field(v_e_240, 1);
    V v_b_2430 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_t_2431 = (g_heff_2espec_2eshapeGo(v_a_2429, v_st_241));
    return (g_heff_2espec_2eletThen(((V)&g_heff_2espec_2eshapeGo_clo), v_x_2428, v_b_2430, v_t_2431));
  }
  case TAG_ERecord: {
    V v_fs_2432 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24ERecord = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_t_2433 = (g_prelude_2emap_24s1448703749x94773476(heff_dup(v_fs_2432)));
    V v_x2_2434 = (g_heff_2espec_2eshapeMany(((V)&g_heff_2espec_2eshapeGo_clo), v_t_2433, v_st_241));
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_MkPair: {
      V v_es_2435 = heff_field(v_x2_2434, 0);
      V v_st_2436 = heff_field(v_x2_2434, 1);
      V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
      V v_t_2437 = heff_tag_at(v_ru_24e_240_24ERecord, TAG_ERecord, 1, (V[]){(g_heff_2espec_2elabelsTo(v_fs_2432, v_es_2435))});
      return heff_tag_at(v_ru_24x2_2434_24MkPair, TAG_MkPair, 2, (V[]){v_t_2437, v_st_2436});
    }
    default: return heff_nomatch(v_x2_2434);
    }
  }
  case TAG_EProj: {
    V v_e1_2438 = heff_field(v_e_240, 0);
    V v_l_2439 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EProj = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x2_2440 = (g_heff_2espec_2eshapeGo(v_e1_2438, v_st_241));
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_MkPair: {
      V v_e_2441 = heff_field(v_x2_2440, 0);
      V v_st_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      return heff_tag_at(v_ru_24e_240_24EProj, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_e_2441, v_l_2439}), v_st_2442});
    }
    default: return heff_nomatch(v_x2_2440);
    }
  }
  case TAG_ETag: {
    V v_t_2443 = heff_field(v_e_240, 0);
    V v_as_2444 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ETag = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x2_2445 = (g_heff_2espec_2eshapeMany(((V)&g_heff_2espec_2eshapeGo_clo), v_as_2444, v_st_241));
    switch (heff_tag_of(v_x2_2445)) {
    case TAG_MkPair: {
      V v_es_2446 = heff_field(v_x2_2445, 0);
      V v_st_2447 = heff_field(v_x2_2445, 1);
      heff_take_n(v_x2_2445, 3ULL, 2);
      return heff_tag_at(v_ru_24e_240_24ETag, TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2443, v_es_2446}), v_st_2447});
    }
    default: return heff_nomatch(v_x2_2445);
    }
  }
  case TAG_EMatch: {
    V v_sc_2448 = heff_field(v_e_240, 0);
    V v_arms_2449 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EMatch = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x3_2450 = (g_heff_2espec_2eshapeGo(v_sc_2448, v_st_241));
    switch (heff_tag_of(v_x3_2450)) {
    case TAG_MkPair: {
      V v_sc_2451 = heff_field(v_x3_2450, 0);
      V v_st_2452 = heff_field(v_x3_2450, 1);
      heff_take_n(v_x3_2450, 3ULL, 2);
      V v_t_2453 = (g_heff_2espec_2eshapeArms(((V)&g_heff_2espec_2eshapeGo_clo), v_arms_2449, v_st_2452));
      switch (heff_tag_of(v_t_2453)) {
      case TAG_MkPair: {
        V v_arms2_2454 = heff_field(v_t_2453, 0);
        V v_st2_2455 = heff_field(v_t_2453, 1);
        heff_take_n(v_t_2453, 3ULL, 2);
        return heff_tag_at(v_ru_24e_240_24EMatch, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_sc_2451, v_arms2_2454}), v_st2_2455});
      }
      default: return heff_nomatch(v_t_2453);
      }
    }
    default: return heff_nomatch(v_x3_2450);
    }
  }
  case TAG_EPrim: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_EPrimCall: {
    V v_p_2457 = heff_field(v_e_240, 0);
    V v_as_2458 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EPrimCall = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x2_2459 = (g_heff_2espec_2eshapeMany(((V)&g_heff_2espec_2eshapeGo_clo), v_as_2458, v_st_241));
    switch (heff_tag_of(v_x2_2459)) {
    case TAG_MkPair: {
      V v_es_2460 = heff_field(v_x2_2459, 0);
      V v_st_2461 = heff_field(v_x2_2459, 1);
      heff_take_n(v_x2_2459, 3ULL, 2);
      return heff_tag_at(v_ru_24e_240_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_2457, v_es_2460}), v_st_2461});
    }
    default: return heff_nomatch(v_x2_2459);
    }
  }
  case TAG_ECall: {
    V v_g_2462 = heff_field(v_e_240, 0);
    V v_as_2463 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ECall = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x2_2464 = (g_heff_2espec_2eshapeMany(((V)&g_heff_2espec_2eshapeGo_clo), v_as_2463, v_st_241));
    switch (heff_tag_of(v_x2_2464)) {
    case TAG_MkPair: {
      V v_es_2465 = heff_field(v_x2_2464, 0);
      V v_st_2466 = heff_field(v_x2_2464, 1);
      heff_take_n(v_x2_2464, 3ULL, 2);
      return heff_tag_at(v_ru_24e_240_24ECall, TAG_MkPair, 2, (V[]){heff_tag(TAG_ECall, 2, (V[]){v_g_2462, v_es_2465}), v_st_2466});
    }
    default: return heff_nomatch(v_x2_2464);
    }
  }
  case TAG_EInt: {
    V v_i_2467 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EInt = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_t_2468 = heff_intShow(heff_get(heff_dup(v_st_241), LBL_n));
    V v_t_2469 = heff_tag_at(v_ru_24e_240_24EInt, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2espec_2eshapeGo_str0), v_t_2468)});
    V v_t_2470 = heff_intShow(heff_get(heff_dup(v_st_241), LBL_n));
    V v_t_2471 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2espec_2eshapeGo_str1), v_t_2470), heff_get(heff_dup(v_st_241), LBL_vars)});
    V v_t_2472 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_EInt, 1, (V[]){v_i_2467}), heff_get(heff_dup(v_st_241), LBL_holes)});
    V v_t_2473 = heff_intAdd(heff_get(heff_dup(v_st_241), LBL_n), MK_INT(1LL));
    V v_t_2474 = heff_rec(4, shape_ren__vars__holes__n, (V[]){heff_get(v_st_241, LBL_ren), v_t_2471, v_t_2472, v_t_2473});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2469, v_t_2474});
  }
  case TAG_EFloat: {
    V v_x_2475 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EFloat = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_t_2476 = heff_intShow(heff_get(heff_dup(v_st_241), LBL_n));
    V v_t_2477 = heff_tag_at(v_ru_24e_240_24EFloat, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2espec_2eshapeGo_str2), v_t_2476)});
    V v_t_2478 = heff_intShow(heff_get(heff_dup(v_st_241), LBL_n));
    V v_t_2479 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2espec_2eshapeGo_str3), v_t_2478), heff_get(heff_dup(v_st_241), LBL_vars)});
    V v_t_2480 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_EFloat, 1, (V[]){v_x_2475}), heff_get(heff_dup(v_st_241), LBL_holes)});
    V v_t_2481 = heff_intAdd(heff_get(heff_dup(v_st_241), LBL_n), MK_INT(1LL));
    V v_t_2482 = heff_rec(4, shape_ren__vars__holes__n, (V[]){heff_get(v_st_241, LBL_ren), v_t_2479, v_t_2480, v_t_2481});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2477, v_t_2482});
  }
  case TAG_EStr: {
    V v_t_2483 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EStr = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_t_2484 = heff_intShow(heff_get(heff_dup(v_st_241), LBL_n));
    V v_t_2485 = heff_tag_at(v_ru_24e_240_24EStr, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2espec_2eshapeGo_str4), v_t_2484)});
    V v_t_2486 = heff_intShow(heff_get(heff_dup(v_st_241), LBL_n));
    V v_t_2487 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2espec_2eshapeGo_str5), v_t_2486), heff_get(heff_dup(v_st_241), LBL_vars)});
    V v_t_2488 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_EStr, 1, (V[]){v_t_2483}), heff_get(heff_dup(v_st_241), LBL_holes)});
    V v_t_2489 = heff_intAdd(heff_get(heff_dup(v_st_241), LBL_n), MK_INT(1LL));
    V v_t_2490 = heff_rec(4, shape_ren__vars__holes__n, (V[]){heff_get(v_st_241, LBL_ren), v_t_2487, v_t_2488, v_t_2489});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2485, v_t_2490});
  }
  case TAG_EFixed: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_EFloat32: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_EAbandon: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_EFix: {
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2espec_2eshapeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2eshapeGo(a[0], a[1]);
}
Clo g_heff_2espec_2eheadUses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eheadUses_entry, 2, 0};

V g_heff_2espec_2eheadUses(V v_go_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_f_241)) {
  case TAG_EVar: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EGlobal: {
    heff_take_n(v_f_241, 0ULL, 1);
    heff_drop(v_go_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EApp: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ELet: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ERecord: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EProj: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ETag: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EMatch: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EPrim: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EPrimCall: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ECall: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EInt: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFloat: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EStr: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFixed: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFloat32: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EAbandon: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFix: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  default: return heff_nomatch(v_f_241);
  }
}
V g_heff_2espec_2eheadUses_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2eheadUses(a[0], a[1]);
}
V g_heff_2espec_2eusesOf_lam0(V self, V *args);
V g_heff_2espec_2eusesOf_lam1(V self, V *args);
V g_heff_2espec_2eusesOf_lam2(V self, V *args);
V g_heff_2espec_2eusesOf_lam3(V self, V *args);
V g_heff_2espec_2eusesOf_lam4(V self, V *args);
V g_heff_2espec_2eusesOf_lam5(V self, V *args);
Clo g_heff_2espec_2eusesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eusesOf_entry, 2, 0};

V g_heff_2espec_2eusesOf(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    V v_h_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_244 = heff_strEq(v_h_243, v_g_240);
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      return heff_tag(TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    }
    case TAG_False: {
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_ELam: {
    V v_b_246 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_g_240;
    V t_1 = v_b_246;
    v_g_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_247 = heff_field(v_x2_241, 0);
    V v_as_248 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2439;
    switch (heff_tag_of(v_f_247)) {
    case TAG_EVar: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EGlobal: {
      V v_h_2410 = heff_dup(heff_field(v_f_247, 0));
      V v_t_2411 = heff_strEq(v_h_2410, heff_dup(v_g_240));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        v_t_2439 = heff_tag_at(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){heff_tag(TAG_Just, 1, (V[]){heff_dup(v_as_248)}), NTAG(TAG_Nil)});
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x2_241_24EApp, 2);
        v_t_2439 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      break;
    }
    case TAG_ELam: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EApp: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ELet: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ERecord: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EProj: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ETag: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EMatch: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrim: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrimCall: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ECall: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EInt: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EStr: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFixed: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat32: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFix: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2439 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_f_247);
    }
    V v_t_2440 = heff_tr(heff_apply(((V)&g_heff_2espec_2eusesOf_clo), 1, (V[]){heff_dup(v_g_240)}));
    V v_t_2441 = heff_tr(g_heff_2espec_2eheadUses(v_t_2440, v_f_247));
    V v_f_2442 = heff_tr(heff_apply(((V)&g_heff_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2443 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_as_248));
    V v_t_2447 = ({ V a_0 = heff_clo(g_heff_2espec_2eusesOf_lam0, 2, 1, (V[]){v_f_2442}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2443; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2443); r_; });
    V v_t_2448 = (g_heff_2espec_2eappendS(v_t_2441, v_t_2447));
    HEFF_LAST return g_heff_2espec_2eappendS(v_t_2439, v_t_2448);
  }
  case TAG_ELet: {
    V v_a_2450 = heff_field(v_x2_241, 1);
    V v_b_2451 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2452 = (g_heff_2espec_2eusesOf(heff_dup(v_g_240), v_a_2450));
    V v_t_2453 = (g_heff_2espec_2eusesOf(v_g_240, v_b_2451));
    HEFF_LAST return g_heff_2espec_2eappendS(v_t_2452, v_t_2453);
  }
  case TAG_ERecord: {
    V v_fs_2454 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_f_2455 = heff_tr(heff_apply(((V)&g_heff_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_xs_2456 = (g_prelude_2emap_24s1448703749x94773476(v_fs_2454));
    V v_t_2457 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2456));
    return ({ V a_0 = heff_clo(g_heff_2espec_2eusesOf_lam1, 2, 1, (V[]){v_f_2455}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2457; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2457); r_; });
  }
  case TAG_EProj: {
    V v_e_2461 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    V t_0 = v_g_240;
    V t_1 = v_e_2461;
    v_g_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2464 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_f_2465 = heff_tr(heff_apply(((V)&g_heff_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2466 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_as_2464));
    return ({ V a_0 = heff_clo(g_heff_2espec_2eusesOf_lam2, 2, 1, (V[]){v_f_2465}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2466; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2466); r_; });
  }
  case TAG_EMatch: {
    V v_s_2470 = heff_field(v_x2_241, 0);
    V v_arms_2471 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2472 = (g_heff_2espec_2eusesOf(heff_dup(v_g_240), v_s_2470));
    V v_f_2473 = heff_tr(heff_apply(((V)&g_heff_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_xs_2474 = (g_prelude_2emap_24s1295898052x1915853031(v_arms_2471));
    V v_t_2475 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_xs_2474));
    V v_t_2479 = ({ V a_0 = heff_clo(g_heff_2espec_2eusesOf_lam3, 2, 1, (V[]){v_f_2473}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2475; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2475); r_; });
    HEFF_LAST return g_heff_2espec_2eappendS(v_t_2472, v_t_2479);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_as_2482 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_f_2483 = heff_tr(heff_apply(((V)&g_heff_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2484 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_as_2482));
    return ({ V a_0 = heff_clo(g_heff_2espec_2eusesOf_lam4, 2, 1, (V[]){v_f_2483}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2484; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2484); r_; });
  }
  case TAG_ECall: {
    V v_h_2488 = heff_field(v_x2_241, 0);
    V v_as_2489 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2490 = heff_strEq(v_h_2488, heff_dup(v_g_240));
    V v_t_2491;
    switch (heff_tag_of(v_t_2490)) {
    case TAG_True: {
      v_t_2491 = heff_tag_at(v_ru_24x2_241_24ECall, TAG_Cons, 2, (V[]){heff_tag(TAG_Just, 1, (V[]){heff_dup(v_as_2489)}), NTAG(TAG_Nil)});
      break;
    }
    case TAG_False: {
      heff_drop_cell(v_ru_24x2_241_24ECall, 2);
      v_t_2491 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_2490);
    }
    V v_f_2492 = heff_tr(heff_apply(((V)&g_heff_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2493 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_as_2489));
    V v_t_2497 = ({ V a_0 = heff_clo(g_heff_2espec_2eusesOf_lam5, 2, 1, (V[]){v_f_2492}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2493; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2493); r_; });
    HEFF_LAST return g_heff_2espec_2eappendS(v_t_2491, v_t_2497);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2eusesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2eusesOf(a[0], a[1]);
}
V g_heff_2espec_2eusesOf_lam0(V self, V *args) {
  V v_acc_2444 = args[0];
  V v_x_2445 = args[1];
  V v_f_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446 = heff_tr(heff_apply(v_f_2442, 1, (V[]){v_x_2445}));
  return (g_prelude_2econcatList(v_t_2446, v_acc_2444));
}
V g_heff_2espec_2eusesOf_lam1(V self, V *args) {
  V v_acc_2458 = args[0];
  V v_x_2459 = args[1];
  V v_f_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2460 = heff_tr(heff_apply(v_f_2455, 1, (V[]){v_x_2459}));
  return (g_prelude_2econcatList(v_t_2460, v_acc_2458));
}
V g_heff_2espec_2eusesOf_lam2(V self, V *args) {
  V v_acc_2467 = args[0];
  V v_x_2468 = args[1];
  V v_f_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = heff_tr(heff_apply(v_f_2465, 1, (V[]){v_x_2468}));
  return (g_prelude_2econcatList(v_t_2469, v_acc_2467));
}
V g_heff_2espec_2eusesOf_lam3(V self, V *args) {
  V v_acc_2476 = args[0];
  V v_x_2477 = args[1];
  V v_f_2473 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2478 = heff_tr(heff_apply(v_f_2473, 1, (V[]){v_x_2477}));
  return (g_prelude_2econcatList(v_t_2478, v_acc_2476));
}
V g_heff_2espec_2eusesOf_lam4(V self, V *args) {
  V v_acc_2485 = args[0];
  V v_x_2486 = args[1];
  V v_f_2483 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2487 = heff_tr(heff_apply(v_f_2483, 1, (V[]){v_x_2486}));
  return (g_prelude_2econcatList(v_t_2487, v_acc_2485));
}
V g_heff_2espec_2eusesOf_lam5(V self, V *args) {
  V v_acc_2494 = args[0];
  V v_x_2495 = args[1];
  V v_f_2492 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2496 = heff_tr(heff_apply(v_f_2492, 1, (V[]){v_x_2495}));
  return (g_prelude_2econcatList(v_t_2496, v_acc_2494));
}
Clo g_heff_2espec_2enthS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2enthS_entry, 2, 0};

V g_heff_2espec_2enthS(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_240), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_240);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2enthS_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2enthS(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2espec_2ehandsOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2ehandsOn_entry, 3, 0};

V g_heff_2espec_2ehandsOn(V v_x_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_x_240);
    heff_drop(v_i_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_as_243 = heff_field(v_x3_242, 0);
    V v_x2_244 = (g_heff_2espec_2enthS(v_i_241, v_as_243));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nothing: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_x21_245 = heff_field(v_x2_244, 0);
      heff_take_n(v_x2_244, 1ULL, 1);
      switch (heff_tag_of(v_x21_245)) {
      case TAG_EVar: {
        V v_y_246 = heff_field(v_x21_245, 0);
        heff_take_n(v_x21_245, 1ULL, 1);
        return heff_strEq(v_x_240, v_y_246);
      }
      case TAG_EGlobal: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        heff_take_n(v_x21_245, 0ULL, 3);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_245);
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2espec_2ehandsOn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2ehandsOn(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2espec_2estaticGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2estaticGo_entry, 3, 0};

V g_heff_2espec_2estaticGo(V v_uses_240, V v_x2_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_apply(((V)&g_heff_2espec_2ehandsOn_clo), 2, (V[]){v_x_243, heff_dup(v_i_242)}));
    V v_t_246 = (g_heff_2espec_2eallS(v_t_245, v_uses_240));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_heff_2espec_2estaticGo(v_uses_240, v_xs_244, heff_intAdd(v_i_242, MK_INT(1LL))))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2espec_2estaticGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2estaticGo(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_heff_2espec_2edropAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2edropAt_entry, 2, 0};

V g_heff_2espec_2edropAt(V v_x1_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_as_241;
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x1_240, 0);
    V v_ds_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      heff_drop(v_d_242);
      heff_drop(v_ds_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_a_244 = heff_field(v_as_241, 0);
      V v_as2_245 = heff_field(v_as_241, 1);
      heff_take_n(v_as_241, 3ULL, 2);
      switch (heff_tag_of(v_d_242)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_244);
        V t_0 = v_ds_243;
        V t_1 = v_as2_245;
        v_x1_240 = t_0;
        v_as_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, (g_heff_2espec_2edropAt(v_ds_243, v_as2_245))});
      }
      default: return heff_nomatch(v_d_242);
      }
    }
    default: return heff_nomatch(v_as_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2espec_2edropAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2edropAt(a[0], a[1]);
}
Clo g_heff_2espec_2eselfHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eselfHead_entry, 4, 0};

V g_heff_2espec_2eselfHead(V v_go_240, V v_g_241, V v_h_242, V v_f_243) {
top: ;
  switch (heff_tag_of(v_f_243)) {
  case TAG_EVar: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EGlobal: {
    V v_k_245 = heff_field(v_f_243, 0);
    V v_ru_24f_243_24EGlobal = heff_take_reuse_n(v_f_243, 1ULL, 1);
    heff_drop(v_go_240);
    V v_t_246 = heff_strEq(heff_dup(v_k_245), v_g_241);
    V v_t_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_k_245);
      v_t_247 = v_h_242;
      break;
    }
    case TAG_False: {
      heff_drop(v_h_242);
      v_t_247 = v_k_245;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_at(v_ru_24f_243_24EGlobal, TAG_EGlobal, 1, (V[]){v_t_247});
  }
  case TAG_ELam: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EApp: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ELet: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ERecord: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EProj: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ETag: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EMatch: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EPrim: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ECall: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EInt: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFloat: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EStr: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFixed: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFloat32: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EAbandon: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFix: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  default: return heff_nomatch(v_f_243);
  }
}
V g_heff_2espec_2eselfHead_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2eselfHead(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2espec_2eselfArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eselfArgs_entry, 5, 0};

V g_heff_2espec_2eselfArgs(V v_g_240, V v_pre_241, V v_ds_242, V v_f_243, V v_as_244) {
top: ;
  switch (heff_tag_of(v_f_243)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EGlobal: {
    V v_k_246 = heff_field(v_f_243, 0);
    V v_t_247 = heff_strEq(heff_dup(v_k_246), v_g_240);
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      V v_t_248 = (g_heff_2espec_2edropAt(v_ds_242, v_as_244));
      return (g_heff_2espec_2eappendS(v_pre_241, v_t_248));
    }
    case TAG_False: {
      heff_drop(v_pre_241);
      heff_drop(v_ds_242);
      return v_as_244;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_ELam: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EApp: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_ECall: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  default: return heff_nomatch(v_f_243);
  }
}
V g_heff_2espec_2eselfArgs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2espec_2eselfArgs(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[3]); return r;
}
V g_heff_2espec_2eselfTo_lam0(V self, V *args);
V g_heff_2espec_2eselfTo_lam1(V self, V *args);
Clo g_heff_2espec_2eselfTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2espec_2eselfTo_entry, 5, 0};

V g_heff_2espec_2eselfTo(V v_g_240, V v_h_241, V v_pre_242, V v_ds_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_244, 0);
    V v_b_248 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ELam = heff_take_reuse_n(v_e_244, 3ULL, 2);
    return heff_tag_at(v_ru_24e_244_24ELam, TAG_ELam, 2, (V[]){v_xs_247, (g_heff_2espec_2eselfTo(v_g_240, v_h_241, v_pre_242, v_ds_243, v_b_248))});
  }
  case TAG_EApp: {
    V v_f_249 = heff_field(v_e_244, 0);
    V v_as_2410 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24EApp = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2411 = heff_tr(heff_apply(((V)&g_heff_2espec_2eselfTo_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243)}));
    V v_t_2412 = heff_tr(g_heff_2espec_2eselfHead(v_t_2411, heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_f_249)));
    V v_t_2413 = heff_tr(heff_apply(((V)&g_heff_2espec_2eselfTo_clo), 4, (V[]){heff_dup(v_g_240), v_h_241, heff_dup(v_pre_242), heff_dup(v_ds_243)}));
    V v_t_2414 = ({ V a_0 = v_g_240; V a_1 = v_pre_242; V a_2 = v_ds_243; V a_3 = v_f_249; V a_4 = v_as_2410; V r_ = (g_heff_2espec_2eselfArgs(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_f_249); r_; });
    return heff_tag_at(v_ru_24e_244_24EApp, TAG_EApp, 2, (V[]){v_t_2412, (g_prelude_2emap(v_t_2413, v_t_2414))});
  }
  case TAG_ELet: {
    V v_x_2415 = heff_field(v_e_244, 0);
    V v_a_2416 = heff_field(v_e_244, 1);
    V v_b_2417 = heff_field(v_e_244, 2);
    V v_ru_24e_244_24ELet = heff_take_reuse_n(v_e_244, 7ULL, 3);
    V v_t_2418 = (g_heff_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243), v_a_2416));
    return heff_tag_at(v_ru_24e_244_24ELet, TAG_ELet, 3, (V[]){v_x_2415, v_t_2418, (g_heff_2espec_2eselfTo(v_g_240, v_h_241, v_pre_242, v_ds_243, v_b_2417))});
  }
  case TAG_ERecord: {
    V v_fs_2419 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24ERecord = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_go_2420 = heff_tr(heff_apply(((V)&g_heff_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    return heff_tag_at(v_ru_24e_244_24ERecord, TAG_ERecord, 1, (V[]){(g_prelude_2emap(heff_clo(g_heff_2espec_2eselfTo_lam0, 1, 1, (V[]){v_go_2420}), v_fs_2419))});
  }
  case TAG_EProj: {
    V v_e1_2425 = heff_field(v_e_244, 0);
    V v_l_2426 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24EProj = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2427 = (g_heff_2espec_2eselfTo(v_g_240, v_h_241, v_pre_242, v_ds_243, v_e1_2425));
    return heff_tag_at(v_ru_24e_244_24EProj, TAG_EProj, 2, (V[]){v_t_2427, v_l_2426});
  }
  case TAG_ETag: {
    V v_t_2428 = heff_field(v_e_244, 0);
    V v_as_2429 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ETag = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2430 = heff_tr(heff_apply(((V)&g_heff_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    return heff_tag_at(v_ru_24e_244_24ETag, TAG_ETag, 2, (V[]){v_t_2428, (g_prelude_2emap(v_t_2430, v_as_2429))});
  }
  case TAG_EMatch: {
    V v_s_2431 = heff_field(v_e_244, 0);
    V v_arms_2432 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24EMatch = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2433 = (g_heff_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243), v_s_2431));
    V v_go_2434 = heff_tr(heff_apply(((V)&g_heff_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    return heff_tag_at(v_ru_24e_244_24EMatch, TAG_EMatch, 2, (V[]){v_t_2433, (g_prelude_2emap(heff_clo(g_heff_2espec_2eselfTo_lam1, 1, 1, (V[]){v_go_2434}), v_arms_2432))});
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EPrimCall: {
    V v_p_2441 = heff_field(v_e_244, 0);
    V v_as_2442 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24EPrimCall = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2443 = heff_tr(heff_apply(((V)&g_heff_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    return heff_tag_at(v_ru_24e_244_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2441, (g_prelude_2emap(v_t_2443, v_as_2442))});
  }
  case TAG_ECall: {
    V v_k_2444 = heff_field(v_e_244, 0);
    V v_as_2445 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ECall = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2446 = heff_tr(heff_apply(((V)&g_heff_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    return heff_tag_at(v_ru_24e_244_24ECall, TAG_ECall, 2, (V[]){v_k_2444, (g_prelude_2emap(v_t_2446, v_as_2445))});
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2espec_2eselfTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2espec_2eselfTo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2espec_2eselfTo_lam0(V self, V *args) {
  V v_x2_2421 = args[0];
  V v_go_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_l_2422 = heff_field(v_x2_2421, 0);
    V v_v_2423 = heff_field(v_x2_2421, 1);
    V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
    V v_t_2424 = heff_tr(heff_apply(v_go_2420, 1, (V[]){v_v_2423}));
    return heff_tag_at(v_ru_24x2_2421_24MkPair, TAG_MkPair, 2, (V[]){v_l_2422, v_t_2424});
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2espec_2eselfTo_lam1(V self, V *args) {
  V v_x2_2435 = args[0];
  V v_go_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_MkArm: {
    V v_t_2436 = heff_field(v_x2_2435, 0);
    V v_vs_2437 = heff_field(v_x2_2435, 1);
    V v_b_2438 = heff_field(v_x2_2435, 2);
    V v_ru_24x2_2435_24MkArm = heff_take_reuse_n(v_x2_2435, 7ULL, 3);
    V v_t_2439 = heff_tr(heff_apply(v_go_2434, 1, (V[]){v_b_2438}));
    return heff_tag_at(v_ru_24x2_2435_24MkArm, TAG_MkArm, 3, (V[]){v_t_2436, v_vs_2437, v_t_2439});
  }
  default: return heff_nomatch(v_x2_2435);
  }
}