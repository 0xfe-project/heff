// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Close 2276
#define TAG_Finish 61316
#define TAG_Open 48267
#define TAG_Start 63542
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_std_2ereactor_2ereactor_get(void);
V g_std_2ereactor_2ereactor_lam1(V self, V *args);
V g_std_2ereactor_2ereactor_lam4(V self, V *args);
V g_std_2ereactor_2ereactor_lam3(V self, V *args);
V g_std_2ereactor_2ereactor_lam2(V self, V *args);
V g_std_2ereactor_2ereactor_lam7(V self, V *args);
V g_std_2ereactor_2ereactor_lam6(V self, V *args);
V g_std_2ereactor_2ereactor_lam5(V self, V *args);
V g_std_2ereactor_2ereactor_lam0(V self, V *args); static Clo g_std_2ereactor_2ereactor_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ereactor_2ereactor_lam0, 3, 0};
V g_std_2ereactor_2ereactor_lam10(V self, V *args);
V g_std_2ereactor_2ereactor_lam9(V self, V *args);
V g_std_2ereactor_2ereactor_lam8(V self, V *args); static Clo g_std_2ereactor_2ereactor_lam8_clo = {{0x80000000u, K_CLO, 0}, g_std_2ereactor_2ereactor_lam8, 4, 0};

static V g_std_2ereactor_2ereactor_val;
static HEFF_ONCE g_std_2ereactor_2ereactor_st;
static V g_std_2ereactor_2ereactor_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2ereactor_2ereactor_lam0_clo), ((V)&g_std_2ereactor_2ereactor_lam8_clo)});
}
V g_std_2ereactor_2ereactor_get(void) {
  if (HEFF_DONE(g_std_2ereactor_2ereactor_st)) return g_std_2ereactor_2ereactor_val;
  return heff_global(&g_std_2ereactor_2ereactor_val, &g_std_2ereactor_2ereactor_st, g_std_2ereactor_2ereactor_init);
}
V g_std_2ereactor_2ereactor_lam1(V self, V *args) {
  V v_i_244 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_tr(heff_call(v_k_243, 1, (V[]){v_i_244}));
  V f_ = v_g_241;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam4(V self, V *args) {
  V v_v_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_v_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam3(V self, V *args) {
  V v_c_249 = args[0];
  V v_k_2410 = args[1];
  V v_use_248 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_use_248;
  args[0] = v_c_249;
  args[1] = heff_clo_n(g_std_2ereactor_2ereactor_lam4, 1, 2, (V[]){v_k_2410, v_g_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2ereactor_2ereactor_lam2(V self, V *args) {
  V v_use_248 = args[0];
  V v_b_247 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_b_247;
  args[0] = heff_clo_n(g_std_2ereactor_2ereactor_lam3, 2, 2, (V[]){v_use_248, v_g_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam7(V self, V *args) {
  V v_l_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_k_2417, 1, (V[]){v_l_2418}));
  V f_ = v_g_241;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam6(V self, V *args) {
  V v_k_2417 = args[0];
  V v_use_2416 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_use_2416;
  args[0] = heff_clo_n(g_std_2ereactor_2ereactor_lam7, 1, 2, (V[]){v_k_2417, v_g_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam5(V self, V *args) {
  V v_use_2416 = args[0];
  V v_f_2415 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_f_2415;
  args[0] = heff_clo_n(g_std_2ereactor_2ereactor_lam6, 1, 2, (V[]){v_use_2416, v_g_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Open: {
    V v_k_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Open = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Open, TAG_Open, 1, (V[]){heff_clo_n(g_std_2ereactor_2ereactor_lam1, 1, 2, (V[]){v_k_243, v_g_241})});
  }
  case TAG_Start: {
    V v_i_246 = heff_field(v_p_242, 0);
    V v_b_247 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Start = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Start, TAG_Start, 2, (V[]){v_i_246, heff_clo_n(g_std_2ereactor_2ereactor_lam2, 1, 2, (V[]){v_b_247, v_g_241})});
  }
  case TAG_Finish: {
    V v_i_2413 = heff_field(v_p_242, 0);
    V v_w_2414 = heff_field(v_p_242, 1);
    V v_f_2415 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Finish = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24Finish, TAG_Finish, 3, (V[]){v_i_2413, v_w_2414, heff_clo_n(g_std_2ereactor_2ereactor_lam5, 1, 2, (V[]){v_f_2415, v_g_241})});
  }
  case TAG_Close: {
    V v_i_2420 = heff_field(v_p_242, 0);
    V v_x_2421 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Close = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2422 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2421}));
    return heff_tag_at_n(v_ru_24p_242_24Close, TAG_Close, 2, (V[]){v_i_2420, v_t_2422});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2ereactor_2ereactor_lam10(V self, V *args) {
  V v_c_2431 = args[0];
  V v_k_2432 = args[1];
  V v_nt_2425 = heff_env(self)[0];
  V v_use_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_tr(heff_call(v_nt_2425, 1, (V[]){v_c_2431}));
  V f_ = v_use_2430;
  args[0] = v_t_2433;
  args[1] = v_k_2432;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2ereactor_2ereactor_lam9(V self, V *args) {
  V v_use_2430 = args[0];
  V v_b_2429 = heff_env(self)[0];
  V v_nt_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_b_2429;
  args[0] = heff_clo_n(g_std_2ereactor_2ereactor_lam10, 2, 2, (V[]){v_nt_2425, v_use_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam8(V self, V *args) {
  V v_m_2423 = args[0];
  V v_n_2424 = args[1];
  V v_nt_2425 = args[2];
  V v_p_2426 = args[3];
  heff_drop(v_m_2423);
  heff_drop(v_n_2424);
  switch (heff_tag_of(v_p_2426)) {
  case TAG_Open: {
    V v_k_2427 = heff_field(v_p_2426, 0);
    V v_ru_24p_2426_24Open = heff_take_reuse_n(v_p_2426, 1ULL, 1);
    heff_drop(v_nt_2425);
    return heff_tag_at_n(v_ru_24p_2426_24Open, TAG_Open, 1, (V[]){v_k_2427});
  }
  case TAG_Start: {
    V v_i_2428 = heff_field(v_p_2426, 0);
    V v_b_2429 = heff_field(v_p_2426, 1);
    V v_ru_24p_2426_24Start = heff_take_reuse_n(v_p_2426, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2426_24Start, TAG_Start, 2, (V[]){v_i_2428, heff_clo_n(g_std_2ereactor_2ereactor_lam9, 1, 2, (V[]){v_b_2429, v_nt_2425})});
  }
  case TAG_Finish: {
    V v_i_2434 = heff_field(v_p_2426, 0);
    V v_w_2435 = heff_field(v_p_2426, 1);
    V v_f_2436 = heff_field(v_p_2426, 2);
    V v_ru_24p_2426_24Finish = heff_take_reuse_n(v_p_2426, 7ULL, 3);
    heff_drop(v_nt_2425);
    return heff_tag_at_n(v_ru_24p_2426_24Finish, TAG_Finish, 3, (V[]){v_i_2434, v_w_2435, v_f_2436});
  }
  case TAG_Close: {
    V v_i_2437 = heff_field(v_p_2426, 0);
    V v_x_2438 = heff_field(v_p_2426, 1);
    V v_ru_24p_2426_24Close = heff_take_reuse_n(v_p_2426, 3ULL, 2);
    heff_drop(v_nt_2425);
    return heff_tag_at_n(v_ru_24p_2426_24Close, TAG_Close, 2, (V[]){v_i_2437, v_x_2438});
  }
  default: return heff_nomatch(v_p_2426);
  }
}