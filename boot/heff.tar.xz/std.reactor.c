// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Begin 41697
#define TAG_Close 2276
#define TAG_End 17255
#define TAG_Finish 61316
#define TAG_MkGroup 19195
#define TAG_Open 48267
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_std_2ereactor_2ereactor_get(void);
V g_std_2ereactor_2estart_24s1697505031x474729009(V, V, V, V, V);
V g_std_2ereactor_2estart_24s1697505031x474729009_entry(V self, V *a);
extern Clo g_std_2ereactor_2estart_24s1697505031x474729009_clo;
V g_std_2ereactor_2estart_24s591229604x2094993252(V, V, V, V, V);
V g_std_2ereactor_2estart_24s591229604x2094993252_entry(V self, V *a);
extern Clo g_std_2ereactor_2estart_24s591229604x2094993252_clo;
V g_std_2ereactor_2ereactor_lam1(V self, V *args);
V g_std_2ereactor_2ereactor_lam2(V self, V *args);
V g_std_2ereactor_2ereactor_lam5(V self, V *args);
V g_std_2ereactor_2ereactor_lam4(V self, V *args);
V g_std_2ereactor_2ereactor_lam3(V self, V *args);
V g_std_2ereactor_2ereactor_lam8(V self, V *args);
V g_std_2ereactor_2ereactor_lam7(V self, V *args);
V g_std_2ereactor_2ereactor_lam6(V self, V *args);
V g_std_2ereactor_2ereactor_lam0(V self, V *args); static Clo g_std_2ereactor_2ereactor_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ereactor_2ereactor_lam0, 3, 0};
V g_std_2ereactor_2ereactor_lam9(V self, V *args); static Clo g_std_2ereactor_2ereactor_lam9_clo = {{0x80000000u, K_CLO, 0}, g_std_2ereactor_2ereactor_lam9, 4, 0};

static V g_std_2ereactor_2ereactor_val;
static HEFF_ONCE g_std_2ereactor_2ereactor_st;
static V g_std_2ereactor_2ereactor_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2ereactor_2ereactor_lam0_clo), ((V)&g_std_2ereactor_2ereactor_lam9_clo)});
}
V g_std_2ereactor_2ereactor_get(void) {
  if (HEFF_DONE(g_std_2ereactor_2ereactor_st)) return g_std_2ereactor_2ereactor_val;
  return heff_global(&g_std_2ereactor_2ereactor_val, &g_std_2ereactor_2ereactor_st, g_std_2ereactor_2ereactor_init);
}
V g_std_2ereactor_2ereactor_lam1(V self, V *args) {
  V v_i_244 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_tr(heff_call(v_k_243, 1, (V[]){v_i_244}));
  V f_ = v_g_241;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam2(V self, V *args) {
  V v_b_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tr(heff_call(v_k_247, 1, (V[]){v_b_248}));
  V f_ = v_g_241;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam5(V self, V *args) {
  V v_w_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tr(heff_call(v_k_2414, 1, (V[]){v_w_2415}));
  V f_ = v_g_241;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam4(V self, V *args) {
  V v_v_2413 = args[0];
  V v_k_2414 = args[1];
  V v_use_2412 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_use_2412;
  args[0] = v_v_2413;
  args[1] = heff_clo_n(g_std_2ereactor_2ereactor_lam5, 1, 2, (V[]){v_k_2414, v_g_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2ereactor_2ereactor_lam3(V self, V *args) {
  V v_use_2412 = args[0];
  V v_b_2411 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_b_2411;
  args[0] = heff_clo_n(g_std_2ereactor_2ereactor_lam4, 2, 2, (V[]){v_use_2412, v_g_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam8(V self, V *args) {
  V v_l_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tr(heff_call(v_k_2421, 1, (V[]){v_l_2422}));
  V f_ = v_g_241;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam7(V self, V *args) {
  V v_k_2421 = args[0];
  V v_use_2420 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_use_2420;
  args[0] = heff_clo_n(g_std_2ereactor_2ereactor_lam8, 1, 2, (V[]){v_k_2421, v_g_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam6(V self, V *args) {
  V v_use_2420 = args[0];
  V v_f_2419 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_f_2419;
  args[0] = heff_clo_n(g_std_2ereactor_2ereactor_lam7, 1, 2, (V[]){v_use_2420, v_g_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2ereactor_2ereactor_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Open: {
    V v_k_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Open = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Open, TAG_Open, 1, (V[]){heff_clo_n(g_std_2ereactor_2ereactor_lam1, 1, 2, (V[]){v_k_243, v_g_241})});
  }
  case TAG_Begin: {
    V v_i_246 = heff_field(v_p_242, 0);
    V v_k_247 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Begin = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Begin, TAG_Begin, 2, (V[]){v_i_246, heff_clo_n(g_std_2ereactor_2ereactor_lam2, 1, 2, (V[]){v_k_247, v_g_241})});
  }
  case TAG_End: {
    V v_i_2410 = heff_field(v_p_242, 0);
    V v_b_2411 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24End = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24End, TAG_End, 2, (V[]){v_i_2410, heff_clo_n(g_std_2ereactor_2ereactor_lam3, 1, 2, (V[]){v_b_2411, v_g_241})});
  }
  case TAG_Finish: {
    V v_i_2417 = heff_field(v_p_242, 0);
    V v_w_2418 = heff_field(v_p_242, 1);
    V v_f_2419 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Finish = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24Finish, TAG_Finish, 3, (V[]){v_i_2417, v_w_2418, heff_clo_n(g_std_2ereactor_2ereactor_lam6, 1, 2, (V[]){v_f_2419, v_g_241})});
  }
  case TAG_Close: {
    V v_i_2424 = heff_field(v_p_242, 0);
    V v_x_2425 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Close = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2426 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2425}));
    return heff_tag_at_n(v_ru_24p_242_24Close, TAG_Close, 2, (V[]){v_i_2424, v_t_2426});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2ereactor_2ereactor_lam9(V self, V *args) {
  V v_m_2427 = args[0];
  V v_n_2428 = args[1];
  V v_nt_2429 = args[2];
  V v_p_2430 = args[3];
  heff_drop(v_m_2427);
  heff_drop(v_n_2428);
  heff_drop(v_nt_2429);
  return v_p_2430;
}
V g_std_2ereactor_2estart_24s591229604x2094993252_lam0(V self, V *args); static Clo g_std_2ereactor_2estart_24s591229604x2094993252_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ereactor_2estart_24s591229604x2094993252_lam0, 1, 0};
V g_std_2ereactor_2estart_24s591229604x2094993252_lam4(V self, V *args); static Clo g_std_2ereactor_2estart_24s591229604x2094993252_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2ereactor_2estart_24s591229604x2094993252_lam4, 1, 0};
V g_std_2ereactor_2estart_24s591229604x2094993252_lam3(V self, V *args);
V g_std_2ereactor_2estart_24s591229604x2094993252_lam2(V self, V *args);
V g_std_2ereactor_2estart_24s591229604x2094993252_lam1(V self, V *args);
Clo g_std_2ereactor_2estart_24s591229604x2094993252_clo = {{0x80000000u, K_CLO, 0}, g_std_2ereactor_2estart_24s591229604x2094993252_entry, 5, 0};

V g_std_2ereactor_2estart_24s591229604x2094993252(V v_lit_240, V v_e_241, V v_c_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Begin, 2, (V[]){heff_dup(v_lit_240), ((V)&g_std_2ereactor_2estart_24s591229604x2094993252_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_241), v_t_248, heff_dup(v_hd_243), heff_clo_n(g_std_2ereactor_2estart_24s591229604x2094993252_lam1, 1, 5, (V[]){v_c_242, v_hd_243, v_lit_240, v_e_241, v_k_244})));
}
V g_std_2ereactor_2estart_24s591229604x2094993252_entry(V self, V *a) {
  (void)self;
  return g_std_2ereactor_2estart_24s591229604x2094993252(a[0], a[1], a[2], a[3], a[4]);
}
V g_std_2ereactor_2estart_24s591229604x2094993252_lam0(V self, V *args) {
  V v_b_245 = args[0];
  return v_b_245;
}
V g_std_2ereactor_2estart_24s591229604x2094993252_lam4(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_std_2ereactor_2estart_24s591229604x2094993252_lam3(V self, V *args) {
  V v_use_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_use_2411;
  heff_room[0] = v_x_2410;
  heff_room[1] = ((V)&g_std_2ereactor_2estart_24s591229604x2094993252_lam4_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2ereactor_2estart_24s591229604x2094993252_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_End, 2, (V[]){v_lit_240, heff_clo_n(g_std_2ereactor_2estart_24s591229604x2094993252_lam3, 1, 1, (V[]){v_x_2410})})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s310169282x2049378029(v_e_241, v_t_2415, v_hd_243, v_k_244));
}
V g_std_2ereactor_2estart_24s591229604x2094993252_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_c_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_e_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_dup(v_x_249) == NTAG(TAG_True))) {
    heff_drop(v_x_249);
    V f_ = v_c_242;
    heff_room[0] = heff_dup(v_hd_243);
    heff_room[1] = heff_clo_n(g_std_2ereactor_2estart_24s591229604x2094993252_lam2, 1, 4, (V[]){v_lit_240, v_e_241, v_hd_243, v_k_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_249);
    heff_drop(v_c_242);
    heff_drop(v_hd_243);
    heff_drop(v_lit_240);
    heff_drop(v_e_241);
    V f_ = v_k_244;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_std_2ereactor_2estart_24s1697505031x474729009_lam0(V self, V *args); static Clo g_std_2ereactor_2estart_24s1697505031x474729009_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2ereactor_2estart_24s1697505031x474729009_lam0, 1, 0};
V g_std_2ereactor_2estart_24s1697505031x474729009_lam4(V self, V *args); static Clo g_std_2ereactor_2estart_24s1697505031x474729009_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2ereactor_2estart_24s1697505031x474729009_lam4, 1, 0};
V g_std_2ereactor_2estart_24s1697505031x474729009_lam3(V self, V *args);
V g_std_2ereactor_2estart_24s1697505031x474729009_lam2(V self, V *args);
V g_std_2ereactor_2estart_24s1697505031x474729009_lam1(V self, V *args);
Clo g_std_2ereactor_2estart_24s1697505031x474729009_clo = {{0x80000000u, K_CLO, 0}, g_std_2ereactor_2estart_24s1697505031x474729009_entry, 5, 0};

V g_std_2ereactor_2estart_24s1697505031x474729009(V v_e_240, V v_x1_241, V v_c_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_MkGroup: {
    V v_i_245 = heff_field(v_x1_241, 0);
    V v_ru_24x1_241_24MkGroup = heff_take_reuse_n(v_x1_241, 1ULL, 1);
    V v_t_247 = heff_tag_at_n(v_ru_24x1_241_24MkGroup, TAG_InR, 1, (V[]){heff_tag_n(TAG_Begin, 2, (V[]){heff_dup(v_i_245), ((V)&g_std_2ereactor_2estart_24s1697505031x474729009_lam0_clo)})});
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_249, heff_dup(v_p_243), heff_clo_n(g_std_2ereactor_2estart_24s1697505031x474729009_lam1, 1, 5, (V[]){v_c_242, v_p_243, v_i_245, v_e_240, v_p_244})));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_std_2ereactor_2estart_24s1697505031x474729009_entry(V self, V *a) {
  (void)self;
  return g_std_2ereactor_2estart_24s1697505031x474729009(a[0], a[1], a[2], a[3], a[4]);
}
V g_std_2ereactor_2estart_24s1697505031x474729009_lam0(V self, V *args) {
  V v_b_246 = args[0];
  return v_b_246;
}
V g_std_2ereactor_2estart_24s1697505031x474729009_lam4(V self, V *args) {
  V v_r_2413 = args[0];
  return v_r_2413;
}
V g_std_2ereactor_2estart_24s1697505031x474729009_lam3(V self, V *args) {
  V v_use_2412 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_use_2412;
  heff_room[0] = v_x_2411;
  heff_room[1] = ((V)&g_std_2ereactor_2estart_24s1697505031x474729009_lam4_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2ereactor_2estart_24s1697505031x474729009_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_i_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_End, 2, (V[]){v_i_245, heff_clo_n(g_std_2ereactor_2estart_24s1697505031x474729009_lam3, 1, 1, (V[]){v_x_2411})})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2416, v_p_243, v_p_244));
}
V g_std_2ereactor_2estart_24s1697505031x474729009_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_i_245 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
    heff_drop(v_x_2410);
    V f_ = v_c_242;
    heff_room[0] = heff_dup(v_p_243);
    heff_room[1] = heff_clo_n(g_std_2ereactor_2estart_24s1697505031x474729009_lam2, 1, 4, (V[]){v_i_245, v_e_240, v_p_243, v_p_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2410);
    heff_drop(v_c_242);
    heff_drop(v_p_243);
    heff_drop(v_i_245);
    heff_drop(v_e_240);
    V f_ = v_p_244;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}