// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_NotRun 12703
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_WriteErr 37283
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_message 1186782793
#define LBL_name 9869138
#define LBL_path 9928940
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_clo;
V g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s1063601026x1972672043(V, V);
V g_list_2ekeepIf_24s1063601026x1972672043_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1063601026x1972672043_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str7, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str10, 27, ": `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str12, 27, ": `zig cc` could not build ");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0(V v_lit_240, V v_x_241, V v_x_242, V v_out_243, V v_x_244, V v_hd_245, V v_next_246, V v_k_247, V v_who_248, V v_failed_249, V v_x_2410) {
top: ;
  V v_s_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    v_s_2413 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str0);
    break;
  }
  case TAG_Right: {
    V v_y_2412 = heff_field(v_x_2410, 0);
    v_s_2413 = heff_dup(v_y_2412);
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2414 = ({ V a_0 = v_s_2413; V b_1 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str1); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str2), v_s_2413, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_2413); heff_drop(b_1); r_; });
  V v_t_2415 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str3); V a_1 = v_t_2414; V r_ = (g_list_2ekeepIf_24s930188071x496633547(b_0, a_1)); heff_drop(b_0); r_; });
  return (g_heff_2ebuild_2ecommands_2ezigLinked_24s31265041x1544877209(v_lit_240, heff_dup(v_x_241), v_t_2415, v_x_242, heff_dup(v_out_243), v_x_244, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_lam0, 1, 7, (V[]){v_x_241, v_hd_245, v_next_246, v_k_247, v_who_248, v_out_243, v_failed_249})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a10 = a[10]; V r = g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a10); heff_drop(a10); return r;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_lam3(V self, V *args) {
  V v_x_2451 = args[0];
  V v_who_248 = heff_env(self)[0];
  V v_out_243 = heff_env(self)[1];
  V v_failed_249 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_drop(v_x_2451);
  heff_clo_take(self, 5);
  V v_t_2452 = heff_strAppend(heff_strAppend(v_who_248, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str12)), v_out_243);
  V f_ = v_failed_249;
  heff_room[0] = v_t_2452;
  heff_room[1] = v_hd_245;
  heff_room[2] = v_k_247;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_lam2(V self, V *args) {
  V v_x_2443 = args[0];
  V v_who_248 = heff_env(self)[0];
  V v_out_243 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_failed_249 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_drop(v_x_2443);
  V v_t_2444 = heff_strAppend(heff_strAppend(heff_dup(v_who_248), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str10)), heff_dup(v_out_243));
  V v_t_2445 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2444, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str11)), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  heff_clo_take(self, 5);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_lam3, 1, 5, (V[]){v_who_248, v_out_243, v_failed_249, v_hd_245, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_ended_2417 = heff_env(self)[0];
  V v_next_246 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_err_2418 = heff_env(self)[4];
  V v_who_248 = heff_env(self)[5];
  V v_out_243 = heff_env(self)[6];
  V v_failed_249 = heff_env(self)[7];
  heff_drop(v_x_2421);
  V v_t_2422 = heff_dup(v_ended_2417);
  V v_t_2426;
  switch (heff_tag_of(v_t_2422)) {
  case TAG_Exited: {
    V v_n_2423 = heff_field(v_t_2422, 0);
    heff_take_n(v_t_2422, 1ULL, 1);
    v_t_2426 = heff_bool(heff_intEq_c_lent(v_n_2423, MK_INT(0LL), 2));
    heff_drop(v_n_2423);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2422, 0ULL, 1);
    v_t_2426 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2426 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    heff_take_n(v_t_2422, 0ULL, 1);
    v_t_2426 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2422);
  }
  if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
    heff_clo_take(self, 8);
    heff_drop(v_ended_2417);
    heff_drop(v_err_2418);
    heff_drop(v_who_248);
    heff_drop(v_out_243);
    heff_drop(v_failed_249);
    heff_drop(v_t_2426);
    V f_ = v_next_246;
    heff_room[0] = v_hd_245;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_clo_take(self, 8);
    heff_drop(v_next_246);
    heff_drop(v_t_2426);
    V v_t_2427 = v_ended_2417;
    V v_t_2436;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Exited: {
      heff_take_n(v_t_2427, 0ULL, 1);
      v_t_2436 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str4);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_t_2427, 0ULL, 1);
      v_t_2436 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str5);
      break;
    }
    case TAG_TimedOut: {
      v_t_2436 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str6);
      break;
    }
    case TAG_NotRun: {
      V v_err_2430 = heff_field(v_t_2427, 0);
      heff_take_n(v_t_2427, 1ULL, 1);
      V v_path_2431 = heff_take_field(v_err_2430, 3);
      V v_name_2432 = heff_take_field(v_err_2430, 1);
      V v_message_2433 = heff_get_n(v_err_2430, 2, 4);
      V v_t_2434 = heff_strAppend(heff_strAppend(v_path_2431, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str7)), v_name_2432);
      V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str8)), v_message_2433);
      v_t_2436 = heff_strAppend(v_t_2435, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_str9));
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    V v_t_2437 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2436, v_err_2418), NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_lam2, 1, 5, (V[]){v_who_248, v_out_243, v_hd_245, v_failed_249, v_k_247})));
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_lam0(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_241 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_next_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_who_248 = heff_env(self)[4];
  V v_out_243 = heff_env(self)[5];
  V v_failed_249 = heff_env(self)[6];
  V v_ended_2417 = heff_take_field(v_x_2416, 0);
  V v_err_2418 = heff_get_n(v_x_2416, 2, 3);
  heff_clo_take(self, 7);
  V v_t_2419 = heff_tag_n(TAG_End, 2, (V[]){v_x_241, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0_lam1, 1, 8, (V[]){v_ended_2417, v_next_246, v_hd_245, v_k_247, v_err_2418, v_who_248, v_out_243, v_failed_249})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str2, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str3, 3, "-O0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str4, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str5, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str6, 11, "ReleaseSafe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str7, 3, "-Os");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str8, 12, "ReleaseSmall");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str9, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str10, 3, "-O3");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str11, 11, "ReleaseFast");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str12, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str13, 9, "heff.link");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1(V v_st_240, V v_dir_241, V v_p_242, V v_hd_243, V v_lit_244, V v_out_245, V v_next_246, V v_k_247, V v_who_248, V v_failed_249, V v_x_2410) {
top: ;
  V v_x_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    heff_take_n(v_x_2410, 0ULL, 1);
    v_x_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2412 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Right = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    v_x_2413 = heff_tag_at_n(v_ru_24x_2410_24Right, TAG_Just, 1, (V[]){v_y_2412});
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2415;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_dup(heff_field(v_x_2413, 0));
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2416 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str0); V a_1 = v_t_2415; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2421 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam0, 1, 2, (V[]){heff_dup(v_st_240), heff_dup(v_dir_241)}), v_t_2416));
  V v_t_2423;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    v_t_2423 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2422 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    v_t_2423 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2424 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str1); V a_1 = v_t_2423; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2429 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam1, 1, 2, (V[]){heff_dup(v_st_240), heff_dup(v_dir_241)}), v_t_2424));
  V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2421));
  V v_t_2431 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2429));
  V v_total_2432 = heff_intAdd(heff_intAdd(v_t_2430, v_t_2431), MK_INT(1LL));
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_242, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str2), v_total_2432, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam2_clo)})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s535099379x685970669(v_t_2435, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam3, 1, 11, (V[]){v_lit_244, v_x_2429, v_hd_243, v_st_240, v_dir_241, v_x_2421, v_out_245, v_next_246, v_k_247, v_who_248, v_failed_249})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam0(V self, V *args) {
  V v_n_2417 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_dir_241));
  V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_n_2417));
  V v_t_2420 = (g_std_2epath_2ejoin(v_t_2418, v_t_2419));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2420); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam1(V self, V *args) {
  V v_n_2425 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_dir_241));
  V v_t_2427 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_n_2425));
  V v_t_2428 = (g_std_2epath_2ejoin(v_t_2426, v_t_2427));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2428); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam2(V self, V *args) {
  V v_t_2433 = args[0];
  return v_t_2433;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam5(V self, V *args) {
  V v_r_2445 = args[0];
  return v_r_2445;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam6(V self, V *args) {
  V v_x_2452 = args[0];
  V v_lit_244 = heff_env(self)[0];
  V v_x_2436 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  V v_out_245 = heff_env(self)[3];
  V v_x_2438 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  V v_next_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  V v_who_248 = heff_env(self)[8];
  V v_failed_249 = heff_env(self)[9];
  switch (heff_tag_of(v_x_2452)) {
  case TAG_Left: {
    V v_x_2453 = heff_field(v_x_2452, 0);
    V v_ru_24x_2452_24Left = heff_take_reuse_n(v_x_2452, 1ULL, 1);
    heff_clo_take(self, 10);
    return ({ V a_0 = v_lit_244; V a_1 = v_x_2436; V a_2 = v_x_2421; V a_3 = v_out_245; V a_4 = v_x_2438; V a_5 = v_hd_243; V a_6 = v_next_246; V a_7 = v_k_247; V a_8 = v_who_248; V a_9 = v_failed_249; V b_10 = heff_tag_re_n(v_ru_24x_2452_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2453}); V r_ = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
  }
  case TAG_Right: {
    V v_y_2454 = heff_field(v_x_2452, 0);
    V v_ru_24x_2452_24Right = heff_take_reuse_n(v_x_2452, 1ULL, 1);
    switch (heff_tag_of(v_y_2454)) {
    case TAG_Left: {
      V v_err_2455 = heff_field(v_y_2454, 0);
      V v_ru_24y_2454_24Left = heff_take_reuse_n(v_y_2454, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2452_24Right, 1);
      heff_clo_take(self, 10);
      return ({ V a_0 = v_lit_244; V a_1 = v_x_2436; V a_2 = v_x_2421; V a_3 = v_out_245; V a_4 = v_x_2438; V a_5 = v_hd_243; V a_6 = v_next_246; V a_7 = v_k_247; V a_8 = v_who_248; V a_9 = v_failed_249; V b_10 = heff_tag_re_n(v_ru_24y_2454_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2455}); V r_ = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
    }
    case TAG_Right: {
      V v_x_2456 = heff_field(v_y_2454, 0);
      heff_take_n(v_y_2454, 1ULL, 1);
      heff_clo_take(self, 10);
      return ({ V a_0 = v_lit_244; V a_1 = v_x_2436; V a_2 = v_x_2421; V a_3 = v_out_245; V a_4 = v_x_2438; V a_5 = v_hd_243; V a_6 = v_next_246; V a_7 = v_k_247; V a_8 = v_who_248; V a_9 = v_failed_249; V b_10 = heff_tag_at_n(v_ru_24x_2452_24Right, TAG_Right, 1, (V[]){v_x_2456}); V r_ = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
    }
    default: return heff_nomatch(v_y_2454);
    }
  }
  default: return heff_nomatch(v_x_2452);
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam4(V self, V *args) {
  V v_x_2438 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_lit_244 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  V v_x_2421 = heff_env(self)[5];
  V v_out_245 = heff_env(self)[6];
  V v_next_246 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  V v_who_248 = heff_env(self)[9];
  V v_failed_249 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2439 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_dir_241));
  V v_t_2440 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str13)));
  V v_t_2441 = (g_std_2epath_2ejoin(v_t_2439, v_t_2440));
  V v_s_2442 = ({ V a_0 = v_st_240; V a_1 = v_t_2441; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2441); r_; });
  V v_path_2443 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2442));
  V v_t_2444 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2443; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2443); r_; });
  V v_a_2446 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2444, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam5_clo)});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2451, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam6, 1, 10, (V[]){v_lit_244, v_x_2436, v_x_2421, v_out_245, v_x_2438, v_hd_243, v_next_246, v_k_247, v_who_248, v_failed_249})));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam3(V self, V *args) {
  V v_x_2436 = args[0];
  V v_lit_244 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_dir_241 = heff_env(self)[4];
  V v_x_2421 = heff_env(self)[5];
  V v_out_245 = heff_env(self)[6];
  V v_next_246 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  V v_who_248 = heff_env(self)[9];
  V v_failed_249 = heff_env(self)[10];
  V v_t_2437;
  if (heff_strEq_c_lent(v_lit_244, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str3), 2)) {
    v_t_2437 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str4);
  } else {
    if (heff_strEq_c_lent(v_lit_244, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str5), 2)) {
      v_t_2437 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str6);
    } else {
      if (heff_strEq_c_lent(v_lit_244, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str7), 2)) {
        v_t_2437 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str8);
      } else {
        if ((heff_strEq_c_lent(v_lit_244, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str9), 2) || heff_strEq_c_lent(v_lit_244, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str10), 2))) {
          v_t_2437 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str11);
        } else {
          v_t_2437 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_str12);
        }
      }
    }
  }
  heff_clo_take(self, 11);
  return (g_heff_2ebuild_2ecommands_2ezigObjects_24s212728388x203540162(heff_dup(v_x_2436), v_t_2437, v_x_2429, NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1444956027x113820092_2ek_24l1_lam4, 1, 11, (V[]){v_st_240, v_dir_241, v_hd_243, v_lit_244, v_x_2436, v_x_2421, v_out_245, v_next_246, v_k_247, v_who_248, v_failed_249})));
}