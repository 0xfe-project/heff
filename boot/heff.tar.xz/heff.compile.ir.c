// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_m 327
#define LBL_n 328
#define LBL_xs 10594
static uint32_t shape_m__n__xs[] = {LBL_m, LBL_n, LBL_xs};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871(V, V, V);
V g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_clo;
V g_heff_2ecompile_2eir_2efreshBindOne(V, V);
V g_heff_2ecompile_2eir_2efreshBindOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshBindOne_clo;
V g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295(V, V, V);
V g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_clo;
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
V g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226(V, V, V);
V g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eir_2espine(V);
V g_heff_2ecompile_2eir_2espine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2espine_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s690313412x1307839513(V, V);
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690313412x1307839513_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1044393341x1523302351(V);
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_clo;
V g_list_2emap_24s584454411x1006678865(V);
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
Clo g_heff_2ecompile_2eir_2ebaseGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ebaseGo_entry, 2, 0};

V g_heff_2ecompile_2eir_2ebaseGo(V v_x_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_x_240)), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return v_x_240;
  } else {
    if (heff_intEq_c(heff_strCharCode(heff_dup(v_x_240), heff_dup(v_i_241)), MK_INT(36LL))) {
      return heff_strSlice(v_x_240, MK_INT(0LL), v_i_241);
    } else {
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_x_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ebaseGo(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2eappendI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eappendI_entry, 2, 0};

V g_heff_2ecompile_2eir_2eappendI(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2ecompile_2eir_2eappendI(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eappendI(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2enubI_lam0(V self, V *args);
Clo g_heff_2ecompile_2eir_2enubI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2enubI_entry, 1, 0};

V g_heff_2ecompile_2eir_2enubI(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eir_2enubI_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2ecompile_2eir_2enubI(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2enubI(a[0]);
}
V g_heff_2ecompile_2eir_2enubI_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_strEq_c(v_y_243, v_x_241)) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
HEFF_STRA(g_heff_2ecompile_2eir_2efreshBindOne_str0, 1, (36));
Clo g_heff_2ecompile_2eir_2efreshBindOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efreshBindOne_entry, 2, 0};

V g_heff_2ecompile_2eir_2efreshBindOne(V v_acc_240, V v_x_241) {
top: ;
  V v_base_242 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_241), MK_INT(0LL)));
  V v_n_243 = heff_take_field(v_acc_240, 1);
  V v_x_27_244 = heff_strAppend(v_base_242, heff_strAppend(((V)&g_heff_2ecompile_2eir_2efreshBindOne_str0), heff_intShow(heff_dup(v_n_243))));
  V v_t_245 = (g_map_2einsert_24s1341440536x470972936(v_x_241, heff_dup(v_x_27_244), heff_take_field(v_acc_240, 0)));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_27_244, heff_get_n(v_acc_240, 2, 3)});
  return heff_rec_n(3, shape_m__n__xs, (V[]){v_t_245, heff_intAdd(v_n_243, MK_INT(1LL)), v_t_246});
}
V g_heff_2ecompile_2eir_2efreshBindOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2efreshBindOne(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_entry, 3, 0};

V g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(v_m_240), v_n_241, v_e_243));
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_e_27_246 = heff_field(v_t_245, 0);
      V v_n1_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      V v_x2_248 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226(v_m_240, v_n1_247, v_rest_244));
      switch (heff_tag_of(v_x2_248)) {
      case TAG_MkPair: {
        V v_es_249 = heff_field(v_x2_248, 0);
        V v_n_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_e_27_246, v_es_249}), v_n_2410});
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_entry, 3, 0};

V g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_l_245 = heff_field(v_x41_243, 0);
      V v_e_246 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24MkPair = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(v_m_240), v_n_241, v_e_246));
      switch (heff_tag_of(v_t_247)) {
      case TAG_MkPair: {
        V v_e_27_248 = heff_field(v_t_247, 0);
        V v_n1_249 = heff_field(v_t_247, 1);
        heff_take_n(v_t_247, 3ULL, 2);
        V v_x2_2410 = (g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295(v_m_240, v_n1_249, v_rest_244));
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_MkPair: {
          V v_fs_2411 = heff_field(v_x2_2410, 0);
          V v_n_2412 = heff_field(v_x2_2410, 1);
          heff_take_n(v_x2_2410, 3ULL, 2);
          V v_t_2413 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_245, v_e_27_248}), v_fs_2411});
          return heff_tag_at_n(v_ru_24x41_243_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_n_2412});
        }
        default: return heff_nomatch(v_x2_2410);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_entry, 3, 0};

V g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkArm: {
      V v_tag_245 = heff_field(v_x41_243, 0);
      V v_vars_246 = heff_field(v_x41_243, 1);
      V v_body_247 = heff_field(v_x41_243, 2);
      V v_ru_24x41_243_24MkArm = heff_take_reuse_n(v_x41_243, 7ULL, 3);
      V v_t_248 = heff_rec_n(3, shape_m__n__xs, (V[]){heff_dup(v_m_240), v_n_241, NTAG(TAG_Nil)});
      V v_v_249 = ({ V a_0 = v_t_248; V a_1 = v_vars_246; V r_ = (g_list_2efoldl_24s690313412x1307839513(a_0, a_1)); heff_drop(v_vars_246); r_; });
      V v_t_2410 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_take_field(v_v_249, 0), heff_take_field(v_v_249, 1), v_body_247));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_MkPair: {
        V v_b_27_2411 = heff_field(v_t_2410, 0);
        V v_n1_2412 = heff_field(v_t_2410, 1);
        heff_take_n(v_t_2410, 3ULL, 2);
        V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_v_249, 2, 3)));
        V v_a_2414 = heff_tag_at_n(v_ru_24x41_243_24MkArm, TAG_MkArm, 3, (V[]){v_tag_245, v_t_2413, v_b_27_2411});
        V v_x2_2415 = (g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871(v_m_240, v_n1_2412, v_rest_244));
        switch (heff_tag_of(v_x2_2415)) {
        case TAG_MkPair: {
          V v_as_2416 = heff_field(v_x2_2415, 0);
          V v_n_2417 = heff_field(v_x2_2415, 1);
          heff_take_n(v_x2_2415, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_a_2414, v_as_2416}), v_n_2417});
        }
        default: return heff_nomatch(v_x2_2415);
        }
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_str0, 1, (36));
Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry, 3, 0};

V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V v_m_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EVar = heff_take_reuse_n(v_e_242, 1ULL, 1);
    V v_t_244 = ({ V a_0 = heff_dup(v_x_243); V a_1 = v_m_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_240); r_; });
    V v_t_246;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      v_t_246 = v_x_243;
      break;
    }
    case TAG_Just: {
      V v_y_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      heff_drop(v_x_243);
      v_t_246 = v_y_245;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24EVar, TAG_EVar, 1, (V[]){v_t_246}), v_n_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_m_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_e_242, 0);
    V v_b_249 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2410 = heff_rec_n(3, shape_m__n__xs, (V[]){v_m_240, v_n_241, NTAG(TAG_Nil)});
    V v_v_2411 = ({ V a_0 = v_t_2410; V a_1 = v_xs_248; V r_ = (g_list_2efoldl_24s690313412x1307839513(a_0, a_1)); heff_drop(v_xs_248); r_; });
    V v_t_2412 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_take_field(v_v_2411, 0), heff_take_field(v_v_2411, 1), v_b_249));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkPair: {
      V v_b_27_2413 = heff_field(v_t_2412, 0);
      V v_n_27_2414 = heff_field(v_t_2412, 1);
      heff_take_n(v_t_2412, 3ULL, 2);
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_v_2411, 2, 3)));
      return heff_tag_at_n(v_ru_24e_242_24ELam, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2415, v_b_27_2413}), v_n_27_2414});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_EApp: {
    V v_f_2416 = heff_field(v_e_242, 0);
    V v_as_2417 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2418 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(v_m_240), v_n_241, v_f_2416));
    switch (heff_tag_of(v_t_2418)) {
    case TAG_MkPair: {
      V v_f_27_2419 = heff_field(v_t_2418, 0);
      V v_n1_2420 = heff_field(v_t_2418, 1);
      heff_take_n(v_t_2418, 3ULL, 2);
      V v_t_2421 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226(v_m_240, v_n1_2420, v_as_2417));
      switch (heff_tag_of(v_t_2421)) {
      case TAG_MkPair: {
        V v_as_27_2422 = heff_field(v_t_2421, 0);
        V v_n2_2423 = heff_field(v_t_2421, 1);
        heff_take_n(v_t_2421, 3ULL, 2);
        return heff_tag_at_n(v_ru_24e_242_24EApp, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_27_2419, v_as_27_2422}), v_n2_2423});
      }
      default: return heff_nomatch(v_t_2421);
      }
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  case TAG_ELet: {
    V v_x_2424 = heff_field(v_e_242, 0);
    V v_a_2425 = heff_field(v_e_242, 1);
    V v_b_2426 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2427 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(v_m_240), v_n_241, v_a_2425));
    switch (heff_tag_of(v_t_2427)) {
    case TAG_MkPair: {
      V v_a_27_2428 = heff_field(v_t_2427, 0);
      V v_n1_2429 = heff_field(v_t_2427, 1);
      V v_ru_24t_2427_24MkPair = heff_take_reuse_n(v_t_2427, 3ULL, 2);
      V v_base_2430 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_2424), MK_INT(0LL)));
      V v_x_27_2431 = heff_strAppend(v_base_2430, heff_strAppend(((V)&g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_str0), heff_intShow(heff_dup(v_n1_2429))));
      V v_m_2432 = (g_map_2einsert_24s1341440536x470972936(v_x_2424, heff_dup(v_x_27_2431), v_m_240));
      V v_t_2433 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(v_m_2432, heff_intAdd(v_n1_2429, MK_INT(1LL)), v_b_2426));
      switch (heff_tag_of(v_t_2433)) {
      case TAG_MkPair: {
        V v_b_27_2434 = heff_field(v_t_2433, 0);
        V v_n3_2435 = heff_field(v_t_2433, 1);
        heff_take_n(v_t_2433, 3ULL, 2);
        return heff_tag_at_n(v_ru_24t_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_27_2431, v_a_27_2428, v_b_27_2434}), v_n3_2435});
      }
      default: return heff_nomatch(v_t_2433);
      }
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  case TAG_ERecord: {
    V v_fs_2436 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 1ULL, 1);
    V v_t_2437 = (g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295(v_m_240, v_n_241, v_fs_2436));
    switch (heff_tag_of(v_t_2437)) {
    case TAG_MkPair: {
      V v_fs_27_2438 = heff_field(v_t_2437, 0);
      V v_n1_2439 = heff_field(v_t_2437, 1);
      V v_ru_24t_2437_24MkPair = heff_take_reuse_n(v_t_2437, 3ULL, 2);
      return heff_tag_at_n(v_ru_24t_2437_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24ERecord, TAG_ERecord, 1, (V[]){v_fs_27_2438}), v_n1_2439});
    }
    default: return heff_nomatch(v_t_2437);
    }
  }
  case TAG_EProj: {
    V v_e2_2440 = heff_field(v_e_242, 0);
    V v_l_2441 = heff_field(v_e_242, 1);
    V v_sh_2442 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2443 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(v_m_240, v_n_241, v_e2_2440));
    switch (heff_tag_of(v_t_2443)) {
    case TAG_MkPair: {
      V v_e_27_2444 = heff_field(v_t_2443, 0);
      V v_n1_2445 = heff_field(v_t_2443, 1);
      V v_ru_24t_2443_24MkPair = heff_take_reuse_n(v_t_2443, 3ULL, 2);
      return heff_tag_at_n(v_ru_24t_2443_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 3, (V[]){v_e_27_2444, v_l_2441, v_sh_2442}), v_n1_2445});
    }
    default: return heff_nomatch(v_t_2443);
    }
  }
  case TAG_ETag: {
    V v_t_2446 = heff_field(v_e_242, 0);
    V v_as_2447 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2448 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226(v_m_240, v_n_241, v_as_2447));
    switch (heff_tag_of(v_t_2448)) {
    case TAG_MkPair: {
      V v_as_27_2449 = heff_field(v_t_2448, 0);
      V v_n1_2450 = heff_field(v_t_2448, 1);
      heff_take_n(v_t_2448, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_242_24ETag, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 2, (V[]){v_t_2446, v_as_27_2449}), v_n1_2450});
    }
    default: return heff_nomatch(v_t_2448);
    }
  }
  case TAG_EMatch: {
    V v_s_2451 = heff_field(v_e_242, 0);
    V v_arms_2452 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2453 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(v_m_240), v_n_241, v_s_2451));
    switch (heff_tag_of(v_t_2453)) {
    case TAG_MkPair: {
      V v_s_27_2454 = heff_field(v_t_2453, 0);
      V v_n1_2455 = heff_field(v_t_2453, 1);
      heff_take_n(v_t_2453, 3ULL, 2);
      V v_t_2456 = (g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871(v_m_240, v_n1_2455, v_arms_2452));
      switch (heff_tag_of(v_t_2456)) {
      case TAG_MkPair: {
        V v_arms_27_2457 = heff_field(v_t_2456, 0);
        V v_n2_2458 = heff_field(v_t_2456, 1);
        heff_take_n(v_t_2456, 3ULL, 2);
        return heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_27_2454, v_arms_27_2457}), v_n2_2458});
      }
      default: return heff_nomatch(v_t_2456);
      }
    }
    default: return heff_nomatch(v_t_2453);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_m_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  case TAG_EPrimCall: {
    V v_p_2460 = heff_field(v_e_242, 0);
    V v_as_2461 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2462 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226(v_m_240, v_n_241, v_as_2461));
    switch (heff_tag_of(v_t_2462)) {
    case TAG_MkPair: {
      V v_as_27_2463 = heff_field(v_t_2462, 0);
      V v_n1_2464 = heff_field(v_t_2462, 1);
      heff_take_n(v_t_2462, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2460, v_as_27_2463}), v_n1_2464});
    }
    default: return heff_nomatch(v_t_2462);
    }
  }
  case TAG_ECall: {
    V v_g_2465 = heff_field(v_e_242, 0);
    V v_as_2466 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2467 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226(v_m_240, v_n_241, v_as_2466));
    switch (heff_tag_of(v_t_2467)) {
    case TAG_MkPair: {
      V v_as_27_2468 = heff_field(v_t_2467, 0);
      V v_n1_2469 = heff_field(v_t_2467, 1);
      heff_take_n(v_t_2467, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_242_24ECall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2465, v_as_27_2468}), v_n1_2469});
    }
    default: return heff_nomatch(v_t_2467);
    }
  }
  case TAG_EInt: {
    heff_drop(v_m_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  case TAG_EFloat: {
    heff_drop(v_m_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  case TAG_EStr: {
    heff_drop(v_m_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  case TAG_EFixed: {
    heff_drop(v_m_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_m_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_m_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  case TAG_EFix: {
    heff_drop(v_m_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_241});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eir_2esubstGo_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2esubstGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esubstGo_entry, 2, 0};

V g_heff_2ecompile_2eir_2esubstGo(V v_m_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EVar = heff_take_reuse_n(v_e_241, 1ULL, 1);
    V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_242), v_m_240));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      return heff_tag_at_n(v_ru_24e_241_24EVar, TAG_EVar, 1, (V[]){v_x_242});
    }
    case TAG_Just: {
      V v_e2_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24e_241_24EVar, 1);
      return v_e2_244;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_xs_246, (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_b_247))});
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_e_241, 0);
    V v_as_249 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2410 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_f_248));
    return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2410, (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), v_as_249))});
  }
  case TAG_ELet: {
    V v_x_2412 = heff_field(v_e_241, 0);
    V v_a_2413 = heff_field(v_e_241, 1);
    V v_b_2414 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2415 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_a_2413));
    return heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2412, v_t_2415, (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_b_2414))});
  }
  case TAG_ERecord: {
    V v_fs_2416 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24ERecord = heff_take_reuse_n(v_e_241, 1ULL, 1);
    return heff_tag_at_n(v_ru_24e_241_24ERecord, TAG_ERecord, 1, (V[]){(g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam1, 1, 1, (V[]){heff_dup(v_m_240)}), v_fs_2416))});
  }
  case TAG_EProj: {
    V v_e2_2420 = heff_field(v_e_241, 0);
    V v_l_2421 = heff_field(v_e_241, 1);
    V v_sh_2422 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24EProj = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2423 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_e2_2420));
    return heff_tag_at_n(v_ru_24e_241_24EProj, TAG_EProj, 3, (V[]){v_t_2423, v_l_2421, v_sh_2422});
  }
  case TAG_ETag: {
    V v_t_2424 = heff_field(v_e_241, 0);
    V v_as_2425 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ETag = heff_take_reuse_n(v_e_241, 3ULL, 2);
    return heff_tag_at_n(v_ru_24e_241_24ETag, TAG_ETag, 2, (V[]){v_t_2424, (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam2, 1, 1, (V[]){heff_dup(v_m_240)}), v_as_2425))});
  }
  case TAG_EMatch: {
    V v_s_2427 = heff_field(v_e_241, 0);
    V v_arms_2428 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2429 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_s_2427));
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_t_2429, (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam3, 1, 1, (V[]){heff_dup(v_m_240)}), v_arms_2428))});
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    V v_p_2435 = heff_field(v_e_241, 0);
    V v_as_2436 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EPrimCall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    return heff_tag_at_n(v_ru_24e_241_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2435, (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam4, 1, 1, (V[]){heff_dup(v_m_240)}), v_as_2436))});
  }
  case TAG_ECall: {
    V v_g_2438 = heff_field(v_e_241, 0);
    V v_as_2439 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    return heff_tag_at_n(v_ru_24e_241_24ECall, TAG_ECall, 2, (V[]){v_g_2438, (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam5, 1, 1, (V[]){heff_dup(v_m_240)}), v_as_2439))});
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EFixed: {
    return v_e_241;
  }
  case TAG_EFloat32: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eir_2esubstGo(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecompile_2eir_2esubstGo_lam0(V self, V *args) {
  V v_a_2411 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2411; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam1(V self, V *args) {
  V v_p_2417 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_l_2418 = heff_field(v_p_2417, 0);
    V v_e2_2419 = heff_field(v_p_2417, 1);
    V v_ru_24p_2417_24MkPair = heff_take_reuse_n(v_p_2417, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2417_24MkPair, TAG_MkPair, 2, (V[]){v_l_2418, ({ V a_0 = v_m_240; V a_1 = v_e2_2419; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; })});
  }
  default: return heff_nomatch(v_p_2417);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_lam2(V self, V *args) {
  V v_a_2426 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2426; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam3(V self, V *args) {
  V v_a_2430 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2430)) {
  case TAG_MkArm: {
    V v_t_2431 = heff_field(v_a_2430, 0);
    V v_vs_2432 = heff_field(v_a_2430, 1);
    V v_b_2433 = heff_field(v_a_2430, 2);
    V v_ru_24a_2430_24MkArm = heff_take_reuse_n(v_a_2430, 7ULL, 3);
    return heff_tag_at_n(v_ru_24a_2430_24MkArm, TAG_MkArm, 3, (V[]){v_t_2431, v_vs_2432, ({ V a_0 = v_m_240; V a_1 = v_b_2433; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; })});
  }
  default: return heff_nomatch(v_a_2430);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_lam4(V self, V *args) {
  V v_a_2437 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2437; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam5(V self, V *args) {
  V v_a_2440 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2440; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
Clo g_heff_2ecompile_2eir_2epushArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushArms_entry, 2, 0};

V g_heff_2ecompile_2eir_2epushArms(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_as_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_a_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_a_242, 2);
      heff_take_n(v_a_242, 4ULL, 3);
      v_t_247 = v_b_246;
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, (g_heff_2ecompile_2eir_2epushArms(v_as_243, v_rest_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushArms(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2epushFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushFields_entry, 2, 0};

V g_heff_2ecompile_2eir_2epushFields(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_p_242)) {
    case TAG_MkPair: {
      V v_e2_245 = heff_field(v_p_242, 1);
      heff_take_n(v_p_242, 2ULL, 2);
      v_t_246 = v_e2_245;
      break;
    }
    default: heff_nomatch(v_p_242);
    }
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_heff_2ecompile_2eir_2epushFields(v_fs_243, v_rest_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushFields(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2ecountW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ecountW_entry, 3, 0};

V g_heff_2ecompile_2eir_2ecountW(V v_x_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return v_n_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      V v_y_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_247;
      if (heff_strEq_c(v_y_245, heff_dup(v_x_240))) {
        v_t_247 = heff_intAdd(v_n_241, MK_INT(1LL));
      } else {
        v_t_247 = v_n_241;
      }
      V t_0 = v_x_240;
      V t_1 = v_t_247;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_2410 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_2410, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2411 = heff_field(v_x31_243, 0);
      V v_as_2412 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2413 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2411, (g_heff_2ecompile_2eir_2eappendI(v_as_2412, v_rest_244))});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2413;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2415 = heff_field(v_x31_243, 1);
      V v_b_2416 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2417 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2416, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2417;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2418 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2419 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2418, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2419;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2420 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 3);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2420, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2424 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2425 = (g_heff_2ecompile_2eir_2eappendI(v_as_2424, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2425;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2426 = heff_field(v_x31_243, 0);
      V v_arms_2427 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2428 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2426, (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_244))});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2428;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2431 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2432 = (g_heff_2ecompile_2eir_2eappendI(v_as_2431, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2432;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2434 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2435 = (g_heff_2ecompile_2eir_2eappendI(v_as_2434, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2435;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ecountW(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eir_2elamW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2elamW_entry, 2, 0};

V g_heff_2ecompile_2eir_2elamW(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, NTAG(TAG_Nil)});
      V v_a_249 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_240), MK_INT(0LL), v_t_248));
      if (heff_intLt_c(MK_INT(0LL), v_a_249)) {
        heff_drop(v_x_240);
        heff_drop(v_rest_243);
        return NTAG(TAG_True);
      } else {
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EApp: {
      V v_f_2411 = heff_field(v_x21_242, 0);
      V v_as_2412 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_2411, (g_heff_2ecompile_2eir_2eappendI(v_as_2412, v_rest_243))});
      V t_0 = v_x_240;
      V t_1 = v_t_2413;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2415 = heff_field(v_x21_242, 1);
      V v_b_2416 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2416, v_rest_243})});
      V t_0 = v_x_240;
      V t_1 = v_t_2417;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2419 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2418, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2419;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2420 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 3);
      V t_0 = v_x_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2420, v_rest_243});
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2424 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2425 = (g_heff_2ecompile_2eir_2eappendI(v_as_2424, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2425;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2426 = heff_field(v_x21_242, 0);
      V v_arms_2427 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2428 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2426, (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243))});
      V t_0 = v_x_240;
      V t_1 = v_t_2428;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2431 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2432 = (g_heff_2ecompile_2eir_2eappendI(v_as_2431, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2432;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2434 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2435 = (g_heff_2ecompile_2eir_2eappendI(v_as_2434, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2435;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2elamW(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2esizeW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esizeW_entry, 2, 0};

V g_heff_2ecompile_2eir_2esizeW(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_n_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_as_249 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, (g_heff_2ecompile_2eir_2eappendI(v_as_249, v_rest_243))});
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2410;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2414;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2416 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2415, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2416;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2417 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 3);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2417, v_rest_243});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2421 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2422 = (g_heff_2ecompile_2eir_2eappendI(v_as_2421, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2422;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2423 = heff_field(v_x21_242, 0);
      V v_arms_2424 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2425 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2423, (g_heff_2ecompile_2eir_2epushArms(v_arms_2424, v_rest_243))});
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2425;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2428 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2429 = (g_heff_2ecompile_2eir_2eappendI(v_as_2428, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2429;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2431 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2432 = (g_heff_2ecompile_2eir_2eappendI(v_as_2431, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2432;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2esizeW(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2esizeB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esizeB_entry, 3, 0};

V g_heff_2ecompile_2eir_2esizeB(V v_lim_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lim_240);
    return v_n_241;
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intLt_c(heff_dup(v_lim_240), heff_dup(v_n_241))) {
      heff_drop(v_lim_240);
      heff_drop(v_e_243);
      heff_drop(v_rest_244);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return v_n_241;
    } else {
      switch (heff_tag_of(v_e_243)) {
      case TAG_EVar: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EGlobal: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ELam: {
        V v_b_249 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_249, v_rest_244});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EApp: {
        V v_f_2410 = heff_field(v_e_243, 0);
        V v_as_2411 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 3ULL, 2);
        V v_t_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2410, (g_heff_2ecompile_2eir_2eappendI(v_as_2411, v_rest_244))});
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2412;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ELet: {
        V v_a_2414 = heff_field(v_e_243, 1);
        V v_b_2415 = heff_field(v_e_243, 2);
        heff_take_n(v_e_243, 6ULL, 3);
        V v_t_2416 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2415, v_rest_244})});
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2416;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ERecord: {
        V v_fs_2417 = heff_field(v_e_243, 0);
        heff_take_n(v_e_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2418 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2417, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2418;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EProj: {
        V v_e2_2419 = heff_field(v_e_243, 0);
        heff_take_n(v_e_243, 1ULL, 3);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e2_2419, v_rest_244});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ETag: {
        V v_as_2423 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2424 = (g_heff_2ecompile_2eir_2eappendI(v_as_2423, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2424;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EMatch: {
        V v_sc_2425 = heff_field(v_e_243, 0);
        V v_arms_2426 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 3ULL, 2);
        V v_t_2427 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_sc_2425, (g_heff_2ecompile_2eir_2epushArms(v_arms_2426, v_rest_244))});
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2427;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EPrim: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EPrimCall: {
        V v_as_2430 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2431 = (g_heff_2ecompile_2eir_2eappendI(v_as_2430, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2431;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ECall: {
        V v_as_2433 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2434 = (g_heff_2ecompile_2eir_2eappendI(v_as_2433, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2434;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EInt: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFloat: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EStr: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFixed: {
        heff_take_n(v_e_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFloat32: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFix: {
        heff_take_n(v_e_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e_243);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2esizeB(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_entry, 1, 0};

V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(v_xs_242));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry, 1, 0};

V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_a_244)));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = (g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(v_xs_242));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_entry, 1, 0};

V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(v_t_246));
    V v_t_248 = (g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(v_xs_242));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_247, v_t_248));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecompile_2eir_2eglobalsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eglobalsGo_entry, 1, 0};

V g_heff_2ecompile_2eir_2eglobalsGo(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    V v_g_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_g_242, NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_as_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(v_f_245));
    V v_t_248 = ({ V a_0 = v_as_246; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_as_246); r_; });
    return (g_heff_2ecompile_2eir_2eappendI(v_t_247, v_t_248));
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eir_2eglobalsGo(v_a_2410));
    V v_t_2413 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_2411));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2412, v_t_2413));
  }
  case TAG_ERecord: {
    V v_fs_2414 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ({ V a_0 = v_fs_2414; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(a_0)); heff_drop(v_fs_2414); r_; });
  }
  case TAG_EProj: {
    V v_e2_2415 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 3);
    V t_0 = v_e2_2415;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2419 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return ({ V a_0 = v_as_2419; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_as_2419); r_; });
  }
  case TAG_EMatch: {
    V v_s_2420 = heff_field(v_x1_240, 0);
    V v_arms_2421 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_2422 = (g_heff_2ecompile_2eir_2eglobalsGo(v_s_2420));
    V v_t_2423 = ({ V a_0 = v_arms_2421; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(a_0)); heff_drop(v_arms_2421); r_; });
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2422, v_t_2423));
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_as_2426 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return ({ V a_0 = v_as_2426; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_as_2426); r_; });
  }
  case TAG_ECall: {
    V v_g_2427 = heff_field(v_x1_240, 0);
    V v_as_2428 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_Cons, 2, (V[]){v_g_2427, ({ V a_0 = v_as_2428; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_as_2428); r_; })});
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eglobalsGo(a[0]);
}
Clo g_heff_2ecompile_2eir_2eallI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eallI_entry, 1, 0};

V g_heff_2ecompile_2eir_2eallI(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_b_241 = heff_field(v_x1_240, 0);
    V v_bs_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_b_241)) {
    case TAG_True: {
      V t_0 = v_bs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_False: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eir_2eallI(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecompile_2eir_2eisValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eisValue_entry, 1, 0};

V g_heff_2ecompile_2eir_2eisValue(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2410 = heff_field(v_x1_240, 0);
    V v_t_2411 = (g_list_2emap_24s1044393341x1523302351(heff_dup(v_fs_2410)));
    return ({ V a_0 = v_t_2411; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2411); r_; });
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_as_2416 = heff_field(v_x1_240, 1);
    V v_t_2417 = (g_list_2emap_24s584454411x1006678865(heff_dup(v_as_2416)));
    return ({ V a_0 = v_t_2417; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2417); r_; });
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eir_2eisValue(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecompile_2eir_2espine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2espine_entry, 1, 0};

V g_heff_2ecompile_2eir_2espine(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_e_240, 0);
    V v_as_246 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EApp = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x2_247 = (g_heff_2ecompile_2eir_2espine(v_f_245));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_h_248 = heff_field(v_x2_247, 0);
      V v_bs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_240_24EApp, TAG_MkPair, 2, (V[]){v_h_248, (g_heff_2ecompile_2eir_2eappendI(v_bs_249, v_as_246))});
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2eir_2espine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2espine(a[0]);
}