// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_MkArm 55352
#define LBL_m 327
#define LBL_n 328
#define LBL_xs 10594
static uint32_t shape_m__n__xs[] = {LBL_m, LBL_n, LBL_xs};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24dps(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24dps_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
HeffT2 g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(V);
HeffT2 g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2efreshBindOne(V, V);
V g_heff_2ecompile_2eir_2efreshBindOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshBindOne_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2enubI_24dps(V, V);
V g_heff_2ecompile_2eir_2enubI_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_24dps_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushArms_24dps(V, V, V);
V g_heff_2ecompile_2eir_2epushArms_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_24dps_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24dps(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24dps_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
HeffT2 g_heff_2ecompile_2eir_2espine_24cpr(V);
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eir_2esubstGo_24dps(V, V, V, V);
V g_heff_2ecompile_2eir_2esubstGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_24dps_clo;
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_list_2efilter_24s727803713x1346936525(V, V);
V g_list_2efilter_24s727803713x1346936525_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_clo;
HeffT2 g_list_2efind_24s1236173780x2048419812_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s690313412x1307839513(V, V);
V g_list_2efoldl_24s690313412x1307839513_entry(V self, V *a);
extern Clo g_list_2efoldl_24s690313412x1307839513_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1044393341x1523302351(V);
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_clo;
V g_list_2emap_24s584454411x1006678865(V);
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_clo;
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str2, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str3, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str4, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str5, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str6, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str7, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str8, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str9, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str10, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str11, 7, "Float32");

HeffT2 g_heff_2ecompile_2eir_2efieldTyOfName_24cpr(V v_x_240) {
top: ;
  if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str0), 2)) {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_FtFloat)}});
  } else {
    if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str1), 2)) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_FtOther)}});
    } else {
      if (heff_strEq_c_lent(v_x_240, ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str2), 2)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_FtAny)}});
      } else {
        HeffT2 v_t_244 = (g_list_2efind_24s1236173780x2048419812_24cpr(((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str3), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str4), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str5), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str6), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str7), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str8), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str9), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str10), ((V)&g_heff_2ecompile_2eir_2efieldTyOfName_24cpr_str11), v_x_240, heff_dup(g_heff_2eelab_2efixed_2eallFixed_get())));
        {
          V v_field_246 = v_t_244.f[1];
          int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
          if ((v_tag_245 == ((int64_t)0ULL))) {
            V v_x_248 = v_field_246;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_FtFixed, 1, (V[]){v_x_248})}});
          } else {
            heff_drop(v_field_246);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    }
  }
}
Clo g_heff_2ecompile_2eir_2ebaseGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ebaseGo_entry, 2, 0};

V g_heff_2ecompile_2eir_2ebaseGo(V v_x_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) <= v_i_241)) {
    return v_x_240;
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_x_240, heff_box_word(v_i_241), 2)) == ((int64_t)36ULL))) {
      return heff_strSlice(v_x_240, MK_INT(0LL), heff_box_word(v_i_241));
    } else {
      V t_0 = v_x_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_x_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ebaseGo(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2eappendI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eappendI_entry, 2, 0};

V g_heff_2ecompile_2eir_2eappendI(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2eir_2eappendI_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eappendI(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2eappendI_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eappendI_24dps_entry, 3, 0};

V g_heff_2ecompile_2eir_2eappendI_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eappendI_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eappendI_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eir_2enubI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2enubI_entry, 1, 0};

V g_heff_2ecompile_2eir_2enubI(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_x_241; V a_1 = v_xs_242; V r_ = (g_list_2efilter_24s727803713x1346936525(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_u_245 = (g_heff_2ecompile_2eir_2enubI_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2enubI(a[0]);
}
Clo g_heff_2ecompile_2eir_2enubI_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2enubI_24dps_entry, 2, 0};

V g_heff_2ecompile_2eir_2enubI_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_list_2efilter_24s727803713x1346936525(a_0, a_1)); heff_drop(v_x_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2enubI_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2enubI_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eir_2efreshBindOne_str0, 1, "$");
Clo g_heff_2ecompile_2eir_2efreshBindOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efreshBindOne_entry, 2, 0};

V g_heff_2ecompile_2eir_2efreshBindOne(V v_acc_240, V v_x_241) {
top: ;
  V v_base_242 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_241), MK_INT(0LL)));
  V v_n_243 = heff_take_field(v_acc_240, 1);
  V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eir_2efreshBindOne_str0), heff_intShow(heff_dup(v_n_243)));
  V v_x_27_245 = heff_strAppend(v_base_242, v_t_244);
  V v_t_246 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_acc_240, 0), v_x_241, heff_dup(v_x_27_245)));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_27_245, heff_get_n(v_acc_240, 2, 3)});
  return heff_rec_n(3, shape_m__n__xs, (V[]){v_t_246, heff_intAdd(v_n_243, MK_INT(1LL)), v_t_247});
}
V g_heff_2ecompile_2eir_2efreshBindOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2efreshBindOne(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_n_241}});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_e_243));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_e_27_248 = v_field_246;
      V v_n1_249 = v_field_247;
      HeffT2 v_t_2410 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n1_249, v_rest_244));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_es_2413 = v_field_2411;
        V v_n_2414 = v_field_2412;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_e_27_248, v_es_2413}), v_n_2414}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}

HeffT2 g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24cpr(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_n_241}});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_l_245 = heff_field(v_x41_243, 0);
      V v_e_246 = heff_field(v_x41_243, 1);
      heff_take_n(v_x41_243, 3ULL, 2);
      HeffT2 v_t_247 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_e_246));
      {
        V v_field_248 = v_t_247.f[0];
        V v_field_249 = v_t_247.f[1];
        V v_e_27_2410 = v_field_248;
        V v_n1_2411 = v_field_249;
        HeffT2 v_t_2412 = (g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24cpr(v_m_240, v_n1_2411, v_rest_244));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v_fs_2415 = v_field_2413;
          V v_n_2416 = v_field_2414;
          V v_t_2417 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_245, v_e_27_2410}), v_fs_2415});
          return ((HeffT2){{v_t_2417, v_n_2416}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x41_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}

HeffT2 g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_n_241}});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkArm: {
      V v_tag_245 = heff_field(v_x41_243, 0);
      V v_vars_246 = heff_field(v_x41_243, 1);
      V v_body_247 = heff_field(v_x41_243, 2);
      V v_ru_24x41_243_24MkArm = heff_take_reuse_n(v_x41_243, 7ULL, 3);
      V v_t_248 = heff_rec_n(3, shape_m__n__xs, (V[]){heff_dup(v_m_240), v_n_241, NTAG(TAG_Nil)});
      V v_v_249 = ({ V a_0 = v_t_248; V a_1 = v_vars_246; V r_ = (g_list_2efoldl_24s690313412x1307839513(a_0, a_1)); heff_drop(v_vars_246); r_; });
      HeffT2 v_t_2410 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_take_field(v_v_249, 0), heff_take_field(v_v_249, 1), v_body_247));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_b_27_2413 = v_field_2411;
        V v_n1_2414 = v_field_2412;
        V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_v_249, 2, 3)));
        V v_a_2416 = heff_tag_at_n(v_ru_24x41_243_24MkArm, TAG_MkArm, 3, (V[]){v_tag_245, v_t_2415, v_b_27_2413});
        HeffT2 v_t_2417 = (g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(v_m_240, v_n1_2414, v_rest_244));
        {
          V v_field_2418 = v_t_2417.f[0];
          V v_field_2419 = v_t_2417.f[1];
          V v_args_2420 = v_field_2418;
          V v_n_2421 = v_field_2419;
          return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_a_2416, v_args_2420}), v_n_2421}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x41_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr_str0, 1, "$");

HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V v_m_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24EVar = heff_take_reuse_n(v_e_242, 1ULL, 1);
    HeffT2 v_t_244 = ({ V a_0 = v_m_240; V a_1 = v_x_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_m_240); r_; });
    V v_t_249;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        V v_y_248 = v_field_246;
        v_t_249 = v_y_248;
      } else {
        heff_drop(v_field_246);
        v_t_249 = v_x_243;
      }
    }
    V v_f_2410 = heff_tag_at_n(v_ru_24e_242_24EVar, TAG_EVar, 1, (V[]){v_t_249});
    return ((HeffT2){{v_f_2410, v_n_241}});
  }
  case TAG_EGlobal: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_ELam: {
    V v_xs_2412 = heff_field(v_e_242, 0);
    V v_b_2413 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2414 = heff_rec_n(3, shape_m__n__xs, (V[]){v_m_240, v_n_241, NTAG(TAG_Nil)});
    V v_v_2415 = ({ V a_0 = v_t_2414; V a_1 = v_xs_2412; V r_ = (g_list_2efoldl_24s690313412x1307839513(a_0, a_1)); heff_drop(v_xs_2412); r_; });
    HeffT2 v_t_2416 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_take_field(v_v_2415, 0), heff_take_field(v_v_2415, 1), v_b_2413));
    {
      V v_field_2417 = v_t_2416.f[0];
      V v_field_2418 = v_t_2416.f[1];
      V v_b_27_2419 = v_field_2417;
      V v_n_27_2420 = v_field_2418;
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_v_2415, 2, 3)));
      V v_f_2422 = heff_tag_at_n(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_t_2421, v_b_27_2419});
      return ((HeffT2){{v_f_2422, v_n_27_2420}});
    }
  }
  case TAG_EApp: {
    V v_f_2423 = heff_field(v_e_242, 0);
    V v_args_2424 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2425 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_f_2423));
    {
      V v_field_2426 = v_t_2425.f[0];
      V v_field_2427 = v_t_2425.f[1];
      V v_f_27_2428 = v_field_2426;
      V v_n1_2429 = v_field_2427;
      HeffT2 v_t_2430 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n1_2429, v_args_2424));
      {
        V v_field_2431 = v_t_2430.f[0];
        V v_field_2432 = v_t_2430.f[1];
        V v_args_27_2433 = v_field_2431;
        V v_n2_2434 = v_field_2432;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){v_f_27_2428, v_args_27_2433}), v_n2_2434}});
      }
    }
  }
  case TAG_ELet: {
    V v_x_2435 = heff_field(v_e_242, 0);
    V v_a_2436 = heff_field(v_e_242, 1);
    V v_b_2437 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2438 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_a_2436));
    {
      V v_field_2439 = v_t_2438.f[0];
      V v_field_2440 = v_t_2438.f[1];
      V v_a_27_2441 = v_field_2439;
      V v_n1_2442 = v_field_2440;
      V v_base_2443 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_2435), MK_INT(0LL)));
      V v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr_str0), heff_intShow(heff_dup(v_n1_2442)));
      V v_x_27_2445 = heff_strAppend(v_base_2443, v_t_2444);
      V v_m_2446 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_240, v_x_2435, heff_dup(v_x_27_2445)));
      HeffT2 v_t_2447 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_2446, heff_intAdd(v_n1_2442, MK_INT(1LL)), v_b_2437));
      {
        V v_field_2448 = v_t_2447.f[0];
        V v_field_2449 = v_t_2447.f[1];
        V v_b_27_2450 = v_field_2448;
        V v_n3_2451 = v_field_2449;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_27_2445, v_a_27_2441, v_b_27_2450}), v_n3_2451}});
      }
    }
  }
  case TAG_ERecord: {
    V v_fs_2452 = heff_field(v_e_242, 0);
    V v_ts_2453 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2454 = (g_heff_2ecompile_2eir_2efreshFields_24s332778902x589328295_24cpr(v_m_240, v_n_241, v_fs_2452));
    {
      V v_field_2455 = v_t_2454.f[0];
      V v_field_2456 = v_t_2454.f[1];
      V v_fs_27_2457 = v_field_2455;
      V v_n1_2458 = v_field_2456;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ERecord, TAG_ERecord, 2, (V[]){v_fs_27_2457, v_ts_2453}), v_n1_2458}});
    }
  }
  case TAG_EProj: {
    V v_e2_2459 = heff_field(v_e_242, 0);
    V v_l_2460 = heff_field(v_e_242, 1);
    V v_sh_2461 = heff_field(v_e_242, 2);
    V v_t_2462 = heff_field(v_e_242, 3);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 15ULL, 4);
    HeffT2 v_t_2463 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_240, v_n_241, v_e2_2459));
    {
      V v_field_2464 = v_t_2463.f[0];
      V v_field_2465 = v_t_2463.f[1];
      V v_e_27_2466 = v_field_2464;
      V v_n1_2467 = v_field_2465;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EProj, TAG_EProj, 4, (V[]){v_e_27_2466, v_l_2460, v_sh_2461, v_t_2462}), v_n1_2467}});
    }
  }
  case TAG_ETag: {
    V v_t_2468 = heff_field(v_e_242, 0);
    V v_args_2469 = heff_field(v_e_242, 1);
    V v_ts_2470 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HeffT2 v_t_2471 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n_241, v_args_2469));
    {
      V v_field_2472 = v_t_2471.f[0];
      V v_field_2473 = v_t_2471.f[1];
      V v_args_27_2474 = v_field_2472;
      V v_n1_2475 = v_field_2473;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ETag, TAG_ETag, 3, (V[]){v_t_2468, v_args_27_2474, v_ts_2470}), v_n1_2475}});
    }
  }
  case TAG_EMatch: {
    V v_s_2476 = heff_field(v_e_242, 0);
    V v_arms_2477 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2478 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_s_2476));
    {
      V v_field_2479 = v_t_2478.f[0];
      V v_field_2480 = v_t_2478.f[1];
      V v_s_27_2481 = v_field_2479;
      V v_n1_2482 = v_field_2480;
      HeffT2 v_t_2483 = (g_heff_2ecompile_2eir_2efreshArms_24s1727764278x278500871_24cpr(v_m_240, v_n1_2482, v_arms_2477));
      {
        V v_field_2484 = v_t_2483.f[0];
        V v_field_2485 = v_t_2483.f[1];
        V v_arms_27_2486 = v_field_2484;
        V v_n2_2487 = v_field_2485;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_27_2481, v_arms_27_2486}), v_n2_2487}});
      }
    }
  }
  case TAG_EPrim: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EPrimCall: {
    V v_p_2489 = heff_field(v_e_242, 0);
    V v_args_2490 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2491 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n_241, v_args_2490));
    {
      V v_field_2492 = v_t_2491.f[0];
      V v_field_2493 = v_t_2491.f[1];
      V v_args_27_2494 = v_field_2492;
      V v_n1_2495 = v_field_2493;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2489, v_args_27_2494}), v_n1_2495}});
    }
  }
  case TAG_ECall: {
    V v_g_2496 = heff_field(v_e_242, 0);
    V v_args_2497 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HeffT2 v_t_2498 = (g_heff_2ecompile_2eir_2efreshMany_24s1318803926x546830226_24cpr(v_m_240, v_n_241, v_args_2497));
    {
      V v_field_2499 = v_t_2498.f[0];
      V v_field_24100 = v_t_2498.f[1];
      V v_args_27_24101 = v_field_2499;
      V v_n1_24102 = v_field_24100;
      return ((HeffT2){{heff_tag_at_n(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_g_2496, v_args_27_24101}), v_n1_24102}});
    }
  }
  case TAG_EInt: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EFloat: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EStr: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EBytes: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EFixed: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EFloat32: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EAbandon: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  case TAG_EFix: {
    heff_drop(v_m_240);
    return ((HeffT2){{v_e_242, v_n_241}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_242)}});
  }
}
Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry, 3, 0};

V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V v_m_240, V v_n_241, V v_e_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_240, v_n_241, v_e_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eir_2esubstGo_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2esubstGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esubstGo_entry, 2, 0};

V g_heff_2ecompile_2eir_2esubstGo(V v_m_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EVar = heff_take_reuse_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_m_240, v_x_242));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_x_242);
        heff_drop_cell(v_ru_24e_241_24EVar, 1);
        V v_e2_247 = v_field_245;
        return v_e2_247;
      } else {
        heff_drop(v_field_245);
        return heff_tag_at_n(v_ru_24e_241_24EVar, TAG_EVar, 1, (V[]){v_x_242});
      }
    }
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    V v_xs_249 = heff_field(v_e_241, 0);
    V v_b_2410 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_cell_2411 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_xs_249, heff_hole()});
    V v_u_2412 = (g_heff_2ecompile_2eir_2esubstGo_24dps(v_m_240, v_b_2410, heff_dup(v_cell_2411), MK_INT(1LL)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_e_241, 0);
    V v_args_2414 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2415 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_f_2413));
    V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2414));
    return heff_tag_at_n(v_ru_24e_241_24EApp, TAG_EApp, 2, (V[]){v_t_2415, v_t_2417});
  }
  case TAG_ELet: {
    V v_x_2418 = heff_field(v_e_241, 0);
    V v_a_2419 = heff_field(v_e_241, 1);
    V v_b_2420 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2421 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_a_2419));
    V v_cell_2422 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2418, v_t_2421, heff_hole()});
    V v_u_2423 = (g_heff_2ecompile_2eir_2esubstGo_24dps(v_m_240, v_b_2420, heff_dup(v_cell_2422), MK_INT(2LL)));
    heff_drop(v_u_2423);
    return v_cell_2422;
  }
  case TAG_ERecord: {
    V v_fs_2424 = heff_field(v_e_241, 0);
    V v_ts_2425 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ERecord = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam1, 1, 1, (V[]){heff_dup(v_m_240)}), v_fs_2424));
    return heff_tag_at_n(v_ru_24e_241_24ERecord, TAG_ERecord, 2, (V[]){v_t_2430, v_ts_2425});
  }
  case TAG_EProj: {
    V v_e2_2431 = heff_field(v_e_241, 0);
    V v_l_2432 = heff_field(v_e_241, 1);
    V v_sh_2433 = heff_field(v_e_241, 2);
    V v_t_2434 = heff_field(v_e_241, 3);
    V v_ru_24e_241_24EProj = heff_take_reuse_n(v_e_241, 15ULL, 4);
    V v_t_2435 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_e2_2431));
    return heff_tag_at_n(v_ru_24e_241_24EProj, TAG_EProj, 4, (V[]){v_t_2435, v_l_2432, v_sh_2433, v_t_2434});
  }
  case TAG_ETag: {
    V v_t_2436 = heff_field(v_e_241, 0);
    V v_args_2437 = heff_field(v_e_241, 1);
    V v_ts_2438 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ETag = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam2, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2437));
    return heff_tag_at_n(v_ru_24e_241_24ETag, TAG_ETag, 3, (V[]){v_t_2436, v_t_2440, v_ts_2438});
  }
  case TAG_EMatch: {
    V v_s_2441 = heff_field(v_e_241, 0);
    V v_arms_2442 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2443 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_s_2441));
    V v_t_2449 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam3, 1, 1, (V[]){heff_dup(v_m_240)}), v_arms_2442));
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_t_2443, v_t_2449});
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    V v_p_2451 = heff_field(v_e_241, 0);
    V v_args_2452 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EPrimCall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2454 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam4, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2452));
    return heff_tag_at_n(v_ru_24e_241_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2451, v_t_2454});
  }
  case TAG_ECall: {
    V v_g_2455 = heff_field(v_e_241, 0);
    V v_args_2456 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2458 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_lam5, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2456));
    return heff_tag_at_n(v_ru_24e_241_24ECall, TAG_ECall, 2, (V[]){v_g_2455, v_t_2458});
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EBytes: {
    return v_e_241;
  }
  case TAG_EFixed: {
    return v_e_241;
  }
  case TAG_EFloat32: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2esubstGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eir_2esubstGo_lam0(V self, V *args) {
  V v_a_2416 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2416; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam1(V self, V *args) {
  V v_p_2426 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2426)) {
  case TAG_MkPair: {
    V v_l_2427 = heff_field(v_p_2426, 0);
    V v_e2_2428 = heff_field(v_p_2426, 1);
    V v_ru_24p_2426_24MkPair = heff_take_reuse_n(v_p_2426, 3ULL, 2);
    V v_t_2429 = ({ V a_0 = v_m_240; V a_1 = v_e2_2428; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
    return heff_tag_at_n(v_ru_24p_2426_24MkPair, TAG_MkPair, 2, (V[]){v_l_2427, v_t_2429});
  }
  default: return heff_nomatch(v_p_2426);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_lam2(V self, V *args) {
  V v_a_2439 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2439; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam3(V self, V *args) {
  V v_a_2444 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2444)) {
  case TAG_MkArm: {
    V v_t_2445 = heff_field(v_a_2444, 0);
    V v_vs_2446 = heff_field(v_a_2444, 1);
    V v_b_2447 = heff_field(v_a_2444, 2);
    V v_ru_24a_2444_24MkArm = heff_take_reuse_n(v_a_2444, 7ULL, 3);
    V v_t_2448 = ({ V a_0 = v_m_240; V a_1 = v_b_2447; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
    return heff_tag_at_n(v_ru_24a_2444_24MkArm, TAG_MkArm, 3, (V[]){v_t_2445, v_vs_2446, v_t_2448});
  }
  default: return heff_nomatch(v_a_2444);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_lam4(V self, V *args) {
  V v_a_2453 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2453; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_lam5(V self, V *args) {
  V v_a_2457 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2457; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2esubstGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esubstGo_24dps_entry, 4, 0};

V g_heff_2ecompile_2eir_2esubstGo_24dps(V v_m_240, V v_e_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_244 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_m_240, v_x_244));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_244);
        V v_e2_249 = v_field_247;
        return heff_setField(v_d_242, v_i_243, v_e2_249);
      } else {
        heff_drop(v_field_247);
        return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EVar, 1, (V[]){v_x_244}));
      }
    }
  }
  case TAG_EGlobal: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_ELam: {
    V v_xs_2411 = heff_field(v_e_241, 0);
    V v_b_2412 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_cell_2413 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_xs_2411, heff_hole()});
    V v_u_2414 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_m_240;
    V t_1 = v_b_2412;
    V t_2 = v_cell_2413;
    V t_3 = MK_INT(1LL);
    v_m_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2415 = heff_field(v_e_241, 0);
    V v_args_2416 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2417 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_f_2415));
    V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam0, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2416));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2417, v_t_2419}));
  }
  case TAG_ELet: {
    V v_x_2420 = heff_field(v_e_241, 0);
    V v_a_2421 = heff_field(v_e_241, 1);
    V v_b_2422 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_t_2423 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_a_2421));
    V v_cell_2424 = heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2420, v_t_2423, heff_hole()});
    V v_u_2425 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_m_240;
    V t_1 = v_b_2422;
    V t_2 = v_cell_2424;
    V t_3 = MK_INT(2LL);
    v_m_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2426 = heff_field(v_e_241, 0);
    V v_ts_2427 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2432 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam1, 1, 1, (V[]){heff_dup(v_m_240)}), v_fs_2426));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2432, v_ts_2427}));
  }
  case TAG_EProj: {
    V v_e2_2433 = heff_field(v_e_241, 0);
    V v_l_2434 = heff_field(v_e_241, 1);
    V v_sh_2435 = heff_field(v_e_241, 2);
    V v_t_2436 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 15ULL, 4);
    V v_t_2437 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_e2_2433));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EProj, 4, (V[]){v_t_2437, v_l_2434, v_sh_2435, v_t_2436}));
  }
  case TAG_ETag: {
    V v_t_2438 = heff_field(v_e_241, 0);
    V v_args_2439 = heff_field(v_e_241, 1);
    V v_ts_2440 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_t_2442 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam2, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2439));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2438, v_t_2442, v_ts_2440}));
  }
  case TAG_EMatch: {
    V v_s_2443 = heff_field(v_e_241, 0);
    V v_arms_2444 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2445 = (g_heff_2ecompile_2eir_2esubstGo(v_m_240, v_s_2443));
    V v_t_2451 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam3, 1, 1, (V[]){heff_dup(v_m_240)}), v_arms_2444));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2445, v_t_2451}));
  }
  case TAG_EPrim: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EPrimCall: {
    V v_p_2453 = heff_field(v_e_241, 0);
    V v_args_2454 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2456 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam4, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2454));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2453, v_t_2456}));
  }
  case TAG_ECall: {
    V v_g_2457 = heff_field(v_e_241, 0);
    V v_args_2458 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2460 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eir_2esubstGo_24dps_lam5, 1, 1, (V[]){heff_dup(v_m_240)}), v_args_2458));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ECall, 2, (V[]){v_g_2457, v_t_2460}));
  }
  case TAG_EInt: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFloat: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EStr: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EBytes: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFixed: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFloat32: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EAbandon: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  case TAG_EFix: {
    return heff_setField(v_d_242, v_i_243, v_e_241);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2esubstGo_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam0(V self, V *args) {
  V v_a_2418 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2418; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam1(V self, V *args) {
  V v_p_2428 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2428)) {
  case TAG_MkPair: {
    V v_l_2429 = heff_field(v_p_2428, 0);
    V v_e2_2430 = heff_field(v_p_2428, 1);
    V v_ru_24p_2428_24MkPair = heff_take_reuse_n(v_p_2428, 3ULL, 2);
    V v_t_2431 = ({ V a_0 = v_m_240; V a_1 = v_e2_2430; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
    return heff_tag_at_n(v_ru_24p_2428_24MkPair, TAG_MkPair, 2, (V[]){v_l_2429, v_t_2431});
  }
  default: return heff_nomatch(v_p_2428);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam2(V self, V *args) {
  V v_a_2441 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2441; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam3(V self, V *args) {
  V v_a_2446 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2446)) {
  case TAG_MkArm: {
    V v_t_2447 = heff_field(v_a_2446, 0);
    V v_vs_2448 = heff_field(v_a_2446, 1);
    V v_b_2449 = heff_field(v_a_2446, 2);
    V v_ru_24a_2446_24MkArm = heff_take_reuse_n(v_a_2446, 7ULL, 3);
    V v_t_2450 = ({ V a_0 = v_m_240; V a_1 = v_b_2449; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
    return heff_tag_at_n(v_ru_24a_2446_24MkArm, TAG_MkArm, 3, (V[]){v_t_2447, v_vs_2448, v_t_2450});
  }
  default: return heff_nomatch(v_a_2446);
  }
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam4(V self, V *args) {
  V v_a_2455 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2455; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
V g_heff_2ecompile_2eir_2esubstGo_24dps_lam5(V self, V *args) {
  V v_a_2459 = args[0];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_m_240; V a_1 = v_a_2459; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_240); r_; });
}
Clo g_heff_2ecompile_2eir_2epushArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushArms_entry, 2, 0};

V g_heff_2ecompile_2eir_2epushArms(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_args_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_a_242)) {
    case TAG_MkArm: {
      V v_b_246 = heff_field(v_a_242, 2);
      heff_take_n(v_a_242, 4ULL, 3);
      v_t_247 = v_b_246;
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = (g_heff_2ecompile_2eir_2epushArms_24dps(v_args_243, v_rest_241, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushArms(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2epushArms_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushArms_24dps_entry, 3, 0};

V g_heff_2ecompile_2eir_2epushArms_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_args_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_a_243)) {
    case TAG_MkArm: {
      V v_b_247 = heff_field(v_a_243, 2);
      heff_take_n(v_a_243, 4ULL, 3);
      v_t_248 = v_b_247;
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_args_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_249;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushArms_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushArms_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eir_2epushFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushFields_entry, 2, 0};

V g_heff_2ecompile_2eir_2epushFields(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_p_242)) {
    case TAG_MkPair: {
      V v_e2_245 = heff_field(v_p_242, 1);
      heff_take_n(v_p_242, 2ULL, 2);
      v_t_246 = v_e2_245;
      break;
    }
    default: heff_nomatch(v_p_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_heff_2ecompile_2eir_2epushFields_24dps(v_fs_243, v_rest_241, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushFields(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2epushFields_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushFields_24dps_entry, 3, 0};

V g_heff_2ecompile_2eir_2epushFields_24dps(V v_x1_240, V v_rest_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_rest_241);
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x1_240, 0);
    V v_fs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_p_243)) {
    case TAG_MkPair: {
      V v_e2_246 = heff_field(v_p_243, 1);
      heff_take_n(v_p_243, 2ULL, 2);
      v_t_247 = v_e2_246;
      break;
    }
    default: heff_nomatch(v_p_243);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_fs_244;
    V t_1 = v_rest_241;
    V t_2 = v_cell_248;
    v_x1_240 = t_0;
    v_rest_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushFields_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushFields_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eir_2ecountW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ecountW_entry, 3, 0};

V g_heff_2ecompile_2eir_2ecountW(V v_x_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_n_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      V v_y_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_247;
      if (heff_strEq_c_lent(v_y_245, v_x_240, 1)) {
        v_t_247 = heff_intAdd(v_n_241, MK_INT(1LL));
      } else {
        v_t_247 = v_n_241;
      }
      V t_0 = v_x_240;
      V t_1 = v_t_247;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_2410 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_2410, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2411 = heff_field(v_x31_243, 0);
      V v_args_2412 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2413 = (g_heff_2ecompile_2eir_2eappendI(v_args_2412, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2411, v_t_2413});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2415 = heff_field(v_x31_243, 1);
      V v_b_2416 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2417 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2416, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2417;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2418 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2420 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2418, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2420;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2421 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 4);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2421, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_args_2426 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2428 = (g_heff_2ecompile_2eir_2eappendI(v_args_2426, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2428;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2429 = heff_field(v_x31_243, 0);
      V v_arms_2430 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2431 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2430, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2429, v_t_2431});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2434 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2435 = (g_heff_2ecompile_2eir_2eappendI(v_args_2434, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2435;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_args_2437 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2438 = (g_heff_2ecompile_2eir_2eappendI(v_args_2437, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2438;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2ecountW(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2elamW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2elamW_entry, 2, 0};

V g_heff_2ecompile_2eir_2elamW(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, NTAG(TAG_Nil)});
      V v_x_249 = (g_heff_2ecompile_2eir_2ecountW(v_x_240, MK_INT(0LL), v_t_248));
      if (heff_intLt_c(MK_INT(0LL), v_x_249)) {
        heff_drop(v_rest_243);
        return NTAG(TAG_True);
      } else {
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EApp: {
      V v_f_2411 = heff_field(v_x21_242, 0);
      V v_args_2412 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2413 = (g_heff_2ecompile_2eir_2eappendI(v_args_2412, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_2411, v_t_2413});
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2415 = heff_field(v_x21_242, 1);
      V v_b_2416 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2416, v_rest_243})});
      V t_0 = v_x_240;
      V t_1 = v_t_2417;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2420 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2418, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2420;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2421 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = v_x_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2421, v_rest_243});
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_args_2426 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2428 = (g_heff_2ecompile_2eir_2eappendI(v_args_2426, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2428;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2429 = heff_field(v_x21_242, 0);
      V v_arms_2430 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2431 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2430, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2429, v_t_2431});
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2434 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2435 = (g_heff_2ecompile_2eir_2eappendI(v_args_2434, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2435;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_args_2437 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2438 = (g_heff_2ecompile_2eir_2eappendI(v_args_2437, v_rest_243));
      V t_0 = v_x_240;
      V t_1 = v_t_2438;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_rest_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2elamW(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2esizeW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esizeW_entry, 2, 0};

V g_heff_2ecompile_2eir_2esizeW(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_n_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_args_249 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI(v_args_249, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2410});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2414;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2417 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2415, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2417;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 4);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_2418, v_rest_243});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_args_2423 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2425 = (g_heff_2ecompile_2eir_2eappendI(v_args_2423, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2425;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2426 = heff_field(v_x21_242, 0);
      V v_arms_2427 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2428 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2427, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2426, v_t_2428});
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2431 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2432 = (g_heff_2ecompile_2eir_2eappendI(v_args_2431, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2432;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_args_2434 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2435 = (g_heff_2ecompile_2eir_2eappendI(v_args_2434, v_rest_243));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2435;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2esizeW(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2esizeB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esizeB_entry, 3, 0};

V g_heff_2ecompile_2eir_2esizeB(V v_lim_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lim_240);
    return v_n_241;
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intLt_c_lent(v_lim_240, v_n_241, 0)) {
      heff_drop(v_lim_240);
      heff_drop(v_e_243);
      heff_drop(v_rest_244);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return v_n_241;
    } else {
      switch (heff_tag_of(v_e_243)) {
      case TAG_EVar: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EGlobal: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ELam: {
        V v_b_249 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_249, v_rest_244});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EApp: {
        V v_f_2410 = heff_field(v_e_243, 0);
        V v_args_2411 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 3ULL, 2);
        V v_t_2412 = (g_heff_2ecompile_2eir_2eappendI(v_args_2411, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2410, v_t_2412});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ELet: {
        V v_a_2414 = heff_field(v_e_243, 1);
        V v_b_2415 = heff_field(v_e_243, 2);
        heff_take_n(v_e_243, 6ULL, 3);
        V v_t_2416 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2415, v_rest_244})});
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2416;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ERecord: {
        V v_fs_2417 = heff_field(v_e_243, 0);
        heff_take_n(v_e_243, 1ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2419 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2417, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2419;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EProj: {
        V v_e2_2420 = heff_field(v_e_243, 0);
        heff_take_n(v_e_243, 1ULL, 4);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e2_2420, v_rest_244});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ETag: {
        V v_args_2425 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 3);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2427 = (g_heff_2ecompile_2eir_2eappendI(v_args_2425, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2427;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EMatch: {
        V v_sc_2428 = heff_field(v_e_243, 0);
        V v_arms_2429 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 3ULL, 2);
        V v_t_2430 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2429, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_sc_2428, v_t_2430});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EPrim: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EPrimCall: {
        V v_args_2433 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2434 = (g_heff_2ecompile_2eir_2eappendI(v_args_2433, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2434;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ECall: {
        V v_args_2436 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2437 = (g_heff_2ecompile_2eir_2eappendI(v_args_2436, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2437;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EInt: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFloat: {
        heff_take_na(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EStr: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EBytes: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFixed: {
        heff_take_n(v_e_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFloat32: {
        heff_take_na(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFix: {
        heff_take_n(v_e_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e_243);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2esizeB(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_entry, 1, 0};

V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(v_xs_242));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry, 1, 0};

V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_a_244)));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = (g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(v_xs_242));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_entry, 1, 0};

V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(v_t_246));
    V v_t_248 = (g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(v_xs_242));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_247, v_t_248));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2eglobalsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eglobalsGo_entry, 1, 0};

V g_heff_2ecompile_2eir_2eglobalsGo(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    V v_g_242 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_g_242, NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_args_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(v_f_245));
    V v_t_248 = ({ V a_0 = v_args_246; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_246); r_; });
    return (g_heff_2ecompile_2eir_2eappendI(v_t_247, v_t_248));
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eir_2eglobalsGo(v_a_2410));
    V v_t_2413 = (g_heff_2ecompile_2eir_2eglobalsGo(v_b_2411));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2412, v_t_2413));
  }
  case TAG_ERecord: {
    V v_fs_2414 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    return ({ V a_0 = v_fs_2414; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(a_0)); heff_drop(v_fs_2414); r_; });
  }
  case TAG_EProj: {
    V v_e2_2416 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 4);
    V t_0 = v_e2_2416;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2421 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 3);
    return ({ V a_0 = v_args_2421; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_2421); r_; });
  }
  case TAG_EMatch: {
    V v_s_2423 = heff_field(v_x1_240, 0);
    V v_arms_2424 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_2425 = (g_heff_2ecompile_2eir_2eglobalsGo(v_s_2423));
    V v_t_2426 = ({ V a_0 = v_arms_2424; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(a_0)); heff_drop(v_arms_2424); r_; });
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2425, v_t_2426));
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_args_2429 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return ({ V a_0 = v_args_2429; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_2429); r_; });
  }
  case TAG_ECall: {
    V v_g_2430 = heff_field(v_x1_240, 0);
    V v_args_2431 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2432 = ({ V a_0 = v_args_2431; V r_ = (g_heff_2ecompile_2eir_2econcatMapI_24s682657916x1861919614(a_0)); heff_drop(v_args_2431); r_; });
    return heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_Cons, 2, (V[]){v_g_2430, v_t_2432});
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eglobalsGo(a[0]);
}
Clo g_heff_2ecompile_2eir_2eallI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eallI_entry, 1, 0};

V g_heff_2ecompile_2eir_2eallI(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_b_241 = heff_field(v_x1_240, 0);
    V v_bs_242 = heff_field(v_x1_240, 1);
    if ((heff_dup(v_b_241) == NTAG(TAG_True))) {
      V t_0 = v_bs_242;
      v_x1_240 = t_0;
      goto top;
    } else {
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2eallI(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2eisValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eisValue_entry, 1, 0};

V g_heff_2ecompile_2eir_2eisValue(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2410 = heff_field(v_x1_240, 0);
    V v_t_2412 = (g_list_2emap_24s1044393341x1523302351(heff_dup(v_fs_2410)));
    return ({ V a_0 = v_t_2412; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2412); r_; });
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_args_2418 = heff_field(v_x1_240, 1);
    V v_t_2420 = (g_list_2emap_24s584454411x1006678865(heff_dup(v_args_2418)));
    return ({ V a_0 = v_t_2420; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2420); r_; });
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2eisValue(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eir_2espine_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EGlobal: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ELam: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_e_240, 0);
    V v_args_246 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    HeffT2 v_t_247 = (g_heff_2ecompile_2eir_2espine_24cpr(v_f_245));
    {
      V v_field_248 = v_t_247.f[0];
      V v_field_249 = v_t_247.f[1];
      V v_h_2410 = v_field_248;
      V v_bs_2411 = v_field_249;
      V v_f_2412 = (g_heff_2ecompile_2eir_2eappendI(v_bs_2411, v_args_246));
      return ((HeffT2){{v_h_2410, v_f_2412}});
    }
  }
  case TAG_ELet: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ERecord: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EProj: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ETag: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EMatch: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EPrim: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EPrimCall: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_ECall: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EInt: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFloat: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EStr: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EBytes: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFixed: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFloat32: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  case TAG_EFix: {
    return ((HeffT2){{v_e_240, NTAG(TAG_Nil)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}