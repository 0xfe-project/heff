// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
HeffT2 g_regex_2ecountAt_2enumberAt_240_2edigits_241_24cpr(V, V, V);

HeffT2 g_regex_2ecountAt_2enumberAt_240_2edigits_241_24cpr(V v_s_240, V v_j_241, V v_n_242) {
top: ;
  if ((heff_intLt_c(heff_dup(v_j_241), heff_strLength_lent(v_s_240, 0)) && ((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) <= ((int64_t)57ULL))))) {
    V v_t_243;
    if (heff_intLt_c_lent(v_n_242, MK_INT(0LL), 2)) {
      heff_drop(v_n_242);
      v_t_243 = MK_INT(0LL);
    } else {
      v_t_243 = v_n_242;
    }
    V v_t_244 = heff_intAdd(heff_intMul(v_t_243, MK_INT(10LL)), heff_strByteAt_lent(v_s_240, v_j_241, 0));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
    V t_2 = heff_intSub(v_t_244, MK_INT(48LL));
    v_s_240 = t_0;
    v_j_241 = t_1;
    v_n_242 = t_2;
    goto top;
  } else {
    return ((HeffT2){{v_n_242, v_j_241}});
  }
}