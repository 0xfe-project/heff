// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_BDelayedBy 11524
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_HGlobal 55847
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_MkAbs 54862
#define TAG_MkAlt 55173
#define TAG_MkChk 56962
#define TAG_MkEquation 38417
#define TAG_MkSt 48854
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_Named 2049
#define TAG_NamedImplicit 12352
#define TAG_NamedInstance 32632
#define TAG_Nom 25944
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIsTy 43896
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9005
#define TAG_SU 9427
#define TAG_SpId 35501
#define TAG_TInf 28962
#define TAG_Throw 56084
#define TAG_VOpaque 37311
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_diags 296935042
#define LBL_elabFor 712452832
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_globals 352931696
#define LBL_head 9693863
#define LBL_hidden 729654485
#define LBL_implicit 319715269
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_level 304224158
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_order 307364712
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_tests 311609915
#define LBL_tm 10464
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_typ 324869
#define LBL_val 326043
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_key__module[] = {LBL_key, LBL_module};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
static uint32_t shape_name__ty__tm__prim[] = {LBL_name, LBL_ty, LBL_tm, LBL_prim};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eenvironment_2eemptyScope_get(void);
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2erules_2eabandonChk(V);
V g_heff_2eelab_2erules_2eabandonChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eabandonChk_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
HeffT1 g_heff_2eelab_2erules_2eautoRec_24cpr(V, V, V);
V g_heff_2eelab_2erules_2ebindingSyn(V, V);
V g_heff_2eelab_2erules_2ebindingSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ebindingSyn_clo;
V g_heff_2eelab_2erules_2ecaseLet(V, V, V);
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseLet_clo;
V g_heff_2eelab_2erules_2efunctionFormation(V, V);
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionFormation_clo;
V g_heff_2eelab_2erules_2efunctionIntro(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntro_clo;
V g_heff_2eelab_2erules_2efunctionIntroAnn(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo;
V g_heff_2eelab_2erules_2efunctionIntroImplicit(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo;
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
HeffT1 g_heff_2eelab_2erules_2eimplicitLams_24cpr(V);
V g_heff_2eelab_2erules_2eimplicitLams_24tok1(V, V);
V g_heff_2eelab_2erules_2eimplicitLams_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_24tok1_clo;
V g_heff_2eelab_2erules_2elazyChk(V, V, V);
V g_heff_2eelab_2erules_2elazyChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elazyChk_clo;
V g_heff_2eelab_2erules_2ementionsLocal(V);
V g_heff_2eelab_2erules_2ementionsLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsLocal_clo;
V g_heff_2eelab_2erules_2erecordIntro(V, V);
V g_heff_2eelab_2erules_2erecordIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordIntro_clo;
V g_heff_2eelab_2erules_2etagChk(V, V, V, V, V);
V g_heff_2eelab_2erules_2etagChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagChk_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934(V);
V g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934_clo;
V g_heff_2eelab_2etoplevel_2ebasicPrimNames_get(void);
V g_heff_2eelab_2etoplevel_2ebodyEnv(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyEnv_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyEnv_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
HeffT1 g_heff_2eelab_2etoplevel_2echkHeadOf_24cpr(V, V);
V g_heff_2eelab_2etoplevel_2edeclJ(V);
V g_heff_2eelab_2etoplevel_2edeclJ_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edeclJ_clo;
V g_heff_2eelab_2etoplevel_2edefineD(V, V, V, V);
V g_heff_2eelab_2etoplevel_2edefineD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edefineD_clo;
V g_heff_2eelab_2etoplevel_2edoPat(V);
V g_heff_2eelab_2etoplevel_2edoPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edoPat_clo;
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_clo;
V g_heff_2eelab_2etoplevel_2eelabWatch(V, V);
V g_heff_2eelab_2etoplevel_2eelabWatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabWatch_clo;
V g_heff_2eelab_2etoplevel_2eequationsD(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eequationsD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eequationsD_clo;
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eeveryImplicitIn_clo;
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(V, V);
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_clo;
V g_heff_2eelab_2etoplevel_2ehasOpPat(V);
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036(V, V, V);
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_clo;
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009(V, V);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_clo;
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(V, V);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_clo;
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2enubInt_24dps(V, V);
V g_heff_2eelab_2etoplevel_2enubInt_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_24dps_clo;
V g_heff_2eelab_2etoplevel_2eonceEach(V, V);
V g_heff_2eelab_2etoplevel_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eonceEach_clo;
V g_heff_2eelab_2etoplevel_2eopPat(V, V);
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eopPat_clo;
V g_heff_2eelab_2etoplevel_2epairOfHoles(V);
V g_heff_2eelab_2etoplevel_2epairOfHoles_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epairOfHoles_clo;
HeffT2 g_heff_2eelab_2etoplevel_2eparamsOf_24cpr(V, V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown(V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo;
V g_heff_2eelab_2etoplevel_2eprimNames_get(void);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2(V, V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_clo;
V g_heff_2eelab_2etoplevel_2esearchedInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2esearchedInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2esearchedInstance_clo;
V g_heff_2eelab_2etoplevel_2etheoryD(V, V, V);
V g_heff_2eelab_2etoplevel_2etheoryD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etheoryD_clo;
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo;
V g_heff_2eelab_2etoplevel_2etupleFront(V, V);
V g_heff_2eelab_2etoplevel_2etupleFront_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleFront_clo;
V g_heff_2eelab_2etoplevel_2etupleValueRev(V, V);
V g_heff_2eelab_2etoplevel_2etupleValueRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleValueRev_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2ewatchPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchPhase_clo;
V g_heff_2eelab_2etoplevel_2ewatchSyn(V);
V g_heff_2eelab_2etoplevel_2ewatchSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchSyn_clo;
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720(V, V);
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_clo;
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
V g_heff_2eelab_2etoplevel_2ewithOne_24tok2(V, V, V);
V g_heff_2eelab_2etoplevel_2ewithOne_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithOne_24tok2_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2einfSpineOf(V);
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2esurfaceprint_2eunIsTy(V);
V g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eunIsTy_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1547578820x1498276962(V, V);
V g_list_2eany_24s1547578820x1498276962_entry(V self, V *a);
extern Clo g_list_2eany_24s1547578820x1498276962_clo;
V g_list_2eany_24s752896332x1549544792(V, V);
V g_list_2eany_24s752896332x1549544792_entry(V self, V *a);
extern Clo g_list_2eany_24s752896332x1549544792_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s2115931744x466898799(V, V);
V g_list_2ekeepIf_24s2115931744x466898799_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2115931744x466898799_clo;
V g_list_2ekeepIf_24s512765522x2052101617(V, V);
V g_list_2ekeepIf_24s512765522x2052101617_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s512765522x2052101617_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s1157078602x1175067503(V, V, V);
V g_prelude_2etraverse_24s1157078602x1175067503_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1157078602x1175067503_clo;
V g_prelude_2etraverse_24s1797919465x75214466(V);
V g_prelude_2etraverse_24s1797919465x75214466_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1797919465x75214466_clo;
V g_prelude_2etraverse_24s189232456x1797852535(V);
V g_prelude_2etraverse_24s189232456x1797852535_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s189232456x1797852535_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2emap_2edelete_24s1614046289x1611773644(V, V);
V g_std_2emap_2edelete_24s1614046289x1611773644_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s1614046289x1611773644_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str2, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str3, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str4, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str5, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str6, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str7, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str8, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str9, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str10, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str11, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
V g_heff_2eelab_2etoplevel_2edoPat_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2edoPat_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoPat_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2edoPat_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam12(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edoPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoPat_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2edoPat(V v_p_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(heff_dup(v_p_240)));
  V v_t_242 = heff_get_n(v_t_241, 0, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_At: {
    V v_it1_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_PatVar: {
      V v_it11_245 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 1);
      if (heff_strEq_c(v_it11_245, ((V)&g_heff_2eelab_2etoplevel_2edoPat_str0))) {
        heff_drop(v_p_240);
        return ((V)&g_heff_2eelab_2etoplevel_2edoPat_lam0_clo);
      } else {
        return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam1, 2, 1, (V[]){v_p_240});
      }
    }
    case TAG_PatTag: {
      V v_x_2420 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 3);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam2, 2, 2, (V[]){v_p_240, v_x_2420});
    }
    case TAG_PatOp: {
      heff_take_n(v_it1_243, 0ULL, 3);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam4, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatInt: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam5, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatFloat: {
      heff_take_na(v_it1_243, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam6, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatString: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam7, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatBinary: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam8, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatRune: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam9, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatRecord: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam10, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatWord: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam11, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatAs: {
      heff_take_n(v_it1_243, 0ULL, 3);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam12, 2, 1, (V[]){v_p_240});
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2etoplevel_2edoPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2edoPat(a[0]);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2eelab_2etoplevel_2edoPat_str1), NTAG(TAG_Nil)});
  V f_ = v_k_247;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k2_2410 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2411 = heff_take_field(v_hd_249, 1);
  V v_malg_2412 = heff_get_n(v_hd_249, 2, 3);
  V v_t_2415;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_2414 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_2415 = v_s_2414;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str2), v_t_2415, NTAG(TAG_Nothing)});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(v_malg_2412, 1, (V[]){v_t_2418}));
  V f_ = v_bind_2411;
  args[0] = v_t_2419;
  args[1] = v_k2_2410;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2424 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2424;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2420, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam2(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_p_240 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(v_p_240));
  return (g_prelude_2etraverse_24s1157078602x1175067503(heff_get_n(v_t_2425, 1, 2), v_hd_2423, heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam3, 1, 2, (V[]){v_k_2424, v_x_2420})));
}
V g_heff_2eelab_2etoplevel_2edoPat_lam4(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k2_2431 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2432 = heff_take_field(v_hd_2430, 1);
  V v_malg_2433 = heff_get_n(v_hd_2430, 2, 3);
  V v_t_2436;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_2435 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_2436 = v_s_2435;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str3), v_t_2436, NTAG(TAG_Nothing)});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tr(heff_call(v_malg_2433, 1, (V[]){v_t_2439}));
  V f_ = v_bind_2432;
  args[0] = v_t_2440;
  args[1] = v_k2_2431;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam5(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k2_2443 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2444 = heff_take_field(v_hd_2442, 1);
  V v_malg_2445 = heff_get_n(v_hd_2442, 2, 3);
  V v_t_2448;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_2447 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_2448 = v_s_2447;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2449 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str4), v_t_2448, NTAG(TAG_Nothing)});
  V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tr(heff_call(v_malg_2445, 1, (V[]){v_t_2451}));
  V f_ = v_bind_2444;
  args[0] = v_t_2452;
  args[1] = v_k2_2443;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam6(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k2_2455 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2456 = heff_take_field(v_hd_2454, 1);
  V v_malg_2457 = heff_get_n(v_hd_2454, 2, 3);
  V v_t_2460;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_2459 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_2460 = v_s_2459;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2461 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str5), v_t_2460, NTAG(TAG_Nothing)});
  V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tr(heff_call(v_malg_2457, 1, (V[]){v_t_2463}));
  V f_ = v_bind_2456;
  args[0] = v_t_2464;
  args[1] = v_k2_2455;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam7(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k2_2467 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2468 = heff_take_field(v_hd_2466, 1);
  V v_malg_2469 = heff_get_n(v_hd_2466, 2, 3);
  V v_t_2472;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_2471 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_2472 = v_s_2471;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2473 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str6), v_t_2472, NTAG(TAG_Nothing)});
  V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tr(heff_call(v_malg_2469, 1, (V[]){v_t_2475}));
  V f_ = v_bind_2468;
  args[0] = v_t_2476;
  args[1] = v_k2_2467;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam8(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k2_2479 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2480 = heff_take_field(v_hd_2478, 1);
  V v_malg_2481 = heff_get_n(v_hd_2478, 2, 3);
  V v_t_2484;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_2483 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_2484 = v_s_2483;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2485 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str7), v_t_2484, NTAG(TAG_Nothing)});
  V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tr(heff_call(v_malg_2481, 1, (V[]){v_t_2487}));
  V f_ = v_bind_2480;
  args[0] = v_t_2488;
  args[1] = v_k2_2479;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam9(V self, V *args) {
  V v_hd_2490 = args[0];
  V v_k2_2491 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2492 = heff_take_field(v_hd_2490, 1);
  V v_malg_2493 = heff_get_n(v_hd_2490, 2, 3);
  V v_t_2496;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_2495 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_2496 = v_s_2495;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2497 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str8), v_t_2496, NTAG(TAG_Nothing)});
  V v_t_2498 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tr(heff_call(v_malg_2493, 1, (V[]){v_t_2499}));
  V f_ = v_bind_2492;
  args[0] = v_t_24100;
  args[1] = v_k2_2491;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam10(V self, V *args) {
  V v_hd_24102 = args[0];
  V v_k2_24103 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_24104 = heff_take_field(v_hd_24102, 1);
  V v_malg_24105 = heff_get_n(v_hd_24102, 2, 3);
  V v_t_24108;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_24107 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_24108 = v_s_24107;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_24109 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str9), v_t_24108, NTAG(TAG_Nothing)});
  V v_t_24110 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
  V v_t_24112 = heff_tr(heff_call(v_malg_24105, 1, (V[]){v_t_24111}));
  V f_ = v_bind_24104;
  args[0] = v_t_24112;
  args[1] = v_k2_24103;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam11(V self, V *args) {
  V v_hd_24114 = args[0];
  V v_k2_24115 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_24116 = heff_take_field(v_hd_24114, 1);
  V v_malg_24117 = heff_get_n(v_hd_24114, 2, 3);
  V v_t_24120;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_24119 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_24120 = v_s_24119;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_24121 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str10), v_t_24120, NTAG(TAG_Nothing)});
  V v_t_24122 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24121})});
  V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
  V v_t_24124 = heff_tr(heff_call(v_malg_24117, 1, (V[]){v_t_24123}));
  V f_ = v_bind_24116;
  args[0] = v_t_24124;
  args[1] = v_k2_24115;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam12(V self, V *args) {
  V v_hd_24128 = args[0];
  V v_k2_24129 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_24130 = heff_take_field(v_hd_24128, 1);
  V v_malg_24131 = heff_get_n(v_hd_24128, 2, 3);
  V v_t_24134;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_24133 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_24134 = v_s_24133;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_24135 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str11), v_t_24134, NTAG(TAG_Nothing)});
  V v_t_24136 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24135})});
  V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
  V v_t_24138 = heff_tr(heff_call(v_malg_24131, 1, (V[]){v_t_24137}));
  V f_ = v_bind_24130;
  args[0] = v_t_24138;
  args[1] = v_k2_24129;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}

HeffT2 g_heff_2eelab_2etoplevel_2eparamsOf_24cpr(V v_i_240, V v_e_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SU: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SDecode: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SFunction: {
    V v_cod_247 = heff_field(v_x3_242, 2);
    V v_x34_248 = heff_field(v_x3_242, 3);
    heff_take_n(v_x3_242, 12ULL, 5);
    switch (heff_tag_of(v_x34_248)) {
    case TAG_Expl: {
      V v_t_2413;
      switch (heff_tag_of(v_cod_247)) {
      case TAG_MkAbs: {
        V v_t_2411 = heff_field(v_cod_247, 1);
        heff_take_n(v_cod_247, 2ULL, 2);
        v_t_2413 = v_t_2411;
        break;
      }
      case TAG_AbsConst: {
        V v_t_2412 = heff_field(v_cod_247, 0);
        heff_take_n(v_cod_247, 1ULL, 1);
        v_t_2413 = v_t_2412;
        break;
      }
      default: heff_nomatch(v_cod_247);
      }
      V t_0 = v_i_240;
      V t_1 = heff_intAdd(v_e_241, MK_INT(1LL));
      V t_2 = v_t_2413;
      v_i_240 = t_0;
      v_e_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Impl: {
      if (heff_intLt_c_lent(MK_INT(0LL), v_e_241, 1)) {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        heff_drop(v_cod_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V v_t_2417;
        switch (heff_tag_of(v_cod_247)) {
        case TAG_MkAbs: {
          V v_t_2415 = heff_field(v_cod_247, 1);
          heff_take_n(v_cod_247, 2ULL, 2);
          v_t_2417 = v_t_2415;
          break;
        }
        case TAG_AbsConst: {
          V v_t_2416 = heff_field(v_cod_247, 0);
          heff_take_n(v_cod_247, 1ULL, 1);
          v_t_2417 = v_t_2416;
          break;
        }
        default: heff_nomatch(v_cod_247);
        }
        V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
        V t_1 = v_e_241;
        V t_2 = v_t_2417;
        v_i_240 = t_0;
        v_e_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_Inst: {
      heff_drop(v_i_240);
      heff_drop(v_e_241);
      heff_drop(v_cod_247);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x34_248)}});
    }
  }
  case TAG_SRecord: {
    heff_take_n(v_x3_242, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SSum: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SIsTy: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SPrimInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SPrimFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SPrimString: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SPrimRune: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SPrimArray: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SFixed: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_249 = (g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187(v_a_247));
        v_a_2410 = heff_bool(!(heff_dup(v_a_249) == NTAG(TAG_True)));
        heff_drop(v_a_249);
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if (!(heff_dup(v_a_2410) == NTAG(TAG_True))) {
      heff_drop(v_a_2410);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_a_2410);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2etupleFront_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etupleFront_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etupleFront(V v_sp_240, V v_rs_241) {
top: ;
  switch (heff_tag_of(v_rs_241)) {
  case TAG_Nil: {
    V v_i_2410;
    switch (heff_tag_of(v_rs_241)) {
    case TAG_Nil: {
      V v_t_242 = heff_tag_n(TAG_ITuple, 1, (V[]){NTAG(TAG_Nil)});
      v_i_2410 = heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_sp_240});
      break;
    }
    case TAG_Cons: {
      V v_r_243 = heff_dup(heff_field(v_rs_241, 0));
      V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rs_241));
      V v_t_248;
      switch (heff_tag_of(v_r_243)) {
      case TAG_At: {
        V v_s_247 = heff_field(v_r_243, 1);
        heff_take_n(v_r_243, 2ULL, 2);
        v_t_248 = v_s_247;
        break;
      }
      default: heff_nomatch(v_r_243);
      }
      V v_t_249 = ({ V rv_1 = heff_get_n(v_t_248, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      v_i_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ITuple, 1, (V[]){v_t_245}), v_t_249});
      break;
    }
    default: heff_nomatch(v_rs_241);
    }
    V v_t_2413;
    switch (heff_tag_of(v_i_2410)) {
    case TAG_At: {
      V v_s_2412 = heff_dup(heff_field(v_i_2410, 1));
      v_t_2413 = v_s_2412;
      break;
    }
    default: heff_nomatch(v_i_2410);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2410}), v_t_2413});
  }
  case TAG_Cons: {
    V v_rs2_2415 = heff_dup(heff_field(v_rs_241, 1));
    switch (heff_tag_of(v_rs2_2415)) {
    case TAG_Nil: {
      heff_drop_rec(v_sp_240, 2);
      switch (heff_tag_of(v_rs_241)) {
      case TAG_Cons: {
        V v_a_2416 = heff_field(v_rs_241, 0);
        heff_take_n(v_rs_241, 1ULL, 2);
        return v_a_2416;
      }
      default: return heff_nomatch(v_rs_241);
      }
    }
    case TAG_Cons: {
      V v_ru_24rs2_2415_24Cons = heff_take_reuse_n(v_rs2_2415, 0ULL, 2);
      V v_i_2428;
      switch (heff_tag_of(v_rs_241)) {
      case TAG_Nil: {
        V v_t_2420 = heff_tag_n(TAG_ITuple, 1, (V[]){NTAG(TAG_Nil)});
        v_i_2428 = heff_tag_at_n(v_ru_24rs2_2415_24Cons, TAG_At, 2, (V[]){v_t_2420, v_sp_240});
        break;
      }
      case TAG_Cons: {
        V v_r_2421 = heff_dup(heff_field(v_rs_241, 0));
        V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rs_241));
        V v_t_2426;
        switch (heff_tag_of(v_r_2421)) {
        case TAG_At: {
          V v_s_2425 = heff_field(v_r_2421, 1);
          heff_take_n(v_r_2421, 2ULL, 2);
          v_t_2426 = v_s_2425;
          break;
        }
        default: heff_nomatch(v_r_2421);
        }
        V v_t_2427 = ({ V rv_1 = heff_get_n(v_t_2426, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        v_i_2428 = heff_tag_at_n(v_ru_24rs2_2415_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_ITuple, 1, (V[]){v_t_2423}), v_t_2427});
        break;
      }
      default: heff_nomatch(v_rs_241);
      }
      V v_t_2431;
      switch (heff_tag_of(v_i_2428)) {
      case TAG_At: {
        V v_s_2430 = heff_dup(heff_field(v_i_2428, 1));
        v_t_2431 = v_s_2430;
        break;
      }
      default: heff_nomatch(v_i_2428);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2428}), v_t_2431});
    }
    default: return heff_nomatch(v_rs2_2415);
    }
  }
  default: return heff_nomatch(v_rs_241);
  }
}
V g_heff_2eelab_2etoplevel_2etupleFront_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etupleFront(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleValueRev_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleValueRev_str1, 12, "builtin.Unit");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleValueRev_str2, 6, "MkPair");
Clo g_heff_2eelab_2etoplevel_2etupleValueRev_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etupleValueRev_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etupleValueRev(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleValueRev_str0), heff_dup(v_sp_240), NTAG(TAG_Nil)});
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleValueRev_str1)}), heff_dup(v_sp_240)});
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_t_243}), heff_dup(v_sp_240)});
    V v_t_245 = heff_tag_n(TAG_IAnn, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_242, heff_dup(v_sp_240)}), v_t_244});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_240});
  }
  case TAG_Cons: {
    V v_z_246 = heff_field(v_x2_241, 0);
    V v_rs_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = (g_heff_2eelab_2etoplevel_2etupleFront(heff_dup(v_sp_240), v_rs_247));
    V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_z_246, NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleValueRev_str2), heff_dup(v_sp_240), heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_249})});
    V v_t_2411 = (g_heff_2eelab_2etoplevel_2epairOfHoles(heff_dup(v_sp_240)));
    V v_t_2412 = heff_tag_n(TAG_IAnn, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_240)}), v_t_2411});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_sp_240});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2etupleValueRev_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etupleValueRev(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_247;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        v_a_247 = (g_heff_2eelab_2etoplevel_2ehasOpPat(v_a_245));
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if (!(heff_dup(v_a_247) == NTAG(TAG_True))) {
      heff_drop(v_a_247);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_a_247);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934(a0); heff_drop(a0); return r;
}

HeffT1 g_heff_2eelab_2etoplevel_2echkHeadOf_24cpr(V v_n_240, V v_j_241) {
top: ;
  V v_t_2437;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_242 = heff_dup(heff_field(v_n_240, 0));
    switch (heff_tag_of(v_x11_242)) {
    case TAG_IVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    case TAG_IInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    case TAG_IFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    case TAG_IString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    case TAG_IBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    case TAG_IPrim: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_x11_242, 0ULL, 2);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_x11_242, 0ULL, 4);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    case TAG_IUpdate: {
      heff_take_n(v_x11_242, 0ULL, 2);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_x11_242, 0ULL, 4);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_x11_242, 0ULL, 3);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    case TAG_INominal: {
      V v_i_2428 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        v_t_2437 = v_i_2428;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_x11_242, 0ULL, 4);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    case TAG_ILazy: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    case TAG_ITuple: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2437 = heff_dup(v_n_240);
      break;
    }
    default: heff_nomatch(v_x11_242);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_t_2438 = (g_heff_2esyntax_2epresyntax_2einfSpineOf(v_t_2437));
  V v_t_2439 = heff_get_n(v_t_2438, 0, 2);
  switch (heff_tag_of(v_t_2439)) {
  case TAG_At: {
    V v_it1_2440 = heff_field(v_t_2439, 0);
    heff_take_n(v_t_2439, 1ULL, 2);
    switch (heff_tag_of(v_it1_2440)) {
    case TAG_IVar: {
      V v_x_2442 = heff_field(v_it1_2440, 0);
      heff_take_n(v_it1_2440, 1ULL, 1);
      V v_t_2445;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2444 = heff_dup(heff_field(v_n_240, 1));
        v_t_2445 = v_s_2444;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      V v_t_2448;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2447 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      V v_t_2449 = (g_heff_2eelab_2erules_2eapply(v_t_2448, v_j_241));
      return ({ V a_0 = v_t_2445; V a_1 = v_x_2442; V a_2 = v_t_2449; HeffT1 r_ = (g_heff_2eelab_2erules_2eautoRec_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2442); r_; });
    }
    case TAG_IInt: {
      heff_take_n(v_it1_2440, 0ULL, 1);
      V v_t_2453;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2452 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2453 = v_s_2452;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2453, v_j_241);
    }
    case TAG_IFloat: {
      heff_take_na(v_it1_2440, 0ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2456 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2457, v_j_241);
    }
    case TAG_IString: {
      heff_take_n(v_it1_2440, 0ULL, 1);
      V v_t_2461;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2460 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2461 = v_s_2460;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2461, v_j_241);
    }
    case TAG_IBytes: {
      heff_take_n(v_it1_2440, 0ULL, 1);
      V v_t_2465;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2464 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2465 = v_s_2464;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2465, v_j_241);
    }
    case TAG_IPrim: {
      heff_take_n(v_it1_2440, 0ULL, 1);
      V v_t_2469;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2468 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2469 = v_s_2468;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2469, v_j_241);
    }
    case TAG_IRune: {
      heff_take_n(v_it1_2440, 0ULL, 1);
      V v_t_2473;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2472 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2473 = v_s_2472;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2473, v_j_241);
    }
    case TAG_IApp: {
      heff_take_n(v_it1_2440, 0ULL, 2);
      V v_t_2478;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2477 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2478 = v_s_2477;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2478, v_j_241);
    }
    case TAG_IAnn: {
      heff_take_n(v_it1_2440, 0ULL, 2);
      V v_t_2483;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2482 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2483 = v_s_2482;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2483, v_j_241);
    }
    case TAG_ISpec: {
      heff_take_n(v_it1_2440, 0ULL, 4);
      V v_t_2490;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2489 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2490 = v_s_2489;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2490, v_j_241);
    }
    case TAG_IUpdate: {
      heff_take_n(v_it1_2440, 0ULL, 2);
      V v_t_2495;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2494 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2495 = v_s_2494;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2495, v_j_241);
    }
    case TAG_IAnnLam: {
      heff_take_n(v_it1_2440, 0ULL, 4);
      V v_t_24102;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_24101 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_24102 = v_s_24101;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_24102, v_j_241);
    }
    case TAG_IInvalid: {
      heff_take_n(v_it1_2440, 0ULL, 3);
      V v_t_24108;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_24107 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_24108 = v_s_24107;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_24108, v_j_241);
    }
    case TAG_INominal: {
      heff_take_n(v_it1_2440, 0ULL, 1);
      V v_t_24112;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_24111 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_24112 = v_s_24111;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_24112, v_j_241);
    }
    case TAG_ILitEq: {
      heff_take_n(v_it1_2440, 0ULL, 4);
      V v_t_24119;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_24118 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_24119 = v_s_24118;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_24119, v_j_241);
    }
    case TAG_ILazy: {
      heff_take_n(v_it1_2440, 0ULL, 1);
      V v_t_24123;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_24122 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_24123 = v_s_24122;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_24123, v_j_241);
    }
    case TAG_ITuple: {
      heff_take_n(v_it1_2440, 0ULL, 1);
      V v_t_24127;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_24126 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_24127 = v_s_24126;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_24127, v_j_241);
    }
    default: return ((HeffT1){{heff_nomatch(v_it1_2440)}});
    }
  }
  default: return ((HeffT1){{heff_nomatch(v_t_2439)}});
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam32(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam35(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam34(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam33(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam39(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam38(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam42(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam41(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam40(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam37(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam36(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam46(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam45(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam49(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam48(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam47(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam44(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam43(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam53(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam52(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam56(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam55(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam54(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam51(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam50(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam60(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam59(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam63(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam62(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam61(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam58(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam57(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam67(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam66(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam70(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam69(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam68(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam65(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam64(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam74(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam73(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam77(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam76(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam75(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam72(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam71(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam81(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam80(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam84(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam83(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam82(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam79(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam78(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam88(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam87(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam91(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam90(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam89(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam86(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam85(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam92(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam94(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam93(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_241 = heff_dup(heff_field(v_n_240, 0));
    switch (heff_tag_of(v_n1_241)) {
    case TAG_CInf: {
      heff_take_n(v_n1_241, 0ULL, 1);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_240);
    }
    case TAG_CType: {
      heff_take_n(v_n1_241, 0ULL, 1);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_240);
    }
    case TAG_CLam: {
      V v_x_245 = heff_field(v_n1_241, 0);
      V v_body_247 = heff_field(v_n1_241, 2);
      heff_take_n(v_n1_241, 5ULL, 3);
      V v_t_248 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_247));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0, 2, 3, (V[]){v_t_248, v_n_240, v_x_245});
    }
    case TAG_CImplicitLam: {
      V v_x_2416 = heff_field(v_n1_241, 0);
      V v_body_2418 = heff_field(v_n1_241, 2);
      heff_take_n(v_n1_241, 5ULL, 3);
      V v_t_2419 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_2418));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2, 2, 3, (V[]){v_t_2419, v_n_240, v_x_2416});
    }
    case TAG_CAnnLam: {
      V v_x_2427 = heff_field(v_n1_241, 0);
      V v_tyN_2429 = heff_field(v_n1_241, 2);
      V v_body_2430 = heff_field(v_n1_241, 3);
      heff_take_n(v_n1_241, 13ULL, 4);
      V v_c_2431 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_tyN_2429));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4, 2, 4, (V[]){v_c_2431, v_body_2430, v_n_240, v_x_2427});
    }
    case TAG_CTag: {
      V v_x_2441 = heff_field(v_n1_241, 0);
      V v_tsp_2442 = heff_field(v_n1_241, 1);
      V v_args_2443 = heff_field(v_n1_241, 2);
      heff_take_n(v_n1_241, 7ULL, 3);
      V v_c_2444 = (g_prelude_2etraverse_24s189232456x1797852535(v_args_2443));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7, 2, 4, (V[]){v_c_2444, v_n_240, v_tsp_2442, v_x_2441});
    }
    case TAG_CStruct: {
      V v_fields_2452 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_n2_2454 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        V v_c_2455 = (g_prelude_2etraverse_24s1797919465x75214466(v_fields_2452));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9, 2, 2, (V[]){v_c_2455, v_n2_2454});
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    case TAG_CMatch: {
      V v_scrutN_2460 = heff_field(v_n1_241, 0);
      V v_casesN_2461 = heff_field(v_n1_241, 1);
      heff_take_n(v_n1_241, 3ULL, 2);
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_n2_2463 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        V v_x1_2464 = (g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934(v_casesN_2461));
        if (!(heff_dup(v_x1_2464) == NTAG(TAG_True))) {
          heff_drop(v_x1_2464);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11, 2, 3, (V[]){v_casesN_2461, v_scrutN_2460, v_n2_2463});
        } else {
          heff_drop(v_x1_2464);
          return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_2463, NTAG(TAG_Nothing), v_scrutN_2460, v_casesN_2461));
        }
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    case TAG_CLetIn: {
      V v_rhsN_2489 = heff_field(v_n1_241, 0);
      V v_alt0_2490 = heff_field(v_n1_241, 1);
      V v_ru_24n1_241_24CLetIn = heff_take_reuse_n(v_n1_241, 3ULL, 2);
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_n2_2492 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        switch (heff_tag_of(v_alt0_2490)) {
        case TAG_At: {
          V v_it1_2493 = heff_dup(heff_field(v_alt0_2490, 0));
          switch (heff_tag_of(v_it1_2493)) {
          case TAG_MkAlt: {
            V v_it11_2495 = heff_field(v_it1_2493, 0);
            V v_bodyN_2496 = heff_field(v_it1_2493, 1);
            heff_take_n(v_it1_2493, 3ULL, 2);
            switch (heff_tag_of(v_it11_2495)) {
            case TAG_At: {
              V v_it111_2497 = heff_dup(heff_field(v_it11_2495, 0));
              switch (heff_tag_of(v_it111_2497)) {
              case TAG_PatVar: {
                V v_x_2499 = heff_field(v_it111_2497, 0);
                heff_take_n(v_it111_2497, 1ULL, 1);
                heff_drop_tag(v_alt0_2490, 2);
                heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                heff_drop(v_n2_2492);
                switch (heff_tag_of(v_it11_2495)) {
                case TAG_At: {
                  heff_take_n(v_it11_2495, 0ULL, 2);
                  V v_c_24102 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_rhsN_2489));
                  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19, 2, 3, (V[]){v_c_24102, v_bodyN_2496, v_x_2499});
                }
                default: return heff_nomatch(v_it11_2495);
                }
              }
              case TAG_PatTag: {
                heff_take_n(v_it111_2497, 0ULL, 3);
                heff_drop(v_bodyN_2496);
                V v_t_24116;
                switch (heff_tag_of(v_alt0_2490)) {
                case TAG_At: {
                  V v_x11_24112 = heff_dup(heff_field(v_alt0_2490, 0));
                  switch (heff_tag_of(v_x11_24112)) {
                  case TAG_MkAlt: {
                    V v_p_24114 = heff_field(v_x11_24112, 0);
                    heff_take_n(v_x11_24112, 1ULL, 2);
                    v_t_24116 = ({ V a_0 = v_p_24114; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24114); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x11_24112);
                  }
                  break;
                }
                default: heff_nomatch(v_alt0_2490);
                }
                if ((heff_dup(v_t_24116) == NTAG(TAG_True))) {
                  heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                  heff_drop_tag(v_it11_2495, 2);
                  heff_drop(v_t_24116);
                  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492});
                } else {
                  heff_drop(v_t_24116);
                  V v_t_24140 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2495}));
                  V v_t_24141 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2490, NTAG(TAG_Nil)});
                  return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_2492, heff_tag_n(TAG_Just, 1, (V[]){v_t_24140}), v_rhsN_2489, v_t_24141));
                }
              }
              case TAG_PatOp: {
                heff_take_n(v_it111_2497, 0ULL, 3);
                heff_drop(v_bodyN_2496);
                V v_t_24149;
                switch (heff_tag_of(v_alt0_2490)) {
                case TAG_At: {
                  V v_x11_24145 = heff_dup(heff_field(v_alt0_2490, 0));
                  switch (heff_tag_of(v_x11_24145)) {
                  case TAG_MkAlt: {
                    V v_p_24147 = heff_field(v_x11_24145, 0);
                    heff_take_n(v_x11_24145, 1ULL, 2);
                    v_t_24149 = ({ V a_0 = v_p_24147; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24147); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x11_24145);
                  }
                  break;
                }
                default: heff_nomatch(v_alt0_2490);
                }
                if ((heff_dup(v_t_24149) == NTAG(TAG_True))) {
                  heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                  heff_drop_tag(v_it11_2495, 2);
                  heff_drop(v_t_24149);
                  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492});
                } else {
                  heff_drop(v_t_24149);
                  V v_t_24173 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2495}));
                  V v_t_24174 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2490, NTAG(TAG_Nil)});
                  return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_2492, heff_tag_n(TAG_Just, 1, (V[]){v_t_24173}), v_rhsN_2489, v_t_24174));
                }
              }
              case TAG_PatInt: {
                V v_ru_24it111_2497_24PatInt = heff_take_reuse_n(v_it111_2497, 0ULL, 1);
                heff_drop(v_bodyN_2496);
                V v_t_24180;
                switch (heff_tag_of(v_alt0_2490)) {
                case TAG_At: {
                  V v_x11_24176 = heff_dup(heff_field(v_alt0_2490, 0));
                  switch (heff_tag_of(v_x11_24176)) {
                  case TAG_MkAlt: {
                    V v_p_24178 = heff_field(v_x11_24176, 0);
                    heff_take_n(v_x11_24176, 1ULL, 2);
                    v_t_24180 = ({ V a_0 = v_p_24178; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24178); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x11_24176);
                  }
                  break;
                }
                default: heff_nomatch(v_alt0_2490);
                }
                if ((heff_dup(v_t_24180) == NTAG(TAG_True))) {
                  heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                  heff_drop_tag(v_it11_2495, 2);
                  heff_drop_cell(v_ru_24it111_2497_24PatInt, 1);
                  heff_drop(v_t_24180);
                  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam36, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492});
                } else {
                  heff_drop(v_t_24180);
                  V v_t_24204 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2495}));
                  V v_t_24205 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2490, NTAG(TAG_Nil)});
                  return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_2492, heff_tag_at_n(v_ru_24it111_2497_24PatInt, TAG_Just, 1, (V[]){v_t_24204}), v_rhsN_2489, v_t_24205));
                }
              }
              case TAG_PatFloat: {
                V v_ru_24it111_2497_24PatFloat = heff_take_reuse_na(v_it111_2497, 0ULL, 1);
                heff_drop(v_bodyN_2496);
                V v_t_24211;
                switch (heff_tag_of(v_alt0_2490)) {
                case TAG_At: {
                  V v_x11_24207 = heff_dup(heff_field(v_alt0_2490, 0));
                  switch (heff_tag_of(v_x11_24207)) {
                  case TAG_MkAlt: {
                    V v_p_24209 = heff_field(v_x11_24207, 0);
                    heff_take_n(v_x11_24207, 1ULL, 2);
                    v_t_24211 = ({ V a_0 = v_p_24209; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24209); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x11_24207);
                  }
                  break;
                }
                default: heff_nomatch(v_alt0_2490);
                }
                if ((heff_dup(v_t_24211) == NTAG(TAG_True))) {
                  heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                  heff_drop_tag(v_it11_2495, 2);
                  heff_drop_cell(v_ru_24it111_2497_24PatFloat, 1);
                  heff_drop(v_t_24211);
                  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam43, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492});
                } else {
                  heff_drop(v_t_24211);
                  V v_t_24235 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2495}));
                  V v_t_24236 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2490, NTAG(TAG_Nil)});
                  return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_2492, heff_tag_at_n(v_ru_24it111_2497_24PatFloat, TAG_Just, 1, (V[]){v_t_24235}), v_rhsN_2489, v_t_24236));
                }
              }
              case TAG_PatString: {
                V v_ru_24it111_2497_24PatString = heff_take_reuse_n(v_it111_2497, 0ULL, 1);
                heff_drop(v_bodyN_2496);
                V v_t_24242;
                switch (heff_tag_of(v_alt0_2490)) {
                case TAG_At: {
                  V v_x11_24238 = heff_dup(heff_field(v_alt0_2490, 0));
                  switch (heff_tag_of(v_x11_24238)) {
                  case TAG_MkAlt: {
                    V v_p_24240 = heff_field(v_x11_24238, 0);
                    heff_take_n(v_x11_24238, 1ULL, 2);
                    v_t_24242 = ({ V a_0 = v_p_24240; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24240); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x11_24238);
                  }
                  break;
                }
                default: heff_nomatch(v_alt0_2490);
                }
                if ((heff_dup(v_t_24242) == NTAG(TAG_True))) {
                  heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                  heff_drop_tag(v_it11_2495, 2);
                  heff_drop_cell(v_ru_24it111_2497_24PatString, 1);
                  heff_drop(v_t_24242);
                  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam50, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492});
                } else {
                  heff_drop(v_t_24242);
                  V v_t_24266 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2495}));
                  V v_t_24267 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2490, NTAG(TAG_Nil)});
                  return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_2492, heff_tag_at_n(v_ru_24it111_2497_24PatString, TAG_Just, 1, (V[]){v_t_24266}), v_rhsN_2489, v_t_24267));
                }
              }
              case TAG_PatBinary: {
                V v_ru_24it111_2497_24PatBinary = heff_take_reuse_n(v_it111_2497, 0ULL, 1);
                heff_drop(v_bodyN_2496);
                V v_t_24273;
                switch (heff_tag_of(v_alt0_2490)) {
                case TAG_At: {
                  V v_x11_24269 = heff_dup(heff_field(v_alt0_2490, 0));
                  switch (heff_tag_of(v_x11_24269)) {
                  case TAG_MkAlt: {
                    V v_p_24271 = heff_field(v_x11_24269, 0);
                    heff_take_n(v_x11_24269, 1ULL, 2);
                    v_t_24273 = ({ V a_0 = v_p_24271; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24271); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x11_24269);
                  }
                  break;
                }
                default: heff_nomatch(v_alt0_2490);
                }
                if ((heff_dup(v_t_24273) == NTAG(TAG_True))) {
                  heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                  heff_drop_tag(v_it11_2495, 2);
                  heff_drop_cell(v_ru_24it111_2497_24PatBinary, 1);
                  heff_drop(v_t_24273);
                  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam57, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492});
                } else {
                  heff_drop(v_t_24273);
                  V v_t_24297 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2495}));
                  V v_t_24298 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2490, NTAG(TAG_Nil)});
                  return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_2492, heff_tag_at_n(v_ru_24it111_2497_24PatBinary, TAG_Just, 1, (V[]){v_t_24297}), v_rhsN_2489, v_t_24298));
                }
              }
              case TAG_PatRune: {
                V v_ru_24it111_2497_24PatRune = heff_take_reuse_n(v_it111_2497, 0ULL, 1);
                heff_drop(v_bodyN_2496);
                V v_t_24304;
                switch (heff_tag_of(v_alt0_2490)) {
                case TAG_At: {
                  V v_x11_24300 = heff_dup(heff_field(v_alt0_2490, 0));
                  switch (heff_tag_of(v_x11_24300)) {
                  case TAG_MkAlt: {
                    V v_p_24302 = heff_field(v_x11_24300, 0);
                    heff_take_n(v_x11_24300, 1ULL, 2);
                    v_t_24304 = ({ V a_0 = v_p_24302; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24302); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x11_24300);
                  }
                  break;
                }
                default: heff_nomatch(v_alt0_2490);
                }
                if ((heff_dup(v_t_24304) == NTAG(TAG_True))) {
                  heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                  heff_drop_tag(v_it11_2495, 2);
                  heff_drop_cell(v_ru_24it111_2497_24PatRune, 1);
                  heff_drop(v_t_24304);
                  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam64, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492});
                } else {
                  heff_drop(v_t_24304);
                  V v_t_24328 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2495}));
                  V v_t_24329 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2490, NTAG(TAG_Nil)});
                  return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_2492, heff_tag_at_n(v_ru_24it111_2497_24PatRune, TAG_Just, 1, (V[]){v_t_24328}), v_rhsN_2489, v_t_24329));
                }
              }
              case TAG_PatRecord: {
                V v_ru_24it111_2497_24PatRecord = heff_take_reuse_n(v_it111_2497, 0ULL, 1);
                heff_drop(v_bodyN_2496);
                V v_t_24335;
                switch (heff_tag_of(v_alt0_2490)) {
                case TAG_At: {
                  V v_x11_24331 = heff_dup(heff_field(v_alt0_2490, 0));
                  switch (heff_tag_of(v_x11_24331)) {
                  case TAG_MkAlt: {
                    V v_p_24333 = heff_field(v_x11_24331, 0);
                    heff_take_n(v_x11_24331, 1ULL, 2);
                    v_t_24335 = ({ V a_0 = v_p_24333; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24333); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x11_24331);
                  }
                  break;
                }
                default: heff_nomatch(v_alt0_2490);
                }
                if ((heff_dup(v_t_24335) == NTAG(TAG_True))) {
                  heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                  heff_drop_tag(v_it11_2495, 2);
                  heff_drop_cell(v_ru_24it111_2497_24PatRecord, 1);
                  heff_drop(v_t_24335);
                  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam71, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492});
                } else {
                  heff_drop(v_t_24335);
                  V v_t_24359 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2495}));
                  V v_t_24360 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2490, NTAG(TAG_Nil)});
                  return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_2492, heff_tag_at_n(v_ru_24it111_2497_24PatRecord, TAG_Just, 1, (V[]){v_t_24359}), v_rhsN_2489, v_t_24360));
                }
              }
              case TAG_PatWord: {
                V v_ru_24it111_2497_24PatWord = heff_take_reuse_n(v_it111_2497, 0ULL, 1);
                heff_drop(v_bodyN_2496);
                V v_t_24366;
                switch (heff_tag_of(v_alt0_2490)) {
                case TAG_At: {
                  V v_x11_24362 = heff_dup(heff_field(v_alt0_2490, 0));
                  switch (heff_tag_of(v_x11_24362)) {
                  case TAG_MkAlt: {
                    V v_p_24364 = heff_field(v_x11_24362, 0);
                    heff_take_n(v_x11_24362, 1ULL, 2);
                    v_t_24366 = ({ V a_0 = v_p_24364; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24364); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x11_24362);
                  }
                  break;
                }
                default: heff_nomatch(v_alt0_2490);
                }
                if ((heff_dup(v_t_24366) == NTAG(TAG_True))) {
                  heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                  heff_drop_tag(v_it11_2495, 2);
                  heff_drop_cell(v_ru_24it111_2497_24PatWord, 1);
                  heff_drop(v_t_24366);
                  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam78, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492});
                } else {
                  heff_drop(v_t_24366);
                  V v_t_24390 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2495}));
                  V v_t_24391 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2490, NTAG(TAG_Nil)});
                  return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_2492, heff_tag_at_n(v_ru_24it111_2497_24PatWord, TAG_Just, 1, (V[]){v_t_24390}), v_rhsN_2489, v_t_24391));
                }
              }
              case TAG_PatAs: {
                heff_take_n(v_it111_2497, 0ULL, 3);
                heff_drop(v_bodyN_2496);
                V v_t_24399;
                switch (heff_tag_of(v_alt0_2490)) {
                case TAG_At: {
                  V v_x11_24395 = heff_dup(heff_field(v_alt0_2490, 0));
                  switch (heff_tag_of(v_x11_24395)) {
                  case TAG_MkAlt: {
                    V v_p_24397 = heff_field(v_x11_24395, 0);
                    heff_take_n(v_x11_24395, 1ULL, 2);
                    v_t_24399 = ({ V a_0 = v_p_24397; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24397); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x11_24395);
                  }
                  break;
                }
                default: heff_nomatch(v_alt0_2490);
                }
                if ((heff_dup(v_t_24399) == NTAG(TAG_True))) {
                  heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                  heff_drop_tag(v_it11_2495, 2);
                  heff_drop(v_t_24399);
                  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam85, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492});
                } else {
                  heff_drop(v_t_24399);
                  V v_t_24423 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2495}));
                  V v_t_24424 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2490, NTAG(TAG_Nil)});
                  return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_2492, heff_tag_n(TAG_Just, 1, (V[]){v_t_24423}), v_rhsN_2489, v_t_24424));
                }
              }
              default: return heff_nomatch(v_it111_2497);
              }
            }
            default: return heff_nomatch(v_it11_2495);
            }
          }
          default: return heff_nomatch(v_it1_2493);
          }
        }
        default: return heff_nomatch(v_alt0_2490);
        }
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    case TAG_CLocal: {
      V v_bodyN_24425 = heff_field(v_n1_241, 0);
      V v_defs_24426 = heff_field(v_n1_241, 1);
      heff_take_n(v_n1_241, 3ULL, 2);
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        heff_take_n(v_n_240, 0ULL, 2);
        return ({ V a_0 = v_defs_24426; V a_1 = v_bodyN_24425; V r_ = (g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(a_0, a_1)); heff_drop(v_defs_24426); r_; });
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    case TAG_CAbandon: {
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_n2_24430 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam92, 2, 1, (V[]){v_n2_24430});
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    case TAG_CNominal: {
      V v_c_24434 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        heff_take_n(v_n_240, 0ULL, 2);
        V v_c_24437 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_c_24434));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam93, 2, 1, (V[]){v_c_24437});
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    default: return heff_nomatch(v_n1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(a[0]);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2413 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2414 = v_s_2413;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2415 = ({ V a_0 = v_t_2414; V a_1 = v_x_245; V a_2 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2efunctionIntro(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
  V f_ = v_k_2410;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_t_248 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_248, v_hd_249, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1, 1, 3, (V[]){v_n_240, v_x_245, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2425;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2424 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2425 = v_s_2424;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_t_2426 = ({ V a_0 = v_t_2425; V a_1 = v_x_2416; V a_2 = v_x_2422; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_x_2422); r_; });
  V f_ = v_k_2421;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_t_2419 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2419, v_hd_2420, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3, 1, 3, (V[]){v_n_240, v_x_2416, v_k_2421})));
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_k_2433 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2439;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2438 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2439 = v_s_2438;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2440 = ({ V a_0 = v_t_2439; V a_1 = v_x_2427; V a_2 = v_x_2434; V a_3 = v_x_2436; V r_ = (g_heff_2eelab_2erules_2efunctionIntroAnn(a_0, a_1, a_2, a_3)); heff_drop(v_x_2434); heff_drop(v_x_2436); r_; });
  V f_ = v_k_2433;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_body_2430 = heff_env(self)[0];
  V v_hd_2432 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  V v_k_2433 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2435 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_2430));
  V f_ = v_c_2435;
  heff_room[0] = v_hd_2432;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6, 1, 4, (V[]){v_n_240, v_x_2427, v_x_2434, v_k_2433});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_c_2431 = heff_env(self)[0];
  V v_body_2430 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2431;
  args[0] = heff_dup(v_hd_2432);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5, 1, 5, (V[]){v_body_2430, v_hd_2432, v_n_240, v_x_2427, v_k_2433});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8(V self, V *args) {
  V v_x_2447 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_tsp_2442 = heff_env(self)[1];
  V v_x_2441 = heff_env(self)[2];
  V v_k_2446 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2450;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2449 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2450 = v_s_2449;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2451 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_t_2450; V a_2 = v_tsp_2442; V a_3 = v_x_2441; V a_4 = v_x_2447; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V f_ = v_k_2446;
  args[0] = v_x_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  V v_c_2444 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_tsp_2442 = heff_env(self)[2];
  V v_x_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2444;
  args[0] = v_hd_2445;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8, 1, 4, (V[]){v_n_240, v_tsp_2442, v_x_2441, v_k_2446});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10(V self, V *args) {
  V v_x_2458 = args[0];
  V v_n2_2454 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2459 = (g_heff_2eelab_2erules_2erecordIntro(v_n2_2454, v_x_2458));
  V f_ = v_k_2457;
  args[0] = v_t_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_n2_2454 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2455;
  args[0] = v_hd_2456;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10, 1, 2, (V[]){v_n2_2454, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15(V self, V *args) {
  V v_x_2477 = args[0];
  V v_body_2473 = heff_env(self)[0];
  V v_sp_2471 = heff_env(self)[1];
  V v_k_2476 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2478 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_2477, v_body_2473}), v_sp_2471});
  V f_ = v_k_2476;
  args[0] = v_t_2478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k_2476 = args[1];
  V v_c_2474 = heff_env(self)[0];
  V v_body_2473 = heff_env(self)[1];
  V v_sp_2471 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2474;
  args[0] = v_hd_2475;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15, 1, 3, (V[]){v_body_2473, v_sp_2471, v_k_2476});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13(V self, V *args) {
  V v_m_2469 = args[0];
  V v_e_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2469)) {
  case TAG_At: {
    V v_x21_2470 = heff_field(v_m_2469, 0);
    V v_sp_2471 = heff_field(v_m_2469, 1);
    heff_take_n(v_m_2469, 3ULL, 2);
    switch (heff_tag_of(v_x21_2470)) {
    case TAG_MkAlt: {
      V v_p_2472 = heff_field(v_x21_2470, 0);
      V v_body_2473 = heff_field(v_x21_2470, 1);
      heff_take_n(v_x21_2470, 3ULL, 2);
      V v_c_2474 = (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_2467, 1, 6), v_p_2472));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14, 2, 3, (V[]){v_c_2474, v_body_2473, v_sp_2471});
    }
    default: return heff_nomatch(v_x21_2470);
    }
  }
  default: return heff_nomatch(v_m_2469);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18(V self, V *args) {
  V v_x_2485 = args[0];
  V v_e_2467 = heff_env(self)[0];
  V v_a_2468 = heff_env(self)[1];
  V v_hd_2480 = heff_env(self)[2];
  V v_k_2481 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT1 v_t_2486 = ({ V a_0 = v_x_2485; HeffT1 r_ = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(a_0)); heff_drop(v_x_2485); r_; });
  {
    V v_field_2487 = v_t_2486.f[0];
    V v_f_2488 = v_field_2487;
    V f_ = v_f_2488;
    heff_room[0] = v_e_2467;
    heff_room[1] = v_a_2468;
    heff_room[2] = v_hd_2480;
    heff_room[3] = v_k_2481;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17(V self, V *args) {
  V v_x_2482 = args[0];
  V v_scrutN_2460 = heff_env(self)[0];
  V v_n2_2463 = heff_env(self)[1];
  V v_hd_2480 = heff_env(self)[2];
  V v_e_2467 = heff_env(self)[3];
  V v_a_2468 = heff_env(self)[4];
  V v_k_2481 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2483 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_scrutN_2460, v_x_2482}), v_n2_2463});
  V v_c_2484 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_t_2483));
  V f_ = v_c_2484;
  heff_room[0] = heff_dup(v_hd_2480);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18, 1, 4, (V[]){v_e_2467, v_a_2468, v_hd_2480, v_k_2481});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16(V self, V *args) {
  V v_hd_2480 = args[0];
  V v_k_2481 = args[1];
  V v_c_2479 = heff_env(self)[0];
  V v_scrutN_2460 = heff_env(self)[1];
  V v_n2_2463 = heff_env(self)[2];
  V v_e_2467 = heff_env(self)[3];
  V v_a_2468 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2479;
  args[0] = heff_dup(v_hd_2480);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17, 1, 6, (V[]){v_scrutN_2460, v_n2_2463, v_hd_2480, v_e_2467, v_a_2468, v_k_2481});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12(V self, V *args) {
  V v_e_2467 = args[0];
  V v_a_2468 = args[1];
  V v_casesN_2461 = heff_env(self)[0];
  V v_scrutN_2460 = heff_env(self)[1];
  V v_n2_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2479 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13, 1, 1, (V[]){heff_dup(v_e_2467)}), v_casesN_2461));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16, 2, 5, (V[]){v_c_2479, v_scrutN_2460, v_n2_2463, v_e_2467, v_a_2468});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k_2466 = args[1];
  V v_casesN_2461 = heff_env(self)[0];
  V v_scrutN_2460 = heff_env(self)[1];
  V v_n2_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2465);
  V f_ = v_k_2466;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12, 2, 3, (V[]){v_casesN_2461, v_scrutN_2460, v_n2_2463})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21(V self, V *args) {
  V v_x_24107 = args[0];
  V v_x_2499 = heff_env(self)[0];
  V v_x_24105 = heff_env(self)[1];
  V v_k_24104 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24108 = ({ V a_0 = v_x_2499; V a_1 = v_x_24105; V a_2 = v_x_24107; V r_ = (g_heff_2eelab_2erules_2ecaseLet(a_0, a_1, a_2)); heff_drop(v_x_24105); heff_drop(v_x_24107); r_; });
  V f_ = v_k_24104;
  args[0] = v_t_24108;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20(V self, V *args) {
  V v_x_24105 = args[0];
  V v_bodyN_2496 = heff_env(self)[0];
  V v_hd_24103 = heff_env(self)[1];
  V v_x_2499 = heff_env(self)[2];
  V v_k_24104 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24106 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_bodyN_2496));
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_24106, v_hd_24103, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21, 1, 3, (V[]){v_x_2499, v_x_24105, v_k_24104})));
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19(V self, V *args) {
  V v_hd_24103 = args[0];
  V v_k_24104 = args[1];
  V v_c_24102 = heff_env(self)[0];
  V v_bodyN_2496 = heff_env(self)[1];
  V v_x_2499 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24102;
  args[0] = heff_dup(v_hd_24103);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20, 1, 4, (V[]){v_bodyN_2496, v_hd_24103, v_x_2499, v_k_24104});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25(V self, V *args) {
  V v_x_24128 = args[0];
  V v_body_24124 = heff_env(self)[0];
  V v_sp_24122 = heff_env(self)[1];
  V v_k_24127 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24129 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24128, v_body_24124}), v_sp_24122});
  V f_ = v_k_24127;
  args[0] = v_t_24129;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24(V self, V *args) {
  V v_hd_24126 = args[0];
  V v_k_24127 = args[1];
  V v_c_24125 = heff_env(self)[0];
  V v_body_24124 = heff_env(self)[1];
  V v_sp_24122 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24125;
  args[0] = v_hd_24126;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25, 1, 3, (V[]){v_body_24124, v_sp_24122, v_k_24127});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28(V self, V *args) {
  V v_x_24136 = args[0];
  V v_e_24119 = heff_env(self)[0];
  V v_a_24120 = heff_env(self)[1];
  V v_hd_24131 = heff_env(self)[2];
  V v_k_24132 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT1 v_t_24137 = ({ V a_0 = v_x_24136; HeffT1 r_ = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(a_0)); heff_drop(v_x_24136); r_; });
  {
    V v_field_24138 = v_t_24137.f[0];
    V v_f_24139 = v_field_24138;
    V f_ = v_f_24139;
    heff_room[0] = v_e_24119;
    heff_room[1] = v_a_24120;
    heff_room[2] = v_hd_24131;
    heff_room[3] = v_k_24132;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27(V self, V *args) {
  V v_x_24133 = args[0];
  V v_rhsN_2489 = heff_env(self)[0];
  V v_n2_2492 = heff_env(self)[1];
  V v_hd_24131 = heff_env(self)[2];
  V v_e_24119 = heff_env(self)[3];
  V v_a_24120 = heff_env(self)[4];
  V v_k_24132 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24134 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2489, v_x_24133}), v_n2_2492});
  V v_c_24135 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_t_24134));
  V f_ = v_c_24135;
  heff_room[0] = heff_dup(v_hd_24131);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28, 1, 4, (V[]){v_e_24119, v_a_24120, v_hd_24131, v_k_24132});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26(V self, V *args) {
  V v_hd_24131 = args[0];
  V v_k_24132 = args[1];
  V v_c_24130 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  V v_e_24119 = heff_env(self)[3];
  V v_a_24120 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24130;
  args[0] = heff_dup(v_hd_24131);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27, 1, 6, (V[]){v_rhsN_2489, v_n2_2492, v_hd_24131, v_e_24119, v_a_24120, v_k_24132});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23(V self, V *args) {
  V v_e_24119 = args[0];
  V v_a_24120 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24130;
  switch (heff_tag_of(v_alt0_2490)) {
  case TAG_At: {
    V v_x21_24121 = heff_field(v_alt0_2490, 0);
    V v_sp_24122 = heff_field(v_alt0_2490, 1);
    heff_take_n(v_alt0_2490, 3ULL, 2);
    switch (heff_tag_of(v_x21_24121)) {
    case TAG_MkAlt: {
      V v_p_24123 = heff_field(v_x21_24121, 0);
      V v_body_24124 = heff_field(v_x21_24121, 1);
      heff_take_n(v_x21_24121, 3ULL, 2);
      V v_c_24125 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24119, 1)), v_p_24123));
      v_c_24130 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24, 2, 3, (V[]){v_c_24125, v_body_24124, v_sp_24122});
      break;
    }
    default: heff_nomatch(v_x21_24121);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2490);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26, 2, 5, (V[]){v_c_24130, v_rhsN_2489, v_n2_2492, v_e_24119, v_a_24120});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22(V self, V *args) {
  V v_hd_24117 = args[0];
  V v_k_24118 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24117);
  V f_ = v_k_24118;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam32(V self, V *args) {
  V v_x_24161 = args[0];
  V v_body_24157 = heff_env(self)[0];
  V v_sp_24155 = heff_env(self)[1];
  V v_k_24160 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24162 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24161, v_body_24157}), v_sp_24155});
  V f_ = v_k_24160;
  args[0] = v_t_24162;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31(V self, V *args) {
  V v_hd_24159 = args[0];
  V v_k_24160 = args[1];
  V v_c_24158 = heff_env(self)[0];
  V v_body_24157 = heff_env(self)[1];
  V v_sp_24155 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24158;
  args[0] = v_hd_24159;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam32, 1, 3, (V[]){v_body_24157, v_sp_24155, v_k_24160});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam35(V self, V *args) {
  V v_x_24169 = args[0];
  V v_e_24152 = heff_env(self)[0];
  V v_a_24153 = heff_env(self)[1];
  V v_hd_24164 = heff_env(self)[2];
  V v_k_24165 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT1 v_t_24170 = ({ V a_0 = v_x_24169; HeffT1 r_ = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(a_0)); heff_drop(v_x_24169); r_; });
  {
    V v_field_24171 = v_t_24170.f[0];
    V v_f_24172 = v_field_24171;
    V f_ = v_f_24172;
    heff_room[0] = v_e_24152;
    heff_room[1] = v_a_24153;
    heff_room[2] = v_hd_24164;
    heff_room[3] = v_k_24165;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam34(V self, V *args) {
  V v_x_24166 = args[0];
  V v_rhsN_2489 = heff_env(self)[0];
  V v_n2_2492 = heff_env(self)[1];
  V v_hd_24164 = heff_env(self)[2];
  V v_e_24152 = heff_env(self)[3];
  V v_a_24153 = heff_env(self)[4];
  V v_k_24165 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24167 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2489, v_x_24166}), v_n2_2492});
  V v_c_24168 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_t_24167));
  V f_ = v_c_24168;
  heff_room[0] = heff_dup(v_hd_24164);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam35, 1, 4, (V[]){v_e_24152, v_a_24153, v_hd_24164, v_k_24165});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam33(V self, V *args) {
  V v_hd_24164 = args[0];
  V v_k_24165 = args[1];
  V v_c_24163 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  V v_e_24152 = heff_env(self)[3];
  V v_a_24153 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24163;
  args[0] = heff_dup(v_hd_24164);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam34, 1, 6, (V[]){v_rhsN_2489, v_n2_2492, v_hd_24164, v_e_24152, v_a_24153, v_k_24165});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30(V self, V *args) {
  V v_e_24152 = args[0];
  V v_a_24153 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24163;
  switch (heff_tag_of(v_alt0_2490)) {
  case TAG_At: {
    V v_x21_24154 = heff_field(v_alt0_2490, 0);
    V v_sp_24155 = heff_field(v_alt0_2490, 1);
    heff_take_n(v_alt0_2490, 3ULL, 2);
    switch (heff_tag_of(v_x21_24154)) {
    case TAG_MkAlt: {
      V v_p_24156 = heff_field(v_x21_24154, 0);
      V v_body_24157 = heff_field(v_x21_24154, 1);
      heff_take_n(v_x21_24154, 3ULL, 2);
      V v_c_24158 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24152, 1)), v_p_24156));
      v_c_24163 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31, 2, 3, (V[]){v_c_24158, v_body_24157, v_sp_24155});
      break;
    }
    default: heff_nomatch(v_x21_24154);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2490);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam33, 2, 5, (V[]){v_c_24163, v_rhsN_2489, v_n2_2492, v_e_24152, v_a_24153});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29(V self, V *args) {
  V v_hd_24150 = args[0];
  V v_k_24151 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24150);
  V f_ = v_k_24151;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam39(V self, V *args) {
  V v_x_24192 = args[0];
  V v_body_24188 = heff_env(self)[0];
  V v_sp_24186 = heff_env(self)[1];
  V v_k_24191 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24193 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24192, v_body_24188}), v_sp_24186});
  V f_ = v_k_24191;
  args[0] = v_t_24193;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam38(V self, V *args) {
  V v_hd_24190 = args[0];
  V v_k_24191 = args[1];
  V v_c_24189 = heff_env(self)[0];
  V v_body_24188 = heff_env(self)[1];
  V v_sp_24186 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24189;
  args[0] = v_hd_24190;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam39, 1, 3, (V[]){v_body_24188, v_sp_24186, v_k_24191});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam42(V self, V *args) {
  V v_x_24200 = args[0];
  V v_e_24183 = heff_env(self)[0];
  V v_a_24184 = heff_env(self)[1];
  V v_hd_24195 = heff_env(self)[2];
  V v_k_24196 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT1 v_t_24201 = ({ V a_0 = v_x_24200; HeffT1 r_ = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(a_0)); heff_drop(v_x_24200); r_; });
  {
    V v_field_24202 = v_t_24201.f[0];
    V v_f_24203 = v_field_24202;
    V f_ = v_f_24203;
    heff_room[0] = v_e_24183;
    heff_room[1] = v_a_24184;
    heff_room[2] = v_hd_24195;
    heff_room[3] = v_k_24196;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam41(V self, V *args) {
  V v_x_24197 = args[0];
  V v_rhsN_2489 = heff_env(self)[0];
  V v_n2_2492 = heff_env(self)[1];
  V v_hd_24195 = heff_env(self)[2];
  V v_e_24183 = heff_env(self)[3];
  V v_a_24184 = heff_env(self)[4];
  V v_k_24196 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24198 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2489, v_x_24197}), v_n2_2492});
  V v_c_24199 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_t_24198));
  V f_ = v_c_24199;
  heff_room[0] = heff_dup(v_hd_24195);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam42, 1, 4, (V[]){v_e_24183, v_a_24184, v_hd_24195, v_k_24196});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam40(V self, V *args) {
  V v_hd_24195 = args[0];
  V v_k_24196 = args[1];
  V v_c_24194 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  V v_e_24183 = heff_env(self)[3];
  V v_a_24184 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24194;
  args[0] = heff_dup(v_hd_24195);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam41, 1, 6, (V[]){v_rhsN_2489, v_n2_2492, v_hd_24195, v_e_24183, v_a_24184, v_k_24196});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam37(V self, V *args) {
  V v_e_24183 = args[0];
  V v_a_24184 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24194;
  switch (heff_tag_of(v_alt0_2490)) {
  case TAG_At: {
    V v_x21_24185 = heff_field(v_alt0_2490, 0);
    V v_sp_24186 = heff_field(v_alt0_2490, 1);
    heff_take_n(v_alt0_2490, 3ULL, 2);
    switch (heff_tag_of(v_x21_24185)) {
    case TAG_MkAlt: {
      V v_p_24187 = heff_field(v_x21_24185, 0);
      V v_body_24188 = heff_field(v_x21_24185, 1);
      heff_take_n(v_x21_24185, 3ULL, 2);
      V v_c_24189 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24183, 1)), v_p_24187));
      v_c_24194 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam38, 2, 3, (V[]){v_c_24189, v_body_24188, v_sp_24186});
      break;
    }
    default: heff_nomatch(v_x21_24185);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2490);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam40, 2, 5, (V[]){v_c_24194, v_rhsN_2489, v_n2_2492, v_e_24183, v_a_24184});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam36(V self, V *args) {
  V v_hd_24181 = args[0];
  V v_k_24182 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24181);
  V f_ = v_k_24182;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam37, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam46(V self, V *args) {
  V v_x_24223 = args[0];
  V v_body_24219 = heff_env(self)[0];
  V v_sp_24217 = heff_env(self)[1];
  V v_k_24222 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24224 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24223, v_body_24219}), v_sp_24217});
  V f_ = v_k_24222;
  args[0] = v_t_24224;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam45(V self, V *args) {
  V v_hd_24221 = args[0];
  V v_k_24222 = args[1];
  V v_c_24220 = heff_env(self)[0];
  V v_body_24219 = heff_env(self)[1];
  V v_sp_24217 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24220;
  args[0] = v_hd_24221;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam46, 1, 3, (V[]){v_body_24219, v_sp_24217, v_k_24222});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam49(V self, V *args) {
  V v_x_24231 = args[0];
  V v_e_24214 = heff_env(self)[0];
  V v_a_24215 = heff_env(self)[1];
  V v_hd_24226 = heff_env(self)[2];
  V v_k_24227 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT1 v_t_24232 = ({ V a_0 = v_x_24231; HeffT1 r_ = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(a_0)); heff_drop(v_x_24231); r_; });
  {
    V v_field_24233 = v_t_24232.f[0];
    V v_f_24234 = v_field_24233;
    V f_ = v_f_24234;
    heff_room[0] = v_e_24214;
    heff_room[1] = v_a_24215;
    heff_room[2] = v_hd_24226;
    heff_room[3] = v_k_24227;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam48(V self, V *args) {
  V v_x_24228 = args[0];
  V v_rhsN_2489 = heff_env(self)[0];
  V v_n2_2492 = heff_env(self)[1];
  V v_hd_24226 = heff_env(self)[2];
  V v_e_24214 = heff_env(self)[3];
  V v_a_24215 = heff_env(self)[4];
  V v_k_24227 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24229 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2489, v_x_24228}), v_n2_2492});
  V v_c_24230 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_t_24229));
  V f_ = v_c_24230;
  heff_room[0] = heff_dup(v_hd_24226);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam49, 1, 4, (V[]){v_e_24214, v_a_24215, v_hd_24226, v_k_24227});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam47(V self, V *args) {
  V v_hd_24226 = args[0];
  V v_k_24227 = args[1];
  V v_c_24225 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  V v_e_24214 = heff_env(self)[3];
  V v_a_24215 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24225;
  args[0] = heff_dup(v_hd_24226);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam48, 1, 6, (V[]){v_rhsN_2489, v_n2_2492, v_hd_24226, v_e_24214, v_a_24215, v_k_24227});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam44(V self, V *args) {
  V v_e_24214 = args[0];
  V v_a_24215 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24225;
  switch (heff_tag_of(v_alt0_2490)) {
  case TAG_At: {
    V v_x21_24216 = heff_field(v_alt0_2490, 0);
    V v_sp_24217 = heff_field(v_alt0_2490, 1);
    heff_take_n(v_alt0_2490, 3ULL, 2);
    switch (heff_tag_of(v_x21_24216)) {
    case TAG_MkAlt: {
      V v_p_24218 = heff_field(v_x21_24216, 0);
      V v_body_24219 = heff_field(v_x21_24216, 1);
      heff_take_n(v_x21_24216, 3ULL, 2);
      V v_c_24220 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24214, 1)), v_p_24218));
      v_c_24225 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam45, 2, 3, (V[]){v_c_24220, v_body_24219, v_sp_24217});
      break;
    }
    default: heff_nomatch(v_x21_24216);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2490);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam47, 2, 5, (V[]){v_c_24225, v_rhsN_2489, v_n2_2492, v_e_24214, v_a_24215});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam43(V self, V *args) {
  V v_hd_24212 = args[0];
  V v_k_24213 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24212);
  V f_ = v_k_24213;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam44, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam53(V self, V *args) {
  V v_x_24254 = args[0];
  V v_body_24250 = heff_env(self)[0];
  V v_sp_24248 = heff_env(self)[1];
  V v_k_24253 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24255 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24254, v_body_24250}), v_sp_24248});
  V f_ = v_k_24253;
  args[0] = v_t_24255;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam52(V self, V *args) {
  V v_hd_24252 = args[0];
  V v_k_24253 = args[1];
  V v_c_24251 = heff_env(self)[0];
  V v_body_24250 = heff_env(self)[1];
  V v_sp_24248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24251;
  args[0] = v_hd_24252;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam53, 1, 3, (V[]){v_body_24250, v_sp_24248, v_k_24253});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam56(V self, V *args) {
  V v_x_24262 = args[0];
  V v_e_24245 = heff_env(self)[0];
  V v_a_24246 = heff_env(self)[1];
  V v_hd_24257 = heff_env(self)[2];
  V v_k_24258 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT1 v_t_24263 = ({ V a_0 = v_x_24262; HeffT1 r_ = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(a_0)); heff_drop(v_x_24262); r_; });
  {
    V v_field_24264 = v_t_24263.f[0];
    V v_f_24265 = v_field_24264;
    V f_ = v_f_24265;
    heff_room[0] = v_e_24245;
    heff_room[1] = v_a_24246;
    heff_room[2] = v_hd_24257;
    heff_room[3] = v_k_24258;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam55(V self, V *args) {
  V v_x_24259 = args[0];
  V v_rhsN_2489 = heff_env(self)[0];
  V v_n2_2492 = heff_env(self)[1];
  V v_hd_24257 = heff_env(self)[2];
  V v_e_24245 = heff_env(self)[3];
  V v_a_24246 = heff_env(self)[4];
  V v_k_24258 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24260 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2489, v_x_24259}), v_n2_2492});
  V v_c_24261 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_t_24260));
  V f_ = v_c_24261;
  heff_room[0] = heff_dup(v_hd_24257);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam56, 1, 4, (V[]){v_e_24245, v_a_24246, v_hd_24257, v_k_24258});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam54(V self, V *args) {
  V v_hd_24257 = args[0];
  V v_k_24258 = args[1];
  V v_c_24256 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  V v_e_24245 = heff_env(self)[3];
  V v_a_24246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24256;
  args[0] = heff_dup(v_hd_24257);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam55, 1, 6, (V[]){v_rhsN_2489, v_n2_2492, v_hd_24257, v_e_24245, v_a_24246, v_k_24258});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam51(V self, V *args) {
  V v_e_24245 = args[0];
  V v_a_24246 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24256;
  switch (heff_tag_of(v_alt0_2490)) {
  case TAG_At: {
    V v_x21_24247 = heff_field(v_alt0_2490, 0);
    V v_sp_24248 = heff_field(v_alt0_2490, 1);
    heff_take_n(v_alt0_2490, 3ULL, 2);
    switch (heff_tag_of(v_x21_24247)) {
    case TAG_MkAlt: {
      V v_p_24249 = heff_field(v_x21_24247, 0);
      V v_body_24250 = heff_field(v_x21_24247, 1);
      heff_take_n(v_x21_24247, 3ULL, 2);
      V v_c_24251 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24245, 1)), v_p_24249));
      v_c_24256 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam52, 2, 3, (V[]){v_c_24251, v_body_24250, v_sp_24248});
      break;
    }
    default: heff_nomatch(v_x21_24247);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2490);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam54, 2, 5, (V[]){v_c_24256, v_rhsN_2489, v_n2_2492, v_e_24245, v_a_24246});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam50(V self, V *args) {
  V v_hd_24243 = args[0];
  V v_k_24244 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24243);
  V f_ = v_k_24244;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam51, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam60(V self, V *args) {
  V v_x_24285 = args[0];
  V v_body_24281 = heff_env(self)[0];
  V v_sp_24279 = heff_env(self)[1];
  V v_k_24284 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24286 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24285, v_body_24281}), v_sp_24279});
  V f_ = v_k_24284;
  args[0] = v_t_24286;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam59(V self, V *args) {
  V v_hd_24283 = args[0];
  V v_k_24284 = args[1];
  V v_c_24282 = heff_env(self)[0];
  V v_body_24281 = heff_env(self)[1];
  V v_sp_24279 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24282;
  args[0] = v_hd_24283;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam60, 1, 3, (V[]){v_body_24281, v_sp_24279, v_k_24284});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam63(V self, V *args) {
  V v_x_24293 = args[0];
  V v_e_24276 = heff_env(self)[0];
  V v_a_24277 = heff_env(self)[1];
  V v_hd_24288 = heff_env(self)[2];
  V v_k_24289 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT1 v_t_24294 = ({ V a_0 = v_x_24293; HeffT1 r_ = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(a_0)); heff_drop(v_x_24293); r_; });
  {
    V v_field_24295 = v_t_24294.f[0];
    V v_f_24296 = v_field_24295;
    V f_ = v_f_24296;
    heff_room[0] = v_e_24276;
    heff_room[1] = v_a_24277;
    heff_room[2] = v_hd_24288;
    heff_room[3] = v_k_24289;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam62(V self, V *args) {
  V v_x_24290 = args[0];
  V v_rhsN_2489 = heff_env(self)[0];
  V v_n2_2492 = heff_env(self)[1];
  V v_hd_24288 = heff_env(self)[2];
  V v_e_24276 = heff_env(self)[3];
  V v_a_24277 = heff_env(self)[4];
  V v_k_24289 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24291 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2489, v_x_24290}), v_n2_2492});
  V v_c_24292 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_t_24291));
  V f_ = v_c_24292;
  heff_room[0] = heff_dup(v_hd_24288);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam63, 1, 4, (V[]){v_e_24276, v_a_24277, v_hd_24288, v_k_24289});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam61(V self, V *args) {
  V v_hd_24288 = args[0];
  V v_k_24289 = args[1];
  V v_c_24287 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  V v_e_24276 = heff_env(self)[3];
  V v_a_24277 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24287;
  args[0] = heff_dup(v_hd_24288);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam62, 1, 6, (V[]){v_rhsN_2489, v_n2_2492, v_hd_24288, v_e_24276, v_a_24277, v_k_24289});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam58(V self, V *args) {
  V v_e_24276 = args[0];
  V v_a_24277 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24287;
  switch (heff_tag_of(v_alt0_2490)) {
  case TAG_At: {
    V v_x21_24278 = heff_field(v_alt0_2490, 0);
    V v_sp_24279 = heff_field(v_alt0_2490, 1);
    heff_take_n(v_alt0_2490, 3ULL, 2);
    switch (heff_tag_of(v_x21_24278)) {
    case TAG_MkAlt: {
      V v_p_24280 = heff_field(v_x21_24278, 0);
      V v_body_24281 = heff_field(v_x21_24278, 1);
      heff_take_n(v_x21_24278, 3ULL, 2);
      V v_c_24282 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24276, 1)), v_p_24280));
      v_c_24287 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam59, 2, 3, (V[]){v_c_24282, v_body_24281, v_sp_24279});
      break;
    }
    default: heff_nomatch(v_x21_24278);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2490);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam61, 2, 5, (V[]){v_c_24287, v_rhsN_2489, v_n2_2492, v_e_24276, v_a_24277});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam57(V self, V *args) {
  V v_hd_24274 = args[0];
  V v_k_24275 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24274);
  V f_ = v_k_24275;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam58, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam67(V self, V *args) {
  V v_x_24316 = args[0];
  V v_body_24312 = heff_env(self)[0];
  V v_sp_24310 = heff_env(self)[1];
  V v_k_24315 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24317 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24316, v_body_24312}), v_sp_24310});
  V f_ = v_k_24315;
  args[0] = v_t_24317;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam66(V self, V *args) {
  V v_hd_24314 = args[0];
  V v_k_24315 = args[1];
  V v_c_24313 = heff_env(self)[0];
  V v_body_24312 = heff_env(self)[1];
  V v_sp_24310 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24313;
  args[0] = v_hd_24314;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam67, 1, 3, (V[]){v_body_24312, v_sp_24310, v_k_24315});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam70(V self, V *args) {
  V v_x_24324 = args[0];
  V v_e_24307 = heff_env(self)[0];
  V v_a_24308 = heff_env(self)[1];
  V v_hd_24319 = heff_env(self)[2];
  V v_k_24320 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT1 v_t_24325 = ({ V a_0 = v_x_24324; HeffT1 r_ = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(a_0)); heff_drop(v_x_24324); r_; });
  {
    V v_field_24326 = v_t_24325.f[0];
    V v_f_24327 = v_field_24326;
    V f_ = v_f_24327;
    heff_room[0] = v_e_24307;
    heff_room[1] = v_a_24308;
    heff_room[2] = v_hd_24319;
    heff_room[3] = v_k_24320;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam69(V self, V *args) {
  V v_x_24321 = args[0];
  V v_rhsN_2489 = heff_env(self)[0];
  V v_n2_2492 = heff_env(self)[1];
  V v_hd_24319 = heff_env(self)[2];
  V v_e_24307 = heff_env(self)[3];
  V v_a_24308 = heff_env(self)[4];
  V v_k_24320 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24322 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2489, v_x_24321}), v_n2_2492});
  V v_c_24323 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_t_24322));
  V f_ = v_c_24323;
  heff_room[0] = heff_dup(v_hd_24319);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam70, 1, 4, (V[]){v_e_24307, v_a_24308, v_hd_24319, v_k_24320});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam68(V self, V *args) {
  V v_hd_24319 = args[0];
  V v_k_24320 = args[1];
  V v_c_24318 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  V v_e_24307 = heff_env(self)[3];
  V v_a_24308 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24318;
  args[0] = heff_dup(v_hd_24319);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam69, 1, 6, (V[]){v_rhsN_2489, v_n2_2492, v_hd_24319, v_e_24307, v_a_24308, v_k_24320});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam65(V self, V *args) {
  V v_e_24307 = args[0];
  V v_a_24308 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24318;
  switch (heff_tag_of(v_alt0_2490)) {
  case TAG_At: {
    V v_x21_24309 = heff_field(v_alt0_2490, 0);
    V v_sp_24310 = heff_field(v_alt0_2490, 1);
    heff_take_n(v_alt0_2490, 3ULL, 2);
    switch (heff_tag_of(v_x21_24309)) {
    case TAG_MkAlt: {
      V v_p_24311 = heff_field(v_x21_24309, 0);
      V v_body_24312 = heff_field(v_x21_24309, 1);
      heff_take_n(v_x21_24309, 3ULL, 2);
      V v_c_24313 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24307, 1)), v_p_24311));
      v_c_24318 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam66, 2, 3, (V[]){v_c_24313, v_body_24312, v_sp_24310});
      break;
    }
    default: heff_nomatch(v_x21_24309);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2490);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam68, 2, 5, (V[]){v_c_24318, v_rhsN_2489, v_n2_2492, v_e_24307, v_a_24308});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam64(V self, V *args) {
  V v_hd_24305 = args[0];
  V v_k_24306 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24305);
  V f_ = v_k_24306;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam65, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam74(V self, V *args) {
  V v_x_24347 = args[0];
  V v_body_24343 = heff_env(self)[0];
  V v_sp_24341 = heff_env(self)[1];
  V v_k_24346 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24348 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24347, v_body_24343}), v_sp_24341});
  V f_ = v_k_24346;
  args[0] = v_t_24348;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam73(V self, V *args) {
  V v_hd_24345 = args[0];
  V v_k_24346 = args[1];
  V v_c_24344 = heff_env(self)[0];
  V v_body_24343 = heff_env(self)[1];
  V v_sp_24341 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24344;
  args[0] = v_hd_24345;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam74, 1, 3, (V[]){v_body_24343, v_sp_24341, v_k_24346});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam77(V self, V *args) {
  V v_x_24355 = args[0];
  V v_e_24338 = heff_env(self)[0];
  V v_a_24339 = heff_env(self)[1];
  V v_hd_24350 = heff_env(self)[2];
  V v_k_24351 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT1 v_t_24356 = ({ V a_0 = v_x_24355; HeffT1 r_ = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(a_0)); heff_drop(v_x_24355); r_; });
  {
    V v_field_24357 = v_t_24356.f[0];
    V v_f_24358 = v_field_24357;
    V f_ = v_f_24358;
    heff_room[0] = v_e_24338;
    heff_room[1] = v_a_24339;
    heff_room[2] = v_hd_24350;
    heff_room[3] = v_k_24351;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam76(V self, V *args) {
  V v_x_24352 = args[0];
  V v_rhsN_2489 = heff_env(self)[0];
  V v_n2_2492 = heff_env(self)[1];
  V v_hd_24350 = heff_env(self)[2];
  V v_e_24338 = heff_env(self)[3];
  V v_a_24339 = heff_env(self)[4];
  V v_k_24351 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24353 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2489, v_x_24352}), v_n2_2492});
  V v_c_24354 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_t_24353));
  V f_ = v_c_24354;
  heff_room[0] = heff_dup(v_hd_24350);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam77, 1, 4, (V[]){v_e_24338, v_a_24339, v_hd_24350, v_k_24351});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam75(V self, V *args) {
  V v_hd_24350 = args[0];
  V v_k_24351 = args[1];
  V v_c_24349 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  V v_e_24338 = heff_env(self)[3];
  V v_a_24339 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24349;
  args[0] = heff_dup(v_hd_24350);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam76, 1, 6, (V[]){v_rhsN_2489, v_n2_2492, v_hd_24350, v_e_24338, v_a_24339, v_k_24351});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam72(V self, V *args) {
  V v_e_24338 = args[0];
  V v_a_24339 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24349;
  switch (heff_tag_of(v_alt0_2490)) {
  case TAG_At: {
    V v_x21_24340 = heff_field(v_alt0_2490, 0);
    V v_sp_24341 = heff_field(v_alt0_2490, 1);
    heff_take_n(v_alt0_2490, 3ULL, 2);
    switch (heff_tag_of(v_x21_24340)) {
    case TAG_MkAlt: {
      V v_p_24342 = heff_field(v_x21_24340, 0);
      V v_body_24343 = heff_field(v_x21_24340, 1);
      heff_take_n(v_x21_24340, 3ULL, 2);
      V v_c_24344 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24338, 1)), v_p_24342));
      v_c_24349 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam73, 2, 3, (V[]){v_c_24344, v_body_24343, v_sp_24341});
      break;
    }
    default: heff_nomatch(v_x21_24340);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2490);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam75, 2, 5, (V[]){v_c_24349, v_rhsN_2489, v_n2_2492, v_e_24338, v_a_24339});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam71(V self, V *args) {
  V v_hd_24336 = args[0];
  V v_k_24337 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24336);
  V f_ = v_k_24337;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam72, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam81(V self, V *args) {
  V v_x_24378 = args[0];
  V v_body_24374 = heff_env(self)[0];
  V v_sp_24372 = heff_env(self)[1];
  V v_k_24377 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24379 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24378, v_body_24374}), v_sp_24372});
  V f_ = v_k_24377;
  args[0] = v_t_24379;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam80(V self, V *args) {
  V v_hd_24376 = args[0];
  V v_k_24377 = args[1];
  V v_c_24375 = heff_env(self)[0];
  V v_body_24374 = heff_env(self)[1];
  V v_sp_24372 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24375;
  args[0] = v_hd_24376;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam81, 1, 3, (V[]){v_body_24374, v_sp_24372, v_k_24377});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam84(V self, V *args) {
  V v_x_24386 = args[0];
  V v_e_24369 = heff_env(self)[0];
  V v_a_24370 = heff_env(self)[1];
  V v_hd_24381 = heff_env(self)[2];
  V v_k_24382 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT1 v_t_24387 = ({ V a_0 = v_x_24386; HeffT1 r_ = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(a_0)); heff_drop(v_x_24386); r_; });
  {
    V v_field_24388 = v_t_24387.f[0];
    V v_f_24389 = v_field_24388;
    V f_ = v_f_24389;
    heff_room[0] = v_e_24369;
    heff_room[1] = v_a_24370;
    heff_room[2] = v_hd_24381;
    heff_room[3] = v_k_24382;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam83(V self, V *args) {
  V v_x_24383 = args[0];
  V v_rhsN_2489 = heff_env(self)[0];
  V v_n2_2492 = heff_env(self)[1];
  V v_hd_24381 = heff_env(self)[2];
  V v_e_24369 = heff_env(self)[3];
  V v_a_24370 = heff_env(self)[4];
  V v_k_24382 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24384 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2489, v_x_24383}), v_n2_2492});
  V v_c_24385 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_t_24384));
  V f_ = v_c_24385;
  heff_room[0] = heff_dup(v_hd_24381);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam84, 1, 4, (V[]){v_e_24369, v_a_24370, v_hd_24381, v_k_24382});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam82(V self, V *args) {
  V v_hd_24381 = args[0];
  V v_k_24382 = args[1];
  V v_c_24380 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  V v_e_24369 = heff_env(self)[3];
  V v_a_24370 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24380;
  args[0] = heff_dup(v_hd_24381);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam83, 1, 6, (V[]){v_rhsN_2489, v_n2_2492, v_hd_24381, v_e_24369, v_a_24370, v_k_24382});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam79(V self, V *args) {
  V v_e_24369 = args[0];
  V v_a_24370 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24380;
  switch (heff_tag_of(v_alt0_2490)) {
  case TAG_At: {
    V v_x21_24371 = heff_field(v_alt0_2490, 0);
    V v_sp_24372 = heff_field(v_alt0_2490, 1);
    heff_take_n(v_alt0_2490, 3ULL, 2);
    switch (heff_tag_of(v_x21_24371)) {
    case TAG_MkAlt: {
      V v_p_24373 = heff_field(v_x21_24371, 0);
      V v_body_24374 = heff_field(v_x21_24371, 1);
      heff_take_n(v_x21_24371, 3ULL, 2);
      V v_c_24375 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24369, 1)), v_p_24373));
      v_c_24380 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam80, 2, 3, (V[]){v_c_24375, v_body_24374, v_sp_24372});
      break;
    }
    default: heff_nomatch(v_x21_24371);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2490);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam82, 2, 5, (V[]){v_c_24380, v_rhsN_2489, v_n2_2492, v_e_24369, v_a_24370});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam78(V self, V *args) {
  V v_hd_24367 = args[0];
  V v_k_24368 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24367);
  V f_ = v_k_24368;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam79, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam88(V self, V *args) {
  V v_x_24411 = args[0];
  V v_body_24407 = heff_env(self)[0];
  V v_sp_24405 = heff_env(self)[1];
  V v_k_24410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24411, v_body_24407}), v_sp_24405});
  V f_ = v_k_24410;
  args[0] = v_t_24412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam87(V self, V *args) {
  V v_hd_24409 = args[0];
  V v_k_24410 = args[1];
  V v_c_24408 = heff_env(self)[0];
  V v_body_24407 = heff_env(self)[1];
  V v_sp_24405 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24408;
  args[0] = v_hd_24409;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam88, 1, 3, (V[]){v_body_24407, v_sp_24405, v_k_24410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam91(V self, V *args) {
  V v_x_24419 = args[0];
  V v_e_24402 = heff_env(self)[0];
  V v_a_24403 = heff_env(self)[1];
  V v_hd_24414 = heff_env(self)[2];
  V v_k_24415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT1 v_t_24420 = ({ V a_0 = v_x_24419; HeffT1 r_ = (g_heff_2eelab_2erules_2eimplicitLams_24cpr(a_0)); heff_drop(v_x_24419); r_; });
  {
    V v_field_24421 = v_t_24420.f[0];
    V v_f_24422 = v_field_24421;
    V f_ = v_f_24422;
    heff_room[0] = v_e_24402;
    heff_room[1] = v_a_24403;
    heff_room[2] = v_hd_24414;
    heff_room[3] = v_k_24415;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam90(V self, V *args) {
  V v_x_24416 = args[0];
  V v_rhsN_2489 = heff_env(self)[0];
  V v_n2_2492 = heff_env(self)[1];
  V v_hd_24414 = heff_env(self)[2];
  V v_e_24402 = heff_env(self)[3];
  V v_a_24403 = heff_env(self)[4];
  V v_k_24415 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2489, v_x_24416}), v_n2_2492});
  V v_c_24418 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_t_24417));
  V f_ = v_c_24418;
  heff_room[0] = heff_dup(v_hd_24414);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam91, 1, 4, (V[]){v_e_24402, v_a_24403, v_hd_24414, v_k_24415});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam89(V self, V *args) {
  V v_hd_24414 = args[0];
  V v_k_24415 = args[1];
  V v_c_24413 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  V v_e_24402 = heff_env(self)[3];
  V v_a_24403 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24413;
  args[0] = heff_dup(v_hd_24414);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam90, 1, 6, (V[]){v_rhsN_2489, v_n2_2492, v_hd_24414, v_e_24402, v_a_24403, v_k_24415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam86(V self, V *args) {
  V v_e_24402 = args[0];
  V v_a_24403 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24413;
  switch (heff_tag_of(v_alt0_2490)) {
  case TAG_At: {
    V v_x21_24404 = heff_field(v_alt0_2490, 0);
    V v_sp_24405 = heff_field(v_alt0_2490, 1);
    heff_take_n(v_alt0_2490, 3ULL, 2);
    switch (heff_tag_of(v_x21_24404)) {
    case TAG_MkAlt: {
      V v_p_24406 = heff_field(v_x21_24404, 0);
      V v_body_24407 = heff_field(v_x21_24404, 1);
      heff_take_n(v_x21_24404, 3ULL, 2);
      V v_c_24408 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24402, 1)), v_p_24406));
      v_c_24413 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam87, 2, 3, (V[]){v_c_24408, v_body_24407, v_sp_24405});
      break;
    }
    default: heff_nomatch(v_x21_24404);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2490);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam89, 2, 5, (V[]){v_c_24413, v_rhsN_2489, v_n2_2492, v_e_24402, v_a_24403});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam85(V self, V *args) {
  V v_hd_24400 = args[0];
  V v_k_24401 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24400);
  V f_ = v_k_24401;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam86, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam92(V self, V *args) {
  V v_hd_24431 = args[0];
  V v_k_24432 = args[1];
  V v_n2_24430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24431);
  V v_t_24433 = (g_heff_2eelab_2erules_2eabandonChk(v_n2_24430));
  V f_ = v_k_24432;
  args[0] = v_t_24433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam94(V self, V *args) {
  V v_x_24440 = args[0];
  V v_k_24439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24441 = ({ V a_0 = v_x_24440; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop(v_x_24440); r_; });
  V f_ = v_k_24439;
  args[0] = v_t_24441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam93(V self, V *args) {
  V v_hd_24438 = args[0];
  V v_k_24439 = args[1];
  V v_c_24437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24437;
  args[0] = v_hd_24438;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam94, 1, 1, (V[]){v_k_24439});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036(V v_nominal_240, V v_sp_241, V v_c_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_242)));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam0, 2, 4, (V[]){v_t_243, v_sp_241, v_c_242, heff_dup(v_nominal_240)});
}
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_247 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkSyn: {
    V v_f_2412 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    V f_ = v_f_2412;
    heff_room[0] = v_e_247;
    heff_room[1] = v_hd_249;
    heff_room[2] = v_k_2410;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam3(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam4, 1, 3, (V[]){v_e_247, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam2(V self, V *args) {
  V v_e_247 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_248 = (g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009(v_sp_241, v_c_242));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam3, 2, 2, (V[]){v_c_248, v_e_247});
}
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_nominal_240 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_j_2413 = ({ V a_0 = heff_dup(v_sp_241); V a_1 = v_x_246; V b_2 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam2, 1, 2, (V[]){v_sp_241, v_c_242})}); V r_ = (g_heff_2eelab_2erules_2elazyChk(a_0, a_1, b_2)); heff_drop(v_x_246); heff_drop(b_2); r_; });
  V v_t_2414;
  if ((heff_dup(v_nominal_240) == NTAG(TAG_True))) {
    heff_drop(v_nominal_240);
    v_t_2414 = ({ V a_0 = v_j_2413; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop(v_j_2413); r_; });
  } else {
    heff_drop(v_nominal_240);
    v_t_2414 = v_j_2413;
  }
  V v_x_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_t_2414); r_; });
  V f_ = v_k_245;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_t_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_nominal_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_243, v_hd_244, heff_clo_n(g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam1, 1, 4, (V[]){v_sp_241, v_c_242, v_nominal_240, v_k_245})));
}
Clo g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_ab_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_implicit_244 = heff_take_field(v_ab_242, 3);
    V v_name_245 = heff_get_n(v_ab_242, 1, 4);
    switch (heff_tag_of(v_implicit_244)) {
    case TAG_Expl: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_name_245, heff_hole()});
      V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_rest_243;
      V t_1 = v_cell_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Impl: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_name_245);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Inst: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_name_245);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_implicit_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2edeclJ_str0, 45, "unexpected notation for top-level declaration");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edeclJ_str1, 45, "unexpected notation for top-level declaration");
V g_heff_2eelab_2etoplevel_2edeclJ_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2edeclJ_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edeclJ_lam3, 1, 0};
V g_heff_2eelab_2etoplevel_2edeclJ_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam5(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edeclJ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edeclJ_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2edeclJ(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_d1_241 = heff_field(v_d_240, 0);
    switch (heff_tag_of(v_d1_241)) {
    case TAG_DeclEquations: {
      V v_name_243 = heff_field(v_d1_241, 0);
      V v_tyN_246 = heff_field(v_d1_241, 3);
      V v_eqs_247 = heff_field(v_d1_241, 4);
      V v_t_2410;
      switch (heff_tag_of(v_tyN_246)) {
      case TAG_At: {
        V v_s_249 = heff_field(v_tyN_246, 1);
        v_t_2410 = heff_dup(v_s_249);
        break;
      }
      default: heff_nomatch(v_tyN_246);
      }
      V v_t_2413;
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        V v_s_2412 = heff_field(v_d_240, 1);
        v_t_2413 = heff_dup(v_s_2412);
        break;
      }
      default: heff_nomatch(v_d_240);
      }
      V v_t_2414 = ({ V rv_1 = heff_get_n(v_t_2413, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2410, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return (g_heff_2eelab_2etoplevel_2eequationsD(heff_dup(v_name_243), v_tyN_246, heff_dup(v_eqs_247), v_t_2414));
    }
    case TAG_DeclDefine: {
      V v_name_2415 = heff_field(v_d1_241, 0);
      V v_params_2417 = heff_field(v_d1_241, 2);
      V v_tyN_2418 = heff_field(v_d1_241, 3);
      V v_bodyN_2419 = heff_field(v_d1_241, 4);
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        return (g_heff_2eelab_2etoplevel_2edefineD(heff_dup(v_name_2415), heff_dup(v_params_2417), v_tyN_2418, v_bodyN_2419));
      }
      default: return heff_nomatch(v_d_240);
      }
    }
    case TAG_DeclTheory: {
      V v_name_2422 = heff_field(v_d1_241, 0);
      V v_params_2424 = heff_field(v_d1_241, 2);
      V v_bodyN_2425 = heff_field(v_d1_241, 3);
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        return (g_heff_2eelab_2etoplevel_2etheoryD(heff_dup(v_name_2422), heff_dup(v_params_2424), v_bodyN_2425));
      }
      default: return heff_nomatch(v_d_240);
      }
    }
    case TAG_DeclPrimitive: {
      V v_x_2428 = heff_field(v_d1_241, 0);
      V v_tyN_2430 = heff_field(v_d1_241, 2);
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        V v_n_2435;
        switch (heff_tag_of(v_tyN_2430)) {
        case TAG_At: {
          V v_n_2433 = heff_field(v_tyN_2430, 0);
          V v_sp_2434 = heff_field(v_tyN_2430, 1);
          v_n_2435 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(heff_dup(v_sp_2434), heff_dup(v_n_2433)));
          break;
        }
        default: heff_nomatch(v_tyN_2430);
        }
        V v_c_2436 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2435));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam0, 2, 2, (V[]){v_c_2436, heff_dup(v_x_2428)});
      }
      default: return heff_nomatch(v_d_240);
      }
    }
    case TAG_DeclTest: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam4, 2, 1, (V[]){heff_dup(v_d_240)});
    }
    case TAG_DeclWatch: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam5, 2, 1, (V[]){heff_dup(v_d_240)});
    }
    default: return heff_nomatch(v_d1_241);
    }
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2eelab_2etoplevel_2edeclJ_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2edeclJ(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam3(V self, V *args) {
  V v_u_2444 = args[0];
  heff_drop(v_u_2444);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam2(V self, V *args) {
  V v_e_2440 = args[0];
  V v_a_2441 = args[1];
  V v_hd_2442 = args[2];
  V v_k_2443 = args[3];
  V v_x_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2440);
  heff_drop(v_a_2441);
  heff_drop(v_hd_2442);
  V v_t_2445 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_2428}), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_lam3_clo)});
  V f_ = v_k_2443;
  args[0] = v_t_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam1(V self, V *args) {
  V v_x_2439 = args[0];
  V v_x_2428 = heff_env(self)[0];
  V v_k_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){heff_dup(v_x_2428), v_x_2439, heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam2, 4, 1, (V[]){v_x_2428})}), NTAG(TAG_True)});
  V f_ = v_k_2438;
  args[0] = v_t_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam0(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_c_2436 = heff_env(self)[0];
  V v_x_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2436;
  args[0] = v_hd_2437;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam1, 1, 2, (V[]){v_x_2428, v_k_2438});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam4(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k2_2450 = args[1];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2451 = heff_take_field(v_hd_2449, 1);
  V v_malg_2452 = heff_get_n(v_hd_2449, 2, 3);
  V v_t_2455;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_s_2454 = heff_field(v_d_240, 1);
    heff_take_n(v_d_240, 2ULL, 2);
    v_t_2455 = v_s_2454;
    break;
  }
  default: heff_nomatch(v_d_240);
  }
  V v_t_2456 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_str0), v_t_2455, NTAG(TAG_Nothing)});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tr(heff_call(v_malg_2452, 1, (V[]){v_t_2458}));
  V f_ = v_bind_2451;
  args[0] = v_t_2459;
  args[1] = v_k2_2450;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam5(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k2_2462 = args[1];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2463 = heff_take_field(v_hd_2461, 1);
  V v_malg_2464 = heff_get_n(v_hd_2461, 2, 3);
  V v_t_2467;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_s_2466 = heff_field(v_d_240, 1);
    heff_take_n(v_d_240, 2ULL, 2);
    v_t_2467 = v_s_2466;
    break;
  }
  default: heff_nomatch(v_d_240);
  }
  V v_t_2468 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_str1), v_t_2467, NTAG(TAG_Nothing)});
  V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tr(heff_call(v_malg_2464, 1, (V[]){v_t_2470}));
  V f_ = v_bind_2463;
  args[0] = v_t_2471;
  args[1] = v_k2_2462;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2enubInt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enubInt_24dps_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2enubInt_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2ekeepIf_24s512765522x2052101617(v_x_242, v_xs_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2enubInt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2enubInt_24dps(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebodyEnv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyEnv_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ebodyEnv(V v_gSelf_240, V v_k_241, V v_name_242, V v_aval_243) {
top: ;
  V v_v_245 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_k_241)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyEnv_lam0, 1, 1, (V[]){heff_dup(v_aval_243)}), NTAG(TAG_Nothing)));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_name_242, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyEnv_lam1, 1, 1, (V[]){v_v_245})});
  V v_t_249 = heff_tag_n(TAG_CBind, 3, (V[]){NTAG(TAG_CEmpty), heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(1LL)}), v_aval_243});
  V v_t_2410 = heff_tag_n(TAG_ForDescriptive, 2, (V[]){heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_k_241)}), NTAG(TAG_SpId)});
  return heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_rec_n(4, shape_len__names__locals__ctx, (V[]){MK_INT(1LL), v_t_246, v_t_248, v_t_249}), v_gSelf_240, v_t_2410, MK_INT(0LL), heff_tag_n(TAG_Just, 1, (V[]){v_k_241}), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebodyEnv(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_aval_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return v_aval_243;
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_v_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_v_245;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str1, 2, ", ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str2, 20, "` (the runtime has: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str3, 55, ", and each fixed-width type's, `int32Add` and the like)");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str4, 30, "there is no primitive called `");
V g_heff_2eelab_2etoplevel_2eprimKnown_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eprimKnown_lam1(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eprimKnown_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eprimKnown_lam1, 2, 0};
V g_heff_2eelab_2etoplevel_2eprimKnown_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eprimKnown_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eprimKnown_lam2, 2, 0};
Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eprimKnown_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eprimKnown(V v_sp_240, V v_d_241) {
top: ;
  V v_prim_242 = heff_take_field(v_d_241, 3);
  V v_name_243 = heff_get_n(v_d_241, 0, 4);
  if ((heff_dup(v_prim_242) == NTAG(TAG_True))) {
    heff_drop(v_prim_242);
    V v_xs_244 = heff_dup(g_heff_2eelab_2etoplevel_2eprimNames_get());
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_name_243)}));
    V v_x1_246 = ({ V a_0 = v_t_245; V a_1 = v_xs_244; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_244); r_; });
    if (!(heff_dup(v_x1_246) == NTAG(TAG_True))) {
      heff_drop(v_x1_246);
      V v_x2_247 = heff_dup(g_heff_2eelab_2etoplevel_2ebasicPrimNames_get());
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str1); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2411 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str2), heff_strAppend(v_t_2410, ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str3)));
      V v_msg_2412 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str4), heff_strAppend(v_name_243, v_t_2411));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eprimKnown_lam0, 2, 2, (V[]){v_msg_2412, v_sp_240});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_name_243);
      heff_drop(v_x1_246);
      return ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_lam1_clo);
    }
  } else {
    heff_drop(v_sp_240);
    heff_drop(v_prim_242);
    heff_drop(v_name_243);
    return ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_lam2_clo);
  }
}
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eprimKnown(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eprimKnown_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_msg_2412 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2415 = heff_take_field(v_hd_2413, 1);
  V v_malg_2416 = heff_get_n(v_hd_2413, 2, 3);
  V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(329LL), NTAG(TAG_SError), v_msg_2412, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(v_malg_2416, 1, (V[]){v_t_2419}));
  V f_ = v_bind_2415;
  args[0] = v_t_2420;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eprimKnown_lam1(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eprimKnown_lam2(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str0, 34, "the instance's implicit argument `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str1, 100, "` is not in what it is an instance of: a search, unifying that with the type wanted, cannot solve it");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str2, 120, "use it in what the instance is an instance of (`{a : Type} -> {{e : Equality a}} -> Equality (List a)`), or leave it out");
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eeveryImplicitIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eeveryImplicitIn_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eeveryImplicitIn(V v_sp_240, V v_depth_241, V v_conclusion_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sp_240);
    heff_drop(v_depth_241);
    heff_drop(v_conclusion_242);
    return ((V)&g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam0_clo);
  }
  case TAG_Cons: {
    V v_b_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    V v_level_248 = heff_dup(heff_rfield(v_b_246, 1));
    V v_name_249 = heff_dup(heff_rfield(v_b_246, 0));
    V v_t_2410 = heff_intSub(heff_intSub(heff_dup(v_depth_241), MK_INT(1LL)), v_level_248);
    V v_t_2411 = (g_heff_2eelab_2erules_2ementionsLocal(v_t_2410));
    V v_t_2412 = heff_tr(heff_call(heff_get_n(v_t_2411, 1, 3), 2, (V[]){MK_INT(0LL), heff_dup(v_conclusion_242)}));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_name_249);
      heff_drop(v_t_2412);
      V t_0 = v_sp_240;
      V t_1 = v_depth_241;
      V t_2 = v_conclusion_242;
      V t_3 = v_rest_247;
      v_sp_240 = t_0;
      v_depth_241 = t_1;
      v_conclusion_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_depth_241);
      heff_drop(v_conclusion_242);
      heff_drop(v_t_2412);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam1, 2, 2, (V[]){v_name_249, v_sp_240});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_name_249 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2415 = heff_take_field(v_hd_2413, 1);
  V v_malg_2416 = heff_get_n(v_hd_2413, 2, 3);
  V v_t_2417 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str0), heff_strAppend(v_name_249, ((V)&g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str1)));
  V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(350LL), NTAG(TAG_SError), v_t_2417, v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str2)})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_call(v_malg_2416, 1, (V[]){v_t_2420}));
  V f_ = v_bind_2415;
  args[0] = v_t_2421;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str0, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str1, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str2, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str3, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str4, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str5, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str6, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str7, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str8, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str9, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str10, 54, "a watch must say what type it has: write `>>> (e : T)`");
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam10(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ewatchSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchSyn_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ewatchSyn(V v_w_240) {
top: ;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_w1_241 = heff_field(v_w_240, 0);
    switch (heff_tag_of(v_w1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_w1_241, 0);
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        HEFF_LAST return g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_i_243));
      }
      default: return heff_nomatch(v_w_240);
      }
    }
    case TAG_CType: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam0, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CLam: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam1, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CImplicitLam: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam2, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CAnnLam: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam3, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CTag: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam4, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CStruct: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam5, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CMatch: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam6, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CLetIn: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam7, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CLocal: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam8, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CAbandon: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam9, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CNominal: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam10, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    default: return heff_nomatch(v_w1_241);
    }
  }
  default: return heff_nomatch(v_w_240);
  }
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ewatchSyn(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_249 = heff_take_field(v_hd_247, 1);
  V v_malg_2410 = heff_get_n(v_hd_247, 2, 3);
  V v_t_2413;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_2412 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_2413 = v_s_2412;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str0), v_t_2413, NTAG(TAG_Nothing)});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(v_malg_2410, 1, (V[]){v_t_2416}));
  V f_ = v_bind_249;
  args[0] = v_t_2417;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam1(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k2_2422 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2423 = heff_take_field(v_hd_2421, 1);
  V v_malg_2424 = heff_get_n(v_hd_2421, 2, 3);
  V v_t_2427;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_2426 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_2427 = v_s_2426;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str1), v_t_2427, NTAG(TAG_Nothing)});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tr(heff_call(v_malg_2424, 1, (V[]){v_t_2430}));
  V f_ = v_bind_2423;
  args[0] = v_t_2431;
  args[1] = v_k2_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam2(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k2_2436 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2437 = heff_take_field(v_hd_2435, 1);
  V v_malg_2438 = heff_get_n(v_hd_2435, 2, 3);
  V v_t_2441;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_2440 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_2441 = v_s_2440;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str2), v_t_2441, NTAG(TAG_Nothing)});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tr(heff_call(v_malg_2438, 1, (V[]){v_t_2444}));
  V f_ = v_bind_2437;
  args[0] = v_t_2445;
  args[1] = v_k2_2436;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam3(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k2_2451 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2452 = heff_take_field(v_hd_2450, 1);
  V v_malg_2453 = heff_get_n(v_hd_2450, 2, 3);
  V v_t_2456;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_2455 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_2456 = v_s_2455;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str3), v_t_2456, NTAG(TAG_Nothing)});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tr(heff_call(v_malg_2453, 1, (V[]){v_t_2459}));
  V f_ = v_bind_2452;
  args[0] = v_t_2460;
  args[1] = v_k2_2451;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam4(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k2_2465 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2466 = heff_take_field(v_hd_2464, 1);
  V v_malg_2467 = heff_get_n(v_hd_2464, 2, 3);
  V v_t_2470;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_2469 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_2470 = v_s_2469;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2471 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str4), v_t_2470, NTAG(TAG_Nothing)});
  V v_t_2472 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tr(heff_call(v_malg_2467, 1, (V[]){v_t_2473}));
  V f_ = v_bind_2466;
  args[0] = v_t_2474;
  args[1] = v_k2_2465;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam5(V self, V *args) {
  V v_hd_2476 = args[0];
  V v_k2_2477 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2478 = heff_take_field(v_hd_2476, 1);
  V v_malg_2479 = heff_get_n(v_hd_2476, 2, 3);
  V v_t_2482;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_2481 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_2482 = v_s_2481;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2483 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str5), v_t_2482, NTAG(TAG_Nothing)});
  V v_t_2484 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tr(heff_call(v_malg_2479, 1, (V[]){v_t_2485}));
  V f_ = v_bind_2478;
  args[0] = v_t_2486;
  args[1] = v_k2_2477;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam6(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k2_2490 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2491 = heff_take_field(v_hd_2489, 1);
  V v_malg_2492 = heff_get_n(v_hd_2489, 2, 3);
  V v_t_2495;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_2494 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_2495 = v_s_2494;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2496 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str6), v_t_2495, NTAG(TAG_Nothing)});
  V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tr(heff_call(v_malg_2492, 1, (V[]){v_t_2498}));
  V f_ = v_bind_2491;
  args[0] = v_t_2499;
  args[1] = v_k2_2490;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam7(V self, V *args) {
  V v_hd_24102 = args[0];
  V v_k2_24103 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_24104 = heff_take_field(v_hd_24102, 1);
  V v_malg_24105 = heff_get_n(v_hd_24102, 2, 3);
  V v_t_24108;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_24107 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_24108 = v_s_24107;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_24109 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str7), v_t_24108, NTAG(TAG_Nothing)});
  V v_t_24110 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
  V v_t_24112 = heff_tr(heff_call(v_malg_24105, 1, (V[]){v_t_24111}));
  V f_ = v_bind_24104;
  args[0] = v_t_24112;
  args[1] = v_k2_24103;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam8(V self, V *args) {
  V v_hd_24115 = args[0];
  V v_k2_24116 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_24117 = heff_take_field(v_hd_24115, 1);
  V v_malg_24118 = heff_get_n(v_hd_24115, 2, 3);
  V v_t_24121;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_24120 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_24121 = v_s_24120;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_24122 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str8), v_t_24121, NTAG(TAG_Nothing)});
  V v_t_24123 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24122})});
  V v_t_24124 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24123})});
  V v_t_24125 = heff_tr(heff_call(v_malg_24118, 1, (V[]){v_t_24124}));
  V f_ = v_bind_24117;
  args[0] = v_t_24125;
  args[1] = v_k2_24116;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam9(V self, V *args) {
  V v_hd_24126 = args[0];
  V v_k2_24127 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_24128 = heff_take_field(v_hd_24126, 1);
  V v_malg_24129 = heff_get_n(v_hd_24126, 2, 3);
  V v_t_24132;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_24131 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_24132 = v_s_24131;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_24133 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str9), v_t_24132, NTAG(TAG_Nothing)});
  V v_t_24134 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24133})});
  V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
  V v_t_24136 = heff_tr(heff_call(v_malg_24129, 1, (V[]){v_t_24135}));
  V f_ = v_bind_24128;
  args[0] = v_t_24136;
  args[1] = v_k2_24127;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam10(V self, V *args) {
  V v_hd_24138 = args[0];
  V v_k2_24139 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_24140 = heff_take_field(v_hd_24138, 1);
  V v_malg_24141 = heff_get_n(v_hd_24138, 2, 3);
  V v_t_24144;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_24143 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_24144 = v_s_24143;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_24145 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str10), v_t_24144, NTAG(TAG_Nothing)});
  V v_t_24146 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24145})});
  V v_t_24147 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24146})});
  V v_t_24148 = heff_tr(heff_call(v_malg_24141, 1, (V[]){v_t_24147}));
  V f_ = v_bind_24140;
  args[0] = v_t_24148;
  args[1] = v_k2_24139;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabWatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabWatch_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eelabWatch(V v_g_240, V v_n_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_242));
    v_t_245 = heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_243});
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_c_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2eelab_2etoplevel_2ewatchSyn(a_0)); heff_drop(v_t_245); r_; });
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_lam0, 2, 3, (V[]){v_c_246, v_g_240, v_n_241});
}
V g_heff_2eelab_2etoplevel_2eelabWatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eelabWatch(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2415 = heff_field(v_n_241, 1);
    heff_take_n(v_n_241, 2ULL, 2);
    v_t_2416 = v_s_2415;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  return ({ V a_0 = v_g_240; V a_1 = v_t_2416; V a_2 = v_x_2413; V a_3 = v_hd_247; V a_4 = v_k_248; V r_ = (g_heff_2eelab_2etoplevel_2ewatchPhase(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2413); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2412;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkSyn: {
    V v_f_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2411 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_240), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2412 = heff_tr(heff_call(v_f_2410, 1, (V[]){v_t_2411}));
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_lam2, 1, 4, (V[]){v_n_241, v_g_240, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_lam1, 1, 4, (V[]){v_g_240, v_hd_247, v_n_241, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewithInstance_str0, 0, "");
Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithInstance_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ewithInstance(V v_isInstance_240, V v_key_241, V v_name_242, V v_g_243) {
top: ;
  if ((heff_dup(v_isInstance_240) == NTAG(TAG_True))) {
    V v_t_245;
    if (heff_strEq_c_lent(v_key_241, v_name_242, 0)) {
      v_t_245 = ((V)&g_heff_2eelab_2etoplevel_2ewithInstance_str0);
    } else {
      int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_key_241, 0)) - heff_unbox_word(heff_strLength_lent(v_name_242, 0)));
      v_t_245 = heff_strSlice_lent(v_key_241, MK_INT(0LL), heff_box_word((v_t_244 - ((int64_t)1ULL))), 6);
    }
    V v_t_246 = (g_list_2ekeepIf_24s2115931744x466898799(v_key_241, heff_take_field(v_g_243, 7)));
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_key__module, (V[]){v_key_241, v_t_245}), v_t_246});
    return ({ V rv_7 = v_t_247; V rr_ = heff_rec_reuse_nf(v_g_243, 127ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  } else {
    V v_t_248 = (g_list_2eany_24s1547578820x1498276962(v_key_241, heff_rfield(v_g_243, 7)));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = ({ V a_0 = v_key_241; V a_1 = heff_take_field(v_g_243, 7); V r_ = (g_list_2ekeepIf_24s2115931744x466898799(a_0, a_1)); heff_drop(v_key_241); r_; });
      return ({ V rv_7 = v_t_249; V rr_ = heff_rec_reuse_nf(v_g_243, 127ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
    } else {
      heff_drop(v_key_241);
      heff_drop(v_t_248);
      return v_g_243;
    }
  }
}
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2ewithInstance(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2etoplevel_2eonceEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eonceEach_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eonceEach(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seen_240);
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_list_2eany_24s752896332x1549544792(heff_dup(v_d_242), v_seen_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_d_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_seen_240;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_d_242, v_seen_240});
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2eonceEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eonceEach(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V v_acc_240, V v_n_241, V v_diags_242) {
top: ;
  V v_globals_243 = heff_take_field(v_acc_240, 0);
  V v_keys_244 = heff_take_field(v_acc_240, 2);
  V v_broken_245 = heff_take_field(v_acc_240, 3);
  V v_watches_246 = heff_take_field(v_acc_240, 4);
  V v_tests_247 = heff_take_field(v_acc_240, 5);
  V v_spans_248 = heff_take_field(v_acc_240, 6);
  V v_infos_249 = heff_take_field(v_acc_240, 7);
  V v_trace_2410 = heff_get_n(v_acc_240, 8, 9);
  V v_t_2433;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_2411 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_DeclEquations: {
      V v_f_2413 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 5);
      v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){v_f_2413});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2418 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 5);
      v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2418});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2423 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 4);
      v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2423});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2427 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 3);
      v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2427});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2430 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 2);
      v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2430});
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2411, 0ULL, 1);
      v_t_2433 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2411);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_t_2433)) {
  case TAG_Nothing: {
    heff_drop(v_n_241);
    return heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_globals_243, v_diags_242, v_keys_244, v_broken_245, v_watches_246, v_tests_247, v_spans_248, v_infos_249, v_trace_2410});
  }
  case TAG_Just: {
    V v_x_2434 = heff_field(v_t_2433, 0);
    heff_take_n(v_t_2433, 1ULL, 1);
    V v_g_2446;
    if (heff_strEq_c_lent(v_x_2434, v_x_2434, 0)) {
      v_g_2446 = v_globals_243;
    } else {
      V v_g_2435 = v_globals_243;
      V v_ambiguous_2436 = heff_take_field(v_g_2435, 4);
      V v_order_2437 = heff_take_field(v_g_2435, 0);
      V v_entries_2438 = heff_take_field(v_g_2435, 1);
      V v_aliases_2439 = heff_take_field(v_g_2435, 2);
      V v_broken_2440 = heff_take_field(v_g_2435, 3);
      V v_places_2441 = heff_take_field(v_g_2435, 5);
      V v_hidden_2442 = heff_take_field(v_g_2435, 6);
      V v_instances_2443 = heff_get_n(v_g_2435, 7, 8);
      V v_t_2444 = (g_std_2emap_2edelete_24s1614046289x1611773644(v_ambiguous_2436, v_x_2434));
      V v_t_2445 = (g_std_2emap_2einsert_24s93785294x875597928(v_aliases_2439, heff_dup(v_x_2434), heff_dup(v_x_2434)));
      v_g_2446 = heff_rec_n(8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, (V[]){v_order_2437, v_entries_2438, v_t_2445, v_broken_2440, v_t_2444, v_places_2441, v_hidden_2442, v_instances_2443});
    }
    V v_order_2447 = heff_take_field(v_g_2446, 0);
    V v_entries_2448 = heff_take_field(v_g_2446, 1);
    V v_aliases_2449 = heff_take_field(v_g_2446, 2);
    V v_broken_2450 = heff_take_field(v_g_2446, 3);
    V v_ambiguous_2451 = heff_take_field(v_g_2446, 4);
    V v_places_2452 = heff_take_field(v_g_2446, 5);
    V v_hidden_2453 = heff_take_field(v_g_2446, 6);
    V v_instances_2454 = heff_get_n(v_g_2446, 7, 8);
    V v_t_2455 = (g_std_2emap_2einsert_24s93785294x875597928(v_broken_2450, heff_dup(v_x_2434), NTAG(TAG_MkUnit)));
    V v_globals_2456 = (g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720(heff_dup(v_n_241), heff_rec_n(8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, (V[]){v_order_2447, v_entries_2448, v_aliases_2449, v_t_2455, v_ambiguous_2451, v_places_2452, v_hidden_2453, v_instances_2454})));
    V v_t_2459;
    switch (heff_tag_of(v_n_241)) {
    case TAG_At: {
      V v_s_2458 = heff_field(v_n_241, 1);
      heff_take_n(v_n_241, 2ULL, 2);
      v_t_2459 = v_s_2458;
      break;
    }
    default: heff_nomatch(v_n_241);
    }
    V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2434, v_t_2459}), v_broken_245});
    return heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_globals_2456, v_diags_242, v_keys_244, v_t_2460, v_watches_246, v_tests_247, v_spans_248, v_infos_249, v_trace_2410});
  }
  default: return heff_nomatch(v_t_2433);
  }
}
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam5, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam6(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam6, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam7(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam7, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam8(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam8, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(V v_g_240, V v_n_241, V v_st_242) {
top: ;
  V v_c_246;
  switch (heff_tag_of(v_st_242)) {
  case TAG_MkSt: {
    V v_c_243 = heff_dup(heff_field(v_st_242, 0));
    v_c_246 = v_c_243;
    break;
  }
  default: heff_nomatch(v_st_242);
  }
  V v_infos_247 = heff_take_field(v_c_246, 0);
  V v_recovered_248 = heff_take_field(v_c_246, 1);
  V v_poisoned_249 = heff_take_field(v_c_246, 2);
  V v_metas_2410 = heff_take_field(v_c_246, 3);
  V v_nextMeta_2411 = heff_take_field(v_c_246, 4);
  V v_postponed_2412 = heff_take_field(v_c_246, 5);
  V v_trace_2413 = heff_get_n(v_c_246, 6, 8);
  V v_c_2414 = (g_heff_2eelab_2etoplevel_2edeclJ(v_n_241));
  V v_t_2419;
  switch (heff_tag_of(v_st_242)) {
  case TAG_MkSt: {
    V v_d_2416 = heff_field(v_st_242, 1);
    V v_w_2417 = heff_field(v_st_242, 2);
    V v_ru_24st_242_24MkSt = heff_take_reuse_n(v_st_242, 6ULL, 3);
    V v_t_2418 = heff_rec_n(8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, (V[]){v_infos_247, v_recovered_248, v_poisoned_249, v_metas_2410, v_nextMeta_2411, v_postponed_2412, v_trace_2413, NTAG(TAG_Nothing)});
    v_t_2419 = heff_tag_at_n(v_ru_24st_242_24MkSt, TAG_MkSt, 3, (V[]){v_t_2418, v_d_2416, v_w_2417});
    break;
  }
  default: heff_nomatch(v_st_242);
  }
  return heff_tail(v_c_2414, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0, 1, 2, (V[]){v_g_240, v_n_241}), v_t_2419});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  heff_drop(v_hd_2446);
  V f_ = v_k_2447;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam5(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k_2453 = args[1];
  heff_drop(v_hd_2452);
  V f_ = v_k_2453;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam6(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k_2458 = args[1];
  heff_drop(v_hd_2457);
  V f_ = v_k_2458;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam7(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  heff_drop(v_hd_2461);
  V f_ = v_k_2462;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam8(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  heff_drop(v_hd_2464);
  V f_ = v_k_2465;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam9(V self, V *args) {
  V v_x_2467 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_x_2420 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2467);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_clo);
  heff_room[0] = v_g_240;
  heff_room[1] = v_n_241;
  heff_room[2] = v_x_2420;
  heff_room[3] = v_x_2425;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_z_2427 = args[1];
  V v_n_241 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2426);
  V v_c_2466;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_2428 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_x11_2428)) {
    case TAG_DeclEquations: {
      V v_x113_2432 = heff_field(v_x11_2428, 2);
      V v_tyN_2433 = heff_field(v_x11_2428, 3);
      heff_take_n(v_x11_2428, 12ULL, 5);
      switch (heff_tag_of(v_x113_2432)) {
      case TAG_AsDefinition: {
        heff_drop(v_tyN_2433);
        v_c_2466 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3_clo);
        break;
      }
      case TAG_AsInstance: {
        V v_t_2439;
        switch (heff_tag_of(v_tyN_2433)) {
        case TAG_At: {
          V v_s_2438 = heff_field(v_tyN_2433, 1);
          heff_take_n(v_tyN_2433, 2ULL, 2);
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_tyN_2433);
        }
        V v_t_2440 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(heff_dup(heff_rfield(v_x_2425, 0))));
        v_c_2466 = (g_heff_2eelab_2etoplevel_2esearchedInstance(v_t_2439, NTAG(TAG_Nil), MK_INT(0LL), v_t_2440));
        break;
      }
      default: heff_nomatch(v_x113_2432);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2428, 0ULL, 5);
      v_c_2466 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4_clo);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2428, 0ULL, 4);
      v_c_2466 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam5_clo);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2428, 0ULL, 3);
      v_c_2466 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam6_clo);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2428, 0ULL, 2);
      v_c_2466 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam7_clo);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2428, 0ULL, 1);
      v_c_2466 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam8_clo);
      break;
    }
    default: heff_nomatch(v_x11_2428);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V f_ = v_c_2466;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam9, 1, 4, (V[]){v_g_240, v_n_241, v_x_2420, v_x_2425});
  heff_room[2] = v_z_2427;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1(V self, V *args) {
  V v_x_2425 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_2420 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo);
  args[0] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2, 2, 4, (V[]){v_n_241, v_x_2425, v_g_240, v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_dup(heff_rfield(v_x_2420, 1));
  V v_c_2424;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_MkTyp: {
    V v_f_2422 = heff_field(v_t_2421, 0);
    heff_take_n(v_t_2421, 1ULL, 1);
    V v_t_2423 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_240), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2424 = heff_tr(heff_call(v_f_2422, 1, (V[]){v_t_2423}));
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1, 1, 3, (V[]){v_n_241, v_g_240, v_x_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2etoplevel_2ewithOne_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithOne_24tok2_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2ewithOne_24tok2(V v_tok_240, V v_ab_241, V v_x2_242) {
top: ;
  V v_implicit_243 = heff_take_field(v_ab_241, 3);
  V v_name_244 = heff_take_field(v_ab_241, 1);
  V v_typ_245 = heff_take_field(v_ab_241, 2);
  V v_span_246 = heff_get_n(v_ab_241, 0, 4);
  switch (heff_tag_of(v_implicit_243)) {
  case TAG_Expl: {
    switch (heff_tag_of(v_x2_242)) {
    case TAG_MkPair: {
      V v_t_247 = heff_field(v_x2_242, 0);
      V v_c_248 = heff_field(v_x2_242, 1);
      V v_ru_24x2_242_24MkPair = heff_take_reuse_n(v_x2_242, 3ULL, 2);
      V v_t_249 = ({ V a_0 = heff_tag_at_n(v_tok_240, TAG_Named, 2, (V[]){heff_dup(v_name_244), v_typ_245}); V a_1 = v_t_247; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_247); r_; });
      V v_t_2410 = ({ V a_0 = v_span_246; V a_1 = v_name_244; V a_2 = v_c_248; V r_ = (g_heff_2eelab_2erules_2efunctionIntro(a_0, a_1, a_2)); heff_drop(v_c_248); r_; });
      return heff_tag_at_n(v_ru_24x2_242_24MkPair, TAG_MkPair, 2, (V[]){v_t_249, v_t_2410});
    }
    default: return heff_nomatch(v_x2_242);
    }
  }
  case TAG_Impl: {
    switch (heff_tag_of(v_x2_242)) {
    case TAG_MkPair: {
      V v_t_2411 = heff_field(v_x2_242, 0);
      V v_c_2412 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      V v_t_2413 = heff_tag_n(TAG_NamedImplicit, 4, (V[]){heff_dup(v_span_246), heff_dup(v_name_244), v_typ_245, NTAG(TAG_Nothing)});
      V v_t_2414 = ({ V a_0 = v_t_2413; V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_2411); r_; });
      V v_t_2415 = ({ V a_0 = v_span_246; V a_1 = v_name_244; V a_2 = v_c_2412; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_c_2412); r_; });
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_t_2414, v_t_2415});
    }
    default: return heff_nomatch(v_x2_242);
    }
  }
  case TAG_Inst: {
    switch (heff_tag_of(v_x2_242)) {
    case TAG_MkPair: {
      V v_t_2416 = heff_field(v_x2_242, 0);
      V v_c_2417 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      V v_t_2418 = ({ V a_0 = heff_tag_n(TAG_NamedInstance, 3, (V[]){heff_dup(v_span_246), heff_dup(v_name_244), v_typ_245}); V a_1 = v_t_2416; V r_ = (g_heff_2eelab_2erules_2efunctionFormation(a_0, a_1)); heff_drop(v_t_2416); r_; });
      V v_t_2419 = ({ V a_0 = v_span_246; V a_1 = v_name_244; V a_2 = v_c_2417; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_c_2417); r_; });
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_t_2418, v_t_2419});
    }
    default: return heff_nomatch(v_x2_242);
    }
  }
  default: return heff_nomatch(v_implicit_243);
  }
}
V g_heff_2eelab_2etoplevel_2ewithOne_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewithOne_24tok2(a[0], a[1], a[2]);
}