// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Expl 20488
#define TAG_ForNominative 23095
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_INotationVar 46285
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_Large 60129
#define TAG_MkAbs 54862
#define TAG_MkAlt 55173
#define TAG_MkChk 56962
#define TAG_MkEquation 38417
#define TAG_MkSt 48854
#define TAG_MkTyp 8305
#define TAG_PatVar 49363
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIsTy 43896
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9006
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_TInf 28962
#define TAG_Throw 56084
#define TAG_TopL 65516
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_arms 9498206
#define LBL_bind 9519364
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_elabFor 712452832
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_evidence 1128105991
#define LBL_globals 352931696
#define LBL_hidden 729654485
#define LBL_implicit 319715269
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_order 307364712
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_tests 311609915
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_unreached 121683306
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace, LBL_unreached};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey, LBL_arms};
static uint32_t shape_key__module[] = {LBL_key, LBL_module};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static uint32_t shape_scope__globals__elabFor__lams__self__insts__named__evidence[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts, LBL_named, LBL_evidence};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_co_2ebind_24s196996678x1811735276(V, V, V);
V g_co_2ebind_24s196996678x1811735276_entry(V self, V *a);
extern Clo g_co_2ebind_24s196996678x1811735276_clo;
V g_heff_2eelab_2eenvironment_2eemptyScope_get(void);
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
V g_heff_2eelab_2ememoed_2eabandonM_get(void);
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2eprimitive_2elibraryTable_get(void);
V g_heff_2eelab_2erules_2eapplyResultFirst(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eapplyResultFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapplyResultFirst_clo;
V g_heff_2eelab_2erules_2eautoRec(V, V, V);
V g_heff_2eelab_2erules_2eautoRec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eautoRec_clo;
V g_heff_2eelab_2erules_2eautoRec_24tok1(V, V, V, V);
V g_heff_2eelab_2erules_2eautoRec_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eautoRec_24tok1_clo;
V g_heff_2eelab_2erules_2ebindingSyn(V, V);
V g_heff_2eelab_2erules_2ebindingSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ebindingSyn_clo;
V g_heff_2eelab_2erules_2ecaseLet(V, V, V);
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseLet_clo;
V g_heff_2eelab_2erules_2eevidenceSearch_get(void);
V g_heff_2eelab_2erules_2efunctionIntroAnn(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo;
V g_heff_2eelab_2erules_2efunctionIntroImplicit(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo;
V g_heff_2eelab_2erules_2elambdaChk(V, V, V, V);
V g_heff_2eelab_2erules_2elambdaChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elambdaChk_clo;
V g_heff_2eelab_2erules_2erecordIntro(V, V);
V g_heff_2eelab_2erules_2erecordIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordIntro_clo;
V g_heff_2eelab_2erules_2etagChk(V, V, V, V, V);
V g_heff_2eelab_2erules_2etagChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagChk_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934(V);
V g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934_clo;
V g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123(V, V, V);
V g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_clo;
V g_heff_2eelab_2etoplevel_2eappChk_2eapplied_242(V, V, V);
V g_heff_2eelab_2etoplevel_2eappChk_2eapplied_242_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappChk_2eapplied_242_clo;
V g_heff_2eelab_2etoplevel_2ebasicPrimNames_get(void);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2ecoveredAbove_get(void);
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980(V, V, V);
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_clo;
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_clo;
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(V, V);
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_clo;
V g_heff_2eelab_2etoplevel_2ehasOpPat(V);
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(V, V);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_clo;
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_clo;
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2enubInt_24dps(V, V);
V g_heff_2eelab_2etoplevel_2enubInt_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_24dps_clo;
V g_heff_2eelab_2etoplevel_2eonceEach(V, V);
V g_heff_2eelab_2etoplevel_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eonceEach_clo;
V g_heff_2eelab_2etoplevel_2eopPat(V, V);
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eopPat_clo;
V g_heff_2eelab_2etoplevel_2epairOfHoles(V);
V g_heff_2eelab_2etoplevel_2epairOfHoles_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epairOfHoles_clo;
HeffT3 g_heff_2eelab_2etoplevel_2eparamsOf_24cpr(V, V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo;
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo;
V g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076_clo;
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo;
V g_heff_2eelab_2etoplevel_2etupleFront(V, V);
V g_heff_2eelab_2etoplevel_2etupleFront_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleFront_clo;
V g_heff_2eelab_2etoplevel_2etupleValueRev(V, V);
V g_heff_2eelab_2etoplevel_2etupleValueRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleValueRev_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2einfSpineOf_24cpr(V);
V g_heff_2esyntax_2esurfaceprint_2eunIsTy(V);
V g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eunIsTy_clo;
V g_list_2eany_24s1547578820x1498276962(V, V);
V g_list_2eany_24s1547578820x1498276962_entry(V self, V *a);
extern Clo g_list_2eany_24s1547578820x1498276962_clo;
V g_list_2eany_24s752896332x1549544792(V, V);
V g_list_2eany_24s752896332x1549544792_entry(V self, V *a);
extern Clo g_list_2eany_24s752896332x1549544792_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s2115931744x466898799(V, V);
V g_list_2ekeepIf_24s2115931744x466898799_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2115931744x466898799_clo;
V g_list_2ekeepIf_24s512765522x2052101617(V, V);
V g_list_2ekeepIf_24s512765522x2052101617_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s512765522x2052101617_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s1413153166x427060745(V, V, V);
V g_prelude_2etraverse_24s1413153166x427060745_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1413153166x427060745_clo;
V g_prelude_2etraverse_24s1797919465x75214466(V);
V g_prelude_2etraverse_24s1797919465x75214466_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1797919465x75214466_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_prelude_2etraverse_24s87601361x1873011385(V);
V g_prelude_2etraverse_24s87601361x1873011385_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s87601361x1873011385_clo;
V g_std_2eordmap_2edelete_24s2135745297x1725920174(V, V);
V g_std_2eordmap_2edelete_24s2135745297x1725920174_entry(V self, V *a);
extern Clo g_std_2eordmap_2edelete_24s2135745297x1725920174_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
HEFF_LIT(g_heff_2eelab_2etoplevel_2ecoveredAbove_str0, 43, "the arms above it match every value it does");

static V g_heff_2eelab_2etoplevel_2ecoveredAbove_val;
static HEFF_ONCE g_heff_2eelab_2etoplevel_2ecoveredAbove_st;
static V g_heff_2eelab_2etoplevel_2ecoveredAbove_init(void) {
  return ((V)&g_heff_2eelab_2etoplevel_2ecoveredAbove_str0);
}
V g_heff_2eelab_2etoplevel_2ecoveredAbove_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2etoplevel_2ecoveredAbove_st)) return g_heff_2eelab_2etoplevel_2ecoveredAbove_val;
  return heff_global(&g_heff_2eelab_2etoplevel_2ecoveredAbove_val, &g_heff_2eelab_2etoplevel_2ecoveredAbove_st, g_heff_2eelab_2etoplevel_2ecoveredAbove_init);
}

HeffT3 g_heff_2eelab_2etoplevel_2eparamsOf_24cpr(V v_i_240, V v_e_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SU: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_i_240, v_e_241}});
  }
  case TAG_SDecode: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_i_240, v_e_241}});
  }
  case TAG_SFunction: {
    V v_cod_247 = heff_field(v_x3_242, 2);
    V v_x34_248 = heff_field(v_x3_242, 3);
    heff_take_n(v_x3_242, 12ULL, 5);
    switch (heff_tag_of(v_x34_248)) {
    case TAG_Expl: {
      V v_t_2413;
      switch (heff_tag_of(v_cod_247)) {
      case TAG_MkAbs: {
        V v_t_2411 = heff_field(v_cod_247, 1);
        heff_take_n(v_cod_247, 2ULL, 2);
        v_t_2413 = v_t_2411;
        break;
      }
      case TAG_AbsConst: {
        V v_t_2412 = heff_field(v_cod_247, 0);
        heff_take_n(v_cod_247, 1ULL, 1);
        v_t_2413 = v_t_2412;
        break;
      }
      default: heff_nomatch(v_cod_247);
      }
      V t_0 = v_i_240;
      V t_1 = heff_intAdd(v_e_241, MK_INT(1LL));
      V t_2 = v_t_2413;
      v_i_240 = t_0;
      v_e_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Impl: {
      if (heff_intLt_c_lent(MK_INT(0LL), v_e_241, 1)) {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        heff_drop(v_cod_247);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      } else {
        V v_t_2417;
        switch (heff_tag_of(v_cod_247)) {
        case TAG_MkAbs: {
          V v_t_2415 = heff_field(v_cod_247, 1);
          heff_take_n(v_cod_247, 2ULL, 2);
          v_t_2417 = v_t_2415;
          break;
        }
        case TAG_AbsConst: {
          V v_t_2416 = heff_field(v_cod_247, 0);
          heff_take_n(v_cod_247, 1ULL, 1);
          v_t_2417 = v_t_2416;
          break;
        }
        default: heff_nomatch(v_cod_247);
        }
        V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
        V t_1 = v_e_241;
        V t_2 = v_t_2417;
        v_i_240 = t_0;
        v_e_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_Inst: {
      heff_drop(v_i_240);
      heff_drop(v_e_241);
      heff_drop(v_cod_247);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    default: return ((HeffT3){{heff_nomatch(v_x34_248)}});
    }
  }
  case TAG_SRecord: {
    heff_take_n(v_x3_242, 0ULL, 3);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_i_240, v_e_241}});
  }
  case TAG_SSum: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_i_240, v_e_241}});
  }
  case TAG_SIsTy: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_i_240, v_e_241}});
  }
  case TAG_SPrimInt: {
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_i_240, v_e_241}});
  }
  case TAG_SPrimFloat: {
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_i_240, v_e_241}});
  }
  case TAG_SPrimString: {
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_i_240, v_e_241}});
  }
  case TAG_SPrimRune: {
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_i_240, v_e_241}});
  }
  case TAG_SPrimArray: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_i_240, v_e_241}});
  }
  case TAG_SFixed: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_i_240, v_e_241}});
  }
  default: return ((HeffT3){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_249 = (g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187(v_a_247));
        v_a_2410 = heff_bool(!(heff_dup(v_a_249) == NTAG(TAG_True)));
        heff_drop(v_a_249);
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if (!(heff_dup(v_a_2410) == NTAG(TAG_True))) {
      heff_drop(v_a_2410);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_a_2410);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2etupleFront_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etupleFront_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etupleFront(V v_sp_240, V v_rs_241) {
top: ;
  switch (heff_tag_of(v_rs_241)) {
  case TAG_Nil: {
    V v_i_2410;
    switch (heff_tag_of(v_rs_241)) {
    case TAG_Nil: {
      V v_t_242 = heff_tag_n(TAG_ITuple, 1, (V[]){NTAG(TAG_Nil)});
      v_i_2410 = heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_sp_240});
      break;
    }
    case TAG_Cons: {
      V v_r_243 = heff_dup(heff_field(v_rs_241, 0));
      V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rs_241));
      V v_t_248;
      switch (heff_tag_of(v_r_243)) {
      case TAG_At: {
        V v_s_247 = heff_field(v_r_243, 1);
        heff_take_n(v_r_243, 2ULL, 2);
        v_t_248 = v_s_247;
        break;
      }
      default: heff_nomatch(v_r_243);
      }
      V v_t_249 = ({ V rv_1 = heff_get_n(v_t_248, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      v_i_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ITuple, 1, (V[]){v_t_245}), v_t_249});
      break;
    }
    default: heff_nomatch(v_rs_241);
    }
    V v_t_2413;
    switch (heff_tag_of(v_i_2410)) {
    case TAG_At: {
      V v_s_2412 = heff_dup(heff_field(v_i_2410, 1));
      v_t_2413 = v_s_2412;
      break;
    }
    default: heff_nomatch(v_i_2410);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2410}), v_t_2413});
  }
  case TAG_Cons: {
    V v_rs2_2415 = heff_dup(heff_field(v_rs_241, 1));
    switch (heff_tag_of(v_rs2_2415)) {
    case TAG_Nil: {
      heff_drop_rec(v_sp_240, 2);
      switch (heff_tag_of(v_rs_241)) {
      case TAG_Cons: {
        V v_a_2416 = heff_field(v_rs_241, 0);
        heff_take_n(v_rs_241, 1ULL, 2);
        return v_a_2416;
      }
      default: return heff_nomatch(v_rs_241);
      }
    }
    case TAG_Cons: {
      V v_ru_24rs2_2415_24Cons = heff_take_reuse_n(v_rs2_2415, 0ULL, 2);
      V v_i_2428;
      switch (heff_tag_of(v_rs_241)) {
      case TAG_Nil: {
        V v_t_2420 = heff_tag_n(TAG_ITuple, 1, (V[]){NTAG(TAG_Nil)});
        v_i_2428 = heff_tag_at_n(v_ru_24rs2_2415_24Cons, TAG_At, 2, (V[]){v_t_2420, v_sp_240});
        break;
      }
      case TAG_Cons: {
        V v_r_2421 = heff_dup(heff_field(v_rs_241, 0));
        V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rs_241));
        V v_t_2426;
        switch (heff_tag_of(v_r_2421)) {
        case TAG_At: {
          V v_s_2425 = heff_field(v_r_2421, 1);
          heff_take_n(v_r_2421, 2ULL, 2);
          v_t_2426 = v_s_2425;
          break;
        }
        default: heff_nomatch(v_r_2421);
        }
        V v_t_2427 = ({ V rv_1 = heff_get_n(v_t_2426, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        v_i_2428 = heff_tag_at_n(v_ru_24rs2_2415_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_ITuple, 1, (V[]){v_t_2423}), v_t_2427});
        break;
      }
      default: heff_nomatch(v_rs_241);
      }
      V v_t_2431;
      switch (heff_tag_of(v_i_2428)) {
      case TAG_At: {
        V v_s_2430 = heff_dup(heff_field(v_i_2428, 1));
        v_t_2431 = v_s_2430;
        break;
      }
      default: heff_nomatch(v_i_2428);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2428}), v_t_2431});
    }
    default: return heff_nomatch(v_rs2_2415);
    }
  }
  default: return heff_nomatch(v_rs_241);
  }
}
V g_heff_2eelab_2etoplevel_2etupleFront_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etupleFront(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleValueRev_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleValueRev_str1, 12, "builtin.Unit");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleValueRev_str2, 6, "MkPair");
Clo g_heff_2eelab_2etoplevel_2etupleValueRev_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etupleValueRev_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etupleValueRev(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleValueRev_str0), heff_dup(v_sp_240), NTAG(TAG_Nil)});
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleValueRev_str1)}), heff_dup(v_sp_240)});
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_t_243}), heff_dup(v_sp_240)});
    V v_t_245 = heff_tag_n(TAG_IAnn, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_242, heff_dup(v_sp_240)}), v_t_244});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_240});
  }
  case TAG_Cons: {
    V v_z_246 = heff_field(v_x2_241, 0);
    V v_rs_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = (g_heff_2eelab_2etoplevel_2etupleFront(heff_dup(v_sp_240), v_rs_247));
    V v_t_249 = (g_heff_2eelab_2etoplevel_2epairOfHoles(heff_dup(v_sp_240)));
    V v_t_2410 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_z_246, NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleValueRev_str2), heff_dup(v_sp_240), heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_IAnn, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_240)}), v_t_249});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_sp_240});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2etupleValueRev_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etupleValueRev(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_247;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        v_a_247 = (g_heff_2eelab_2etoplevel_2ehasOpPat(v_a_245));
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if (!(heff_dup(v_a_247) == NTAG(TAG_True))) {
      heff_drop(v_a_247);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_a_247);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123(V v_i_240, V v_h_241, V v_args_242) {
top: ;
  V v_c_243 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_h_241)));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_lam0, 2, 4, (V[]){v_c_243, v_args_242, v_i_240, v_h_241});
}
V g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_lam3(V self, V *args) {
  V v_s_2462 = args[0];
  V v_h_241 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_t_2465;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_h_241)) {
  case TAG_At: {
    V v_s_2464 = heff_field(v_h_241, 1);
    heff_take_n(v_h_241, 2ULL, 2);
    v_t_2465 = v_s_2464;
    break;
  }
  default: heff_nomatch(v_h_241);
  }
  return ({ V a_0 = heff_get_n(v_t_2465, 0, 2); V a_1 = v_s_2462; V a_2 = v_x_247; V r_ = (g_heff_2eelab_2etoplevel_2eappChk_2eapplied_242(a_0, a_1, a_2)); heff_drop(v_x_247); r_; });
}
V g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_i_240 = heff_env(self)[0];
  V v_h_241 = heff_env(self)[1];
  V v_args_242 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_i_248 = heff_dup(v_i_240);
  V v_t_2411;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_i_240)) {
  case TAG_At: {
    V v_s_2410 = heff_dup(heff_field(v_i_240, 1));
    v_t_2411 = v_s_2410;
    break;
  }
  default: heff_nomatch(v_i_240);
  }
  V v_t_2414;
  switch (heff_tag_of(v_h_241)) {
  case TAG_At: {
    V v_s_2413 = heff_dup(heff_field(v_h_241, 1));
    v_t_2414 = v_s_2413;
    break;
  }
  default: heff_nomatch(v_h_241);
  }
  V v_t_2422;
  switch (heff_tag_of(v_args_242)) {
  case TAG_Nil: {
    V v_t_2417;
    switch (heff_tag_of(v_i_240)) {
    case TAG_At: {
      V v_s_2416 = heff_dup(heff_field(v_i_240, 1));
      v_t_2417 = v_s_2416;
      break;
    }
    default: heff_nomatch(v_i_240);
    }
    v_t_2422 = heff_get_n(v_t_2417, 1, 2);
    break;
  }
  case TAG_Cons: {
    V v_x11_2418 = heff_dup(heff_field(v_args_242, 0));
    switch (heff_tag_of(v_x11_2418)) {
    case TAG_At: {
      V v_sp_2421 = heff_field(v_x11_2418, 1);
      heff_take_n(v_x11_2418, 2ULL, 2);
      v_t_2422 = heff_get_n(v_sp_2421, 1, 2);
      break;
    }
    default: heff_nomatch(v_x11_2418);
    }
    break;
  }
  default: heff_nomatch(v_args_242);
  }
  V v_t_2459;
  switch (heff_tag_of(v_i_240)) {
  case TAG_At: {
    V v_x11_2423 = heff_field(v_i_240, 0);
    heff_take_n(v_i_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2423)) {
    case TAG_IVar: {
      heff_take_n(v_x11_2423, 0ULL, 1);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_INotationVar: {
      heff_take_n(v_x11_2423, 0ULL, 3);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_IInt: {
      heff_take_n(v_x11_2423, 0ULL, 1);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_IFloat: {
      heff_take_n(v_x11_2423, 0ULL, 1);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_IString: {
      heff_take_n(v_x11_2423, 0ULL, 1);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_IBytes: {
      heff_take_n(v_x11_2423, 0ULL, 1);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_IPrim: {
      heff_take_n(v_x11_2423, 0ULL, 1);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_x11_2423, 0ULL, 1);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_x11_2423, 0ULL, 2);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_x11_2423, 0ULL, 2);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_x11_2423, 0ULL, 4);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_IUpdate: {
      heff_take_n(v_x11_2423, 0ULL, 2);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_x11_2423, 0ULL, 4);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_x11_2423, 0ULL, 3);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_INominal: {
      heff_take_n(v_x11_2423, 0ULL, 1);
      v_t_2459 = NTAG(TAG_True);
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_x11_2423, 0ULL, 4);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_ILazy: {
      heff_take_n(v_x11_2423, 0ULL, 1);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    case TAG_ITuple: {
      heff_take_n(v_x11_2423, 0ULL, 1);
      v_t_2459 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2423);
    }
    break;
  }
  default: heff_nomatch(v_i_240);
  }
  V v_t_2460 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_242); r_; });
  V v_t_2461 = ({ V rv_1 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_t_2414, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_j_2466 = ({ V a_0 = v_t_2411; V a_1 = v_t_2461; V a_2 = v_t_2459; V a_3 = v_x_246; V a_4 = v_t_2460; V a_5 = heff_clo_n(g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_lam3, 1, 2, (V[]){v_h_241, v_x_247}); V r_ = (g_heff_2eelab_2erules_2eapplyResultFirst(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2459); r_; });
  V v_t_24105;
  switch (heff_tag_of(v_i_248)) {
  case TAG_At: {
    V v_x11_2467 = heff_dup(heff_field(v_i_248, 0));
    switch (heff_tag_of(v_x11_2467)) {
    case TAG_IVar: {
      heff_take_n(v_x11_2467, 0ULL, 1);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_INotationVar: {
      heff_take_n(v_x11_2467, 0ULL, 3);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_IInt: {
      heff_take_n(v_x11_2467, 0ULL, 1);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_IFloat: {
      heff_take_n(v_x11_2467, 0ULL, 1);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_IString: {
      heff_take_n(v_x11_2467, 0ULL, 1);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_IBytes: {
      heff_take_n(v_x11_2467, 0ULL, 1);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_IPrim: {
      heff_take_n(v_x11_2467, 0ULL, 1);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_x11_2467, 0ULL, 1);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_x11_2467, 0ULL, 2);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_x11_2467, 0ULL, 2);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_x11_2467, 0ULL, 4);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_IUpdate: {
      heff_take_n(v_x11_2467, 0ULL, 2);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_x11_2467, 0ULL, 4);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_x11_2467, 0ULL, 3);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_INominal: {
      V v_i_2496 = heff_field(v_x11_2467, 0);
      heff_take_n(v_x11_2467, 1ULL, 1);
      switch (heff_tag_of(v_i_248)) {
      case TAG_At: {
        v_t_24105 = v_i_2496;
        break;
      }
      default: heff_nomatch(v_i_248);
      }
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_x11_2467, 0ULL, 4);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_ILazy: {
      heff_take_n(v_x11_2467, 0ULL, 1);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    case TAG_ITuple: {
      heff_take_n(v_x11_2467, 0ULL, 1);
      v_t_24105 = heff_dup(v_i_248);
      break;
    }
    default: heff_nomatch(v_x11_2467);
    }
    break;
  }
  default: heff_nomatch(v_i_248);
  }
  HeffT2 v_t_24106 = (g_heff_2esyntax_2epresyntax_2einfSpineOf_24cpr(v_t_24105));
  {
    V v_field_24107 = v_t_24106.f[0];
    heff_drop(v_t_24106.f[1]);
    V v_t_24109 = v_field_24107;
    V v_x_24149;
    switch (heff_tag_of(v_t_24109)) {
    case TAG_At: {
      V v_it1_24110 = heff_field(v_t_24109, 0);
      heff_take_n(v_t_24109, 1ULL, 2);
      switch (heff_tag_of(v_it1_24110)) {
      case TAG_IVar: {
        V v_x_24112 = heff_field(v_it1_24110, 0);
        V v_ru_24it1_24110_24IVar = heff_take_reuse_n(v_it1_24110, 1ULL, 1);
        V v_t_24115;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_24114 = heff_field(v_i_248, 1);
          heff_take_n(v_i_248, 2ULL, 2);
          v_t_24115 = v_s_24114;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_x_24149 = ({ V a_0 = v_ru_24it1_24110_24IVar; V a_1 = v_t_24115; V a_2 = v_x_24112; V a_3 = v_j_2466; V r_ = (g_heff_2eelab_2erules_2eautoRec_24tok1(a_0, a_1, a_2, a_3)); heff_drop(v_x_24112); r_; });
        break;
      }
      case TAG_INotationVar: {
        heff_take_n(v_it1_24110, 0ULL, 3);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_IInt: {
        heff_take_n(v_it1_24110, 0ULL, 1);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_IFloat: {
        heff_take_n(v_it1_24110, 0ULL, 1);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_IString: {
        heff_take_n(v_it1_24110, 0ULL, 1);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_IBytes: {
        heff_take_n(v_it1_24110, 0ULL, 1);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_IPrim: {
        heff_take_n(v_it1_24110, 0ULL, 1);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_IRune: {
        heff_take_n(v_it1_24110, 0ULL, 1);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_IApp: {
        heff_take_n(v_it1_24110, 0ULL, 2);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_IAnn: {
        heff_take_n(v_it1_24110, 0ULL, 2);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_ISpec: {
        heff_take_n(v_it1_24110, 0ULL, 4);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_IUpdate: {
        heff_take_n(v_it1_24110, 0ULL, 2);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_IAnnLam: {
        heff_take_n(v_it1_24110, 0ULL, 4);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_IInvalid: {
        heff_take_n(v_it1_24110, 0ULL, 3);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_INominal: {
        heff_take_n(v_it1_24110, 0ULL, 1);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_ILitEq: {
        heff_take_n(v_it1_24110, 0ULL, 4);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_ILazy: {
        heff_take_n(v_it1_24110, 0ULL, 1);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      case TAG_ITuple: {
        heff_take_n(v_it1_24110, 0ULL, 1);
        heff_drop(v_i_248);
        v_x_24149 = v_j_2466;
        break;
      }
      default: heff_nomatch(v_it1_24110);
      }
      break;
    }
    default: heff_nomatch(v_t_24109);
    }
    V f_ = v_k_245;
    args[0] = v_x_24149;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_args_242 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_i_240 = heff_env(self)[2];
  V v_h_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_prelude_2etraverse_24s1413153166x427060745(heff_dup(v_args_242), v_hd_244, heff_clo_n(g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_lam2, 1, 5, (V[]){v_i_240, v_h_241, v_args_242, v_x_246, v_k_245})));
}
V g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_args_242 = heff_env(self)[1];
  V v_i_240 = heff_env(self)[2];
  V v_h_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eappChk_24s1721438207x567707123_lam1, 1, 5, (V[]){v_args_242, v_hd_244, v_i_240, v_h_241, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_str0, 50, "can only use abandon when checking at a small type");
HEFF_LIT(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_str1, 50, "can only use abandon when checking at a small type");
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31, 2, 0};
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam32(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam33(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam35(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam34(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_241 = heff_dup(heff_field(v_n_240, 0));
    switch (heff_tag_of(v_n1_241)) {
    case TAG_CInf: {
      heff_take_n(v_n1_241, 0ULL, 1);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_240);
    }
    case TAG_CType: {
      heff_take_n(v_n1_241, 0ULL, 1);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_240);
    }
    case TAG_CLam: {
      V v_x_245 = heff_field(v_n1_241, 0);
      V v_body_247 = heff_field(v_n1_241, 2);
      heff_take_n(v_n1_241, 5ULL, 3);
      V v_m_248 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_247));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0, 2, 3, (V[]){v_m_248, v_n_240, v_x_245});
    }
    case TAG_CImplicitLam: {
      V v_x_2417 = heff_field(v_n1_241, 0);
      V v_body_2419 = heff_field(v_n1_241, 2);
      heff_take_n(v_n1_241, 5ULL, 3);
      V v_m_2420 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_2419));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2, 2, 3, (V[]){v_m_2420, v_n_240, v_x_2417});
    }
    case TAG_CAnnLam: {
      V v_x_2429 = heff_field(v_n1_241, 0);
      V v_tyN_2431 = heff_field(v_n1_241, 2);
      V v_body_2432 = heff_field(v_n1_241, 3);
      heff_take_n(v_n1_241, 13ULL, 4);
      V v_c_2433 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_tyN_2431));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4, 2, 4, (V[]){v_c_2433, v_body_2432, v_n_240, v_x_2429});
    }
    case TAG_CTag: {
      V v_x_2443 = heff_field(v_n1_241, 0);
      V v_tsp_2444 = heff_field(v_n1_241, 1);
      V v_args_2445 = heff_field(v_n1_241, 2);
      heff_take_n(v_n1_241, 7ULL, 3);
      V v_c_2446 = (g_prelude_2etraverse_24s87601361x1873011385(v_args_2445));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7, 2, 4, (V[]){v_c_2446, v_n_240, v_tsp_2444, v_x_2443});
    }
    case TAG_CStruct: {
      V v_fields_2454 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_n2_2456 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        V v_c_2457 = (g_prelude_2etraverse_24s1797919465x75214466(v_fields_2454));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9, 2, 2, (V[]){v_c_2457, v_n2_2456});
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    case TAG_CMatch: {
      V v_scrutN_2462 = heff_field(v_n1_241, 0);
      V v_casesN_2463 = heff_field(v_n1_241, 1);
      heff_take_n(v_n1_241, 3ULL, 2);
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_n2_2465 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        V v_x1_2466 = (g_heff_2eelab_2etoplevel_2eallL_24s163978761x1516408934(v_casesN_2463));
        if (!(heff_dup(v_x1_2466) == NTAG(TAG_True))) {
          heff_drop(v_x1_2466);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11, 2, 3, (V[]){v_casesN_2463, v_scrutN_2462, v_n2_2465});
        } else {
          heff_drop(v_x1_2466);
          return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_2465, NTAG(TAG_Nothing), v_scrutN_2462, v_casesN_2463));
        }
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    case TAG_CLetIn: {
      V v_rhsN_2489 = heff_field(v_n1_241, 0);
      V v_alt0_2490 = heff_field(v_n1_241, 1);
      heff_take_n(v_n1_241, 3ULL, 2);
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_n2_2492 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        switch (heff_tag_of(v_alt0_2490)) {
        case TAG_At: {
          V v_it1_2493 = heff_dup(heff_field(v_alt0_2490, 0));
          switch (heff_tag_of(v_it1_2493)) {
          case TAG_MkAlt: {
            V v_it11_2495 = heff_field(v_it1_2493, 0);
            V v_bodyN_2496 = heff_field(v_it1_2493, 1);
            heff_take_n(v_it1_2493, 3ULL, 2);
            switch (heff_tag_of(v_it11_2495)) {
            case TAG_At: {
              V v_it111_2497 = heff_dup(heff_field(v_it11_2495, 0));
              switch (heff_tag_of(v_it111_2497)) {
              case TAG_PatVar: {
                V v_x_2499 = heff_field(v_it111_2497, 0);
                heff_take_n(v_it111_2497, 1ULL, 1);
                heff_drop_tag(v_alt0_2490, 2);
                heff_drop(v_n2_2492);
                switch (heff_tag_of(v_it11_2495)) {
                case TAG_At: {
                  heff_take_n(v_it11_2495, 0ULL, 2);
                  V v_c_24102 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_rhsN_2489));
                  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19, 2, 3, (V[]){v_c_24102, v_bodyN_2496, v_x_2499});
                }
                default: return heff_nomatch(v_it11_2495);
                }
              }
              default: {
                heff_drop(v_bodyN_2496);
                heff_drop(v_it111_2497);
                V v_t_24114;
                switch (heff_tag_of(v_alt0_2490)) {
                case TAG_At: {
                  V v_x11_24110 = heff_dup(heff_field(v_alt0_2490, 0));
                  switch (heff_tag_of(v_x11_24110)) {
                  case TAG_MkAlt: {
                    V v_p_24112 = heff_field(v_x11_24110, 0);
                    heff_take_n(v_x11_24110, 1ULL, 2);
                    v_t_24114 = ({ V a_0 = v_p_24112; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24112); r_; });
                    break;
                  }
                  default: heff_nomatch(v_x11_24110);
                  }
                  break;
                }
                default: heff_nomatch(v_alt0_2490);
                }
                if ((heff_dup(v_t_24114) == NTAG(TAG_True))) {
                  heff_drop_tag(v_it11_2495, 2);
                  heff_drop(v_t_24114);
                  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492});
                } else {
                  heff_drop(v_t_24114);
                  V v_t_24136 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2495}));
                  return (g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600(v_alt0_2490, v_n2_2492, heff_tag_n(TAG_Just, 1, (V[]){v_t_24136}), v_rhsN_2489));
                }
              }
              }
            }
            default: return heff_nomatch(v_it11_2495);
            }
          }
          default: return heff_nomatch(v_it1_2493);
          }
        }
        default: return heff_nomatch(v_alt0_2490);
        }
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    case TAG_CLocal: {
      V v_bodyN_24137 = heff_field(v_n1_241, 0);
      V v_defs_24138 = heff_field(v_n1_241, 1);
      heff_take_n(v_n1_241, 3ULL, 2);
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        heff_take_n(v_n_240, 0ULL, 2);
        return ({ V a_0 = v_defs_24138; V a_1 = v_bodyN_24137; V r_ = (g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(a_0, a_1)); heff_drop(v_defs_24138); r_; });
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    case TAG_CAbandon: {
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_n2_24142 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29, 2, 1, (V[]){v_n2_24142});
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    case TAG_CNominal: {
      V v_c_24167 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        heff_take_n(v_n_240, 0ULL, 2);
        V v_c_24170 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_c_24167));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam34, 2, 1, (V[]){v_c_24170});
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    default: return heff_nomatch(v_n1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(a[0]);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  V v_t_2415;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2414 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2415 = v_s_2414;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2416 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_t_2415; V a_2 = v_x_245; V a_3 = v_x_2412; V r_ = (g_heff_2eelab_2erules_2elambdaChk(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_x_2412); r_; });
  V f_ = v_k_2410;
  args[0] = v_x_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_m_248 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_m_248}));
  return (g_co_2ebind_24s196996678x1811735276(v_t_2411, v_hd_249, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1, 1, 3, (V[]){v_n_240, v_x_245, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_k_2422 = heff_env(self)[2];
  V v_t_2427;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2426 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2427 = v_s_2426;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_t_2428 = ({ V a_0 = v_t_2427; V a_1 = v_x_2417; V a_2 = v_x_2424; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_x_2424); r_; });
  V f_ = v_k_2422;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_m_2420 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_m_2420}));
  return (g_co_2ebind_24s196996678x1811735276(v_t_2423, v_hd_2421, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3, 1, 3, (V[]){v_n_240, v_x_2417, v_k_2422})));
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_x_2436 = heff_env(self)[2];
  V v_k_2435 = heff_env(self)[3];
  V v_t_2441;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2440 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2441 = v_s_2440;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2442 = ({ V a_0 = v_t_2441; V a_1 = v_x_2429; V a_2 = v_x_2436; V a_3 = v_x_2438; V r_ = (g_heff_2eelab_2erules_2efunctionIntroAnn(a_0, a_1, a_2, a_3)); heff_drop(v_x_2436); heff_drop(v_x_2438); r_; });
  V f_ = v_k_2435;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_body_2432 = heff_env(self)[0];
  V v_hd_2434 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  V v_k_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2437 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_2432));
  V f_ = v_t_2437;
  heff_room[0] = v_hd_2434;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6, 1, 4, (V[]){v_n_240, v_x_2429, v_x_2436, v_k_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_body_2432 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2433;
  args[0] = heff_dup(v_hd_2434);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5, 1, 5, (V[]){v_body_2432, v_hd_2434, v_n_240, v_x_2429, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_tsp_2444 = heff_env(self)[1];
  V v_x_2443 = heff_env(self)[2];
  V v_k_2448 = heff_env(self)[3];
  V v_t_2452;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2451 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2452 = v_s_2451;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2453 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_t_2452; V a_2 = v_tsp_2444; V a_3 = v_x_2443; V a_4 = v_x_2449; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V f_ = v_k_2448;
  args[0] = v_x_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_tsp_2444 = heff_env(self)[2];
  V v_x_2443 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2446;
  args[0] = v_hd_2447;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8, 1, 4, (V[]){v_n_240, v_tsp_2444, v_x_2443, v_k_2448});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10(V self, V *args) {
  V v_x_2460 = args[0];
  V v_n2_2456 = heff_env(self)[0];
  V v_k_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2461 = (g_heff_2eelab_2erules_2erecordIntro(v_n2_2456, v_x_2460));
  V f_ = v_k_2459;
  args[0] = v_t_2461;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_c_2457 = heff_env(self)[0];
  V v_n2_2456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2457;
  args[0] = v_hd_2458;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10, 1, 2, (V[]){v_n2_2456, v_k_2459});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15(V self, V *args) {
  V v_x_2479 = args[0];
  V v_body_2475 = heff_env(self)[0];
  V v_sp_2473 = heff_env(self)[1];
  V v_k_2478 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2480 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_2479, v_body_2475}), v_sp_2473});
  V f_ = v_k_2478;
  args[0] = v_t_2480;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14(V self, V *args) {
  V v_hd_2477 = args[0];
  V v_k_2478 = args[1];
  V v_c_2476 = heff_env(self)[0];
  V v_body_2475 = heff_env(self)[1];
  V v_sp_2473 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2476;
  args[0] = v_hd_2477;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15, 1, 3, (V[]){v_body_2475, v_sp_2473, v_k_2478});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13(V self, V *args) {
  V v_m_2471 = args[0];
  V v_e_2469 = heff_env(self)[0];
  switch (heff_tag_of(v_m_2471)) {
  case TAG_At: {
    V v_x21_2472 = heff_field(v_m_2471, 0);
    V v_sp_2473 = heff_field(v_m_2471, 1);
    heff_take_n(v_m_2471, 3ULL, 2);
    switch (heff_tag_of(v_x21_2472)) {
    case TAG_MkAlt: {
      V v_p_2474 = heff_field(v_x21_2472, 0);
      V v_body_2475 = heff_field(v_x21_2472, 1);
      heff_take_n(v_x21_2472, 3ULL, 2);
      heff_clo_take(self, 1);
      V v_c_2476 = (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_2469, 1, 8), v_p_2474));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14, 2, 3, (V[]){v_c_2476, v_body_2475, v_sp_2473});
    }
    default: return heff_nomatch(v_x21_2472);
    }
  }
  default: return heff_nomatch(v_m_2471);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18(V self, V *args) {
  V v_x_2487 = args[0];
  V v_e_2469 = heff_env(self)[0];
  V v_a_2470 = heff_env(self)[1];
  V v_hd_2482 = heff_env(self)[2];
  V v_k_2483 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2487)) {
  case TAG_MkChk: {
    V v_f_2488 = heff_field(v_x_2487, 0);
    heff_take_n(v_x_2487, 1ULL, 1);
    heff_clo_take(self, 4);
    V f_ = v_f_2488;
    heff_room[0] = v_e_2469;
    heff_room[1] = v_a_2470;
    heff_room[2] = v_hd_2482;
    heff_room[3] = v_k_2483;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_2487);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17(V self, V *args) {
  V v_x_2484 = args[0];
  V v_scrutN_2462 = heff_env(self)[0];
  V v_n2_2465 = heff_env(self)[1];
  V v_hd_2482 = heff_env(self)[2];
  V v_e_2469 = heff_env(self)[3];
  V v_a_2470 = heff_env(self)[4];
  V v_k_2483 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2485 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_scrutN_2462, v_x_2484}), v_n2_2465});
  V v_t_2486 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_2485));
  V f_ = v_t_2486;
  heff_room[0] = heff_dup(v_hd_2482);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18, 1, 4, (V[]){v_e_2469, v_a_2470, v_hd_2482, v_k_2483});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16(V self, V *args) {
  V v_hd_2482 = args[0];
  V v_k_2483 = args[1];
  V v_c_2481 = heff_env(self)[0];
  V v_scrutN_2462 = heff_env(self)[1];
  V v_n2_2465 = heff_env(self)[2];
  V v_e_2469 = heff_env(self)[3];
  V v_a_2470 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2481;
  args[0] = heff_dup(v_hd_2482);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17, 1, 6, (V[]){v_scrutN_2462, v_n2_2465, v_hd_2482, v_e_2469, v_a_2470, v_k_2483});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12(V self, V *args) {
  V v_e_2469 = args[0];
  V v_a_2470 = args[1];
  V v_casesN_2463 = heff_env(self)[0];
  V v_scrutN_2462 = heff_env(self)[1];
  V v_n2_2465 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2481 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13, 1, 1, (V[]){heff_dup(v_e_2469)}), v_casesN_2463));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16, 2, 5, (V[]){v_c_2481, v_scrutN_2462, v_n2_2465, v_e_2469, v_a_2470});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k_2468 = args[1];
  V v_casesN_2463 = heff_env(self)[0];
  V v_scrutN_2462 = heff_env(self)[1];
  V v_n2_2465 = heff_env(self)[2];
  heff_drop(v_hd_2467);
  heff_clo_take(self, 3);
  V f_ = v_k_2468;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12, 2, 3, (V[]){v_casesN_2463, v_scrutN_2462, v_n2_2465})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21(V self, V *args) {
  V v_x_24108 = args[0];
  V v_x_2499 = heff_env(self)[0];
  V v_x_24105 = heff_env(self)[1];
  V v_k_24104 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24109 = ({ V a_0 = v_x_2499; V a_1 = v_x_24105; V a_2 = v_x_24108; V r_ = (g_heff_2eelab_2erules_2ecaseLet(a_0, a_1, a_2)); heff_drop(v_x_24105); heff_drop(v_x_24108); r_; });
  V f_ = v_k_24104;
  args[0] = v_t_24109;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20(V self, V *args) {
  V v_x_24105 = args[0];
  V v_bodyN_2496 = heff_env(self)[0];
  V v_hd_24103 = heff_env(self)[1];
  V v_x_2499 = heff_env(self)[2];
  V v_k_24104 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_m_24106 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_bodyN_2496));
  V v_t_24107 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_m_24106}));
  return (g_co_2ebind_24s196996678x1811735276(v_t_24107, v_hd_24103, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21, 1, 3, (V[]){v_x_2499, v_x_24105, v_k_24104})));
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19(V self, V *args) {
  V v_hd_24103 = args[0];
  V v_k_24104 = args[1];
  V v_c_24102 = heff_env(self)[0];
  V v_bodyN_2496 = heff_env(self)[1];
  V v_x_2499 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24102;
  args[0] = heff_dup(v_hd_24103);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20, 1, 4, (V[]){v_bodyN_2496, v_hd_24103, v_x_2499, v_k_24104});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25(V self, V *args) {
  V v_x_24126 = args[0];
  V v_body_24122 = heff_env(self)[0];
  V v_sp_24120 = heff_env(self)[1];
  V v_k_24125 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24127 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24126, v_body_24122}), v_sp_24120});
  V f_ = v_k_24125;
  args[0] = v_t_24127;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24(V self, V *args) {
  V v_hd_24124 = args[0];
  V v_k_24125 = args[1];
  V v_c_24123 = heff_env(self)[0];
  V v_body_24122 = heff_env(self)[1];
  V v_sp_24120 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24123;
  args[0] = v_hd_24124;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25, 1, 3, (V[]){v_body_24122, v_sp_24120, v_k_24125});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28(V self, V *args) {
  V v_x_24134 = args[0];
  V v_e_24117 = heff_env(self)[0];
  V v_a_24118 = heff_env(self)[1];
  V v_hd_24129 = heff_env(self)[2];
  V v_k_24130 = heff_env(self)[3];
  switch (heff_tag_of(v_x_24134)) {
  case TAG_MkChk: {
    V v_f_24135 = heff_field(v_x_24134, 0);
    heff_take_n(v_x_24134, 1ULL, 1);
    heff_clo_take(self, 4);
    V f_ = v_f_24135;
    heff_room[0] = v_e_24117;
    heff_room[1] = v_a_24118;
    heff_room[2] = v_hd_24129;
    heff_room[3] = v_k_24130;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_24134);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27(V self, V *args) {
  V v_x_24131 = args[0];
  V v_rhsN_2489 = heff_env(self)[0];
  V v_n2_2492 = heff_env(self)[1];
  V v_hd_24129 = heff_env(self)[2];
  V v_e_24117 = heff_env(self)[3];
  V v_a_24118 = heff_env(self)[4];
  V v_k_24130 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2489, v_x_24131}), v_n2_2492});
  V v_t_24133 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_24132));
  V f_ = v_t_24133;
  heff_room[0] = heff_dup(v_hd_24129);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28, 1, 4, (V[]){v_e_24117, v_a_24118, v_hd_24129, v_k_24130});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26(V self, V *args) {
  V v_hd_24129 = args[0];
  V v_k_24130 = args[1];
  V v_c_24128 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  V v_e_24117 = heff_env(self)[3];
  V v_a_24118 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24128;
  args[0] = heff_dup(v_hd_24129);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27, 1, 6, (V[]){v_rhsN_2489, v_n2_2492, v_hd_24129, v_e_24117, v_a_24118, v_k_24130});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23(V self, V *args) {
  V v_e_24117 = args[0];
  V v_a_24118 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  V v_c_24128;
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_alt0_2490)) {
  case TAG_At: {
    V v_x21_24119 = heff_field(v_alt0_2490, 0);
    V v_sp_24120 = heff_field(v_alt0_2490, 1);
    heff_take_n(v_alt0_2490, 3ULL, 2);
    switch (heff_tag_of(v_x21_24119)) {
    case TAG_MkAlt: {
      V v_p_24121 = heff_field(v_x21_24119, 0);
      V v_body_24122 = heff_field(v_x21_24119, 1);
      heff_take_n(v_x21_24119, 3ULL, 2);
      V v_c_24123 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24117, 1)), v_p_24121));
      v_c_24128 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24, 2, 3, (V[]){v_c_24123, v_body_24122, v_sp_24120});
      break;
    }
    default: heff_nomatch(v_x21_24119);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2490);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26, 2, 5, (V[]){v_c_24128, v_rhsN_2489, v_n2_2492, v_e_24117, v_a_24118});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22(V self, V *args) {
  V v_hd_24115 = args[0];
  V v_k_24116 = args[1];
  V v_alt0_2490 = heff_env(self)[0];
  V v_rhsN_2489 = heff_env(self)[1];
  V v_n2_2492 = heff_env(self)[2];
  heff_drop(v_hd_24115);
  heff_clo_take(self, 3);
  V f_ = v_k_24116;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23, 2, 3, (V[]){v_alt0_2490, v_rhsN_2489, v_n2_2492})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31(V self, V *args) {
  V v_hd_24149 = args[0];
  V v_k_24150 = args[1];
  heff_drop(v_hd_24149);
  V f_ = v_k_24150;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eabandonM_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam32(V self, V *args) {
  V v_hd_24151 = args[0];
  V v_k2_24152 = args[1];
  V v_sp_24145 = heff_env(self)[0];
  V v_malg_24153 = heff_take_field(v_hd_24151, 2);
  V v_bind_24154 = heff_get_n(v_hd_24151, 1, 3);
  heff_clo_take(self, 1);
  V v_t_24155 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(321LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_str0), v_sp_24145, NTAG(TAG_Nothing)});
  V v_t_24156 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24155})});
  V v_t_24157 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24156})});
  V v_t_24158 = heff_tr(heff_call(v_malg_24153, 1, (V[]){v_t_24157}));
  V f_ = v_bind_24154;
  args[0] = v_t_24158;
  args[1] = v_k2_24152;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam33(V self, V *args) {
  V v_hd_24159 = args[0];
  V v_k2_24160 = args[1];
  V v_sp_24145 = heff_env(self)[0];
  V v_malg_24161 = heff_take_field(v_hd_24159, 2);
  V v_bind_24162 = heff_get_n(v_hd_24159, 1, 3);
  heff_clo_take(self, 1);
  V v_t_24163 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(321LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_str1), v_sp_24145, NTAG(TAG_Nothing)});
  V v_t_24164 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24163})});
  V v_t_24165 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24164})});
  V v_t_24166 = heff_tr(heff_call(v_malg_24161, 1, (V[]){v_t_24165}));
  V f_ = v_bind_24162;
  args[0] = v_t_24166;
  args[1] = v_k2_24160;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30(V self, V *args) {
  V v_e_24146 = args[0];
  V v_a_24147 = args[1];
  V v_sp_24145 = heff_env(self)[0];
  heff_drop(v_e_24146);
  V v_x1_24148 = ({ V a_0 = v_a_24147; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_a_24147); r_; });
  switch (heff_tag_of(v_x1_24148)) {
  case TAG_Small: {
    heff_drop(self);
    return ((V)&g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31_clo);
  }
  case TAG_Large: {
    heff_clo_take(self, 1);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam32, 2, 1, (V[]){v_sp_24145});
  }
  case TAG_TopL: {
    heff_clo_take(self, 1);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam33, 2, 1, (V[]){v_sp_24145});
  }
  default: return heff_nomatch(v_x1_24148);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29(V self, V *args) {
  V v_hd_24143 = args[0];
  V v_k_24144 = args[1];
  V v_n2_24142 = heff_env(self)[0];
  heff_drop(v_hd_24143);
  heff_clo_take(self, 1);
  V v_sp_24145 = v_n2_24142;
  V f_ = v_k_24144;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30, 2, 1, (V[]){v_sp_24145})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam35(V self, V *args) {
  V v_x_24173 = args[0];
  V v_k_24172 = heff_env(self)[0];
  V v_t_24174 = ({ V a_0 = v_x_24173; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop(v_x_24173); r_; });
  heff_clo_take(self, 1);
  V f_ = v_k_24172;
  args[0] = v_t_24174;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam34(V self, V *args) {
  V v_hd_24171 = args[0];
  V v_k_24172 = args[1];
  V v_c_24170 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24170;
  args[0] = v_hd_24171;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam35, 1, 1, (V[]){v_k_24172});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_ab_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_implicit_244 = heff_take_field(v_ab_242, 3);
    V v_name_245 = heff_get_n(v_ab_242, 1, 4);
    V v_t_246 = v_implicit_244;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Expl: {
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_name_245, heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_247);
      V t_0 = v_rest_243;
      V t_1 = v_u_248;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Impl: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_name_245);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Inst: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_name_245);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2etoplevel_2enubInt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enubInt_24dps_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2enubInt_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s512765522x2052101617(heff_dup(v_x_242), v_xs_243));
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_t_244;
    V t_1 = v_u_246;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2enubInt_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2enubInt_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str1, 2, ", ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str2, 30, "there is no primitive called `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str3, 20, "` (the runtime has: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str4, 55, ", and each fixed-width type's, `int32Add` and the like)");
Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eprimKnown_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eprimKnown(V v_sp_240, V v_d_241, V v_z_242, V v_z_243) {
top: ;
  V v_malg_244 = heff_take_field(v_z_242, 2);
  V v_bind_245 = heff_get_n(v_z_242, 1, 3);
  V v_prim_246 = heff_take_field(v_d_241, 3);
  V v_name_247 = heff_get_n(v_d_241, 0, 4);
  V v_t_248 = v_prim_246;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    HeffT2 v_t_249 = ({ V b_0 = heff_dup(g_heff_2eelab_2eprimitive_2elibraryTable_get()); V a_1 = v_name_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        heff_drop(v_sp_240);
        heff_drop(v_malg_244);
        heff_drop(v_bind_245);
        heff_drop(v_name_247);
        V v_x_2412 = v_field_2411;
        heff_drop(v_x_2412);
        return heff_tail(v_z_243, 1, (V[]){NTAG(TAG_MkUnit)});
      } else {
        heff_drop(v_field_2411);
        V v_x2_2413 = heff_dup(g_heff_2eelab_2etoplevel_2ebasicPrimNames_get());
        V v_t_2416;
        switch (heff_tag_of(v_x2_2413)) {
        case TAG_Nil: {
          v_t_2416 = ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str0);
          break;
        }
        case TAG_Cons: {
          V v_x_2414 = heff_field(v_x2_2413, 0);
          V v_xs_2415 = heff_field(v_x2_2413, 1);
          heff_take_n(v_x2_2413, 3ULL, 2);
          v_t_2416 = ({ V a_0 = ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str1); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2413);
        }
        V v_t_2417 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str2), v_name_247), ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str3));
        V v_msg_2418 = heff_strAppend(heff_strAppend(v_t_2417, v_t_2416), ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str4));
        V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(329LL), NTAG(TAG_SError), v_msg_2418, v_sp_240, NTAG(TAG_Nothing)});
        V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2419})});
        V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
        V v_t_2422 = heff_tr(heff_call(v_malg_244, 1, (V[]){v_t_2421}));
        return heff_tail(v_bind_245, 2, (V[]){v_t_2422, v_z_243});
      }
    }
  } else {
    heff_drop(v_sp_240);
    heff_drop(v_malg_244);
    heff_drop(v_bind_245);
    heff_drop(v_name_247);
    heff_drop(v_t_248);
    return heff_tail(v_z_243, 1, (V[]){NTAG(TAG_MkUnit)});
  }
}
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eprimKnown(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewithInstance_str0, 0, "");
Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithInstance_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ewithInstance(V v_isInstance_240, V v_key_241, V v_name_242, V v_g_243) {
top: ;
  if ((heff_dup(v_isInstance_240) == NTAG(TAG_True))) {
    V v_t_245;
    if (heff_strEq_c_lent(v_key_241, v_name_242, 0)) {
      v_t_245 = ((V)&g_heff_2eelab_2etoplevel_2ewithInstance_str0);
    } else {
      int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_key_241, 0)) - heff_unbox_word(heff_strLength_lent(v_name_242, 0)));
      v_t_245 = heff_strSlice_lent(v_key_241, MK_INT(0LL), heff_box_word((v_t_244 - ((int64_t)1ULL))), 6);
    }
    V v_t_246 = (g_list_2ekeepIf_24s2115931744x466898799(v_key_241, heff_take_field(v_g_243, 7)));
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_key__module, (V[]){v_key_241, v_t_245}), v_t_246});
    return ({ V rv_7 = v_t_247; V rr_ = heff_rec_reuse_nf(v_g_243, 127ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  } else {
    V v_t_248 = (g_list_2eany_24s1547578820x1498276962(v_key_241, heff_rfield(v_g_243, 7)));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = ({ V a_0 = v_key_241; V a_1 = heff_take_field(v_g_243, 7); V r_ = (g_list_2ekeepIf_24s2115931744x466898799(a_0, a_1)); heff_drop(v_key_241); r_; });
      return ({ V rv_7 = v_t_249; V rr_ = heff_rec_reuse_nf(v_g_243, 127ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
    } else {
      heff_drop(v_key_241);
      heff_drop(v_t_248);
      return v_g_243;
    }
  }
}
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2ewithInstance(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2etoplevel_2eonceEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eonceEach_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eonceEach(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seen_240);
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_list_2eany_24s752896332x1549544792(heff_dup(v_d_242), v_seen_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_d_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_seen_240;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V t_0 = heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_d_242, v_seen_240});
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2eonceEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eonceEach(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_str0, 0, "");
Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V v_acc_240, V v_n_241, V v_diags_242) {
top: ;
  V v_t_2425;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_243 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_x11_243)) {
    case TAG_DeclEquations: {
      V v_f_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 5);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_f_245});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2410 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 5);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2410});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2415 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 4);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2415});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2419 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 3);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2419});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2422 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 2);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2422});
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_243, 0ULL, 1);
      v_t_2425 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_243);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_t_2425)) {
  case TAG_Nothing: {
    heff_drop(v_n_241);
    V v_keys_2426 = heff_take_field(v_acc_240, 2);
    V v_broken_2427 = heff_take_field(v_acc_240, 3);
    V v_watches_2428 = heff_take_field(v_acc_240, 4);
    V v_tests_2429 = heff_take_field(v_acc_240, 5);
    V v_spans_2430 = heff_take_field(v_acc_240, 6);
    V v_infos_2431 = heff_take_field(v_acc_240, 7);
    V v_trace_2432 = heff_take_field(v_acc_240, 8);
    V v_unreached_2433 = heff_take_field(v_acc_240, 9);
    return ({ V rv_1 = v_diags_242; V rv_2 = v_keys_2426; V rv_3 = v_broken_2427; V rv_4 = v_watches_2428; V rv_5 = v_tests_2429; V rv_6 = v_spans_2430; V rv_7 = v_infos_2431; V rv_8 = v_trace_2432; V rv_9 = v_unreached_2433; V rr_ = heff_rec_reuse_nf(v_acc_240, 1ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
  }
  case TAG_Just: {
    V v_x_2434 = heff_field(v_t_2425, 0);
    V v_ru_24t_2425_24Just = heff_take_reuse_n(v_t_2425, 1ULL, 1);
    V v_n_2435 = heff_dup(v_n_241);
    V v_g_2439;
    if (heff_strEq_c_lent(v_x_2434, v_x_2434, 0)) {
      v_g_2439 = heff_dup(heff_rfield(v_acc_240, 0));
    } else {
      V v_g_2436 = heff_dup(heff_rfield(v_acc_240, 0));
      V v_t_2437 = (g_std_2eordmap_2edelete_24s2135745297x1725920174(heff_take_field(v_g_2436, 4), v_x_2434));
      V v_t_2438 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_g_2436, 2), heff_dup(v_x_2434), heff_dup(v_x_2434)));
      v_g_2439 = ({ V rv_2 = v_t_2438; V rv_4 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_g_2436, 235ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 64719u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 4) = rv_4; rr_; });
    }
    V v_t_2440 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_g_2439, 3), heff_dup(v_x_2434), NTAG(TAG_MkUnit)));
    V v_g_2441 = ({ V rv_3 = v_t_2440; V rr_ = heff_rec_reuse_nf(v_g_2439, 247ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 65343u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_t_2464;
    switch (heff_tag_of(v_n_2435)) {
    case TAG_At: {
      V v_x11_2442 = heff_dup(heff_field(v_n_2435, 0));
      switch (heff_tag_of(v_x11_2442)) {
      case TAG_DeclEquations: {
        V v_f_2444 = heff_field(v_x11_2442, 0);
        heff_take_n(v_x11_2442, 1ULL, 5);
        v_t_2464 = heff_tag_at_n(v_ru_24t_2425_24Just, TAG_Just, 1, (V[]){v_f_2444});
        break;
      }
      case TAG_DeclDefine: {
        V v_x_2449 = heff_field(v_x11_2442, 0);
        heff_take_n(v_x11_2442, 1ULL, 5);
        v_t_2464 = heff_tag_at_n(v_ru_24t_2425_24Just, TAG_Just, 1, (V[]){v_x_2449});
        break;
      }
      case TAG_DeclTheory: {
        V v_x_2454 = heff_field(v_x11_2442, 0);
        heff_take_n(v_x11_2442, 1ULL, 4);
        v_t_2464 = heff_tag_at_n(v_ru_24t_2425_24Just, TAG_Just, 1, (V[]){v_x_2454});
        break;
      }
      case TAG_DeclPrimitive: {
        V v_x_2458 = heff_field(v_x11_2442, 0);
        heff_take_n(v_x11_2442, 1ULL, 3);
        v_t_2464 = heff_tag_at_n(v_ru_24t_2425_24Just, TAG_Just, 1, (V[]){v_x_2458});
        break;
      }
      case TAG_DeclTest: {
        V v_x_2461 = heff_field(v_x11_2442, 0);
        heff_take_n(v_x11_2442, 1ULL, 2);
        v_t_2464 = heff_tag_at_n(v_ru_24t_2425_24Just, TAG_Just, 1, (V[]){v_x_2461});
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_2442, 0ULL, 1);
        heff_drop_cell(v_ru_24t_2425_24Just, 1);
        v_t_2464 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_2442);
      }
      break;
    }
    default: heff_nomatch(v_n_2435);
    }
    V v_globals_2492;
    switch (heff_tag_of(v_t_2464)) {
    case TAG_Nothing: {
      heff_drop(v_n_2435);
      v_globals_2492 = v_g_2441;
      break;
    }
    case TAG_Just: {
      V v_x_2465 = heff_field(v_t_2464, 0);
      heff_take_n(v_t_2464, 1ULL, 1);
      switch (heff_tag_of(v_n_2435)) {
      case TAG_At: {
        V v_x11_2466 = heff_field(v_n_2435, 0);
        V v_ru_24n_2435_24At = heff_take_reuse_n(v_n_2435, 1ULL, 2);
        switch (heff_tag_of(v_x11_2466)) {
        case TAG_DeclEquations: {
          V v_x113_2470 = heff_field(v_x11_2466, 2);
          heff_take_n(v_x11_2466, 4ULL, 5);
          switch (heff_tag_of(v_x113_2470)) {
          case TAG_AsDefinition: {
            heff_drop(v_x_2465);
            heff_drop_cell(v_ru_24n_2435_24At, 2);
            v_globals_2492 = v_g_2441;
            break;
          }
          case TAG_AsInstance: {
            V v_t_2474;
            if (heff_strEq_c_lent(v_x_2465, v_x_2465, 0)) {
              v_t_2474 = ((V)&g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_str0);
            } else {
              int64_t v_t_2473 = (heff_unbox_word(heff_strLength_lent(v_x_2465, 0)) - heff_unbox_word(heff_strLength_lent(v_x_2465, 0)));
              v_t_2474 = heff_strSlice_lent(v_x_2465, MK_INT(0LL), heff_box_word((v_t_2473 - ((int64_t)1ULL))), 6);
            }
            V v_t_2475 = (g_list_2ekeepIf_24s2115931744x466898799(v_x_2465, heff_take_field(v_g_2441, 7)));
            V v_t_2476 = heff_tag_at_n(v_ru_24n_2435_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_key__module, (V[]){v_x_2465, v_t_2474}), v_t_2475});
            v_globals_2492 = ({ V rv_7 = v_t_2476; V rr_ = heff_rec_reuse_nf(v_g_2441, 127ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
            break;
          }
          default: heff_nomatch(v_x113_2470);
          }
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_x11_2466, 0ULL, 5);
          heff_drop(v_x_2465);
          heff_drop_cell(v_ru_24n_2435_24At, 2);
          v_globals_2492 = v_g_2441;
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_x11_2466, 0ULL, 4);
          heff_drop(v_x_2465);
          heff_drop_cell(v_ru_24n_2435_24At, 2);
          v_globals_2492 = v_g_2441;
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_x11_2466, 0ULL, 3);
          heff_drop(v_x_2465);
          heff_drop_cell(v_ru_24n_2435_24At, 2);
          v_globals_2492 = v_g_2441;
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_x11_2466, 0ULL, 2);
          heff_drop(v_x_2465);
          heff_drop_cell(v_ru_24n_2435_24At, 2);
          v_globals_2492 = v_g_2441;
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_x11_2466, 0ULL, 1);
          heff_drop(v_x_2465);
          heff_drop_cell(v_ru_24n_2435_24At, 2);
          v_globals_2492 = v_g_2441;
          break;
        }
        default: heff_nomatch(v_x11_2466);
        }
        break;
      }
      default: heff_nomatch(v_n_2435);
      }
      break;
    }
    default: heff_nomatch(v_t_2464);
    }
    V v_t_2493 = heff_take_field(v_acc_240, 3);
    V v_watches_2494 = heff_take_field(v_acc_240, 4);
    V v_tests_2495 = heff_take_field(v_acc_240, 5);
    V v_spans_2496 = heff_take_field(v_acc_240, 6);
    V v_infos_2497 = heff_take_field(v_acc_240, 7);
    V v_trace_2498 = heff_take_field(v_acc_240, 8);
    V v_unreached_2499 = heff_take_field(v_acc_240, 9);
    V v_t_24102;
    switch (heff_tag_of(v_n_241)) {
    case TAG_At: {
      V v_s_24101 = heff_field(v_n_241, 1);
      heff_take_n(v_n_241, 2ULL, 2);
      v_t_24102 = v_s_24101;
      break;
    }
    default: heff_nomatch(v_n_241);
    }
    V v_t_24103 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2434, v_t_24102}), v_t_2493});
    return ({ V rv_0 = v_globals_2492; V rv_1 = v_diags_242; V rv_3 = v_t_24103; V rv_4 = v_watches_2494; V rv_5 = v_tests_2495; V rv_6 = v_spans_2496; V rv_7 = v_infos_2497; V rv_8 = v_trace_2498; V rv_9 = v_unreached_2499; V rr_ = heff_rec_reuse_nf(v_acc_240, 4ULL, 10, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace__unreached, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
  }
  default: return heff_nomatch(v_t_2425);
  }
}
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(V v_g_240, V v_n_241, V v_st_242) {
top: ;
  V v_c_246;
  switch (heff_tag_of(v_st_242)) {
  case TAG_MkSt: {
    V v_c_243 = heff_dup(heff_field(v_st_242, 0));
    v_c_246 = v_c_243;
    break;
  }
  default: heff_nomatch(v_st_242);
  }
  V v_t_2411;
  switch (heff_tag_of(v_st_242)) {
  case TAG_MkSt: {
    V v_d_248 = heff_field(v_st_242, 1);
    V v_w_249 = heff_field(v_st_242, 2);
    V v_ru_24st_242_24MkSt = heff_take_reuse_n(v_st_242, 6ULL, 3);
    V v_t_2410 = ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_c_246, 383ULL, 9, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey__arms, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
    v_t_2411 = heff_tag_re_n(v_ru_24st_242_24MkSt, TAG_MkSt, 3, 6ULL, (V[]){v_t_2410, v_d_248, v_w_249});
    break;
  }
  default: heff_nomatch(v_st_242);
  }
  HEFF_LAST return g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980(heff_dup(v_n_241), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0, 1, 2, (V[]){v_g_240, v_n_241}), v_t_2411);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_drop(v_x_2430);
  heff_clo_take(self, 4);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_clo);
  heff_room[0] = v_g_240;
  heff_room[1] = v_n_241;
  heff_room[2] = v_x_2412;
  heff_room[3] = v_x_2416;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_z_2418 = args[1];
  V v_n_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_drop(v_x_2417);
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_2419 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_x11_2419)) {
    case TAG_DeclEquations: {
      V v_x113_2423 = heff_field(v_x11_2419, 2);
      V v_tyN_2424 = heff_field(v_x11_2419, 3);
      heff_take_n(v_x11_2419, 12ULL, 5);
      switch (heff_tag_of(v_x113_2423)) {
      case TAG_AsDefinition: {
        heff_drop(v_tyN_2424);
        return ({ V a_0 = v_g_240; V a_1 = v_n_241; V a_2 = v_x_2412; V a_3 = v_x_2416; V a_4 = v_z_2418; V r_ = (g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_n_241, 2); r_; });
      }
      case TAG_AsInstance: {
        V v_t_2428;
        switch (heff_tag_of(v_tyN_2424)) {
        case TAG_At: {
          V v_s_2427 = heff_field(v_tyN_2424, 1);
          heff_take_n(v_tyN_2424, 2ULL, 2);
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_tyN_2424);
        }
        V v_t_2429 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(heff_dup(heff_rfield(v_x_2416, 0))));
        V v_t_2431 = heff_tr(g_heff_2eelab_2etoplevel_2esearchedInstance_24s915213290x104484076(v_t_2428, NTAG(TAG_Nil), MK_INT(0LL), v_t_2429, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3, 1, 4, (V[]){v_g_240, v_n_241, v_x_2412, v_x_2416})));
        V f_ = v_t_2431;
        args[0] = v_z_2418;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x113_2423);
      }
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2419, 0ULL, 5);
      return ({ V a_0 = v_g_240; V a_1 = v_n_241; V a_2 = v_x_2412; V a_3 = v_x_2416; V a_4 = v_z_2418; V r_ = (g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2419, 0ULL, 4);
      return ({ V a_0 = v_g_240; V a_1 = v_n_241; V a_2 = v_x_2412; V a_3 = v_x_2416; V a_4 = v_z_2418; V r_ = (g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2419, 0ULL, 3);
      return ({ V a_0 = v_g_240; V a_1 = v_n_241; V a_2 = v_x_2412; V a_3 = v_x_2416; V a_4 = v_z_2418; V r_ = (g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2419, 0ULL, 2);
      return ({ V a_0 = v_g_240; V a_1 = v_n_241; V a_2 = v_x_2412; V a_3 = v_x_2416; V a_4 = v_z_2418; V r_ = (g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_n_241, 2); r_; });
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2419, 0ULL, 1);
      return ({ V a_0 = v_g_240; V a_1 = v_n_241; V a_2 = v_x_2412; V a_3 = v_x_2416; V a_4 = v_z_2418; V r_ = (g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_n_241, 2); r_; });
    }
    default: return heff_nomatch(v_x11_2419);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo);
  args[0] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2, 2, 4, (V[]){v_n_241, v_g_240, v_x_2412, v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_t_2413 = heff_dup(heff_rfield(v_x_2412, 1));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_MkTyp: {
    V v_f_2414 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    V v_t_2415 = heff_rec_n(8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_240), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil), NTAG(TAG_False), heff_dup(g_heff_2eelab_2erules_2eevidenceSearch_get())});
    heff_clo_take(self, 2);
    V f_ = v_f_2414;
    heff_room[0] = v_t_2415;
    heff_room[1] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
    heff_room[2] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1, 1, 3, (V[]){v_n_241, v_g_240, v_x_2412});
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_t_2413);
  }
}