// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_BDelayedBy 11524
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_HGlobal 55847
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkChk 56962
#define TAG_MkSt 48854
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_Nom 25944
#define TAG_PatAs 19989
#define TAG_PatBytes 60255
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SPrim 55533
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_VOpaque 37311
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_broken 566525696
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_diags 296935042
#define LBL_elabFor 712452832
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_globals 352931696
#define LBL_head 9693863
#define LBL_implicit 319715269
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_level 304224158
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_order 307364712
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_scope 310622830
#define LBL_scrutinee 73860976
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_tests 311609915
#define LBL_tm 10464
#define LBL_trace 311979359
#define LBL_tree 10063973
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_values 1123329101
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
static uint32_t shape_name__ty__tm__prim[] = {LBL_name, LBL_ty, LBL_tm, LBL_prim};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_instances};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eclauses_2ecaseTreeOf(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecaseTreeOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecaseTreeOf_clo;
V g_heff_2eelab_2eclauses_2efresh(V, V);
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efresh_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_clo;
V g_heff_2eelab_2eclauses_2etraverseC_24s246054844x100991343(V);
V g_heff_2eelab_2eclauses_2etraverseC_24s246054844x100991343_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_24s246054844x100991343_clo;
V g_heff_2eelab_2eenvironment_2eemptyScope_get(void);
V g_heff_2eelab_2eglobals_2eaddInstance(V, V, V);
V g_heff_2eelab_2eglobals_2eaddInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddInstance_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2erules_2eabandonChk(V);
V g_heff_2eelab_2erules_2eabandonChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eabandonChk_clo;
V g_heff_2eelab_2erules_2ecaseLet(V, V, V);
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseLet_clo;
V g_heff_2eelab_2erules_2efunctionIntro(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntro_clo;
V g_heff_2eelab_2erules_2efunctionIntroAnn(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo;
V g_heff_2eelab_2erules_2efunctionIntroImplicit(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo;
V g_heff_2eelab_2erules_2ementionsLocal(V);
V g_heff_2eelab_2erules_2ementionsLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsLocal_clo;
V g_heff_2eelab_2erules_2erecordIntro(V, V);
V g_heff_2eelab_2erules_2erecordIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordIntro_clo;
V g_heff_2eelab_2erules_2esumElim(V, V, V, V);
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumElim_clo;
V g_heff_2eelab_2erules_2esumIntro(V, V, V, V);
V g_heff_2eelab_2erules_2esumIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumIntro_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744(V);
V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_clo;
V g_heff_2eelab_2etoplevel_2eannotatesData(V);
V g_heff_2eelab_2etoplevel_2eannotatesData_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eannotatesData_clo;
V g_heff_2eelab_2etoplevel_2ebasicPrimNames_get(void);
V g_heff_2eelab_2etoplevel_2ebodyEnv(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyEnv_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyEnv_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2edeclJ(V);
V g_heff_2eelab_2etoplevel_2edeclJ_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edeclJ_clo;
V g_heff_2eelab_2etoplevel_2edefineD(V, V, V, V);
V g_heff_2eelab_2etoplevel_2edefineD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edefineD_clo;
V g_heff_2eelab_2etoplevel_2edoPat(V);
V g_heff_2eelab_2etoplevel_2edoPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edoPat_clo;
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115(V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_clo;
V g_heff_2eelab_2etoplevel_2eelabWatch(V, V);
V g_heff_2eelab_2etoplevel_2eelabWatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabWatch_clo;
V g_heff_2eelab_2etoplevel_2eequationsD(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eequationsD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eequationsD_clo;
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eeveryImplicitIn_clo;
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(V, V);
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(V, V);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2enubInt_24dps(V, V);
V g_heff_2eelab_2etoplevel_2enubInt_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_24dps_clo;
V g_heff_2eelab_2etoplevel_2eopPat(V, V);
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eopPat_clo;
V g_heff_2eelab_2etoplevel_2eprimKnown(V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo;
V g_heff_2eelab_2etoplevel_2eprimNames_get(void);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2esearchedInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2esearchedInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2esearchedInstance_clo;
V g_heff_2eelab_2etoplevel_2etagSpans(V);
V g_heff_2eelab_2etoplevel_2etagSpans_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSpans_clo;
V g_heff_2eelab_2etoplevel_2etheoryD(V, V, V);
V g_heff_2eelab_2etoplevel_2etheoryD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etheoryD_clo;
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL(V, V);
V g_heff_2eelab_2etoplevel_2etraverseEL_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(V);
V g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774_clo;
V g_heff_2eelab_2etoplevel_2ewatchPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchPhase_clo;
V g_heff_2eelab_2etoplevel_2ewatchSyn(V);
V g_heff_2eelab_2etoplevel_2ewatchSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchSyn_clo;
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720(V, V);
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_clo;
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epsurface_2eunIsTy(V);
V g_heff_2esyntax_2epsurface_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eunIsTy_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str2, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str3, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str4, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str5, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str6, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str7, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str8, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str9, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str10, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str11, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
V g_heff_2eelab_2etoplevel_2edoPat_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2edoPat_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoPat_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2edoPat_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam12(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edoPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoPat_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2edoPat(V v_p_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(heff_dup(v_p_240)));
  V v_it_242 = heff_get_n(v_t_241, 0, 2);
  switch (heff_tag_of(v_it_242)) {
  case TAG_At: {
    V v_it1_243 = heff_field(v_it_242, 0);
    heff_take_n(v_it_242, 1ULL, 2);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_PatVar: {
      V v_it11_245 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 1);
      if (heff_strEq_c(v_it11_245, ((V)&g_heff_2eelab_2etoplevel_2edoPat_str0))) {
        heff_drop(v_p_240);
        return ((V)&g_heff_2eelab_2etoplevel_2edoPat_lam0_clo);
      } else {
        V v_sp_2412;
        switch (heff_tag_of(v_p_240)) {
        case TAG_At: {
          V v_s_2411 = heff_field(v_p_240, 1);
          heff_take_n(v_p_240, 2ULL, 2);
          v_sp_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_p_240);
        }
        return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam1, 2, 1, (V[]){v_sp_2412});
      }
    }
    case TAG_PatTag: {
      V v_x_2419 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 3);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(v_p_240));
      V v_c_2423 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s2025788799x417268573(heff_get_n(v_t_2422, 1, 2)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam2, 2, 2, (V[]){v_c_2423, v_x_2419});
    }
    case TAG_PatOp: {
      heff_take_n(v_it1_243, 0ULL, 3);
      V v_sp_2432;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2431 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2432 = v_s_2431;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam4, 2, 1, (V[]){v_sp_2432});
    }
    case TAG_PatInt: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2442;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2441 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2442 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam5, 2, 1, (V[]){v_sp_2442});
    }
    case TAG_PatFloat: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2452;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2451 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2452 = v_s_2451;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam6, 2, 1, (V[]){v_sp_2452});
    }
    case TAG_PatString: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2462;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2461 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2462 = v_s_2461;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam7, 2, 1, (V[]){v_sp_2462});
    }
    case TAG_PatBytes: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2472;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2471 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2472 = v_s_2471;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam8, 2, 1, (V[]){v_sp_2472});
    }
    case TAG_PatRune: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2482;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2481 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2482 = v_s_2481;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam9, 2, 1, (V[]){v_sp_2482});
    }
    case TAG_PatRecord: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_2492;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2491 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_2492 = v_s_2491;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam10, 2, 1, (V[]){v_sp_2492});
    }
    case TAG_PatWord: {
      heff_take_n(v_it1_243, 0ULL, 1);
      V v_sp_24102;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_24101 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_24102 = v_s_24101;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam11, 2, 1, (V[]){v_sp_24102});
    }
    case TAG_PatAs: {
      heff_take_n(v_it1_243, 0ULL, 3);
      V v_sp_24114;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_24113 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_sp_24114 = v_s_24113;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam12, 2, 1, (V[]){v_sp_24114});
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2eelab_2etoplevel_2edoPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2edoPat(a[0]);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  heff_drop(v_hd_247);
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2eelab_2etoplevel_2edoPat_str1), NTAG(TAG_Nil)});
  V f_ = v_k_248;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_sp_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str2), v_sp_2412, NTAG(TAG_Nothing)});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_2413, 2), 1, (V[]){v_t_2417}));
  V f_ = heff_get_n(v_hd_2413, 1, 3);
  args[0] = v_t_2418;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam3, 1, 2, (V[]){v_k_2425, v_x_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam4(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k2_2434 = args[1];
  V v_sp_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str3), v_sp_2432, NTAG(TAG_Nothing)});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_call(heff_take_field(v_hd_2433, 2), 1, (V[]){v_t_2437}));
  V f_ = heff_get_n(v_hd_2433, 1, 3);
  args[0] = v_t_2438;
  args[1] = v_k2_2434;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_sp_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str4), v_sp_2442, NTAG(TAG_Nothing)});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tr(heff_call(heff_take_field(v_hd_2443, 2), 1, (V[]){v_t_2447}));
  V f_ = heff_get_n(v_hd_2443, 1, 3);
  args[0] = v_t_2448;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam6(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k2_2454 = args[1];
  V v_sp_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2455 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str5), v_sp_2452, NTAG(TAG_Nothing)});
  V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tr(heff_call(heff_take_field(v_hd_2453, 2), 1, (V[]){v_t_2457}));
  V f_ = heff_get_n(v_hd_2453, 1, 3);
  args[0] = v_t_2458;
  args[1] = v_k2_2454;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam7(V self, V *args) {
  V v_hd_2463 = args[0];
  V v_k2_2464 = args[1];
  V v_sp_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str6), v_sp_2462, NTAG(TAG_Nothing)});
  V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tr(heff_call(heff_take_field(v_hd_2463, 2), 1, (V[]){v_t_2467}));
  V f_ = heff_get_n(v_hd_2463, 1, 3);
  args[0] = v_t_2468;
  args[1] = v_k2_2464;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam8(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k2_2474 = args[1];
  V v_sp_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2475 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str7), v_sp_2472, NTAG(TAG_Nothing)});
  V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tr(heff_call(heff_take_field(v_hd_2473, 2), 1, (V[]){v_t_2477}));
  V f_ = heff_get_n(v_hd_2473, 1, 3);
  args[0] = v_t_2478;
  args[1] = v_k2_2474;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam9(V self, V *args) {
  V v_hd_2483 = args[0];
  V v_k2_2484 = args[1];
  V v_sp_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2485 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str8), v_sp_2482, NTAG(TAG_Nothing)});
  V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tr(heff_call(heff_take_field(v_hd_2483, 2), 1, (V[]){v_t_2487}));
  V f_ = heff_get_n(v_hd_2483, 1, 3);
  args[0] = v_t_2488;
  args[1] = v_k2_2484;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam10(V self, V *args) {
  V v_hd_2493 = args[0];
  V v_k2_2494 = args[1];
  V v_sp_2492 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2495 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str9), v_sp_2492, NTAG(TAG_Nothing)});
  V v_t_2496 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tr(heff_call(heff_take_field(v_hd_2493, 2), 1, (V[]){v_t_2497}));
  V f_ = heff_get_n(v_hd_2493, 1, 3);
  args[0] = v_t_2498;
  args[1] = v_k2_2494;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam11(V self, V *args) {
  V v_hd_24103 = args[0];
  V v_k2_24104 = args[1];
  V v_sp_24102 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24105 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str10), v_sp_24102, NTAG(TAG_Nothing)});
  V v_t_24106 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tr(heff_call(heff_take_field(v_hd_24103, 2), 1, (V[]){v_t_24107}));
  V f_ = heff_get_n(v_hd_24103, 1, 3);
  args[0] = v_t_24108;
  args[1] = v_k2_24104;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam12(V self, V *args) {
  V v_hd_24115 = args[0];
  V v_k2_24116 = args[1];
  V v_sp_24114 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24117 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str11), v_sp_24114, NTAG(TAG_Nothing)});
  V v_t_24118 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24117})});
  V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
  V v_t_24120 = heff_tr(heff_call(heff_take_field(v_hd_24115, 2), 1, (V[]){v_t_24119}));
  V f_ = heff_get_n(v_hd_24115, 1, 3);
  args[0] = v_t_24120;
  args[1] = v_k2_24116;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_str0, 2, "it");
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_241 = heff_dup(heff_field(v_n_240, 0));
    V v_n2_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_n1_241)) {
    case TAG_CInf: {
      heff_take_n(v_n1_241, 0ULL, 1);
      heff_drop(v_n2_242);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_240);
    }
    case TAG_CType: {
      heff_take_n(v_n1_241, 0ULL, 1);
      heff_drop(v_n2_242);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_240);
    }
    case TAG_CLam: {
      V v_x_245 = heff_field(v_n1_241, 0);
      V v_body_247 = heff_field(v_n1_241, 2);
      heff_take_n(v_n1_241, 5ULL, 3);
      heff_drop(v_n2_242);
      V v_t_248 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_247));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0, 2, 3, (V[]){v_t_248, v_n_240, v_x_245});
    }
    case TAG_CImplicitLam: {
      V v_x_2416 = heff_field(v_n1_241, 0);
      V v_body_2418 = heff_field(v_n1_241, 2);
      heff_take_n(v_n1_241, 5ULL, 3);
      heff_drop(v_n2_242);
      V v_t_2419 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_2418));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2, 2, 3, (V[]){v_t_2419, v_n_240, v_x_2416});
    }
    case TAG_CAnnLam: {
      V v_x_2427 = heff_field(v_n1_241, 0);
      V v_tyN_2429 = heff_field(v_n1_241, 2);
      V v_body_2430 = heff_field(v_n1_241, 3);
      heff_take_n(v_n1_241, 13ULL, 4);
      heff_drop(v_n2_242);
      V v_c_2431 = ({ V a_0 = v_tyN_2429; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_tyN_2429); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4, 2, 4, (V[]){v_c_2431, v_body_2430, v_n_240, v_x_2427});
    }
    case TAG_CTag: {
      V v_x_2441 = heff_field(v_n1_241, 0);
      V v_tsp_2442 = heff_field(v_n1_241, 1);
      V v_args_2443 = heff_field(v_n1_241, 2);
      heff_take_n(v_n1_241, 7ULL, 3);
      heff_drop(v_n2_242);
      V v_c_2444 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s637354997x51537058(v_args_2443));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7, 2, 4, (V[]){v_c_2444, v_n_240, v_tsp_2442, v_x_2441});
    }
    case TAG_CStruct: {
      V v_fields_2452 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      V v_c_2453 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1283337555x1974181603(v_fields_2452));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9, 2, 2, (V[]){v_c_2453, v_n2_242});
    }
    case TAG_CMatch: {
      V v_scrutN_2458 = heff_field(v_n1_241, 0);
      V v_casesN_2459 = heff_field(v_n1_241, 1);
      heff_take_n(v_n1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      V v_x1_2460 = (g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744(v_casesN_2459));
      V v_t_2461 = heff_bool(!(heff_dup(v_x1_2460) == NTAG(TAG_True)));
      heff_drop(v_x1_2460);
      if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
        heff_drop(v_t_2461);
        return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11, 2, 3, (V[]){v_casesN_2459, v_scrutN_2458, v_n2_242});
      } else {
        heff_drop(v_t_2461);
        V v_t_2484 = (g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(v_casesN_2459));
        V v_t_2486 = heff_bool(((heff_dup(v_t_2484) == NTAG(TAG_True)) && ({ V v_x1_2485 = (g_heff_2eelab_2etoplevel_2eannotatesData(v_scrutN_2458)); int c_ = !(heff_dup(v_x1_2485) == NTAG(TAG_True)); heff_drop(v_x1_2485); c_; })));
        heff_drop(v_t_2484);
        if ((heff_dup(v_t_2486) == NTAG(TAG_True))) {
          heff_drop(v_t_2486);
          V v_c_2487 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_scrutN_2458));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19, 2, 3, (V[]){v_c_2487, v_casesN_2459, v_n2_242});
        } else {
          heff_drop(v_t_2486);
          V v_x1_2499 = (g_heff_2eelab_2eclauses_2etraverseC_24s246054844x100991343(v_casesN_2459));
          V v_t_24104;
          switch (heff_tag_of(v_x1_2499)) {
          case TAG_Left: {
            V v_e_24100 = heff_field(v_x1_2499, 0);
            V v_ru_24x1_2499_24Left = heff_take_reuse_n(v_x1_2499, 1ULL, 1);
            heff_drop(v_n2_242);
            v_t_24104 = heff_tag_at_n(v_ru_24x1_2499_24Left, TAG_Left, 1, (V[]){v_e_24100});
            break;
          }
          case TAG_Right: {
            V v_x_24101 = heff_field(v_x1_2499, 0);
            heff_take_n(v_x1_2499, 1ULL, 1);
            V v_used_24102 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(v_x_24101, NTAG(TAG_Nil)));
            V v_t_24103 = (g_heff_2eelab_2eclauses_2efresh(v_used_24102, ((V)&g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_str0)));
            v_t_24104 = (g_heff_2eelab_2eclauses_2ecaseTreeOf(v_n2_242, v_x_24101, v_used_24102, v_t_24103));
            break;
          }
          default: heff_nomatch(v_x1_2499);
          }
          switch (heff_tag_of(v_t_24104)) {
          case TAG_Left: {
            V v_err_24105 = heff_field(v_t_24104, 0);
            heff_take_n(v_t_24104, 1ULL, 1);
            heff_drop(v_scrutN_2458);
            return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22, 2, 1, (V[]){v_err_24105});
          }
          case TAG_Right: {
            V v_r_24112 = heff_field(v_t_24104, 0);
            heff_take_n(v_t_24104, 1ULL, 1);
            V v_c_24113 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_scrutN_2458));
            return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23, 2, 2, (V[]){v_c_24113, v_r_24112});
          }
          default: return heff_nomatch(v_t_24104);
          }
        }
      }
    }
    case TAG_CLetIn: {
      V v_rhsN_24120 = heff_field(v_n1_241, 0);
      V v_alt0_24121 = heff_field(v_n1_241, 1);
      V v_ru_24n1_241_24CLetIn = heff_take_reuse_n(v_n1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      switch (heff_tag_of(v_alt0_24121)) {
      case TAG_At: {
        V v_it1_24122 = heff_dup(heff_field(v_alt0_24121, 0));
        switch (heff_tag_of(v_it1_24122)) {
        case TAG_MkAlt: {
          V v_it11_24124 = heff_field(v_it1_24122, 0);
          V v_bodyN_24125 = heff_field(v_it1_24122, 1);
          V v_ru_24it1_24122_24MkAlt = heff_take_reuse_n(v_it1_24122, 3ULL, 2);
          switch (heff_tag_of(v_it11_24124)) {
          case TAG_At: {
            V v_it111_24126 = heff_field(v_it11_24124, 0);
            heff_take_n(v_it11_24124, 1ULL, 2);
            switch (heff_tag_of(v_it111_24126)) {
            case TAG_PatVar: {
              V v_x_24128 = heff_field(v_it111_24126, 0);
              heff_take_n(v_it111_24126, 1ULL, 1);
              heff_drop(v_n2_242);
              heff_drop_tag(v_alt0_24121, 2);
              heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
              heff_drop_cell(v_ru_24it1_24122_24MkAlt, 2);
              V v_c_24129 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_rhsN_24120));
              return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26, 2, 3, (V[]){v_c_24129, v_bodyN_24125, v_x_24128});
            }
            case TAG_PatTag: {
              heff_take_n(v_it111_24126, 0ULL, 3);
              heff_drop(v_bodyN_24125);
              V v_t_24139 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24140 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24139}), v_n2_242});
              V t_0 = v_t_24140;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatOp: {
              heff_take_n(v_it111_24126, 0ULL, 3);
              heff_drop(v_bodyN_24125);
              V v_t_24144 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24145 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24144}), v_n2_242});
              V t_0 = v_t_24145;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatInt: {
              heff_take_n(v_it111_24126, 0ULL, 1);
              heff_drop(v_bodyN_24125);
              V v_t_24147 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24148 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24147}), v_n2_242});
              V t_0 = v_t_24148;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatFloat: {
              heff_take_n(v_it111_24126, 0ULL, 1);
              heff_drop(v_bodyN_24125);
              V v_t_24150 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24151 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24150}), v_n2_242});
              V t_0 = v_t_24151;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatString: {
              heff_take_n(v_it111_24126, 0ULL, 1);
              heff_drop(v_bodyN_24125);
              V v_t_24153 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24154 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24153}), v_n2_242});
              V t_0 = v_t_24154;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatBytes: {
              heff_take_n(v_it111_24126, 0ULL, 1);
              heff_drop(v_bodyN_24125);
              V v_t_24156 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24157 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24156}), v_n2_242});
              V t_0 = v_t_24157;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatRune: {
              heff_take_n(v_it111_24126, 0ULL, 1);
              heff_drop(v_bodyN_24125);
              V v_t_24159 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24160 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24159}), v_n2_242});
              V t_0 = v_t_24160;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatRecord: {
              heff_take_n(v_it111_24126, 0ULL, 1);
              heff_drop(v_bodyN_24125);
              V v_t_24162 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24163 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24162}), v_n2_242});
              V t_0 = v_t_24163;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatWord: {
              heff_take_n(v_it111_24126, 0ULL, 1);
              heff_drop(v_bodyN_24125);
              V v_t_24165 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24166 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24165}), v_n2_242});
              V t_0 = v_t_24166;
              v_n_240 = t_0;
              goto top;
            }
            case TAG_PatAs: {
              heff_take_n(v_it111_24126, 0ULL, 3);
              heff_drop(v_bodyN_24125);
              V v_t_24170 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_24121, NTAG(TAG_Nil)});
              V v_t_24171 = heff_tag_at_n(v_ru_24it1_24122_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_rhsN_24120, v_t_24170}), v_n2_242});
              V t_0 = v_t_24171;
              v_n_240 = t_0;
              goto top;
            }
            default: return heff_nomatch(v_it111_24126);
            }
          }
          default: return heff_nomatch(v_it11_24124);
          }
        }
        default: return heff_nomatch(v_it1_24122);
        }
      }
      default: return heff_nomatch(v_alt0_24121);
      }
    }
    case TAG_CLocal: {
      V v_bodyN_24172 = heff_field(v_n1_241, 0);
      V v_defs_24173 = heff_field(v_n1_241, 1);
      heff_take_n(v_n1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_n2_242);
      return ({ V a_0 = v_defs_24173; V a_1 = v_bodyN_24172; V r_ = (g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(a_0, a_1)); heff_drop(v_defs_24173); r_; });
    }
    case TAG_CAbandon: {
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29, 2, 1, (V[]){v_n2_242});
    }
    case TAG_CNominal: {
      V v_c_24177 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_n2_242);
      V v_c_24178 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_c_24177));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30, 2, 1, (V[]){v_c_24178});
    }
    default: return heff_nomatch(v_n1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(a[0]);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2413 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2414 = v_s_2413;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2415 = ({ V a_0 = v_t_2414; V a_1 = v_x_245; V a_2 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2efunctionIntro(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
  V f_ = v_k_2410;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_t_248 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_248, v_hd_249, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1, 1, 3, (V[]){v_n_240, v_x_245, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2425;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2424 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2425 = v_s_2424;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2426 = ({ V a_0 = v_t_2425; V a_1 = v_x_2416; V a_2 = v_x_2422; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_x_2422); r_; });
  V f_ = v_k_2421;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_t_2419 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2419, v_hd_2420, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3, 1, 3, (V[]){v_n_240, v_x_2416, v_k_2421})));
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_k_2433 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2439;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2438 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2439 = v_s_2438;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2440 = ({ V a_0 = v_t_2439; V a_1 = v_x_2427; V a_2 = v_x_2434; V a_3 = v_x_2436; V r_ = (g_heff_2eelab_2erules_2efunctionIntroAnn(a_0, a_1, a_2, a_3)); heff_drop(v_x_2434); heff_drop(v_x_2436); r_; });
  V f_ = v_k_2433;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_body_2430 = heff_env(self)[0];
  V v_hd_2432 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  V v_k_2433 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2435 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_2430));
  V f_ = v_c_2435;
  heff_room[0] = v_hd_2432;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6, 1, 4, (V[]){v_n_240, v_x_2427, v_x_2434, v_k_2433});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_c_2431 = heff_env(self)[0];
  V v_body_2430 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2431;
  args[0] = heff_dup(v_hd_2432);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5, 1, 5, (V[]){v_body_2430, v_hd_2432, v_n_240, v_x_2427, v_k_2433});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8(V self, V *args) {
  V v_x_2447 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_tsp_2442 = heff_env(self)[1];
  V v_x_2441 = heff_env(self)[2];
  V v_k_2446 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2450;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2449 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2450 = v_s_2449;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2451 = (g_heff_2eelab_2erules_2esumIntro(v_t_2450, v_tsp_2442, v_x_2441, v_x_2447));
  V f_ = v_k_2446;
  args[0] = v_x_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  V v_c_2444 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_tsp_2442 = heff_env(self)[2];
  V v_x_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2444;
  args[0] = v_hd_2445;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8, 1, 4, (V[]){v_n_240, v_tsp_2442, v_x_2441, v_k_2446});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10(V self, V *args) {
  V v_x_2456 = args[0];
  V v_n2_242 = heff_env(self)[0];
  V v_k_2455 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2457 = (g_heff_2eelab_2erules_2erecordIntro(v_n2_242, v_x_2456));
  V f_ = v_k_2455;
  args[0] = v_t_2457;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  V v_c_2453 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2453;
  args[0] = v_hd_2454;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10, 1, 2, (V[]){v_n2_242, v_k_2455});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15(V self, V *args) {
  V v_x_2474 = args[0];
  V v_body_2470 = heff_env(self)[0];
  V v_sp_2468 = heff_env(self)[1];
  V v_k_2473 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_2474, v_body_2470}), v_sp_2468});
  V f_ = v_k_2473;
  args[0] = v_t_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k_2473 = args[1];
  V v_c_2471 = heff_env(self)[0];
  V v_body_2470 = heff_env(self)[1];
  V v_sp_2468 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2471;
  args[0] = v_hd_2472;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15, 1, 3, (V[]){v_body_2470, v_sp_2468, v_k_2473});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13(V self, V *args) {
  V v_m_2466 = args[0];
  V v_e_2464 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2466)) {
  case TAG_At: {
    V v_x21_2467 = heff_field(v_m_2466, 0);
    V v_sp_2468 = heff_field(v_m_2466, 1);
    heff_take_n(v_m_2466, 3ULL, 2);
    switch (heff_tag_of(v_x21_2467)) {
    case TAG_MkAlt: {
      V v_p_2469 = heff_field(v_x21_2467, 0);
      V v_body_2470 = heff_field(v_x21_2467, 1);
      heff_take_n(v_x21_2467, 3ULL, 2);
      V v_c_2471 = (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_2464, 1, 6), v_p_2469));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14, 2, 3, (V[]){v_c_2471, v_body_2470, v_sp_2468});
    }
    default: return heff_nomatch(v_x21_2467);
    }
  }
  default: return heff_nomatch(v_m_2466);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18(V self, V *args) {
  V v_x_2482 = args[0];
  V v_e_2464 = heff_env(self)[0];
  V v_a_2465 = heff_env(self)[1];
  V v_hd_2477 = heff_env(self)[2];
  V v_k_2478 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2482)) {
  case TAG_MkChk: {
    V v_f_2483 = heff_field(v_x_2482, 0);
    heff_take_n(v_x_2482, 1ULL, 1);
    V f_ = v_f_2483;
    heff_room[0] = v_e_2464;
    heff_room[1] = v_a_2465;
    heff_room[2] = v_hd_2477;
    heff_room[3] = v_k_2478;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_2482);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17(V self, V *args) {
  V v_x_2479 = args[0];
  V v_scrutN_2458 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  V v_hd_2477 = heff_env(self)[2];
  V v_e_2464 = heff_env(self)[3];
  V v_a_2465 = heff_env(self)[4];
  V v_k_2478 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2480 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_scrutN_2458, v_x_2479}), v_n2_242});
  V v_c_2481 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_2480));
  V f_ = v_c_2481;
  heff_room[0] = heff_dup(v_hd_2477);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18, 1, 4, (V[]){v_e_2464, v_a_2465, v_hd_2477, v_k_2478});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16(V self, V *args) {
  V v_hd_2477 = args[0];
  V v_k_2478 = args[1];
  V v_c_2476 = heff_env(self)[0];
  V v_scrutN_2458 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  V v_e_2464 = heff_env(self)[3];
  V v_a_2465 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2476;
  args[0] = heff_dup(v_hd_2477);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17, 1, 6, (V[]){v_scrutN_2458, v_n2_242, v_hd_2477, v_e_2464, v_a_2465, v_k_2478});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12(V self, V *args) {
  V v_e_2464 = args[0];
  V v_a_2465 = args[1];
  V v_casesN_2459 = heff_env(self)[0];
  V v_scrutN_2458 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2476 = (g_heff_2eelab_2etoplevel_2etraverseEL(heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13, 1, 1, (V[]){heff_dup(v_e_2464)}), v_casesN_2459));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16, 2, 5, (V[]){v_c_2476, v_scrutN_2458, v_n2_242, v_e_2464, v_a_2465});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_casesN_2459 = heff_env(self)[0];
  V v_scrutN_2458 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2462);
  V f_ = v_k_2463;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12, 2, 3, (V[]){v_casesN_2459, v_scrutN_2458, v_n2_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21(V self, V *args) {
  V v_x_2492 = args[0];
  V v_casesN_2459 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  V v_x_2490 = heff_env(self)[2];
  V v_k_2489 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2493 = (g_heff_2eelab_2etoplevel_2etagSpans(v_casesN_2459));
  V v_t_2494 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2492)));
  V v_t_2495 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2492));
  V v_t_2496 = (g_list_2emap_24s1173914895x100384474(v_x_2492));
  V v_t_2497 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2494), v_t_2495, heff_arrayFromList(v_t_2496)});
  V v_x_2498 = ({ V a_0 = v_n2_242; V a_1 = v_x_2490; V a_2 = v_t_2493; V a_3 = v_t_2497; V r_ = (g_heff_2eelab_2erules_2esumElim(a_0, a_1, a_2, a_3)); heff_drop(v_x_2490); heff_drop(v_t_2493); r_; });
  V f_ = v_k_2489;
  args[0] = v_x_2498;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20(V self, V *args) {
  V v_x_2490 = args[0];
  V v_casesN_2459 = heff_env(self)[0];
  V v_hd_2488 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  V v_k_2489 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2491 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s499648829x347965743(heff_dup(v_casesN_2459)));
  V f_ = v_c_2491;
  heff_room[0] = v_hd_2488;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21, 1, 4, (V[]){v_casesN_2459, v_n2_242, v_x_2490, v_k_2489});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  V v_c_2487 = heff_env(self)[0];
  V v_casesN_2459 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2487;
  args[0] = heff_dup(v_hd_2488);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20, 1, 4, (V[]){v_casesN_2459, v_hd_2488, v_n2_242, v_k_2489});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22(V self, V *args) {
  V v_hd_24106 = args[0];
  V v_k2_24107 = args[1];
  V v_err_24105 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24108 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), heff_take_field(v_err_24105, 1), heff_get_n(v_err_24105, 0, 2), NTAG(TAG_Nothing)});
  V v_t_24109 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tr(heff_call(heff_take_field(v_hd_24106, 2), 1, (V[]){v_t_24110}));
  V f_ = heff_get_n(v_hd_24106, 1, 3);
  args[0] = v_t_24111;
  args[1] = v_k2_24107;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25(V self, V *args) {
  V v_x_24118 = args[0];
  V v_r_24112 = heff_env(self)[0];
  V v_x_24116 = heff_env(self)[1];
  V v_k_24115 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24119 = ({ V a_0 = heff_get_n(v_r_24112, 0, 2); V a_1 = v_x_24116; V a_2 = v_x_24118; V r_ = (g_heff_2eelab_2erules_2ecaseLet(a_0, a_1, a_2)); heff_drop(v_x_24116); heff_drop(v_x_24118); r_; });
  V f_ = v_k_24115;
  args[0] = v_t_24119;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24(V self, V *args) {
  V v_x_24116 = args[0];
  V v_r_24112 = heff_env(self)[0];
  V v_hd_24114 = heff_env(self)[1];
  V v_k_24115 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24117 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(heff_rfield(v_r_24112, 1))));
  V f_ = v_c_24117;
  heff_room[0] = v_hd_24114;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25, 1, 3, (V[]){v_r_24112, v_x_24116, v_k_24115});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23(V self, V *args) {
  V v_hd_24114 = args[0];
  V v_k_24115 = args[1];
  V v_c_24113 = heff_env(self)[0];
  V v_r_24112 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24113;
  args[0] = heff_dup(v_hd_24114);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24, 1, 3, (V[]){v_r_24112, v_hd_24114, v_k_24115});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28(V self, V *args) {
  V v_x_24134 = args[0];
  V v_x_24128 = heff_env(self)[0];
  V v_x_24132 = heff_env(self)[1];
  V v_k_24131 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24135 = ({ V a_0 = v_x_24128; V a_1 = v_x_24132; V a_2 = v_x_24134; V r_ = (g_heff_2eelab_2erules_2ecaseLet(a_0, a_1, a_2)); heff_drop(v_x_24132); heff_drop(v_x_24134); r_; });
  V f_ = v_k_24131;
  args[0] = v_t_24135;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27(V self, V *args) {
  V v_x_24132 = args[0];
  V v_bodyN_24125 = heff_env(self)[0];
  V v_hd_24130 = heff_env(self)[1];
  V v_x_24128 = heff_env(self)[2];
  V v_k_24131 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24133 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_bodyN_24125));
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_24133, v_hd_24130, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28, 1, 3, (V[]){v_x_24128, v_x_24132, v_k_24131})));
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26(V self, V *args) {
  V v_hd_24130 = args[0];
  V v_k_24131 = args[1];
  V v_c_24129 = heff_env(self)[0];
  V v_bodyN_24125 = heff_env(self)[1];
  V v_x_24128 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24129;
  args[0] = heff_dup(v_hd_24130);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27, 1, 4, (V[]){v_bodyN_24125, v_hd_24130, v_x_24128, v_k_24131});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29(V self, V *args) {
  V v_hd_24174 = args[0];
  V v_k_24175 = args[1];
  V v_n2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24174);
  V v_t_24176 = (g_heff_2eelab_2erules_2eabandonChk(v_n2_242));
  V f_ = v_k_24175;
  args[0] = v_t_24176;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31(V self, V *args) {
  V v_x_24181 = args[0];
  V v_k_24180 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24182 = ({ V a_0 = v_x_24181; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop(v_x_24181); r_; });
  V f_ = v_k_24180;
  args[0] = v_t_24182;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30(V self, V *args) {
  V v_hd_24179 = args[0];
  V v_k_24180 = args[1];
  V v_c_24178 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24178;
  args[0] = v_hd_24179;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31, 1, 1, (V[]){v_k_24180});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_c_245 = (g_heff_2eelab_2etoplevel_2evariantF_24s114968106x648122774(v_x_243));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam1, 2, 2, (V[]){v_c_245, v_xs_244});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(a[0]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_249 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718(v_xs_244));
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam3, 1, 2, (V[]){v_k_247, v_x_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_xs_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_24s1267189985x335600718_lam2, 1, 3, (V[]){v_xs_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_ab_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_take_field(v_ab_242, 3);
    V v_x1_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Expl: {
      v_x1_245 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_x1_245 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_x1_245 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    if ((heff_dup(v_x1_245) == NTAG(TAG_True))) {
      heff_drop(v_x1_245);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_ab_242, 1, 4), heff_hole()});
      V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_rest_243;
      V t_1 = v_cell_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_ab_242, 4);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_x1_245);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2edeclJ_str0, 45, "unexpected notation for top-level declaration");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edeclJ_str1, 45, "unexpected notation for top-level declaration");
V g_heff_2eelab_2etoplevel_2edeclJ_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2edeclJ_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edeclJ_lam3, 1, 0};
V g_heff_2eelab_2etoplevel_2edeclJ_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam5(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edeclJ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edeclJ_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2edeclJ(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_d1_241 = heff_field(v_d_240, 0);
    switch (heff_tag_of(v_d1_241)) {
    case TAG_DeclEquations: {
      V v_name_243 = heff_field(v_d1_241, 0);
      V v_tyN_246 = heff_field(v_d1_241, 3);
      V v_eqs_247 = heff_field(v_d1_241, 4);
      V v_t_2410;
      switch (heff_tag_of(v_tyN_246)) {
      case TAG_At: {
        V v_s_249 = heff_field(v_tyN_246, 1);
        v_t_2410 = heff_dup(v_s_249);
        break;
      }
      default: heff_nomatch(v_tyN_246);
      }
      V v_t_2413;
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        V v_s_2412 = heff_field(v_d_240, 1);
        v_t_2413 = heff_dup(v_s_2412);
        break;
      }
      default: heff_nomatch(v_d_240);
      }
      V v_t_2414 = ({ V rv_1 = heff_get_n(v_t_2413, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2410, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return (g_heff_2eelab_2etoplevel_2eequationsD(heff_dup(v_name_243), v_tyN_246, heff_dup(v_eqs_247), v_t_2414));
    }
    case TAG_DeclDefine: {
      V v_name_2415 = heff_field(v_d1_241, 0);
      V v_params_2417 = heff_field(v_d1_241, 2);
      V v_tyN_2418 = heff_field(v_d1_241, 3);
      V v_bodyN_2419 = heff_field(v_d1_241, 4);
      return (g_heff_2eelab_2etoplevel_2edefineD(heff_dup(v_name_2415), heff_dup(v_params_2417), v_tyN_2418, v_bodyN_2419));
    }
    case TAG_DeclTheory: {
      V v_name_2420 = heff_field(v_d1_241, 0);
      V v_params_2422 = heff_field(v_d1_241, 2);
      V v_bodyN_2423 = heff_field(v_d1_241, 3);
      return (g_heff_2eelab_2etoplevel_2etheoryD(heff_dup(v_name_2420), heff_dup(v_params_2422), v_bodyN_2423));
    }
    case TAG_DeclPrimitive: {
      V v_x_2424 = heff_field(v_d1_241, 0);
      V v_tyN_2426 = heff_field(v_d1_241, 2);
      V v_n_2429;
      switch (heff_tag_of(v_tyN_2426)) {
      case TAG_At: {
        V v_n_2427 = heff_field(v_tyN_2426, 0);
        V v_sp_2428 = heff_field(v_tyN_2426, 1);
        v_n_2429 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(heff_dup(v_sp_2428), heff_dup(v_n_2427)));
        break;
      }
      default: heff_nomatch(v_tyN_2426);
      }
      V v_c_2430 = ({ V a_0 = v_n_2429; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n_2429); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam0, 2, 2, (V[]){v_c_2430, heff_dup(v_x_2424)});
    }
    case TAG_DeclTest: {
      V v_sp_2445;
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        V v_s_2444 = heff_field(v_d_240, 1);
        v_sp_2445 = heff_dup(v_s_2444);
        break;
      }
      default: heff_nomatch(v_d_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam4, 2, 1, (V[]){v_sp_2445});
    }
    case TAG_DeclWatch: {
      V v_sp_2455;
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        V v_s_2454 = heff_field(v_d_240, 1);
        v_sp_2455 = heff_dup(v_s_2454);
        break;
      }
      default: heff_nomatch(v_d_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam5, 2, 1, (V[]){v_sp_2455});
    }
    default: return heff_nomatch(v_d1_241);
    }
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2eelab_2etoplevel_2edeclJ_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2edeclJ(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam3(V self, V *args) {
  V v_u_2438 = args[0];
  heff_drop(v_u_2438);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam2(V self, V *args) {
  V v_e_2434 = args[0];
  V v_a_2435 = args[1];
  V v_hd_2436 = args[2];
  V v_k_2437 = args[3];
  V v_x_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2434);
  heff_drop(v_a_2435);
  heff_drop(v_hd_2436);
  V v_t_2439 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_2424}), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_lam3_clo)});
  V f_ = v_k_2437;
  args[0] = v_t_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam1(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_k_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){heff_dup(v_x_2424), v_x_2433, heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam2, 4, 1, (V[]){v_x_2424})}), NTAG(TAG_True)});
  V f_ = v_k_2432;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam0(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2430;
  args[0] = v_hd_2431;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam1, 1, 2, (V[]){v_x_2424, v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam4(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k2_2447 = args[1];
  V v_sp_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_str0), v_sp_2445, NTAG(TAG_Nothing)});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_call(heff_take_field(v_hd_2446, 2), 1, (V[]){v_t_2450}));
  V f_ = heff_get_n(v_hd_2446, 1, 3);
  args[0] = v_t_2451;
  args[1] = v_k2_2447;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam5(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  V v_sp_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_str1), v_sp_2455, NTAG(TAG_Nothing)});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_call(heff_take_field(v_hd_2456, 2), 1, (V[]){v_t_2460}));
  V f_ = heff_get_n(v_hd_2456, 1, 3);
  args[0] = v_t_2461;
  args[1] = v_k2_2457;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enubInt_24dps_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enubInt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enubInt_24dps_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2enubInt_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_248 = (g_list_2efilter(heff_clo_n(g_heff_2eelab_2etoplevel_2enubInt_24dps_lam0, 1, 1, (V[]){v_x_242}), v_xs_243));
    V t_0 = v_t_248;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2enubInt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2enubInt_24dps(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2enubInt_24dps_lam0(V self, V *args) {
  V v_y_246 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ret_24bool = heff_bool(!heff_intEq_c(heff_dup(v_y_246), heff_dup(v_x_242)));
  heff_drop(v_y_246);
  heff_drop(v_x_242);
  return v_ret_24bool;
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebodyEnv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyEnv_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ebodyEnv(V v_gSelf_240, V v_k_241, V v_name_242, V v_aval_243) {
top: ;
  V v_v_245 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_k_241)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyEnv_lam0, 1, 1, (V[]){heff_dup(v_aval_243)}), NTAG(TAG_Nothing)));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_name_242, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyEnv_lam1, 1, 1, (V[]){v_v_245})});
  V v_t_249 = heff_tag_n(TAG_CBind, 3, (V[]){NTAG(TAG_CEmpty), heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(1LL)}), v_aval_243});
  V v_t_2410 = heff_tag_n(TAG_ForDescriptive, 2, (V[]){heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_k_241)}), NTAG(TAG_SpId)});
  return heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_rec_n(4, shape_len__names__locals__ctx, (V[]){MK_INT(1LL), v_t_246, v_t_248, v_t_249}), v_gSelf_240, v_t_2410, MK_INT(0LL), heff_tag_n(TAG_Just, 1, (V[]){v_k_241}), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebodyEnv(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_aval_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return v_aval_243;
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_v_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_v_245;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str1, 2, ", ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str2, 20, "` (the runtime has: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str3, 55, ", and each fixed-width type's, `int32Add` and the like)");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str4, 30, "there is no primitive called `");
V g_heff_2eelab_2etoplevel_2eprimKnown_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eprimKnown_lam1(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eprimKnown_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eprimKnown_lam1, 2, 0};
Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eprimKnown_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eprimKnown(V v_sp_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 3);
  V v_t_246 = heff_bool(((heff_dup(v_t_242) == NTAG(TAG_True)) && ({ V v_xs_243 = heff_dup(g_heff_2eelab_2etoplevel_2eprimNames_get()); int c_ = ({ V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_d_241, 0))})); int c_ = ({ V v_x1_245 = (g_list_2eany(heff_dup(v_t_244), v_xs_243)); int c_ = !(heff_dup(v_x1_245) == NTAG(TAG_True)); heff_drop(v_x1_245); c_; }); heff_drop(v_t_244); c_; }); heff_drop(v_xs_243); c_; })));
  heff_drop(v_t_242);
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_x2_247 = heff_dup(g_heff_2eelab_2etoplevel_2ebasicPrimNames_get());
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str1); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_t_2411 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str2), heff_strAppend(v_t_2410, ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str3)));
    V v_t_2412 = heff_strAppend(heff_get_n(v_d_241, 0, 4), v_t_2411);
    V v_msg_2413 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str4), v_t_2412);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eprimKnown_lam0, 2, 2, (V[]){v_msg_2413, v_sp_240});
  } else {
    heff_drop(v_sp_240);
    heff_drop_rec(v_d_241, 4);
    heff_drop(v_t_246);
    return ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_lam1_clo);
  }
}
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eprimKnown(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eprimKnown_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k2_2415 = args[1];
  V v_msg_2413 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(329LL), NTAG(TAG_SError), v_msg_2413, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tr(heff_call(heff_take_field(v_hd_2414, 2), 1, (V[]){v_t_2418}));
  V f_ = heff_get_n(v_hd_2414, 1, 3);
  args[0] = v_t_2419;
  args[1] = v_k2_2415;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eprimKnown_lam1(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str0, 100, "` is not in what it is an instance of: a search, unifying that with the type wanted, cannot solve it");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str1, 34, "the instance's implicit argument `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str2, 120, "use it in what the instance is an instance of (`{a : Type} -> {{e : Equality a}} -> Equality (List a)`), or leave it out");
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eeveryImplicitIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eeveryImplicitIn_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eeveryImplicitIn(V v_sp_240, V v_depth_241, V v_conclusion_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sp_240);
    heff_drop(v_depth_241);
    heff_drop(v_conclusion_242);
    return ((V)&g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam0_clo);
  }
  case TAG_Cons: {
    V v_b_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    V v_t_248 = heff_intSub(heff_intSub(heff_dup(v_depth_241), MK_INT(1LL)), heff_dup(heff_rfield(v_b_246, 1)));
    V v_t_249 = (g_heff_2eelab_2erules_2ementionsLocal(v_t_248));
    V v_t_2410 = heff_tr(heff_call(heff_get_n(v_t_249, 1, 3), 2, (V[]){MK_INT(0LL), heff_dup(v_conclusion_242)}));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V t_0 = v_sp_240;
      V t_1 = v_depth_241;
      V t_2 = v_conclusion_242;
      V t_3 = v_rest_247;
      v_sp_240 = t_0;
      v_depth_241 = t_1;
      v_conclusion_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_depth_241);
      heff_drop(v_conclusion_242);
      heff_drop(v_t_2410);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam1, 2, 2, (V[]){heff_dup(v_b_246), v_sp_240});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k2_2412 = args[1];
  V v_b_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_strAppend(heff_get_n(v_b_246, 0, 2), ((V)&g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str0));
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(350LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str1), v_t_2413), v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str2)})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_2411, 2), 1, (V[]){v_t_2416}));
  V f_ = heff_get_n(v_hd_2411, 1, 3);
  args[0] = v_t_2417;
  args[1] = v_k2_2412;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str0, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str1, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str2, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str3, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str4, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str5, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str6, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str7, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str8, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str9, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str10, 54, "a watch must say what type it has: write `>>> (e : T)`");
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam10(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ewatchSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchSyn_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ewatchSyn(V v_w_240) {
top: ;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_w1_241 = heff_field(v_w_240, 0);
    switch (heff_tag_of(v_w1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_w1_241, 0);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_i_243));
    }
    case TAG_CType: {
      V v_sp_247;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_246 = heff_field(v_w_240, 1);
        v_sp_247 = heff_dup(v_s_246);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam0, 2, 1, (V[]){v_sp_247});
    }
    case TAG_CLam: {
      V v_sp_2419;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2418 = heff_field(v_w_240, 1);
        v_sp_2419 = heff_dup(v_s_2418);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam1, 2, 1, (V[]){v_sp_2419});
    }
    case TAG_CImplicitLam: {
      V v_sp_2431;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2430 = heff_field(v_w_240, 1);
        v_sp_2431 = heff_dup(v_s_2430);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam2, 2, 1, (V[]){v_sp_2431});
    }
    case TAG_CAnnLam: {
      V v_sp_2444;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2443 = heff_field(v_w_240, 1);
        v_sp_2444 = heff_dup(v_s_2443);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam3, 2, 1, (V[]){v_sp_2444});
    }
    case TAG_CTag: {
      V v_sp_2456;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2455 = heff_field(v_w_240, 1);
        v_sp_2456 = heff_dup(v_s_2455);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam4, 2, 1, (V[]){v_sp_2456});
    }
    case TAG_CStruct: {
      V v_sp_2466;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2465 = heff_field(v_w_240, 1);
        v_sp_2466 = heff_dup(v_s_2465);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam5, 2, 1, (V[]){v_sp_2466});
    }
    case TAG_CMatch: {
      V v_sp_2477;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2476 = heff_field(v_w_240, 1);
        v_sp_2477 = heff_dup(v_s_2476);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam6, 2, 1, (V[]){v_sp_2477});
    }
    case TAG_CLetIn: {
      V v_sp_2488;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2487 = heff_field(v_w_240, 1);
        v_sp_2488 = heff_dup(v_s_2487);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam7, 2, 1, (V[]){v_sp_2488});
    }
    case TAG_CLocal: {
      V v_sp_2499;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_2498 = heff_field(v_w_240, 1);
        v_sp_2499 = heff_dup(v_s_2498);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam8, 2, 1, (V[]){v_sp_2499});
    }
    case TAG_CAbandon: {
      V v_sp_24108;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_24107 = heff_field(v_w_240, 1);
        v_sp_24108 = heff_dup(v_s_24107);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam9, 2, 1, (V[]){v_sp_24108});
    }
    case TAG_CNominal: {
      V v_sp_24118;
      switch (heff_tag_of(v_w_240)) {
      case TAG_At: {
        V v_s_24117 = heff_field(v_w_240, 1);
        v_sp_24118 = heff_dup(v_s_24117);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam10, 2, 1, (V[]){v_sp_24118});
    }
    default: return heff_nomatch(v_w1_241);
    }
  }
  default: return heff_nomatch(v_w_240);
  }
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ewatchSyn(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k2_249 = args[1];
  V v_sp_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str0), v_sp_247, NTAG(TAG_Nothing)});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){v_t_2412}));
  V f_ = heff_get_n(v_hd_248, 1, 3);
  args[0] = v_t_2413;
  args[1] = v_k2_249;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam1(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k2_2421 = args[1];
  V v_sp_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str1), v_sp_2419, NTAG(TAG_Nothing)});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_2420, 2), 1, (V[]){v_t_2424}));
  V f_ = heff_get_n(v_hd_2420, 1, 3);
  args[0] = v_t_2425;
  args[1] = v_k2_2421;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam2(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_sp_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str2), v_sp_2431, NTAG(TAG_Nothing)});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_call(heff_take_field(v_hd_2432, 2), 1, (V[]){v_t_2436}));
  V f_ = heff_get_n(v_hd_2432, 1, 3);
  args[0] = v_t_2437;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam3(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k2_2446 = args[1];
  V v_sp_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str3), v_sp_2444, NTAG(TAG_Nothing)});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tr(heff_call(heff_take_field(v_hd_2445, 2), 1, (V[]){v_t_2449}));
  V f_ = heff_get_n(v_hd_2445, 1, 3);
  args[0] = v_t_2450;
  args[1] = v_k2_2446;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam4(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k2_2458 = args[1];
  V v_sp_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str4), v_sp_2456, NTAG(TAG_Nothing)});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tr(heff_call(heff_take_field(v_hd_2457, 2), 1, (V[]){v_t_2461}));
  V f_ = heff_get_n(v_hd_2457, 1, 3);
  args[0] = v_t_2462;
  args[1] = v_k2_2458;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam5(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k2_2468 = args[1];
  V v_sp_2466 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str5), v_sp_2466, NTAG(TAG_Nothing)});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tr(heff_call(heff_take_field(v_hd_2467, 2), 1, (V[]){v_t_2471}));
  V f_ = heff_get_n(v_hd_2467, 1, 3);
  args[0] = v_t_2472;
  args[1] = v_k2_2468;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam6(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k2_2479 = args[1];
  V v_sp_2477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2480 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str6), v_sp_2477, NTAG(TAG_Nothing)});
  V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tr(heff_call(heff_take_field(v_hd_2478, 2), 1, (V[]){v_t_2482}));
  V f_ = heff_get_n(v_hd_2478, 1, 3);
  args[0] = v_t_2483;
  args[1] = v_k2_2479;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam7(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k2_2490 = args[1];
  V v_sp_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2491 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str7), v_sp_2488, NTAG(TAG_Nothing)});
  V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tr(heff_call(heff_take_field(v_hd_2489, 2), 1, (V[]){v_t_2493}));
  V f_ = heff_get_n(v_hd_2489, 1, 3);
  args[0] = v_t_2494;
  args[1] = v_k2_2490;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam8(V self, V *args) {
  V v_hd_24100 = args[0];
  V v_k2_24101 = args[1];
  V v_sp_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24102 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str8), v_sp_2499, NTAG(TAG_Nothing)});
  V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24102})});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tr(heff_call(heff_take_field(v_hd_24100, 2), 1, (V[]){v_t_24104}));
  V f_ = heff_get_n(v_hd_24100, 1, 3);
  args[0] = v_t_24105;
  args[1] = v_k2_24101;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam9(V self, V *args) {
  V v_hd_24109 = args[0];
  V v_k2_24110 = args[1];
  V v_sp_24108 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24111 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str9), v_sp_24108, NTAG(TAG_Nothing)});
  V v_t_24112 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
  V v_t_24114 = heff_tr(heff_call(heff_take_field(v_hd_24109, 2), 1, (V[]){v_t_24113}));
  V f_ = heff_get_n(v_hd_24109, 1, 3);
  args[0] = v_t_24114;
  args[1] = v_k2_24110;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam10(V self, V *args) {
  V v_hd_24119 = args[0];
  V v_k2_24120 = args[1];
  V v_sp_24118 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24121 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str10), v_sp_24118, NTAG(TAG_Nothing)});
  V v_t_24122 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24121})});
  V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
  V v_t_24124 = heff_tr(heff_call(heff_take_field(v_hd_24119, 2), 1, (V[]){v_t_24123}));
  V f_ = heff_get_n(v_hd_24119, 1, 3);
  args[0] = v_t_24124;
  args[1] = v_k2_24120;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabWatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabWatch_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eelabWatch(V v_g_240, V v_n_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_242));
    v_t_245 = heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_243});
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_c_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2eelab_2etoplevel_2ewatchSyn(a_0)); heff_drop(v_t_245); r_; });
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_lam0, 2, 3, (V[]){v_c_246, v_g_240, v_n_241});
}
V g_heff_2eelab_2etoplevel_2eelabWatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eelabWatch(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2415 = heff_field(v_n_241, 1);
    heff_take_n(v_n_241, 2ULL, 2);
    v_t_2416 = v_s_2415;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  return ({ V a_0 = v_g_240; V a_1 = v_t_2416; V a_2 = v_x_2413; V a_3 = v_hd_247; V a_4 = v_k_248; V r_ = (g_heff_2eelab_2etoplevel_2ewatchPhase(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2413); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2412;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkSyn: {
    V v_f_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2411 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_240), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2412 = heff_tr(heff_call(v_f_2410, 1, (V[]){v_t_2411}));
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_lam2, 1, 4, (V[]){v_n_241, v_g_240, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_lam1, 1, 4, (V[]){v_g_240, v_hd_247, v_n_241, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewithInstance_str0, 0, "");
V g_heff_2eelab_2etoplevel_2ewithInstance_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewithInstance_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithInstance_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ewithInstance(V v_isInstance_240, V v_key_241, V v_name_242, V v_g_243) {
top: ;
  if ((heff_dup(v_isInstance_240) == NTAG(TAG_True))) {
    V v_t_246;
    if (heff_strEq_c(heff_dup(v_key_241), heff_dup(v_name_242))) {
      heff_drop(v_name_242);
      v_t_246 = ((V)&g_heff_2eelab_2etoplevel_2ewithInstance_str0);
    } else {
      V v_t_245 = heff_intSub(heff_strLength(heff_dup(v_key_241)), heff_strLength(v_name_242));
      v_t_246 = heff_strSlice(heff_dup(v_key_241), MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL)));
    }
    return (g_heff_2eelab_2eglobals_2eaddInstance(v_key_241, v_t_246, v_g_243));
  } else {
    heff_drop(v_name_242);
    V v_t_248 = (g_list_2eany(heff_clo_n(g_heff_2eelab_2etoplevel_2ewithInstance_lam0, 1, 1, (V[]){heff_dup(v_key_241)}), heff_rfield(v_g_243, 6)));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_2411 = (g_list_2efilter(heff_clo_n(g_heff_2eelab_2etoplevel_2ewithInstance_lam1, 1, 1, (V[]){v_key_241}), heff_take_field(v_g_243, 6)));
      return ({ V rv_6 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_g_243, 63ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances, 4095u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
    } else {
      heff_drop(v_key_241);
      heff_drop(v_t_248);
      return v_g_243;
    }
  }
}
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ewithInstance(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2ewithInstance_lam0(V self, V *args) {
  V v_i_247 = args[0];
  V v_key_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_i_247, 0, 2), v_key_241);
}
V g_heff_2eelab_2etoplevel_2ewithInstance_lam1(V self, V *args) {
  V v_i_249 = args[0];
  V v_key_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ret_24bool = heff_bool(!heff_strEq_c(heff_dup(heff_rfield(v_i_249, 0)), heff_dup(v_key_241)));
  heff_drop_rec(v_i_249, 2);
  heff_drop(v_key_241);
  return v_ret_24bool;
}
Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V v_acc_240, V v_n_241, V v_diags_242) {
top: ;
  V v_t_2425;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_243 = heff_field(v_n_241, 0);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_DeclEquations: {
      V v_f_245 = heff_field(v_x11_243, 0);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_f_245)});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2410 = heff_field(v_x11_243, 0);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2410)});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2415 = heff_field(v_x11_243, 0);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2415)});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2419 = heff_field(v_x11_243, 0);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2419)});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2422 = heff_field(v_x11_243, 0);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2422)});
      break;
    }
    case TAG_DeclWatch: {
      v_t_2425 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_243);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_t_2425)) {
  case TAG_Nothing: {
    return ({ V rv_1 = v_diags_242; V rr_ = heff_rec_reuse_nf(v_acc_240, 509ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Just: {
    V v_x_2426 = heff_field(v_t_2425, 0);
    heff_take_n(v_t_2425, 1ULL, 1);
    V v_g_2428;
    if (heff_strEq_c(heff_dup(v_x_2426), heff_dup(v_x_2426))) {
      v_g_2428 = heff_dup(heff_rfield(v_acc_240, 0));
    } else {
      v_g_2428 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_x_2426), heff_dup(v_x_2426), heff_dup(heff_rfield(v_acc_240, 0))));
    }
    V v_t_2429 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_2426), NTAG(TAG_MkUnit), heff_take_field(v_g_2428, 3)));
    V v_t_2430 = ({ V rv_3 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_g_2428, 119ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_globals_2431 = (g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720(v_n_241, v_t_2430));
    V v_t_2434;
    switch (heff_tag_of(v_n_241)) {
    case TAG_At: {
      V v_s_2433 = heff_field(v_n_241, 1);
      v_t_2434 = heff_dup(v_s_2433);
      break;
    }
    default: heff_nomatch(v_n_241);
    }
    V v_broken_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2426, v_t_2434}), heff_take_field(v_acc_240, 3)});
    return ({ V rv_0 = v_globals_2431; V rv_1 = v_diags_242; V rv_3 = v_broken_2435; V rr_ = heff_rec_reuse_nf(v_acc_240, 500ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 261936u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  default: return heff_nomatch(v_t_2425);
  }
}
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam5, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(V v_g_240, V v_n_241, V v_st_242) {
top: ;
  V v_c_246;
  switch (heff_tag_of(v_st_242)) {
  case TAG_MkSt: {
    V v_c_243 = heff_dup(heff_field(v_st_242, 0));
    v_c_246 = v_c_243;
    break;
  }
  default: heff_nomatch(v_st_242);
  }
  V v_t_247 = ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_c_246, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  V v_x1_248 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_247}), v_st_242});
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop(v_g_240);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_t_2413 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      V v_t_2417;
      switch (heff_tag_of(v_st_2410)) {
      case TAG_MkSt: {
        V v_d_2415 = heff_field(v_st_2410, 1);
        V v_w_2416 = heff_field(v_st_2410, 2);
        V v_ru_24st_2410_24MkSt = heff_take_reuse_n(v_st_2410, 6ULL, 3);
        v_t_2417 = heff_tag_at_n(v_ru_24st_2410_24MkSt, TAG_MkSt, 3, (V[]){v_x_2412, v_d_2415, v_w_2416});
        break;
      }
      default: heff_nomatch(v_st_2410);
      }
      V v_x1_2418 = heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_t_2417});
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_MkPair: {
        V v_x11_2419 = heff_field(v_x1_2418, 0);
        V v_st_2420 = heff_field(v_x1_2418, 1);
        V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
        switch (heff_tag_of(v_x11_2419)) {
        case TAG_Left: {
          V v_e_2421 = heff_field(v_x11_2419, 0);
          heff_take_n(v_x11_2419, 1ULL, 1);
          heff_drop(v_g_240);
          return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2421}), v_st_2420});
        }
        case TAG_Right: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2418_24MkPair, 2);
          V v_c_2423 = (g_heff_2eelab_2etoplevel_2edeclJ(v_n_241));
          return heff_tail(v_c_2423, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0, 1, 2, (V[]){v_g_240, heff_dup(v_n_241)}), v_st_2420});
        }
        default: return heff_nomatch(v_x11_2419);
        }
      }
      default: return heff_nomatch(v_x1_2418);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  heff_drop(v_hd_2458);
  V f_ = v_k_2459;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam5(V self, V *args) {
  V v_a_2464 = args[0];
  V v_a_2465 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2464}), v_a_2465});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4(V self, V *args) {
  V v_x_2463 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2463);
  return ({ V a_0 = v_g_240; V a_1 = v_n_241; V a_2 = v_x_2424; V a_3 = v_x_2429; V a_4 = heff_dup(g_heff_2eelab_2emeta_2eelabH_get()); V a_5 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam5_clo); V r_ = (g_heff_2eelab_2etoplevel_2eelabBody_24s1470448860x783984115(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_n_241); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_z_2431 = args[1];
  V v_n_241 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_x_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2430);
  V v_x1_2457;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_2432 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_x11_2432)) {
    case TAG_DeclEquations: {
      V v_x113_2436 = heff_field(v_x11_2432, 2);
      V v_tyN_2437 = heff_field(v_x11_2432, 3);
      heff_take_n(v_x11_2432, 12ULL, 5);
      switch (heff_tag_of(v_x113_2436)) {
      case TAG_AsDefinition: {
        heff_drop(v_tyN_2437);
        v_x1_2457 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_AsInstance: {
        V v_t_2441;
        switch (heff_tag_of(v_tyN_2437)) {
        case TAG_At: {
          V v_s_2440 = heff_field(v_tyN_2437, 1);
          heff_take_n(v_tyN_2437, 2ULL, 2);
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_tyN_2437);
        }
        v_x1_2457 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2441});
        break;
      }
      default: heff_nomatch(v_x113_2436);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2432, 0ULL, 5);
      v_x1_2457 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2432, 0ULL, 4);
      v_x1_2457 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2432, 0ULL, 3);
      v_x1_2457 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2432, 0ULL, 2);
      v_x1_2457 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2432, 0ULL, 1);
      v_x1_2457 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2432);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_c_2462;
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_Nothing: {
    v_c_2462 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3_clo);
    break;
  }
  case TAG_Just: {
    V v_sp_2460 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    V v_t_2461 = (g_heff_2esyntax_2epsurface_2eunIsTy(heff_dup(heff_rfield(v_x_2429, 0))));
    v_c_2462 = (g_heff_2eelab_2etoplevel_2esearchedInstance(v_sp_2460, NTAG(TAG_Nil), MK_INT(0LL), v_t_2461));
    break;
  }
  default: heff_nomatch(v_x1_2457);
  }
  V f_ = v_c_2462;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4, 1, 4, (V[]){v_g_240, v_n_241, v_x_2424, v_x_2429});
  heff_room[2] = v_z_2431;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo);
  args[0] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2, 2, 4, (V[]){v_n_241, v_x_2429, v_g_240, v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0(V self, V *args) {
  V v_x_2424 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_dup(heff_rfield(v_x_2424, 1));
  V v_c_2428;
  switch (heff_tag_of(v_t_2425)) {
  case TAG_MkTyp: {
    V v_f_2426 = heff_field(v_t_2425, 0);
    heff_take_n(v_t_2425, 1ULL, 1);
    V v_t_2427 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_240), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2428 = heff_tr(heff_call(v_f_2426, 1, (V[]){v_t_2427}));
    break;
  }
  default: heff_nomatch(v_t_2425);
  }
  V f_ = v_c_2428;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1, 1, 3, (V[]){v_n_241, v_g_240, v_x_2424});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}