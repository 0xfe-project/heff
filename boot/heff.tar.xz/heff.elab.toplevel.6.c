// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_BDelayedBy 11524
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CBind 55652
#define TAG_CEmpty 30359
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_HGlobal 55847
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_MkAbs 54862
#define TAG_MkAlt 55173
#define TAG_MkChk 56962
#define TAG_MkSt 48854
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_Nom 25944
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SIsTy 43896
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SRecord 16932
#define TAG_SSum 9005
#define TAG_SU 9427
#define TAG_SpId 35501
#define TAG_TInf 28962
#define TAG_Throw 56084
#define TAG_VOpaque 37311
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_diags 296935042
#define LBL_elabFor 712452832
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_globals 352931696
#define LBL_head 9693863
#define LBL_hidden 729654485
#define LBL_implicit 319715269
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_level 304224158
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_order 307364712
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_tests 311609915
#define LBL_tm 10464
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_key__module[] = {LBL_key, LBL_module};
static uint32_t shape_len__names__locals__ctx[] = {LBL_len, LBL_names, LBL_locals, LBL_ctx};
static uint32_t shape_name__ty__tm__prim[] = {LBL_name, LBL_ty, LBL_tm, LBL_prim};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eenvironment_2eemptyScope_get(void);
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2erules_2eabandonChk(V);
V g_heff_2eelab_2erules_2eabandonChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eabandonChk_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
HeffT1 g_heff_2eelab_2erules_2eautoRec_24cpr(V, V, V);
V g_heff_2eelab_2erules_2ebindingSyn(V, V);
V g_heff_2eelab_2erules_2ebindingSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ebindingSyn_clo;
V g_heff_2eelab_2erules_2ecaseLet(V, V, V);
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseLet_clo;
V g_heff_2eelab_2erules_2efunctionIntro(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntro_clo;
V g_heff_2eelab_2erules_2efunctionIntroAnn(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroAnn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroAnn_clo;
V g_heff_2eelab_2erules_2efunctionIntroImplicit(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroImplicit_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroImplicit_clo;
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2erules_2elazyChk(V, V, V);
V g_heff_2eelab_2erules_2elazyChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elazyChk_clo;
V g_heff_2eelab_2erules_2ementionsLocal(V);
V g_heff_2eelab_2erules_2ementionsLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsLocal_clo;
V g_heff_2eelab_2erules_2erecordIntro(V, V);
V g_heff_2eelab_2erules_2erecordIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordIntro_clo;
V g_heff_2eelab_2erules_2etagChk(V, V, V, V, V);
V g_heff_2eelab_2erules_2etagChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagChk_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744(V);
V g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744_clo;
V g_heff_2eelab_2etoplevel_2ebasicPrimNames_get(void);
V g_heff_2eelab_2etoplevel_2ebodyEnv(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyEnv_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyEnv_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
HeffT1 g_heff_2eelab_2etoplevel_2echkHeadOf_24cpr(V, V);
V g_heff_2eelab_2etoplevel_2edeclJ(V);
V g_heff_2eelab_2etoplevel_2edeclJ_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edeclJ_clo;
V g_heff_2eelab_2etoplevel_2edefineD(V, V, V, V);
V g_heff_2eelab_2etoplevel_2edefineD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edefineD_clo;
V g_heff_2eelab_2etoplevel_2edoPat(V);
V g_heff_2eelab_2etoplevel_2edoPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edoPat_clo;
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_clo;
V g_heff_2eelab_2etoplevel_2eelabWatch(V, V);
V g_heff_2eelab_2etoplevel_2eelabWatch_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabWatch_clo;
V g_heff_2eelab_2etoplevel_2eequationsD(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eequationsD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eequationsD_clo;
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eeveryImplicitIn_clo;
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(V, V);
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_clo;
V g_heff_2eelab_2etoplevel_2ehasOpPat(V);
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036(V, V, V);
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_clo;
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009(V, V);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_clo;
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(V, V);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_clo;
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2enubInt_24dps(V, V);
V g_heff_2eelab_2etoplevel_2enubInt_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_24dps_clo;
V g_heff_2eelab_2etoplevel_2eonceEach(V, V);
V g_heff_2eelab_2etoplevel_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eonceEach_clo;
V g_heff_2eelab_2etoplevel_2eopPat(V, V);
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eopPat_clo;
V g_heff_2eelab_2etoplevel_2epairOfHoles(V);
V g_heff_2eelab_2etoplevel_2epairOfHoles_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epairOfHoles_clo;
HeffT2 g_heff_2eelab_2etoplevel_2eparamsOf_24cpr(V, V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown(V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo;
V g_heff_2eelab_2etoplevel_2eprimNames_get(void);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2esearchedInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2esearchedInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2esearchedInstance_clo;
V g_heff_2eelab_2etoplevel_2etheoryD(V, V, V);
V g_heff_2eelab_2etoplevel_2etheoryD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etheoryD_clo;
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo;
V g_heff_2eelab_2etoplevel_2etupleFront(V, V);
V g_heff_2eelab_2etoplevel_2etupleFront_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleFront_clo;
V g_heff_2eelab_2etoplevel_2etupleValueRev(V, V);
V g_heff_2eelab_2etoplevel_2etupleValueRev_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleValueRev_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2ewatchPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchPhase_clo;
V g_heff_2eelab_2etoplevel_2ewatchSyn(V);
V g_heff_2eelab_2etoplevel_2ewatchSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchSyn_clo;
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720(V, V);
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_clo;
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(V, V, V);
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2einfSpineOf(V);
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2esurfaceprint_2eunIsTy(V);
V g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eunIsTy_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1868716698x184030185(V, V);
V g_list_2eany_24s1868716698x184030185_entry(V self, V *a);
extern Clo g_list_2eany_24s1868716698x184030185_clo;
V g_list_2eany_24s992013231x1460818112(V, V);
V g_list_2eany_24s992013231x1460818112_entry(V self, V *a);
extern Clo g_list_2eany_24s992013231x1460818112_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s193123870x387721583(V, V);
V g_list_2ekeepIf_24s193123870x387721583_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s193123870x387721583_clo;
V g_list_2ekeepIf_24s522699319x1190492156(V, V);
V g_list_2ekeepIf_24s522699319x1190492156_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s522699319x1190492156_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s1157078602x1175067503(V, V, V);
V g_prelude_2etraverse_24s1157078602x1175067503_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1157078602x1175067503_clo;
V g_prelude_2etraverse_24s1797919465x75214466(V);
V g_prelude_2etraverse_24s1797919465x75214466_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1797919465x75214466_clo;
V g_prelude_2etraverse_24s189232456x1797852535(V);
V g_prelude_2etraverse_24s189232456x1797852535_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s189232456x1797852535_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2emap_2edelete_24s1614046289x1611773644(V, V);
V g_std_2emap_2edelete_24s1614046289x1611773644_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s1614046289x1611773644_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str2, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str3, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str4, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str5, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str6, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str7, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str8, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str9, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str10, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edoPat_str11, 75, "a `case` pattern is a pattern: a tag applied to patterns, a literal, or `_`");
V g_heff_2eelab_2etoplevel_2edoPat_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2edoPat_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoPat_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2edoPat_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoPat_lam12(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edoPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoPat_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2edoPat(V v_p_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(heff_dup(v_p_240)));
  V v_t_242 = heff_get_n(v_t_241, 0, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_At: {
    V v_it1_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_PatVar: {
      V v_it11_245 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 1);
      if (heff_strEq_c(v_it11_245, ((V)&g_heff_2eelab_2etoplevel_2edoPat_str0))) {
        heff_drop(v_p_240);
        return ((V)&g_heff_2eelab_2etoplevel_2edoPat_lam0_clo);
      } else {
        return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam1, 2, 1, (V[]){v_p_240});
      }
    }
    case TAG_PatTag: {
      V v_x_2419 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 3);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam2, 2, 2, (V[]){v_p_240, v_x_2419});
    }
    case TAG_PatOp: {
      heff_take_n(v_it1_243, 0ULL, 3);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam4, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatInt: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam5, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatFloat: {
      heff_take_na(v_it1_243, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam6, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatString: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam7, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatBinary: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam8, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatRune: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam9, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatRecord: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam10, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatWord: {
      heff_take_n(v_it1_243, 0ULL, 1);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam11, 2, 1, (V[]){v_p_240});
    }
    case TAG_PatAs: {
      heff_take_n(v_it1_243, 0ULL, 3);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam12, 2, 1, (V[]){v_p_240});
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2etoplevel_2edoPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2edoPat(a[0]);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  heff_drop(v_hd_247);
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2eelab_2etoplevel_2edoPat_str1), NTAG(TAG_Nil)});
  V f_ = v_k_248;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k2_2411 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_2413 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_2414 = v_s_2413;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str2), v_t_2414, NTAG(TAG_Nothing)});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_2410, 2), 1, (V[]){v_t_2417}));
  V f_ = heff_get_n(v_hd_2410, 1, 3);
  args[0] = v_t_2418;
  args[1] = v_k2_2411;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_2423 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_p_240 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(v_p_240));
  return (g_prelude_2etraverse_24s1157078602x1175067503(heff_get_n(v_t_2424, 1, 2), v_hd_2422, heff_clo_n(g_heff_2eelab_2etoplevel_2edoPat_lam3, 1, 2, (V[]){v_k_2423, v_x_2419})));
}
V g_heff_2eelab_2etoplevel_2edoPat_lam4(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k2_2430 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_2432 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_2433 = v_s_2432;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str3), v_t_2433, NTAG(TAG_Nothing)});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_call(heff_take_field(v_hd_2429, 2), 1, (V[]){v_t_2436}));
  V f_ = heff_get_n(v_hd_2429, 1, 3);
  args[0] = v_t_2437;
  args[1] = v_k2_2430;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam5(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k2_2440 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2443;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_2442 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_2443 = v_s_2442;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2444 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str4), v_t_2443, NTAG(TAG_Nothing)});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tr(heff_call(heff_take_field(v_hd_2439, 2), 1, (V[]){v_t_2446}));
  V f_ = heff_get_n(v_hd_2439, 1, 3);
  args[0] = v_t_2447;
  args[1] = v_k2_2440;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam6(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k2_2450 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2453;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_2452 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_2453 = v_s_2452;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2454 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str5), v_t_2453, NTAG(TAG_Nothing)});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tr(heff_call(heff_take_field(v_hd_2449, 2), 1, (V[]){v_t_2456}));
  V f_ = heff_get_n(v_hd_2449, 1, 3);
  args[0] = v_t_2457;
  args[1] = v_k2_2450;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam7(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k2_2460 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2463;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_2462 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_2463 = v_s_2462;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2464 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str6), v_t_2463, NTAG(TAG_Nothing)});
  V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tr(heff_call(heff_take_field(v_hd_2459, 2), 1, (V[]){v_t_2466}));
  V f_ = heff_get_n(v_hd_2459, 1, 3);
  args[0] = v_t_2467;
  args[1] = v_k2_2460;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam8(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k2_2470 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2473;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_2472 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_2473 = v_s_2472;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2474 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str7), v_t_2473, NTAG(TAG_Nothing)});
  V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tr(heff_call(heff_take_field(v_hd_2469, 2), 1, (V[]){v_t_2476}));
  V f_ = heff_get_n(v_hd_2469, 1, 3);
  args[0] = v_t_2477;
  args[1] = v_k2_2470;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam9(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k2_2480 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2483;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_2482 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_2483 = v_s_2482;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2484 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str8), v_t_2483, NTAG(TAG_Nothing)});
  V v_t_2485 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tr(heff_call(heff_take_field(v_hd_2479, 2), 1, (V[]){v_t_2486}));
  V f_ = heff_get_n(v_hd_2479, 1, 3);
  args[0] = v_t_2487;
  args[1] = v_k2_2480;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam10(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k2_2490 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2493;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_2492 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_2493 = v_s_2492;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2494 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str9), v_t_2493, NTAG(TAG_Nothing)});
  V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tr(heff_call(heff_take_field(v_hd_2489, 2), 1, (V[]){v_t_2496}));
  V f_ = heff_get_n(v_hd_2489, 1, 3);
  args[0] = v_t_2497;
  args[1] = v_k2_2490;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam11(V self, V *args) {
  V v_hd_2499 = args[0];
  V v_k2_24100 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24103;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_24102 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_24103 = v_s_24102;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_24104 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str10), v_t_24103, NTAG(TAG_Nothing)});
  V v_t_24105 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tr(heff_call(heff_take_field(v_hd_2499, 2), 1, (V[]){v_t_24106}));
  V f_ = heff_get_n(v_hd_2499, 1, 3);
  args[0] = v_t_24107;
  args[1] = v_k2_24100;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edoPat_lam12(V self, V *args) {
  V v_hd_24111 = args[0];
  V v_k2_24112 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24115;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_s_24114 = heff_field(v_p_240, 1);
    heff_take_n(v_p_240, 2ULL, 2);
    v_t_24115 = v_s_24114;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_24116 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edoPat_str11), v_t_24115, NTAG(TAG_Nothing)});
  V v_t_24117 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24116})});
  V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
  V v_t_24119 = heff_tr(heff_call(heff_take_field(v_hd_24111, 2), 1, (V[]){v_t_24118}));
  V f_ = heff_get_n(v_hd_24111, 1, 3);
  args[0] = v_t_24119;
  args[1] = v_k2_24112;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}

HeffT2 g_heff_2eelab_2etoplevel_2eparamsOf_24cpr(V v_i_240, V v_e_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SU: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SDecode: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SFunction: {
    V v_cod_247 = heff_field(v_x3_242, 2);
    V v_x34_248 = heff_field(v_x3_242, 3);
    heff_take_n(v_x3_242, 12ULL, 5);
    switch (heff_tag_of(v_x34_248)) {
    case TAG_Expl: {
      V v_t_2413;
      switch (heff_tag_of(v_cod_247)) {
      case TAG_MkAbs: {
        V v_t_2411 = heff_field(v_cod_247, 1);
        heff_take_n(v_cod_247, 2ULL, 2);
        v_t_2413 = v_t_2411;
        break;
      }
      case TAG_AbsConst: {
        V v_t_2412 = heff_field(v_cod_247, 0);
        heff_take_n(v_cod_247, 1ULL, 1);
        v_t_2413 = v_t_2412;
        break;
      }
      default: heff_nomatch(v_cod_247);
      }
      V t_0 = v_i_240;
      V t_1 = heff_intAdd(v_e_241, MK_INT(1LL));
      V t_2 = v_t_2413;
      v_i_240 = t_0;
      v_e_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Impl: {
      if (heff_intLt_c_lent(MK_INT(0LL), v_e_241, 1)) {
        heff_drop(v_i_240);
        heff_drop(v_e_241);
        heff_drop(v_cod_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V v_t_2418;
        switch (heff_tag_of(v_cod_247)) {
        case TAG_MkAbs: {
          V v_t_2416 = heff_field(v_cod_247, 1);
          heff_take_n(v_cod_247, 2ULL, 2);
          v_t_2418 = v_t_2416;
          break;
        }
        case TAG_AbsConst: {
          V v_t_2417 = heff_field(v_cod_247, 0);
          heff_take_n(v_cod_247, 1ULL, 1);
          v_t_2418 = v_t_2417;
          break;
        }
        default: heff_nomatch(v_cod_247);
        }
        V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
        V t_1 = v_e_241;
        V t_2 = v_t_2418;
        v_i_240 = t_0;
        v_e_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    case TAG_Inst: {
      heff_drop(v_i_240);
      heff_drop(v_e_241);
      heff_drop(v_cod_247);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x34_248)}});
    }
  }
  case TAG_SRecord: {
    heff_take_n(v_x3_242, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SSum: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SIsTy: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SPrimInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SPrimFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SPrimString: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SPrimRune: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SPrimArray: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  case TAG_SFixed: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_MkPair, 2, (V[]){v_i_240, v_e_241})}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2eelab_2etoplevel_2etupleFront_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etupleFront_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etupleFront(V v_sp_240, V v_rs_241) {
top: ;
  switch (heff_tag_of(v_rs_241)) {
  case TAG_Nil: {
    V v_i_2410;
    switch (heff_tag_of(v_rs_241)) {
    case TAG_Nil: {
      V v_t_242 = heff_tag_n(TAG_ITuple, 1, (V[]){NTAG(TAG_Nil)});
      v_i_2410 = heff_tag_n(TAG_At, 2, (V[]){v_t_242, v_sp_240});
      break;
    }
    case TAG_Cons: {
      V v_r_243 = heff_dup(heff_field(v_rs_241, 0));
      V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rs_241));
      V v_t_248;
      switch (heff_tag_of(v_r_243)) {
      case TAG_At: {
        V v_s_247 = heff_field(v_r_243, 1);
        heff_take_n(v_r_243, 2ULL, 2);
        v_t_248 = v_s_247;
        break;
      }
      default: heff_nomatch(v_r_243);
      }
      V v_t_249 = ({ V rv_1 = heff_get_n(v_t_248, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      v_i_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ITuple, 1, (V[]){v_t_245}), v_t_249});
      break;
    }
    default: heff_nomatch(v_rs_241);
    }
    V v_t_2413;
    switch (heff_tag_of(v_i_2410)) {
    case TAG_At: {
      V v_s_2412 = heff_dup(heff_field(v_i_2410, 1));
      v_t_2413 = v_s_2412;
      break;
    }
    default: heff_nomatch(v_i_2410);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2410}), v_t_2413});
  }
  case TAG_Cons: {
    V v_a_2414 = heff_dup(heff_field(v_rs_241, 0));
    V v_rs2_2415 = heff_dup(heff_field(v_rs_241, 1));
    switch (heff_tag_of(v_rs2_2415)) {
    case TAG_Nil: {
      heff_drop_rec(v_sp_240, 2);
      heff_drop_tag(v_rs_241, 2);
      return v_a_2414;
    }
    case TAG_Cons: {
      V v_ru_24rs2_2415_24Cons = heff_take_reuse_n(v_rs2_2415, 0ULL, 2);
      heff_drop(v_a_2414);
      V v_i_2426;
      switch (heff_tag_of(v_rs_241)) {
      case TAG_Nil: {
        V v_t_2418 = heff_tag_n(TAG_ITuple, 1, (V[]){NTAG(TAG_Nil)});
        v_i_2426 = heff_tag_at_n(v_ru_24rs2_2415_24Cons, TAG_At, 2, (V[]){v_t_2418, v_sp_240});
        break;
      }
      case TAG_Cons: {
        V v_r_2419 = heff_dup(heff_field(v_rs_241, 0));
        V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rs_241));
        V v_t_2424;
        switch (heff_tag_of(v_r_2419)) {
        case TAG_At: {
          V v_s_2423 = heff_field(v_r_2419, 1);
          heff_take_n(v_r_2419, 2ULL, 2);
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_r_2419);
        }
        V v_t_2425 = ({ V rv_1 = heff_get_n(v_t_2424, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        v_i_2426 = heff_tag_at_n(v_ru_24rs2_2415_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_ITuple, 1, (V[]){v_t_2421}), v_t_2425});
        break;
      }
      default: heff_nomatch(v_rs_241);
      }
      V v_t_2429;
      switch (heff_tag_of(v_i_2426)) {
      case TAG_At: {
        V v_s_2428 = heff_dup(heff_field(v_i_2426, 1));
        v_t_2429 = v_s_2428;
        break;
      }
      default: heff_nomatch(v_i_2426);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2426}), v_t_2429});
    }
    default: return heff_nomatch(v_rs2_2415);
    }
  }
  default: return heff_nomatch(v_rs_241);
  }
}
V g_heff_2eelab_2etoplevel_2etupleFront_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etupleFront(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleValueRev_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleValueRev_str1, 12, "builtin.Unit");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleValueRev_str2, 6, "MkPair");
Clo g_heff_2eelab_2etoplevel_2etupleValueRev_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etupleValueRev_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etupleValueRev(V v_sp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_242 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleValueRev_str0), heff_dup(v_sp_240), NTAG(TAG_Nil)});
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleValueRev_str1)}), heff_dup(v_sp_240)});
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_t_243}), heff_dup(v_sp_240)});
    V v_t_245 = heff_tag_n(TAG_IAnn, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_242, heff_dup(v_sp_240)}), v_t_244});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_240});
  }
  case TAG_Cons: {
    V v_z_246 = heff_field(v_x2_241, 0);
    V v_rs_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = (g_heff_2eelab_2etoplevel_2etupleFront(heff_dup(v_sp_240), v_rs_247));
    V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_z_246, NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2etoplevel_2etupleValueRev_str2), heff_dup(v_sp_240), heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_249})});
    V v_t_2411 = (g_heff_2eelab_2etoplevel_2epairOfHoles(heff_dup(v_sp_240)));
    V v_t_2412 = heff_tag_n(TAG_IAnn, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_240)}), v_t_2411});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_sp_240});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2etupleValueRev_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etupleValueRev(a[0], a[1]);
}

HeffT1 g_heff_2eelab_2etoplevel_2echkHeadOf_24cpr(V v_n_240, V v_j_241) {
top: ;
  V v_t_2435;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_242 = heff_dup(heff_field(v_n_240, 0));
    switch (heff_tag_of(v_x11_242)) {
    case TAG_IVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    case TAG_IInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    case TAG_IFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    case TAG_IString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    case TAG_IBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    case TAG_IPrim: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_x11_242, 0ULL, 2);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_x11_242, 0ULL, 2);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_x11_242, 0ULL, 4);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    case TAG_IUpdate: {
      heff_take_n(v_x11_242, 0ULL, 2);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_x11_242, 0ULL, 4);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_x11_242, 0ULL, 3);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    case TAG_INominal: {
      V v_i_2428 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      v_t_2435 = v_i_2428;
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_x11_242, 0ULL, 4);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    case TAG_ILazy: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    case TAG_ITuple: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2435 = heff_dup(v_n_240);
      break;
    }
    default: heff_nomatch(v_x11_242);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_t_2436 = (g_heff_2esyntax_2epresyntax_2einfSpineOf(v_t_2435));
  V v_t_2437 = heff_get_n(v_t_2436, 0, 2);
  switch (heff_tag_of(v_t_2437)) {
  case TAG_At: {
    V v_it1_2438 = heff_field(v_t_2437, 0);
    heff_take_n(v_t_2437, 1ULL, 2);
    switch (heff_tag_of(v_it1_2438)) {
    case TAG_IVar: {
      V v_x_2440 = heff_field(v_it1_2438, 0);
      heff_take_n(v_it1_2438, 1ULL, 1);
      V v_t_2443;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2442 = heff_dup(heff_field(v_n_240, 1));
        v_t_2443 = v_s_2442;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      V v_t_2446;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2445 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2446 = v_s_2445;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      V v_t_2447 = (g_heff_2eelab_2erules_2eapply(v_t_2446, v_j_241));
      return ({ V a_0 = v_t_2443; V a_1 = v_x_2440; V a_2 = v_t_2447; HeffT1 r_ = (g_heff_2eelab_2erules_2eautoRec_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2440); r_; });
    }
    case TAG_IInt: {
      heff_take_n(v_it1_2438, 0ULL, 1);
      V v_t_2451;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2450 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2451 = v_s_2450;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2451, v_j_241);
    }
    case TAG_IFloat: {
      heff_take_na(v_it1_2438, 0ULL, 1);
      V v_t_2455;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2454 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2455 = v_s_2454;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2455, v_j_241);
    }
    case TAG_IString: {
      heff_take_n(v_it1_2438, 0ULL, 1);
      V v_t_2459;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2458 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2459 = v_s_2458;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2459, v_j_241);
    }
    case TAG_IBytes: {
      heff_take_n(v_it1_2438, 0ULL, 1);
      V v_t_2463;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2462 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2463 = v_s_2462;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2463, v_j_241);
    }
    case TAG_IPrim: {
      heff_take_n(v_it1_2438, 0ULL, 1);
      V v_t_2467;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2466 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2467 = v_s_2466;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2467, v_j_241);
    }
    case TAG_IRune: {
      heff_take_n(v_it1_2438, 0ULL, 1);
      V v_t_2471;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2470 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2471 = v_s_2470;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2471, v_j_241);
    }
    case TAG_IApp: {
      heff_take_n(v_it1_2438, 0ULL, 2);
      V v_t_2476;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2475 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2476 = v_s_2475;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2476, v_j_241);
    }
    case TAG_IAnn: {
      heff_take_n(v_it1_2438, 0ULL, 2);
      V v_t_2481;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2480 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2481 = v_s_2480;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2481, v_j_241);
    }
    case TAG_ISpec: {
      heff_take_n(v_it1_2438, 0ULL, 4);
      V v_t_2488;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2487 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2488 = v_s_2487;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2488, v_j_241);
    }
    case TAG_IUpdate: {
      heff_take_n(v_it1_2438, 0ULL, 2);
      V v_t_2493;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2492 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_2493 = v_s_2492;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_2493, v_j_241);
    }
    case TAG_IAnnLam: {
      heff_take_n(v_it1_2438, 0ULL, 4);
      V v_t_24100;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_2499 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_24100 = v_s_2499;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_24100, v_j_241);
    }
    case TAG_IInvalid: {
      heff_take_n(v_it1_2438, 0ULL, 3);
      V v_t_24106;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_24105 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_24106 = v_s_24105;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_24106, v_j_241);
    }
    case TAG_INominal: {
      heff_take_n(v_it1_2438, 0ULL, 1);
      V v_t_24110;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_24109 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_24110 = v_s_24109;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_24110, v_j_241);
    }
    case TAG_ILitEq: {
      heff_take_n(v_it1_2438, 0ULL, 4);
      V v_t_24117;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_24116 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_24117 = v_s_24116;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_24117, v_j_241);
    }
    case TAG_ILazy: {
      heff_take_n(v_it1_2438, 0ULL, 1);
      V v_t_24121;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_24120 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_24121 = v_s_24120;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_24121, v_j_241);
    }
    case TAG_ITuple: {
      heff_take_n(v_it1_2438, 0ULL, 1);
      V v_t_24125;
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_s_24124 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        v_t_24125 = v_s_24124;
        break;
      }
      default: heff_nomatch(v_n_240);
      }
      HEFF_LAST return g_heff_2eelab_2erules_2eapply_24cpr(v_t_24125, v_j_241);
    }
    default: return ((HeffT1){{heff_nomatch(v_it1_2438)}});
    }
  }
  default: return ((HeffT1){{heff_nomatch(v_t_2437)}});
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam32(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam35(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam34(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam33(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam39(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam38(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam42(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam41(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam40(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam37(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam36(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam46(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam45(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam49(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam48(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam47(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam44(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam43(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam53(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam52(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam56(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam55(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam54(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam51(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam50(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam60(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam59(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam63(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam62(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam61(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam58(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam57(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam67(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam66(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam70(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam69(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam68(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam65(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam64(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam74(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam73(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam77(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam76(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam75(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam72(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam71(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam81(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam80(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam84(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam83(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam82(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam79(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam78(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam88(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam87(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam91(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam90(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam89(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam86(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam85(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam92(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam94(V self, V *args);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam93(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_241 = heff_dup(heff_field(v_n_240, 0));
    V v_n2_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_n1_241)) {
    case TAG_CInf: {
      heff_take_n(v_n1_241, 0ULL, 1);
      heff_drop(v_n2_242);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_240);
    }
    case TAG_CType: {
      heff_take_n(v_n1_241, 0ULL, 1);
      heff_drop(v_n2_242);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_240);
    }
    case TAG_CLam: {
      V v_x_245 = heff_field(v_n1_241, 0);
      V v_body_247 = heff_field(v_n1_241, 2);
      heff_take_n(v_n1_241, 5ULL, 3);
      heff_drop(v_n2_242);
      V v_t_248 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_247));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0, 2, 3, (V[]){v_t_248, v_n_240, v_x_245});
    }
    case TAG_CImplicitLam: {
      V v_x_2416 = heff_field(v_n1_241, 0);
      V v_body_2418 = heff_field(v_n1_241, 2);
      heff_take_n(v_n1_241, 5ULL, 3);
      heff_drop(v_n2_242);
      V v_t_2419 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_2418));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2, 2, 3, (V[]){v_t_2419, v_n_240, v_x_2416});
    }
    case TAG_CAnnLam: {
      V v_x_2427 = heff_field(v_n1_241, 0);
      V v_tyN_2429 = heff_field(v_n1_241, 2);
      V v_body_2430 = heff_field(v_n1_241, 3);
      heff_take_n(v_n1_241, 13ULL, 4);
      heff_drop(v_n2_242);
      V v_c_2431 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_tyN_2429));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4, 2, 4, (V[]){v_c_2431, v_body_2430, v_n_240, v_x_2427});
    }
    case TAG_CTag: {
      V v_x_2441 = heff_field(v_n1_241, 0);
      V v_tsp_2442 = heff_field(v_n1_241, 1);
      V v_args_2443 = heff_field(v_n1_241, 2);
      heff_take_n(v_n1_241, 7ULL, 3);
      heff_drop(v_n2_242);
      V v_c_2444 = (g_prelude_2etraverse_24s189232456x1797852535(v_args_2443));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7, 2, 4, (V[]){v_c_2444, v_n_240, v_tsp_2442, v_x_2441});
    }
    case TAG_CStruct: {
      V v_fields_2452 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      V v_c_2453 = (g_prelude_2etraverse_24s1797919465x75214466(v_fields_2452));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9, 2, 2, (V[]){v_c_2453, v_n2_242});
    }
    case TAG_CMatch: {
      V v_scrutN_2458 = heff_field(v_n1_241, 0);
      V v_casesN_2459 = heff_field(v_n1_241, 1);
      heff_take_n(v_n1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      V v_x1_2460 = (g_heff_2eelab_2etoplevel_2eallL_24s450303745x1665808744(v_casesN_2459));
      if ((heff_dup(v_x1_2460) == NTAG(TAG_True))) {
        heff_drop(v_x1_2460);
        return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_242, NTAG(TAG_Nothing), v_scrutN_2458, v_casesN_2459));
      } else {
        heff_drop(v_x1_2460);
        return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11, 2, 3, (V[]){v_casesN_2459, v_scrutN_2458, v_n2_242});
      }
    }
    case TAG_CLetIn: {
      V v_rhsN_2483 = heff_field(v_n1_241, 0);
      V v_alt0_2484 = heff_field(v_n1_241, 1);
      V v_ru_24n1_241_24CLetIn = heff_take_reuse_n(v_n1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      switch (heff_tag_of(v_alt0_2484)) {
      case TAG_At: {
        V v_it1_2485 = heff_dup(heff_field(v_alt0_2484, 0));
        switch (heff_tag_of(v_it1_2485)) {
        case TAG_MkAlt: {
          V v_it11_2487 = heff_field(v_it1_2485, 0);
          V v_bodyN_2488 = heff_field(v_it1_2485, 1);
          heff_take_n(v_it1_2485, 3ULL, 2);
          switch (heff_tag_of(v_it11_2487)) {
          case TAG_At: {
            V v_it111_2489 = heff_dup(heff_field(v_it11_2487, 0));
            switch (heff_tag_of(v_it111_2489)) {
            case TAG_PatVar: {
              V v_x_2491 = heff_field(v_it111_2489, 0);
              heff_take_n(v_it111_2489, 1ULL, 1);
              heff_drop(v_n2_242);
              heff_drop_tag(v_alt0_2484, 2);
              heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
              heff_drop_tag(v_it11_2487, 2);
              V v_c_2492 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_rhsN_2483));
              return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19, 2, 3, (V[]){v_c_2492, v_bodyN_2488, v_x_2491});
            }
            case TAG_PatTag: {
              heff_take_n(v_it111_2489, 0ULL, 3);
              heff_drop(v_bodyN_2488);
              V v_t_24106;
              switch (heff_tag_of(v_alt0_2484)) {
              case TAG_At: {
                V v_x11_24102 = heff_dup(heff_field(v_alt0_2484, 0));
                switch (heff_tag_of(v_x11_24102)) {
                case TAG_MkAlt: {
                  V v_p_24104 = heff_field(v_x11_24102, 0);
                  heff_take_n(v_x11_24102, 1ULL, 2);
                  v_t_24106 = ({ V a_0 = v_p_24104; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24104); r_; });
                  break;
                }
                default: heff_nomatch(v_x11_24102);
                }
                break;
              }
              default: heff_nomatch(v_alt0_2484);
              }
              if ((heff_dup(v_t_24106) == NTAG(TAG_True))) {
                heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                heff_drop_tag(v_it11_2487, 2);
                heff_drop(v_t_24106);
                return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242});
              } else {
                heff_drop(v_t_24106);
                V v_t_24128 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2487}));
                V v_t_24129 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2484, NTAG(TAG_Nil)});
                return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_242, heff_tag_n(TAG_Just, 1, (V[]){v_t_24128}), v_rhsN_2483, v_t_24129));
              }
            }
            case TAG_PatOp: {
              heff_take_n(v_it111_2489, 0ULL, 3);
              heff_drop(v_bodyN_2488);
              V v_t_24137;
              switch (heff_tag_of(v_alt0_2484)) {
              case TAG_At: {
                V v_x11_24133 = heff_dup(heff_field(v_alt0_2484, 0));
                switch (heff_tag_of(v_x11_24133)) {
                case TAG_MkAlt: {
                  V v_p_24135 = heff_field(v_x11_24133, 0);
                  heff_take_n(v_x11_24133, 1ULL, 2);
                  v_t_24137 = ({ V a_0 = v_p_24135; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24135); r_; });
                  break;
                }
                default: heff_nomatch(v_x11_24133);
                }
                break;
              }
              default: heff_nomatch(v_alt0_2484);
              }
              if ((heff_dup(v_t_24137) == NTAG(TAG_True))) {
                heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                heff_drop_tag(v_it11_2487, 2);
                heff_drop(v_t_24137);
                return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242});
              } else {
                heff_drop(v_t_24137);
                V v_t_24159 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2487}));
                V v_t_24160 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2484, NTAG(TAG_Nil)});
                return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_242, heff_tag_n(TAG_Just, 1, (V[]){v_t_24159}), v_rhsN_2483, v_t_24160));
              }
            }
            case TAG_PatInt: {
              V v_ru_24it111_2489_24PatInt = heff_take_reuse_n(v_it111_2489, 0ULL, 1);
              heff_drop(v_bodyN_2488);
              V v_t_24166;
              switch (heff_tag_of(v_alt0_2484)) {
              case TAG_At: {
                V v_x11_24162 = heff_dup(heff_field(v_alt0_2484, 0));
                switch (heff_tag_of(v_x11_24162)) {
                case TAG_MkAlt: {
                  V v_p_24164 = heff_field(v_x11_24162, 0);
                  heff_take_n(v_x11_24162, 1ULL, 2);
                  v_t_24166 = ({ V a_0 = v_p_24164; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24164); r_; });
                  break;
                }
                default: heff_nomatch(v_x11_24162);
                }
                break;
              }
              default: heff_nomatch(v_alt0_2484);
              }
              if ((heff_dup(v_t_24166) == NTAG(TAG_True))) {
                heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                heff_drop_tag(v_it11_2487, 2);
                heff_drop_cell(v_ru_24it111_2489_24PatInt, 1);
                heff_drop(v_t_24166);
                return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam36, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242});
              } else {
                heff_drop(v_t_24166);
                V v_t_24188 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2487}));
                V v_t_24189 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2484, NTAG(TAG_Nil)});
                return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_242, heff_tag_at_n(v_ru_24it111_2489_24PatInt, TAG_Just, 1, (V[]){v_t_24188}), v_rhsN_2483, v_t_24189));
              }
            }
            case TAG_PatFloat: {
              V v_ru_24it111_2489_24PatFloat = heff_take_reuse_na(v_it111_2489, 0ULL, 1);
              heff_drop(v_bodyN_2488);
              V v_t_24195;
              switch (heff_tag_of(v_alt0_2484)) {
              case TAG_At: {
                V v_x11_24191 = heff_dup(heff_field(v_alt0_2484, 0));
                switch (heff_tag_of(v_x11_24191)) {
                case TAG_MkAlt: {
                  V v_p_24193 = heff_field(v_x11_24191, 0);
                  heff_take_n(v_x11_24191, 1ULL, 2);
                  v_t_24195 = ({ V a_0 = v_p_24193; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24193); r_; });
                  break;
                }
                default: heff_nomatch(v_x11_24191);
                }
                break;
              }
              default: heff_nomatch(v_alt0_2484);
              }
              if ((heff_dup(v_t_24195) == NTAG(TAG_True))) {
                heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                heff_drop_tag(v_it11_2487, 2);
                heff_drop_cell(v_ru_24it111_2489_24PatFloat, 1);
                heff_drop(v_t_24195);
                return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam43, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242});
              } else {
                heff_drop(v_t_24195);
                V v_t_24217 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2487}));
                V v_t_24218 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2484, NTAG(TAG_Nil)});
                return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_242, heff_tag_at_n(v_ru_24it111_2489_24PatFloat, TAG_Just, 1, (V[]){v_t_24217}), v_rhsN_2483, v_t_24218));
              }
            }
            case TAG_PatString: {
              V v_ru_24it111_2489_24PatString = heff_take_reuse_n(v_it111_2489, 0ULL, 1);
              heff_drop(v_bodyN_2488);
              V v_t_24224;
              switch (heff_tag_of(v_alt0_2484)) {
              case TAG_At: {
                V v_x11_24220 = heff_dup(heff_field(v_alt0_2484, 0));
                switch (heff_tag_of(v_x11_24220)) {
                case TAG_MkAlt: {
                  V v_p_24222 = heff_field(v_x11_24220, 0);
                  heff_take_n(v_x11_24220, 1ULL, 2);
                  v_t_24224 = ({ V a_0 = v_p_24222; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24222); r_; });
                  break;
                }
                default: heff_nomatch(v_x11_24220);
                }
                break;
              }
              default: heff_nomatch(v_alt0_2484);
              }
              if ((heff_dup(v_t_24224) == NTAG(TAG_True))) {
                heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                heff_drop_tag(v_it11_2487, 2);
                heff_drop_cell(v_ru_24it111_2489_24PatString, 1);
                heff_drop(v_t_24224);
                return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam50, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242});
              } else {
                heff_drop(v_t_24224);
                V v_t_24246 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2487}));
                V v_t_24247 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2484, NTAG(TAG_Nil)});
                return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_242, heff_tag_at_n(v_ru_24it111_2489_24PatString, TAG_Just, 1, (V[]){v_t_24246}), v_rhsN_2483, v_t_24247));
              }
            }
            case TAG_PatBinary: {
              V v_ru_24it111_2489_24PatBinary = heff_take_reuse_n(v_it111_2489, 0ULL, 1);
              heff_drop(v_bodyN_2488);
              V v_t_24253;
              switch (heff_tag_of(v_alt0_2484)) {
              case TAG_At: {
                V v_x11_24249 = heff_dup(heff_field(v_alt0_2484, 0));
                switch (heff_tag_of(v_x11_24249)) {
                case TAG_MkAlt: {
                  V v_p_24251 = heff_field(v_x11_24249, 0);
                  heff_take_n(v_x11_24249, 1ULL, 2);
                  v_t_24253 = ({ V a_0 = v_p_24251; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24251); r_; });
                  break;
                }
                default: heff_nomatch(v_x11_24249);
                }
                break;
              }
              default: heff_nomatch(v_alt0_2484);
              }
              if ((heff_dup(v_t_24253) == NTAG(TAG_True))) {
                heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                heff_drop_tag(v_it11_2487, 2);
                heff_drop_cell(v_ru_24it111_2489_24PatBinary, 1);
                heff_drop(v_t_24253);
                return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam57, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242});
              } else {
                heff_drop(v_t_24253);
                V v_t_24275 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2487}));
                V v_t_24276 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2484, NTAG(TAG_Nil)});
                return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_242, heff_tag_at_n(v_ru_24it111_2489_24PatBinary, TAG_Just, 1, (V[]){v_t_24275}), v_rhsN_2483, v_t_24276));
              }
            }
            case TAG_PatRune: {
              V v_ru_24it111_2489_24PatRune = heff_take_reuse_n(v_it111_2489, 0ULL, 1);
              heff_drop(v_bodyN_2488);
              V v_t_24282;
              switch (heff_tag_of(v_alt0_2484)) {
              case TAG_At: {
                V v_x11_24278 = heff_dup(heff_field(v_alt0_2484, 0));
                switch (heff_tag_of(v_x11_24278)) {
                case TAG_MkAlt: {
                  V v_p_24280 = heff_field(v_x11_24278, 0);
                  heff_take_n(v_x11_24278, 1ULL, 2);
                  v_t_24282 = ({ V a_0 = v_p_24280; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24280); r_; });
                  break;
                }
                default: heff_nomatch(v_x11_24278);
                }
                break;
              }
              default: heff_nomatch(v_alt0_2484);
              }
              if ((heff_dup(v_t_24282) == NTAG(TAG_True))) {
                heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                heff_drop_tag(v_it11_2487, 2);
                heff_drop_cell(v_ru_24it111_2489_24PatRune, 1);
                heff_drop(v_t_24282);
                return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam64, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242});
              } else {
                heff_drop(v_t_24282);
                V v_t_24304 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2487}));
                V v_t_24305 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2484, NTAG(TAG_Nil)});
                return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_242, heff_tag_at_n(v_ru_24it111_2489_24PatRune, TAG_Just, 1, (V[]){v_t_24304}), v_rhsN_2483, v_t_24305));
              }
            }
            case TAG_PatRecord: {
              V v_ru_24it111_2489_24PatRecord = heff_take_reuse_n(v_it111_2489, 0ULL, 1);
              heff_drop(v_bodyN_2488);
              V v_t_24311;
              switch (heff_tag_of(v_alt0_2484)) {
              case TAG_At: {
                V v_x11_24307 = heff_dup(heff_field(v_alt0_2484, 0));
                switch (heff_tag_of(v_x11_24307)) {
                case TAG_MkAlt: {
                  V v_p_24309 = heff_field(v_x11_24307, 0);
                  heff_take_n(v_x11_24307, 1ULL, 2);
                  v_t_24311 = ({ V a_0 = v_p_24309; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24309); r_; });
                  break;
                }
                default: heff_nomatch(v_x11_24307);
                }
                break;
              }
              default: heff_nomatch(v_alt0_2484);
              }
              if ((heff_dup(v_t_24311) == NTAG(TAG_True))) {
                heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                heff_drop_tag(v_it11_2487, 2);
                heff_drop_cell(v_ru_24it111_2489_24PatRecord, 1);
                heff_drop(v_t_24311);
                return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam71, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242});
              } else {
                heff_drop(v_t_24311);
                V v_t_24333 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2487}));
                V v_t_24334 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2484, NTAG(TAG_Nil)});
                return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_242, heff_tag_at_n(v_ru_24it111_2489_24PatRecord, TAG_Just, 1, (V[]){v_t_24333}), v_rhsN_2483, v_t_24334));
              }
            }
            case TAG_PatWord: {
              V v_ru_24it111_2489_24PatWord = heff_take_reuse_n(v_it111_2489, 0ULL, 1);
              heff_drop(v_bodyN_2488);
              V v_t_24340;
              switch (heff_tag_of(v_alt0_2484)) {
              case TAG_At: {
                V v_x11_24336 = heff_dup(heff_field(v_alt0_2484, 0));
                switch (heff_tag_of(v_x11_24336)) {
                case TAG_MkAlt: {
                  V v_p_24338 = heff_field(v_x11_24336, 0);
                  heff_take_n(v_x11_24336, 1ULL, 2);
                  v_t_24340 = ({ V a_0 = v_p_24338; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24338); r_; });
                  break;
                }
                default: heff_nomatch(v_x11_24336);
                }
                break;
              }
              default: heff_nomatch(v_alt0_2484);
              }
              if ((heff_dup(v_t_24340) == NTAG(TAG_True))) {
                heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                heff_drop_tag(v_it11_2487, 2);
                heff_drop_cell(v_ru_24it111_2489_24PatWord, 1);
                heff_drop(v_t_24340);
                return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam78, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242});
              } else {
                heff_drop(v_t_24340);
                V v_t_24362 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2487}));
                V v_t_24363 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2484, NTAG(TAG_Nil)});
                return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_242, heff_tag_at_n(v_ru_24it111_2489_24PatWord, TAG_Just, 1, (V[]){v_t_24362}), v_rhsN_2483, v_t_24363));
              }
            }
            case TAG_PatAs: {
              heff_take_n(v_it111_2489, 0ULL, 3);
              heff_drop(v_bodyN_2488);
              V v_t_24371;
              switch (heff_tag_of(v_alt0_2484)) {
              case TAG_At: {
                V v_x11_24367 = heff_dup(heff_field(v_alt0_2484, 0));
                switch (heff_tag_of(v_x11_24367)) {
                case TAG_MkAlt: {
                  V v_p_24369 = heff_field(v_x11_24367, 0);
                  heff_take_n(v_x11_24367, 1ULL, 2);
                  v_t_24371 = ({ V a_0 = v_p_24369; V r_ = (g_heff_2eelab_2etoplevel_2ehasOpPat(a_0)); heff_drop(v_p_24369); r_; });
                  break;
                }
                default: heff_nomatch(v_x11_24367);
                }
                break;
              }
              default: heff_nomatch(v_alt0_2484);
              }
              if ((heff_dup(v_t_24371) == NTAG(TAG_True))) {
                heff_drop_cell(v_ru_24n1_241_24CLetIn, 2);
                heff_drop_tag(v_it11_2487, 2);
                heff_drop(v_t_24371);
                return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam85, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242});
              } else {
                heff_drop(v_t_24371);
                V v_t_24393 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2ebindingSyn_clo), 1, (V[]){v_it11_2487}));
                V v_t_24394 = heff_tag_at_n(v_ru_24n1_241_24CLetIn, TAG_Cons, 2, (V[]){v_alt0_2484, NTAG(TAG_Nil)});
                return (g_heff_2eelab_2etoplevel_2ematchF_24s1406149430x1195460197(v_n2_242, heff_tag_n(TAG_Just, 1, (V[]){v_t_24393}), v_rhsN_2483, v_t_24394));
              }
            }
            default: return heff_nomatch(v_it111_2489);
            }
          }
          default: return heff_nomatch(v_it11_2487);
          }
        }
        default: return heff_nomatch(v_it1_2485);
        }
      }
      default: return heff_nomatch(v_alt0_2484);
      }
    }
    case TAG_CLocal: {
      V v_bodyN_24395 = heff_field(v_n1_241, 0);
      V v_defs_24396 = heff_field(v_n1_241, 1);
      heff_take_n(v_n1_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_n2_242);
      return ({ V a_0 = v_defs_24396; V a_1 = v_bodyN_24395; V r_ = (g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(a_0, a_1)); heff_drop(v_defs_24396); r_; });
    }
    case TAG_CAbandon: {
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam92, 2, 1, (V[]){v_n2_242});
    }
    case TAG_CNominal: {
      V v_c_24400 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_n2_242);
      V v_c_24401 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(v_c_24400));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam93, 2, 1, (V[]){v_c_24401});
    }
    default: return heff_nomatch(v_n1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(a[0]);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2413 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2414 = v_s_2413;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2415 = ({ V a_0 = v_t_2414; V a_1 = v_x_245; V a_2 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2efunctionIntro(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
  V f_ = v_k_2410;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_t_248 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_248, v_hd_249, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam1, 1, 3, (V[]){v_n_240, v_x_245, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2425;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2424 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2425 = v_s_2424;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_t_2426 = ({ V a_0 = v_t_2425; V a_1 = v_x_2416; V a_2 = v_x_2422; V r_ = (g_heff_2eelab_2erules_2efunctionIntroImplicit(a_0, a_1, a_2)); heff_drop(v_x_2422); r_; });
  V f_ = v_k_2421;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_t_2419 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2419, v_hd_2420, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam3, 1, 3, (V[]){v_n_240, v_x_2416, v_k_2421})));
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2427 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_k_2433 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2439;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2438 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2439 = v_s_2438;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2440 = ({ V a_0 = v_t_2439; V a_1 = v_x_2427; V a_2 = v_x_2434; V a_3 = v_x_2436; V r_ = (g_heff_2eelab_2erules_2efunctionIntroAnn(a_0, a_1, a_2, a_3)); heff_drop(v_x_2434); heff_drop(v_x_2436); r_; });
  V f_ = v_k_2433;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_body_2430 = heff_env(self)[0];
  V v_hd_2432 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  V v_k_2433 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2435 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_2430));
  V f_ = v_c_2435;
  heff_room[0] = v_hd_2432;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam6, 1, 4, (V[]){v_n_240, v_x_2427, v_x_2434, v_k_2433});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_c_2431 = heff_env(self)[0];
  V v_body_2430 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2431;
  args[0] = heff_dup(v_hd_2432);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam5, 1, 5, (V[]){v_body_2430, v_hd_2432, v_n_240, v_x_2427, v_k_2433});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8(V self, V *args) {
  V v_x_2447 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_tsp_2442 = heff_env(self)[1];
  V v_x_2441 = heff_env(self)[2];
  V v_k_2446 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2450;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2449 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2450 = v_s_2449;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2451 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_t_2450; V a_2 = v_tsp_2442; V a_3 = v_x_2441; V a_4 = v_x_2447; V r_ = (g_heff_2eelab_2erules_2etagChk(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V f_ = v_k_2446;
  args[0] = v_x_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam7(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  V v_c_2444 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  V v_tsp_2442 = heff_env(self)[2];
  V v_x_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2444;
  args[0] = v_hd_2445;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam8, 1, 4, (V[]){v_n_240, v_tsp_2442, v_x_2441, v_k_2446});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10(V self, V *args) {
  V v_x_2456 = args[0];
  V v_n2_242 = heff_env(self)[0];
  V v_k_2455 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2457 = (g_heff_2eelab_2erules_2erecordIntro(v_n2_242, v_x_2456));
  V f_ = v_k_2455;
  args[0] = v_t_2457;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam9(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  V v_c_2453 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2453;
  args[0] = v_hd_2454;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam10, 1, 2, (V[]){v_n2_242, v_k_2455});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15(V self, V *args) {
  V v_x_2473 = args[0];
  V v_body_2469 = heff_env(self)[0];
  V v_sp_2467 = heff_env(self)[1];
  V v_k_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2474 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_2473, v_body_2469}), v_sp_2467});
  V f_ = v_k_2472;
  args[0] = v_t_2474;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  V v_c_2470 = heff_env(self)[0];
  V v_body_2469 = heff_env(self)[1];
  V v_sp_2467 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2470;
  args[0] = v_hd_2471;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam15, 1, 3, (V[]){v_body_2469, v_sp_2467, v_k_2472});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13(V self, V *args) {
  V v_m_2465 = args[0];
  V v_e_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2465)) {
  case TAG_At: {
    V v_x21_2466 = heff_field(v_m_2465, 0);
    V v_sp_2467 = heff_field(v_m_2465, 1);
    heff_take_n(v_m_2465, 3ULL, 2);
    switch (heff_tag_of(v_x21_2466)) {
    case TAG_MkAlt: {
      V v_p_2468 = heff_field(v_x21_2466, 0);
      V v_body_2469 = heff_field(v_x21_2466, 1);
      heff_take_n(v_x21_2466, 3ULL, 2);
      V v_c_2470 = (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_2463, 1, 6), v_p_2468));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam14, 2, 3, (V[]){v_c_2470, v_body_2469, v_sp_2467});
    }
    default: return heff_nomatch(v_x21_2466);
    }
  }
  default: return heff_nomatch(v_m_2465);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18(V self, V *args) {
  V v_x_2481 = args[0];
  V v_e_2463 = heff_env(self)[0];
  V v_a_2464 = heff_env(self)[1];
  V v_hd_2476 = heff_env(self)[2];
  V v_k_2477 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2481)) {
  case TAG_MkChk: {
    V v_f_2482 = heff_field(v_x_2481, 0);
    heff_take_n(v_x_2481, 1ULL, 1);
    V f_ = v_f_2482;
    heff_room[0] = v_e_2463;
    heff_room[1] = v_a_2464;
    heff_room[2] = v_hd_2476;
    heff_room[3] = v_k_2477;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_2481);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17(V self, V *args) {
  V v_x_2478 = args[0];
  V v_scrutN_2458 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  V v_hd_2476 = heff_env(self)[2];
  V v_e_2463 = heff_env(self)[3];
  V v_a_2464 = heff_env(self)[4];
  V v_k_2477 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2479 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_scrutN_2458, v_x_2478}), v_n2_242});
  V v_c_2480 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_2479));
  V f_ = v_c_2480;
  heff_room[0] = heff_dup(v_hd_2476);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam18, 1, 4, (V[]){v_e_2463, v_a_2464, v_hd_2476, v_k_2477});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16(V self, V *args) {
  V v_hd_2476 = args[0];
  V v_k_2477 = args[1];
  V v_c_2475 = heff_env(self)[0];
  V v_scrutN_2458 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  V v_e_2463 = heff_env(self)[3];
  V v_a_2464 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2475;
  args[0] = heff_dup(v_hd_2476);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam17, 1, 6, (V[]){v_scrutN_2458, v_n2_242, v_hd_2476, v_e_2463, v_a_2464, v_k_2477});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12(V self, V *args) {
  V v_e_2463 = args[0];
  V v_a_2464 = args[1];
  V v_casesN_2459 = heff_env(self)[0];
  V v_scrutN_2458 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2475 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam13, 1, 1, (V[]){heff_dup(v_e_2463)}), v_casesN_2459));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam16, 2, 5, (V[]){v_c_2475, v_scrutN_2458, v_n2_242, v_e_2463, v_a_2464});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam11(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_casesN_2459 = heff_env(self)[0];
  V v_scrutN_2458 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2461);
  V f_ = v_k_2462;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam12, 2, 3, (V[]){v_casesN_2459, v_scrutN_2458, v_n2_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21(V self, V *args) {
  V v_x_2497 = args[0];
  V v_x_2491 = heff_env(self)[0];
  V v_x_2495 = heff_env(self)[1];
  V v_k_2494 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2498 = ({ V a_0 = v_x_2491; V a_1 = v_x_2495; V a_2 = v_x_2497; V r_ = (g_heff_2eelab_2erules_2ecaseLet(a_0, a_1, a_2)); heff_drop(v_x_2495); heff_drop(v_x_2497); r_; });
  V f_ = v_k_2494;
  args[0] = v_t_2498;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20(V self, V *args) {
  V v_x_2495 = args[0];
  V v_bodyN_2488 = heff_env(self)[0];
  V v_hd_2493 = heff_env(self)[1];
  V v_x_2491 = heff_env(self)[2];
  V v_k_2494 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2496 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_bodyN_2488));
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2496, v_hd_2493, heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam21, 1, 3, (V[]){v_x_2491, v_x_2495, v_k_2494})));
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam19(V self, V *args) {
  V v_hd_2493 = args[0];
  V v_k_2494 = args[1];
  V v_c_2492 = heff_env(self)[0];
  V v_bodyN_2488 = heff_env(self)[1];
  V v_x_2491 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2492;
  args[0] = heff_dup(v_hd_2493);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam20, 1, 4, (V[]){v_bodyN_2488, v_hd_2493, v_x_2491, v_k_2494});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25(V self, V *args) {
  V v_x_24118 = args[0];
  V v_body_24114 = heff_env(self)[0];
  V v_sp_24112 = heff_env(self)[1];
  V v_k_24117 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24119 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24118, v_body_24114}), v_sp_24112});
  V f_ = v_k_24117;
  args[0] = v_t_24119;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24(V self, V *args) {
  V v_hd_24116 = args[0];
  V v_k_24117 = args[1];
  V v_c_24115 = heff_env(self)[0];
  V v_body_24114 = heff_env(self)[1];
  V v_sp_24112 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24115;
  args[0] = v_hd_24116;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam25, 1, 3, (V[]){v_body_24114, v_sp_24112, v_k_24117});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28(V self, V *args) {
  V v_x_24126 = args[0];
  V v_e_24109 = heff_env(self)[0];
  V v_a_24110 = heff_env(self)[1];
  V v_hd_24121 = heff_env(self)[2];
  V v_k_24122 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_24126)) {
  case TAG_MkChk: {
    V v_f_24127 = heff_field(v_x_24126, 0);
    heff_take_n(v_x_24126, 1ULL, 1);
    V f_ = v_f_24127;
    heff_room[0] = v_e_24109;
    heff_room[1] = v_a_24110;
    heff_room[2] = v_hd_24121;
    heff_room[3] = v_k_24122;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_24126);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27(V self, V *args) {
  V v_x_24123 = args[0];
  V v_rhsN_2483 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  V v_hd_24121 = heff_env(self)[2];
  V v_e_24109 = heff_env(self)[3];
  V v_a_24110 = heff_env(self)[4];
  V v_k_24122 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24124 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2483, v_x_24123}), v_n2_242});
  V v_c_24125 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_24124));
  V f_ = v_c_24125;
  heff_room[0] = heff_dup(v_hd_24121);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam28, 1, 4, (V[]){v_e_24109, v_a_24110, v_hd_24121, v_k_24122});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26(V self, V *args) {
  V v_hd_24121 = args[0];
  V v_k_24122 = args[1];
  V v_c_24120 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  V v_e_24109 = heff_env(self)[3];
  V v_a_24110 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24120;
  args[0] = heff_dup(v_hd_24121);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam27, 1, 6, (V[]){v_rhsN_2483, v_n2_242, v_hd_24121, v_e_24109, v_a_24110, v_k_24122});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23(V self, V *args) {
  V v_e_24109 = args[0];
  V v_a_24110 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24120;
  switch (heff_tag_of(v_alt0_2484)) {
  case TAG_At: {
    V v_x21_24111 = heff_field(v_alt0_2484, 0);
    V v_sp_24112 = heff_field(v_alt0_2484, 1);
    heff_take_n(v_alt0_2484, 3ULL, 2);
    switch (heff_tag_of(v_x21_24111)) {
    case TAG_MkAlt: {
      V v_p_24113 = heff_field(v_x21_24111, 0);
      V v_body_24114 = heff_field(v_x21_24111, 1);
      heff_take_n(v_x21_24111, 3ULL, 2);
      V v_c_24115 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24109, 1)), v_p_24113));
      v_c_24120 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam24, 2, 3, (V[]){v_c_24115, v_body_24114, v_sp_24112});
      break;
    }
    default: heff_nomatch(v_x21_24111);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2484);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam26, 2, 5, (V[]){v_c_24120, v_rhsN_2483, v_n2_242, v_e_24109, v_a_24110});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam22(V self, V *args) {
  V v_hd_24107 = args[0];
  V v_k_24108 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24107);
  V f_ = v_k_24108;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam23, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam32(V self, V *args) {
  V v_x_24149 = args[0];
  V v_body_24145 = heff_env(self)[0];
  V v_sp_24143 = heff_env(self)[1];
  V v_k_24148 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24150 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24149, v_body_24145}), v_sp_24143});
  V f_ = v_k_24148;
  args[0] = v_t_24150;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31(V self, V *args) {
  V v_hd_24147 = args[0];
  V v_k_24148 = args[1];
  V v_c_24146 = heff_env(self)[0];
  V v_body_24145 = heff_env(self)[1];
  V v_sp_24143 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24146;
  args[0] = v_hd_24147;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam32, 1, 3, (V[]){v_body_24145, v_sp_24143, v_k_24148});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam35(V self, V *args) {
  V v_x_24157 = args[0];
  V v_e_24140 = heff_env(self)[0];
  V v_a_24141 = heff_env(self)[1];
  V v_hd_24152 = heff_env(self)[2];
  V v_k_24153 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_24157)) {
  case TAG_MkChk: {
    V v_f_24158 = heff_field(v_x_24157, 0);
    heff_take_n(v_x_24157, 1ULL, 1);
    V f_ = v_f_24158;
    heff_room[0] = v_e_24140;
    heff_room[1] = v_a_24141;
    heff_room[2] = v_hd_24152;
    heff_room[3] = v_k_24153;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_24157);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam34(V self, V *args) {
  V v_x_24154 = args[0];
  V v_rhsN_2483 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  V v_hd_24152 = heff_env(self)[2];
  V v_e_24140 = heff_env(self)[3];
  V v_a_24141 = heff_env(self)[4];
  V v_k_24153 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24155 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2483, v_x_24154}), v_n2_242});
  V v_c_24156 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_24155));
  V f_ = v_c_24156;
  heff_room[0] = heff_dup(v_hd_24152);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam35, 1, 4, (V[]){v_e_24140, v_a_24141, v_hd_24152, v_k_24153});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam33(V self, V *args) {
  V v_hd_24152 = args[0];
  V v_k_24153 = args[1];
  V v_c_24151 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  V v_e_24140 = heff_env(self)[3];
  V v_a_24141 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24151;
  args[0] = heff_dup(v_hd_24152);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam34, 1, 6, (V[]){v_rhsN_2483, v_n2_242, v_hd_24152, v_e_24140, v_a_24141, v_k_24153});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30(V self, V *args) {
  V v_e_24140 = args[0];
  V v_a_24141 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24151;
  switch (heff_tag_of(v_alt0_2484)) {
  case TAG_At: {
    V v_x21_24142 = heff_field(v_alt0_2484, 0);
    V v_sp_24143 = heff_field(v_alt0_2484, 1);
    heff_take_n(v_alt0_2484, 3ULL, 2);
    switch (heff_tag_of(v_x21_24142)) {
    case TAG_MkAlt: {
      V v_p_24144 = heff_field(v_x21_24142, 0);
      V v_body_24145 = heff_field(v_x21_24142, 1);
      heff_take_n(v_x21_24142, 3ULL, 2);
      V v_c_24146 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24140, 1)), v_p_24144));
      v_c_24151 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam31, 2, 3, (V[]){v_c_24146, v_body_24145, v_sp_24143});
      break;
    }
    default: heff_nomatch(v_x21_24142);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2484);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam33, 2, 5, (V[]){v_c_24151, v_rhsN_2483, v_n2_242, v_e_24140, v_a_24141});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam29(V self, V *args) {
  V v_hd_24138 = args[0];
  V v_k_24139 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24138);
  V f_ = v_k_24139;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam30, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam39(V self, V *args) {
  V v_x_24178 = args[0];
  V v_body_24174 = heff_env(self)[0];
  V v_sp_24172 = heff_env(self)[1];
  V v_k_24177 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24179 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24178, v_body_24174}), v_sp_24172});
  V f_ = v_k_24177;
  args[0] = v_t_24179;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam38(V self, V *args) {
  V v_hd_24176 = args[0];
  V v_k_24177 = args[1];
  V v_c_24175 = heff_env(self)[0];
  V v_body_24174 = heff_env(self)[1];
  V v_sp_24172 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24175;
  args[0] = v_hd_24176;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam39, 1, 3, (V[]){v_body_24174, v_sp_24172, v_k_24177});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam42(V self, V *args) {
  V v_x_24186 = args[0];
  V v_e_24169 = heff_env(self)[0];
  V v_a_24170 = heff_env(self)[1];
  V v_hd_24181 = heff_env(self)[2];
  V v_k_24182 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_24186)) {
  case TAG_MkChk: {
    V v_f_24187 = heff_field(v_x_24186, 0);
    heff_take_n(v_x_24186, 1ULL, 1);
    V f_ = v_f_24187;
    heff_room[0] = v_e_24169;
    heff_room[1] = v_a_24170;
    heff_room[2] = v_hd_24181;
    heff_room[3] = v_k_24182;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_24186);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam41(V self, V *args) {
  V v_x_24183 = args[0];
  V v_rhsN_2483 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  V v_hd_24181 = heff_env(self)[2];
  V v_e_24169 = heff_env(self)[3];
  V v_a_24170 = heff_env(self)[4];
  V v_k_24182 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24184 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2483, v_x_24183}), v_n2_242});
  V v_c_24185 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_24184));
  V f_ = v_c_24185;
  heff_room[0] = heff_dup(v_hd_24181);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam42, 1, 4, (V[]){v_e_24169, v_a_24170, v_hd_24181, v_k_24182});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam40(V self, V *args) {
  V v_hd_24181 = args[0];
  V v_k_24182 = args[1];
  V v_c_24180 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  V v_e_24169 = heff_env(self)[3];
  V v_a_24170 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24180;
  args[0] = heff_dup(v_hd_24181);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam41, 1, 6, (V[]){v_rhsN_2483, v_n2_242, v_hd_24181, v_e_24169, v_a_24170, v_k_24182});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam37(V self, V *args) {
  V v_e_24169 = args[0];
  V v_a_24170 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24180;
  switch (heff_tag_of(v_alt0_2484)) {
  case TAG_At: {
    V v_x21_24171 = heff_field(v_alt0_2484, 0);
    V v_sp_24172 = heff_field(v_alt0_2484, 1);
    heff_take_n(v_alt0_2484, 3ULL, 2);
    switch (heff_tag_of(v_x21_24171)) {
    case TAG_MkAlt: {
      V v_p_24173 = heff_field(v_x21_24171, 0);
      V v_body_24174 = heff_field(v_x21_24171, 1);
      heff_take_n(v_x21_24171, 3ULL, 2);
      V v_c_24175 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24169, 1)), v_p_24173));
      v_c_24180 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam38, 2, 3, (V[]){v_c_24175, v_body_24174, v_sp_24172});
      break;
    }
    default: heff_nomatch(v_x21_24171);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2484);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam40, 2, 5, (V[]){v_c_24180, v_rhsN_2483, v_n2_242, v_e_24169, v_a_24170});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam36(V self, V *args) {
  V v_hd_24167 = args[0];
  V v_k_24168 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24167);
  V f_ = v_k_24168;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam37, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam46(V self, V *args) {
  V v_x_24207 = args[0];
  V v_body_24203 = heff_env(self)[0];
  V v_sp_24201 = heff_env(self)[1];
  V v_k_24206 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24208 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24207, v_body_24203}), v_sp_24201});
  V f_ = v_k_24206;
  args[0] = v_t_24208;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam45(V self, V *args) {
  V v_hd_24205 = args[0];
  V v_k_24206 = args[1];
  V v_c_24204 = heff_env(self)[0];
  V v_body_24203 = heff_env(self)[1];
  V v_sp_24201 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24204;
  args[0] = v_hd_24205;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam46, 1, 3, (V[]){v_body_24203, v_sp_24201, v_k_24206});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam49(V self, V *args) {
  V v_x_24215 = args[0];
  V v_e_24198 = heff_env(self)[0];
  V v_a_24199 = heff_env(self)[1];
  V v_hd_24210 = heff_env(self)[2];
  V v_k_24211 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_24215)) {
  case TAG_MkChk: {
    V v_f_24216 = heff_field(v_x_24215, 0);
    heff_take_n(v_x_24215, 1ULL, 1);
    V f_ = v_f_24216;
    heff_room[0] = v_e_24198;
    heff_room[1] = v_a_24199;
    heff_room[2] = v_hd_24210;
    heff_room[3] = v_k_24211;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_24215);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam48(V self, V *args) {
  V v_x_24212 = args[0];
  V v_rhsN_2483 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  V v_hd_24210 = heff_env(self)[2];
  V v_e_24198 = heff_env(self)[3];
  V v_a_24199 = heff_env(self)[4];
  V v_k_24211 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24213 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2483, v_x_24212}), v_n2_242});
  V v_c_24214 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_24213));
  V f_ = v_c_24214;
  heff_room[0] = heff_dup(v_hd_24210);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam49, 1, 4, (V[]){v_e_24198, v_a_24199, v_hd_24210, v_k_24211});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam47(V self, V *args) {
  V v_hd_24210 = args[0];
  V v_k_24211 = args[1];
  V v_c_24209 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  V v_e_24198 = heff_env(self)[3];
  V v_a_24199 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24209;
  args[0] = heff_dup(v_hd_24210);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam48, 1, 6, (V[]){v_rhsN_2483, v_n2_242, v_hd_24210, v_e_24198, v_a_24199, v_k_24211});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam44(V self, V *args) {
  V v_e_24198 = args[0];
  V v_a_24199 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24209;
  switch (heff_tag_of(v_alt0_2484)) {
  case TAG_At: {
    V v_x21_24200 = heff_field(v_alt0_2484, 0);
    V v_sp_24201 = heff_field(v_alt0_2484, 1);
    heff_take_n(v_alt0_2484, 3ULL, 2);
    switch (heff_tag_of(v_x21_24200)) {
    case TAG_MkAlt: {
      V v_p_24202 = heff_field(v_x21_24200, 0);
      V v_body_24203 = heff_field(v_x21_24200, 1);
      heff_take_n(v_x21_24200, 3ULL, 2);
      V v_c_24204 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24198, 1)), v_p_24202));
      v_c_24209 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam45, 2, 3, (V[]){v_c_24204, v_body_24203, v_sp_24201});
      break;
    }
    default: heff_nomatch(v_x21_24200);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2484);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam47, 2, 5, (V[]){v_c_24209, v_rhsN_2483, v_n2_242, v_e_24198, v_a_24199});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam43(V self, V *args) {
  V v_hd_24196 = args[0];
  V v_k_24197 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24196);
  V f_ = v_k_24197;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam44, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam53(V self, V *args) {
  V v_x_24236 = args[0];
  V v_body_24232 = heff_env(self)[0];
  V v_sp_24230 = heff_env(self)[1];
  V v_k_24235 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24237 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24236, v_body_24232}), v_sp_24230});
  V f_ = v_k_24235;
  args[0] = v_t_24237;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam52(V self, V *args) {
  V v_hd_24234 = args[0];
  V v_k_24235 = args[1];
  V v_c_24233 = heff_env(self)[0];
  V v_body_24232 = heff_env(self)[1];
  V v_sp_24230 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24233;
  args[0] = v_hd_24234;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam53, 1, 3, (V[]){v_body_24232, v_sp_24230, v_k_24235});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam56(V self, V *args) {
  V v_x_24244 = args[0];
  V v_e_24227 = heff_env(self)[0];
  V v_a_24228 = heff_env(self)[1];
  V v_hd_24239 = heff_env(self)[2];
  V v_k_24240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_24244)) {
  case TAG_MkChk: {
    V v_f_24245 = heff_field(v_x_24244, 0);
    heff_take_n(v_x_24244, 1ULL, 1);
    V f_ = v_f_24245;
    heff_room[0] = v_e_24227;
    heff_room[1] = v_a_24228;
    heff_room[2] = v_hd_24239;
    heff_room[3] = v_k_24240;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_24244);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam55(V self, V *args) {
  V v_x_24241 = args[0];
  V v_rhsN_2483 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  V v_hd_24239 = heff_env(self)[2];
  V v_e_24227 = heff_env(self)[3];
  V v_a_24228 = heff_env(self)[4];
  V v_k_24240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24242 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2483, v_x_24241}), v_n2_242});
  V v_c_24243 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_24242));
  V f_ = v_c_24243;
  heff_room[0] = heff_dup(v_hd_24239);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam56, 1, 4, (V[]){v_e_24227, v_a_24228, v_hd_24239, v_k_24240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam54(V self, V *args) {
  V v_hd_24239 = args[0];
  V v_k_24240 = args[1];
  V v_c_24238 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  V v_e_24227 = heff_env(self)[3];
  V v_a_24228 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24238;
  args[0] = heff_dup(v_hd_24239);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam55, 1, 6, (V[]){v_rhsN_2483, v_n2_242, v_hd_24239, v_e_24227, v_a_24228, v_k_24240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam51(V self, V *args) {
  V v_e_24227 = args[0];
  V v_a_24228 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24238;
  switch (heff_tag_of(v_alt0_2484)) {
  case TAG_At: {
    V v_x21_24229 = heff_field(v_alt0_2484, 0);
    V v_sp_24230 = heff_field(v_alt0_2484, 1);
    heff_take_n(v_alt0_2484, 3ULL, 2);
    switch (heff_tag_of(v_x21_24229)) {
    case TAG_MkAlt: {
      V v_p_24231 = heff_field(v_x21_24229, 0);
      V v_body_24232 = heff_field(v_x21_24229, 1);
      heff_take_n(v_x21_24229, 3ULL, 2);
      V v_c_24233 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24227, 1)), v_p_24231));
      v_c_24238 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam52, 2, 3, (V[]){v_c_24233, v_body_24232, v_sp_24230});
      break;
    }
    default: heff_nomatch(v_x21_24229);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2484);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam54, 2, 5, (V[]){v_c_24238, v_rhsN_2483, v_n2_242, v_e_24227, v_a_24228});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam50(V self, V *args) {
  V v_hd_24225 = args[0];
  V v_k_24226 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24225);
  V f_ = v_k_24226;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam51, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam60(V self, V *args) {
  V v_x_24265 = args[0];
  V v_body_24261 = heff_env(self)[0];
  V v_sp_24259 = heff_env(self)[1];
  V v_k_24264 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24266 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24265, v_body_24261}), v_sp_24259});
  V f_ = v_k_24264;
  args[0] = v_t_24266;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam59(V self, V *args) {
  V v_hd_24263 = args[0];
  V v_k_24264 = args[1];
  V v_c_24262 = heff_env(self)[0];
  V v_body_24261 = heff_env(self)[1];
  V v_sp_24259 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24262;
  args[0] = v_hd_24263;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam60, 1, 3, (V[]){v_body_24261, v_sp_24259, v_k_24264});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam63(V self, V *args) {
  V v_x_24273 = args[0];
  V v_e_24256 = heff_env(self)[0];
  V v_a_24257 = heff_env(self)[1];
  V v_hd_24268 = heff_env(self)[2];
  V v_k_24269 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_24273)) {
  case TAG_MkChk: {
    V v_f_24274 = heff_field(v_x_24273, 0);
    heff_take_n(v_x_24273, 1ULL, 1);
    V f_ = v_f_24274;
    heff_room[0] = v_e_24256;
    heff_room[1] = v_a_24257;
    heff_room[2] = v_hd_24268;
    heff_room[3] = v_k_24269;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_24273);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam62(V self, V *args) {
  V v_x_24270 = args[0];
  V v_rhsN_2483 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  V v_hd_24268 = heff_env(self)[2];
  V v_e_24256 = heff_env(self)[3];
  V v_a_24257 = heff_env(self)[4];
  V v_k_24269 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24271 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2483, v_x_24270}), v_n2_242});
  V v_c_24272 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_24271));
  V f_ = v_c_24272;
  heff_room[0] = heff_dup(v_hd_24268);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam63, 1, 4, (V[]){v_e_24256, v_a_24257, v_hd_24268, v_k_24269});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam61(V self, V *args) {
  V v_hd_24268 = args[0];
  V v_k_24269 = args[1];
  V v_c_24267 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  V v_e_24256 = heff_env(self)[3];
  V v_a_24257 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24267;
  args[0] = heff_dup(v_hd_24268);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam62, 1, 6, (V[]){v_rhsN_2483, v_n2_242, v_hd_24268, v_e_24256, v_a_24257, v_k_24269});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam58(V self, V *args) {
  V v_e_24256 = args[0];
  V v_a_24257 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24267;
  switch (heff_tag_of(v_alt0_2484)) {
  case TAG_At: {
    V v_x21_24258 = heff_field(v_alt0_2484, 0);
    V v_sp_24259 = heff_field(v_alt0_2484, 1);
    heff_take_n(v_alt0_2484, 3ULL, 2);
    switch (heff_tag_of(v_x21_24258)) {
    case TAG_MkAlt: {
      V v_p_24260 = heff_field(v_x21_24258, 0);
      V v_body_24261 = heff_field(v_x21_24258, 1);
      heff_take_n(v_x21_24258, 3ULL, 2);
      V v_c_24262 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24256, 1)), v_p_24260));
      v_c_24267 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam59, 2, 3, (V[]){v_c_24262, v_body_24261, v_sp_24259});
      break;
    }
    default: heff_nomatch(v_x21_24258);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2484);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam61, 2, 5, (V[]){v_c_24267, v_rhsN_2483, v_n2_242, v_e_24256, v_a_24257});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam57(V self, V *args) {
  V v_hd_24254 = args[0];
  V v_k_24255 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24254);
  V f_ = v_k_24255;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam58, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam67(V self, V *args) {
  V v_x_24294 = args[0];
  V v_body_24290 = heff_env(self)[0];
  V v_sp_24288 = heff_env(self)[1];
  V v_k_24293 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24295 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24294, v_body_24290}), v_sp_24288});
  V f_ = v_k_24293;
  args[0] = v_t_24295;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam66(V self, V *args) {
  V v_hd_24292 = args[0];
  V v_k_24293 = args[1];
  V v_c_24291 = heff_env(self)[0];
  V v_body_24290 = heff_env(self)[1];
  V v_sp_24288 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24291;
  args[0] = v_hd_24292;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam67, 1, 3, (V[]){v_body_24290, v_sp_24288, v_k_24293});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam70(V self, V *args) {
  V v_x_24302 = args[0];
  V v_e_24285 = heff_env(self)[0];
  V v_a_24286 = heff_env(self)[1];
  V v_hd_24297 = heff_env(self)[2];
  V v_k_24298 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_24302)) {
  case TAG_MkChk: {
    V v_f_24303 = heff_field(v_x_24302, 0);
    heff_take_n(v_x_24302, 1ULL, 1);
    V f_ = v_f_24303;
    heff_room[0] = v_e_24285;
    heff_room[1] = v_a_24286;
    heff_room[2] = v_hd_24297;
    heff_room[3] = v_k_24298;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_24302);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam69(V self, V *args) {
  V v_x_24299 = args[0];
  V v_rhsN_2483 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  V v_hd_24297 = heff_env(self)[2];
  V v_e_24285 = heff_env(self)[3];
  V v_a_24286 = heff_env(self)[4];
  V v_k_24298 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24300 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2483, v_x_24299}), v_n2_242});
  V v_c_24301 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_24300));
  V f_ = v_c_24301;
  heff_room[0] = heff_dup(v_hd_24297);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam70, 1, 4, (V[]){v_e_24285, v_a_24286, v_hd_24297, v_k_24298});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam68(V self, V *args) {
  V v_hd_24297 = args[0];
  V v_k_24298 = args[1];
  V v_c_24296 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  V v_e_24285 = heff_env(self)[3];
  V v_a_24286 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24296;
  args[0] = heff_dup(v_hd_24297);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam69, 1, 6, (V[]){v_rhsN_2483, v_n2_242, v_hd_24297, v_e_24285, v_a_24286, v_k_24298});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam65(V self, V *args) {
  V v_e_24285 = args[0];
  V v_a_24286 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24296;
  switch (heff_tag_of(v_alt0_2484)) {
  case TAG_At: {
    V v_x21_24287 = heff_field(v_alt0_2484, 0);
    V v_sp_24288 = heff_field(v_alt0_2484, 1);
    heff_take_n(v_alt0_2484, 3ULL, 2);
    switch (heff_tag_of(v_x21_24287)) {
    case TAG_MkAlt: {
      V v_p_24289 = heff_field(v_x21_24287, 0);
      V v_body_24290 = heff_field(v_x21_24287, 1);
      heff_take_n(v_x21_24287, 3ULL, 2);
      V v_c_24291 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24285, 1)), v_p_24289));
      v_c_24296 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam66, 2, 3, (V[]){v_c_24291, v_body_24290, v_sp_24288});
      break;
    }
    default: heff_nomatch(v_x21_24287);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2484);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam68, 2, 5, (V[]){v_c_24296, v_rhsN_2483, v_n2_242, v_e_24285, v_a_24286});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam64(V self, V *args) {
  V v_hd_24283 = args[0];
  V v_k_24284 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24283);
  V f_ = v_k_24284;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam65, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam74(V self, V *args) {
  V v_x_24323 = args[0];
  V v_body_24319 = heff_env(self)[0];
  V v_sp_24317 = heff_env(self)[1];
  V v_k_24322 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24324 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24323, v_body_24319}), v_sp_24317});
  V f_ = v_k_24322;
  args[0] = v_t_24324;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam73(V self, V *args) {
  V v_hd_24321 = args[0];
  V v_k_24322 = args[1];
  V v_c_24320 = heff_env(self)[0];
  V v_body_24319 = heff_env(self)[1];
  V v_sp_24317 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24320;
  args[0] = v_hd_24321;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam74, 1, 3, (V[]){v_body_24319, v_sp_24317, v_k_24322});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam77(V self, V *args) {
  V v_x_24331 = args[0];
  V v_e_24314 = heff_env(self)[0];
  V v_a_24315 = heff_env(self)[1];
  V v_hd_24326 = heff_env(self)[2];
  V v_k_24327 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_24331)) {
  case TAG_MkChk: {
    V v_f_24332 = heff_field(v_x_24331, 0);
    heff_take_n(v_x_24331, 1ULL, 1);
    V f_ = v_f_24332;
    heff_room[0] = v_e_24314;
    heff_room[1] = v_a_24315;
    heff_room[2] = v_hd_24326;
    heff_room[3] = v_k_24327;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_24331);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam76(V self, V *args) {
  V v_x_24328 = args[0];
  V v_rhsN_2483 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  V v_hd_24326 = heff_env(self)[2];
  V v_e_24314 = heff_env(self)[3];
  V v_a_24315 = heff_env(self)[4];
  V v_k_24327 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24329 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2483, v_x_24328}), v_n2_242});
  V v_c_24330 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_24329));
  V f_ = v_c_24330;
  heff_room[0] = heff_dup(v_hd_24326);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam77, 1, 4, (V[]){v_e_24314, v_a_24315, v_hd_24326, v_k_24327});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam75(V self, V *args) {
  V v_hd_24326 = args[0];
  V v_k_24327 = args[1];
  V v_c_24325 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  V v_e_24314 = heff_env(self)[3];
  V v_a_24315 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24325;
  args[0] = heff_dup(v_hd_24326);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam76, 1, 6, (V[]){v_rhsN_2483, v_n2_242, v_hd_24326, v_e_24314, v_a_24315, v_k_24327});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam72(V self, V *args) {
  V v_e_24314 = args[0];
  V v_a_24315 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24325;
  switch (heff_tag_of(v_alt0_2484)) {
  case TAG_At: {
    V v_x21_24316 = heff_field(v_alt0_2484, 0);
    V v_sp_24317 = heff_field(v_alt0_2484, 1);
    heff_take_n(v_alt0_2484, 3ULL, 2);
    switch (heff_tag_of(v_x21_24316)) {
    case TAG_MkAlt: {
      V v_p_24318 = heff_field(v_x21_24316, 0);
      V v_body_24319 = heff_field(v_x21_24316, 1);
      heff_take_n(v_x21_24316, 3ULL, 2);
      V v_c_24320 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24314, 1)), v_p_24318));
      v_c_24325 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam73, 2, 3, (V[]){v_c_24320, v_body_24319, v_sp_24317});
      break;
    }
    default: heff_nomatch(v_x21_24316);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2484);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam75, 2, 5, (V[]){v_c_24325, v_rhsN_2483, v_n2_242, v_e_24314, v_a_24315});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam71(V self, V *args) {
  V v_hd_24312 = args[0];
  V v_k_24313 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24312);
  V f_ = v_k_24313;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam72, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam81(V self, V *args) {
  V v_x_24352 = args[0];
  V v_body_24348 = heff_env(self)[0];
  V v_sp_24346 = heff_env(self)[1];
  V v_k_24351 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24353 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24352, v_body_24348}), v_sp_24346});
  V f_ = v_k_24351;
  args[0] = v_t_24353;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam80(V self, V *args) {
  V v_hd_24350 = args[0];
  V v_k_24351 = args[1];
  V v_c_24349 = heff_env(self)[0];
  V v_body_24348 = heff_env(self)[1];
  V v_sp_24346 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24349;
  args[0] = v_hd_24350;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam81, 1, 3, (V[]){v_body_24348, v_sp_24346, v_k_24351});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam84(V self, V *args) {
  V v_x_24360 = args[0];
  V v_e_24343 = heff_env(self)[0];
  V v_a_24344 = heff_env(self)[1];
  V v_hd_24355 = heff_env(self)[2];
  V v_k_24356 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_24360)) {
  case TAG_MkChk: {
    V v_f_24361 = heff_field(v_x_24360, 0);
    heff_take_n(v_x_24360, 1ULL, 1);
    V f_ = v_f_24361;
    heff_room[0] = v_e_24343;
    heff_room[1] = v_a_24344;
    heff_room[2] = v_hd_24355;
    heff_room[3] = v_k_24356;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_24360);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam83(V self, V *args) {
  V v_x_24357 = args[0];
  V v_rhsN_2483 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  V v_hd_24355 = heff_env(self)[2];
  V v_e_24343 = heff_env(self)[3];
  V v_a_24344 = heff_env(self)[4];
  V v_k_24356 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24358 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2483, v_x_24357}), v_n2_242});
  V v_c_24359 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_24358));
  V f_ = v_c_24359;
  heff_room[0] = heff_dup(v_hd_24355);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam84, 1, 4, (V[]){v_e_24343, v_a_24344, v_hd_24355, v_k_24356});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam82(V self, V *args) {
  V v_hd_24355 = args[0];
  V v_k_24356 = args[1];
  V v_c_24354 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  V v_e_24343 = heff_env(self)[3];
  V v_a_24344 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24354;
  args[0] = heff_dup(v_hd_24355);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam83, 1, 6, (V[]){v_rhsN_2483, v_n2_242, v_hd_24355, v_e_24343, v_a_24344, v_k_24356});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam79(V self, V *args) {
  V v_e_24343 = args[0];
  V v_a_24344 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24354;
  switch (heff_tag_of(v_alt0_2484)) {
  case TAG_At: {
    V v_x21_24345 = heff_field(v_alt0_2484, 0);
    V v_sp_24346 = heff_field(v_alt0_2484, 1);
    heff_take_n(v_alt0_2484, 3ULL, 2);
    switch (heff_tag_of(v_x21_24345)) {
    case TAG_MkAlt: {
      V v_p_24347 = heff_field(v_x21_24345, 0);
      V v_body_24348 = heff_field(v_x21_24345, 1);
      heff_take_n(v_x21_24345, 3ULL, 2);
      V v_c_24349 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24343, 1)), v_p_24347));
      v_c_24354 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam80, 2, 3, (V[]){v_c_24349, v_body_24348, v_sp_24346});
      break;
    }
    default: heff_nomatch(v_x21_24345);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2484);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam82, 2, 5, (V[]){v_c_24354, v_rhsN_2483, v_n2_242, v_e_24343, v_a_24344});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam78(V self, V *args) {
  V v_hd_24341 = args[0];
  V v_k_24342 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24341);
  V f_ = v_k_24342;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam79, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam88(V self, V *args) {
  V v_x_24383 = args[0];
  V v_body_24379 = heff_env(self)[0];
  V v_sp_24377 = heff_env(self)[1];
  V v_k_24382 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24384 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24383, v_body_24379}), v_sp_24377});
  V f_ = v_k_24382;
  args[0] = v_t_24384;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam87(V self, V *args) {
  V v_hd_24381 = args[0];
  V v_k_24382 = args[1];
  V v_c_24380 = heff_env(self)[0];
  V v_body_24379 = heff_env(self)[1];
  V v_sp_24377 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24380;
  args[0] = v_hd_24381;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam88, 1, 3, (V[]){v_body_24379, v_sp_24377, v_k_24382});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam91(V self, V *args) {
  V v_x_24391 = args[0];
  V v_e_24374 = heff_env(self)[0];
  V v_a_24375 = heff_env(self)[1];
  V v_hd_24386 = heff_env(self)[2];
  V v_k_24387 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_24391)) {
  case TAG_MkChk: {
    V v_f_24392 = heff_field(v_x_24391, 0);
    heff_take_n(v_x_24391, 1ULL, 1);
    V f_ = v_f_24392;
    heff_room[0] = v_e_24374;
    heff_room[1] = v_a_24375;
    heff_room[2] = v_hd_24386;
    heff_room[3] = v_k_24387;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_24391);
  }
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam90(V self, V *args) {
  V v_x_24388 = args[0];
  V v_rhsN_2483 = heff_env(self)[0];
  V v_n2_242 = heff_env(self)[1];
  V v_hd_24386 = heff_env(self)[2];
  V v_e_24374 = heff_env(self)[3];
  V v_a_24375 = heff_env(self)[4];
  V v_k_24387 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24389 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhsN_2483, v_x_24388}), v_n2_242});
  V v_c_24390 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_t_24389));
  V f_ = v_c_24390;
  heff_room[0] = heff_dup(v_hd_24386);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam91, 1, 4, (V[]){v_e_24374, v_a_24375, v_hd_24386, v_k_24387});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam89(V self, V *args) {
  V v_hd_24386 = args[0];
  V v_k_24387 = args[1];
  V v_c_24385 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  V v_e_24374 = heff_env(self)[3];
  V v_a_24375 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24385;
  args[0] = heff_dup(v_hd_24386);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam90, 1, 6, (V[]){v_rhsN_2483, v_n2_242, v_hd_24386, v_e_24374, v_a_24375, v_k_24387});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam86(V self, V *args) {
  V v_e_24374 = args[0];
  V v_a_24375 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24385;
  switch (heff_tag_of(v_alt0_2484)) {
  case TAG_At: {
    V v_x21_24376 = heff_field(v_alt0_2484, 0);
    V v_sp_24377 = heff_field(v_alt0_2484, 1);
    heff_take_n(v_alt0_2484, 3ULL, 2);
    switch (heff_tag_of(v_x21_24376)) {
    case TAG_MkAlt: {
      V v_p_24378 = heff_field(v_x21_24376, 0);
      V v_body_24379 = heff_field(v_x21_24376, 1);
      heff_take_n(v_x21_24376, 3ULL, 2);
      V v_c_24380 = (g_heff_2eelab_2etoplevel_2eopPat(heff_dup(heff_rfield(v_e_24374, 1)), v_p_24378));
      v_c_24385 = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam87, 2, 3, (V[]){v_c_24380, v_body_24379, v_sp_24377});
      break;
    }
    default: heff_nomatch(v_x21_24376);
    }
    break;
  }
  default: heff_nomatch(v_alt0_2484);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam89, 2, 5, (V[]){v_c_24385, v_rhsN_2483, v_n2_242, v_e_24374, v_a_24375});
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam85(V self, V *args) {
  V v_hd_24372 = args[0];
  V v_k_24373 = args[1];
  V v_alt0_2484 = heff_env(self)[0];
  V v_rhsN_2483 = heff_env(self)[1];
  V v_n2_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_24372);
  V f_ = v_k_24373;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam86, 2, 3, (V[]){v_alt0_2484, v_rhsN_2483, v_n2_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam92(V self, V *args) {
  V v_hd_24397 = args[0];
  V v_k_24398 = args[1];
  V v_n2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24397);
  V v_t_24399 = (g_heff_2eelab_2erules_2eabandonChk(v_n2_242));
  V f_ = v_k_24398;
  args[0] = v_t_24399;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam94(V self, V *args) {
  V v_x_24404 = args[0];
  V v_k_24403 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24405 = ({ V a_0 = v_x_24404; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop(v_x_24404); r_; });
  V f_ = v_k_24403;
  args[0] = v_t_24405;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam93(V self, V *args) {
  V v_hd_24402 = args[0];
  V v_k_24403 = args[1];
  V v_c_24401 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24401;
  args[0] = v_hd_24402;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_lam94, 1, 1, (V[]){v_k_24403});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036(V v_nominal_240, V v_sp_241, V v_c_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_242)));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam0, 2, 4, (V[]){v_t_243, v_sp_241, v_c_242, heff_dup(v_nominal_240)});
}
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_247 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkSyn: {
    V v_f_2412 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    V f_ = v_f_2412;
    heff_room[0] = v_e_247;
    heff_room[1] = v_hd_249;
    heff_room[2] = v_k_2410;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam3(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam4, 1, 3, (V[]){v_e_247, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam2(V self, V *args) {
  V v_e_247 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_248 = (g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009(v_sp_241, v_c_242));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam3, 2, 2, (V[]){v_c_248, v_e_247});
}
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_nominal_240 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_j_2413 = ({ V a_0 = heff_dup(v_sp_241); V a_1 = v_x_246; V b_2 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam2, 1, 2, (V[]){v_sp_241, v_c_242})}); V r_ = (g_heff_2eelab_2erules_2elazyChk(a_0, a_1, b_2)); heff_drop(v_x_246); heff_drop(b_2); r_; });
  V v_t_2414;
  if ((heff_dup(v_nominal_240) == NTAG(TAG_True))) {
    heff_drop(v_nominal_240);
    v_t_2414 = ({ V a_0 = v_j_2413; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop(v_j_2413); r_; });
  } else {
    heff_drop(v_nominal_240);
    v_t_2414 = v_j_2413;
  }
  V v_x_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_t_2414); r_; });
  V f_ = v_k_245;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_t_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_nominal_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_243, v_hd_244, heff_clo_n(g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_lam1, 1, 4, (V[]){v_sp_241, v_c_242, v_nominal_240, v_k_245})));
}
Clo g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_ab_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_take_field(v_ab_242, 3);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Expl: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_ab_242, 1, 4), heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Impl: {
      heff_drop_rec(v_ab_242, 4);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Inst: {
      heff_drop_rec(v_ab_242, 4);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2edeclJ_str0, 45, "unexpected notation for top-level declaration");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edeclJ_str1, 45, "unexpected notation for top-level declaration");
V g_heff_2eelab_2etoplevel_2edeclJ_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2edeclJ_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edeclJ_lam3, 1, 0};
V g_heff_2eelab_2etoplevel_2edeclJ_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_lam5(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edeclJ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edeclJ_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2edeclJ(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_d1_241 = heff_field(v_d_240, 0);
    switch (heff_tag_of(v_d1_241)) {
    case TAG_DeclEquations: {
      V v_name_243 = heff_field(v_d1_241, 0);
      V v_tyN_246 = heff_field(v_d1_241, 3);
      V v_eqs_247 = heff_field(v_d1_241, 4);
      V v_t_2410;
      switch (heff_tag_of(v_tyN_246)) {
      case TAG_At: {
        V v_s_249 = heff_field(v_tyN_246, 1);
        v_t_2410 = heff_dup(v_s_249);
        break;
      }
      default: heff_nomatch(v_tyN_246);
      }
      V v_t_2413;
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        V v_s_2412 = heff_field(v_d_240, 1);
        v_t_2413 = heff_dup(v_s_2412);
        break;
      }
      default: heff_nomatch(v_d_240);
      }
      V v_t_2414 = ({ V rv_1 = heff_get_n(v_t_2413, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2410, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return (g_heff_2eelab_2etoplevel_2eequationsD(heff_dup(v_name_243), v_tyN_246, heff_dup(v_eqs_247), v_t_2414));
    }
    case TAG_DeclDefine: {
      V v_name_2415 = heff_field(v_d1_241, 0);
      V v_params_2417 = heff_field(v_d1_241, 2);
      V v_tyN_2418 = heff_field(v_d1_241, 3);
      V v_bodyN_2419 = heff_field(v_d1_241, 4);
      return (g_heff_2eelab_2etoplevel_2edefineD(heff_dup(v_name_2415), heff_dup(v_params_2417), v_tyN_2418, v_bodyN_2419));
    }
    case TAG_DeclTheory: {
      V v_name_2420 = heff_field(v_d1_241, 0);
      V v_params_2422 = heff_field(v_d1_241, 2);
      V v_bodyN_2423 = heff_field(v_d1_241, 3);
      return (g_heff_2eelab_2etoplevel_2etheoryD(heff_dup(v_name_2420), heff_dup(v_params_2422), v_bodyN_2423));
    }
    case TAG_DeclPrimitive: {
      V v_x_2424 = heff_field(v_d1_241, 0);
      V v_tyN_2426 = heff_field(v_d1_241, 2);
      V v_n_2429;
      switch (heff_tag_of(v_tyN_2426)) {
      case TAG_At: {
        V v_n_2427 = heff_field(v_tyN_2426, 0);
        V v_sp_2428 = heff_field(v_tyN_2426, 1);
        v_n_2429 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(heff_dup(v_sp_2428), heff_dup(v_n_2427)));
        break;
      }
      default: heff_nomatch(v_tyN_2426);
      }
      V v_c_2430 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2429));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam0, 2, 2, (V[]){v_c_2430, heff_dup(v_x_2424)});
    }
    case TAG_DeclTest: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam4, 2, 1, (V[]){heff_dup(v_d_240)});
    }
    case TAG_DeclWatch: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam5, 2, 1, (V[]){heff_dup(v_d_240)});
    }
    default: return heff_nomatch(v_d1_241);
    }
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2eelab_2etoplevel_2edeclJ_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2edeclJ(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam3(V self, V *args) {
  V v_u_2438 = args[0];
  heff_drop(v_u_2438);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam2(V self, V *args) {
  V v_e_2434 = args[0];
  V v_a_2435 = args[1];
  V v_hd_2436 = args[2];
  V v_k_2437 = args[3];
  V v_x_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2434);
  heff_drop(v_a_2435);
  heff_drop(v_hd_2436);
  V v_t_2439 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SPrim, 1, (V[]){v_x_2424}), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_lam3_clo)});
  V f_ = v_k_2437;
  args[0] = v_t_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam1(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_k_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){heff_dup(v_x_2424), v_x_2433, heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam2, 4, 1, (V[]){v_x_2424})}), NTAG(TAG_True)});
  V f_ = v_k_2432;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam0(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_c_2430 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2430;
  args[0] = v_hd_2431;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_lam1, 1, 2, (V[]){v_x_2424, v_k_2432});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam4(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2447;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_s_2446 = heff_field(v_d_240, 1);
    heff_take_n(v_d_240, 2ULL, 2);
    v_t_2447 = v_s_2446;
    break;
  }
  default: heff_nomatch(v_d_240);
  }
  V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_str0), v_t_2447, NTAG(TAG_Nothing)});
  V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_call(heff_take_field(v_hd_2443, 2), 1, (V[]){v_t_2450}));
  V f_ = heff_get_n(v_hd_2443, 1, 3);
  args[0] = v_t_2451;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_lam5(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k2_2454 = args[1];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2457;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_s_2456 = heff_field(v_d_240, 1);
    heff_take_n(v_d_240, 2ULL, 2);
    v_t_2457 = v_s_2456;
    break;
  }
  default: heff_nomatch(v_d_240);
  }
  V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_str1), v_t_2457, NTAG(TAG_Nothing)});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tr(heff_call(heff_take_field(v_hd_2453, 2), 1, (V[]){v_t_2460}));
  V f_ = heff_get_n(v_hd_2453, 1, 3);
  args[0] = v_t_2461;
  args[1] = v_k2_2454;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2enubInt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enubInt_24dps_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2enubInt_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2ekeepIf_24s193123870x387721583(v_x_242, v_xs_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2enubInt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2enubInt_24dps(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebodyEnv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyEnv_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ebodyEnv(V v_gSelf_240, V v_k_241, V v_name_242, V v_aval_243) {
top: ;
  V v_v_245 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_k_241)}), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyEnv_lam0, 1, 1, (V[]){heff_dup(v_aval_243)}), NTAG(TAG_Nothing)));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_name_242, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyEnv_lam1, 1, 1, (V[]){v_v_245})});
  V v_t_249 = heff_tag_n(TAG_CBind, 3, (V[]){NTAG(TAG_CEmpty), heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(1LL)}), v_aval_243});
  V v_t_2410 = heff_tag_n(TAG_ForDescriptive, 2, (V[]){heff_tag_n(TAG_HGlobal, 1, (V[]){heff_dup(v_k_241)}), NTAG(TAG_SpId)});
  return heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_rec_n(4, shape_len__names__locals__ctx, (V[]){MK_INT(1LL), v_t_246, v_t_248, v_t_249}), v_gSelf_240, v_t_2410, MK_INT(0LL), heff_tag_n(TAG_Just, 1, (V[]){v_k_241}), NTAG(TAG_Nil)});
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebodyEnv(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_aval_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return v_aval_243;
}
V g_heff_2eelab_2etoplevel_2ebodyEnv_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_v_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_v_245;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str1, 2, ", ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str2, 20, "` (the runtime has: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str3, 55, ", and each fixed-width type's, `int32Add` and the like)");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eprimKnown_str4, 30, "there is no primitive called `");
V g_heff_2eelab_2etoplevel_2eprimKnown_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eprimKnown_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eprimKnown_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2eprimKnown_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eprimKnown_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eprimKnown_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eprimKnown_lam2, 2, 0};
Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eprimKnown_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eprimKnown(V v_sp_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_d_241, 3);
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V v_xs_243 = heff_dup(g_heff_2eelab_2etoplevel_2eprimNames_get());
    V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_d_241, 0))}));
    V v_x1_245 = ({ V a_0 = v_t_244; V a_1 = v_xs_243; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_243); r_; });
    if ((heff_dup(v_x1_245) == NTAG(TAG_True))) {
      heff_drop(v_sp_240);
      heff_drop_rec(v_d_241, 4);
      heff_drop(v_x1_245);
      return ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_lam0_clo);
    } else {
      heff_drop(v_x1_245);
      V v_x2_248 = heff_dup(g_heff_2eelab_2etoplevel_2ebasicPrimNames_get());
      V v_t_2411;
      switch (heff_tag_of(v_x2_248)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_x2_248, 0);
        V v_xs_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 3ULL, 2);
        v_t_2411 = ({ V a_0 = ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str1); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
        break;
      }
      default: heff_nomatch(v_x2_248);
      }
      V v_t_2412 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str2), heff_strAppend(v_t_2411, ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str3)));
      V v_t_2413 = heff_strAppend(heff_get_n(v_d_241, 0, 4), v_t_2412);
      V v_msg_2414 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eprimKnown_str4), v_t_2413);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eprimKnown_lam1, 2, 2, (V[]){v_msg_2414, v_sp_240});
    }
  } else {
    heff_drop(v_sp_240);
    heff_drop_rec(v_d_241, 4);
    heff_drop(v_t_242);
    return ((V)&g_heff_2eelab_2etoplevel_2eprimKnown_lam2_clo);
  }
}
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eprimKnown(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eprimKnown_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eprimKnown_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k2_2416 = args[1];
  V v_msg_2414 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(329LL), NTAG(TAG_SError), v_msg_2414, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_2415, 2), 1, (V[]){v_t_2419}));
  V f_ = heff_get_n(v_hd_2415, 1, 3);
  args[0] = v_t_2420;
  args[1] = v_k2_2416;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eprimKnown_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str0, 100, "` is not in what it is an instance of: a search, unifying that with the type wanted, cannot solve it");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str1, 34, "the instance's implicit argument `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str2, 120, "use it in what the instance is an instance of (`{a : Type} -> {{e : Equality a}} -> Equality (List a)`), or leave it out");
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eeveryImplicitIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eeveryImplicitIn_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eeveryImplicitIn(V v_sp_240, V v_depth_241, V v_conclusion_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sp_240);
    heff_drop(v_depth_241);
    heff_drop(v_conclusion_242);
    return ((V)&g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam0_clo);
  }
  case TAG_Cons: {
    V v_b_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    V v_t_248 = heff_intSub(heff_intSub(heff_dup(v_depth_241), MK_INT(1LL)), heff_dup(heff_rfield(v_b_246, 1)));
    V v_t_249 = (g_heff_2eelab_2erules_2ementionsLocal(v_t_248));
    V v_t_2410 = heff_tr(heff_call(heff_get_n(v_t_249, 1, 3), 2, (V[]){MK_INT(0LL), heff_dup(v_conclusion_242)}));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V t_0 = v_sp_240;
      V t_1 = v_depth_241;
      V t_2 = v_conclusion_242;
      V t_3 = v_rest_247;
      v_sp_240 = t_0;
      v_depth_241 = t_1;
      v_conclusion_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    } else {
      heff_drop(v_depth_241);
      heff_drop(v_conclusion_242);
      heff_drop(v_t_2410);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam1, 2, 2, (V[]){heff_dup(v_b_246), v_sp_240});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k2_2412 = args[1];
  V v_b_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_strAppend(heff_get_n(v_b_246, 0, 2), ((V)&g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str0));
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(350LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str1), v_t_2413), v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eeveryImplicitIn_str2)})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_2411, 2), 1, (V[]){v_t_2416}));
  V f_ = heff_get_n(v_hd_2411, 1, 3);
  args[0] = v_t_2417;
  args[1] = v_k2_2412;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str0, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str1, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str2, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str3, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str4, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str5, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str6, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str7, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str8, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str9, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchSyn_str10, 54, "a watch must say what type it has: write `>>> (e : T)`");
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam10(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ewatchSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchSyn_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ewatchSyn(V v_w_240) {
top: ;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_w1_241 = heff_field(v_w_240, 0);
    switch (heff_tag_of(v_w1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_w1_241, 0);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_i_243));
    }
    case TAG_CType: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam0, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CLam: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam1, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CImplicitLam: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam2, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CAnnLam: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam3, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CTag: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam4, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CStruct: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam5, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CMatch: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam6, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CLetIn: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam7, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CLocal: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam8, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CAbandon: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam9, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    case TAG_CNominal: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchSyn_lam10, 2, 1, (V[]){heff_dup(v_w_240)});
    }
    default: return heff_nomatch(v_w1_241);
    }
  }
  default: return heff_nomatch(v_w_240);
  }
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ewatchSyn(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k2_246 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_248 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_249 = v_s_248;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str0), v_t_249, NTAG(TAG_Nothing)});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2412}));
  V f_ = heff_get_n(v_hd_245, 1, 3);
  args[0] = v_t_2413;
  args[1] = v_k2_246;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k2_2418 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_2420 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_2421 = v_s_2420;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str1), v_t_2421, NTAG(TAG_Nothing)});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_2424}));
  V f_ = heff_get_n(v_hd_2417, 1, 3);
  args[0] = v_t_2425;
  args[1] = v_k2_2418;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam2(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k2_2430 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_2432 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_2433 = v_s_2432;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str2), v_t_2433, NTAG(TAG_Nothing)});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_call(heff_take_field(v_hd_2429, 2), 1, (V[]){v_t_2436}));
  V f_ = heff_get_n(v_hd_2429, 1, 3);
  args[0] = v_t_2437;
  args[1] = v_k2_2430;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam3(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k2_2443 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_2445 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_2446 = v_s_2445;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str3), v_t_2446, NTAG(TAG_Nothing)});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tr(heff_call(heff_take_field(v_hd_2442, 2), 1, (V[]){v_t_2449}));
  V f_ = heff_get_n(v_hd_2442, 1, 3);
  args[0] = v_t_2450;
  args[1] = v_k2_2443;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam4(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k2_2455 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_2457 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_2458 = v_s_2457;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str4), v_t_2458, NTAG(TAG_Nothing)});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tr(heff_call(heff_take_field(v_hd_2454, 2), 1, (V[]){v_t_2461}));
  V f_ = heff_get_n(v_hd_2454, 1, 3);
  args[0] = v_t_2462;
  args[1] = v_k2_2455;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam5(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k2_2465 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2468;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_2467 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_2468 = v_s_2467;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str5), v_t_2468, NTAG(TAG_Nothing)});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tr(heff_call(heff_take_field(v_hd_2464, 2), 1, (V[]){v_t_2471}));
  V f_ = heff_get_n(v_hd_2464, 1, 3);
  args[0] = v_t_2472;
  args[1] = v_k2_2465;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam6(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k2_2476 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2479;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_2478 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_2479 = v_s_2478;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2480 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str6), v_t_2479, NTAG(TAG_Nothing)});
  V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tr(heff_call(heff_take_field(v_hd_2475, 2), 1, (V[]){v_t_2482}));
  V f_ = heff_get_n(v_hd_2475, 1, 3);
  args[0] = v_t_2483;
  args[1] = v_k2_2476;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam7(V self, V *args) {
  V v_hd_2486 = args[0];
  V v_k2_2487 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2490;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_2489 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_2490 = v_s_2489;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2491 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str7), v_t_2490, NTAG(TAG_Nothing)});
  V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tr(heff_call(heff_take_field(v_hd_2486, 2), 1, (V[]){v_t_2493}));
  V f_ = heff_get_n(v_hd_2486, 1, 3);
  args[0] = v_t_2494;
  args[1] = v_k2_2487;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam8(V self, V *args) {
  V v_hd_2497 = args[0];
  V v_k2_2498 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24101;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_24100 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_24101 = v_s_24100;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_24102 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str8), v_t_24101, NTAG(TAG_Nothing)});
  V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24102})});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tr(heff_call(heff_take_field(v_hd_2497, 2), 1, (V[]){v_t_24104}));
  V f_ = heff_get_n(v_hd_2497, 1, 3);
  args[0] = v_t_24105;
  args[1] = v_k2_2498;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam9(V self, V *args) {
  V v_hd_24106 = args[0];
  V v_k2_24107 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24110;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_24109 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_24110 = v_s_24109;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_24111 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str9), v_t_24110, NTAG(TAG_Nothing)});
  V v_t_24112 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
  V v_t_24114 = heff_tr(heff_call(heff_take_field(v_hd_24106, 2), 1, (V[]){v_t_24113}));
  V f_ = heff_get_n(v_hd_24106, 1, 3);
  args[0] = v_t_24114;
  args[1] = v_k2_24107;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchSyn_lam10(V self, V *args) {
  V v_hd_24116 = args[0];
  V v_k2_24117 = args[1];
  V v_w_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24120;
  switch (heff_tag_of(v_w_240)) {
  case TAG_At: {
    V v_s_24119 = heff_field(v_w_240, 1);
    heff_take_n(v_w_240, 2ULL, 2);
    v_t_24120 = v_s_24119;
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_24121 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2ewatchSyn_str10), v_t_24120, NTAG(TAG_Nothing)});
  V v_t_24122 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24121})});
  V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
  V v_t_24124 = heff_tr(heff_call(heff_take_field(v_hd_24116, 2), 1, (V[]){v_t_24123}));
  V f_ = heff_get_n(v_hd_24116, 1, 3);
  args[0] = v_t_24124;
  args[1] = v_k2_24117;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabWatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabWatch_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eelabWatch(V v_g_240, V v_n_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_242));
    v_t_245 = heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_243});
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_c_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2eelab_2etoplevel_2ewatchSyn(a_0)); heff_drop(v_t_245); r_; });
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_lam0, 2, 3, (V[]){v_c_246, v_g_240, v_n_241});
}
V g_heff_2eelab_2etoplevel_2eelabWatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eelabWatch(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2415 = heff_field(v_n_241, 1);
    heff_take_n(v_n_241, 2ULL, 2);
    v_t_2416 = v_s_2415;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  return ({ V a_0 = v_g_240; V a_1 = v_t_2416; V a_2 = v_x_2413; V a_3 = v_hd_247; V a_4 = v_k_248; V r_ = (g_heff_2eelab_2etoplevel_2ewatchPhase(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2413); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2412;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkSyn: {
    V v_f_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2411 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_240), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2412 = heff_tr(heff_call(v_f_2410, 1, (V[]){v_t_2411}));
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_lam2, 1, 4, (V[]){v_n_241, v_g_240, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabWatch_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_lam1, 1, 4, (V[]){v_g_240, v_hd_247, v_n_241, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewithInstance_str0, 0, "");
Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithInstance_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ewithInstance(V v_isInstance_240, V v_key_241, V v_name_242, V v_g_243) {
top: ;
  if ((heff_dup(v_isInstance_240) == NTAG(TAG_True))) {
    V v_t_246;
    if (heff_strEq_c_lent(v_key_241, v_name_242, 0)) {
      v_t_246 = ((V)&g_heff_2eelab_2etoplevel_2ewithInstance_str0);
    } else {
      int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_key_241, 0)) - heff_unbox_word(heff_strLength_lent(v_name_242, 0)));
      v_t_246 = heff_strSlice_lent(v_key_241, MK_INT(0LL), heff_box_word((v_t_245 - ((int64_t)1ULL))), 6);
    }
    V v_t_247 = (g_list_2ekeepIf_24s522699319x1190492156(v_key_241, heff_take_field(v_g_243, 7)));
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_key__module, (V[]){v_key_241, v_t_246}), v_t_247});
    return ({ V rv_7 = v_t_248; V rr_ = heff_rec_reuse_nf(v_g_243, 127ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  } else {
    V v_t_249 = (g_list_2eany_24s1868716698x184030185(v_key_241, heff_rfield(v_g_243, 7)));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_t_2410 = ({ V a_0 = v_key_241; V a_1 = heff_take_field(v_g_243, 7); V r_ = (g_list_2ekeepIf_24s522699319x1190492156(a_0, a_1)); heff_drop(v_key_241); r_; });
      return ({ V rv_7 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_g_243, 127ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
    } else {
      heff_drop(v_key_241);
      heff_drop(v_t_249);
      return v_g_243;
    }
  }
}
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2ewithInstance(a0, a[1], a2, a[3]); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2etoplevel_2eonceEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eonceEach_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eonceEach(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seen_240);
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_list_2eany_24s992013231x1460818112(heff_dup(v_d_242), v_seen_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_d_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_seen_240;
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_d_242, v_seen_240});
      V t_1 = v_rest_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2eonceEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eonceEach(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(V v_acc_240, V v_n_241, V v_diags_242) {
top: ;
  V v_t_2425;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_243 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_x11_243)) {
    case TAG_DeclEquations: {
      V v_f_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 5);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_f_245});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2410 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 5);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2410});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2415 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 4);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2415});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2419 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 3);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2419});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2422 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 2);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2422});
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_243, 0ULL, 1);
      v_t_2425 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_243);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_t_2425)) {
  case TAG_Nothing: {
    heff_drop(v_n_241);
    return ({ V rv_1 = v_diags_242; V rr_ = heff_rec_reuse_nf(v_acc_240, 509ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Just: {
    V v_x_2426 = heff_field(v_t_2425, 0);
    heff_take_n(v_t_2425, 1ULL, 1);
    V v_g_2431;
    if (heff_strEq_c_lent(v_x_2426, v_x_2426, 0)) {
      v_g_2431 = heff_dup(heff_rfield(v_acc_240, 0));
    } else {
      V v_g_2428 = heff_dup(heff_rfield(v_acc_240, 0));
      V v_t_2429 = (g_std_2emap_2edelete_24s1614046289x1611773644(heff_take_field(v_g_2428, 4), v_x_2426));
      V v_t_2430 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_g_2428, 2), heff_dup(v_x_2426), heff_dup(v_x_2426)));
      v_g_2431 = ({ V rv_2 = v_t_2430; V rv_4 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_g_2428, 235ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 64719u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 4) = rv_4; rr_; });
    }
    V v_t_2432 = (g_std_2emap_2einsert_24s93785294x875597928(heff_take_field(v_g_2431, 3), heff_dup(v_x_2426), NTAG(TAG_MkUnit)));
    V v_t_2433 = ({ V rv_3 = v_t_2432; V rr_ = heff_rec_reuse_nf(v_g_2431, 247ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 65343u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    V v_globals_2434 = (g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720(heff_dup(v_n_241), v_t_2433));
    V v_t_2437;
    switch (heff_tag_of(v_n_241)) {
    case TAG_At: {
      V v_s_2436 = heff_field(v_n_241, 1);
      heff_take_n(v_n_241, 2ULL, 2);
      v_t_2437 = v_s_2436;
      break;
    }
    default: heff_nomatch(v_n_241);
    }
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2426, v_t_2437}), heff_take_field(v_acc_240, 3)});
    return ({ V rv_0 = v_globals_2434; V rv_1 = v_diags_242; V rv_3 = v_t_2438; V rr_ = heff_rec_reuse_nf(v_acc_240, 500ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 261936u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  default: return heff_nomatch(v_t_2425);
  }
}
V g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopBroken_24s792927224x1785429591(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam5, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam6(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam6, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam7(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam7, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam8(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam8, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(V v_g_240, V v_n_241, V v_st_242) {
top: ;
  V v_c_246;
  switch (heff_tag_of(v_st_242)) {
  case TAG_MkSt: {
    V v_c_243 = heff_dup(heff_field(v_st_242, 0));
    v_c_246 = v_c_243;
    break;
  }
  default: heff_nomatch(v_st_242);
  }
  V v_c_247 = (g_heff_2eelab_2etoplevel_2edeclJ(v_n_241));
  V v_t_2412;
  switch (heff_tag_of(v_st_242)) {
  case TAG_MkSt: {
    V v_d_249 = heff_field(v_st_242, 1);
    V v_w_2410 = heff_field(v_st_242, 2);
    V v_ru_24st_242_24MkSt = heff_take_reuse_n(v_st_242, 6ULL, 3);
    V v_t_2411 = ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_c_246, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
    v_t_2412 = heff_tag_at_n(v_ru_24st_242_24MkSt, TAG_MkSt, 3, (V[]){v_t_2411, v_d_249, v_w_2410});
    break;
  }
  default: heff_nomatch(v_st_242);
  }
  return heff_tail(v_c_247, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0, 1, 2, (V[]){v_g_240, v_n_241}), v_t_2412});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  heff_drop(v_hd_2439);
  V f_ = v_k_2440;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam5(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  heff_drop(v_hd_2445);
  V f_ = v_k_2446;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam6(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  heff_drop(v_hd_2450);
  V f_ = v_k_2451;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam7(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  heff_drop(v_hd_2454);
  V f_ = v_k_2455;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam8(V self, V *args) {
  V v_hd_2457 = args[0];
  V v_k_2458 = args[1];
  heff_drop(v_hd_2457);
  V f_ = v_k_2458;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam9(V self, V *args) {
  V v_x_2460 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_x_2418 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2460);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_clo);
  heff_room[0] = v_g_240;
  heff_room[1] = v_n_241;
  heff_room[2] = v_x_2413;
  heff_room[3] = v_x_2418;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_z_2420 = args[1];
  V v_n_241 = heff_env(self)[0];
  V v_x_2418 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2419);
  V v_c_2459;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_2421 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_x11_2421)) {
    case TAG_DeclEquations: {
      V v_x113_2425 = heff_field(v_x11_2421, 2);
      V v_tyN_2426 = heff_field(v_x11_2421, 3);
      heff_take_n(v_x11_2421, 12ULL, 5);
      switch (heff_tag_of(v_x113_2425)) {
      case TAG_AsDefinition: {
        heff_drop(v_tyN_2426);
        v_c_2459 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam3_clo);
        break;
      }
      case TAG_AsInstance: {
        V v_t_2432;
        switch (heff_tag_of(v_tyN_2426)) {
        case TAG_At: {
          V v_s_2431 = heff_field(v_tyN_2426, 1);
          heff_take_n(v_tyN_2426, 2ULL, 2);
          v_t_2432 = v_s_2431;
          break;
        }
        default: heff_nomatch(v_tyN_2426);
        }
        V v_t_2433 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(heff_dup(heff_rfield(v_x_2418, 0))));
        v_c_2459 = (g_heff_2eelab_2etoplevel_2esearchedInstance(v_t_2432, NTAG(TAG_Nil), MK_INT(0LL), v_t_2433));
        break;
      }
      default: heff_nomatch(v_x113_2425);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2421, 0ULL, 5);
      v_c_2459 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam4_clo);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2421, 0ULL, 4);
      v_c_2459 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam5_clo);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2421, 0ULL, 3);
      v_c_2459 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam6_clo);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2421, 0ULL, 2);
      v_c_2459 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam7_clo);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2421, 0ULL, 1);
      v_c_2459 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam8_clo);
      break;
    }
    default: heff_nomatch(v_x11_2421);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V f_ = v_c_2459;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam9, 1, 4, (V[]){v_g_240, v_n_241, v_x_2413, v_x_2418});
  heff_room[2] = v_z_2420;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo);
  args[0] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam2, 2, 4, (V[]){v_n_241, v_x_2418, v_g_240, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_dup(heff_rfield(v_x_2413, 1));
  V v_c_2417;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_MkTyp: {
    V v_f_2415 = heff_field(v_t_2414, 0);
    heff_take_n(v_t_2414, 1ULL, 1);
    V v_t_2416 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_240), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2417 = heff_tr(heff_call(v_f_2415, 1, (V[]){v_t_2416}));
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s1502442182x2070851910_lam1, 1, 3, (V[]){v_n_241, v_g_240, v_x_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}