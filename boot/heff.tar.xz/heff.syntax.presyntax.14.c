// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_ELocal 42997
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_EndJump 17665
#define TAG_EndValue 24675
#define TAG_IsInferable 49402
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_guard 300063423
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_pure 9948095
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_stmts 311127493
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s301034265x1732874986_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryIn(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_clo;
HeffT1 g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2edoT_get(void);
V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902(V);
V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2efieldSetAcc_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
V g_heff_2esyntax_2epresyntax_2eifOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eifOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eifOf_clo;
V g_heff_2esyntax_2epresyntax_2eisMadeName(V);
V g_heff_2esyntax_2epresyntax_2eisMadeName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisMadeName_clo;
V g_heff_2esyntax_2epresyntax_2ejumpCall(V, V, V);
V g_heff_2esyntax_2epresyntax_2ejumpCall_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpCall_clo;
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(V, V);
V g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760_clo;
V g_heff_2esyntax_2epresyntax_2eleaving(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eleaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eleaving_clo;
V g_heff_2esyntax_2epresyntax_2eliftE(V, V, V);
V g_heff_2esyntax_2epresyntax_2eliftE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eliftE_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
V g_heff_2esyntax_2epresyntax_2emadeNameSaid(V);
V g_heff_2esyntax_2epresyntax_2emadeNameSaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2emadeNameSaid_clo;
V g_heff_2esyntax_2epresyntax_2estmtT(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_heff_2esyntax_2epresyntax_2ewhileT(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileT_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileT_clo;
V g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_clo;
HeffT4 g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240(V, V);
V g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_clo;
HeffT4 g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(V v_lit_240, V v_st_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((HeffT2){{v_st_241, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2esyntax_2epresyntax_2efieldSetAcc_24cpr(heff_dup(v_lit_240), v_st_241, v_x_243));
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_st_248 = v_field_246;
      V v_y_249 = v_field_247;
      HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24cpr(v_lit_240, v_st_248, v_xs_244));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x_2413 = v_field_2411;
        V v_y_2414 = v_field_2412;
        return ((HeffT2){{v_x_2413, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_249, v_y_2414})}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s301034265x1732874986_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        heff_take_n(v_a_244, 3ULL, 2);
        V v_a_248;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_248 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_248 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_247)));
        }
        HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eaccList_24s301034265x1732874986_24cpr(v_a_248, v_xs_243));
        {
          V v_field_2410 = v_t_249.f[0];
          V v_field_2411 = v_t_249.f[1];
          V v_x_2412 = v_field_2410;
          V v_y_2413 = v_field_2411;
          V v_t_2414 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_a_246, v_a_247}), v_a_245});
          return ((HeffT2){{v_x_2412, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2414, v_y_2413})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eliftE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eliftE_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2eliftE(V v_l_240, V v_acc_241, V v_e_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(v_l_240, v_acc_241, v_e_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2epresyntax_2eliftE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eliftE(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_str0, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_str1, 5, "after");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_str2, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_str3, 4, "loop");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_str4, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_str5, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2ewhileT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewhileT_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2ewhileT(V v_t_240, V v_cx_241, V v_sp_242, V v_c_243, V v_body_244, V v_rest_245, V v_end_246) {
top: ;
  HeffT4 v_t_247 = (g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240_24cpr(heff_dup(v_sp_242), heff_dup(v_cx_241)));
  V v_t_2417;
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_field_2410 = v_t_247.f[2];
    heff_drop(v_t_247.f[3]);
    V v_vars_2412 = v_field_249;
    V v_t_2416;
    if ((heff_dup(v_field_2410) == NTAG(TAG_True))) {
      heff_drop(v_field_2410);
      switch (heff_tag_of(v_vars_2412)) {
      case TAG_Nil: {
        V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewhileT_str0)}), heff_dup(v_sp_242)});
        v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        v_t_2416 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_2412));
        break;
      }
      default: heff_nomatch(v_vars_2412);
      }
    } else {
      heff_drop(v_field_2410);
      v_t_2416 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_2412));
    }
    v_t_2417 = (g_heff_2esyntax_2epresyntax_2eapp(v_field_248, v_t_2416));
  }
  V v_t_2418 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
  V v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_str1), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_str2), v_t_2418));
  V v_t_2420 = ({ V a_0 = heff_dup(v_sp_242); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_241, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_t_240, 0)), 3, (V[]){heff_dup(v_cx_241), v_rest_245, v_end_246}));
  V v_t_2422 = (g_heff_2esyntax_2epresyntax_2elocalFun(v_t_2419, heff_dup(v_sp_242), v_t_2420, v_t_2421));
  V v_t_2423 = heff_intShow(heff_dup(heff_rfield(v_sp_242, 0)));
  V v_t_2424 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_str3), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_str4), v_t_2423));
  V v_t_2425 = ({ V a_0 = heff_dup(v_sp_242); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_241, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2426 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_False)});
  HeffT2 v_t_2427 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_241), v_t_2426}), NTAG(TAG_Nil), v_c_243));
  V v_t_2450;
  {
    V v_field_2428 = v_t_2427.f[0];
    V v_field_2429 = v_t_2427.f[1];
    V v_x_2430 = v_field_2428;
    V v_y_2431 = v_field_2429;
    V v_cont_2432 = (g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240(heff_dup(v_sp_242), heff_dup(v_cx_241)));
    V v_brk_2433 = (g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241(heff_dup(v_sp_242), heff_dup(v_cx_241)));
    V v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_cont_2432, v_brk_2433})});
    V v_t_2435 = heff_rec_n(5, shape_names__muts__loop__sp__depth, (V[]){heff_dup(heff_rfield(v_cx_241, 0)), heff_dup(heff_rfield(v_cx_241, 1)), v_t_2434, heff_dup(heff_rfield(v_cx_241, 3)), heff_dup(heff_rfield(v_cx_241, 4))});
    V v_t_2436 = (g_heff_2esyntax_2epresyntax_2ewhileT_2eloopJ_240(heff_dup(v_sp_242), heff_dup(v_cx_241)));
    V v_t_2437 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 3, (V[]){v_t_2435, v_body_244, heff_tag_n(TAG_EndJump, 1, (V[]){v_t_2436})}));
    HeffT4 v_t_2438 = (g_heff_2esyntax_2epresyntax_2ewhileT_2eafterJ_241_24cpr(heff_dup(v_sp_242), heff_dup(v_cx_241)));
    V v_t_2448;
    {
      V v_field_2439 = v_t_2438.f[0];
      V v_field_2440 = v_t_2438.f[1];
      V v_field_2441 = v_t_2438.f[2];
      heff_drop(v_t_2438.f[3]);
      V v_vars_2443 = v_field_2440;
      V v_t_2447;
      if ((heff_dup(v_field_2441) == NTAG(TAG_True))) {
        heff_drop(v_field_2441);
        switch (heff_tag_of(v_vars_2443)) {
        case TAG_Nil: {
          V v_t_2444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewhileT_str5)}), heff_dup(v_sp_242)});
          v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2444, NTAG(TAG_Nil)});
          break;
        }
        case TAG_Cons: {
          v_t_2447 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_2443));
          break;
        }
        default: heff_nomatch(v_vars_2443);
        }
      } else {
        heff_drop(v_field_2441);
        v_t_2447 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_242), v_vars_2443));
      }
      v_t_2448 = (g_heff_2esyntax_2epresyntax_2eapp(v_field_2439, v_t_2447));
    }
    V v_t_2449 = (g_heff_2esyntax_2epresyntax_2eifOf(heff_dup(v_sp_242), v_y_2431, v_t_2437, v_t_2448));
    v_t_2450 = ({ V a_0 = v_cx_241; V a_1 = v_x_2430; V a_2 = v_t_2449; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2430); r_; });
  }
  V v_t_2451 = (g_heff_2esyntax_2epresyntax_2elocalFun(v_t_2424, heff_dup(v_sp_242), v_t_2425, v_t_2450));
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
  V v_t_2453 = heff_tag_n(TAG_ELocal, 2, (V[]){v_t_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2452})});
  return heff_tag_n(TAG_At, 2, (V[]){v_t_2453, v_sp_242});
}
V g_heff_2esyntax_2epresyntax_2ewhileT_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewhileT(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_str0, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V v_cx_240, V v_x3_241, V v_end_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_sp_243 = heff_dup(heff_rfield(v_cx_240, 3));
    switch (heff_tag_of(v_end_242)) {
    case TAG_EndValue: {
      V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 1, 2);
      V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_244}), heff_dup(v_sp_243)});
      V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_str0)}), heff_dup(v_sp_243)});
      V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
      V v_t_248 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_245, v_t_247));
      return (g_heff_2esyntax_2epresyntax_2eleaving(heff_dup(v_cx_240), v_sp_243, heff_get_n(v_cx_240, 4, 5), v_t_248));
    }
    case TAG_EndJump: {
      V v_j_249 = heff_field(v_end_242, 0);
      heff_take_n(v_end_242, 1ULL, 1);
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2ejumpCall(v_cx_240, v_sp_243, v_j_249);
    }
    default: return heff_nomatch(v_end_242);
    }
  }
  case TAG_Cons: {
    V v_s_2410 = heff_field(v_x3_241, 0);
    V v_x32_2411 = heff_field(v_x3_241, 1);
    switch (heff_tag_of(v_x32_2411)) {
    case TAG_Nil: {
      switch (heff_tag_of(v_end_242)) {
      case TAG_EndValue: {
        return (g_heff_2esyntax_2epresyntax_2elastT_24s1191919014x71621760(v_cx_240, heff_dup(v_s_2410)));
      }
      case TAG_EndJump: {
        return (g_heff_2esyntax_2epresyntax_2estmtT(heff_dup(g_heff_2esyntax_2epresyntax_2edoT_get()), v_cx_240, heff_dup(v_s_2410), heff_dup(v_x32_2411), v_end_242));
      }
      default: return heff_nomatch(v_end_242);
      }
    }
    case TAG_Cons: {
      return (g_heff_2esyntax_2epresyntax_2estmtT(heff_dup(g_heff_2esyntax_2epresyntax_2edoT_get()), v_cx_240, heff_dup(v_s_2410), heff_dup(v_x32_2411), v_end_242));
    }
    default: return heff_nomatch(v_x32_2411);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryIn_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryIn(V v_r_240, V v_asBits_241, V v_segs_242, V v_sp_243) {
top: ;
  HeffT1 v_t_244 = (g_heff_2esyntax_2epresyntax_2ebinaryIn_24cpr(v_r_240, v_asBits_241, v_segs_242, v_sp_243));
  {
    V v_field_245 = v_t_244.f[0];
    return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_245});
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2ebinaryIn(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkEquation: {
      V v_f_243 = heff_field(v_x21_241, 0);
      V v_fsp_244 = heff_field(v_x21_241, 1);
      V v_ps_245 = heff_field(v_x21_241, 2);
      V v_rhs_246 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24MkEquation = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      HeffT2 v_t_247 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_rhs_246));
      V v_t_2421;
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V v_c_2411 = v_field_249;
          v_t_2421 = v_c_2411;
        } else {
          if ((v_tag_248 == ((int64_t)1ULL))) {
            V v_i_2413 = v_field_249;
            V v_t_2416;
            switch (heff_tag_of(v_i_2413)) {
            case TAG_At: {
              V v_s_2415 = heff_dup(heff_field(v_i_2413, 1));
              v_t_2416 = v_s_2415;
              break;
            }
            default: heff_nomatch(v_i_2413);
            }
            v_t_2421 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2413}), v_t_2416});
          } else {
            V v_t_2417 = v_field_249;
            V v_t_2420;
            switch (heff_tag_of(v_t_2417)) {
            case TAG_At: {
              V v_s_2419 = heff_dup(heff_field(v_t_2417, 1));
              v_t_2420 = v_s_2419;
              break;
            }
            default: heff_nomatch(v_t_2417);
            }
            v_t_2421 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2417}), v_t_2420});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_243, v_fsp_244, v_ps_245, v_t_2421}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eequationOf_24s425549632x347211902(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str0, 7, "#mutual");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str1, 4, "#arg");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str2, 1, "x");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str3, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str4, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str5, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str6, 7, "Mutual#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str7, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2emadeNameSaid_str8, 1, " ");
Clo g_heff_2esyntax_2epresyntax_2emadeNameSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2emadeNameSaid_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2emadeNameSaid(V v_x_240) {
top: ;
  V v_x1_241 = (g_heff_2esyntax_2epresyntax_2eisMadeName(v_x_240));
  if ((heff_dup(v_x1_241) == NTAG(TAG_True))) {
    heff_drop(v_x1_241);
    int64_t v_t_242 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)7ULL));
    V v_t_243 = heff_strSlice(heff_dup(v_x_240), heff_box_word(v_t_242), heff_strLength_lent(v_x_240, 0));
    if (heff_strEq_c(v_t_243, ((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str0))) {
      int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)7ULL));
      return heff_strSlice(v_x_240, MK_INT(0LL), heff_box_word(v_t_245));
    } else {
      int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)4ULL));
      V v_t_247 = heff_strSlice(heff_dup(v_x_240), heff_box_word(v_t_246), heff_strLength_lent(v_x_240, 0));
      if (heff_strEq_c(v_t_247, ((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str1))) {
        heff_drop(v_x_240);
        return ((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str2);
      } else {
        if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str3), v_x_240, MK_INT(0LL), 5))) {
          V v_j_2410 = heff_strFind_lent(((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str4), v_x_240, MK_INT(0LL), 5);
          if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
            heff_drop(v_j_2410);
            return v_x_240;
          } else {
            V v_t_2412 = heff_strSlice(heff_dup(v_x_240), heff_intAdd(heff_dup(v_j_2410), MK_INT(1LL)), heff_strLength_lent(v_x_240, 0));
            return heff_strAppend(heff_strSlice(v_x_240, MK_INT(0LL), v_j_2410), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str5), v_t_2412));
          }
        } else {
          if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str6), v_x_240, MK_INT(0LL), 5))) {
            V v_j_2414 = heff_strFind_lent(((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str7), v_x_240, MK_INT(0LL), 5);
            if (heff_intLt_c_lent(v_j_2414, MK_INT(0LL), 2)) {
              heff_drop(v_j_2414);
              return v_x_240;
            } else {
              V v_t_2416 = heff_strSlice(heff_dup(v_x_240), heff_intAdd(heff_dup(v_j_2414), MK_INT(1LL)), heff_strLength_lent(v_x_240, 0));
              return heff_strAppend(heff_strSlice(v_x_240, MK_INT(0LL), v_j_2414), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2emadeNameSaid_str8), v_t_2416));
            }
          } else {
            return v_x_240;
          }
        }
      }
    }
  } else {
    heff_drop(v_x1_241);
    return v_x_240;
  }
}
V g_heff_2esyntax_2epresyntax_2emadeNameSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2emadeNameSaid(a[0]);
}