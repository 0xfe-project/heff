// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Ok 9325
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_fixed 298804110
#define LBL_op 10312
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
V g_heff_2ecompile_2einterp_2ebytesJoined(V, V);
V g_heff_2ecompile_2einterp_2ebytesJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesJoined_clo;
V g_heff_2ecompile_2einterp_2ebytesOfNat(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfNat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfNat_clo;
V g_heff_2ecompile_2einterp_2eevalFields(V, V, V);
V g_heff_2ecompile_2einterp_2eevalFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalFields_clo;
V g_heff_2ecompile_2einterp_2efixedInt1(V, V, V);
V g_heff_2ecompile_2einterp_2efixedInt1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedInt1_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get(void);
V g_heff_2ecompile_2einterp_2efromListV(V, V);
V g_heff_2ecompile_2einterp_2efromListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efromListV_clo;
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotBytes_get(void);
HeffT2 g_heff_2ecompile_2einterp_2enthTh_24cpr(V, V);
double g_heff_2ecompile_2einterp_2etwoToF_w(V);
V g_heff_2ecompile_2einterp_2etwoToF(V);
V g_heff_2ecompile_2einterp_2etwoToF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoToF_clo;
V g_heff_2eelab_2efixed_2efixedMin(V);
V g_heff_2eelab_2efixed_2efixedMin_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMin_clo;
V g_heff_2eelab_2efixed_2efixedPrimName(V);
V g_heff_2eelab_2efixed_2efixedPrimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimName_clo;
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
Clo g_heff_2ecompile_2einterp_2ebytesJoined_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebytesJoined_entry, 2, 0};

V g_heff_2ecompile_2einterp_2ebytesJoined(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_acc_241})});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_VFun: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_b_2414 = heff_field(v_x11_242, 0);
      V t_0 = v_rest_243;
      V t_1 = heff_strAppend(v_acc_241, heff_dup(v_b_2414));
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_VBits: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2ebytesJoined_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2ebytesJoined(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2einterp_2ebytesOfNat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebytesOfNat_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ebytesOfNat(V v_box_24k_240, V v_u_241, V v_acc_242) {
  int64_t v_k_240 = heff_unbox_word(v_box_24k_240);
top: ;
  if ((v_k_240 <= ((int64_t)0ULL))) {
    heff_drop(v_u_241);
    return v_acc_242;
  } else {
    uint8_t v_t_243 = heff_from_int_u8(heff_intMod(heff_dup(v_u_241), MK_INT(256LL)));
    V v_t_244 = heff_strAppend(heff_strFromByte(heff_box_u8(v_t_243)), v_acc_242);
    int64_t t_0 = (v_k_240 - ((int64_t)1ULL));
    V t_1 = heff_intDiv(v_u_241, MK_INT(256LL));
    V t_2 = v_t_244;
    v_k_240 = t_0;
    v_u_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2einterp_2ebytesOfNat_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebytesOfNat(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2etwoToF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2etwoToF_entry, 1, 0};

double g_heff_2ecompile_2einterp_2etwoToF_w(V v_box_24k_240) {
  int64_t v_k_240 = heff_unbox_word(v_box_24k_240);
top: ;
  if ((v_k_240 == ((int64_t)0ULL))) {
    return (1.0);
  } else {
    if ((((int64_t)0ULL) < v_k_240)) {
      double v_t_241 = (g_heff_2ecompile_2einterp_2etwoToF_w(heff_box_word((v_k_240 - ((int64_t)1ULL)))));
      return ((2.0) * v_t_241);
    } else {
      double v_t_242 = (g_heff_2ecompile_2einterp_2etwoToF_w(heff_box_word((v_k_240 + ((int64_t)1ULL)))));
      return ((0.5) * v_t_242);
    }
  }
}
V g_heff_2ecompile_2einterp_2etwoToF(V v_box_24k_240) {
  return heff_box_f64((g_heff_2ecompile_2einterp_2etwoToF_w(v_box_24k_240)));
}
V g_heff_2ecompile_2einterp_2etwoToF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2etwoToF(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2efromListV_str0, 4, "Cons");
Clo g_heff_2ecompile_2einterp_2efromListV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efromListV_entry, 2, 0};

V g_heff_2ecompile_2einterp_2efromListV(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VTag: {
    V v_x11_244 = heff_field(v_x1_240, 0);
    V v_x12_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24VTag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(v_x11_244, ((V)&g_heff_2ecompile_2einterp_2efromListV_str0))) {
      switch (heff_tag_of(v_x12_245)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
        HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
      }
      case TAG_Cons: {
        V v_x_246 = heff_field(v_x12_245, 0);
        V v_x122_247 = heff_field(v_x12_245, 1);
        heff_take_n(v_x12_245, 3ULL, 2);
        switch (heff_tag_of(v_x122_247)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
          heff_drop(v_x_246);
          HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
        }
        case TAG_Cons: {
          V v_rest_248 = heff_field(v_x122_247, 0);
          V v_x1222_249 = heff_field(v_x122_247, 1);
          heff_take_n(v_x122_247, 3ULL, 2);
          switch (heff_tag_of(v_x1222_249)) {
          case TAG_Nil: {
            V t_0 = v_rest_248;
            V t_1 = heff_tag_at_n(v_ru_24x1_240_24VTag, TAG_Cons, 2, (V[]){v_x_246, v_acc_241});
            v_x1_240 = t_0;
            v_acc_241 = t_1;
            goto top;
          }
          case TAG_Cons: {
            heff_take_n(v_x1222_249, 0ULL, 2);
            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
            heff_drop(v_x_246);
            heff_drop(v_rest_248);
            HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
          }
          default: return heff_nomatch(v_x1222_249);
          }
        }
        default: return heff_nomatch(v_x122_247);
        }
      }
      default: return heff_nomatch(v_x12_245);
      }
    } else {
      heff_drop(v_x12_245);
      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
      HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
    }
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VBits: {
    heff_take_n(v_x1_240, 0ULL, 2);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VErased: {
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2efromListV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efromListV(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str0, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str1, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str2, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str3, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str4, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str5, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str6, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str7, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str8, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str9, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str10, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str11, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str12, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str13, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str14, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str15, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str16, 13, "no primitive ");
Clo g_heff_2ecompile_2einterp_2efixedInt1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efixedInt1_entry, 3, 0};

V g_heff_2ecompile_2einterp_2efixedInt1(V v_w_240, V v_op_241, V v_a_242) {
top: ;
  switch (heff_tag_of(v_op_241)) {
  case TAG_OpAdd: {
    heff_drop(v_a_242);
    V v_t_243 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str0), v_t_243)});
  }
  case TAG_OpSub: {
    heff_drop(v_a_242);
    V v_t_244 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str1), v_t_244)});
  }
  case TAG_OpMul: {
    heff_drop(v_a_242);
    V v_t_245 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str2), v_t_245)});
  }
  case TAG_OpDiv: {
    heff_drop(v_a_242);
    V v_t_246 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str3), v_t_246)});
  }
  case TAG_OpRem: {
    heff_drop(v_a_242);
    V v_t_247 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str4), v_t_247)});
  }
  case TAG_OpEq: {
    heff_drop(v_a_242);
    V v_t_248 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str5), v_t_248)});
  }
  case TAG_OpLt: {
    heff_drop(v_a_242);
    V v_t_249 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str6), v_t_249)});
  }
  case TAG_OpLe: {
    heff_drop(v_a_242);
    V v_t_2410 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str7), v_t_2410)});
  }
  case TAG_OpAnd: {
    heff_drop(v_a_242);
    V v_t_2411 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str8), v_t_2411)});
  }
  case TAG_OpOr: {
    heff_drop(v_a_242);
    V v_t_2412 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str9), v_t_2412)});
  }
  case TAG_OpXor: {
    heff_drop(v_a_242);
    V v_t_2413 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str10), v_t_2413)});
  }
  case TAG_OpShl: {
    heff_drop(v_a_242);
    V v_t_2414 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str11), v_t_2414)});
  }
  case TAG_OpShr: {
    heff_drop(v_a_242);
    V v_t_2415 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str12), v_t_2415)});
  }
  case TAG_OpShow: {
    heff_drop(v_w_240);
    V v_t_2416 = heff_tag_n(TAG_VStr, 1, (V[]){heff_intShow(v_a_242)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2416});
  }
  case TAG_OpFromInt: {
    V v_t_2417 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
    V v_t_2418 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
    V v_t_2419;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2419 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2419 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2419 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2419 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2419 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2419 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2419 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2419 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2419 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2420 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2419));
    V v_t_2421 = heff_intMod(heff_intSub(v_a_242, v_t_2418), v_t_2420);
    V v_t_2422 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2417, v_t_2421)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2422});
  }
  case TAG_OpToInt: {
    heff_drop(v_w_240);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_242})});
  }
  case TAG_OpSqrt: {
    heff_drop(v_a_242);
    V v_t_2423 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str13), v_t_2423)});
  }
  case TAG_OpFromFloat: {
    heff_drop(v_a_242);
    V v_t_2424 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str14), v_t_2424)});
  }
  case TAG_OpToFloat: {
    heff_drop(v_a_242);
    V v_t_2425 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str15), v_t_2425)});
  }
  case TAG_OpFloor: {
    heff_drop(v_a_242);
    V v_t_2426 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str16), v_t_2426)});
  }
  default: return heff_nomatch(v_op_241);
  }
}
V g_heff_2ecompile_2einterp_2efixedInt1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efixedInt1(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_st;
static V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_st)) return g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_val;
  return heff_global(&g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_val, &g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_st, g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_init);
}
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VFloat: {
        double v_a_2413 = heff_tflat_f64(v_v_245, 0);
        heff_take_na(v_v_245, 0ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VFloat: {
          double v_b_2419 = heff_tflat_f64(v_v_247, 0);
          heff_take_na(v_v_247, 0ULL, 1);
          V v_t_2420 = heff_tag_at_nf(v_ru_24x1_246_24Ok, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(pow(v_a_2413, v_b_2419))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam1, 2, 1, (V[]){v_a_241})})});
}

HeffT2 g_heff_2ecompile_2einterp_2enthTh_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop(v_x_242);
      if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        heff_drop(v_xs_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2einterp_2eevalFields_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eevalFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eevalFields_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eevalFields(V v_ev_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ev_240);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_l_245 = heff_field(v_x21_243, 0);
      V v_t_246 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      V v_x1_247 = heff_tr(heff_call(heff_dup(v_ev_240), 1, (V[]){v_t_246}));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Ok: {
        V v_v_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V t_0 = v_ev_240;
        V t_1 = v_rest_244;
        V t_2 = heff_clo_n(g_heff_2ecompile_2einterp_2eevalFields_lam0, 1, 3, (V[]){v_l_245, v_v_248, v_k_242});
        v_ev_240 = t_0;
        v_x2_241 = t_1;
        v_k_242 = t_2;
        goto top;
      }
      case TAG_Abn: {
        heff_drop(v_ev_240);
        heff_drop(v_k_242);
        heff_drop(v_rest_244);
        heff_drop(v_l_245);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_ev_240);
        heff_drop(v_k_242);
        heff_drop(v_rest_244);
        heff_drop(v_l_245);
        return NTAG(TAG_Div);
      }
      case TAG_Bug: {
        V v_what_2411 = heff_field(v_x1_247, 0);
        V v_ru_24x1_247_24Bug = heff_take_reuse_n(v_x1_247, 1ULL, 1);
        heff_drop(v_ev_240);
        heff_drop(v_k_242);
        heff_drop(v_rest_244);
        heff_drop(v_l_245);
        return heff_tag_at_n(v_ru_24x1_247_24Bug, TAG_Bug, 1, (V[]){v_what_2411});
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2eevalFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eevalFields(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2einterp_2eevalFields_lam0(V self, V *args) {
  V v_vs_249 = args[0];
  V v_l_245 = heff_env(self)[0];
  V v_v_248 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_245, v_v_248}), v_vs_249});
  V f_ = v_k_242;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}