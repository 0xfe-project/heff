// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Ok 9325
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VArr 15466
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42634
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_fixed 298804110
#define LBL_op 10312
#define LBL_syntax 1059664654
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
V g_heff_2ecompile_2einterp_2ebitsOf_24s171135403x1430053534(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsOf_24s171135403x1430053534_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsOf_24s171135403x1430053534_clo;
V g_heff_2ecompile_2einterp_2ebitsOf_24s732277109x458231430(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsOf_24s732277109x458231430_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsOf_24s732277109x458231430_clo;
V g_heff_2ecompile_2einterp_2ebitwise(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitwise_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitwise_clo;
V g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103(V, V, V);
V g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103_clo;
V g_heff_2ecompile_2einterp_2eevalFields(V, V, V);
V g_heff_2ecompile_2einterp_2eevalFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalFields_clo;
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1251174705x232593684(V, V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1251174705x232593684_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1251174705x232593684_clo;
V g_heff_2ecompile_2einterp_2efixThunk(V, V, V);
V g_heff_2ecompile_2einterp_2efixThunk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixThunk_clo;
V g_heff_2ecompile_2einterp_2efixedInt1(V, V, V);
V g_heff_2ecompile_2einterp_2efixedInt1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedInt1_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get(void);
V g_heff_2ecompile_2einterp_2efromListV(V, V);
V g_heff_2ecompile_2einterp_2efromListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efromListV_clo;
V g_heff_2ecompile_2einterp_2egenGo(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2egenGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2egenGo_clo;
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get(void);
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s1193635016x558583007(V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1193635016x558583007_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1193635016x558583007_clo;
V g_heff_2ecompile_2einterp_2elistValsGo(V, V);
V g_heff_2ecompile_2einterp_2elistValsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elistValsGo_clo;
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotARune_get(void);
V g_heff_2ecompile_2einterp_2enotAnArray_get(void);
V g_heff_2ecompile_2einterp_2enotAnInt_get(void);
V g_heff_2ecompile_2einterp_2enthV(V, V);
V g_heff_2ecompile_2einterp_2enthV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2enthV_clo;
V g_heff_2ecompile_2einterp_2erune2(V);
V g_heff_2ecompile_2einterp_2erune2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2erune2_clo;
V g_heff_2ecompile_2einterp_2etoListV(V);
V g_heff_2ecompile_2einterp_2etoListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f513172498x6317789(V, V, V);
V g_heff_2ecompile_2einterp_2etoListV_24f513172498x6317789_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f513172498x6317789_clo;
V g_heff_2eelab_2efixed_2efixedMin(V);
V g_heff_2eelab_2efixed_2efixedMin_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMin_clo;
V g_heff_2eelab_2efixed_2efixedPrimName(V);
V g_heff_2eelab_2efixed_2efixedPrimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimName_clo;
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAnArray_str0, 38, "a primitive given what is not an array");

static V g_heff_2ecompile_2einterp_2enotAnArray_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAnArray_st;
static V g_heff_2ecompile_2einterp_2enotAnArray_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAnArray_str0)});
}
V g_heff_2ecompile_2einterp_2enotAnArray_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAnArray_st)) return g_heff_2ecompile_2einterp_2enotAnArray_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAnArray_val, &g_heff_2ecompile_2einterp_2enotAnArray_st, g_heff_2ecompile_2einterp_2enotAnArray_init);
}
V g_heff_2ecompile_2einterp_2erune2_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2erune2_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2erune2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2erune2_entry, 1, 0};

V g_heff_2ecompile_2einterp_2erune2(V v_f_240) {
top: ;
  return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2erune2_lam0, 2, 1, (V[]){v_f_240})});
}
V g_heff_2ecompile_2einterp_2erune2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2erune2(a[0]);
}
V g_heff_2ecompile_2einterp_2erune2_lam1(V self, V *args) {
  V v_d_243 = args[0];
  V v_b_244 = args[1];
  V v_a_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_245 = heff_tr(heff_call(v_a_242, 1, (V[]){heff_dup(v_d_243)}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Ok: {
    V v_v_246 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Ok = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    V v_x1_247 = heff_tr(heff_call(v_b_244, 1, (V[]){v_d_243}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Ok: {
      V v_v_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      switch (heff_tag_of(v_v_246)) {
      case TAG_VFun: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_246, 0ULL, 2);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VFloat: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VRune: {
        V v_a_2417 = heff_field(v_v_246, 0);
        heff_take_n(v_v_246, 1ULL, 1);
        switch (heff_tag_of(v_v_248)) {
        case TAG_VFun: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_248, 0ULL, 2);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VFloat: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VRune: {
          V v_b_2426 = heff_field(v_v_248, 0);
          heff_take_n(v_v_248, 1ULL, 1);
          V f_ = v_f_240;
          args[0] = v_a_2417;
          args[1] = v_b_2426;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VArr: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_248, 0ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        case TAG_VErased: {
          heff_drop(v_f_240);
          heff_drop(v_a_2417);
          return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
        }
        default: return heff_nomatch(v_v_248);
        }
      }
      case TAG_VArr: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_246, 0ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      case TAG_VErased: {
        heff_drop(v_f_240);
        heff_drop(v_v_248);
        return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
      }
      default: return heff_nomatch(v_v_246);
      }
    }
    case TAG_Abn: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      heff_drop_cell(v_ru_24x1_245_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_v_246);
      return heff_tag_at_n(v_ru_24x1_245_24Ok, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_245, 0);
    V v_ru_24x1_245_24Bug = heff_take_reuse_n(v_x1_245, 1ULL, 1);
    heff_drop(v_d_243);
    heff_drop(v_b_244);
    heff_drop(v_f_240);
    return heff_tag_at_n(v_ru_24x1_245_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2ecompile_2einterp_2erune2_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_a_242 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2erune2_lam1, 2, 2, (V[]){v_a_242, v_f_240})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str0, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str1, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str2, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str3, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str4, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str5, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str6, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str7, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2egenGo_str8, 30, "applied what is not a function");
V g_heff_2ecompile_2einterp_2egenGo_lam0(V self, V *args);
V g_heff_2ecompile_2einterp_2egenGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2einterp_2egenGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2egenGo_entry, 5, 0};

V g_heff_2ecompile_2einterp_2egenGo(V v_d_240, V v_j_241, V v_n_242, V v_f_243, V v_k_244) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_242), heff_dup(v_j_241))) {
    heff_drop(v_d_240);
    heff_drop(v_j_241);
    heff_drop(v_n_242);
    heff_drop(v_f_243);
    return heff_tail(v_k_244, 1, (V[]){NTAG(TAG_Nil)});
  } else {
    V v_x1_2418;
    switch (heff_tag_of(v_f_243)) {
    case TAG_VFun: {
      V v_f_246 = heff_dup(heff_field(v_f_243, 0));
      v_x1_2418 = heff_tr(heff_call(v_f_246, 2, (V[]){heff_dup(v_d_240), heff_clo_n(g_heff_2ecompile_2einterp_2egenGo_lam0, 1, 1, (V[]){heff_dup(v_j_241)})}));
      break;
    }
    case TAG_VCons: {
      v_x1_2418 = heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str0)});
      break;
    }
    case TAG_VTag: {
      v_x1_2418 = heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str1)});
      break;
    }
    case TAG_VInt: {
      v_x1_2418 = heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str2)});
      break;
    }
    case TAG_VFloat: {
      v_x1_2418 = heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str3)});
      break;
    }
    case TAG_VFloat32: {
      v_x1_2418 = heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str4)});
      break;
    }
    case TAG_VStr: {
      v_x1_2418 = heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str5)});
      break;
    }
    case TAG_VRune: {
      v_x1_2418 = heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str6)});
      break;
    }
    case TAG_VArr: {
      v_x1_2418 = heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str7)});
      break;
    }
    case TAG_VBytes: {
      v_x1_2418 = heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2egenGo_str8)});
      break;
    }
    case TAG_VErased: {
      v_x1_2418 = heff_tag_n(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
      break;
    }
    default: heff_nomatch(v_f_243);
    }
    switch (heff_tag_of(v_x1_2418)) {
    case TAG_Ok: {
      V v_v_2419 = heff_field(v_x1_2418, 0);
      heff_take_n(v_x1_2418, 1ULL, 1);
      V t_0 = v_d_240;
      V t_1 = heff_intAdd(v_j_241, MK_INT(1LL));
      V t_2 = v_n_242;
      V t_3 = v_f_243;
      V t_4 = heff_clo_n(g_heff_2ecompile_2einterp_2egenGo_lam1, 1, 2, (V[]){v_k_244, v_v_2419});
      v_d_240 = t_0;
      v_j_241 = t_1;
      v_n_242 = t_2;
      v_f_243 = t_3;
      v_k_244 = t_4;
      goto top;
    }
    case TAG_Abn: {
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_f_243);
      heff_drop(v_k_244);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_f_243);
      heff_drop(v_k_244);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2421 = heff_field(v_x1_2418, 0);
      V v_ru_24x1_2418_24Bug = heff_take_reuse_n(v_x1_2418, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop(v_j_241);
      heff_drop(v_n_242);
      heff_drop(v_f_243);
      heff_drop(v_k_244);
      return heff_tag_at_n(v_ru_24x1_2418_24Bug, TAG_Bug, 1, (V[]){v_what_2421});
    }
    default: return heff_nomatch(v_x1_2418);
    }
  }
}
V g_heff_2ecompile_2einterp_2egenGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2egenGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2einterp_2egenGo_lam0(V self, V *args) {
  V v_d_247 = args[0];
  V v_j_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_247);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_j_241})});
}
V g_heff_2ecompile_2einterp_2egenGo_lam1(V self, V *args) {
  V v_vs_2420 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_v_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_v_2419, v_vs_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2efromListV_str0, 4, "Cons");
Clo g_heff_2ecompile_2einterp_2efromListV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efromListV_entry, 2, 0};

V g_heff_2ecompile_2einterp_2efromListV(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VTag: {
    V v_x11_244 = heff_field(v_x1_240, 0);
    V v_x12_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24VTag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(v_x11_244, ((V)&g_heff_2ecompile_2einterp_2efromListV_str0))) {
      switch (heff_tag_of(v_x12_245)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
        HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x12_245, 0);
        V v_x122_248 = heff_field(v_x12_245, 1);
        heff_take_n(v_x12_245, 3ULL, 2);
        switch (heff_tag_of(v_x122_248)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
          heff_drop(v_x_247);
          HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
        }
        case TAG_Cons: {
          V v_rest_249 = heff_field(v_x122_248, 0);
          V v_x1222_2410 = heff_field(v_x122_248, 1);
          heff_take_n(v_x122_248, 3ULL, 2);
          switch (heff_tag_of(v_x1222_2410)) {
          case TAG_Nil: {
            V t_0 = v_rest_249;
            V t_1 = heff_tag_at_n(v_ru_24x1_240_24VTag, TAG_Cons, 2, (V[]){v_x_247, v_acc_241});
            v_x1_240 = t_0;
            v_acc_241 = t_1;
            goto top;
          }
          case TAG_Cons: {
            heff_take_n(v_x1222_2410, 0ULL, 2);
            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
            heff_drop(v_x_247);
            heff_drop(v_rest_249);
            HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
          }
          default: return heff_nomatch(v_x1222_2410);
          }
        }
        default: return heff_nomatch(v_x122_248);
        }
      }
      default: return heff_nomatch(v_x12_245);
      }
    } else {
      heff_drop(v_x12_245);
      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
      HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
    }
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VErased: {
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2efromListV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efromListV(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2etoListV_str0, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2einterp_2etoListV_str1, 4, "Cons");
Clo g_heff_2ecompile_2einterp_2etoListV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2etoListV_entry, 1, 0};

V g_heff_2ecompile_2einterp_2etoListV(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2etoListV_str0), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2einterp_2etoListV(v_xs_242));
    V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2etoListV_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, v_t_244})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2etoListV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2etoListV(a[0]);
}
Clo g_heff_2ecompile_2einterp_2enthV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2enthV_entry, 2, 0};

V g_heff_2ecompile_2einterp_2enthV(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_xs_243;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2enthV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2enthV(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2einterp_2ebitwise_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitwise_entry, 4, 0};

V g_heff_2ecompile_2einterp_2ebitwise(V v_f_240, V v_n_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intEq_c(heff_dup(v_n_241), MK_INT(0LL))) {
    heff_drop(v_f_240);
    heff_drop(v_n_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return MK_INT(0LL);
  } else {
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){heff_intMod(heff_dup(v_a_242), MK_INT(2LL)), heff_intMod(heff_dup(v_b_243), MK_INT(2LL))}));
    V v_t_246 = (g_heff_2ecompile_2einterp_2ebitwise(v_f_240, heff_intSub(v_n_241, MK_INT(1LL)), heff_intDiv(v_a_242, MK_INT(2LL)), heff_intDiv(v_b_243, MK_INT(2LL))));
    return heff_intAdd(v_t_245, heff_intMul(MK_INT(2LL), v_t_246));
  }
}
V g_heff_2ecompile_2einterp_2ebitwise_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitwise(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2einterp_2ebitsOf_24s171135403x1430053534_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsOf_24s171135403x1430053534_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ebitsOf_24s171135403x1430053534(V v_w_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_243 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_243 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_243 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_243 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_243 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_243 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_243 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_243 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_243 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_244;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_244 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_244 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_244 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_244 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_244 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_244 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_245 = (g_heff_2eelab_2efixed_2etwoTo(v_t_244));
  V v_t_246;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_246 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_246 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_246 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_246 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_246 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_246 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_246 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_246 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_246 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_247 = (g_heff_2eelab_2efixed_2etwoTo(v_t_246));
  V v_n_248 = (g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103(v_t_243, heff_intMod(v_a_241, v_t_245), heff_intMod(v_b_242, v_t_247)));
  V v_t_249 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
  V v_t_2410 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
  V v_t_2411;
  switch (heff_tag_of(v_w_240)) {
  case TAG_I8: {
    v_t_2411 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_2411 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_2411 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_2411 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_2411 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_2411 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_2411 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_2411 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_2411 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_240);
  }
  V v_t_2412 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2411));
  V v_t_2413 = heff_intMod(heff_intSub(v_n_248, v_t_2410), v_t_2412);
  V v_t_2414 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intAdd(v_t_249, v_t_2413)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2414});
}
V g_heff_2ecompile_2einterp_2ebitsOf_24s171135403x1430053534_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2ebitsOf_24s171135403x1430053534(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2einterp_2ebitsOf_24s732277109x458231430_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2ebitsOf_24s732277109x458231430_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsOf_24s732277109x458231430_entry, 4, 0};

V g_heff_2ecompile_2einterp_2ebitsOf_24s732277109x458231430(V v_lit_240, V v_w_241, V v_a_242, V v_b_243) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_244 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_244 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_244 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_244 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_244 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_244 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_244 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_245;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_245 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_245 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_245 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_245 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_245 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_245 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_245 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_245 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_245 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_246 = (g_heff_2eelab_2efixed_2etwoTo(v_t_245));
  V v_t_247;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_247 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_247 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_247 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_247 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_247 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_247 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_247 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_248 = (g_heff_2eelab_2efixed_2etwoTo(v_t_247));
  V v_n_2411 = (g_heff_2ecompile_2einterp_2ebitwise(heff_clo_n(g_heff_2ecompile_2einterp_2ebitsOf_24s732277109x458231430_lam0, 2, 1, (V[]){v_lit_240}), v_t_244, heff_intMod(v_a_242, v_t_246), heff_intMod(v_b_243, v_t_248)));
  V v_t_2412 = (g_heff_2eelab_2efixed_2efixedMin(v_w_241));
  V v_t_2413 = (g_heff_2eelab_2efixed_2efixedMin(v_w_241));
  V v_t_2414;
  switch (heff_tag_of(v_w_241)) {
  case TAG_I8: {
    v_t_2414 = MK_INT(8LL);
    break;
  }
  case TAG_I16: {
    v_t_2414 = MK_INT(16LL);
    break;
  }
  case TAG_I32: {
    v_t_2414 = MK_INT(32LL);
    break;
  }
  case TAG_I64: {
    v_t_2414 = MK_INT(64LL);
    break;
  }
  case TAG_U8: {
    v_t_2414 = MK_INT(8LL);
    break;
  }
  case TAG_U16: {
    v_t_2414 = MK_INT(16LL);
    break;
  }
  case TAG_U32: {
    v_t_2414 = MK_INT(32LL);
    break;
  }
  case TAG_U64: {
    v_t_2414 = MK_INT(64LL);
    break;
  }
  case TAG_F32: {
    v_t_2414 = MK_INT(32LL);
    break;
  }
  default: heff_nomatch(v_w_241);
  }
  V v_t_2415 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2414));
  V v_t_2416 = heff_intMod(heff_intSub(v_n_2411, v_t_2413), v_t_2415);
  V v_t_2417 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2412, v_t_2416)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2417});
}
V g_heff_2ecompile_2einterp_2ebitsOf_24s732277109x458231430_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2einterp_2ebitsOf_24s732277109x458231430(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2einterp_2ebitsOf_24s732277109x458231430_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_a_2410 = args[1];
  V v_lit_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intMod(heff_intAdd(v_a_249, v_a_2410), v_lit_240);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str0, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str1, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str2, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str3, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str4, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str5, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str6, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str7, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str8, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str9, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str10, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str11, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str12, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str13, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str14, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str15, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt1_str16, 13, "no primitive ");
Clo g_heff_2ecompile_2einterp_2efixedInt1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efixedInt1_entry, 3, 0};

V g_heff_2ecompile_2einterp_2efixedInt1(V v_w_240, V v_op_241, V v_a_242) {
top: ;
  switch (heff_tag_of(v_op_241)) {
  case TAG_OpAdd: {
    heff_drop(v_a_242);
    V v_t_243 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str0), v_t_243)});
  }
  case TAG_OpSub: {
    heff_drop(v_a_242);
    V v_t_244 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str1), v_t_244)});
  }
  case TAG_OpMul: {
    heff_drop(v_a_242);
    V v_t_245 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str2), v_t_245)});
  }
  case TAG_OpDiv: {
    heff_drop(v_a_242);
    V v_t_246 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str3), v_t_246)});
  }
  case TAG_OpRem: {
    heff_drop(v_a_242);
    V v_t_247 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str4), v_t_247)});
  }
  case TAG_OpEq: {
    heff_drop(v_a_242);
    V v_t_248 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str5), v_t_248)});
  }
  case TAG_OpLt: {
    heff_drop(v_a_242);
    V v_t_249 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str6), v_t_249)});
  }
  case TAG_OpLe: {
    heff_drop(v_a_242);
    V v_t_2410 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str7), v_t_2410)});
  }
  case TAG_OpAnd: {
    heff_drop(v_a_242);
    V v_t_2411 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str8), v_t_2411)});
  }
  case TAG_OpOr: {
    heff_drop(v_a_242);
    V v_t_2412 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str9), v_t_2412)});
  }
  case TAG_OpXor: {
    heff_drop(v_a_242);
    V v_t_2413 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str10), v_t_2413)});
  }
  case TAG_OpShl: {
    heff_drop(v_a_242);
    V v_t_2414 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str11), v_t_2414)});
  }
  case TAG_OpShr: {
    heff_drop(v_a_242);
    V v_t_2415 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str12), v_t_2415)});
  }
  case TAG_OpShow: {
    heff_drop(v_w_240);
    V v_t_2416 = heff_tag_n(TAG_VStr, 1, (V[]){heff_intShow(v_a_242)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2416});
  }
  case TAG_OpFromInt: {
    V v_t_2417 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
    V v_t_2418 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
    V v_t_2419;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2419 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2419 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2419 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2419 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2419 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2419 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2419 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2419 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2419 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2420 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2419));
    V v_t_2421 = heff_intMod(heff_intSub(v_a_242, v_t_2418), v_t_2420);
    V v_t_2422 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2417, v_t_2421)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2422});
  }
  case TAG_OpToInt: {
    heff_drop(v_w_240);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_242})});
  }
  case TAG_OpSqrt: {
    heff_drop(v_a_242);
    V v_t_2423 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str13), v_t_2423)});
  }
  case TAG_OpFromFloat: {
    heff_drop(v_a_242);
    V v_t_2424 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str14), v_t_2424)});
  }
  case TAG_OpToFloat: {
    heff_drop(v_a_242);
    V v_t_2425 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str15), v_t_2425)});
  }
  case TAG_OpFloor: {
    heff_drop(v_a_242);
    V v_t_2426 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt1_str16), v_t_2426)});
  }
  default: return heff_nomatch(v_op_241);
  }
}
V g_heff_2ecompile_2einterp_2efixedInt1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efixedInt1(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_st;
static V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_st)) return g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_val;
  return heff_global(&g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_val, &g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_st, g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_init);
}
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_VInt, 1, (V[]){heff_intSub(v_a_2412, v_b_2417)});
          return heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2418});
        }
        case TAG_VFloat: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_lam1, 2, 1, (V[]){v_a_241})})});
}
Clo g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(V v_a_240, V v_b_241) {
top: ;
  V v_t_246 = heff_bool((heff_intEq_c(heff_dup(v_a_240), MK_INT(0LL)) ? (heff_intEq_c(heff_dup(v_b_241), MK_INT(0LL)) || heff_intEq_c(heff_dup(v_b_241), MK_INT(-1LL))) : (heff_intEq_c(heff_dup(v_a_240), MK_INT(-1LL)) && (heff_intEq_c(heff_dup(v_b_241), MK_INT(0LL)) || heff_intEq_c(heff_dup(v_b_241), MK_INT(-1LL))))));
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_t_247 = heff_intMul(heff_intMod(v_a_240, MK_INT(2LL)), heff_intMod(v_b_241, MK_INT(2LL)));
    return heff_intSub(MK_INT(0LL), v_t_247);
  } else {
    heff_drop(v_t_246);
    V v_t_248 = heff_intMul(heff_intMod(heff_dup(v_a_240), MK_INT(2LL)), heff_intMod(heff_dup(v_b_241), MK_INT(2LL)));
    V v_t_249 = (g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(heff_intDiv(v_a_240, MK_INT(2LL)), heff_intDiv(v_b_241, MK_INT(2LL))));
    return heff_intAdd(v_t_248, heff_intMul(MK_INT(2LL), v_t_249));
  }
}
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(a[0], a[1]);
}
Clo g_heff_2ecompile_2einterp_2eintBits_24s1193635016x558583007_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eintBits_24s1193635016x558583007_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eintBits_24s1193635016x558583007(V v_lit_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_247 = heff_bool((heff_intEq_c(heff_dup(v_a_241), MK_INT(0LL)) ? (heff_intEq_c(heff_dup(v_b_242), MK_INT(0LL)) || heff_intEq_c(heff_dup(v_b_242), MK_INT(-1LL))) : (heff_intEq_c(heff_dup(v_a_241), MK_INT(-1LL)) && (heff_intEq_c(heff_dup(v_b_242), MK_INT(0LL)) || heff_intEq_c(heff_dup(v_b_242), MK_INT(-1LL))))));
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_t_248 = heff_intAdd(heff_intMod(v_a_241, MK_INT(2LL)), heff_intMod(v_b_242, MK_INT(2LL)));
    return heff_intSub(MK_INT(0LL), heff_intMod(v_t_248, v_lit_240));
  } else {
    heff_drop(v_t_247);
    V v_t_249 = heff_intAdd(heff_intMod(heff_dup(v_a_241), MK_INT(2LL)), heff_intMod(heff_dup(v_b_242), MK_INT(2LL)));
    V v_t_2410 = (g_heff_2ecompile_2einterp_2eintBits_24s1193635016x558583007(heff_dup(v_lit_240), heff_intDiv(v_a_241, MK_INT(2LL)), heff_intDiv(v_b_242, MK_INT(2LL))));
    return heff_intAdd(heff_intMod(v_t_249, v_lit_240), heff_intMul(MK_INT(2LL), v_t_2410));
  }
}
V g_heff_2ecompile_2einterp_2eintBits_24s1193635016x558583007_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eintBits_24s1193635016x558583007(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_st;
static V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_st)) return g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_val;
  return heff_global(&g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_val, &g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_st, g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_init);
}
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2420 = heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_box_f64((heff_unbox_f64(v_a_2413) / heff_unbox_f64(v_b_2419)))});
          return heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_st;
static V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_st)) return g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_val;
  return heff_global(&g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_val, &g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_st, g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_init);
}
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VFloat: {
        V v_a_2413 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VFloat: {
          V v_b_2419 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2420 = heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_VFloat, 1, (V[]){heff_box_f64(pow(heff_unbox_f64(v_a_2413), heff_unbox_f64(v_b_2419)))});
          return heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2413);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2431 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Bug, 1, (V[]){v_what_2431});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2432 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2432});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2eevalFields_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eevalFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eevalFields_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eevalFields(V v_ev_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ev_240);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_l_245 = heff_field(v_x21_243, 0);
      V v_t_246 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      V v_x1_247 = heff_tr(heff_call(heff_dup(v_ev_240), 1, (V[]){v_t_246}));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Ok: {
        V v_v_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V t_0 = v_ev_240;
        V t_1 = v_rest_244;
        V t_2 = heff_clo_n(g_heff_2ecompile_2einterp_2eevalFields_lam0, 1, 3, (V[]){v_l_245, v_v_248, v_k_242});
        v_ev_240 = t_0;
        v_x2_241 = t_1;
        v_k_242 = t_2;
        goto top;
      }
      case TAG_Abn: {
        heff_drop(v_ev_240);
        heff_drop(v_k_242);
        heff_drop(v_rest_244);
        heff_drop(v_l_245);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_ev_240);
        heff_drop(v_k_242);
        heff_drop(v_rest_244);
        heff_drop(v_l_245);
        return NTAG(TAG_Div);
      }
      case TAG_Bug: {
        V v_what_2411 = heff_field(v_x1_247, 0);
        V v_ru_24x1_247_24Bug = heff_take_reuse_n(v_x1_247, 1ULL, 1);
        heff_drop(v_ev_240);
        heff_drop(v_k_242);
        heff_drop(v_rest_244);
        heff_drop(v_l_245);
        return heff_tag_at_n(v_ru_24x1_247_24Bug, TAG_Bug, 1, (V[]){v_what_2411});
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2eevalFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eevalFields(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2einterp_2eevalFields_lam0(V self, V *args) {
  V v_vs_249 = args[0];
  V v_l_245 = heff_env(self)[0];
  V v_v_248 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_245, v_v_248}), v_vs_249});
  V f_ = v_k_242;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2elistValsGo_str0, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2einterp_2elistValsGo_str1, 4, "Cons");
Clo g_heff_2ecompile_2einterp_2elistValsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2elistValsGo_entry, 2, 0};

V g_heff_2ecompile_2einterp_2elistValsGo(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VTag: {
    V v_x11_244 = heff_field(v_x1_240, 0);
    V v_x12_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24VTag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_x11_244), ((V)&g_heff_2ecompile_2einterp_2elistValsGo_str0))) {
      heff_drop(v_x11_244);
      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
      switch (heff_tag_of(v_x12_245)) {
      case TAG_Nil: {
        V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_247});
      }
      case TAG_Cons: {
        heff_take_n(v_x12_245, 0ULL, 2);
        heff_drop(v_acc_241);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x12_245);
      }
    } else {
      if (heff_strEq_c(v_x11_244, ((V)&g_heff_2ecompile_2einterp_2elistValsGo_str1))) {
        switch (heff_tag_of(v_x12_245)) {
        case TAG_Nil: {
          heff_drop(v_acc_241);
          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Cons: {
          V v_x_2411 = heff_field(v_x12_245, 0);
          V v_x122_2412 = heff_field(v_x12_245, 1);
          heff_take_n(v_x12_245, 3ULL, 2);
          switch (heff_tag_of(v_x122_2412)) {
          case TAG_Nil: {
            heff_drop(v_acc_241);
            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
            heff_drop(v_x_2411);
            return NTAG(TAG_Nothing);
          }
          case TAG_Cons: {
            V v_rest_2413 = heff_field(v_x122_2412, 0);
            V v_x1222_2414 = heff_field(v_x122_2412, 1);
            heff_take_n(v_x122_2412, 3ULL, 2);
            switch (heff_tag_of(v_x1222_2414)) {
            case TAG_Nil: {
              V t_0 = v_rest_2413;
              V t_1 = heff_tag_at_n(v_ru_24x1_240_24VTag, TAG_Cons, 2, (V[]){v_x_2411, v_acc_241});
              v_x1_240 = t_0;
              v_acc_241 = t_1;
              goto top;
            }
            case TAG_Cons: {
              heff_take_n(v_x1222_2414, 0ULL, 2);
              heff_drop(v_acc_241);
              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
              heff_drop(v_x_2411);
              heff_drop(v_rest_2413);
              return NTAG(TAG_Nothing);
            }
            default: return heff_nomatch(v_x1222_2414);
            }
          }
          default: return heff_nomatch(v_x122_2412);
          }
        }
        default: return heff_nomatch(v_x12_245);
        }
      } else {
        heff_drop(v_acc_241);
        heff_drop(v_x12_245);
        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
        return NTAG(TAG_Nothing);
      }
    }
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VErased: {
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2elistValsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2elistValsGo(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1251174705x232593684_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1251174705x232593684_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1251174705x232593684_entry, 6, 0};

V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1251174705x232593684(V v_lit_240, V v_lit_241, V v_lit_242, V v_ge_243, V v_x3_244, V v_acc_245) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_ge_243);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_245));
  }
  case TAG_Cons: {
    V v_x31_246 = heff_field(v_x3_244, 0);
    V v_rest_247 = heff_field(v_x3_244, 1);
    V v_ru_24x3_244_24Cons = heff_take_reuse_n(v_x3_244, 3ULL, 2);
    switch (heff_tag_of(v_x31_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x31_246, 0);
      V v_entry_249 = heff_field(v_x31_246, 1);
      heff_take_n(v_x31_246, 3ULL, 2);
      V v_r_2410 = heff_tr(g_heff_2ecompile_2einterp_2efixThunk(heff_dup(v_ge_243), heff_get_n(v_entry_249, 0, 4), MK_INT(0LL)));
      V v_t_2412 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_248), heff_clo_n(g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1251174705x232593684_lam0, 1, 1, (V[]){heff_dup(v_r_2410)}), v_ge_243));
      V v_t_2417;
      if (heff_strEq_c(heff_strSlice(heff_dup(v_x_248), heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242))) {
        V v_t_2416;
        switch (heff_tag_of(v_r_2410)) {
        case TAG_Ok: {
          V v_v_2414 = heff_field(v_r_2410, 0);
          V v_ru_24r_2410_24Ok = heff_take_reuse_n(v_r_2410, 1ULL, 1);
          v_t_2416 = heff_tag_at_n(v_ru_24r_2410_24Ok, TAG_RSucceeded, 1, (V[]){v_v_2414});
          break;
        }
        case TAG_Abn: {
          v_t_2416 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          v_t_2416 = NTAG(TAG_RDiverged);
          break;
        }
        case TAG_Bug: {
          V v_what_2415 = heff_field(v_r_2410, 0);
          V v_ru_24r_2410_24Bug = heff_take_reuse_n(v_r_2410, 1ULL, 1);
          v_t_2416 = heff_tag_at_n(v_ru_24r_2410_24Bug, TAG_RBug, 1, (V[]){v_what_2415});
          break;
        }
        default: heff_nomatch(v_r_2410);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x3_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_248, v_t_2416}), v_acc_245});
      } else {
        heff_drop_cell(v_ru_24x3_244_24Cons, 2);
        heff_drop(v_x_248);
        heff_drop(v_r_2410);
        v_t_2417 = v_acc_245;
      }
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_t_2412;
      V t_4 = v_rest_247;
      V t_5 = v_t_2417;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_ge_243 = t_3;
      v_x3_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x31_246);
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1251174705x232593684_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1251174705x232593684(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1251174705x232593684_lam0(V self, V *args) {
  V v_d_2411 = args[0];
  V v_r_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2411);
  return v_r_2410;
}
HEFF_LIT(g_heff_2ecompile_2einterp_2etoListV_24f513172498x6317789_str0, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2einterp_2etoListV_24f513172498x6317789_str1, 4, "Cons");
Clo g_heff_2ecompile_2einterp_2etoListV_24f513172498x6317789_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2etoListV_24f513172498x6317789_entry, 3, 0};

V g_heff_2ecompile_2einterp_2etoListV_24f513172498x6317789(V v_f_240, V v_a_241, V v_b_242) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_242), heff_dup(v_a_241))) {
    heff_drop(v_f_240);
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2etoListV_24f513172498x6317789_str0), NTAG(TAG_Nil)});
  } else {
    V v_x_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_a_241)}));
    V v_t_245 = (g_heff_2ecompile_2einterp_2etoListV_24f513172498x6317789(v_f_240, heff_intAdd(v_a_241, MK_INT(1LL)), v_b_242));
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2etoListV_24f513172498x6317789_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_246})});
  }
}
V g_heff_2ecompile_2einterp_2etoListV_24f513172498x6317789_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2etoListV_24f513172498x6317789(a[0], a[1], a[2]);
}