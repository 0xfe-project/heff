// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_Ok 9325
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
float g_float32_2efromDecimal_w(V, V);
V g_float32_2efromDecimal(V, V);
V g_float32_2efromDecimal_entry(V self, V *a);
extern Clo g_float32_2efromDecimal_clo;
V g_heff_2ecompile_2einterp_2ebytesJoined(V, V);
V g_heff_2ecompile_2einterp_2ebytesJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesJoined_clo;
V g_heff_2ecompile_2einterp_2ebytesOfNat(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfNat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfNat_clo;
double g_heff_2ecompile_2einterp_2edecimalTextV_w(V, V);
V g_heff_2ecompile_2einterp_2edecimalTextV(V, V);
V g_heff_2ecompile_2einterp_2edecimalTextV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2edecimalTextV_clo;
V g_heff_2ecompile_2einterp_2edigitsEndV(V, V);
V g_heff_2ecompile_2einterp_2edigitsEndV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2edigitsEndV_clo;
V g_heff_2ecompile_2einterp_2edigitsValueV(V, V, V, V);
V g_heff_2ecompile_2einterp_2edigitsValueV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2edigitsValueV_clo;
V g_heff_2ecompile_2einterp_2eevalFields(V, V, V);
V g_heff_2ecompile_2einterp_2eevalFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalFields_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get(void);
V g_heff_2ecompile_2einterp_2efromListV(V, V);
V g_heff_2ecompile_2einterp_2efromListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efromListV_clo;
V g_heff_2ecompile_2einterp_2elistValsGo(V, V);
V g_heff_2ecompile_2einterp_2elistValsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elistValsGo_clo;
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotBytes_get(void);
HeffT2 g_heff_2ecompile_2einterp_2enthTh_24cpr(V, V);
double g_heff_2ecompile_2einterp_2etwoToF_w(V);
V g_heff_2ecompile_2einterp_2etwoToF(V);
V g_heff_2ecompile_2einterp_2etwoToF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoToF_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
double g_std_2emath_2efromDecimal_w(V, V);
V g_std_2emath_2efromDecimal(V, V);
V g_std_2emath_2efromDecimal_entry(V self, V *a);
extern Clo g_std_2emath_2efromDecimal_clo;
Clo g_heff_2ecompile_2einterp_2ebytesJoined_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebytesJoined_entry, 2, 0};

V g_heff_2ecompile_2einterp_2ebytesJoined(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_acc_241})});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_VFun: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_b_2414 = heff_field(v_x11_242, 0);
      V t_0 = v_rest_243;
      V t_1 = heff_strAppend(v_acc_241, heff_dup(v_b_2414));
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_VBits: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop(v_acc_241);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2ebytesJoined_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2ebytesJoined(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2einterp_2ebytesOfNat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebytesOfNat_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ebytesOfNat(V v_box_24k_240, V v_u_241, V v_acc_242) {
  int64_t v_k_240 = heff_unbox_word(v_box_24k_240);
top: ;
  if ((v_k_240 <= ((int64_t)0ULL))) {
    heff_drop(v_u_241);
    return v_acc_242;
  } else {
    uint8_t v_t_243 = heff_from_int_u8(heff_intMod(heff_dup(v_u_241), MK_INT(256LL)));
    V v_t_244 = heff_strAppend(heff_strFromByte(heff_box_u8(v_t_243)), v_acc_242);
    int64_t t_0 = (v_k_240 - ((int64_t)1ULL));
    V t_1 = heff_intDiv(v_u_241, MK_INT(256LL));
    V t_2 = v_t_244;
    v_k_240 = t_0;
    v_u_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2ecompile_2einterp_2ebytesOfNat_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebytesOfNat(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2etwoToF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2etwoToF_entry, 1, 0};

double g_heff_2ecompile_2einterp_2etwoToF_w(V v_box_24k_240) {
  int64_t v_k_240 = heff_unbox_word(v_box_24k_240);
top: ;
  if ((v_k_240 == ((int64_t)0ULL))) {
    return (1.0);
  } else {
    if ((((int64_t)0ULL) < v_k_240)) {
      double v_t_241 = (g_heff_2ecompile_2einterp_2etwoToF_w(heff_box_word((v_k_240 - ((int64_t)1ULL)))));
      return ((2.0) * v_t_241);
    } else {
      double v_t_242 = (g_heff_2ecompile_2einterp_2etwoToF_w(heff_box_word((v_k_240 + ((int64_t)1ULL)))));
      return ((0.5) * v_t_242);
    }
  }
}
V g_heff_2ecompile_2einterp_2etwoToF(V v_box_24k_240) {
  return heff_box_f64((g_heff_2ecompile_2einterp_2etwoToF_w(v_box_24k_240)));
}
V g_heff_2ecompile_2einterp_2etwoToF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2etwoToF(a[0]);
}
Clo g_heff_2ecompile_2einterp_2edecimalTextV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2edecimalTextV_entry, 2, 0};

double g_heff_2ecompile_2einterp_2edecimalTextV_w(V v_box_24n_240, V v_t_241) {
  int64_t v_n_240 = heff_unbox_word(v_box_24n_240);
top: ;
  V v_a_242;
  if ((heff_unbox_word(heff_strByteAt_lent(v_t_241, MK_INT(0LL), 2)) == ((int64_t)45ULL))) {
    v_a_242 = MK_INT(1LL);
  } else {
    v_a_242 = MK_INT(0LL);
  }
  V v_p_243 = (g_heff_2ecompile_2einterp_2edigitsEndV(v_t_241, heff_dup(v_a_242)));
  V v_f_244;
  if ((heff_unbox_word(heff_strByteAt_lent(v_t_241, v_p_243, 0)) == ((int64_t)46ULL))) {
    v_f_244 = (g_heff_2ecompile_2einterp_2edigitsEndV(v_t_241, heff_intAdd(heff_dup(v_p_243), MK_INT(1LL))));
  } else {
    v_f_244 = heff_dup(v_p_243);
  }
  V v_x_245;
  if (((heff_unbox_word(heff_strByteAt_lent(v_t_241, v_f_244, 0)) == ((int64_t)101ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_t_241, v_f_244, 0)) == ((int64_t)69ULL)))) {
    v_x_245 = heff_intAdd(heff_dup(v_f_244), MK_INT(1LL));
  } else {
    v_x_245 = heff_dup(v_f_244);
  }
  V v_b_246;
  if ((heff_intLt_c_lent(v_f_244, v_x_245, 0) && ((heff_unbox_word(heff_strByteAt_lent(v_t_241, v_x_245, 0)) == ((int64_t)43ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_t_241, v_x_245, 0)) == ((int64_t)45ULL))))) {
    v_b_246 = heff_intAdd(heff_dup(v_x_245), MK_INT(1LL));
  } else {
    v_b_246 = heff_dup(v_x_245);
  }
  V v_end_247 = (g_heff_2ecompile_2einterp_2edigitsEndV(v_t_241, heff_dup(v_b_246)));
  V v_places_248;
  if (heff_intLt_c_lent(v_p_243, v_f_244, 0)) {
    v_places_248 = heff_intSub(heff_intSub(heff_dup(v_f_244), heff_dup(v_p_243)), MK_INT(1LL));
  } else {
    v_places_248 = MK_INT(0LL);
  }
  V v_power_2410;
  if (((heff_unbox_word(heff_strByteAt_lent(v_t_241, v_x_245, 0)) == ((int64_t)45ULL)) && heff_intLt_c_lent(v_f_244, v_x_245, 0))) {
    V v_t_249 = (g_heff_2ecompile_2einterp_2edigitsValueV(v_t_241, heff_dup(v_b_246), heff_dup(v_end_247), MK_INT(0LL)));
    v_power_2410 = heff_intSub(MK_INT(0LL), v_t_249);
  } else {
    v_power_2410 = (g_heff_2ecompile_2einterp_2edigitsValueV(v_t_241, heff_dup(v_b_246), heff_dup(v_end_247), MK_INT(0LL)));
  }
  if ((heff_intEq_c_lent(v_p_243, v_a_242, 0) || (heff_intEq_c(heff_dup(v_f_244), heff_intAdd(heff_dup(v_p_243), MK_INT(1LL))) || ((heff_intLt_c_lent(v_f_244, v_x_245, 0) && heff_intEq_c_lent(v_end_247, v_b_246, 0)) || heff_intLt_c(heff_dup(v_end_247), heff_strLength_lent(v_t_241, 0)))))) {
    heff_drop(v_a_242);
    heff_drop(v_p_243);
    heff_drop(v_f_244);
    heff_drop(v_x_245);
    heff_drop(v_b_246);
    heff_drop(v_end_247);
    heff_drop(v_places_248);
    heff_drop(v_power_2410);
    return ((0.0) / (0.0));
  } else {
    heff_drop(v_x_245);
    heff_drop(v_b_246);
    heff_drop(v_end_247);
    int64_t v_n_2411 = v_n_240;
    V v_negative_2412 = heff_bool((heff_peek_word(v_a_242) == ((int64_t)1ULL)));
    V v_t_2413 = (g_heff_2ecompile_2einterp_2edigitsValueV(v_t_241, v_a_242, heff_dup(v_p_243), MK_INT(0LL)));
    V v_m_2414 = (g_heff_2ecompile_2einterp_2edigitsValueV(v_t_241, heff_intAdd(v_p_243, MK_INT(1LL)), v_f_244, v_t_2413));
    V v_e_2415 = heff_intSub(v_power_2410, v_places_248);
    if ((v_n_2411 == ((int64_t)32ULL))) {
      float v_t_2416 = (g_float32_2efromDecimal_w(v_m_2414, v_e_2415));
      double v_x_2417 = ((double)v_t_2416);
      if ((heff_dup(v_negative_2412) == NTAG(TAG_True))) {
        heff_drop(v_negative_2412);
        return ((-1.0) * v_x_2417);
      } else {
        heff_drop(v_negative_2412);
        return v_x_2417;
      }
    } else {
      double v_x_2418 = (g_std_2emath_2efromDecimal_w(v_m_2414, v_e_2415));
      if ((heff_dup(v_negative_2412) == NTAG(TAG_True))) {
        heff_drop(v_negative_2412);
        return ((-1.0) * v_x_2418);
      } else {
        heff_drop(v_negative_2412);
        return v_x_2418;
      }
    }
  }
}
V g_heff_2ecompile_2einterp_2edecimalTextV(V v_box_24n_240, V v_t_241) {
  return heff_box_f64((g_heff_2ecompile_2einterp_2edecimalTextV_w(v_box_24n_240, v_t_241)));
}
V g_heff_2ecompile_2einterp_2edecimalTextV_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2einterp_2edecimalTextV(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2einterp_2efromListV_str0, 4, "Cons");
Clo g_heff_2ecompile_2einterp_2efromListV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efromListV_entry, 2, 0};

V g_heff_2ecompile_2einterp_2efromListV(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VTag: {
    V v_x11_244 = heff_field(v_x1_240, 0);
    V v_x12_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24VTag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(v_x11_244, ((V)&g_heff_2ecompile_2einterp_2efromListV_str0))) {
      switch (heff_tag_of(v_x12_245)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
        HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
      }
      case TAG_Cons: {
        V v_x_246 = heff_field(v_x12_245, 0);
        V v_x122_247 = heff_field(v_x12_245, 1);
        heff_take_n(v_x12_245, 3ULL, 2);
        switch (heff_tag_of(v_x122_247)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
          heff_drop(v_x_246);
          HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
        }
        case TAG_Cons: {
          V v_rest_248 = heff_field(v_x122_247, 0);
          V v_x1222_249 = heff_field(v_x122_247, 1);
          heff_take_n(v_x122_247, 3ULL, 2);
          switch (heff_tag_of(v_x1222_249)) {
          case TAG_Nil: {
            V t_0 = v_rest_248;
            V t_1 = heff_tag_at_n(v_ru_24x1_240_24VTag, TAG_Cons, 2, (V[]){v_x_246, v_acc_241});
            v_x1_240 = t_0;
            v_acc_241 = t_1;
            goto top;
          }
          case TAG_Cons: {
            heff_take_n(v_x1222_249, 0ULL, 2);
            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
            heff_drop(v_x_246);
            heff_drop(v_rest_248);
            HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
          }
          default: return heff_nomatch(v_x1222_249);
          }
        }
        default: return heff_nomatch(v_x122_247);
        }
      }
      default: return heff_nomatch(v_x12_245);
      }
    } else {
      heff_drop(v_x12_245);
      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
      HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
    }
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VBits: {
    heff_take_n(v_x1_240, 0ULL, 2);
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  case TAG_VErased: {
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2efromListV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efromListV(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_st;
static V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_st)) return g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_val;
  return heff_global(&g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_val, &g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_st, g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_init);
}
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VFloat: {
        double v_a_2413 = heff_tflat_f64(v_v_245, 0);
        heff_take_na(v_v_245, 0ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VFloat: {
          double v_b_2419 = heff_tflat_f64(v_v_247, 0);
          heff_take_na(v_v_247, 0ULL, 1);
          V v_t_2420 = heff_tag_at_nf(v_ru_24x1_246_24Ok, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(pow(v_a_2413, v_b_2419))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_lam1, 2, 1, (V[]){v_a_241})})});
}

HeffT2 g_heff_2ecompile_2einterp_2enthTh_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ecompile_2einterp_2eevalFields_lam0(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eevalFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eevalFields_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eevalFields(V v_ev_240, V v_x2_241, V v_k_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ev_240);
    return heff_tail(v_k_242, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_l_245 = heff_field(v_x21_243, 0);
      V v_t_246 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      V v_x1_247 = heff_tr(heff_call(heff_dup(v_ev_240), 1, (V[]){v_t_246}));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Ok: {
        V v_v_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V t_0 = v_ev_240;
        V t_1 = v_rest_244;
        V t_2 = heff_clo_n(g_heff_2ecompile_2einterp_2eevalFields_lam0, 1, 3, (V[]){v_l_245, v_v_248, v_k_242});
        v_ev_240 = t_0;
        v_x2_241 = t_1;
        v_k_242 = t_2;
        goto top;
      }
      case TAG_Abn: {
        heff_drop(v_ev_240);
        heff_drop(v_k_242);
        heff_drop(v_rest_244);
        heff_drop(v_l_245);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_ev_240);
        heff_drop(v_k_242);
        heff_drop(v_rest_244);
        heff_drop(v_l_245);
        return NTAG(TAG_Div);
      }
      case TAG_Bug: {
        V v_what_2411 = heff_field(v_x1_247, 0);
        V v_ru_24x1_247_24Bug = heff_take_reuse_n(v_x1_247, 1ULL, 1);
        heff_drop(v_ev_240);
        heff_drop(v_k_242);
        heff_drop(v_rest_244);
        heff_drop(v_l_245);
        return heff_tag_at_n(v_ru_24x1_247_24Bug, TAG_Bug, 1, (V[]){v_what_2411});
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2eevalFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eevalFields(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2einterp_2eevalFields_lam0(V self, V *args) {
  V v_vs_249 = args[0];
  V v_l_245 = heff_env(self)[0];
  V v_v_248 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_245, v_v_248}), v_vs_249});
  V f_ = v_k_242;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2elistValsGo_str0, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2einterp_2elistValsGo_str1, 4, "Cons");
Clo g_heff_2ecompile_2einterp_2elistValsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2elistValsGo_entry, 2, 0};

V g_heff_2ecompile_2einterp_2elistValsGo(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VTag: {
    V v_x11_244 = heff_field(v_x1_240, 0);
    V v_x12_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24VTag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x11_244, ((V)&g_heff_2ecompile_2einterp_2elistValsGo_str0), 2)) {
      heff_drop(v_x11_244);
      heff_drop_cell(v_ru_24x1_240_24VTag, 2);
      switch (heff_tag_of(v_x12_245)) {
      case TAG_Nil: {
        V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_246});
      }
      case TAG_Cons: {
        heff_take_n(v_x12_245, 0ULL, 2);
        heff_drop(v_acc_241);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x12_245);
      }
    } else {
      if (heff_strEq_c(v_x11_244, ((V)&g_heff_2ecompile_2einterp_2elistValsGo_str1))) {
        switch (heff_tag_of(v_x12_245)) {
        case TAG_Nil: {
          heff_drop(v_acc_241);
          heff_drop_cell(v_ru_24x1_240_24VTag, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Cons: {
          V v_x_249 = heff_field(v_x12_245, 0);
          V v_x122_2410 = heff_field(v_x12_245, 1);
          heff_take_n(v_x12_245, 3ULL, 2);
          switch (heff_tag_of(v_x122_2410)) {
          case TAG_Nil: {
            heff_drop(v_acc_241);
            heff_drop_cell(v_ru_24x1_240_24VTag, 2);
            heff_drop(v_x_249);
            return NTAG(TAG_Nothing);
          }
          case TAG_Cons: {
            V v_rest_2411 = heff_field(v_x122_2410, 0);
            V v_x1222_2412 = heff_field(v_x122_2410, 1);
            heff_take_n(v_x122_2410, 3ULL, 2);
            switch (heff_tag_of(v_x1222_2412)) {
            case TAG_Nil: {
              V t_0 = v_rest_2411;
              V t_1 = heff_tag_at_n(v_ru_24x1_240_24VTag, TAG_Cons, 2, (V[]){v_x_249, v_acc_241});
              v_x1_240 = t_0;
              v_acc_241 = t_1;
              goto top;
            }
            case TAG_Cons: {
              heff_take_n(v_x1222_2412, 0ULL, 2);
              heff_drop(v_acc_241);
              heff_drop_cell(v_ru_24x1_240_24VTag, 2);
              heff_drop(v_x_249);
              heff_drop(v_rest_2411);
              return NTAG(TAG_Nothing);
            }
            default: return heff_nomatch(v_x1222_2412);
            }
          }
          default: return heff_nomatch(v_x122_2410);
          }
        }
        default: return heff_nomatch(v_x12_245);
        }
      } else {
        heff_drop(v_acc_241);
        heff_drop(v_x12_245);
        heff_drop_cell(v_ru_24x1_240_24VTag, 2);
        return NTAG(TAG_Nothing);
      }
    }
  }
  case TAG_VInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VArr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VBits: {
    heff_take_n(v_x1_240, 0ULL, 2);
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_VErased: {
    heff_drop(v_acc_241);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2elistValsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2elistValsGo(a[0], a[1]);
}