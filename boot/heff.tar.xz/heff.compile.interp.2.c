// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_ArrayAppend 23933
#define TAG_ArrayFromList 11455
#define TAG_ArrayGenerate 2390
#define TAG_ArrayIndex 31774
#define TAG_ArrayInsertAt 1609
#define TAG_ArrayLength 32493
#define TAG_ArrayPush 18071
#define TAG_ArrayRemoveAt 38526
#define TAG_ArrayReplicate 47039
#define TAG_ArrayReserve 45606
#define TAG_ArraySet 62162
#define TAG_ArraySlice 38486
#define TAG_ArrayToList 20274
#define TAG_BitsBytes 6377
#define TAG_BitsConcat 14523
#define TAG_BitsEq 8995
#define TAG_BitsIntAt 48290
#define TAG_BitsLength 37027
#define TAG_BitsOfBytes 24218
#define TAG_BitsOfInt 3554
#define TAG_BitsSlice 40746
#define TAG_Bug 14592
#define TAG_BytesAppend 445
#define TAG_BytesAsString 10306
#define TAG_BytesAt 9508
#define TAG_BytesConcat 52027
#define TAG_BytesEq 9629
#define TAG_BytesFromList 45957
#define TAG_BytesFromString 47012
#define TAG_BytesHasAt 63051
#define TAG_BytesIntAt 64296
#define TAG_BytesLength 9005
#define TAG_BytesOfInt 19560
#define TAG_BytesSlice 56752
#define TAG_BytesToList 62312
#define TAG_BytesToString 37927
#define TAG_Div 16157
#define TAG_FloatAcos 708
#define TAG_FloatAdd 6390
#define TAG_FloatAsin 15893
#define TAG_FloatAtan 16606
#define TAG_FloatAtan2 55855
#define TAG_FloatBits 36420
#define TAG_FloatCos 8668
#define TAG_FloatDiv 9446
#define TAG_FloatEq 13032
#define TAG_FloatExp 10866
#define TAG_FloatFloor 58439
#define TAG_FloatFromInt 61384
#define TAG_FloatLe 13237
#define TAG_FloatLog 17305
#define TAG_FloatLt 13252
#define TAG_FloatMul 18457
#define TAG_FloatOfBits 49155
#define TAG_FloatOfDecimal 61587
#define TAG_FloatPow 21165
#define TAG_FloatShow 17547
#define TAG_FloatSin 23853
#define TAG_FloatSqrt 26286
#define TAG_FloatSub 24213
#define TAG_FloatTan 24566
#define TAG_IntAdd 18227
#define TAG_IntAnd 18537
#define TAG_IntDiv 21283
#define TAG_IntEq 36665
#define TAG_IntHash 50175
#define TAG_IntLe 36870
#define TAG_IntLt 36885
#define TAG_IntMod 30100
#define TAG_IntMul 30294
#define TAG_IntOr 36976
#define TAG_IntShl 35657
#define TAG_IntShow 56864
#define TAG_IntShr 35663
#define TAG_IntSub 36050
#define TAG_IntXor 40685
#define TAG_Keep 49586
#define TAG_OfFixed 17267
#define TAG_Ok 9325
#define TAG_OnWindows 60758
#define TAG_Panic 15447
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_RuneEq 61407
#define TAG_RuneFromInt 49375
#define TAG_RuneLe 61612
#define TAG_RuneLt 61627
#define TAG_RuneToInt 27192
#define TAG_StrAppend 34515
#define TAG_StrByteAt 5424
#define TAG_StrCompare 35677
#define TAG_StrEq 12955
#define TAG_StrEqRange 52111
#define TAG_StrFind 15860
#define TAG_StrFromByte 3813
#define TAG_StrFromJS 60564
#define TAG_StrHash 2387
#define TAG_StrHashRange 56513
#define TAG_StrLength 43075
#define TAG_StrLt 13175
#define TAG_StrOfRunes 54236
#define TAG_StrRuneAt 38304
#define TAG_StrRuneCount 54745
#define TAG_StrRuneWidth 48503
#define TAG_StrRunes 5519
#define TAG_StrSlice 780
#define TAG_StrToJS 44411
#define TAG_TrieSlot 53599
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_aliases 1464806715
#define LBL_entries 787768015
#define LBL_fixed 298804110
#define LBL_keys 9783995
#define LBL_op 10312
#define LBL_syntax 1059664654
#define LBL_values 1123329101
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
V g_heff_2ecompile_2einterp_2eapplyErased(V, V);
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eapplyErased_clo;
V g_heff_2ecompile_2einterp_2ebits1(V);
V g_heff_2ecompile_2einterp_2ebits1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebits1_clo;
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void);
V g_heff_2ecompile_2einterp_2ebitsCopy(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsCopy_clo;
V g_heff_2ecompile_2einterp_2ebitsJoined(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsJoined_clo;
V g_heff_2ecompile_2einterp_2ebitsRead(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsRead_clo;
V g_heff_2ecompile_2einterp_2ebitsSet(V);
V g_heff_2ecompile_2einterp_2ebitsSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsSet_clo;
V g_heff_2ecompile_2einterp_2ebyteString(V, V);
V g_heff_2ecompile_2einterp_2ebyteString_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebyteString_clo;
V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get(void);
V g_heff_2ecompile_2einterp_2ebytesJoined(V, V);
V g_heff_2ecompile_2einterp_2ebytesJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesJoined_clo;
V g_heff_2ecompile_2einterp_2ebytesOfNat(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfNat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfNat_clo;
double g_heff_2ecompile_2einterp_2edecimalTextV_w(V, V);
V g_heff_2ecompile_2einterp_2edecimalTextV(V, V);
V g_heff_2ecompile_2einterp_2edecimalTextV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2edecimalTextV_clo;
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void);
V g_heff_2ecompile_2einterp_2efixedPrimV(V);
V g_heff_2ecompile_2einterp_2efixedPrimV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedPrimV_clo;
V g_heff_2ecompile_2einterp_2efloat2(V);
V g_heff_2ecompile_2einterp_2efloat2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloat2_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get(void);
V g_heff_2ecompile_2einterp_2efmix64(V);
V g_heff_2ecompile_2einterp_2efmix64_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efmix64_clo;
V g_heff_2ecompile_2einterp_2efromListV(V, V);
V g_heff_2ecompile_2einterp_2efromListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efromListV_clo;
V g_heff_2ecompile_2einterp_2egenGo(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2egenGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2egenGo_clo;
V g_heff_2ecompile_2einterp_2ehashFrom(V, V, V);
V g_heff_2ecompile_2einterp_2ehashFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ehashFrom_clo;
V g_heff_2ecompile_2einterp_2eieeeBits_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeBits(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeBits_clo;
V g_heff_2ecompile_2einterp_2eieeeMagnitude_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeMagnitude(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeMagnitude_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeMagnitude_clo;
double g_heff_2ecompile_2einterp_2eieeeOf_w(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeOf_clo;
V g_heff_2ecompile_2einterp_2eint2(V);
V g_heff_2ecompile_2einterp_2eint2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eint2_clo;
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void);
V g_heff_2ecompile_2einterp_2eintAtV(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintAtV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintAtV_clo;
V g_heff_2ecompile_2einterp_2eintAtV_24tok1(V, V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintAtV_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintAtV_24tok1_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_clo;
V g_heff_2ecompile_2einterp_2elistValsGo(V, V);
V g_heff_2ecompile_2einterp_2elistValsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elistValsGo_clo;
V g_heff_2ecompile_2einterp_2elittleInGo(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2elittleInGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elittleInGo_clo;
V g_heff_2ecompile_2einterp_2elittleOutGo(V, V, V, V);
V g_heff_2ecompile_2einterp_2elittleOutGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elittleOutGo_clo;
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotARune_get(void);
V g_heff_2ecompile_2einterp_2enotAString_get(void);
V g_heff_2ecompile_2einterp_2enotAnArray_get(void);
V g_heff_2ecompile_2einterp_2enotAnInt_get(void);
V g_heff_2ecompile_2einterp_2enotBytes_get(void);
HeffT2 g_heff_2ecompile_2einterp_2enthV_24cpr(V, V);
V g_heff_2ecompile_2einterp_2eprim(V);
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eprim_clo;
V g_heff_2ecompile_2einterp_2ereachGlobals(V, V, V);
V g_heff_2ecompile_2einterp_2ereachGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ereachGlobals_clo;
V g_heff_2ecompile_2einterp_2erune2(V);
V g_heff_2ecompile_2einterp_2erune2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2erune2_clo;
V g_heff_2ecompile_2einterp_2eruneCodes(V);
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_clo;
V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V, V);
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo;
V g_heff_2ecompile_2einterp_2escalarV(V);
V g_heff_2ecompile_2einterp_2escalarV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2escalarV_clo;
V g_heff_2ecompile_2einterp_2esetAt(V, V, V);
V g_heff_2ecompile_2einterp_2esetAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esetAt_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2einterp_2esliceV(V, V, V);
V g_heff_2ecompile_2einterp_2esliceV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esliceV_clo;
V g_heff_2ecompile_2einterp_2estr2(V);
V g_heff_2ecompile_2einterp_2estr2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2estr2_clo;
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get(void);
V g_heff_2ecompile_2einterp_2etoListV(V);
V g_heff_2ecompile_2einterp_2etoListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(V, V, V);
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(V);
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_clo;
V g_heff_2ecompile_2einterp_2etwoTo(V);
V g_heff_2ecompile_2einterp_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoTo_clo;
V g_heff_2ecompile_2einterp_2eword64_get(void);
V g_heff_2ecompile_2einterp_2ewordOf(V, V, V);
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ewordOf_clo;
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2erename_2enubFirst(V);
V g_heff_2eelab_2erename_2enubFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2enubFirst_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s24324293x740715900(V, V);
V g_list_2emap_24s24324293x740715900_entry(V self, V *a);
extern Clo g_list_2emap_24s24324293x740715900_clo;
V g_list_2emap_24s391931963x434308123(V);
V g_list_2emap_24s391931963x434308123_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_clo;
V g_list_2emap_24s503834852x510769098(V, V);
V g_list_2emap_24s503834852x510769098_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_rune_2evalidString_2evalidFrom_240(V, V);
V g_rune_2evalidString_2evalidFrom_240_entry(V self, V *a);
extern Clo g_rune_2evalidString_2evalidFrom_240_clo;
V g_runeFromInt_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAnInt_str0, 38, "a primitive given what is not an `Int`");
HEFF_TAG_LIT(g_heff_2ecompile_2einterp_2enotAnInt_lit1, TAG_Bug, 1, ((V)&g_heff_2ecompile_2einterp_2enotAnInt_str0));

static V g_heff_2ecompile_2einterp_2enotAnInt_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAnInt_st;
static V g_heff_2ecompile_2einterp_2enotAnInt_init(void) {
  return ((V)&g_heff_2ecompile_2einterp_2enotAnInt_lit1);
}
V g_heff_2ecompile_2einterp_2enotAnInt_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAnInt_st)) return g_heff_2ecompile_2einterp_2enotAnInt_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAnInt_val, &g_heff_2ecompile_2einterp_2enotAnInt_st, g_heff_2ecompile_2einterp_2enotAnInt_init);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAFloat64_str0, 41, "a primitive given what is not a `Float64`");
HEFF_TAG_LIT(g_heff_2ecompile_2einterp_2enotAFloat64_lit1, TAG_Bug, 1, ((V)&g_heff_2ecompile_2einterp_2enotAFloat64_str0));

static V g_heff_2ecompile_2einterp_2enotAFloat64_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAFloat64_st;
static V g_heff_2ecompile_2einterp_2enotAFloat64_init(void) {
  return ((V)&g_heff_2ecompile_2einterp_2enotAFloat64_lit1);
}
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAFloat64_st)) return g_heff_2ecompile_2einterp_2enotAFloat64_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAFloat64_val, &g_heff_2ecompile_2einterp_2enotAFloat64_st, g_heff_2ecompile_2einterp_2enotAFloat64_init);
}
Clo g_heff_2ecompile_2einterp_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ewordOf_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ewordOf(V v_n_240, V v_f_241, V v_v_242) {
top: ;
  if ((heff_unbox_word(heff_intMod(v_f_241, MK_INT(2LL))) == ((int64_t)1ULL))) {
    V v_t_243 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_245 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_246 = heff_intAdd(heff_intMod(v_v_242, v_t_243), v_t_244);
    V v_u_247 = heff_intMod(v_t_246, v_t_245);
    V v_n_248 = v_n_240;
    V v_t_249 = (g_heff_2ecompile_2einterp_2elittleOutGo(heff_dup(v_u_247), heff_box_word((heff_peek_word(v_n_248) / ((int64_t)8ULL))), MK_INT(0LL), MK_INT(0LL)));
    V v_t_2410 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_n_248) % ((int64_t)8ULL)))));
    int64_t v_t_2411 = (((int64_t)8ULL) * (heff_peek_word(v_n_248) / ((int64_t)8ULL)));
    V v_t_2412 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word(v_t_2411)));
    V v_t_2413 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_unbox_word(v_n_248) % ((int64_t)8ULL)))));
    V v_t_2414 = heff_intMod(heff_intDiv(v_u_247, v_t_2412), v_t_2413);
    return heff_intAdd(heff_intMul(v_t_249, v_t_2410), v_t_2414);
  } else {
    V v_t_2415 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_2416 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_2417 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_240));
    V v_t_2418 = heff_intAdd(heff_intMod(v_v_242, v_t_2415), v_t_2416);
    return heff_intMod(v_t_2418, v_t_2417);
  }
}
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ewordOf(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2eieeeBits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eieeeBits_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eieeeBits_w(V v_eb_240, V v_fb_241, double v_x_242) {
top: ;
  if (!(v_x_242 == v_x_242)) {
    V v_t_243 = (g_heff_2ecompile_2einterp_2etwoTo(v_eb_240));
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_fb_241)));
    V v_t_245 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_unbox_word(v_fb_241) - ((int64_t)1ULL)))));
    V v_t_246 = heff_intMul(heff_intSub(v_t_243, MK_INT(1LL)), v_t_244);
    return heff_intAdd(v_t_246, v_t_245);
  } else {
    if (((v_x_242 < (0.0)) || ((v_x_242 == (0.0)) && (((1.0) / v_x_242) < (0.0))))) {
      V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_eb_240) + heff_peek_word(v_fb_241)))));
      V v_t_248 = (g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, ((0.0) - v_x_242)));
      return heff_intAdd(v_t_247, v_t_248);
    } else {
      HEFF_LAST return g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, v_x_242);
    }
  }
}
V g_heff_2ecompile_2einterp_2eieeeBits(V v_eb_240, V v_fb_241, V v_box_24x_242) {
  double v_x_242 = heff_unbox_f64(v_box_24x_242);
  return (g_heff_2ecompile_2einterp_2eieeeBits_w(v_eb_240, v_fb_241, v_x_242));
}
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eieeeBits(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eruneCodes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_VFun: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2411 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2411, heff_hole()});
      V v_u_2413 = (g_heff_2ecompile_2einterp_2eruneCodes_24dps(v_rest_242, v_cell_2412));
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eruneCodes(a[0]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_VFun: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2412 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2412, heff_hole()});
      V v_u_2414 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2413);
      V t_0 = v_rest_243;
      V t_1 = v_u_2414;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2einterp_2eruneCodes_24dps(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st;
static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st)) return g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val, &g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)(heff_unbox_f32(v_a_2414) / heff_unbox_f32(v_b_2421))))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_re_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_re_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st;
static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st)) return g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
  return heff_global(&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val, &g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init);
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = (g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(v_a_2412, v_b_2417));
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VInt, 1, (V[]){v_t_2418})});
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_re_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_re_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1, 2, 1, (V[]){v_a_241})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10, 36, "a primitive given what is not `Bits`");
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st;
static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st)) return g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val, &g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init);
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  V v_x1_242 = heff_tr(heff_call(v_a_241, 1, (V[]){v_d_240}));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Ok: {
    V v_v_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Ok = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_v_243)) {
    case TAG_VFun: {
      V v_ru_24v_243_24VFun = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFun, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0)});
    }
    case TAG_VCons: {
      V v_ru_24v_243_24VCons = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VCons, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1)});
    }
    case TAG_VTag: {
      heff_take_n(v_v_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2)});
    }
    case TAG_VInt: {
      V v_ru_24v_243_24VInt = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3)});
    }
    case TAG_VFloat: {
      V v_ru_24v_243_24VFloat = heff_take_reuse_na(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4)});
    }
    case TAG_VFloat32: {
      V v_ru_24v_243_24VFloat32 = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat32, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5)});
    }
    case TAG_VStr: {
      V v_ru_24v_243_24VStr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VStr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6)});
    }
    case TAG_VRune: {
      V v_ru_24v_243_24VRune = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VRune, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7)});
    }
    case TAG_VArr: {
      V v_ru_24v_243_24VArr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VArr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8)});
    }
    case TAG_VBytes: {
      V v_ru_24v_243_24VBytes = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VBytes, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9)});
    }
    case TAG_VBits: {
      V v_n_2415 = heff_field(v_v_243, 0);
      heff_take_n(v_v_243, 1ULL, 2);
      return heff_tag_at_n(v_ru_24x1_242_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_n_2415})});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10)});
    }
    default: return heff_nomatch(v_v_243);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2417 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Bug = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_242_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_2417});
  }
  default: return heff_nomatch(v_x1_242);
  }
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str3, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str4, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str5, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str6, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str7, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str8, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str9, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str10, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str11, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str12, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str13, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str14, 32, "an index in range, of no element");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str15, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str16, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str17, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str18, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str19, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str20, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str21, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str22, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str23, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str24, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str26, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str27, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str28, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str29, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str30, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str31, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str32, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str33, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str34, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str35, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str36, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str37, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str38, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str39, 13, "no primitive ");
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam0, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam1, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam2, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam3, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam4, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam5, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam6, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam7, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam8, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam9, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam10, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam11, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam12, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam13, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam14, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam15, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam16, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam17, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam18, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam19, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam20, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam21, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam22, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam23, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam24, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam25, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam27, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam26, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam29, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam28, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam32, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam31, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam38, 1, 0};
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam36, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam35, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam40, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam39, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam42, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam41, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam44_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam44, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam43, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam47, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam46, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam51, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam50_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam50, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam54_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam54, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam53_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam53, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam58_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam58, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam57_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam57, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam61_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam61, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam60_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam60, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam64_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam64, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam63_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam63, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam66_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam66, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam67_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam67, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam70_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam70, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam71_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam71, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam72_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam72, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam73_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam73, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam75_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam75, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam76_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam76, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam77_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam77, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam78_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam78, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam79_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam79, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam81_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam81, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam80_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam80, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam83_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam83, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam82_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam82, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam84_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam84, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam86_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam86, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam87_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam87, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam89_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam89, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam91_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam91, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam92_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam92, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam93_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam93, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam94_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam94, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam95_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam95, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam96_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam96, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam97_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam97, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam99_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam99, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam102_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam102, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam103_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam103, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam106_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam106, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam107_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam107, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam108_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam108, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam109_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam109, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam110(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam110_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam110, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam114(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam113(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam112(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam111(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam111_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam111, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam117(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam116(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam115(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam115_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam115, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam120(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam119(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam118(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam118_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam118, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam124(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam123(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam122(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam121(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam121_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam121, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam127(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam126(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam125(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam125_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam125, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam128(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam128_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam128, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam131(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam130(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam129(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam129_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam129, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam132(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam132, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam133(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam133_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam133, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam135(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam134(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam134_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam134, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam137(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam136(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam136_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam136, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam139(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam138(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam138_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam138, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam143(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam142(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam141(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam140(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam140_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam140, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam144(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam144_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam144, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam147(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam146(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam145(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam145_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam145, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam150(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam149(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam148(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam148_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam148, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam151(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam151_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam151, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam154(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam153(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam152(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam152_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam152, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam155(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eprim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eprim(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_IntAdd: {
    return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get());
  }
  case TAG_IntSub: {
    return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get());
  }
  case TAG_IntMul: {
    return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get());
  }
  case TAG_IntDiv: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam0_clo));
  }
  case TAG_IntMod: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam1_clo));
  }
  case TAG_IntEq: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam2_clo));
  }
  case TAG_IntLt: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam3_clo));
  }
  case TAG_IntLe: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam4_clo));
  }
  case TAG_IntShow: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam5_clo)});
  }
  case TAG_IntAnd: {
    return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get());
  }
  case TAG_IntOr: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam6_clo));
  }
  case TAG_IntXor: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam7_clo));
  }
  case TAG_IntShl: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam8_clo));
  }
  case TAG_IntShr: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam9_clo));
  }
  case TAG_FloatAdd: {
    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get());
  }
  case TAG_FloatSub: {
    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get());
  }
  case TAG_FloatMul: {
    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get());
  }
  case TAG_FloatDiv: {
    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get());
  }
  case TAG_FloatEq: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam10_clo));
  }
  case TAG_FloatLt: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam11_clo));
  }
  case TAG_FloatLe: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam12_clo));
  }
  case TAG_FloatShow: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam13_clo)});
  }
  case TAG_FloatFromInt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam14_clo)});
  }
  case TAG_FloatSqrt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam15_clo)});
  }
  case TAG_OnWindows: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam16_clo)});
  }
  case TAG_FloatFloor: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam17_clo)});
  }
  case TAG_FloatSin: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam18_clo)});
  }
  case TAG_FloatCos: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam19_clo)});
  }
  case TAG_FloatTan: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam20_clo)});
  }
  case TAG_FloatAsin: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam21_clo)});
  }
  case TAG_FloatAcos: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam22_clo)});
  }
  case TAG_FloatAtan: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam23_clo)});
  }
  case TAG_FloatAtan2: {
    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get());
  }
  case TAG_FloatExp: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam24_clo)});
  }
  case TAG_FloatLog: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam25_clo)});
  }
  case TAG_FloatPow: {
    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get());
  }
  case TAG_ArrayLength: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam26_clo)});
  }
  case TAG_ArrayIndex: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam28_clo)});
  }
  case TAG_ArraySet: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam31_clo)});
  }
  case TAG_ArrayGenerate: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam35_clo)});
  }
  case TAG_ArrayFromList: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam39_clo)});
  }
  case TAG_ArrayToList: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam41_clo)});
  }
  case TAG_ArrayReplicate: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam43_clo)});
  }
  case TAG_ArraySlice: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam46_clo)});
  }
  case TAG_ArrayAppend: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam50_clo)});
  }
  case TAG_ArrayInsertAt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam53_clo)});
  }
  case TAG_ArrayRemoveAt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam57_clo)});
  }
  case TAG_ArrayPush: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam60_clo)});
  }
  case TAG_ArrayReserve: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam63_clo)});
  }
  case TAG_StrAppend: {
    return heff_dup(g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get());
  }
  case TAG_StrLength: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam66_clo)});
  }
  case TAG_StrSlice: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam67_clo)});
  }
  case TAG_StrEq: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam70_clo));
  }
  case TAG_StrLt: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam71_clo));
  }
  case TAG_StrCompare: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam72_clo));
  }
  case TAG_StrFind: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam73_clo));
  }
  case TAG_RuneEq: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam75_clo));
  }
  case TAG_RuneLt: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam76_clo));
  }
  case TAG_RuneLe: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam77_clo));
  }
  case TAG_RuneToInt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam78_clo)});
  }
  case TAG_RuneFromInt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam79_clo)});
  }
  case TAG_Keep: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam80_clo)});
  }
  case TAG_Panic: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam82_clo)});
  }
  case TAG_StrByteAt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam84_clo)});
  }
  case TAG_StrFromByte: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam86_clo)});
  }
  case TAG_StrRuneAt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam87_clo)});
  }
  case TAG_StrRuneWidth: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam89_clo)});
  }
  case TAG_StrRuneCount: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam91_clo)});
  }
  case TAG_StrRunes: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam92_clo)});
  }
  case TAG_StrOfRunes: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam93_clo)});
  }
  case TAG_StrToJS: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam94_clo)});
  }
  case TAG_StrFromJS: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam95_clo)});
  }
  case TAG_BytesLength: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam96_clo)});
  }
  case TAG_BytesAt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam97_clo)});
  }
  case TAG_BytesSlice: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam99_clo)});
  }
  case TAG_BytesAppend: {
    return heff_dup(g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get());
  }
  case TAG_BytesConcat: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam102_clo)});
  }
  case TAG_BytesEq: {
    V v_f_241268 = ((V)&g_heff_2ecompile_2einterp_2eprim_lam103_clo);
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam104, 2, 1, (V[]){v_f_241268})});
  }
  case TAG_BytesFromList: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam106_clo)});
  }
  case TAG_BytesToList: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam107_clo)});
  }
  case TAG_BytesFromString: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam108_clo)});
  }
  case TAG_BytesAsString: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam109_clo)});
  }
  case TAG_BytesToString: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam110_clo)});
  }
  case TAG_BytesIntAt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam111_clo)});
  }
  case TAG_BytesOfInt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam115_clo)});
  }
  case TAG_BytesHasAt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam118_clo)});
  }
  case TAG_BitsLength: {
    return heff_dup(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get());
  }
  case TAG_BitsIntAt: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam121_clo));
  }
  case TAG_BitsOfInt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam125_clo)});
  }
  case TAG_BitsConcat: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam128_clo)});
  }
  case TAG_BitsSlice: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam129_clo));
  }
  case TAG_BitsOfBytes: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam132_clo)});
  }
  case TAG_BitsBytes: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam133_clo));
  }
  case TAG_BitsEq: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam134_clo));
  }
  case TAG_FloatBits: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam136_clo)});
  }
  case TAG_FloatOfBits: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam138_clo)});
  }
  case TAG_FloatOfDecimal: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam140_clo)});
  }
  case TAG_StrHash: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam144_clo)});
  }
  case TAG_StrHashRange: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam145_clo)});
  }
  case TAG_StrEqRange: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam148_clo));
  }
  case TAG_IntHash: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam151_clo)});
  }
  case TAG_TrieSlot: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam152_clo)});
  }
  case TAG_OfFixed: {
    V v_w_242147 = heff_field(v_p_240, 0);
    V v_op_242148 = heff_field(v_p_240, 1);
    HEFF_LAST return g_heff_2ecompile_2einterp_2efixedPrimV(heff_rec_n(2, shape_fixed__op, (V[]){heff_dup(v_w_242147), heff_dup(v_op_242148)}));
  }
  default: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam155, 2, 1, (V[]){heff_dup(v_p_240)})});
  }
  }
}
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2eprim(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_b_242 = args[1];
  if (heff_intEq_c_lent(v_b_242, MK_INT(0LL), 2)) {
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){MK_INT(0LL)})});
  } else {
    V v_t_243 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_241, v_b_242)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_243});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args) {
  V v_a_244 = args[0];
  V v_b_245 = args[1];
  if (heff_intEq_c_lent(v_b_245, MK_INT(0LL), 2)) {
    heff_drop(v_b_245);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_244})});
  } else {
    V v_t_246 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMod(v_a_244, v_b_245)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_246});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args) {
  V v_a_247 = args[0];
  V v_b_248 = args[1];
  V v_t_249;
  if (heff_intEq_c(v_a_247, v_b_248)) {
    v_t_249 = ((V)&g_heff_2ecompile_2einterp_2eprim_str0);
  } else {
    v_t_249 = ((V)&g_heff_2ecompile_2einterp_2eprim_str1);
  }
  V v_t_2410 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2410});
}
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args) {
  V v_a_2411 = args[0];
  V v_b_2412 = args[1];
  V v_t_2413;
  if (heff_intLt_c(v_a_2411, v_b_2412)) {
    v_t_2413 = ((V)&g_heff_2ecompile_2einterp_2eprim_str2);
  } else {
    v_t_2413 = ((V)&g_heff_2ecompile_2einterp_2eprim_str3);
  }
  V v_t_2414 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2414});
}
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args) {
  V v_a_2415 = args[0];
  V v_b_2416 = args[1];
  V v_t_2417;
  if (heff_intLe_c(v_a_2415, v_b_2416)) {
    v_t_2417 = ((V)&g_heff_2ecompile_2einterp_2eprim_str4);
  } else {
    v_t_2417 = ((V)&g_heff_2ecompile_2einterp_2eprim_str5);
  }
  V v_t_2418 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2418});
}
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args) {
  V v_d_2419 = args[0];
  V v_a_2420 = args[1];
  V v_x1_2421 = heff_tr(heff_call(v_a_2420, 1, (V[]){v_d_2419}));
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_Ok: {
    V v_v_2422 = heff_field(v_x1_2421, 0);
    V v_ru_24x1_2421_24Ok = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
    switch (heff_tag_of(v_v_2422)) {
    case TAG_VFun: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2422, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_2427 = heff_field(v_v_2422, 0);
      V v_ru_24v_2422_24VInt = heff_take_reuse_n(v_v_2422, 1ULL, 1);
      V v_t_2428 = heff_tag_at_n(v_ru_24v_2422_24VInt, TAG_VStr, 1, (V[]){heff_intShow(v_a_2427)});
      return heff_tag_at_n(v_ru_24x1_2421_24Ok, TAG_Ok, 1, (V[]){v_t_2428});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2422, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_2422);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2437 = heff_field(v_x1_2421, 0);
    V v_ru_24x1_2421_24Bug = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_2421_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_2437});
  }
  default: return heff_nomatch(v_x1_2421);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args) {
  V v_a_2438 = args[0];
  V v_b_2439 = args[1];
  V v_t_2440 = (g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), v_a_2438, v_b_2439));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2440})});
}
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args) {
  V v_a_2441 = args[0];
  V v_b_2442 = args[1];
  V v_t_2443 = (g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(MK_INT(2LL), v_a_2441, v_b_2442));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2443})});
}
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args) {
  V v_a_2444 = args[0];
  V v_b_2445 = args[1];
  if (heff_intLt_c_lent(v_b_2445, MK_INT(0LL), 2)) {
    V v_k_2446 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2445)));
    V v_t_2447 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2444, v_k_2446)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2447});
  } else {
    V v_k_2448 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2445));
    V v_t_2449 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2444, v_k_2448)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2449});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args) {
  V v_a_2450 = args[0];
  V v_b_2451 = args[1];
  if (heff_intLt_c_lent(v_b_2451, MK_INT(0LL), 2)) {
    V v_k_2452 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2451)));
    V v_t_2453 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2450, v_k_2452)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2453});
  } else {
    V v_k_2454 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2451));
    V v_t_2455 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2450, v_k_2454)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2455});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args) {
  V v_box_24a_2456 = args[0];
  V v_box_24b_2457 = args[1];
  double v_a_2456 = heff_unbox_f64(v_box_24a_2456);
  double v_b_2457 = heff_unbox_f64(v_box_24b_2457);
  V v_t_2458;
  if ((v_a_2456 == v_b_2457)) {
    v_t_2458 = ((V)&g_heff_2ecompile_2einterp_2eprim_str6);
  } else {
    v_t_2458 = ((V)&g_heff_2ecompile_2einterp_2eprim_str7);
  }
  V v_t_2459 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2459});
}
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args) {
  V v_box_24a_2460 = args[0];
  V v_box_24b_2461 = args[1];
  double v_a_2460 = heff_unbox_f64(v_box_24a_2460);
  double v_b_2461 = heff_unbox_f64(v_box_24b_2461);
  V v_t_2462;
  if ((v_a_2460 < v_b_2461)) {
    v_t_2462 = ((V)&g_heff_2ecompile_2einterp_2eprim_str8);
  } else {
    v_t_2462 = ((V)&g_heff_2ecompile_2einterp_2eprim_str9);
  }
  V v_t_2463 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2463});
}
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args) {
  V v_box_24a_2464 = args[0];
  V v_box_24b_2465 = args[1];
  double v_a_2464 = heff_unbox_f64(v_box_24a_2464);
  double v_b_2465 = heff_unbox_f64(v_box_24b_2465);
  V v_t_2466;
  if ((v_a_2464 <= v_b_2465)) {
    v_t_2466 = ((V)&g_heff_2ecompile_2einterp_2eprim_str10);
  } else {
    v_t_2466 = ((V)&g_heff_2ecompile_2einterp_2eprim_str11);
  }
  V v_t_2467 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2467});
}
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args) {
  V v_d_2468 = args[0];
  V v_a_2469 = args[1];
  V v_x1_2470 = heff_tr(heff_call(v_a_2469, 1, (V[]){v_d_2468}));
  switch (heff_tag_of(v_x1_2470)) {
  case TAG_Ok: {
    V v_v_2471 = heff_field(v_x1_2470, 0);
    V v_ru_24x1_2470_24Ok = heff_take_reuse_n(v_x1_2470, 1ULL, 1);
    switch (heff_tag_of(v_v_2471)) {
    case TAG_VFun: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2471, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      V v_a_2477 = heff_tget_v(v_v_2471, 0);
      V v_ru_24v_2471_24VFloat = heff_take_reuse_na(v_v_2471, 0ULL, 1);
      V v_t_2478 = heff_tag_at_n(v_ru_24v_2471_24VFloat, TAG_VStr, 1, (V[]){heff_floatShow(v_a_2477)});
      return heff_tag_at_n(v_ru_24x1_2470_24Ok, TAG_Ok, 1, (V[]){v_t_2478});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2471, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_2471);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2486 = heff_field(v_x1_2470, 0);
    V v_ru_24x1_2470_24Bug = heff_take_reuse_n(v_x1_2470, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_2470_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_2486});
  }
  default: return heff_nomatch(v_x1_2470);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args) {
  V v_d_2487 = args[0];
  V v_a_2488 = args[1];
  V v_x1_2489 = heff_tr(heff_call(v_a_2488, 1, (V[]){v_d_2487}));
  switch (heff_tag_of(v_x1_2489)) {
  case TAG_Ok: {
    V v_v_2490 = heff_field(v_x1_2489, 0);
    V v_ru_24x1_2489_24Ok = heff_take_reuse_n(v_x1_2489, 1ULL, 1);
    switch (heff_tag_of(v_v_2490)) {
    case TAG_VFun: {
      heff_take_n(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2490, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_2495 = heff_field(v_v_2490, 0);
      V v_ru_24v_2490_24VInt = heff_take_reuse_n(v_v_2490, 1ULL, 1);
      V v_t_2496 = heff_tag_at_nf(v_ru_24v_2490_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(heff_from_int_f64(v_a_2495))});
      return heff_tag_at_n(v_ru_24x1_2489_24Ok, TAG_Ok, 1, (V[]){v_t_2496});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2490, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_2490);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24105 = heff_field(v_x1_2489, 0);
    V v_ru_24x1_2489_24Bug = heff_take_reuse_n(v_x1_2489, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_2489_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24105});
  }
  default: return heff_nomatch(v_x1_2489);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args) {
  V v_d_24106 = args[0];
  V v_a_24107 = args[1];
  V v_x1_24108 = heff_tr(heff_call(v_a_24107, 1, (V[]){v_d_24106}));
  switch (heff_tag_of(v_x1_24108)) {
  case TAG_Ok: {
    V v_v_24109 = heff_field(v_x1_24108, 0);
    V v_ru_24x1_24108_24Ok = heff_take_reuse_n(v_x1_24108, 1ULL, 1);
    switch (heff_tag_of(v_v_24109)) {
    case TAG_VFun: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24109, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24115 = heff_tflat_f64(v_v_24109, 0);
      V v_ru_24v_24109_24VFloat = heff_take_reuse_na(v_v_24109, 0ULL, 1);
      V v_t_24116 = heff_tag_at_nf(v_ru_24v_24109_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(sqrt(v_a_24115))});
      return heff_tag_at_n(v_ru_24x1_24108_24Ok, TAG_Ok, 1, (V[]){v_t_24116});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24109, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24109);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24124 = heff_field(v_x1_24108, 0);
    V v_ru_24x1_24108_24Bug = heff_take_reuse_n(v_x1_24108, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24108_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24124});
  }
  default: return heff_nomatch(v_x1_24108);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args) {
  V v_d_24125 = args[0];
  V v_a_24126 = args[1];
  heff_drop(v_d_24125);
  heff_drop(v_a_24126);
  V v_t_24127 = heff_onWindows(NTAG(TAG_MkUnit));
  V v_t_24128;
  if ((heff_dup(v_t_24127) == NTAG(TAG_True))) {
    heff_drop(v_t_24127);
    v_t_24128 = ((V)&g_heff_2ecompile_2einterp_2eprim_str12);
  } else {
    heff_drop(v_t_24127);
    v_t_24128 = ((V)&g_heff_2ecompile_2einterp_2eprim_str13);
  }
  V v_t_24129 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24128, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24129});
}
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args) {
  V v_d_24130 = args[0];
  V v_a_24131 = args[1];
  V v_x1_24132 = heff_tr(heff_call(v_a_24131, 1, (V[]){v_d_24130}));
  switch (heff_tag_of(v_x1_24132)) {
  case TAG_Ok: {
    V v_v_24133 = heff_field(v_x1_24132, 0);
    V v_ru_24x1_24132_24Ok = heff_take_reuse_n(v_x1_24132, 1ULL, 1);
    switch (heff_tag_of(v_v_24133)) {
    case TAG_VFun: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24133, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24139 = heff_tflat_f64(v_v_24133, 0);
      V v_ru_24v_24133_24VFloat = heff_take_reuse_na(v_v_24133, 0ULL, 1);
      if (((v_a_24139 - v_a_24139) == (0.0))) {
        V v_t_24140 = heff_tag_at_n(v_ru_24v_24133_24VFloat, TAG_VInt, 1, (V[]){heff_floor_f64(v_a_24139)});
        return heff_tag_at_n(v_ru_24x1_24132_24Ok, TAG_Ok, 1, (V[]){v_t_24140});
      } else {
        return heff_tag_at_n(v_ru_24x1_24132_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24133_24VFloat, TAG_VInt, 1, (V[]){MK_INT(0LL)})});
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24133, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24133);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24148 = heff_field(v_x1_24132, 0);
    V v_ru_24x1_24132_24Bug = heff_take_reuse_n(v_x1_24132, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24132_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24148});
  }
  default: return heff_nomatch(v_x1_24132);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args) {
  V v_d_24149 = args[0];
  V v_a_24150 = args[1];
  V v_x1_24151 = heff_tr(heff_call(v_a_24150, 1, (V[]){v_d_24149}));
  switch (heff_tag_of(v_x1_24151)) {
  case TAG_Ok: {
    V v_v_24152 = heff_field(v_x1_24151, 0);
    V v_ru_24x1_24151_24Ok = heff_take_reuse_n(v_x1_24151, 1ULL, 1);
    switch (heff_tag_of(v_v_24152)) {
    case TAG_VFun: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24152, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24158 = heff_tflat_f64(v_v_24152, 0);
      V v_ru_24v_24152_24VFloat = heff_take_reuse_na(v_v_24152, 0ULL, 1);
      V v_t_24159 = heff_tag_at_nf(v_ru_24v_24152_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(heff_sin(v_a_24158))});
      return heff_tag_at_n(v_ru_24x1_24151_24Ok, TAG_Ok, 1, (V[]){v_t_24159});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24152, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24152);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24167 = heff_field(v_x1_24151, 0);
    V v_ru_24x1_24151_24Bug = heff_take_reuse_n(v_x1_24151, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24151_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24167});
  }
  default: return heff_nomatch(v_x1_24151);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args) {
  V v_d_24168 = args[0];
  V v_a_24169 = args[1];
  V v_x1_24170 = heff_tr(heff_call(v_a_24169, 1, (V[]){v_d_24168}));
  switch (heff_tag_of(v_x1_24170)) {
  case TAG_Ok: {
    V v_v_24171 = heff_field(v_x1_24170, 0);
    V v_ru_24x1_24170_24Ok = heff_take_reuse_n(v_x1_24170, 1ULL, 1);
    switch (heff_tag_of(v_v_24171)) {
    case TAG_VFun: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24171, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24177 = heff_tflat_f64(v_v_24171, 0);
      V v_ru_24v_24171_24VFloat = heff_take_reuse_na(v_v_24171, 0ULL, 1);
      V v_t_24178 = heff_tag_at_nf(v_ru_24v_24171_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(heff_cos(v_a_24177))});
      return heff_tag_at_n(v_ru_24x1_24170_24Ok, TAG_Ok, 1, (V[]){v_t_24178});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24171, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24171);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24186 = heff_field(v_x1_24170, 0);
    V v_ru_24x1_24170_24Bug = heff_take_reuse_n(v_x1_24170, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24170_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24186});
  }
  default: return heff_nomatch(v_x1_24170);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args) {
  V v_d_24187 = args[0];
  V v_a_24188 = args[1];
  V v_x1_24189 = heff_tr(heff_call(v_a_24188, 1, (V[]){v_d_24187}));
  switch (heff_tag_of(v_x1_24189)) {
  case TAG_Ok: {
    V v_v_24190 = heff_field(v_x1_24189, 0);
    V v_ru_24x1_24189_24Ok = heff_take_reuse_n(v_x1_24189, 1ULL, 1);
    switch (heff_tag_of(v_v_24190)) {
    case TAG_VFun: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24190, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24196 = heff_tflat_f64(v_v_24190, 0);
      V v_ru_24v_24190_24VFloat = heff_take_reuse_na(v_v_24190, 0ULL, 1);
      V v_t_24197 = heff_tag_at_nf(v_ru_24v_24190_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(heff_tan(v_a_24196))});
      return heff_tag_at_n(v_ru_24x1_24189_24Ok, TAG_Ok, 1, (V[]){v_t_24197});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24190, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24190);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24205 = heff_field(v_x1_24189, 0);
    V v_ru_24x1_24189_24Bug = heff_take_reuse_n(v_x1_24189, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24189_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24205});
  }
  default: return heff_nomatch(v_x1_24189);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args) {
  V v_d_24206 = args[0];
  V v_a_24207 = args[1];
  V v_x1_24208 = heff_tr(heff_call(v_a_24207, 1, (V[]){v_d_24206}));
  switch (heff_tag_of(v_x1_24208)) {
  case TAG_Ok: {
    V v_v_24209 = heff_field(v_x1_24208, 0);
    V v_ru_24x1_24208_24Ok = heff_take_reuse_n(v_x1_24208, 1ULL, 1);
    switch (heff_tag_of(v_v_24209)) {
    case TAG_VFun: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24209, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24215 = heff_tflat_f64(v_v_24209, 0);
      V v_ru_24v_24209_24VFloat = heff_take_reuse_na(v_v_24209, 0ULL, 1);
      V v_t_24216 = heff_tag_at_nf(v_ru_24v_24209_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(asin(v_a_24215))});
      return heff_tag_at_n(v_ru_24x1_24208_24Ok, TAG_Ok, 1, (V[]){v_t_24216});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24209, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24209);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24224 = heff_field(v_x1_24208, 0);
    V v_ru_24x1_24208_24Bug = heff_take_reuse_n(v_x1_24208, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24208_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24224});
  }
  default: return heff_nomatch(v_x1_24208);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args) {
  V v_d_24225 = args[0];
  V v_a_24226 = args[1];
  V v_x1_24227 = heff_tr(heff_call(v_a_24226, 1, (V[]){v_d_24225}));
  switch (heff_tag_of(v_x1_24227)) {
  case TAG_Ok: {
    V v_v_24228 = heff_field(v_x1_24227, 0);
    V v_ru_24x1_24227_24Ok = heff_take_reuse_n(v_x1_24227, 1ULL, 1);
    switch (heff_tag_of(v_v_24228)) {
    case TAG_VFun: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24228, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24234 = heff_tflat_f64(v_v_24228, 0);
      V v_ru_24v_24228_24VFloat = heff_take_reuse_na(v_v_24228, 0ULL, 1);
      V v_t_24235 = heff_tag_at_nf(v_ru_24v_24228_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(acos(v_a_24234))});
      return heff_tag_at_n(v_ru_24x1_24227_24Ok, TAG_Ok, 1, (V[]){v_t_24235});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24228, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24228);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24243 = heff_field(v_x1_24227, 0);
    V v_ru_24x1_24227_24Bug = heff_take_reuse_n(v_x1_24227, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24227_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24243});
  }
  default: return heff_nomatch(v_x1_24227);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args) {
  V v_d_24244 = args[0];
  V v_a_24245 = args[1];
  V v_x1_24246 = heff_tr(heff_call(v_a_24245, 1, (V[]){v_d_24244}));
  switch (heff_tag_of(v_x1_24246)) {
  case TAG_Ok: {
    V v_v_24247 = heff_field(v_x1_24246, 0);
    V v_ru_24x1_24246_24Ok = heff_take_reuse_n(v_x1_24246, 1ULL, 1);
    switch (heff_tag_of(v_v_24247)) {
    case TAG_VFun: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24247, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24253 = heff_tflat_f64(v_v_24247, 0);
      V v_ru_24v_24247_24VFloat = heff_take_reuse_na(v_v_24247, 0ULL, 1);
      V v_t_24254 = heff_tag_at_nf(v_ru_24v_24247_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(atan(v_a_24253))});
      return heff_tag_at_n(v_ru_24x1_24246_24Ok, TAG_Ok, 1, (V[]){v_t_24254});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24247, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24247);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24262 = heff_field(v_x1_24246, 0);
    V v_ru_24x1_24246_24Bug = heff_take_reuse_n(v_x1_24246, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24246_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24262});
  }
  default: return heff_nomatch(v_x1_24246);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args) {
  V v_d_24263 = args[0];
  V v_a_24264 = args[1];
  V v_x1_24265 = heff_tr(heff_call(v_a_24264, 1, (V[]){v_d_24263}));
  switch (heff_tag_of(v_x1_24265)) {
  case TAG_Ok: {
    V v_v_24266 = heff_field(v_x1_24265, 0);
    V v_ru_24x1_24265_24Ok = heff_take_reuse_n(v_x1_24265, 1ULL, 1);
    switch (heff_tag_of(v_v_24266)) {
    case TAG_VFun: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24266, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24272 = heff_tflat_f64(v_v_24266, 0);
      V v_ru_24v_24266_24VFloat = heff_take_reuse_na(v_v_24266, 0ULL, 1);
      V v_t_24273 = heff_tag_at_nf(v_ru_24v_24266_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(heff_exp(v_a_24272))});
      return heff_tag_at_n(v_ru_24x1_24265_24Ok, TAG_Ok, 1, (V[]){v_t_24273});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24266, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24266);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24281 = heff_field(v_x1_24265, 0);
    V v_ru_24x1_24265_24Bug = heff_take_reuse_n(v_x1_24265, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24265_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24281});
  }
  default: return heff_nomatch(v_x1_24265);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args) {
  V v_d_24282 = args[0];
  V v_a_24283 = args[1];
  V v_x1_24284 = heff_tr(heff_call(v_a_24283, 1, (V[]){v_d_24282}));
  switch (heff_tag_of(v_x1_24284)) {
  case TAG_Ok: {
    V v_v_24285 = heff_field(v_x1_24284, 0);
    V v_ru_24x1_24284_24Ok = heff_take_reuse_n(v_x1_24284, 1ULL, 1);
    switch (heff_tag_of(v_v_24285)) {
    case TAG_VFun: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24285, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24291 = heff_tflat_f64(v_v_24285, 0);
      V v_ru_24v_24285_24VFloat = heff_take_reuse_na(v_v_24285, 0ULL, 1);
      V v_t_24292 = heff_tag_at_nf(v_ru_24v_24285_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(heff_log(v_a_24291))});
      return heff_tag_at_n(v_ru_24x1_24284_24Ok, TAG_Ok, 1, (V[]){v_t_24292});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24285, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24285);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24300 = heff_field(v_x1_24284, 0);
    V v_ru_24x1_24284_24Bug = heff_take_reuse_n(v_x1_24284, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24284_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24300});
  }
  default: return heff_nomatch(v_x1_24284);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args) {
  V v_d_24303 = args[0];
  V v_a_24304 = args[1];
  V v_x1_24305 = heff_tr(heff_call(v_a_24304, 1, (V[]){v_d_24303}));
  switch (heff_tag_of(v_x1_24305)) {
  case TAG_Ok: {
    V v_v_24306 = heff_field(v_x1_24305, 0);
    V v_ru_24x1_24305_24Ok = heff_take_reuse_n(v_x1_24305, 1ULL, 1);
    switch (heff_tag_of(v_v_24306)) {
    case TAG_VFun: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24306, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24316 = heff_field(v_v_24306, 0);
      V v_ru_24v_24306_24VArr = heff_take_reuse_n(v_v_24306, 1ULL, 1);
      V v_t_24317 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_xs_24316); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      return heff_tag_at_n(v_ru_24x1_24305_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24306_24VArr, TAG_VInt, 1, (V[]){v_t_24317})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24306, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24306);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24321 = heff_field(v_x1_24305, 0);
    V v_ru_24x1_24305_24Bug = heff_take_reuse_n(v_x1_24305, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24305_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24321});
  }
  default: return heff_nomatch(v_x1_24305);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args) {
  V v_d_24301 = args[0];
  V v_u_24302 = args[1];
  heff_drop(v_d_24301);
  heff_drop(v_u_24302);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam27_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args) {
  V v_d_24338 = args[0];
  V v_a_24339 = args[1];
  V v_xs_24337 = heff_env(self)[0];
  V v_x1_24340 = heff_tr(heff_call(v_a_24339, 1, (V[]){v_d_24338}));
  switch (heff_tag_of(v_x1_24340)) {
  case TAG_Ok: {
    V v_v_24341 = heff_field(v_x1_24340, 0);
    V v_ru_24x1_24340_24Ok = heff_take_reuse_n(v_x1_24340, 1ULL, 1);
    switch (heff_tag_of(v_v_24341)) {
    case TAG_VFun: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24341, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24346 = heff_field(v_v_24341, 0);
      V v_ru_24v_24341_24VInt = heff_take_reuse_n(v_v_24341, 1ULL, 1);
      if ((heff_intLe_c_lent(MK_INT(0LL), v_a_24346, 1) && ({ V v_t_242152 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24337)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; }); int c_ = heff_intLt_c_lent(v_a_24346, v_t_242152, 0); heff_drop(v_t_242152); c_; }))) {
        heff_clo_take(self, 1);
        HeffT2 v_t_24347 = ({ V b_0 = heff_arrayToList(v_xs_24337); V a_1 = v_a_24346; HeffT2 r_ = (g_heff_2ecompile_2einterp_2enthV_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_24349 = v_t_24347.f[1];
          int64_t v_tag_24348 = ((int64_t)v_t_24347.f[0]);
          if ((v_tag_24348 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24v_24341_24VInt, 1);
            V v_v_24350 = v_field_24349;
            return heff_tag_at_n(v_ru_24x1_24340_24Ok, TAG_Ok, 1, (V[]){v_v_24350});
          } else {
            heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
            heff_drop(v_field_24349);
            return heff_tag_at_n(v_ru_24v_24341_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str14)});
          }
        }
      } else {
        heff_drop(self);
        heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
        heff_drop(v_a_24346);
        heff_drop_cell(v_ru_24v_24341_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24341, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24341, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24341);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24359 = heff_field(v_x1_24340, 0);
    V v_ru_24x1_24340_24Bug = heff_take_reuse_n(v_x1_24340, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24340_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24359});
  }
  default: return heff_nomatch(v_x1_24340);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args) {
  V v_d_24324 = args[0];
  V v_a_24325 = args[1];
  V v_x1_24326 = heff_tr(heff_call(v_a_24325, 1, (V[]){v_d_24324}));
  switch (heff_tag_of(v_x1_24326)) {
  case TAG_Ok: {
    V v_v_24327 = heff_field(v_x1_24326, 0);
    V v_ru_24x1_24326_24Ok = heff_take_reuse_n(v_x1_24326, 1ULL, 1);
    switch (heff_tag_of(v_v_24327)) {
    case TAG_VFun: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24327, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24337 = heff_field(v_v_24327, 0);
      V v_ru_24v_24327_24VArr = heff_take_reuse_n(v_v_24327, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24326_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24327_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam30, 2, 1, (V[]){v_xs_24337})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24327, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24327);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24363 = heff_field(v_x1_24326, 0);
    V v_ru_24x1_24326_24Bug = heff_take_reuse_n(v_x1_24326, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24326_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24363});
  }
  default: return heff_nomatch(v_x1_24326);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args) {
  V v_d_24322 = args[0];
  V v_u_24323 = args[1];
  heff_drop(v_d_24322);
  heff_drop(v_u_24323);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam29_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args) {
  V v_d_24389 = args[0];
  V v_x_24390 = args[1];
  V v_a_24388 = heff_env(self)[0];
  V v_xs_24379 = heff_env(self)[1];
  V v_x1_24391 = heff_tr(heff_call(v_x_24390, 1, (V[]){v_d_24389}));
  switch (heff_tag_of(v_x1_24391)) {
  case TAG_Ok: {
    V v_v_24392 = heff_field(v_x1_24391, 0);
    V v_ru_24x1_24391_24Ok = heff_take_reuse_n(v_x1_24391, 1ULL, 1);
    if ((heff_intLe_c_lent(MK_INT(0LL), v_a_24388, 1) && ({ V v_t_242153 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24379)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; }); int c_ = heff_intLt_c_lent(v_a_24388, v_t_242153, 0); heff_drop(v_t_242153); c_; }))) {
      heff_clo_take(self, 2);
      V v_t_24393 = (g_heff_2ecompile_2einterp_2esetAt(heff_arrayToList(v_xs_24379), v_a_24388, v_v_24392));
      V v_t_24394 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24393)});
      return heff_tag_at_n(v_ru_24x1_24391_24Ok, TAG_Ok, 1, (V[]){v_t_24394});
    } else {
      heff_clo_take(self, 2);
      heff_drop(v_a_24388);
      heff_drop(v_v_24392);
      return heff_tag_at_n(v_ru_24x1_24391_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VArr, 1, (V[]){v_xs_24379})});
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24395 = heff_field(v_x1_24391, 0);
    V v_ru_24x1_24391_24Bug = heff_take_reuse_n(v_x1_24391, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24391_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24395});
  }
  default: return heff_nomatch(v_x1_24391);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args) {
  V v_d_24380 = args[0];
  V v_a_24381 = args[1];
  V v_xs_24379 = heff_env(self)[0];
  V v_x1_24382 = heff_tr(heff_call(v_a_24381, 1, (V[]){v_d_24380}));
  switch (heff_tag_of(v_x1_24382)) {
  case TAG_Ok: {
    V v_v_24383 = heff_field(v_x1_24382, 0);
    V v_ru_24x1_24382_24Ok = heff_take_reuse_n(v_x1_24382, 1ULL, 1);
    switch (heff_tag_of(v_v_24383)) {
    case TAG_VFun: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24383, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24388 = heff_field(v_v_24383, 0);
      V v_ru_24v_24383_24VInt = heff_take_reuse_n(v_v_24383, 1ULL, 1);
      heff_clo_take(self, 1);
      return heff_tag_at_n(v_ru_24x1_24382_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24383_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam34, 2, 2, (V[]){v_a_24388, v_xs_24379})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24383, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24383, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24383);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24404 = heff_field(v_x1_24382, 0);
    V v_ru_24x1_24382_24Bug = heff_take_reuse_n(v_x1_24382, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24382_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24404});
  }
  default: return heff_nomatch(v_x1_24382);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args) {
  V v_d_24366 = args[0];
  V v_a_24367 = args[1];
  V v_x1_24368 = heff_tr(heff_call(v_a_24367, 1, (V[]){v_d_24366}));
  switch (heff_tag_of(v_x1_24368)) {
  case TAG_Ok: {
    V v_v_24369 = heff_field(v_x1_24368, 0);
    V v_ru_24x1_24368_24Ok = heff_take_reuse_n(v_x1_24368, 1ULL, 1);
    switch (heff_tag_of(v_v_24369)) {
    case TAG_VFun: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24369, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24379 = heff_field(v_v_24369, 0);
      V v_ru_24v_24369_24VArr = heff_take_reuse_n(v_v_24369, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24368_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24369_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam33, 2, 1, (V[]){v_xs_24379})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24369, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24369);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24408 = heff_field(v_x1_24368, 0);
    V v_ru_24x1_24368_24Bug = heff_take_reuse_n(v_x1_24368, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24368_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24408});
  }
  default: return heff_nomatch(v_x1_24368);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args) {
  V v_d_24364 = args[0];
  V v_u_24365 = args[1];
  heff_drop(v_d_24364);
  heff_drop(v_u_24365);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam32_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args) {
  V v_vs_24424 = args[0];
  V v_t_24425 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_vs_24424)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24425});
}
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args) {
  V v_d_24420 = args[0];
  V v_f_24421 = args[1];
  V v_a_24419 = heff_env(self)[0];
  V v_x1_24422 = heff_tr(heff_call(v_f_24421, 1, (V[]){heff_dup(v_d_24420)}));
  switch (heff_tag_of(v_x1_24422)) {
  case TAG_Ok: {
    V v_v_24423 = heff_field(v_x1_24422, 0);
    heff_take_n(v_x1_24422, 1ULL, 1);
    heff_clo_take(self, 1);
    return (g_heff_2ecompile_2einterp_2egenGo(v_d_24420, MK_INT(0LL), v_a_24419, v_v_24423, ((V)&g_heff_2ecompile_2einterp_2eprim_lam38_clo)));
  }
  case TAG_Abn: {
    heff_drop(v_d_24420);
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_24420);
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24426 = heff_field(v_x1_24422, 0);
    V v_ru_24x1_24422_24Bug = heff_take_reuse_n(v_x1_24422, 1ULL, 1);
    heff_drop(v_d_24420);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24422_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24426});
  }
  default: return heff_nomatch(v_x1_24422);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args) {
  V v_d_24411 = args[0];
  V v_a_24412 = args[1];
  V v_x1_24413 = heff_tr(heff_call(v_a_24412, 1, (V[]){v_d_24411}));
  switch (heff_tag_of(v_x1_24413)) {
  case TAG_Ok: {
    V v_v_24414 = heff_field(v_x1_24413, 0);
    V v_ru_24x1_24413_24Ok = heff_take_reuse_n(v_x1_24413, 1ULL, 1);
    switch (heff_tag_of(v_v_24414)) {
    case TAG_VFun: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24414, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24419 = heff_field(v_v_24414, 0);
      V v_ru_24v_24414_24VInt = heff_take_reuse_n(v_v_24414, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24413_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24414_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam37, 2, 1, (V[]){v_a_24419})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24414, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24414);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24435 = heff_field(v_x1_24413, 0);
    V v_ru_24x1_24413_24Bug = heff_take_reuse_n(v_x1_24413, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24413_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24435});
  }
  default: return heff_nomatch(v_x1_24413);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args) {
  V v_d_24409 = args[0];
  V v_u_24410 = args[1];
  heff_drop(v_d_24409);
  heff_drop(v_u_24410);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam36_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args) {
  V v_d_24438 = args[0];
  V v_l_24439 = args[1];
  V v_x1_24440 = heff_tr(heff_call(v_l_24439, 1, (V[]){v_d_24438}));
  switch (heff_tag_of(v_x1_24440)) {
  case TAG_Ok: {
    V v_v_24441 = heff_field(v_x1_24440, 0);
    V v_ru_24x1_24440_24Ok = heff_take_reuse_n(v_x1_24440, 1ULL, 1);
    V v_t_24442 = (g_heff_2ecompile_2einterp_2efromListV(v_v_24441, NTAG(TAG_Nil)));
    V v_t_24443 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24442)});
    return heff_tag_at_n(v_ru_24x1_24440_24Ok, TAG_Ok, 1, (V[]){v_t_24443});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24444 = heff_field(v_x1_24440, 0);
    V v_ru_24x1_24440_24Bug = heff_take_reuse_n(v_x1_24440, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24440_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24444});
  }
  default: return heff_nomatch(v_x1_24440);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args) {
  V v_d_24436 = args[0];
  V v_u_24437 = args[1];
  heff_drop(v_d_24436);
  heff_drop(v_u_24437);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam40_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args) {
  V v_d_24447 = args[0];
  V v_a_24448 = args[1];
  V v_x1_24449 = heff_tr(heff_call(v_a_24448, 1, (V[]){v_d_24447}));
  switch (heff_tag_of(v_x1_24449)) {
  case TAG_Ok: {
    V v_v_24450 = heff_field(v_x1_24449, 0);
    V v_ru_24x1_24449_24Ok = heff_take_reuse_n(v_x1_24449, 1ULL, 1);
    switch (heff_tag_of(v_v_24450)) {
    case TAG_VFun: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24450, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24460 = heff_field(v_v_24450, 0);
      heff_take_n(v_v_24450, 1ULL, 1);
      V v_t_24461 = (g_heff_2ecompile_2einterp_2etoListV(heff_arrayToList(v_xs_24460)));
      return heff_tag_at_n(v_ru_24x1_24449_24Ok, TAG_Ok, 1, (V[]){v_t_24461});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24450, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24450);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24465 = heff_field(v_x1_24449, 0);
    V v_ru_24x1_24449_24Bug = heff_take_reuse_n(v_x1_24449, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24449_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24465});
  }
  default: return heff_nomatch(v_x1_24449);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args) {
  V v_d_24445 = args[0];
  V v_u_24446 = args[1];
  heff_drop(v_d_24445);
  heff_drop(v_u_24446);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam42_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args) {
  V v_d_24477 = args[0];
  V v_x_24478 = args[1];
  V v_a_24476 = heff_env(self)[0];
  V v_x1_24479 = heff_tr(heff_call(v_x_24478, 1, (V[]){v_d_24477}));
  switch (heff_tag_of(v_x1_24479)) {
  case TAG_Ok: {
    V v_v_24480 = heff_field(v_x1_24479, 0);
    V v_ru_24x1_24479_24Ok = heff_take_reuse_n(v_x1_24479, 1ULL, 1);
    heff_clo_take(self, 1);
    V v_t_24481 = (g_list_2ereplicate(v_a_24476, v_v_24480));
    V v_t_24482 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24481)});
    return heff_tag_at_n(v_ru_24x1_24479_24Ok, TAG_Ok, 1, (V[]){v_t_24482});
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24483 = heff_field(v_x1_24479, 0);
    V v_ru_24x1_24479_24Bug = heff_take_reuse_n(v_x1_24479, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24479_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24483});
  }
  default: return heff_nomatch(v_x1_24479);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args) {
  V v_d_24468 = args[0];
  V v_a_24469 = args[1];
  V v_x1_24470 = heff_tr(heff_call(v_a_24469, 1, (V[]){v_d_24468}));
  switch (heff_tag_of(v_x1_24470)) {
  case TAG_Ok: {
    V v_v_24471 = heff_field(v_x1_24470, 0);
    V v_ru_24x1_24470_24Ok = heff_take_reuse_n(v_x1_24470, 1ULL, 1);
    switch (heff_tag_of(v_v_24471)) {
    case TAG_VFun: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24471, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24476 = heff_field(v_v_24471, 0);
      V v_ru_24v_24471_24VInt = heff_take_reuse_n(v_v_24471, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24470_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24471_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam45, 2, 1, (V[]){v_a_24476})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24471, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24471);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24492 = heff_field(v_x1_24470, 0);
    V v_ru_24x1_24470_24Bug = heff_take_reuse_n(v_x1_24470, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24470_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24492});
  }
  default: return heff_nomatch(v_x1_24470);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args) {
  V v_d_24466 = args[0];
  V v_u_24467 = args[1];
  heff_drop(v_d_24466);
  heff_drop(v_u_24467);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam44_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args) {
  V v_d_24518 = args[0];
  V v_a_24519 = args[1];
  V v_xs_24508 = heff_env(self)[0];
  V v_a_24517 = heff_env(self)[1];
  V v_x1_24520 = heff_tr(heff_call(v_a_24519, 1, (V[]){v_d_24518}));
  switch (heff_tag_of(v_x1_24520)) {
  case TAG_Ok: {
    V v_v_24521 = heff_field(v_x1_24520, 0);
    V v_ru_24x1_24520_24Ok = heff_take_reuse_n(v_x1_24520, 1ULL, 1);
    switch (heff_tag_of(v_v_24521)) {
    case TAG_VFun: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24521, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24526 = heff_field(v_v_24521, 0);
      V v_ru_24v_24521_24VInt = heff_take_reuse_n(v_v_24521, 1ULL, 1);
      heff_clo_take(self, 2);
      V v_t_24527 = ({ V b_0 = heff_arrayToList(v_xs_24508); V a_1 = v_a_24517; V a_2 = v_a_24526; V r_ = (g_heff_2ecompile_2einterp_2esliceV(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V v_t_24528 = heff_tag_at_n(v_ru_24v_24521_24VInt, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24527)});
      return heff_tag_at_n(v_ru_24x1_24520_24Ok, TAG_Ok, 1, (V[]){v_t_24528});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24521, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24521, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24521);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24537 = heff_field(v_x1_24520, 0);
    V v_ru_24x1_24520_24Bug = heff_take_reuse_n(v_x1_24520, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24520_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24537});
  }
  default: return heff_nomatch(v_x1_24520);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args) {
  V v_d_24509 = args[0];
  V v_a_24510 = args[1];
  V v_xs_24508 = heff_env(self)[0];
  V v_x1_24511 = heff_tr(heff_call(v_a_24510, 1, (V[]){v_d_24509}));
  switch (heff_tag_of(v_x1_24511)) {
  case TAG_Ok: {
    V v_v_24512 = heff_field(v_x1_24511, 0);
    V v_ru_24x1_24511_24Ok = heff_take_reuse_n(v_x1_24511, 1ULL, 1);
    switch (heff_tag_of(v_v_24512)) {
    case TAG_VFun: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24512, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24517 = heff_field(v_v_24512, 0);
      V v_ru_24v_24512_24VInt = heff_take_reuse_n(v_v_24512, 1ULL, 1);
      heff_clo_take(self, 1);
      return heff_tag_at_n(v_ru_24x1_24511_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24512_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam49, 2, 2, (V[]){v_xs_24508, v_a_24517})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24512, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24512, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24512);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24546 = heff_field(v_x1_24511, 0);
    V v_ru_24x1_24511_24Bug = heff_take_reuse_n(v_x1_24511, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24511_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24546});
  }
  default: return heff_nomatch(v_x1_24511);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args) {
  V v_d_24495 = args[0];
  V v_a_24496 = args[1];
  V v_x1_24497 = heff_tr(heff_call(v_a_24496, 1, (V[]){v_d_24495}));
  switch (heff_tag_of(v_x1_24497)) {
  case TAG_Ok: {
    V v_v_24498 = heff_field(v_x1_24497, 0);
    V v_ru_24x1_24497_24Ok = heff_take_reuse_n(v_x1_24497, 1ULL, 1);
    switch (heff_tag_of(v_v_24498)) {
    case TAG_VFun: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24498, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24508 = heff_field(v_v_24498, 0);
      V v_ru_24v_24498_24VArr = heff_take_reuse_n(v_v_24498, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24497_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24498_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam48, 2, 1, (V[]){v_xs_24508})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24498, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24498);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24550 = heff_field(v_x1_24497, 0);
    V v_ru_24x1_24497_24Bug = heff_take_reuse_n(v_x1_24497, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24497_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24550});
  }
  default: return heff_nomatch(v_x1_24497);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args) {
  V v_d_24493 = args[0];
  V v_u_24494 = args[1];
  heff_drop(v_d_24493);
  heff_drop(v_u_24494);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam47_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args) {
  V v_d_24567 = args[0];
  V v_a_24568 = args[1];
  V v_xs_24566 = heff_env(self)[0];
  V v_x1_24569 = heff_tr(heff_call(v_a_24568, 1, (V[]){v_d_24567}));
  switch (heff_tag_of(v_x1_24569)) {
  case TAG_Ok: {
    V v_v_24570 = heff_field(v_x1_24569, 0);
    V v_ru_24x1_24569_24Ok = heff_take_reuse_n(v_x1_24569, 1ULL, 1);
    switch (heff_tag_of(v_v_24570)) {
    case TAG_VFun: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24570, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24570, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24580 = heff_field(v_v_24570, 0);
      V v_ru_24v_24570_24VArr = heff_take_reuse_n(v_v_24570, 1ULL, 1);
      heff_clo_take(self, 1);
      V v_t_24581 = (g_prelude_2e_2b_2b(heff_arrayToList(v_xs_24566), heff_arrayToList(v_xs_24580)));
      V v_t_24582 = heff_tag_at_n(v_ru_24v_24570_24VArr, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24581)});
      return heff_tag_at_n(v_ru_24x1_24569_24Ok, TAG_Ok, 1, (V[]){v_t_24582});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24570, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24570);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24586 = heff_field(v_x1_24569, 0);
    V v_ru_24x1_24569_24Bug = heff_take_reuse_n(v_x1_24569, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24569_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24586});
  }
  default: return heff_nomatch(v_x1_24569);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args) {
  V v_d_24553 = args[0];
  V v_a_24554 = args[1];
  V v_x1_24555 = heff_tr(heff_call(v_a_24554, 1, (V[]){v_d_24553}));
  switch (heff_tag_of(v_x1_24555)) {
  case TAG_Ok: {
    V v_v_24556 = heff_field(v_x1_24555, 0);
    V v_ru_24x1_24555_24Ok = heff_take_reuse_n(v_x1_24555, 1ULL, 1);
    switch (heff_tag_of(v_v_24556)) {
    case TAG_VFun: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24556, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24566 = heff_field(v_v_24556, 0);
      V v_ru_24v_24556_24VArr = heff_take_reuse_n(v_v_24556, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24555_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24556_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam52, 2, 1, (V[]){v_xs_24566})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24556, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24556);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24590 = heff_field(v_x1_24555, 0);
    V v_ru_24x1_24555_24Bug = heff_take_reuse_n(v_x1_24555, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24555_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24590});
  }
  default: return heff_nomatch(v_x1_24555);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args) {
  V v_d_24551 = args[0];
  V v_u_24552 = args[1];
  heff_drop(v_d_24551);
  heff_drop(v_u_24552);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam51_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args) {
  V v_d_24616 = args[0];
  V v_x_24617 = args[1];
  V v_xs_24606 = heff_env(self)[0];
  V v_a_24615 = heff_env(self)[1];
  V v_x1_24618 = heff_tr(heff_call(v_x_24617, 1, (V[]){v_d_24616}));
  switch (heff_tag_of(v_x1_24618)) {
  case TAG_Ok: {
    V v_v_24619 = heff_field(v_x1_24618, 0);
    V v_ru_24x1_24618_24Ok = heff_take_reuse_n(v_x1_24618, 1ULL, 1);
    heff_clo_take(self, 2);
    V v_xs_24620 = heff_arrayToList(v_xs_24606);
    V v_t_24621 = (g_list_2etake(heff_dup(v_a_24615), heff_dup(v_xs_24620)));
    V v_t_24622 = ({ V a_0 = v_a_24615; V a_1 = v_xs_24620; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_xs_24620); r_; });
    V v_t_24623 = (g_prelude_2e_2b_2b(v_t_24621, heff_tag_n(TAG_Cons, 2, (V[]){v_v_24619, v_t_24622})));
    V v_t_24624 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24623)});
    return heff_tag_at_n(v_ru_24x1_24618_24Ok, TAG_Ok, 1, (V[]){v_t_24624});
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24625 = heff_field(v_x1_24618, 0);
    V v_ru_24x1_24618_24Bug = heff_take_reuse_n(v_x1_24618, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24618_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24625});
  }
  default: return heff_nomatch(v_x1_24618);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args) {
  V v_d_24607 = args[0];
  V v_a_24608 = args[1];
  V v_xs_24606 = heff_env(self)[0];
  V v_x1_24609 = heff_tr(heff_call(v_a_24608, 1, (V[]){v_d_24607}));
  switch (heff_tag_of(v_x1_24609)) {
  case TAG_Ok: {
    V v_v_24610 = heff_field(v_x1_24609, 0);
    V v_ru_24x1_24609_24Ok = heff_take_reuse_n(v_x1_24609, 1ULL, 1);
    switch (heff_tag_of(v_v_24610)) {
    case TAG_VFun: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24610, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24615 = heff_field(v_v_24610, 0);
      V v_ru_24v_24610_24VInt = heff_take_reuse_n(v_v_24610, 1ULL, 1);
      heff_clo_take(self, 1);
      return heff_tag_at_n(v_ru_24x1_24609_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24610_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam56, 2, 2, (V[]){v_xs_24606, v_a_24615})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24610, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24610, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24610);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24634 = heff_field(v_x1_24609, 0);
    V v_ru_24x1_24609_24Bug = heff_take_reuse_n(v_x1_24609, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24609_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24634});
  }
  default: return heff_nomatch(v_x1_24609);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args) {
  V v_d_24593 = args[0];
  V v_a_24594 = args[1];
  V v_x1_24595 = heff_tr(heff_call(v_a_24594, 1, (V[]){v_d_24593}));
  switch (heff_tag_of(v_x1_24595)) {
  case TAG_Ok: {
    V v_v_24596 = heff_field(v_x1_24595, 0);
    V v_ru_24x1_24595_24Ok = heff_take_reuse_n(v_x1_24595, 1ULL, 1);
    switch (heff_tag_of(v_v_24596)) {
    case TAG_VFun: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24596, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24606 = heff_field(v_v_24596, 0);
      V v_ru_24v_24596_24VArr = heff_take_reuse_n(v_v_24596, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24595_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24596_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam55, 2, 1, (V[]){v_xs_24606})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24596, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24596);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24638 = heff_field(v_x1_24595, 0);
    V v_ru_24x1_24595_24Bug = heff_take_reuse_n(v_x1_24595, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24595_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24638});
  }
  default: return heff_nomatch(v_x1_24595);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args) {
  V v_d_24591 = args[0];
  V v_u_24592 = args[1];
  heff_drop(v_d_24591);
  heff_drop(v_u_24592);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam54_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args) {
  V v_d_24655 = args[0];
  V v_a_24656 = args[1];
  V v_xs_24654 = heff_env(self)[0];
  V v_x1_24657 = heff_tr(heff_call(v_a_24656, 1, (V[]){v_d_24655}));
  switch (heff_tag_of(v_x1_24657)) {
  case TAG_Ok: {
    V v_v_24658 = heff_field(v_x1_24657, 0);
    V v_ru_24x1_24657_24Ok = heff_take_reuse_n(v_x1_24657, 1ULL, 1);
    switch (heff_tag_of(v_v_24658)) {
    case TAG_VFun: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24658, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24663 = heff_field(v_v_24658, 0);
      V v_ru_24v_24658_24VInt = heff_take_reuse_n(v_v_24658, 1ULL, 1);
      heff_clo_take(self, 1);
      V v_xs_24664 = heff_arrayToList(v_xs_24654);
      V v_t_24667;
      if ((heff_intLe_c_lent(MK_INT(0LL), v_a_24663, 1) && ({ V v_t_242154 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_24664)); int c_ = heff_intLt_c_lent(v_a_24663, v_t_242154, 0); heff_drop(v_t_242154); c_; }))) {
        V v_t_24665 = (g_list_2etake(heff_dup(v_a_24663), heff_dup(v_xs_24664)));
        V v_t_24666 = ({ V a_0 = heff_intAdd(v_a_24663, MK_INT(1LL)); V a_1 = v_xs_24664; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_xs_24664); r_; });
        v_t_24667 = (g_prelude_2e_2b_2b(v_t_24665, v_t_24666));
      } else {
        heff_drop(v_a_24663);
        v_t_24667 = v_xs_24664;
      }
      V v_t_24668 = heff_tag_at_n(v_ru_24v_24658_24VInt, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24667)});
      return heff_tag_at_n(v_ru_24x1_24657_24Ok, TAG_Ok, 1, (V[]){v_t_24668});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24658, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24658, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24658);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24677 = heff_field(v_x1_24657, 0);
    V v_ru_24x1_24657_24Bug = heff_take_reuse_n(v_x1_24657, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24657_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24677});
  }
  default: return heff_nomatch(v_x1_24657);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args) {
  V v_d_24641 = args[0];
  V v_a_24642 = args[1];
  V v_x1_24643 = heff_tr(heff_call(v_a_24642, 1, (V[]){v_d_24641}));
  switch (heff_tag_of(v_x1_24643)) {
  case TAG_Ok: {
    V v_v_24644 = heff_field(v_x1_24643, 0);
    V v_ru_24x1_24643_24Ok = heff_take_reuse_n(v_x1_24643, 1ULL, 1);
    switch (heff_tag_of(v_v_24644)) {
    case TAG_VFun: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24644, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24654 = heff_field(v_v_24644, 0);
      V v_ru_24v_24644_24VArr = heff_take_reuse_n(v_v_24644, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24643_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24644_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam59, 2, 1, (V[]){v_xs_24654})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24644, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24644);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24681 = heff_field(v_x1_24643, 0);
    V v_ru_24x1_24643_24Bug = heff_take_reuse_n(v_x1_24643, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24643_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24681});
  }
  default: return heff_nomatch(v_x1_24643);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args) {
  V v_d_24639 = args[0];
  V v_u_24640 = args[1];
  heff_drop(v_d_24639);
  heff_drop(v_u_24640);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam58_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args) {
  V v_d_24698 = args[0];
  V v_x_24699 = args[1];
  V v_xs_24697 = heff_env(self)[0];
  V v_x1_24700 = heff_tr(heff_call(v_x_24699, 1, (V[]){v_d_24698}));
  switch (heff_tag_of(v_x1_24700)) {
  case TAG_Ok: {
    V v_v_24701 = heff_field(v_x1_24700, 0);
    V v_ru_24x1_24700_24Ok = heff_take_reuse_n(v_x1_24700, 1ULL, 1);
    V v_t_24702 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_24701, NTAG(TAG_Nil)});
    heff_clo_take(self, 1);
    V v_t_24703 = (g_prelude_2e_2b_2b(heff_arrayToList(v_xs_24697), v_t_24702));
    V v_t_24704 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24703)});
    return heff_tag_at_n(v_ru_24x1_24700_24Ok, TAG_Ok, 1, (V[]){v_t_24704});
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24705 = heff_field(v_x1_24700, 0);
    V v_ru_24x1_24700_24Bug = heff_take_reuse_n(v_x1_24700, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24700_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24705});
  }
  default: return heff_nomatch(v_x1_24700);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args) {
  V v_d_24684 = args[0];
  V v_a_24685 = args[1];
  V v_x1_24686 = heff_tr(heff_call(v_a_24685, 1, (V[]){v_d_24684}));
  switch (heff_tag_of(v_x1_24686)) {
  case TAG_Ok: {
    V v_v_24687 = heff_field(v_x1_24686, 0);
    V v_ru_24x1_24686_24Ok = heff_take_reuse_n(v_x1_24686, 1ULL, 1);
    switch (heff_tag_of(v_v_24687)) {
    case TAG_VFun: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24687, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24697 = heff_field(v_v_24687, 0);
      V v_ru_24v_24687_24VArr = heff_take_reuse_n(v_v_24687, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24686_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24687_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam62, 2, 1, (V[]){v_xs_24697})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24687, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24687);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24709 = heff_field(v_x1_24686, 0);
    V v_ru_24x1_24686_24Bug = heff_take_reuse_n(v_x1_24686, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24686_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24709});
  }
  default: return heff_nomatch(v_x1_24686);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args) {
  V v_d_24682 = args[0];
  V v_u_24683 = args[1];
  heff_drop(v_d_24682);
  heff_drop(v_u_24683);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam61_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args) {
  V v_d_24726 = args[0];
  V v_a_24727 = args[1];
  V v_xs_24725 = heff_env(self)[0];
  V v_x1_24728 = heff_tr(heff_call(v_a_24727, 1, (V[]){v_d_24726}));
  switch (heff_tag_of(v_x1_24728)) {
  case TAG_Ok: {
    V v_v_24729 = heff_field(v_x1_24728, 0);
    V v_ru_24x1_24728_24Ok = heff_take_reuse_n(v_x1_24728, 1ULL, 1);
    switch (heff_tag_of(v_v_24729)) {
    case TAG_VFun: {
      heff_take_n(v_v_24729, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24729, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24729, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_ru_24v_24729_24VInt = heff_take_reuse_n(v_v_24729, 0ULL, 1);
      heff_clo_take(self, 1);
      return heff_tag_at_n(v_ru_24x1_24728_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24729_24VInt, TAG_VArr, 1, (V[]){v_xs_24725})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24729, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24729, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24729, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24729, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24729, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24729, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24729, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24729);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24743 = heff_field(v_x1_24728, 0);
    V v_ru_24x1_24728_24Bug = heff_take_reuse_n(v_x1_24728, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24728_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24743});
  }
  default: return heff_nomatch(v_x1_24728);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args) {
  V v_d_24712 = args[0];
  V v_a_24713 = args[1];
  V v_x1_24714 = heff_tr(heff_call(v_a_24713, 1, (V[]){v_d_24712}));
  switch (heff_tag_of(v_x1_24714)) {
  case TAG_Ok: {
    V v_v_24715 = heff_field(v_x1_24714, 0);
    V v_ru_24x1_24714_24Ok = heff_take_reuse_n(v_x1_24714, 1ULL, 1);
    switch (heff_tag_of(v_v_24715)) {
    case TAG_VFun: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24715, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24725 = heff_field(v_v_24715, 0);
      V v_ru_24v_24715_24VArr = heff_take_reuse_n(v_v_24715, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24714_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24715_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam65, 2, 1, (V[]){v_xs_24725})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24715, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24715);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24747 = heff_field(v_x1_24714, 0);
    V v_ru_24x1_24714_24Bug = heff_take_reuse_n(v_x1_24714, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24714_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24747});
  }
  default: return heff_nomatch(v_x1_24714);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args) {
  V v_d_24710 = args[0];
  V v_u_24711 = args[1];
  heff_drop(v_d_24710);
  heff_drop(v_u_24711);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam64_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args) {
  V v_d_24748 = args[0];
  V v_a_24749 = args[1];
  V v_x1_24750 = heff_tr(heff_call(v_a_24749, 1, (V[]){v_d_24748}));
  switch (heff_tag_of(v_x1_24750)) {
  case TAG_Ok: {
    V v_v_24751 = heff_field(v_x1_24750, 0);
    V v_ru_24x1_24750_24Ok = heff_take_reuse_n(v_x1_24750, 1ULL, 1);
    switch (heff_tag_of(v_v_24751)) {
    case TAG_VFun: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24751, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24759 = heff_field(v_v_24751, 0);
      V v_ru_24v_24751_24VStr = heff_take_reuse_n(v_v_24751, 1ULL, 1);
      V v_t_24760 = heff_tag_at_n(v_ru_24v_24751_24VStr, TAG_VInt, 1, (V[]){heff_strLength(v_a_24759)});
      return heff_tag_at_n(v_ru_24x1_24750_24Ok, TAG_Ok, 1, (V[]){v_t_24760});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24751, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24751);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24766 = heff_field(v_x1_24750, 0);
    V v_ru_24x1_24750_24Bug = heff_take_reuse_n(v_x1_24750, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24750_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24766});
  }
  default: return heff_nomatch(v_x1_24750);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args) {
  V v_d_24788 = args[0];
  V v_a_24789 = args[1];
  V v_a_24778 = heff_env(self)[0];
  V v_a_24787 = heff_env(self)[1];
  V v_x1_24790 = heff_tr(heff_call(v_a_24789, 1, (V[]){v_d_24788}));
  switch (heff_tag_of(v_x1_24790)) {
  case TAG_Ok: {
    V v_v_24791 = heff_field(v_x1_24790, 0);
    V v_ru_24x1_24790_24Ok = heff_take_reuse_n(v_x1_24790, 1ULL, 1);
    switch (heff_tag_of(v_v_24791)) {
    case TAG_VFun: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24791, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24796 = heff_field(v_v_24791, 0);
      V v_ru_24v_24791_24VInt = heff_take_reuse_n(v_v_24791, 1ULL, 1);
      heff_clo_take(self, 2);
      V v_t_24797 = heff_tag_at_n(v_ru_24v_24791_24VInt, TAG_VStr, 1, (V[]){heff_strSlice(v_a_24778, v_a_24787, v_a_24796)});
      return heff_tag_at_n(v_ru_24x1_24790_24Ok, TAG_Ok, 1, (V[]){v_t_24797});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24791, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24791, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24791);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24806 = heff_field(v_x1_24790, 0);
    V v_ru_24x1_24790_24Bug = heff_take_reuse_n(v_x1_24790, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24790_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24806});
  }
  default: return heff_nomatch(v_x1_24790);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args) {
  V v_d_24779 = args[0];
  V v_a_24780 = args[1];
  V v_a_24778 = heff_env(self)[0];
  V v_x1_24781 = heff_tr(heff_call(v_a_24780, 1, (V[]){v_d_24779}));
  switch (heff_tag_of(v_x1_24781)) {
  case TAG_Ok: {
    V v_v_24782 = heff_field(v_x1_24781, 0);
    V v_ru_24x1_24781_24Ok = heff_take_reuse_n(v_x1_24781, 1ULL, 1);
    switch (heff_tag_of(v_v_24782)) {
    case TAG_VFun: {
      heff_take_n(v_v_24782, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24782, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24782, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24787 = heff_field(v_v_24782, 0);
      V v_ru_24v_24782_24VInt = heff_take_reuse_n(v_v_24782, 1ULL, 1);
      heff_clo_take(self, 1);
      return heff_tag_at_n(v_ru_24x1_24781_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24782_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam69, 2, 2, (V[]){v_a_24778, v_a_24787})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24782, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24782, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24782, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24782, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24782, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24782, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24782, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24782);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24815 = heff_field(v_x1_24781, 0);
    V v_ru_24x1_24781_24Bug = heff_take_reuse_n(v_x1_24781, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24781_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24815});
  }
  default: return heff_nomatch(v_x1_24781);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args) {
  V v_d_24767 = args[0];
  V v_a_24768 = args[1];
  V v_x1_24769 = heff_tr(heff_call(v_a_24768, 1, (V[]){v_d_24767}));
  switch (heff_tag_of(v_x1_24769)) {
  case TAG_Ok: {
    V v_v_24770 = heff_field(v_x1_24769, 0);
    V v_ru_24x1_24769_24Ok = heff_take_reuse_n(v_x1_24769, 1ULL, 1);
    switch (heff_tag_of(v_v_24770)) {
    case TAG_VFun: {
      heff_take_n(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24770, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24778 = heff_field(v_v_24770, 0);
      V v_ru_24v_24770_24VStr = heff_take_reuse_n(v_v_24770, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24769_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24770_24VStr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam68, 2, 1, (V[]){v_a_24778})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24770, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24770);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24821 = heff_field(v_x1_24769, 0);
    V v_ru_24x1_24769_24Bug = heff_take_reuse_n(v_x1_24769, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24769_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24821});
  }
  default: return heff_nomatch(v_x1_24769);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args) {
  V v_a_24822 = args[0];
  V v_b_24823 = args[1];
  V v_t_24824;
  if (heff_strEq_c(v_a_24822, v_b_24823)) {
    v_t_24824 = ((V)&g_heff_2ecompile_2einterp_2eprim_str15);
  } else {
    v_t_24824 = ((V)&g_heff_2ecompile_2einterp_2eprim_str16);
  }
  V v_t_24825 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24824, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24825});
}
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args) {
  V v_a_24826 = args[0];
  V v_b_24827 = args[1];
  V v_t_24828;
  if (heff_strLt_c(v_a_24826, v_b_24827)) {
    v_t_24828 = ((V)&g_heff_2ecompile_2einterp_2eprim_str17);
  } else {
    v_t_24828 = ((V)&g_heff_2ecompile_2einterp_2eprim_str18);
  }
  V v_t_24829 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24828, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24829});
}
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args) {
  V v_a_24830 = args[0];
  V v_b_24831 = args[1];
  V v_t_24832;
  if (heff_strLt_c_lent(v_a_24830, v_b_24831, 0)) {
    heff_drop(v_a_24830);
    heff_drop(v_b_24831);
    v_t_24832 = MK_INT(-1LL);
  } else {
    if (heff_strEq_c(v_a_24830, v_b_24831)) {
      v_t_24832 = MK_INT(0LL);
    } else {
      v_t_24832 = MK_INT(1LL);
    }
  }
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24832})});
}
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args) {
  V v_d_24835 = args[0];
  V v_a_24836 = args[1];
  V v_n_24833 = heff_env(self)[0];
  V v_a_24834 = heff_env(self)[1];
  V v_x1_24837 = heff_tr(heff_call(v_a_24836, 1, (V[]){v_d_24835}));
  switch (heff_tag_of(v_x1_24837)) {
  case TAG_Ok: {
    V v_v_24838 = heff_field(v_x1_24837, 0);
    V v_ru_24x1_24837_24Ok = heff_take_reuse_n(v_x1_24837, 1ULL, 1);
    switch (heff_tag_of(v_v_24838)) {
    case TAG_VFun: {
      heff_take_n(v_v_24838, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24838, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24838, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24843 = heff_field(v_v_24838, 0);
      V v_ru_24v_24838_24VInt = heff_take_reuse_n(v_v_24838, 1ULL, 1);
      V v_t_24844;
      if (heff_intLe_c_lent(MK_INT(0LL), v_a_24843, 1)) {
        v_t_24844 = v_a_24843;
      } else {
        heff_drop(v_a_24843);
        v_t_24844 = MK_INT(0LL);
      }
      heff_clo_take(self, 2);
      V v_j_24845 = heff_strFind(v_n_24833, v_a_24834, v_t_24844);
      V v_t_24846;
      if (heff_intLt_c_lent(v_j_24845, MK_INT(0LL), 2)) {
        heff_drop(v_j_24845);
        v_t_24846 = MK_INT(-1LL);
      } else {
        v_t_24846 = v_j_24845;
      }
      return heff_tag_at_n(v_ru_24x1_24837_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24838_24VInt, TAG_VInt, 1, (V[]){v_t_24846})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24838, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24838, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24838, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24838, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24838, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24838, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24838, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24838);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24855 = heff_field(v_x1_24837, 0);
    V v_ru_24x1_24837_24Bug = heff_take_reuse_n(v_x1_24837, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24837_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24855});
  }
  default: return heff_nomatch(v_x1_24837);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args) {
  V v_n_24833 = args[0];
  V v_a_24834 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam74, 2, 2, (V[]){v_n_24833, v_a_24834})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args) {
  V v_a_24856 = args[0];
  V v_b_24857 = args[1];
  V v_t_24858;
  if (heff_intEq_c(v_a_24856, v_b_24857)) {
    v_t_24858 = ((V)&g_heff_2ecompile_2einterp_2eprim_str19);
  } else {
    v_t_24858 = ((V)&g_heff_2ecompile_2einterp_2eprim_str20);
  }
  V v_t_24859 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24858, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24859});
}
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args) {
  V v_a_24860 = args[0];
  V v_b_24861 = args[1];
  V v_t_24862;
  if (heff_intLt_c(v_a_24860, v_b_24861)) {
    v_t_24862 = ((V)&g_heff_2ecompile_2einterp_2eprim_str21);
  } else {
    v_t_24862 = ((V)&g_heff_2ecompile_2einterp_2eprim_str22);
  }
  V v_t_24863 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24862, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24863});
}
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args) {
  V v_a_24864 = args[0];
  V v_b_24865 = args[1];
  V v_t_24866;
  if (heff_intLe_c(v_a_24864, v_b_24865)) {
    v_t_24866 = ((V)&g_heff_2ecompile_2einterp_2eprim_str23);
  } else {
    v_t_24866 = ((V)&g_heff_2ecompile_2einterp_2eprim_str24);
  }
  V v_t_24867 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24866, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24867});
}
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args) {
  V v_d_24868 = args[0];
  V v_a_24869 = args[1];
  V v_x1_24870 = heff_tr(heff_call(v_a_24869, 1, (V[]){v_d_24868}));
  switch (heff_tag_of(v_x1_24870)) {
  case TAG_Ok: {
    V v_v_24871 = heff_field(v_x1_24870, 0);
    V v_ru_24x1_24870_24Ok = heff_take_reuse_n(v_x1_24870, 1ULL, 1);
    switch (heff_tag_of(v_v_24871)) {
    case TAG_VFun: {
      heff_take_n(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24871, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VRune: {
      V v_a_24880 = heff_field(v_v_24871, 0);
      V v_ru_24v_24871_24VRune = heff_take_reuse_n(v_v_24871, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24870_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24871_24VRune, TAG_VInt, 1, (V[]){v_a_24880})});
    }
    case TAG_VArr: {
      heff_take_n(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24871, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    default: return heff_nomatch(v_v_24871);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24885 = heff_field(v_x1_24870, 0);
    V v_ru_24x1_24870_24Bug = heff_take_reuse_n(v_x1_24870, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24870_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24885});
  }
  default: return heff_nomatch(v_x1_24870);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args) {
  V v_d_24886 = args[0];
  V v_a_24887 = args[1];
  V v_x1_24888 = heff_tr(heff_call(v_a_24887, 1, (V[]){v_d_24886}));
  switch (heff_tag_of(v_x1_24888)) {
  case TAG_Ok: {
    V v_v_24889 = heff_field(v_x1_24888, 0);
    V v_ru_24x1_24888_24Ok = heff_take_reuse_n(v_x1_24888, 1ULL, 1);
    switch (heff_tag_of(v_v_24889)) {
    case TAG_VFun: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24889, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24894 = heff_field(v_v_24889, 0);
      V v_ru_24v_24889_24VInt = heff_take_reuse_n(v_v_24889, 1ULL, 1);
      V v_t_24895 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_24896 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_24897 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(32LL)));
      V v_t_24898 = heff_intSub(v_a_24894, heff_intSub(MK_INT(0LL), v_t_24896));
      V v_t_24899 = heff_intAdd(heff_intSub(MK_INT(0LL), v_t_24895), heff_intMod(v_t_24898, v_t_24897));
      return heff_tag_at_n(v_ru_24x1_24888_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24889_24VInt, TAG_VRune, 1, (V[]){v_t_24899})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24889, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24889);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24908 = heff_field(v_x1_24888, 0);
    V v_ru_24x1_24888_24Bug = heff_take_reuse_n(v_x1_24888, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24888_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24908});
  }
  default: return heff_nomatch(v_x1_24888);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args) {
  V v_d_24911 = args[0];
  V v_a_24912 = args[1];
  V f_ = v_a_24912;
  args[0] = v_d_24911;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args) {
  V v_d_24909 = args[0];
  V v_u_24910 = args[1];
  heff_drop(v_d_24909);
  heff_drop(v_u_24910);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam81_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args) {
  V v_d_24915 = args[0];
  V v_a_24916 = args[1];
  V v_x1_24917 = heff_tr(heff_call(v_a_24916, 1, (V[]){v_d_24915}));
  switch (heff_tag_of(v_x1_24917)) {
  case TAG_Ok: {
    V v_v_24918 = heff_field(v_x1_24917, 0);
    heff_take_n(v_x1_24917, 1ULL, 1);
    switch (heff_tag_of(v_v_24918)) {
    case TAG_VFun: {
      heff_take_n(v_v_24918, 0ULL, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24918, 0ULL, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24918, 0ULL, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24918, 0ULL, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24918, 0ULL, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24918, 0ULL, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24918, 0ULL, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_VRune: {
      heff_take_n(v_v_24918, 0ULL, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24918, 0ULL, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24918, 0ULL, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24918, 0ULL, 2);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24918);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24932 = heff_field(v_x1_24917, 0);
    V v_ru_24x1_24917_24Bug = heff_take_reuse_n(v_x1_24917, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24917_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24932});
  }
  default: return heff_nomatch(v_x1_24917);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args) {
  V v_d_24913 = args[0];
  V v_u_24914 = args[1];
  heff_drop(v_d_24913);
  heff_drop(v_u_24914);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam83_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args) {
  V v_d_24945 = args[0];
  V v_a_24946 = args[1];
  V v_a_24944 = heff_env(self)[0];
  V v_x1_24947 = heff_tr(heff_call(v_a_24946, 1, (V[]){v_d_24945}));
  switch (heff_tag_of(v_x1_24947)) {
  case TAG_Ok: {
    V v_v_24948 = heff_field(v_x1_24947, 0);
    V v_ru_24x1_24947_24Ok = heff_take_reuse_n(v_x1_24947, 1ULL, 1);
    switch (heff_tag_of(v_v_24948)) {
    case TAG_VFun: {
      heff_take_n(v_v_24948, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24947_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24948, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24947_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24948, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24947_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24953 = heff_field(v_v_24948, 0);
      V v_ru_24v_24948_24VInt = heff_take_reuse_n(v_v_24948, 1ULL, 1);
      heff_clo_take(self, 1);
      V v_t_24954 = heff_tag_at_n(v_ru_24v_24948_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_24944, v_a_24953)});
      return heff_tag_at_n(v_ru_24x1_24947_24Ok, TAG_Ok, 1, (V[]){v_t_24954});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24948, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24947_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24948, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24947_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24948, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24947_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24948, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24947_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24948, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24947_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24948, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24947_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24948, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24947_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_24947_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24948);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24963 = heff_field(v_x1_24947, 0);
    V v_ru_24x1_24947_24Bug = heff_take_reuse_n(v_x1_24947, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_24947_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24963});
  }
  default: return heff_nomatch(v_x1_24947);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args) {
  V v_d_24933 = args[0];
  V v_a_24934 = args[1];
  V v_x1_24935 = heff_tr(heff_call(v_a_24934, 1, (V[]){v_d_24933}));
  switch (heff_tag_of(v_x1_24935)) {
  case TAG_Ok: {
    V v_v_24936 = heff_field(v_x1_24935, 0);
    V v_ru_24x1_24935_24Ok = heff_take_reuse_n(v_x1_24935, 1ULL, 1);
    switch (heff_tag_of(v_v_24936)) {
    case TAG_VFun: {
      heff_take_n(v_v_24936, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24935_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24936, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24935_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24936, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24935_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24936, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24935_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24936, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24935_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24936, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24935_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24944 = heff_field(v_v_24936, 0);
      V v_ru_24v_24936_24VStr = heff_take_reuse_n(v_v_24936, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24935_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24936_24VStr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam85, 2, 1, (V[]){v_a_24944})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24936, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24935_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24936, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24935_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24936, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24935_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24936, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24935_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24935_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24936);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24969 = heff_field(v_x1_24935, 0);
    V v_ru_24x1_24935_24Bug = heff_take_reuse_n(v_x1_24935, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24935_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24969});
  }
  default: return heff_nomatch(v_x1_24935);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args) {
  V v_d_24970 = args[0];
  V v_a_24971 = args[1];
  V v_x1_24972 = heff_tr(heff_call(v_a_24971, 1, (V[]){v_d_24970}));
  switch (heff_tag_of(v_x1_24972)) {
  case TAG_Ok: {
    V v_v_24973 = heff_field(v_x1_24972, 0);
    V v_ru_24x1_24972_24Ok = heff_take_reuse_n(v_x1_24972, 1ULL, 1);
    switch (heff_tag_of(v_v_24973)) {
    case TAG_VFun: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24973, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24978 = heff_field(v_v_24973, 0);
      V v_ru_24v_24973_24VInt = heff_take_reuse_n(v_v_24973, 1ULL, 1);
      V v_t_24979 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_a_24978)));
      return heff_tag_at_n(v_ru_24x1_24972_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24973_24VInt, TAG_VStr, 1, (V[]){v_t_24979})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24973, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24973);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24988 = heff_field(v_x1_24972, 0);
    V v_ru_24x1_24972_24Bug = heff_take_reuse_n(v_x1_24972, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24972_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_24988});
  }
  default: return heff_nomatch(v_x1_24972);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args) {
  V v_d_241001 = args[0];
  V v_a_241002 = args[1];
  V v_a_241000 = heff_env(self)[0];
  V v_x1_241003 = heff_tr(heff_call(v_a_241002, 1, (V[]){v_d_241001}));
  switch (heff_tag_of(v_x1_241003)) {
  case TAG_Ok: {
    V v_v_241004 = heff_field(v_x1_241003, 0);
    V v_ru_24x1_241003_24Ok = heff_take_reuse_n(v_x1_241003, 1ULL, 1);
    switch (heff_tag_of(v_v_241004)) {
    case TAG_VFun: {
      heff_take_n(v_v_241004, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241004, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241004, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241009 = heff_field(v_v_241004, 0);
      V v_ru_24v_241004_24VInt = heff_take_reuse_n(v_v_241004, 1ULL, 1);
      heff_clo_take(self, 1);
      V v_t_241010 = heff_runeToInt(heff_strRuneAt(v_a_241000, v_a_241009));
      return heff_tag_at_n(v_ru_24x1_241003_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241004_24VInt, TAG_VRune, 1, (V[]){v_t_241010})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241004, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241004, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241004, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241004, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241004, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241004, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241004, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241004);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241019 = heff_field(v_x1_241003, 0);
    V v_ru_24x1_241003_24Bug = heff_take_reuse_n(v_x1_241003, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241003_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241019});
  }
  default: return heff_nomatch(v_x1_241003);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args) {
  V v_d_24989 = args[0];
  V v_a_24990 = args[1];
  V v_x1_24991 = heff_tr(heff_call(v_a_24990, 1, (V[]){v_d_24989}));
  switch (heff_tag_of(v_x1_24991)) {
  case TAG_Ok: {
    V v_v_24992 = heff_field(v_x1_24991, 0);
    V v_ru_24x1_24991_24Ok = heff_take_reuse_n(v_x1_24991, 1ULL, 1);
    switch (heff_tag_of(v_v_24992)) {
    case TAG_VFun: {
      heff_take_n(v_v_24992, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24991_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24992, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24991_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24992, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24991_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24992, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24991_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24992, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24991_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24992, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24991_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241000 = heff_field(v_v_24992, 0);
      V v_ru_24v_24992_24VStr = heff_take_reuse_n(v_v_24992, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24991_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24992_24VStr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam88, 2, 1, (V[]){v_a_241000})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24992, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24991_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24992, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24991_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24992, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24991_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24992, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24991_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24991_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24992);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241025 = heff_field(v_x1_24991, 0);
    V v_ru_24x1_24991_24Bug = heff_take_reuse_n(v_x1_24991, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_24991_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241025});
  }
  default: return heff_nomatch(v_x1_24991);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args) {
  V v_d_241038 = args[0];
  V v_a_241039 = args[1];
  V v_a_241037 = heff_env(self)[0];
  V v_x1_241040 = heff_tr(heff_call(v_a_241039, 1, (V[]){v_d_241038}));
  switch (heff_tag_of(v_x1_241040)) {
  case TAG_Ok: {
    V v_v_241041 = heff_field(v_x1_241040, 0);
    V v_ru_24x1_241040_24Ok = heff_take_reuse_n(v_x1_241040, 1ULL, 1);
    switch (heff_tag_of(v_v_241041)) {
    case TAG_VFun: {
      heff_take_n(v_v_241041, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241041, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241041, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241046 = heff_field(v_v_241041, 0);
      V v_ru_24v_241041_24VInt = heff_take_reuse_n(v_v_241041, 1ULL, 1);
      heff_clo_take(self, 1);
      V v_t_241047 = heff_tag_at_n(v_ru_24v_241041_24VInt, TAG_VInt, 1, (V[]){heff_strRuneWidth(v_a_241037, v_a_241046)});
      return heff_tag_at_n(v_ru_24x1_241040_24Ok, TAG_Ok, 1, (V[]){v_t_241047});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241041, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241041, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241041, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241041, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241041, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241041, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241041, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241041);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241056 = heff_field(v_x1_241040, 0);
    V v_ru_24x1_241040_24Bug = heff_take_reuse_n(v_x1_241040, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241040_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241056});
  }
  default: return heff_nomatch(v_x1_241040);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args) {
  V v_d_241026 = args[0];
  V v_a_241027 = args[1];
  V v_x1_241028 = heff_tr(heff_call(v_a_241027, 1, (V[]){v_d_241026}));
  switch (heff_tag_of(v_x1_241028)) {
  case TAG_Ok: {
    V v_v_241029 = heff_field(v_x1_241028, 0);
    V v_ru_24x1_241028_24Ok = heff_take_reuse_n(v_x1_241028, 1ULL, 1);
    switch (heff_tag_of(v_v_241029)) {
    case TAG_VFun: {
      heff_take_n(v_v_241029, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241028_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241029, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241028_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241029, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241028_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241029, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241028_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241029, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241028_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241029, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241028_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241037 = heff_field(v_v_241029, 0);
      V v_ru_24v_241029_24VStr = heff_take_reuse_n(v_v_241029, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241028_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241029_24VStr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam90, 2, 1, (V[]){v_a_241037})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241029, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241028_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241029, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241028_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241029, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241028_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241029, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241028_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241028_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241029);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241062 = heff_field(v_x1_241028, 0);
    V v_ru_24x1_241028_24Bug = heff_take_reuse_n(v_x1_241028, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241028_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241062});
  }
  default: return heff_nomatch(v_x1_241028);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args) {
  V v_d_241063 = args[0];
  V v_a_241064 = args[1];
  V v_x1_241065 = heff_tr(heff_call(v_a_241064, 1, (V[]){v_d_241063}));
  switch (heff_tag_of(v_x1_241065)) {
  case TAG_Ok: {
    V v_v_241066 = heff_field(v_x1_241065, 0);
    V v_ru_24x1_241065_24Ok = heff_take_reuse_n(v_x1_241065, 1ULL, 1);
    switch (heff_tag_of(v_v_241066)) {
    case TAG_VFun: {
      heff_take_n(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241066, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241074 = heff_field(v_v_241066, 0);
      V v_ru_24v_241066_24VStr = heff_take_reuse_n(v_v_241066, 1ULL, 1);
      V v_t_241075 = heff_tag_at_n(v_ru_24v_241066_24VStr, TAG_VInt, 1, (V[]){heff_strRuneCount(v_a_241074)});
      return heff_tag_at_n(v_ru_24x1_241065_24Ok, TAG_Ok, 1, (V[]){v_t_241075});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241066, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241066);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241081 = heff_field(v_x1_241065, 0);
    V v_ru_24x1_241065_24Bug = heff_take_reuse_n(v_x1_241065, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241065_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241081});
  }
  default: return heff_nomatch(v_x1_241065);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args) {
  V v_d_241082 = args[0];
  V v_a_241083 = args[1];
  V v_x1_241084 = heff_tr(heff_call(v_a_241083, 1, (V[]){v_d_241082}));
  switch (heff_tag_of(v_x1_241084)) {
  case TAG_Ok: {
    V v_v_241085 = heff_field(v_x1_241084, 0);
    V v_ru_24x1_241084_24Ok = heff_take_reuse_n(v_x1_241084, 1ULL, 1);
    switch (heff_tag_of(v_v_241085)) {
    case TAG_VFun: {
      heff_take_n(v_v_241085, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241084_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241085, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241084_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241085, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241084_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241085, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241084_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241085, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241084_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241085, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241084_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241093 = heff_field(v_v_241085, 0);
      heff_take_n(v_v_241085, 1ULL, 1);
      V v_t_241094 = (g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(heff_strRunes(v_a_241093)));
      return heff_tag_at_n(v_ru_24x1_241084_24Ok, TAG_Ok, 1, (V[]){v_t_241094});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241085, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241084_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241085, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241084_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241085, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241084_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241085, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241084_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241084_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241085);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241100 = heff_field(v_x1_241084, 0);
    V v_ru_24x1_241084_24Bug = heff_take_reuse_n(v_x1_241084, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241084_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241100});
  }
  default: return heff_nomatch(v_x1_241084);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args) {
  V v_d_241101 = args[0];
  V v_l_241102 = args[1];
  V v_x1_241103 = heff_tr(heff_call(v_l_241102, 1, (V[]){v_d_241101}));
  switch (heff_tag_of(v_x1_241103)) {
  case TAG_Ok: {
    V v_v_241104 = heff_field(v_x1_241103, 0);
    V v_ru_24x1_241103_24Ok = heff_take_reuse_n(v_x1_241103, 1ULL, 1);
    V v_t_241105 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241104, NTAG(TAG_Nil)));
    V v_t_241106 = (g_heff_2ecompile_2einterp_2eruneCodes(v_t_241105));
    V v_t_241107 = (g_list_2emap(heff_dup(g_runeFromInt_get()), v_t_241106));
    V v_t_241108 = heff_tag_n(TAG_VStr, 1, (V[]){heff_strOfRunes(v_t_241107)});
    return heff_tag_at_n(v_ru_24x1_241103_24Ok, TAG_Ok, 1, (V[]){v_t_241108});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241109 = heff_field(v_x1_241103, 0);
    V v_ru_24x1_241103_24Bug = heff_take_reuse_n(v_x1_241103, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241103_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241109});
  }
  default: return heff_nomatch(v_x1_241103);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args) {
  V v_d_241110 = args[0];
  V v_a_241111 = args[1];
  V v_x1_241112 = heff_tr(heff_call(v_a_241111, 1, (V[]){v_d_241110}));
  switch (heff_tag_of(v_x1_241112)) {
  case TAG_Ok: {
    V v_v_241113 = heff_field(v_x1_241112, 0);
    V v_ru_24x1_241112_24Ok = heff_take_reuse_n(v_x1_241112, 1ULL, 1);
    switch (heff_tag_of(v_v_241113)) {
    case TAG_VFun: {
      heff_take_n(v_v_241113, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241112_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241113, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241112_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241113, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241112_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241113, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241112_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241113, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241112_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241113, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241112_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241121 = heff_field(v_v_241113, 0);
      V v_ru_24v_241113_24VStr = heff_take_reuse_n(v_v_241113, 1ULL, 1);
      V v_t_241122 = heff_strOfRunes(heff_strRunes(v_a_241121));
      return heff_tag_at_n(v_ru_24x1_241112_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241113_24VStr, TAG_VStr, 1, (V[]){v_t_241122})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241113, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241112_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241113, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241112_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241113, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241112_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241113, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241112_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241112_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241113);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241128 = heff_field(v_x1_241112, 0);
    V v_ru_24x1_241112_24Bug = heff_take_reuse_n(v_x1_241112, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241112_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241128});
  }
  default: return heff_nomatch(v_x1_241112);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args) {
  V v_d_241129 = args[0];
  V v_a_241130 = args[1];
  V v_x1_241131 = heff_tr(heff_call(v_a_241130, 1, (V[]){v_d_241129}));
  switch (heff_tag_of(v_x1_241131)) {
  case TAG_Ok: {
    V v_v_241132 = heff_field(v_x1_241131, 0);
    V v_ru_24x1_241131_24Ok = heff_take_reuse_n(v_x1_241131, 1ULL, 1);
    switch (heff_tag_of(v_v_241132)) {
    case TAG_VFun: {
      heff_take_n(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241132, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241140 = heff_field(v_v_241132, 0);
      V v_ru_24v_241132_24VStr = heff_take_reuse_n(v_v_241132, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241131_24Ok, TAG_Ok, 1, (V[]){heff_tag_re_n(v_ru_24v_241132_24VStr, TAG_VStr, 1, 1ULL, (V[]){v_a_241140})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241132, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241132);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241146 = heff_field(v_x1_241131, 0);
    V v_ru_24x1_241131_24Bug = heff_take_reuse_n(v_x1_241131, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241131_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241146});
  }
  default: return heff_nomatch(v_x1_241131);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args) {
  V v_d_241147 = args[0];
  V v_a_241148 = args[1];
  V v_x1_241149 = heff_tr(heff_call(v_a_241148, 1, (V[]){v_d_241147}));
  switch (heff_tag_of(v_x1_241149)) {
  case TAG_Ok: {
    V v_v_241150 = heff_field(v_x1_241149, 0);
    V v_ru_24x1_241149_24Ok = heff_take_reuse_n(v_x1_241149, 1ULL, 1);
    switch (heff_tag_of(v_v_241150)) {
    case TAG_VFun: {
      heff_take_n(v_v_241150, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241150, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241150, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241150, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241150, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241150, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241150, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241150, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241150, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241161 = heff_field(v_v_241150, 0);
      V v_ru_24v_241150_24VBytes = heff_take_reuse_n(v_v_241150, 1ULL, 1);
      V v_t_241162 = heff_tag_at_n(v_ru_24v_241150_24VBytes, TAG_VInt, 1, (V[]){heff_strLength(v_a_241161)});
      return heff_tag_at_n(v_ru_24x1_241149_24Ok, TAG_Ok, 1, (V[]){v_t_241162});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241150, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241150);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241165 = heff_field(v_x1_241149, 0);
    V v_ru_24x1_241149_24Bug = heff_take_reuse_n(v_x1_241149, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241149_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241165});
  }
  default: return heff_nomatch(v_x1_241149);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args) {
  V v_d_241181 = args[0];
  V v_a_241182 = args[1];
  V v_a_241180 = heff_env(self)[0];
  V v_x1_241183 = heff_tr(heff_call(v_a_241182, 1, (V[]){v_d_241181}));
  switch (heff_tag_of(v_x1_241183)) {
  case TAG_Ok: {
    V v_v_241184 = heff_field(v_x1_241183, 0);
    V v_ru_24x1_241183_24Ok = heff_take_reuse_n(v_x1_241183, 1ULL, 1);
    switch (heff_tag_of(v_v_241184)) {
    case TAG_VFun: {
      heff_take_n(v_v_241184, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241184, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241184, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241189 = heff_field(v_v_241184, 0);
      V v_ru_24v_241184_24VInt = heff_take_reuse_n(v_v_241184, 1ULL, 1);
      if ((heff_intLe_c_lent(MK_INT(0LL), v_a_241189, 1) && heff_intLt_c_lent(v_a_241189, heff_strLength_lent(v_a_241180, 0), 2))) {
        heff_clo_take(self, 1);
        V v_t_241190 = heff_tag_at_n(v_ru_24v_241184_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_241180, v_a_241189)});
        return heff_tag_at_n(v_ru_24x1_241183_24Ok, TAG_Ok, 1, (V[]){v_t_241190});
      } else {
        heff_drop(self);
        heff_drop_cell(v_ru_24x1_241183_24Ok, 1);
        heff_drop(v_a_241189);
        heff_drop_cell(v_ru_24v_241184_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241184, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241184, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241184, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241184, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241184, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241184, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241184, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241184);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241199 = heff_field(v_x1_241183, 0);
    V v_ru_24x1_241183_24Bug = heff_take_reuse_n(v_x1_241183, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241183_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241199});
  }
  default: return heff_nomatch(v_x1_241183);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args) {
  V v_d_241166 = args[0];
  V v_a_241167 = args[1];
  V v_x1_241168 = heff_tr(heff_call(v_a_241167, 1, (V[]){v_d_241166}));
  switch (heff_tag_of(v_x1_241168)) {
  case TAG_Ok: {
    V v_v_241169 = heff_field(v_x1_241168, 0);
    V v_ru_24x1_241168_24Ok = heff_take_reuse_n(v_x1_241168, 1ULL, 1);
    switch (heff_tag_of(v_v_241169)) {
    case TAG_VFun: {
      heff_take_n(v_v_241169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241169, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241180 = heff_field(v_v_241169, 0);
      V v_ru_24v_241169_24VBytes = heff_take_reuse_n(v_v_241169, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241168_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241169_24VBytes, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam98, 2, 1, (V[]){v_a_241180})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241169, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241169);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241202 = heff_field(v_x1_241168, 0);
    V v_ru_24x1_241168_24Bug = heff_take_reuse_n(v_x1_241168, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241168_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241202});
  }
  default: return heff_nomatch(v_x1_241168);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args) {
  V v_d_241227 = args[0];
  V v_a_241228 = args[1];
  V v_a_241217 = heff_env(self)[0];
  V v_a_241226 = heff_env(self)[1];
  V v_x1_241229 = heff_tr(heff_call(v_a_241228, 1, (V[]){v_d_241227}));
  switch (heff_tag_of(v_x1_241229)) {
  case TAG_Ok: {
    V v_v_241230 = heff_field(v_x1_241229, 0);
    V v_ru_24x1_241229_24Ok = heff_take_reuse_n(v_x1_241229, 1ULL, 1);
    switch (heff_tag_of(v_v_241230)) {
    case TAG_VFun: {
      heff_take_n(v_v_241230, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241230, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241230, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241235 = heff_field(v_v_241230, 0);
      V v_ru_24v_241230_24VInt = heff_take_reuse_n(v_v_241230, 1ULL, 1);
      heff_clo_take(self, 2);
      V v_t_241236 = heff_tag_at_n(v_ru_24v_241230_24VInt, TAG_VBytes, 1, (V[]){heff_strSlice(v_a_241217, v_a_241226, v_a_241235)});
      return heff_tag_at_n(v_ru_24x1_241229_24Ok, TAG_Ok, 1, (V[]){v_t_241236});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241230, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241230, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241230, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241230, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241230, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241230, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241230, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241230);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241245 = heff_field(v_x1_241229, 0);
    V v_ru_24x1_241229_24Bug = heff_take_reuse_n(v_x1_241229, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241229_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241245});
  }
  default: return heff_nomatch(v_x1_241229);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args) {
  V v_d_241218 = args[0];
  V v_a_241219 = args[1];
  V v_a_241217 = heff_env(self)[0];
  V v_x1_241220 = heff_tr(heff_call(v_a_241219, 1, (V[]){v_d_241218}));
  switch (heff_tag_of(v_x1_241220)) {
  case TAG_Ok: {
    V v_v_241221 = heff_field(v_x1_241220, 0);
    V v_ru_24x1_241220_24Ok = heff_take_reuse_n(v_x1_241220, 1ULL, 1);
    switch (heff_tag_of(v_v_241221)) {
    case TAG_VFun: {
      heff_take_n(v_v_241221, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241220_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241221, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241220_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241221, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241220_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241226 = heff_field(v_v_241221, 0);
      V v_ru_24v_241221_24VInt = heff_take_reuse_n(v_v_241221, 1ULL, 1);
      heff_clo_take(self, 1);
      return heff_tag_at_n(v_ru_24x1_241220_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241221_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam101, 2, 2, (V[]){v_a_241217, v_a_241226})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241221, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241220_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241221, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241220_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241221, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241220_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241221, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241220_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241221, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241220_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241221, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241220_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241221, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241220_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241220_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241221);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241254 = heff_field(v_x1_241220, 0);
    V v_ru_24x1_241220_24Bug = heff_take_reuse_n(v_x1_241220, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241220_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241254});
  }
  default: return heff_nomatch(v_x1_241220);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args) {
  V v_d_241203 = args[0];
  V v_a_241204 = args[1];
  V v_x1_241205 = heff_tr(heff_call(v_a_241204, 1, (V[]){v_d_241203}));
  switch (heff_tag_of(v_x1_241205)) {
  case TAG_Ok: {
    V v_v_241206 = heff_field(v_x1_241205, 0);
    V v_ru_24x1_241205_24Ok = heff_take_reuse_n(v_x1_241205, 1ULL, 1);
    switch (heff_tag_of(v_v_241206)) {
    case TAG_VFun: {
      heff_take_n(v_v_241206, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241205_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241206, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241205_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241206, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241205_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241206, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241205_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241206, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241205_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241206, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241205_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241206, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241205_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241206, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241205_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241206, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241205_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241217 = heff_field(v_v_241206, 0);
      V v_ru_24v_241206_24VBytes = heff_take_reuse_n(v_v_241206, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241205_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241206_24VBytes, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam100, 2, 1, (V[]){v_a_241217})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241206, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241205_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241205_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241206);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241257 = heff_field(v_x1_241205, 0);
    V v_ru_24x1_241205_24Bug = heff_take_reuse_n(v_x1_241205, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241205_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241257});
  }
  default: return heff_nomatch(v_x1_241205);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args) {
  V v_d_241258 = args[0];
  V v_l_241259 = args[1];
  V v_x1_241260 = heff_tr(heff_call(v_l_241259, 1, (V[]){v_d_241258}));
  switch (heff_tag_of(v_x1_241260)) {
  case TAG_Ok: {
    V v_v_241261 = heff_field(v_x1_241260, 0);
    heff_take_n(v_x1_241260, 1ULL, 1);
    V v_t_241262 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241261, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_241262; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str25); V r_ = (g_heff_2ecompile_2einterp_2ebytesJoined(a_0, a_1)); heff_drop(v_t_241262); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241263 = heff_field(v_x1_241260, 0);
    V v_ru_24x1_241260_24Bug = heff_take_reuse_n(v_x1_241260, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241260_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241263});
  }
  default: return heff_nomatch(v_x1_241260);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args) {
  V v_a_241264 = args[0];
  V v_b_241265 = args[1];
  V v_t_241266;
  if (heff_strEq_c(v_a_241264, v_b_241265)) {
    v_t_241266 = ((V)&g_heff_2ecompile_2einterp_2eprim_str26);
  } else {
    v_t_241266 = ((V)&g_heff_2ecompile_2einterp_2eprim_str27);
  }
  V v_t_241267 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241266, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241267});
}
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args) {
  V v_d_241271 = args[0];
  V v_b_241272 = args[1];
  V v_a_241270 = heff_env(self)[0];
  V v_f_241268 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241273 = heff_tr(heff_call(v_a_241270, 1, (V[]){heff_dup(v_d_241271)}));
  switch (heff_tag_of(v_x1_241273)) {
  case TAG_Ok: {
    V v_v_241274 = heff_field(v_x1_241273, 0);
    V v_ru_24x1_241273_24Ok = heff_take_reuse_n(v_x1_241273, 1ULL, 1);
    V v_x1_241275 = heff_tr(heff_call(v_b_241272, 1, (V[]){v_d_241271}));
    switch (heff_tag_of(v_x1_241275)) {
    case TAG_Ok: {
      V v_v_241276 = heff_field(v_x1_241275, 0);
      heff_take_n(v_x1_241275, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_241273_24Ok, 1);
      V v_f_241277 = v_f_241268;
      V v_x2_241278 = v_v_241274;
      V v_x3_241279 = v_v_241276;
      switch (heff_tag_of(v_x2_241278)) {
      case TAG_VFun: {
        heff_take_n(v_x2_241278, 0ULL, 1);
        heff_drop(v_f_241277);
        heff_drop(v_x3_241279);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VCons: {
        heff_take_n(v_x2_241278, 0ULL, 1);
        heff_drop(v_f_241277);
        heff_drop(v_x3_241279);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VTag: {
        heff_take_n(v_x2_241278, 0ULL, 2);
        heff_drop(v_f_241277);
        heff_drop(v_x3_241279);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VInt: {
        heff_take_n(v_x2_241278, 0ULL, 1);
        heff_drop(v_f_241277);
        heff_drop(v_x3_241279);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_x2_241278, 0ULL, 1);
        heff_drop(v_f_241277);
        heff_drop(v_x3_241279);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_x2_241278, 0ULL, 1);
        heff_drop(v_f_241277);
        heff_drop(v_x3_241279);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VStr: {
        heff_take_n(v_x2_241278, 0ULL, 1);
        heff_drop(v_f_241277);
        heff_drop(v_x3_241279);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VRune: {
        heff_take_n(v_x2_241278, 0ULL, 1);
        heff_drop(v_f_241277);
        heff_drop(v_x3_241279);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VArr: {
        heff_take_n(v_x2_241278, 0ULL, 1);
        heff_drop(v_f_241277);
        heff_drop(v_x3_241279);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VBytes: {
        V v_a_241290 = heff_field(v_x2_241278, 0);
        heff_take_n(v_x2_241278, 1ULL, 1);
        switch (heff_tag_of(v_x3_241279)) {
        case TAG_VFun: {
          heff_take_n(v_x3_241279, 0ULL, 1);
          heff_drop(v_f_241277);
          heff_drop(v_a_241290);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VCons: {
          heff_take_n(v_x3_241279, 0ULL, 1);
          heff_drop(v_f_241277);
          heff_drop(v_a_241290);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VTag: {
          heff_take_n(v_x3_241279, 0ULL, 2);
          heff_drop(v_f_241277);
          heff_drop(v_a_241290);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VInt: {
          heff_take_n(v_x3_241279, 0ULL, 1);
          heff_drop(v_f_241277);
          heff_drop(v_a_241290);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_x3_241279, 0ULL, 1);
          heff_drop(v_f_241277);
          heff_drop(v_a_241290);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_x3_241279, 0ULL, 1);
          heff_drop(v_f_241277);
          heff_drop(v_a_241290);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VStr: {
          heff_take_n(v_x3_241279, 0ULL, 1);
          heff_drop(v_f_241277);
          heff_drop(v_a_241290);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VRune: {
          heff_take_n(v_x3_241279, 0ULL, 1);
          heff_drop(v_f_241277);
          heff_drop(v_a_241290);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VArr: {
          heff_take_n(v_x3_241279, 0ULL, 1);
          heff_drop(v_f_241277);
          heff_drop(v_a_241290);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VBytes: {
          V v_b_241301 = heff_field(v_x3_241279, 0);
          heff_take_n(v_x3_241279, 1ULL, 1);
          V f_ = v_f_241277;
          args[0] = v_a_241290;
          args[1] = v_b_241301;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VBits: {
          heff_take_n(v_x3_241279, 0ULL, 2);
          heff_drop(v_f_241277);
          heff_drop(v_a_241290);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VErased: {
          heff_drop(v_f_241277);
          heff_drop(v_a_241290);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        default: return heff_nomatch(v_x3_241279);
        }
      }
      case TAG_VBits: {
        heff_take_n(v_x2_241278, 0ULL, 2);
        heff_drop(v_f_241277);
        heff_drop(v_x3_241279);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VErased: {
        heff_drop(v_f_241277);
        heff_drop(v_x3_241279);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      default: return heff_nomatch(v_x2_241278);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_241274);
      heff_drop_cell(v_ru_24x1_241273_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_241274);
      heff_drop_cell(v_ru_24x1_241273_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_241306 = heff_field(v_x1_241275, 0);
      heff_take_n(v_x1_241275, 1ULL, 1);
      heff_drop(v_v_241274);
      return heff_tag_at_n(v_ru_24x1_241273_24Ok, TAG_Bug, 1, (V[]){v_what_241306});
    }
    default: return heff_nomatch(v_x1_241275);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_241271);
    heff_drop(v_b_241272);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_241271);
    heff_drop(v_b_241272);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241307 = heff_field(v_x1_241273, 0);
    V v_ru_24x1_241273_24Bug = heff_take_reuse_n(v_x1_241273, 1ULL, 1);
    heff_drop(v_d_241271);
    heff_drop(v_b_241272);
    return heff_tag_re_n(v_ru_24x1_241273_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241307});
  }
  default: return heff_nomatch(v_x1_241273);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args) {
  V v_d_241269 = args[0];
  V v_a_241270 = args[1];
  V v_f_241268 = heff_env(self)[0];
  heff_drop(v_d_241269);
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam105, 2, 2, (V[]){v_a_241270, v_f_241268})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args) {
  V v_d_241308 = args[0];
  V v_l_241309 = args[1];
  V v_x1_241310 = heff_tr(heff_call(v_l_241309, 1, (V[]){v_d_241308}));
  switch (heff_tag_of(v_x1_241310)) {
  case TAG_Ok: {
    V v_v_241311 = heff_field(v_x1_241310, 0);
    V v_ru_24x1_241310_24Ok = heff_take_reuse_n(v_x1_241310, 1ULL, 1);
    V v_t_241312 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241311, NTAG(TAG_Nil)));
    V v_t_241313 = ({ V a_0 = v_t_241312; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str28); V r_ = (g_heff_2ecompile_2einterp_2ebyteString(a_0, a_1)); heff_drop(v_t_241312); r_; });
    return heff_tag_at_n(v_ru_24x1_241310_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_t_241313})});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241314 = heff_field(v_x1_241310, 0);
    V v_ru_24x1_241310_24Bug = heff_take_reuse_n(v_x1_241310, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241310_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241314});
  }
  default: return heff_nomatch(v_x1_241310);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args) {
  V v_d_241315 = args[0];
  V v_a_241316 = args[1];
  V v_x1_241317 = heff_tr(heff_call(v_a_241316, 1, (V[]){v_d_241315}));
  switch (heff_tag_of(v_x1_241317)) {
  case TAG_Ok: {
    V v_v_241318 = heff_field(v_x1_241317, 0);
    V v_ru_24x1_241317_24Ok = heff_take_reuse_n(v_x1_241317, 1ULL, 1);
    switch (heff_tag_of(v_v_241318)) {
    case TAG_VFun: {
      heff_take_n(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241318, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241329 = heff_field(v_v_241318, 0);
      heff_take_n(v_v_241318, 1ULL, 1);
      int64_t v_t_241330 = (heff_unbox_word(heff_strLength_lent(v_a_241329, 0)) - ((int64_t)1ULL));
      V v_t_241331 = ({ V a_0 = v_a_241329; V a_1 = MK_INT(0LL); V a_2 = heff_box_word(v_t_241330); V r_ = (g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(a_0, a_1, a_2)); heff_drop(v_a_241329); r_; });
      return heff_tag_at_n(v_ru_24x1_241317_24Ok, TAG_Ok, 1, (V[]){v_t_241331});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241318, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241318);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241334 = heff_field(v_x1_241317, 0);
    V v_ru_24x1_241317_24Bug = heff_take_reuse_n(v_x1_241317, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241317_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241334});
  }
  default: return heff_nomatch(v_x1_241317);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args) {
  V v_d_241335 = args[0];
  V v_a_241336 = args[1];
  V v_x1_241337 = heff_tr(heff_call(v_a_241336, 1, (V[]){v_d_241335}));
  switch (heff_tag_of(v_x1_241337)) {
  case TAG_Ok: {
    V v_v_241338 = heff_field(v_x1_241337, 0);
    V v_ru_24x1_241337_24Ok = heff_take_reuse_n(v_x1_241337, 1ULL, 1);
    switch (heff_tag_of(v_v_241338)) {
    case TAG_VFun: {
      heff_take_n(v_v_241338, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241337_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241338, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241337_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241338, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241337_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241338, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241337_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241338, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241337_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241338, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241337_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241346 = heff_field(v_v_241338, 0);
      V v_ru_24v_241338_24VStr = heff_take_reuse_n(v_v_241338, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241337_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241338_24VStr, TAG_VBytes, 1, (V[]){v_a_241346})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241338, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241337_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241338, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241337_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241338, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241337_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241338, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241337_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241337_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241338);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241352 = heff_field(v_x1_241337, 0);
    V v_ru_24x1_241337_24Bug = heff_take_reuse_n(v_x1_241337, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241337_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241352});
  }
  default: return heff_nomatch(v_x1_241337);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args) {
  V v_d_241353 = args[0];
  V v_a_241354 = args[1];
  V v_x1_241355 = heff_tr(heff_call(v_a_241354, 1, (V[]){v_d_241353}));
  switch (heff_tag_of(v_x1_241355)) {
  case TAG_Ok: {
    V v_v_241356 = heff_field(v_x1_241355, 0);
    V v_ru_24x1_241355_24Ok = heff_take_reuse_n(v_x1_241355, 1ULL, 1);
    switch (heff_tag_of(v_v_241356)) {
    case TAG_VFun: {
      heff_take_n(v_v_241356, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241356, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241356, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241356, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241356, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241356, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241356, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241356, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241356, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241367 = heff_field(v_v_241356, 0);
      V v_ru_24v_241356_24VBytes = heff_take_reuse_n(v_v_241356, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241355_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241356_24VBytes, TAG_VStr, 1, (V[]){v_a_241367})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241356, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241356);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241370 = heff_field(v_x1_241355, 0);
    V v_ru_24x1_241355_24Bug = heff_take_reuse_n(v_x1_241355, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241355_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241370});
  }
  default: return heff_nomatch(v_x1_241355);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam110(V self, V *args) {
  V v_d_241371 = args[0];
  V v_a_241372 = args[1];
  V v_x1_241373 = heff_tr(heff_call(v_a_241372, 1, (V[]){v_d_241371}));
  switch (heff_tag_of(v_x1_241373)) {
  case TAG_Ok: {
    V v_v_241374 = heff_field(v_x1_241373, 0);
    V v_ru_24x1_241373_24Ok = heff_take_reuse_n(v_x1_241373, 1ULL, 1);
    switch (heff_tag_of(v_v_241374)) {
    case TAG_VFun: {
      heff_take_n(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241374, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241385 = heff_field(v_v_241374, 0);
      V v_ru_24v_241374_24VBytes = heff_take_reuse_n(v_v_241374, 1ULL, 1);
      V v_t_241386 = (g_rune_2evalidString_2evalidFrom_240(v_a_241385, MK_INT(0LL)));
      V v_t_241387;
      if ((heff_dup(v_t_241386) == NTAG(TAG_True))) {
        heff_drop(v_t_241386);
        v_t_241387 = v_a_241385;
      } else {
        heff_drop(v_t_241386);
        v_t_241387 = heff_strOfRunes(heff_strRunes(v_a_241385));
      }
      return heff_tag_at_n(v_ru_24x1_241373_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241374_24VBytes, TAG_VStr, 1, (V[]){v_t_241387})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241374, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241374);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241390 = heff_field(v_x1_241373, 0);
    V v_ru_24x1_241373_24Bug = heff_take_reuse_n(v_x1_241373, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241373_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241390});
  }
  default: return heff_nomatch(v_x1_241373);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam114(V self, V *args) {
  V v_d_241424 = args[0];
  V v_a_241425 = args[1];
  V v_a_241405 = heff_env(self)[0];
  V v_a_241414 = heff_env(self)[1];
  V v_a_241423 = heff_env(self)[2];
  V v_x1_241426 = heff_tr(heff_call(v_a_241425, 1, (V[]){v_d_241424}));
  switch (heff_tag_of(v_x1_241426)) {
  case TAG_Ok: {
    V v_v_241427 = heff_field(v_x1_241426, 0);
    V v_ru_24x1_241426_24Ok = heff_take_reuse_n(v_x1_241426, 1ULL, 1);
    switch (heff_tag_of(v_v_241427)) {
    case TAG_VFun: {
      heff_take_n(v_v_241427, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241426_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241427, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241426_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241427, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241426_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241432 = heff_field(v_v_241427, 0);
      heff_take_n(v_v_241427, 1ULL, 1);
      int64_t v_t_241433 = (heff_unbox_word(heff_strLength_lent(v_a_241405, 0)) * ((int64_t)8ULL));
      heff_clo_take(self, 3);
      return ({ V a_0 = v_ru_24x1_241426_24Ok; V a_1 = v_a_241405; V a_2 = heff_box_word(v_t_241433); V a_3 = v_a_241414; V a_4 = v_a_241423; V a_5 = v_a_241432; V r_ = (g_heff_2ecompile_2einterp_2eintAtV_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_a_241405); r_; });
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241427, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241426_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241427, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241426_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241427, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241426_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241427, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241426_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241427, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241426_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241427, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241426_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241427, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241426_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241426_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241427);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241442 = heff_field(v_x1_241426, 0);
    V v_ru_24x1_241426_24Bug = heff_take_reuse_n(v_x1_241426, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241426_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241442});
  }
  default: return heff_nomatch(v_x1_241426);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam113(V self, V *args) {
  V v_d_241415 = args[0];
  V v_a_241416 = args[1];
  V v_a_241405 = heff_env(self)[0];
  V v_a_241414 = heff_env(self)[1];
  V v_x1_241417 = heff_tr(heff_call(v_a_241416, 1, (V[]){v_d_241415}));
  switch (heff_tag_of(v_x1_241417)) {
  case TAG_Ok: {
    V v_v_241418 = heff_field(v_x1_241417, 0);
    V v_ru_24x1_241417_24Ok = heff_take_reuse_n(v_x1_241417, 1ULL, 1);
    switch (heff_tag_of(v_v_241418)) {
    case TAG_VFun: {
      heff_take_n(v_v_241418, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241417_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241418, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241417_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241418, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241417_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241423 = heff_field(v_v_241418, 0);
      V v_ru_24v_241418_24VInt = heff_take_reuse_n(v_v_241418, 1ULL, 1);
      heff_clo_take(self, 2);
      return heff_tag_at_n(v_ru_24x1_241417_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241418_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam114, 2, 3, (V[]){v_a_241405, v_a_241414, v_a_241423})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241418, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241417_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241418, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241417_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241418, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241417_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241418, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241417_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241418, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241417_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241418, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241417_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241418, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241417_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241417_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241418);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241451 = heff_field(v_x1_241417, 0);
    V v_ru_24x1_241417_24Bug = heff_take_reuse_n(v_x1_241417, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241417_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241451});
  }
  default: return heff_nomatch(v_x1_241417);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam112(V self, V *args) {
  V v_d_241406 = args[0];
  V v_a_241407 = args[1];
  V v_a_241405 = heff_env(self)[0];
  V v_x1_241408 = heff_tr(heff_call(v_a_241407, 1, (V[]){v_d_241406}));
  switch (heff_tag_of(v_x1_241408)) {
  case TAG_Ok: {
    V v_v_241409 = heff_field(v_x1_241408, 0);
    V v_ru_24x1_241408_24Ok = heff_take_reuse_n(v_x1_241408, 1ULL, 1);
    switch (heff_tag_of(v_v_241409)) {
    case TAG_VFun: {
      heff_take_n(v_v_241409, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241408_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241409, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241408_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241409, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241408_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241414 = heff_field(v_v_241409, 0);
      V v_ru_24v_241409_24VInt = heff_take_reuse_n(v_v_241409, 1ULL, 1);
      heff_clo_take(self, 1);
      return heff_tag_at_n(v_ru_24x1_241408_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241409_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam113, 2, 2, (V[]){v_a_241405, v_a_241414})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241409, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241408_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241409, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241408_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241409, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241408_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241409, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241408_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241409, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241408_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241409, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241408_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241409, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241408_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241408_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241409);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241460 = heff_field(v_x1_241408, 0);
    V v_ru_24x1_241408_24Bug = heff_take_reuse_n(v_x1_241408, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241408_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241460});
  }
  default: return heff_nomatch(v_x1_241408);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam111(V self, V *args) {
  V v_d_241391 = args[0];
  V v_a_241392 = args[1];
  V v_x1_241393 = heff_tr(heff_call(v_a_241392, 1, (V[]){v_d_241391}));
  switch (heff_tag_of(v_x1_241393)) {
  case TAG_Ok: {
    V v_v_241394 = heff_field(v_x1_241393, 0);
    V v_ru_24x1_241393_24Ok = heff_take_reuse_n(v_x1_241393, 1ULL, 1);
    switch (heff_tag_of(v_v_241394)) {
    case TAG_VFun: {
      heff_take_n(v_v_241394, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241393_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241394, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241393_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241394, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241393_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241394, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241393_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241394, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241393_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241394, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241393_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241394, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241393_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241394, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241393_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241394, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241393_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241405 = heff_field(v_v_241394, 0);
      V v_ru_24v_241394_24VBytes = heff_take_reuse_n(v_v_241394, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241393_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241394_24VBytes, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam112, 2, 1, (V[]){v_a_241405})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241394, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241393_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241393_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241394);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241463 = heff_field(v_x1_241393, 0);
    V v_ru_24x1_241393_24Bug = heff_take_reuse_n(v_x1_241393, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241393_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241463});
  }
  default: return heff_nomatch(v_x1_241393);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam117(V self, V *args) {
  V v_d_241482 = args[0];
  V v_a_241483 = args[1];
  V v_a_241472 = heff_env(self)[0];
  V v_a_241481 = heff_env(self)[1];
  V v_x1_241484 = heff_tr(heff_call(v_a_241483, 1, (V[]){v_d_241482}));
  switch (heff_tag_of(v_x1_241484)) {
  case TAG_Ok: {
    V v_v_241485 = heff_field(v_x1_241484, 0);
    V v_ru_24x1_241484_24Ok = heff_take_reuse_n(v_x1_241484, 1ULL, 1);
    switch (heff_tag_of(v_v_241485)) {
    case TAG_VFun: {
      heff_take_n(v_v_241485, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241484_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241485, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241484_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241485, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241484_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241490 = heff_field(v_v_241485, 0);
      V v_ru_24v_241485_24VInt = heff_take_reuse_n(v_v_241485, 1ULL, 1);
      heff_clo_take(self, 2);
      V v_n_241491 = v_a_241472;
      V v_f_241492 = v_a_241481;
      V v_v_241493 = v_a_241490;
      if ((heff_intLt_c_lent(v_n_241491, MK_INT(0LL), 2) || (heff_intLt_c_lent(MK_INT(64LL), v_n_241491, 1) || !((heff_peek_word(v_n_241491) % ((int64_t)8ULL)) == ((int64_t)0ULL))))) {
        heff_drop_cell(v_ru_24x1_241484_24Ok, 1);
        heff_drop_cell(v_ru_24v_241485_24VInt, 1);
        heff_drop(v_n_241491);
        heff_drop(v_f_241492);
        heff_drop(v_v_241493);
        return NTAG(TAG_Abn);
      } else {
        V v_w_241494 = (g_heff_2ecompile_2einterp_2ewordOf(heff_dup(v_n_241491), v_f_241492, v_v_241493));
        int64_t v_t_241495 = ((heff_peek_word(v_n_241491) + ((int64_t)7ULL)) / ((int64_t)8ULL));
        int64_t v_t_241496 = ((v_t_241495 * ((int64_t)8ULL)) - heff_peek_word(v_n_241491));
        V v_t_241497 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word(v_t_241496)));
        int64_t v_t_241498 = ((heff_unbox_word(v_n_241491) + ((int64_t)7ULL)) / ((int64_t)8ULL));
        V v_t_241499 = (g_heff_2ecompile_2einterp_2ebytesOfNat(heff_box_word(v_t_241498), heff_intMul(v_w_241494, v_t_241497), ((V)&g_heff_2ecompile_2einterp_2eprim_str29)));
        return heff_tag_at_n(v_ru_24x1_241484_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241485_24VInt, TAG_VBytes, 1, (V[]){v_t_241499})});
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241485, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241484_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241485, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241484_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241485, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241484_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241485, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241484_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241485, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241484_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241485, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241484_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241485, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241484_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241484_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241485);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241508 = heff_field(v_x1_241484, 0);
    V v_ru_24x1_241484_24Bug = heff_take_reuse_n(v_x1_241484, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241484_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241508});
  }
  default: return heff_nomatch(v_x1_241484);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam116(V self, V *args) {
  V v_d_241473 = args[0];
  V v_a_241474 = args[1];
  V v_a_241472 = heff_env(self)[0];
  V v_x1_241475 = heff_tr(heff_call(v_a_241474, 1, (V[]){v_d_241473}));
  switch (heff_tag_of(v_x1_241475)) {
  case TAG_Ok: {
    V v_v_241476 = heff_field(v_x1_241475, 0);
    V v_ru_24x1_241475_24Ok = heff_take_reuse_n(v_x1_241475, 1ULL, 1);
    switch (heff_tag_of(v_v_241476)) {
    case TAG_VFun: {
      heff_take_n(v_v_241476, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241476, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241476, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241481 = heff_field(v_v_241476, 0);
      V v_ru_24v_241476_24VInt = heff_take_reuse_n(v_v_241476, 1ULL, 1);
      heff_clo_take(self, 1);
      return heff_tag_at_n(v_ru_24x1_241475_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241476_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam117, 2, 2, (V[]){v_a_241472, v_a_241481})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241476, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241476, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241476, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241476, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241476, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241476, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241476, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241476);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241517 = heff_field(v_x1_241475, 0);
    V v_ru_24x1_241475_24Bug = heff_take_reuse_n(v_x1_241475, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241475_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241517});
  }
  default: return heff_nomatch(v_x1_241475);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam115(V self, V *args) {
  V v_d_241464 = args[0];
  V v_a_241465 = args[1];
  V v_x1_241466 = heff_tr(heff_call(v_a_241465, 1, (V[]){v_d_241464}));
  switch (heff_tag_of(v_x1_241466)) {
  case TAG_Ok: {
    V v_v_241467 = heff_field(v_x1_241466, 0);
    V v_ru_24x1_241466_24Ok = heff_take_reuse_n(v_x1_241466, 1ULL, 1);
    switch (heff_tag_of(v_v_241467)) {
    case TAG_VFun: {
      heff_take_n(v_v_241467, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241466_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241467, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241466_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241467, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241466_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241472 = heff_field(v_v_241467, 0);
      V v_ru_24v_241467_24VInt = heff_take_reuse_n(v_v_241467, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241466_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241467_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam116, 2, 1, (V[]){v_a_241472})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241467, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241466_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241467, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241466_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241467, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241466_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241467, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241466_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241467, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241466_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241467, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241466_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241467, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241466_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241466_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241467);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241526 = heff_field(v_x1_241466, 0);
    V v_ru_24x1_241466_24Bug = heff_take_reuse_n(v_x1_241466, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241466_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241526});
  }
  default: return heff_nomatch(v_x1_241466);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam120(V self, V *args) {
  V v_d_241551 = args[0];
  V v_a_241552 = args[1];
  V v_a_241550 = heff_env(self)[0];
  V v_a_241541 = heff_env(self)[1];
  V v_x1_241553 = heff_tr(heff_call(v_a_241552, 1, (V[]){v_d_241551}));
  switch (heff_tag_of(v_x1_241553)) {
  case TAG_Ok: {
    V v_v_241554 = heff_field(v_x1_241553, 0);
    V v_ru_24x1_241553_24Ok = heff_take_reuse_n(v_x1_241553, 1ULL, 1);
    switch (heff_tag_of(v_v_241554)) {
    case TAG_VFun: {
      heff_take_n(v_v_241554, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241554, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241554, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241554, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241554, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241554, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241554, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241554, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241554, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241565 = heff_field(v_v_241554, 0);
      heff_take_n(v_v_241554, 1ULL, 1);
      V v_t_241567;
      heff_clo_take(self, 2);
      if ((heff_intLe_c_lent(MK_INT(0LL), v_a_241550, 1) && (heff_intLe_c(heff_intAdd_lent(v_a_241550, heff_strLength_lent(v_a_241565, 0), 2), heff_strLength_lent(v_a_241541, 0)) && ({ V v_t_241566 = heff_intAdd_lent(v_a_241550, heff_strLength_lent(v_a_241565, 0), 2); int c_ = ({ V v_t_242155 = heff_strSlice_lent(v_a_241541, v_a_241550, v_t_241566, 0); int c_ = heff_strEq_c_lent(v_t_242155, v_a_241565, 0); heff_drop(v_t_242155); c_; }); heff_drop(v_t_241566); c_; })))) {
        heff_drop(v_a_241550);
        heff_drop(v_a_241541);
        heff_drop(v_a_241565);
        v_t_241567 = ((V)&g_heff_2ecompile_2einterp_2eprim_str30);
      } else {
        heff_drop(v_a_241550);
        heff_drop(v_a_241541);
        heff_drop(v_a_241565);
        v_t_241567 = ((V)&g_heff_2ecompile_2einterp_2eprim_str31);
      }
      V v_t_241568 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241567, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_241553_24Ok, TAG_Ok, 1, (V[]){v_t_241568});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241554, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241554);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241571 = heff_field(v_x1_241553, 0);
    V v_ru_24x1_241553_24Bug = heff_take_reuse_n(v_x1_241553, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241553_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241571});
  }
  default: return heff_nomatch(v_x1_241553);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam119(V self, V *args) {
  V v_d_241542 = args[0];
  V v_a_241543 = args[1];
  V v_a_241541 = heff_env(self)[0];
  V v_x1_241544 = heff_tr(heff_call(v_a_241543, 1, (V[]){v_d_241542}));
  switch (heff_tag_of(v_x1_241544)) {
  case TAG_Ok: {
    V v_v_241545 = heff_field(v_x1_241544, 0);
    V v_ru_24x1_241544_24Ok = heff_take_reuse_n(v_x1_241544, 1ULL, 1);
    switch (heff_tag_of(v_v_241545)) {
    case TAG_VFun: {
      heff_take_n(v_v_241545, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241544_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241545, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241544_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241545, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241544_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241550 = heff_field(v_v_241545, 0);
      V v_ru_24v_241545_24VInt = heff_take_reuse_n(v_v_241545, 1ULL, 1);
      heff_clo_take(self, 1);
      return heff_tag_at_n(v_ru_24x1_241544_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241545_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam120, 2, 2, (V[]){v_a_241550, v_a_241541})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241545, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241544_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241545, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241544_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241545, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241544_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241545, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241544_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241545, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241544_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241545, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241544_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241545, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241544_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241544_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241545);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241580 = heff_field(v_x1_241544, 0);
    V v_ru_24x1_241544_24Bug = heff_take_reuse_n(v_x1_241544, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241544_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241580});
  }
  default: return heff_nomatch(v_x1_241544);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam118(V self, V *args) {
  V v_d_241527 = args[0];
  V v_a_241528 = args[1];
  V v_x1_241529 = heff_tr(heff_call(v_a_241528, 1, (V[]){v_d_241527}));
  switch (heff_tag_of(v_x1_241529)) {
  case TAG_Ok: {
    V v_v_241530 = heff_field(v_x1_241529, 0);
    V v_ru_24x1_241529_24Ok = heff_take_reuse_n(v_x1_241529, 1ULL, 1);
    switch (heff_tag_of(v_v_241530)) {
    case TAG_VFun: {
      heff_take_n(v_v_241530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241530, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241541 = heff_field(v_v_241530, 0);
      V v_ru_24v_241530_24VBytes = heff_take_reuse_n(v_v_241530, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241529_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241530_24VBytes, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam119, 2, 1, (V[]){v_a_241541})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241530, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241530);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241583 = heff_field(v_x1_241529, 0);
    V v_ru_24x1_241529_24Bug = heff_take_reuse_n(v_x1_241529, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241529_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241583});
  }
  default: return heff_nomatch(v_x1_241529);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam124(V self, V *args) {
  V v_d_241604 = args[0];
  V v_a_241605 = args[1];
  V v_s_241585 = heff_env(self)[0];
  V v_m_241584 = heff_env(self)[1];
  V v_a_241594 = heff_env(self)[2];
  V v_a_241603 = heff_env(self)[3];
  V v_x1_241606 = heff_tr(heff_call(v_a_241605, 1, (V[]){v_d_241604}));
  switch (heff_tag_of(v_x1_241606)) {
  case TAG_Ok: {
    V v_v_241607 = heff_field(v_x1_241606, 0);
    V v_ru_24x1_241606_24Ok = heff_take_reuse_n(v_x1_241606, 1ULL, 1);
    switch (heff_tag_of(v_v_241607)) {
    case TAG_VFun: {
      heff_take_n(v_v_241607, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241606_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241607, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241606_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241607, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241606_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241612 = heff_field(v_v_241607, 0);
      heff_take_n(v_v_241607, 1ULL, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_ru_24x1_241606_24Ok; V a_1 = v_s_241585; V a_2 = v_m_241584; V a_3 = v_a_241594; V a_4 = v_a_241603; V a_5 = v_a_241612; V r_ = (g_heff_2ecompile_2einterp_2eintAtV_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_s_241585); r_; });
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241607, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241606_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241607, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241606_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241607, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241606_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241607, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241606_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241607, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241606_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241607, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241606_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241607, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241606_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241606_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241607);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241621 = heff_field(v_x1_241606, 0);
    V v_ru_24x1_241606_24Bug = heff_take_reuse_n(v_x1_241606, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241606_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241621});
  }
  default: return heff_nomatch(v_x1_241606);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam123(V self, V *args) {
  V v_d_241595 = args[0];
  V v_a_241596 = args[1];
  V v_s_241585 = heff_env(self)[0];
  V v_m_241584 = heff_env(self)[1];
  V v_a_241594 = heff_env(self)[2];
  V v_x1_241597 = heff_tr(heff_call(v_a_241596, 1, (V[]){v_d_241595}));
  switch (heff_tag_of(v_x1_241597)) {
  case TAG_Ok: {
    V v_v_241598 = heff_field(v_x1_241597, 0);
    V v_ru_24x1_241597_24Ok = heff_take_reuse_n(v_x1_241597, 1ULL, 1);
    switch (heff_tag_of(v_v_241598)) {
    case TAG_VFun: {
      heff_take_n(v_v_241598, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241597_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241598, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241597_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241598, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241597_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241603 = heff_field(v_v_241598, 0);
      V v_ru_24v_241598_24VInt = heff_take_reuse_n(v_v_241598, 1ULL, 1);
      heff_clo_take(self, 3);
      return heff_tag_at_n(v_ru_24x1_241597_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241598_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam124, 2, 4, (V[]){v_s_241585, v_m_241584, v_a_241594, v_a_241603})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241598, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241597_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241598, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241597_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241598, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241597_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241598, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241597_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241598, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241597_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241598, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241597_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241598, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241597_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241597_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241598);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241630 = heff_field(v_x1_241597, 0);
    V v_ru_24x1_241597_24Bug = heff_take_reuse_n(v_x1_241597, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241597_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241630});
  }
  default: return heff_nomatch(v_x1_241597);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam122(V self, V *args) {
  V v_d_241586 = args[0];
  V v_a_241587 = args[1];
  V v_s_241585 = heff_env(self)[0];
  V v_m_241584 = heff_env(self)[1];
  V v_x1_241588 = heff_tr(heff_call(v_a_241587, 1, (V[]){v_d_241586}));
  switch (heff_tag_of(v_x1_241588)) {
  case TAG_Ok: {
    V v_v_241589 = heff_field(v_x1_241588, 0);
    V v_ru_24x1_241588_24Ok = heff_take_reuse_n(v_x1_241588, 1ULL, 1);
    switch (heff_tag_of(v_v_241589)) {
    case TAG_VFun: {
      heff_take_n(v_v_241589, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241588_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241589, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241588_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241589, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241588_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241594 = heff_field(v_v_241589, 0);
      V v_ru_24v_241589_24VInt = heff_take_reuse_n(v_v_241589, 1ULL, 1);
      heff_clo_take(self, 2);
      return heff_tag_at_n(v_ru_24x1_241588_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241589_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam123, 2, 3, (V[]){v_s_241585, v_m_241584, v_a_241594})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241589, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241588_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241589, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241588_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241589, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241588_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241589, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241588_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241589, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241588_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241589, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241588_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241589, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241588_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241588_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241589);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241639 = heff_field(v_x1_241588, 0);
    V v_ru_24x1_241588_24Bug = heff_take_reuse_n(v_x1_241588, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241588_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241639});
  }
  default: return heff_nomatch(v_x1_241588);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam121(V self, V *args) {
  V v_m_241584 = args[0];
  V v_s_241585 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam122, 2, 2, (V[]){v_s_241585, v_m_241584})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam127(V self, V *args) {
  V v_d_241658 = args[0];
  V v_a_241659 = args[1];
  V v_a_241648 = heff_env(self)[0];
  V v_a_241657 = heff_env(self)[1];
  V v_x1_241660 = heff_tr(heff_call(v_a_241659, 1, (V[]){v_d_241658}));
  switch (heff_tag_of(v_x1_241660)) {
  case TAG_Ok: {
    V v_v_241661 = heff_field(v_x1_241660, 0);
    V v_ru_24x1_241660_24Ok = heff_take_reuse_n(v_x1_241660, 1ULL, 1);
    switch (heff_tag_of(v_v_241661)) {
    case TAG_VFun: {
      heff_take_n(v_v_241661, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241660_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241661, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241660_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241661, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241660_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241666 = heff_field(v_v_241661, 0);
      heff_take_n(v_v_241661, 1ULL, 1);
      heff_clo_take(self, 2);
      V v_n_241667 = v_a_241648;
      V v_f_241668 = v_a_241657;
      V v_v_241669 = v_a_241666;
      if ((heff_intLt_c_lent(v_n_241667, MK_INT(0LL), 2) || heff_intLt_c_lent(MK_INT(64LL), v_n_241667, 1))) {
        heff_drop_cell(v_ru_24x1_241660_24Ok, 1);
        heff_drop(v_n_241667);
        heff_drop(v_f_241668);
        heff_drop(v_v_241669);
        return NTAG(TAG_Abn);
      } else {
        V v_w_241670 = (g_heff_2ecompile_2einterp_2ewordOf(heff_dup(v_n_241667), v_f_241668, v_v_241669));
        int64_t v_t_241671 = ((heff_peek_word(v_n_241667) + ((int64_t)7ULL)) / ((int64_t)8ULL));
        int64_t v_t_241672 = ((v_t_241671 * ((int64_t)8ULL)) - heff_peek_word(v_n_241667));
        V v_t_241673 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word(v_t_241672)));
        int64_t v_t_241674 = ((heff_peek_word(v_n_241667) + ((int64_t)7ULL)) / ((int64_t)8ULL));
        V v_t_241675 = (g_heff_2ecompile_2einterp_2ebytesOfNat(heff_box_word(v_t_241674), heff_intMul(v_w_241670, v_t_241673), ((V)&g_heff_2ecompile_2einterp_2eprim_str32)));
        return heff_tag_at_n(v_ru_24x1_241660_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_n_241667, v_t_241675})});
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241661, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241660_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241661, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241660_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241661, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241660_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241661, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241660_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241661, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241660_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241661, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241660_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241661, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241660_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241660_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241661);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241684 = heff_field(v_x1_241660, 0);
    V v_ru_24x1_241660_24Bug = heff_take_reuse_n(v_x1_241660, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241660_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241684});
  }
  default: return heff_nomatch(v_x1_241660);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam126(V self, V *args) {
  V v_d_241649 = args[0];
  V v_a_241650 = args[1];
  V v_a_241648 = heff_env(self)[0];
  V v_x1_241651 = heff_tr(heff_call(v_a_241650, 1, (V[]){v_d_241649}));
  switch (heff_tag_of(v_x1_241651)) {
  case TAG_Ok: {
    V v_v_241652 = heff_field(v_x1_241651, 0);
    V v_ru_24x1_241651_24Ok = heff_take_reuse_n(v_x1_241651, 1ULL, 1);
    switch (heff_tag_of(v_v_241652)) {
    case TAG_VFun: {
      heff_take_n(v_v_241652, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241651_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241652, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241651_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241652, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241651_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241657 = heff_field(v_v_241652, 0);
      V v_ru_24v_241652_24VInt = heff_take_reuse_n(v_v_241652, 1ULL, 1);
      heff_clo_take(self, 1);
      return heff_tag_at_n(v_ru_24x1_241651_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241652_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam127, 2, 2, (V[]){v_a_241648, v_a_241657})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241652, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241651_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241652, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241651_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241652, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241651_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241652, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241651_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241652, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241651_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241652, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241651_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241652, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241651_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241651_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241652);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241693 = heff_field(v_x1_241651, 0);
    V v_ru_24x1_241651_24Bug = heff_take_reuse_n(v_x1_241651, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241651_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241693});
  }
  default: return heff_nomatch(v_x1_241651);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam125(V self, V *args) {
  V v_d_241640 = args[0];
  V v_a_241641 = args[1];
  V v_x1_241642 = heff_tr(heff_call(v_a_241641, 1, (V[]){v_d_241640}));
  switch (heff_tag_of(v_x1_241642)) {
  case TAG_Ok: {
    V v_v_241643 = heff_field(v_x1_241642, 0);
    V v_ru_24x1_241642_24Ok = heff_take_reuse_n(v_x1_241642, 1ULL, 1);
    switch (heff_tag_of(v_v_241643)) {
    case TAG_VFun: {
      heff_take_n(v_v_241643, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241642_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241643, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241642_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241643, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241642_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241648 = heff_field(v_v_241643, 0);
      V v_ru_24v_241643_24VInt = heff_take_reuse_n(v_v_241643, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241642_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241643_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam126, 2, 1, (V[]){v_a_241648})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241643, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241642_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241643, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241642_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241643, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241642_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241643, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241642_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241643, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241642_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241643, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241642_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241643, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241642_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241642_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241643);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241702 = heff_field(v_x1_241642, 0);
    V v_ru_24x1_241642_24Bug = heff_take_reuse_n(v_x1_241642, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241642_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241702});
  }
  default: return heff_nomatch(v_x1_241642);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam128(V self, V *args) {
  V v_d_241703 = args[0];
  V v_l_241704 = args[1];
  V v_x1_241705 = heff_tr(heff_call(v_l_241704, 1, (V[]){v_d_241703}));
  switch (heff_tag_of(v_x1_241705)) {
  case TAG_Ok: {
    V v_v_241706 = heff_field(v_x1_241705, 0);
    heff_take_n(v_x1_241705, 1ULL, 1);
    V v_t_241707 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241706, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_241707; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2einterp_2eprim_str33); V r_ = (g_heff_2ecompile_2einterp_2ebitsJoined(a_0, a_1, a_2)); heff_drop(v_t_241707); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241708 = heff_field(v_x1_241705, 0);
    V v_ru_24x1_241705_24Bug = heff_take_reuse_n(v_x1_241705, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241705_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241708});
  }
  default: return heff_nomatch(v_x1_241705);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam131(V self, V *args) {
  V v_d_241720 = args[0];
  V v_a_241721 = args[1];
  V v_a_241719 = heff_env(self)[0];
  V v_m_241709 = heff_env(self)[1];
  V v_s_241710 = heff_env(self)[2];
  V v_x1_241722 = heff_tr(heff_call(v_a_241721, 1, (V[]){v_d_241720}));
  switch (heff_tag_of(v_x1_241722)) {
  case TAG_Ok: {
    V v_v_241723 = heff_field(v_x1_241722, 0);
    V v_ru_24x1_241722_24Ok = heff_take_reuse_n(v_x1_241722, 1ULL, 1);
    switch (heff_tag_of(v_v_241723)) {
    case TAG_VFun: {
      heff_take_n(v_v_241723, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241722_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241723, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241722_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241723, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241722_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241728 = heff_field(v_v_241723, 0);
      heff_take_n(v_v_241723, 1ULL, 1);
      if ((heff_intLt_c_lent(v_a_241719, MK_INT(0LL), 2) || (heff_intLt_c_lent(v_a_241728, MK_INT(0LL), 2) || heff_intLt_c_lent(v_m_241709, heff_intAdd_lent(v_a_241719, v_a_241728, 0), 2)))) {
        heff_drop(self);
        heff_drop_cell(v_ru_24x1_241722_24Ok, 1);
        heff_drop(v_a_241728);
        return NTAG(TAG_Abn);
      } else {
        heff_clo_take(self, 3);
        heff_drop(v_m_241709);
        V v_t_241729 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str34); V a_2 = v_s_241710; V a_3 = heff_dup(v_a_241719); V a_4 = heff_intAdd_lent(v_a_241719, v_a_241728, 1); V r_ = (g_heff_2ecompile_2einterp_2ebitsCopy(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_241710); r_; });
        return heff_tag_at_n(v_ru_24x1_241722_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_a_241728, v_t_241729})});
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241723, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241722_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241723, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241722_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241723, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241722_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241723, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241722_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241723, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241722_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241723, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241722_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241723, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241722_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241722_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241723);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241738 = heff_field(v_x1_241722, 0);
    V v_ru_24x1_241722_24Bug = heff_take_reuse_n(v_x1_241722, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241722_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241738});
  }
  default: return heff_nomatch(v_x1_241722);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam130(V self, V *args) {
  V v_d_241711 = args[0];
  V v_a_241712 = args[1];
  V v_m_241709 = heff_env(self)[0];
  V v_s_241710 = heff_env(self)[1];
  V v_x1_241713 = heff_tr(heff_call(v_a_241712, 1, (V[]){v_d_241711}));
  switch (heff_tag_of(v_x1_241713)) {
  case TAG_Ok: {
    V v_v_241714 = heff_field(v_x1_241713, 0);
    V v_ru_24x1_241713_24Ok = heff_take_reuse_n(v_x1_241713, 1ULL, 1);
    switch (heff_tag_of(v_v_241714)) {
    case TAG_VFun: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241714, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241719 = heff_field(v_v_241714, 0);
      V v_ru_24v_241714_24VInt = heff_take_reuse_n(v_v_241714, 1ULL, 1);
      heff_clo_take(self, 2);
      return heff_tag_at_n(v_ru_24x1_241713_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241714_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam131, 2, 3, (V[]){v_a_241719, v_m_241709, v_s_241710})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241714, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241714, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241714);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241747 = heff_field(v_x1_241713, 0);
    V v_ru_24x1_241713_24Bug = heff_take_reuse_n(v_x1_241713, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241713_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241747});
  }
  default: return heff_nomatch(v_x1_241713);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam129(V self, V *args) {
  V v_m_241709 = args[0];
  V v_s_241710 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam130, 2, 2, (V[]){v_m_241709, v_s_241710})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam132(V self, V *args) {
  V v_d_241748 = args[0];
  V v_a_241749 = args[1];
  V v_x1_241750 = heff_tr(heff_call(v_a_241749, 1, (V[]){v_d_241748}));
  switch (heff_tag_of(v_x1_241750)) {
  case TAG_Ok: {
    V v_v_241751 = heff_field(v_x1_241750, 0);
    V v_ru_24x1_241750_24Ok = heff_take_reuse_n(v_x1_241750, 1ULL, 1);
    switch (heff_tag_of(v_v_241751)) {
    case TAG_VFun: {
      heff_take_n(v_v_241751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241751, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241762 = heff_field(v_v_241751, 0);
      heff_take_n(v_v_241751, 1ULL, 1);
      int64_t v_t_241763 = (heff_unbox_word(heff_strLength_lent(v_a_241762, 0)) * ((int64_t)8ULL));
      return heff_tag_at_n(v_ru_24x1_241750_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){heff_box_word(v_t_241763), v_a_241762})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241751, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241751);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241766 = heff_field(v_x1_241750, 0);
    V v_ru_24x1_241750_24Bug = heff_take_reuse_n(v_x1_241750, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241750_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241766});
  }
  default: return heff_nomatch(v_x1_241750);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam133(V self, V *args) {
  V v_n_241767 = args[0];
  V v_s_241768 = args[1];
  if ((heff_unbox_word(heff_intMod(v_n_241767, MK_INT(8LL))) == ((int64_t)0ULL))) {
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_s_241768})});
  } else {
    heff_drop(v_s_241768);
    return NTAG(TAG_Abn);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam135(V self, V *args) {
  V v_m_241771 = args[0];
  V v_t_241772 = args[1];
  V v_n_241769 = heff_env(self)[0];
  V v_s_241770 = heff_env(self)[1];
  V v_t_241773;
  heff_clo_take(self, 2);
  if ((heff_intEq_c_lent(v_n_241769, v_m_241771, 0) && heff_strEq_c_lent(v_s_241770, v_t_241772, 0))) {
    heff_drop(v_m_241771);
    heff_drop(v_t_241772);
    heff_drop(v_n_241769);
    heff_drop(v_s_241770);
    v_t_241773 = ((V)&g_heff_2ecompile_2einterp_2eprim_str35);
  } else {
    heff_drop(v_m_241771);
    heff_drop(v_t_241772);
    heff_drop(v_n_241769);
    heff_drop(v_s_241770);
    v_t_241773 = ((V)&g_heff_2ecompile_2einterp_2eprim_str36);
  }
  V v_t_241774 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241773, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241774});
}
V g_heff_2ecompile_2einterp_2eprim_lam134(V self, V *args) {
  V v_n_241769 = args[0];
  V v_s_241770 = args[1];
  V v_t_241775 = (g_heff_2ecompile_2einterp_2ebits1(heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam135, 2, 2, (V[]){v_n_241769, v_s_241770})));
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241775});
}
V g_heff_2ecompile_2einterp_2eprim_lam137(V self, V *args) {
  V v_d_241785 = args[0];
  V v_a_241786 = args[1];
  V v_a_241784 = heff_env(self)[0];
  V v_x1_241787 = heff_tr(heff_call(v_a_241786, 1, (V[]){v_d_241785}));
  switch (heff_tag_of(v_x1_241787)) {
  case TAG_Ok: {
    V v_v_241788 = heff_field(v_x1_241787, 0);
    V v_ru_24x1_241787_24Ok = heff_take_reuse_n(v_x1_241787, 1ULL, 1);
    switch (heff_tag_of(v_v_241788)) {
    case TAG_VFun: {
      heff_take_n(v_v_241788, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241788, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241788, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241788, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_241794 = heff_tflat_f64(v_v_241788, 0);
      V v_ru_24v_241788_24VFloat = heff_take_reuse_na(v_v_241788, 0ULL, 1);
      if (heff_intEq_c_lent(v_a_241784, MK_INT(64LL), 2)) {
        heff_drop(self);
        V v_t_241795 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(11LL), MK_INT(52LL), v_a_241794));
        return heff_tag_at_n(v_ru_24x1_241787_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241788_24VFloat, TAG_VInt, 1, (V[]){v_t_241795})});
      } else {
        heff_clo_take(self, 1);
        if (heff_intEq_c(v_a_241784, MK_INT(32LL))) {
          double v_t_241796 = ((double)((float)v_a_241794));
          V v_t_241797 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(8LL), MK_INT(23LL), v_t_241796));
          return heff_tag_at_n(v_ru_24x1_241787_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241788_24VFloat, TAG_VInt, 1, (V[]){v_t_241797})});
        } else {
          heff_drop_cell(v_ru_24x1_241787_24Ok, 1);
          heff_drop_cell(v_ru_24v_241788_24VFloat, 1);
          return NTAG(TAG_Abn);
        }
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241788, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241788, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241788, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241788, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241788, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241788, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_241788);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241805 = heff_field(v_x1_241787, 0);
    V v_ru_24x1_241787_24Bug = heff_take_reuse_n(v_x1_241787, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241787_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241805});
  }
  default: return heff_nomatch(v_x1_241787);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam136(V self, V *args) {
  V v_d_241776 = args[0];
  V v_a_241777 = args[1];
  V v_x1_241778 = heff_tr(heff_call(v_a_241777, 1, (V[]){v_d_241776}));
  switch (heff_tag_of(v_x1_241778)) {
  case TAG_Ok: {
    V v_v_241779 = heff_field(v_x1_241778, 0);
    V v_ru_24x1_241778_24Ok = heff_take_reuse_n(v_x1_241778, 1ULL, 1);
    switch (heff_tag_of(v_v_241779)) {
    case TAG_VFun: {
      heff_take_n(v_v_241779, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241778_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241779, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241778_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241779, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241778_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241784 = heff_field(v_v_241779, 0);
      V v_ru_24v_241779_24VInt = heff_take_reuse_n(v_v_241779, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241778_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241779_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam137, 2, 1, (V[]){v_a_241784})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241779, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241778_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241779, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241778_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241779, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241778_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241779, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241778_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241779, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241778_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241779, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241778_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241779, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241778_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241778_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241779);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241814 = heff_field(v_x1_241778, 0);
    V v_ru_24x1_241778_24Bug = heff_take_reuse_n(v_x1_241778, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241778_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241814});
  }
  default: return heff_nomatch(v_x1_241778);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam139(V self, V *args) {
  V v_d_241824 = args[0];
  V v_a_241825 = args[1];
  V v_a_241823 = heff_env(self)[0];
  V v_x1_241826 = heff_tr(heff_call(v_a_241825, 1, (V[]){v_d_241824}));
  switch (heff_tag_of(v_x1_241826)) {
  case TAG_Ok: {
    V v_v_241827 = heff_field(v_x1_241826, 0);
    V v_ru_24x1_241826_24Ok = heff_take_reuse_n(v_x1_241826, 1ULL, 1);
    switch (heff_tag_of(v_v_241827)) {
    case TAG_VFun: {
      heff_take_n(v_v_241827, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241826_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241827, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241826_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241827, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241826_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241832 = heff_field(v_v_241827, 0);
      V v_ru_24v_241827_24VInt = heff_take_reuse_n(v_v_241827, 1ULL, 1);
      heff_clo_take(self, 1);
      V v_n_241833 = v_a_241823;
      V v_u_241834 = v_a_241832;
      if (heff_intEq_c_lent(v_n_241833, MK_INT(64LL), 2)) {
        heff_drop(v_n_241833);
        V v_t_241835 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
        V v_t_241836 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
        V v_t_241837 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
        V v_t_241838 = heff_intAdd(heff_intMod(v_u_241834, v_t_241835), v_t_241836);
        double v_t_241839 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(11LL), MK_INT(52LL), heff_intMod(v_t_241838, v_t_241837)));
        return heff_tag_at_n(v_ru_24x1_241826_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_nf(v_ru_24v_241827_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_241839)})});
      } else {
        if (heff_intEq_c(v_n_241833, MK_INT(32LL))) {
          V v_t_241840 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
          V v_t_241841 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
          V v_t_241842 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
          V v_t_241843 = heff_intAdd(heff_intMod(v_u_241834, v_t_241840), v_t_241841);
          double v_t_241844 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(8LL), MK_INT(23LL), heff_intMod(v_t_241843, v_t_241842)));
          return heff_tag_at_n(v_ru_24x1_241826_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_nf(v_ru_24v_241827_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_241844)})});
        } else {
          heff_drop_cell(v_ru_24x1_241826_24Ok, 1);
          heff_drop_cell(v_ru_24v_241827_24VInt, 1);
          heff_drop(v_u_241834);
          return NTAG(TAG_Abn);
        }
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241827, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241826_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241827, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241826_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241827, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241826_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241827, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241826_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241827, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241826_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241827, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241826_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241827, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241826_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241826_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241827);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241853 = heff_field(v_x1_241826, 0);
    V v_ru_24x1_241826_24Bug = heff_take_reuse_n(v_x1_241826, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241826_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241853});
  }
  default: return heff_nomatch(v_x1_241826);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam138(V self, V *args) {
  V v_d_241815 = args[0];
  V v_a_241816 = args[1];
  V v_x1_241817 = heff_tr(heff_call(v_a_241816, 1, (V[]){v_d_241815}));
  switch (heff_tag_of(v_x1_241817)) {
  case TAG_Ok: {
    V v_v_241818 = heff_field(v_x1_241817, 0);
    V v_ru_24x1_241817_24Ok = heff_take_reuse_n(v_x1_241817, 1ULL, 1);
    switch (heff_tag_of(v_v_241818)) {
    case TAG_VFun: {
      heff_take_n(v_v_241818, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241817_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241818, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241817_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241818, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241817_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241823 = heff_field(v_v_241818, 0);
      V v_ru_24v_241818_24VInt = heff_take_reuse_n(v_v_241818, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241817_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241818_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam139, 2, 1, (V[]){v_a_241823})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241818, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241817_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241818, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241817_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241818, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241817_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241818, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241817_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241818, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241817_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241818, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241817_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241818, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241817_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241817_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241818);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241862 = heff_field(v_x1_241817, 0);
    V v_ru_24x1_241817_24Bug = heff_take_reuse_n(v_x1_241817, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241817_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241862});
  }
  default: return heff_nomatch(v_x1_241817);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam143(V self, V *args) {
  V v_d_241893 = args[0];
  V v_a_241894 = args[1];
  V v_a_241883 = heff_env(self)[0];
  V v_a_241892 = heff_env(self)[1];
  V v_a_241871 = heff_env(self)[2];
  V v_x1_241895 = heff_tr(heff_call(v_a_241894, 1, (V[]){v_d_241893}));
  switch (heff_tag_of(v_x1_241895)) {
  case TAG_Ok: {
    V v_v_241896 = heff_field(v_x1_241895, 0);
    V v_ru_24x1_241895_24Ok = heff_take_reuse_n(v_x1_241895, 1ULL, 1);
    switch (heff_tag_of(v_v_241896)) {
    case TAG_VFun: {
      heff_take_n(v_v_241896, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241895_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241896, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241895_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241896, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241895_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241901 = heff_field(v_v_241896, 0);
      V v_ru_24v_241896_24VInt = heff_take_reuse_n(v_v_241896, 1ULL, 1);
      heff_clo_take(self, 3);
      V v_t_241902 = heff_strSlice(v_a_241883, v_a_241892, v_a_241901);
      if (heff_intEq_c_lent(v_a_241871, MK_INT(64LL), 2)) {
        heff_drop(v_a_241871);
        double v_t_241903 = ({ V a_0 = MK_INT(64LL); V a_1 = v_t_241902; double r_ = (g_heff_2ecompile_2einterp_2edecimalTextV_w(a_0, a_1)); heff_drop(v_t_241902); r_; });
        return heff_tag_at_n(v_ru_24x1_241895_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_nf(v_ru_24v_241896_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_241903)})});
      } else {
        if (heff_intEq_c(v_a_241871, MK_INT(32LL))) {
          double v_t_241904 = ({ V a_0 = MK_INT(32LL); V a_1 = v_t_241902; double r_ = (g_heff_2ecompile_2einterp_2edecimalTextV_w(a_0, a_1)); heff_drop(v_t_241902); r_; });
          return heff_tag_at_n(v_ru_24x1_241895_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_nf(v_ru_24v_241896_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_241904)})});
        } else {
          heff_drop_cell(v_ru_24x1_241895_24Ok, 1);
          heff_drop_cell(v_ru_24v_241896_24VInt, 1);
          heff_drop(v_t_241902);
          return NTAG(TAG_Abn);
        }
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241896, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241895_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241896, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241895_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241896, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241895_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241896, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241895_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241896, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241895_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241896, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241895_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241896, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241895_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241895_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241896);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241913 = heff_field(v_x1_241895, 0);
    V v_ru_24x1_241895_24Bug = heff_take_reuse_n(v_x1_241895, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241895_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241913});
  }
  default: return heff_nomatch(v_x1_241895);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam142(V self, V *args) {
  V v_d_241884 = args[0];
  V v_a_241885 = args[1];
  V v_a_241883 = heff_env(self)[0];
  V v_a_241871 = heff_env(self)[1];
  V v_x1_241886 = heff_tr(heff_call(v_a_241885, 1, (V[]){v_d_241884}));
  switch (heff_tag_of(v_x1_241886)) {
  case TAG_Ok: {
    V v_v_241887 = heff_field(v_x1_241886, 0);
    V v_ru_24x1_241886_24Ok = heff_take_reuse_n(v_x1_241886, 1ULL, 1);
    switch (heff_tag_of(v_v_241887)) {
    case TAG_VFun: {
      heff_take_n(v_v_241887, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241886_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241887, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241886_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241887, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241886_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241892 = heff_field(v_v_241887, 0);
      V v_ru_24v_241887_24VInt = heff_take_reuse_n(v_v_241887, 1ULL, 1);
      heff_clo_take(self, 2);
      return heff_tag_at_n(v_ru_24x1_241886_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241887_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam143, 2, 3, (V[]){v_a_241883, v_a_241892, v_a_241871})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241887, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241886_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241887, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241886_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241887, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241886_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241887, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241886_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241887, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241886_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241887, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241886_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241887, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241886_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241886_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241887);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241922 = heff_field(v_x1_241886, 0);
    V v_ru_24x1_241886_24Bug = heff_take_reuse_n(v_x1_241886, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241886_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241922});
  }
  default: return heff_nomatch(v_x1_241886);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam141(V self, V *args) {
  V v_d_241872 = args[0];
  V v_a_241873 = args[1];
  V v_a_241871 = heff_env(self)[0];
  V v_x1_241874 = heff_tr(heff_call(v_a_241873, 1, (V[]){v_d_241872}));
  switch (heff_tag_of(v_x1_241874)) {
  case TAG_Ok: {
    V v_v_241875 = heff_field(v_x1_241874, 0);
    V v_ru_24x1_241874_24Ok = heff_take_reuse_n(v_x1_241874, 1ULL, 1);
    switch (heff_tag_of(v_v_241875)) {
    case TAG_VFun: {
      heff_take_n(v_v_241875, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241874_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241875, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241874_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241875, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241874_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241875, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241874_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241875, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241874_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241875, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241874_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241883 = heff_field(v_v_241875, 0);
      V v_ru_24v_241875_24VStr = heff_take_reuse_n(v_v_241875, 1ULL, 1);
      heff_clo_take(self, 1);
      return heff_tag_at_n(v_ru_24x1_241874_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241875_24VStr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam142, 2, 2, (V[]){v_a_241883, v_a_241871})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241875, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241874_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241875, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241874_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241875, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241874_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241875, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241874_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241874_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241875);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241928 = heff_field(v_x1_241874, 0);
    V v_ru_24x1_241874_24Bug = heff_take_reuse_n(v_x1_241874, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241874_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241928});
  }
  default: return heff_nomatch(v_x1_241874);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam140(V self, V *args) {
  V v_d_241863 = args[0];
  V v_a_241864 = args[1];
  V v_x1_241865 = heff_tr(heff_call(v_a_241864, 1, (V[]){v_d_241863}));
  switch (heff_tag_of(v_x1_241865)) {
  case TAG_Ok: {
    V v_v_241866 = heff_field(v_x1_241865, 0);
    V v_ru_24x1_241865_24Ok = heff_take_reuse_n(v_x1_241865, 1ULL, 1);
    switch (heff_tag_of(v_v_241866)) {
    case TAG_VFun: {
      heff_take_n(v_v_241866, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241865_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241866, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241865_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241866, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241865_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241871 = heff_field(v_v_241866, 0);
      V v_ru_24v_241866_24VInt = heff_take_reuse_n(v_v_241866, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241865_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241866_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam141, 2, 1, (V[]){v_a_241871})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241866, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241865_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241866, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241865_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241866, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241865_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241866, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241865_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241866, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241865_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241866, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241865_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241866, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241865_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241865_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241866);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241937 = heff_field(v_x1_241865, 0);
    V v_ru_24x1_241865_24Bug = heff_take_reuse_n(v_x1_241865, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241865_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241937});
  }
  default: return heff_nomatch(v_x1_241865);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam144(V self, V *args) {
  V v_d_241938 = args[0];
  V v_a_241939 = args[1];
  V v_x1_241940 = heff_tr(heff_call(v_a_241939, 1, (V[]){v_d_241938}));
  switch (heff_tag_of(v_x1_241940)) {
  case TAG_Ok: {
    V v_v_241941 = heff_field(v_x1_241940, 0);
    V v_ru_24x1_241940_24Ok = heff_take_reuse_n(v_x1_241940, 1ULL, 1);
    switch (heff_tag_of(v_v_241941)) {
    case TAG_VFun: {
      heff_take_n(v_v_241941, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241940_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241941, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241940_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241941, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241940_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241941, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241940_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241941, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241940_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241941, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241940_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241949 = heff_field(v_v_241941, 0);
      V v_ru_24v_241941_24VStr = heff_take_reuse_n(v_v_241941, 1ULL, 1);
      V v_t_241950 = ({ V a_0 = v_a_241949; V a_1 = MK_INT(0LL); V a_2 = heff_strLength_lent(v_a_241949, 0); V r_ = (g_heff_2ecompile_2einterp_2ehashFrom(a_0, a_1, a_2)); heff_drop(v_a_241949); r_; });
      V v_t_241951 = (g_heff_2ecompile_2einterp_2efmix64(v_t_241950));
      V v_t_241952 = heff_tag_at_n(v_ru_24v_241941_24VStr, TAG_VInt, 1, (V[]){heff_intDiv(v_t_241951, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_241940_24Ok, TAG_Ok, 1, (V[]){v_t_241952});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241941, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241940_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241941, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241940_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241941, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241940_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241941, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241940_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241940_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241941);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241958 = heff_field(v_x1_241940, 0);
    V v_ru_24x1_241940_24Bug = heff_take_reuse_n(v_x1_241940, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241940_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_241958});
  }
  default: return heff_nomatch(v_x1_241940);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam147(V self, V *args) {
  V v_d_241980 = args[0];
  V v_a_241981 = args[1];
  V v_a_241970 = heff_env(self)[0];
  V v_a_241979 = heff_env(self)[1];
  V v_x1_241982 = heff_tr(heff_call(v_a_241981, 1, (V[]){v_d_241980}));
  switch (heff_tag_of(v_x1_241982)) {
  case TAG_Ok: {
    V v_v_241983 = heff_field(v_x1_241982, 0);
    V v_ru_24x1_241982_24Ok = heff_take_reuse_n(v_x1_241982, 1ULL, 1);
    switch (heff_tag_of(v_v_241983)) {
    case TAG_VFun: {
      heff_take_n(v_v_241983, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241982_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241983, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241982_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241983, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241982_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241988 = heff_field(v_v_241983, 0);
      V v_ru_24v_241983_24VInt = heff_take_reuse_n(v_v_241983, 1ULL, 1);
      heff_clo_take(self, 2);
      V v_s_241989 = heff_strSlice(v_a_241970, v_a_241979, v_a_241988);
      V v_t_241990 = ({ V a_0 = v_s_241989; V a_1 = MK_INT(0LL); V a_2 = heff_strLength_lent(v_s_241989, 0); V r_ = (g_heff_2ecompile_2einterp_2ehashFrom(a_0, a_1, a_2)); heff_drop(v_s_241989); r_; });
      V v_t_241991 = (g_heff_2ecompile_2einterp_2efmix64(v_t_241990));
      V v_t_241992 = heff_tag_at_n(v_ru_24v_241983_24VInt, TAG_VInt, 1, (V[]){heff_intDiv(v_t_241991, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_241982_24Ok, TAG_Ok, 1, (V[]){v_t_241992});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241983, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241982_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241983, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241982_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241983, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241982_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241983, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241982_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241983, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241982_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241983, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241982_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241983, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241982_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241982_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241983);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_242001 = heff_field(v_x1_241982, 0);
    V v_ru_24x1_241982_24Bug = heff_take_reuse_n(v_x1_241982, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241982_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_242001});
  }
  default: return heff_nomatch(v_x1_241982);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam146(V self, V *args) {
  V v_d_241971 = args[0];
  V v_a_241972 = args[1];
  V v_a_241970 = heff_env(self)[0];
  V v_x1_241973 = heff_tr(heff_call(v_a_241972, 1, (V[]){v_d_241971}));
  switch (heff_tag_of(v_x1_241973)) {
  case TAG_Ok: {
    V v_v_241974 = heff_field(v_x1_241973, 0);
    V v_ru_24x1_241973_24Ok = heff_take_reuse_n(v_x1_241973, 1ULL, 1);
    switch (heff_tag_of(v_v_241974)) {
    case TAG_VFun: {
      heff_take_n(v_v_241974, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241973_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241974, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241973_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241974, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241973_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241979 = heff_field(v_v_241974, 0);
      V v_ru_24v_241974_24VInt = heff_take_reuse_n(v_v_241974, 1ULL, 1);
      heff_clo_take(self, 1);
      return heff_tag_at_n(v_ru_24x1_241973_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241974_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam147, 2, 2, (V[]){v_a_241970, v_a_241979})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241974, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241973_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241974, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241973_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241974, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241973_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241974, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241973_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241974, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241973_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241974, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241973_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241974, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241973_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_241973_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241974);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_242010 = heff_field(v_x1_241973, 0);
    V v_ru_24x1_241973_24Bug = heff_take_reuse_n(v_x1_241973, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_241973_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_242010});
  }
  default: return heff_nomatch(v_x1_241973);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam145(V self, V *args) {
  V v_d_241959 = args[0];
  V v_a_241960 = args[1];
  V v_x1_241961 = heff_tr(heff_call(v_a_241960, 1, (V[]){v_d_241959}));
  switch (heff_tag_of(v_x1_241961)) {
  case TAG_Ok: {
    V v_v_241962 = heff_field(v_x1_241961, 0);
    V v_ru_24x1_241961_24Ok = heff_take_reuse_n(v_x1_241961, 1ULL, 1);
    switch (heff_tag_of(v_v_241962)) {
    case TAG_VFun: {
      heff_take_n(v_v_241962, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241961_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241962, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241961_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241962, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241961_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241962, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241961_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241962, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241961_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241962, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241961_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241970 = heff_field(v_v_241962, 0);
      V v_ru_24v_241962_24VStr = heff_take_reuse_n(v_v_241962, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241961_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241962_24VStr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam146, 2, 1, (V[]){v_a_241970})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241962, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241961_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241962, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241961_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241962, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241961_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241962, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241961_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241961_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241962);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_242016 = heff_field(v_x1_241961, 0);
    V v_ru_24x1_241961_24Bug = heff_take_reuse_n(v_x1_241961, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_241961_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_242016});
  }
  default: return heff_nomatch(v_x1_241961);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam150(V self, V *args) {
  V v_d_242028 = args[0];
  V v_a_242029 = args[1];
  V v_t_242017 = heff_env(self)[0];
  V v_a_242018 = heff_env(self)[1];
  V v_a_242027 = heff_env(self)[2];
  V v_x1_242030 = heff_tr(heff_call(v_a_242029, 1, (V[]){v_d_242028}));
  switch (heff_tag_of(v_x1_242030)) {
  case TAG_Ok: {
    V v_v_242031 = heff_field(v_x1_242030, 0);
    V v_ru_24x1_242030_24Ok = heff_take_reuse_n(v_x1_242030, 1ULL, 1);
    switch (heff_tag_of(v_v_242031)) {
    case TAG_VFun: {
      heff_take_n(v_v_242031, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_242031, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_242031, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_242036 = heff_field(v_v_242031, 0);
      heff_take_n(v_v_242031, 1ULL, 1);
      V v_t_242037;
      heff_clo_take(self, 3);
      if (heff_strEq_c(v_t_242017, heff_strSlice(v_a_242018, v_a_242027, v_a_242036))) {
        v_t_242037 = ((V)&g_heff_2ecompile_2einterp_2eprim_str37);
      } else {
        v_t_242037 = ((V)&g_heff_2ecompile_2einterp_2eprim_str38);
      }
      V v_t_242038 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_242037, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_242030_24Ok, TAG_Ok, 1, (V[]){v_t_242038});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_242031, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_242031, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_242031, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_242031, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_242031, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_242031, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_242031, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_242031);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_242047 = heff_field(v_x1_242030, 0);
    V v_ru_24x1_242030_24Bug = heff_take_reuse_n(v_x1_242030, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_242030_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_242047});
  }
  default: return heff_nomatch(v_x1_242030);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam149(V self, V *args) {
  V v_d_242019 = args[0];
  V v_a_242020 = args[1];
  V v_t_242017 = heff_env(self)[0];
  V v_a_242018 = heff_env(self)[1];
  V v_x1_242021 = heff_tr(heff_call(v_a_242020, 1, (V[]){v_d_242019}));
  switch (heff_tag_of(v_x1_242021)) {
  case TAG_Ok: {
    V v_v_242022 = heff_field(v_x1_242021, 0);
    V v_ru_24x1_242021_24Ok = heff_take_reuse_n(v_x1_242021, 1ULL, 1);
    switch (heff_tag_of(v_v_242022)) {
    case TAG_VFun: {
      heff_take_n(v_v_242022, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_242022, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_242022, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_242027 = heff_field(v_v_242022, 0);
      V v_ru_24v_242022_24VInt = heff_take_reuse_n(v_v_242022, 1ULL, 1);
      heff_clo_take(self, 2);
      return heff_tag_at_n(v_ru_24x1_242021_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_242022_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam150, 2, 3, (V[]){v_t_242017, v_a_242018, v_a_242027})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_242022, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_242022, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_242022, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_242022, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_242022, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_242022, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_242022, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_242022);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_242056 = heff_field(v_x1_242021, 0);
    V v_ru_24x1_242021_24Bug = heff_take_reuse_n(v_x1_242021, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_242021_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_242056});
  }
  default: return heff_nomatch(v_x1_242021);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam148(V self, V *args) {
  V v_t_242017 = args[0];
  V v_a_242018 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam149, 2, 2, (V[]){v_t_242017, v_a_242018})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam151(V self, V *args) {
  V v_d_242057 = args[0];
  V v_a_242058 = args[1];
  V v_x1_242059 = heff_tr(heff_call(v_a_242058, 1, (V[]){v_d_242057}));
  switch (heff_tag_of(v_x1_242059)) {
  case TAG_Ok: {
    V v_v_242060 = heff_field(v_x1_242059, 0);
    V v_ru_24x1_242059_24Ok = heff_take_reuse_n(v_x1_242059, 1ULL, 1);
    switch (heff_tag_of(v_v_242060)) {
    case TAG_VFun: {
      heff_take_n(v_v_242060, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242059_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_242060, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242059_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_242060, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242059_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_242065 = heff_field(v_v_242060, 0);
      V v_ru_24v_242060_24VInt = heff_take_reuse_n(v_v_242060, 1ULL, 1);
      V v_t_242066 = heff_intAdd(heff_intMod(v_a_242065, heff_dup(g_heff_2ecompile_2einterp_2eword64_get())), heff_dup(g_heff_2ecompile_2einterp_2eword64_get()));
      V v_t_242067 = (g_heff_2ecompile_2einterp_2efmix64(heff_intMod(v_t_242066, heff_dup(g_heff_2ecompile_2einterp_2eword64_get()))));
      V v_t_242068 = heff_tag_at_n(v_ru_24v_242060_24VInt, TAG_VInt, 1, (V[]){heff_intDiv(v_t_242067, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_242059_24Ok, TAG_Ok, 1, (V[]){v_t_242068});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_242060, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242059_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_242060, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242059_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_242060, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242059_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_242060, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242059_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_242060, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242059_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_242060, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242059_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_242060, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242059_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_242059_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_242060);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_242077 = heff_field(v_x1_242059, 0);
    V v_ru_24x1_242059_24Bug = heff_take_reuse_n(v_x1_242059, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_242059_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_242077});
  }
  default: return heff_nomatch(v_x1_242059);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam154(V self, V *args) {
  V v_d_242096 = args[0];
  V v_a_242097 = args[1];
  V v_a_242086 = heff_env(self)[0];
  V v_a_242095 = heff_env(self)[1];
  V v_x1_242098 = heff_tr(heff_call(v_a_242097, 1, (V[]){v_d_242096}));
  switch (heff_tag_of(v_x1_242098)) {
  case TAG_Ok: {
    V v_v_242099 = heff_field(v_x1_242098, 0);
    V v_ru_24x1_242098_24Ok = heff_take_reuse_n(v_x1_242098, 1ULL, 1);
    switch (heff_tag_of(v_v_242099)) {
    case TAG_VFun: {
      heff_take_n(v_v_242099, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242098_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_242099, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242098_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_242099, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242098_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_242104 = heff_field(v_v_242099, 0);
      V v_ru_24v_242099_24VInt = heff_take_reuse_n(v_v_242099, 1ULL, 1);
      heff_clo_take(self, 2);
      V v_bm_242105 = v_a_242086;
      V v_h_242106 = v_a_242095;
      V v_s_242107 = v_a_242104;
      V v_t_242108 = (g_heff_2eelab_2efixed_2etwoTo(heff_dup(v_s_242107)));
      V v_t_242109 = heff_intMod(heff_intDiv_lent(v_h_242106, v_t_242108, 2), MK_INT(32LL));
      V v_t_242110 = (g_heff_2eelab_2efixed_2etwoTo(v_t_242109));
      V v_t_242111 = heff_intMod(heff_intDiv_lent(v_bm_242105, v_t_242110, 2), MK_INT(2LL));
      V v_t_242119;
      if ((heff_unbox_word(v_t_242111) == ((int64_t)1ULL))) {
        V v_t_242112 = (g_heff_2eelab_2efixed_2etwoTo(v_s_242107));
        V v_t_242113 = heff_intMod(heff_intDiv(v_h_242106, v_t_242112), MK_INT(32LL));
        V v_t_242114 = (g_heff_2eelab_2efixed_2etwoTo(v_t_242113));
        v_t_242119 = (g_heff_2ecompile_2einterp_2ebitsSet(heff_intMod(v_bm_242105, v_t_242114)));
      } else {
        V v_t_242115 = (g_heff_2eelab_2efixed_2etwoTo(v_s_242107));
        V v_t_242116 = heff_intMod(heff_intDiv(v_h_242106, v_t_242115), MK_INT(32LL));
        V v_t_242117 = (g_heff_2eelab_2efixed_2etwoTo(v_t_242116));
        V v_t_242118 = (g_heff_2ecompile_2einterp_2ebitsSet(heff_intMod(v_bm_242105, v_t_242117)));
        v_t_242119 = heff_intSub(MK_INT(-1LL), v_t_242118);
      }
      return heff_tag_at_n(v_ru_24x1_242098_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_242099_24VInt, TAG_VInt, 1, (V[]){v_t_242119})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_242099, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242098_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_242099, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242098_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_242099, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242098_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_242099, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242098_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_242099, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242098_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_242099, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242098_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_242099, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242098_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242098_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_242099);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_242128 = heff_field(v_x1_242098, 0);
    V v_ru_24x1_242098_24Bug = heff_take_reuse_n(v_x1_242098, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_242098_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_242128});
  }
  default: return heff_nomatch(v_x1_242098);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam153(V self, V *args) {
  V v_d_242087 = args[0];
  V v_a_242088 = args[1];
  V v_a_242086 = heff_env(self)[0];
  V v_x1_242089 = heff_tr(heff_call(v_a_242088, 1, (V[]){v_d_242087}));
  switch (heff_tag_of(v_x1_242089)) {
  case TAG_Ok: {
    V v_v_242090 = heff_field(v_x1_242089, 0);
    V v_ru_24x1_242089_24Ok = heff_take_reuse_n(v_x1_242089, 1ULL, 1);
    switch (heff_tag_of(v_v_242090)) {
    case TAG_VFun: {
      heff_take_n(v_v_242090, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_242090, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_242090, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_242095 = heff_field(v_v_242090, 0);
      V v_ru_24v_242090_24VInt = heff_take_reuse_n(v_v_242090, 1ULL, 1);
      heff_clo_take(self, 1);
      return heff_tag_at_n(v_ru_24x1_242089_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_242090_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam154, 2, 2, (V[]){v_a_242086, v_a_242095})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_242090, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_242090, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_242090, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_242090, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_242090, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_242090, 0ULL, 1);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_242090, 0ULL, 2);
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(self);
      heff_drop_cell(v_ru_24x1_242089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_242090);
    }
  }
  case TAG_Abn: {
    heff_drop(self);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(self);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_242137 = heff_field(v_x1_242089, 0);
    V v_ru_24x1_242089_24Bug = heff_take_reuse_n(v_x1_242089, 1ULL, 1);
    heff_drop(self);
    return heff_tag_re_n(v_ru_24x1_242089_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_242137});
  }
  default: return heff_nomatch(v_x1_242089);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam152(V self, V *args) {
  V v_d_242078 = args[0];
  V v_a_242079 = args[1];
  V v_x1_242080 = heff_tr(heff_call(v_a_242079, 1, (V[]){v_d_242078}));
  switch (heff_tag_of(v_x1_242080)) {
  case TAG_Ok: {
    V v_v_242081 = heff_field(v_x1_242080, 0);
    V v_ru_24x1_242080_24Ok = heff_take_reuse_n(v_x1_242080, 1ULL, 1);
    switch (heff_tag_of(v_v_242081)) {
    case TAG_VFun: {
      heff_take_n(v_v_242081, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242080_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_242081, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242080_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_242081, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242080_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_242086 = heff_field(v_v_242081, 0);
      V v_ru_24v_242081_24VInt = heff_take_reuse_n(v_v_242081, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_242080_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_242081_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam153, 2, 1, (V[]){v_a_242086})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_242081, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242080_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_242081, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242080_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_242081, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242080_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_242081, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242080_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_242081, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242080_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_242081, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242080_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_242081, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242080_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_242080_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_242081);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_242146 = heff_field(v_x1_242080, 0);
    V v_ru_24x1_242080_24Bug = heff_take_reuse_n(v_x1_242080, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x1_242080_24Bug, TAG_Bug, 1, 1ULL, (V[]){v_what_242146});
  }
  default: return heff_nomatch(v_x1_242080);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam155(V self, V *args) {
  V v_d_242149 = args[0];
  V v_a_242150 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_drop(v_d_242149);
  heff_drop(v_a_242150);
  heff_clo_take(self, 1);
  V v_t_242151 = ({ V a_0 = v_p_240; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_240); r_; });
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprim_str39), v_t_242151)});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str0, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str2, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str3, 2, "{ ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str4, 2, " }");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str5, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str6, 4, "Cons");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str10, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str16, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str17, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str18, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str20, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str21, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str22, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str23, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str24, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str25, 1, ")");
Clo g_heff_2ecompile_2einterp_2eshowValGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eshowValGo_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eshowValGo(V v_inArg_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VCons: {
    V v_fs_242 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_keys_243 = heff_take_field(v_fs_242, 0);
    V v_values_244 = heff_get_n(v_fs_242, 2, 3);
    V v_t_245 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_243), heff_arrayToList(v_values_244)));
    V v_x2_246 = (g_list_2emap_24s24324293x740715900(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str0), v_t_245));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str3), v_t_249), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str4));
  }
  case TAG_VTag: {
    V v_x_2410 = heff_field(v_v_241, 0);
    V v_vs_2411 = heff_field(v_v_241, 1);
    V v_ru_24v_241_24VTag = heff_take_reuse_n(v_v_241, 3ULL, 2);
    V v_t_2421;
    if (heff_strEq_c_lent(v_x_2410, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str5), 2)) {
      heff_drop_cell(v_ru_24v_241_24VTag, 2);
      switch (heff_tag_of(v_vs_2411)) {
      case TAG_Nil: {
        v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        v_t_2421 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_vs_2411);
      }
    } else {
      if (heff_strEq_c_lent(v_x_2410, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str6), 2)) {
        switch (heff_tag_of(v_vs_2411)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24v_241_24VTag, 2);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_x_2414 = heff_dup(heff_field(v_vs_2411, 0));
          V v_x122_2415 = heff_dup(heff_field(v_vs_2411, 1));
          switch (heff_tag_of(v_x122_2415)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24v_241_24VTag, 2);
            heff_drop(v_x_2414);
            v_t_2421 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Cons: {
            V v_rest_2416 = heff_field(v_x122_2415, 0);
            V v_x1222_2417 = heff_field(v_x122_2415, 1);
            heff_take_n(v_x122_2415, 3ULL, 2);
            switch (heff_tag_of(v_x1222_2417)) {
            case TAG_Nil: {
              V v_t_2418 = heff_tag_at_n(v_ru_24v_241_24VTag, TAG_Cons, 2, (V[]){v_x_2414, NTAG(TAG_Nil)});
              v_t_2421 = (g_heff_2ecompile_2einterp_2elistValsGo(v_rest_2416, v_t_2418));
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_x1222_2417, 0ULL, 2);
              heff_drop_cell(v_ru_24v_241_24VTag, 2);
              heff_drop(v_x_2414);
              heff_drop(v_rest_2416);
              v_t_2421 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_x1222_2417);
            }
            break;
          }
          default: heff_nomatch(v_x122_2415);
          }
          break;
        }
        default: heff_nomatch(v_vs_2411);
        }
      } else {
        heff_drop_cell(v_ru_24v_241_24VTag, 2);
        v_t_2421 = NTAG(TAG_Nothing);
      }
    }
    switch (heff_tag_of(v_t_2421)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_vs_2411)) {
      case TAG_Nil: {
        return v_x_2410;
      }
      case TAG_Cons: {
        if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
          V v_x2_2424 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str7), v_vs_2411));
          V v_t_2427;
          switch (heff_tag_of(v_x2_2424)) {
          case TAG_Nil: {
            v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str8);
            break;
          }
          case TAG_Cons: {
            V v_x_2425 = heff_field(v_x2_2424, 0);
            V v_xs_2426 = heff_field(v_x2_2424, 1);
            heff_take_n(v_x2_2424, 3ULL, 2);
            v_t_2427 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str9); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2424);
          }
          V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str10), v_x_2410), v_t_2427);
          return heff_strAppend(v_t_2428, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str11));
        } else {
          V v_x2_2429 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str12), v_vs_2411));
          V v_t_2432;
          switch (heff_tag_of(v_x2_2429)) {
          case TAG_Nil: {
            v_t_2432 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str13);
            break;
          }
          case TAG_Cons: {
            V v_x_2430 = heff_field(v_x2_2429, 0);
            V v_xs_2431 = heff_field(v_x2_2429, 1);
            heff_take_n(v_x2_2429, 3ULL, 2);
            v_t_2432 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str14); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2429);
          }
          return heff_strAppend(v_x_2410, v_t_2432);
        }
      }
      default: return heff_nomatch(v_vs_2411);
      }
    }
    case TAG_Just: {
      V v_items_2433 = heff_field(v_t_2421, 0);
      heff_take_n(v_t_2421, 1ULL, 1);
      heff_drop(v_x_2410);
      heff_drop(v_vs_2411);
      V v_x2_2434 = (g_list_2emap_24s391931963x434308123(v_items_2433));
      V v_t_2437;
      switch (heff_tag_of(v_x2_2434)) {
      case TAG_Nil: {
        v_t_2437 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str15);
        break;
      }
      case TAG_Cons: {
        V v_x_2435 = heff_field(v_x2_2434, 0);
        V v_xs_2436 = heff_field(v_x2_2434, 1);
        heff_take_n(v_x2_2434, 3ULL, 2);
        v_t_2437 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str16); V a_1 = v_x_2435; V a_2 = v_xs_2436; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2436); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2434);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str17), v_t_2437), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str18));
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  case TAG_VArr: {
    V v_xs_2438 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_x2_2439 = (g_list_2emap_24s391931963x434308123(heff_arrayToList(v_xs_2438)));
    V v_t_2442;
    switch (heff_tag_of(v_x2_2439)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_x2_2439, 0);
      V v_xs_2441 = heff_field(v_x2_2439, 1);
      heff_take_n(v_x2_2439, 3ULL, 2);
      v_t_2442 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str20); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2439);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str21), v_t_2442), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str22));
  }
  default: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2443 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2443, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str23))) {
        V v_t_2444 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop(v_v_241); r_; });
        return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str24), v_t_2444), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str25));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop(v_v_241); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop(v_v_241); r_; });
    }
  }
  }
}
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2eshowValGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_lam0, 1, 0};
Clo g_heff_2ecompile_2einterp_2eapplyErased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eapplyErased(V v_n_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_r_241)) {
  case TAG_RSucceeded: {
    V v_r1_242 = heff_dup(heff_field(v_r_241, 0));
    switch (heff_tag_of(v_r1_242)) {
    case TAG_VFun: {
      V v_f_243 = heff_field(v_r1_242, 0);
      V v_ru_24r1_242_24VFun = heff_take_reuse_n(v_r1_242, 1ULL, 1);
      switch (heff_tag_of(v_r_241)) {
      case TAG_RSucceeded: {
        V v_ru_24r_241_24RSucceeded = heff_take_reuse_n(v_r_241, 0ULL, 1);
        if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
          heff_drop(v_n_240);
          return heff_tag_at_n(v_ru_24r_241_24RSucceeded, TAG_RSucceeded, 1, (V[]){heff_tag_re_n(v_ru_24r1_242_24VFun, TAG_VFun, 1, 1ULL, (V[]){v_f_243})});
        } else {
          heff_drop_cell(v_ru_24r1_242_24VFun, 1);
          V v_x1_246 = heff_tr(heff_call(v_f_243, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo)}));
          V v_t_249;
          switch (heff_tag_of(v_x1_246)) {
          case TAG_Ok: {
            V v_v_247 = heff_field(v_x1_246, 0);
            heff_take_n(v_x1_246, 1ULL, 1);
            v_t_249 = heff_tag_at_n(v_ru_24r_241_24RSucceeded, TAG_RSucceeded, 1, (V[]){v_v_247});
            break;
          }
          case TAG_Abn: {
            heff_drop_cell(v_ru_24r_241_24RSucceeded, 1);
            v_t_249 = NTAG(TAG_RAbandoned);
            break;
          }
          case TAG_Div: {
            heff_drop_cell(v_ru_24r_241_24RSucceeded, 1);
            v_t_249 = NTAG(TAG_RDiverged);
            break;
          }
          case TAG_Bug: {
            V v_what_248 = heff_field(v_x1_246, 0);
            V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
            heff_drop_cell(v_ru_24r_241_24RSucceeded, 1);
            v_t_249 = heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_RBug, 1, (V[]){v_what_248});
            break;
          }
          default: heff_nomatch(v_x1_246);
          }
          V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
          V t_1 = v_t_249;
          v_n_240 = t_0;
          v_r_241 = t_1;
          goto top;
        }
      }
      default: return heff_nomatch(v_r_241);
      }
    }
    case TAG_VCons: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VTag: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VInt: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat: {
      heff_take_na(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat32: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VStr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VRune: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VArr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBytes: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBits: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VErased: {
      heff_drop(v_n_240);
      return v_r_241;
    }
    default: return heff_nomatch(v_r1_242);
    }
  }
  case TAG_RAbandoned: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RDiverged: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RBug: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  default: return heff_nomatch(v_r_241);
  }
}
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eapplyErased(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args) {
  V v_d_245 = args[0];
  heff_drop(v_d_245);
  return heff_tag_n(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
}
Clo g_heff_2ecompile_2einterp_2ereachGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ereachGlobals_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ereachGlobals(V v_gs_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_gs_240, 8);
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_seen_241, v_k_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_k_243);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        V t_0 = v_gs_240;
        V t_1 = v_seen_241;
        V t_2 = v_rest_244;
        v_gs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_seen_241, heff_dup(v_k_243), NTAG(TAG_MkUnit)));
        HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_gs_240, 1), v_k_243));
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          V v_t_2424;
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            heff_drop(v_k_243);
            V v_e_2413 = v_field_2412;
            V v_t_2414 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_get_n(v_e_2413, 0, 4)));
            v_t_2424 = (g_heff_2eelab_2erename_2enubFirst(v_t_2414));
          } else {
            heff_drop(v_field_2412);
            HeffT2 v_t_2415 = ({ V a_0 = heff_rfield(v_gs_240, 2); V a_1 = v_k_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_k_243); r_; });
            {
              V v_field_2417 = v_t_2415.f[1];
              int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
              if ((v_tag_2416 == ((int64_t)0ULL))) {
                V v_k2_2418 = v_field_2417;
                HeffT2 v_t_2419 = ({ V a_0 = heff_rfield(v_gs_240, 1); V a_1 = v_k2_2418; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_k2_2418); r_; });
                {
                  V v_field_2421 = v_t_2419.f[1];
                  int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                  if ((v_tag_2420 == ((int64_t)0ULL))) {
                    V v_entry_2422 = v_field_2421;
                    V v_t_2423 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_get_n(v_entry_2422, 0, 4)));
                    v_t_2424 = (g_heff_2eelab_2erename_2enubFirst(v_t_2423));
                  } else {
                    heff_drop(v_field_2421);
                    v_t_2424 = NTAG(TAG_Nil);
                  }
                }
              } else {
                heff_drop(v_field_2417);
                v_t_2424 = NTAG(TAG_Nil);
              }
            }
          }
          V v_t_2425 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_242_24Cons, v_t_2424, v_rest_244));
          V t_0 = v_gs_240;
          V t_1 = v_t_249;
          V t_2 = v_t_2425;
          v_gs_240 = t_0;
          v_seen_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2einterp_2ereachGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ereachGlobals(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2eintAtV_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eintAtV_24tok1_entry, 6, 0};

V g_heff_2ecompile_2einterp_2eintAtV_24tok1(V v_tok_240, V v_s_241, V v_limit_242, V v_o_243, V v_n_244, V v_f_245) {
top: ;
  if ((heff_intLt_c_lent(v_o_243, MK_INT(0LL), 2) || (heff_intLt_c_lent(v_n_244, MK_INT(0LL), 2) || (heff_intLt_c_lent(MK_INT(64LL), v_n_244, 1) || heff_intLt_c_lent(v_limit_242, heff_intAdd_lent(v_o_243, v_n_244, 0), 2))))) {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_limit_242);
    heff_drop(v_o_243);
    heff_drop(v_n_244);
    heff_drop(v_f_245);
    return NTAG(TAG_Abn);
  } else {
    heff_drop(v_limit_242);
    if ((heff_unbox_word(heff_intMod_lent(v_f_245, MK_INT(2LL), 2)) == ((int64_t)1ULL))) {
      V v_w_246 = (g_heff_2ecompile_2einterp_2ebitsRead(v_s_241, v_o_243, heff_dup(v_n_244), MK_INT(0LL)));
      V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intMod_lent(v_n_244, MK_INT(8LL), 2)));
      V v_t_248 = heff_intMul(MK_INT(8LL), heff_intDiv_lent(v_n_244, MK_INT(8LL), 2));
      V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(v_t_248));
      V v_t_2410 = heff_intMul(heff_intMod_lent(v_w_246, v_t_247, 2), v_t_249);
      V v_u_2411 = (g_heff_2ecompile_2einterp_2elittleInGo(v_w_246, heff_dup(v_n_244), heff_intDiv_lent(v_n_244, MK_INT(8LL), 2), MK_INT(0LL), v_t_2410));
      V v_t_2412 = heff_intMod(heff_intDiv(v_f_245, MK_INT(2LL)), MK_INT(2LL));
      V v_t_2415;
      if ((heff_unbox_word(v_t_2412) == ((int64_t)1ULL))) {
        if (heff_intLt_c_lent(MK_INT(0LL), v_n_244, 1)) {
          V v_y_2413 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intSub_lent(v_n_244, MK_INT(1LL), 2)));
          if (heff_intLe_c_lent(v_y_2413, v_u_2411, 1)) {
            V v_t_2414 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_244));
            v_t_2415 = heff_intSub(v_u_2411, v_t_2414);
          } else {
            heff_drop(v_n_244);
            v_t_2415 = v_u_2411;
          }
        } else {
          heff_drop(v_n_244);
          v_t_2415 = v_u_2411;
        }
      } else {
        heff_drop(v_n_244);
        v_t_2415 = v_u_2411;
      }
      return heff_tag_at_n(v_tok_240, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2415})});
    } else {
      V v_u_2416 = (g_heff_2ecompile_2einterp_2ebitsRead(v_s_241, v_o_243, heff_dup(v_n_244), MK_INT(0LL)));
      V v_t_2417 = heff_intMod(heff_intDiv(v_f_245, MK_INT(2LL)), MK_INT(2LL));
      V v_t_2420;
      if ((heff_unbox_word(v_t_2417) == ((int64_t)1ULL))) {
        if (heff_intLt_c_lent(MK_INT(0LL), v_n_244, 1)) {
          V v_y_2418 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intSub_lent(v_n_244, MK_INT(1LL), 2)));
          if (heff_intLe_c_lent(v_y_2418, v_u_2416, 1)) {
            V v_t_2419 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_244));
            v_t_2420 = heff_intSub(v_u_2416, v_t_2419);
          } else {
            heff_drop(v_n_244);
            v_t_2420 = v_u_2416;
          }
        } else {
          heff_drop(v_n_244);
          v_t_2420 = v_u_2416;
        }
      } else {
        heff_drop(v_n_244);
        v_t_2420 = v_u_2416;
      }
      return heff_tag_at_n(v_tok_240, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2420})});
    }
  }
}
V g_heff_2ecompile_2einterp_2eintAtV_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2einterp_2eintAtV_24tok1(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}