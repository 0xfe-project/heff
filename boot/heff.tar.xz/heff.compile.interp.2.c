// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_Ok 9325
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_aliases 1464806715
#define LBL_entries 787768015
#define LBL_keys 9783995
#define LBL_syntax 1059664654
#define LBL_values 1123329101
V g_heff_2ecompile_2einterp_2eapplyErased(V, V);
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eapplyErased_clo;
V g_heff_2ecompile_2einterp_2ebits1(V);
V g_heff_2ecompile_2einterp_2ebits1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebits1_clo;
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void);
V g_heff_2ecompile_2einterp_2ebitsCopy(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsCopy_clo;
V g_heff_2ecompile_2einterp_2ebitsJoined(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsJoined_clo;
V g_heff_2ecompile_2einterp_2ebitsOfIntV(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsOfIntV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsOfIntV_clo;
V g_heff_2ecompile_2einterp_2ebyteString(V, V);
V g_heff_2ecompile_2einterp_2ebyteString_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebyteString_clo;
V g_heff_2ecompile_2einterp_2ebytes2(V);
V g_heff_2ecompile_2einterp_2ebytes2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytes2_clo;
V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get(void);
V g_heff_2ecompile_2einterp_2ebytesJoined(V, V);
V g_heff_2ecompile_2einterp_2ebytesJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesJoined_clo;
V g_heff_2ecompile_2einterp_2ebytesOfIntV(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfIntV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfIntV_clo;
V g_heff_2ecompile_2einterp_2ebytesOfNat(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfNat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfNat_clo;
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void);
V g_heff_2ecompile_2einterp_2efixedPrimV(V);
V g_heff_2ecompile_2einterp_2efixedPrimV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedPrimV_clo;
V g_heff_2ecompile_2einterp_2efloat2(V);
V g_heff_2ecompile_2einterp_2efloat2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloat2_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get(void);
V g_heff_2ecompile_2einterp_2efloatOfBitsV(V, V);
V g_heff_2ecompile_2einterp_2efloatOfBitsV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloatOfBitsV_clo;
V g_heff_2ecompile_2einterp_2efloatTake2(V, V, V);
V g_heff_2ecompile_2einterp_2efloatTake2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloatTake2_clo;
V g_heff_2ecompile_2einterp_2efmix64(V);
V g_heff_2ecompile_2einterp_2efmix64_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efmix64_clo;
V g_heff_2ecompile_2einterp_2efromListV(V, V);
V g_heff_2ecompile_2einterp_2efromListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efromListV_clo;
V g_heff_2ecompile_2einterp_2egenGo(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2egenGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2egenGo_clo;
V g_heff_2ecompile_2einterp_2ehashFrom(V, V, V);
V g_heff_2ecompile_2einterp_2ehashFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ehashFrom_clo;
V g_heff_2ecompile_2einterp_2eieeeBits_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeBits(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeBits_clo;
V g_heff_2ecompile_2einterp_2eieeeMagnitude_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeMagnitude(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeMagnitude_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeMagnitude_clo;
double g_heff_2ecompile_2einterp_2eieeeOf_w(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeOf_clo;
V g_heff_2ecompile_2einterp_2eint2(V);
V g_heff_2ecompile_2einterp_2eint2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eint2_clo;
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void);
V g_heff_2ecompile_2einterp_2eintAtV(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintAtV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintAtV_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_clo;
HeffT2 g_heff_2ecompile_2einterp_2elistValsGo_24cpr(V, V);
V g_heff_2ecompile_2einterp_2elittleOut(V, V);
V g_heff_2ecompile_2einterp_2elittleOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elittleOut_clo;
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotARune_get(void);
V g_heff_2ecompile_2einterp_2enotAString_get(void);
V g_heff_2ecompile_2einterp_2enotAnArray_get(void);
V g_heff_2ecompile_2einterp_2enotAnInt_get(void);
V g_heff_2ecompile_2einterp_2enotBytes_get(void);
HeffT2 g_heff_2ecompile_2einterp_2enthV_24cpr(V, V);
V g_heff_2ecompile_2einterp_2eprim(V);
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eprim_clo;
V g_heff_2ecompile_2einterp_2ereachGlobals(V, V, V);
V g_heff_2ecompile_2einterp_2ereachGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ereachGlobals_clo;
V g_heff_2ecompile_2einterp_2erune2(V);
V g_heff_2ecompile_2einterp_2erune2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2erune2_clo;
V g_heff_2ecompile_2einterp_2eruneCodes(V);
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_clo;
V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V, V);
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo;
V g_heff_2ecompile_2einterp_2escalarV(V);
V g_heff_2ecompile_2einterp_2escalarV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2escalarV_clo;
V g_heff_2ecompile_2einterp_2esetAt(V, V, V);
V g_heff_2ecompile_2einterp_2esetAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esetAt_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2einterp_2esliceV(V, V, V);
V g_heff_2ecompile_2einterp_2esliceV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esliceV_clo;
V g_heff_2ecompile_2einterp_2estr2(V);
V g_heff_2ecompile_2einterp_2estr2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2estr2_clo;
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get(void);
V g_heff_2ecompile_2einterp_2etoListV(V);
V g_heff_2ecompile_2einterp_2etoListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(V, V, V);
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(V);
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_clo;
V g_heff_2ecompile_2einterp_2etrieSlotOf(V, V, V);
V g_heff_2ecompile_2einterp_2etrieSlotOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etrieSlotOf_clo;
V g_heff_2ecompile_2einterp_2etwoTo(V);
V g_heff_2ecompile_2einterp_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoTo_clo;
V g_heff_2ecompile_2einterp_2eword64_get(void);
V g_heff_2ecompile_2einterp_2ewordOf(V, V, V);
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ewordOf_clo;
HeffT2 g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(V);
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2erename_2enubFirst(V);
V g_heff_2eelab_2erename_2enubFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2enubFirst_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1427000880x1925304966(V, V);
V g_list_2emap_24s1427000880x1925304966_entry(V self, V *a);
extern Clo g_list_2emap_24s1427000880x1925304966_clo;
V g_list_2emap_24s391931963x434308123(V);
V g_list_2emap_24s391931963x434308123_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_clo;
V g_list_2emap_24s503834852x510769098(V, V);
V g_list_2emap_24s503834852x510769098_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_rune_2evalidFrom(V, V);
V g_rune_2evalidFrom_entry(V self, V *a);
extern Clo g_rune_2evalidFrom_clo;
V g_runeFromInt_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAnInt_str0, 38, "a primitive given what is not an `Int`");

static V g_heff_2ecompile_2einterp_2enotAnInt_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAnInt_st;
static V g_heff_2ecompile_2einterp_2enotAnInt_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAnInt_str0)});
}
V g_heff_2ecompile_2einterp_2enotAnInt_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAnInt_st)) return g_heff_2ecompile_2einterp_2enotAnInt_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAnInt_val, &g_heff_2ecompile_2einterp_2enotAnInt_st, g_heff_2ecompile_2einterp_2enotAnInt_init);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAFloat64_str0, 41, "a primitive given what is not a `Float64`");

static V g_heff_2ecompile_2einterp_2enotAFloat64_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAFloat64_st;
static V g_heff_2ecompile_2einterp_2enotAFloat64_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAFloat64_str0)});
}
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAFloat64_st)) return g_heff_2ecompile_2einterp_2enotAFloat64_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAFloat64_val, &g_heff_2ecompile_2einterp_2enotAFloat64_st, g_heff_2ecompile_2einterp_2enotAFloat64_init);
}
Clo g_heff_2ecompile_2einterp_2efloatTake2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloatTake2_entry, 3, 0};

V g_heff_2ecompile_2einterp_2efloatTake2(V v_f_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_VFun: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VCons: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VTag: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VInt: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VFloat: {
    V v_a_248 = heff_tget_v(v_x2_241, 0);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_VFun: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      V v_b_2414 = heff_tget_v(v_x3_242, 0);
      return heff_tail(v_f_240, 2, (V[]){v_a_248, v_b_2414});
    }
    case TAG_VFloat32: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_VFloat32: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VStr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VRune: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VArr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VBytes: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VBits: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VErased: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2efloatTake2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2einterp_2efloatTake2(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2einterp_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ewordOf_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ewordOf(V v_n_240, V v_f_241, V v_v_242) {
top: ;
  if ((heff_unbox_word(heff_intMod(v_f_241, MK_INT(2LL))) == ((int64_t)1ULL))) {
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_245 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_246 = heff_intAdd(heff_intMod(v_v_242, v_t_244), v_t_245);
    V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    return (g_heff_2ecompile_2einterp_2elittleOut(heff_intMod(v_t_246, v_t_247), v_n_240));
  } else {
    V v_t_248 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_2410 = heff_intAdd(heff_intMod(v_v_242, v_t_248), v_t_249);
    V v_t_2411 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_240));
    return heff_intMod(v_t_2410, v_t_2411);
  }
}
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ewordOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsOfIntV_str0, 0, "");
Clo g_heff_2ecompile_2einterp_2ebitsOfIntV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsOfIntV_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ebitsOfIntV(V v_n_240, V v_f_241, V v_v_242) {
top: ;
  if (heff_intLt_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_f_241);
    heff_drop(v_v_242);
    return NTAG(TAG_Abn);
  } else {
    if (heff_intLt_c_lent(MK_INT(64LL), v_n_240, 1)) {
      heff_drop(v_n_240);
      heff_drop(v_f_241);
      heff_drop(v_v_242);
      return NTAG(TAG_Abn);
    } else {
      V v_w_245 = (g_heff_2ecompile_2einterp_2ewordOf(heff_dup(v_n_240), v_f_241, v_v_242));
      int64_t v_t_246 = ((heff_peek_word(v_n_240) + ((int64_t)7ULL)) / ((int64_t)8ULL));
      int64_t v_t_247 = ((heff_peek_word(v_n_240) + ((int64_t)7ULL)) / ((int64_t)8ULL));
      int64_t v_t_248 = ((v_t_247 * ((int64_t)8ULL)) - heff_peek_word(v_n_240));
      V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word(v_t_248)));
      V v_t_2410 = (g_heff_2ecompile_2einterp_2ebytesOfNat(heff_box_word(v_t_246), heff_intMul(v_w_245, v_t_249), ((V)&g_heff_2ecompile_2einterp_2ebitsOfIntV_str0)));
      return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_n_240, v_t_2410})});
    }
  }
}
V g_heff_2ecompile_2einterp_2ebitsOfIntV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitsOfIntV(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2eieeeBits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eieeeBits_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eieeeBits_w(V v_eb_240, V v_fb_241, double v_x_242) {
top: ;
  V v_t_244 = heff_bool(!(v_x_242 == v_x_242));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = (g_heff_2ecompile_2einterp_2etwoTo(v_eb_240));
    V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_fb_241)));
    V v_t_247 = heff_intMul(heff_intSub(v_t_245, MK_INT(1LL)), v_t_246);
    V v_t_248 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_unbox_word(v_fb_241) - ((int64_t)1ULL)))));
    return heff_intAdd(v_t_247, v_t_248);
  } else {
    heff_drop(v_t_244);
    if ((v_x_242 < (0.0))) {
      V v_t_2410 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_eb_240) + heff_peek_word(v_fb_241)))));
      V v_t_2411 = (g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, ((0.0) - v_x_242)));
      return heff_intAdd(v_t_2410, v_t_2411);
    } else {
      if ((v_x_242 == (0.0))) {
        if ((((1.0) / v_x_242) < (0.0))) {
          V v_t_2414 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_eb_240) + heff_peek_word(v_fb_241)))));
          V v_t_2415 = (g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, ((0.0) - v_x_242)));
          return heff_intAdd(v_t_2414, v_t_2415);
        } else {
          HEFF_LAST return g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, v_x_242);
        }
      } else {
        HEFF_LAST return g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, v_x_242);
      }
    }
  }
}
V g_heff_2ecompile_2einterp_2eieeeBits(V v_eb_240, V v_fb_241, V v_box_24x_242) {
  double v_x_242 = heff_unbox_f64(v_box_24x_242);
  return (g_heff_2ecompile_2einterp_2eieeeBits_w(v_eb_240, v_fb_241, v_x_242));
}
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eieeeBits(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2efloatOfBitsV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloatOfBitsV_entry, 2, 0};

V g_heff_2ecompile_2einterp_2efloatOfBitsV(V v_n_240, V v_u_241) {
top: ;
  if (heff_intEq_c_lent(v_n_240, MK_INT(64LL), 2)) {
    heff_drop(v_n_240);
    V v_t_243 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    V v_t_245 = heff_intAdd(heff_intMod(v_u_241, v_t_243), v_t_244);
    V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    double v_t_247 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(11LL), MK_INT(52LL), heff_intMod(v_t_245, v_t_246)));
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_nf(TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_247)})});
  } else {
    if (heff_intEq_c(v_n_240, MK_INT(32LL))) {
      V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      V v_t_2410 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      V v_t_2411 = heff_intAdd(heff_intMod(v_u_241, v_t_249), v_t_2410);
      V v_t_2412 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      double v_t_2413 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(8LL), MK_INT(23LL), heff_intMod(v_t_2411, v_t_2412)));
      return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_nf(TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_2413)})});
    } else {
      heff_drop(v_u_241);
      return NTAG(TAG_Abn);
    }
  }
}
V g_heff_2ecompile_2einterp_2efloatOfBitsV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efloatOfBitsV(a[0], a[1]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eruneCodes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_VFun: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2411 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2411, heff_hole()});
      V v_u_2413 = (g_heff_2ecompile_2einterp_2eruneCodes_24dps(v_rest_242, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eruneCodes(a[0]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_VFun: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2412 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2412, heff_hole()});
      V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2413;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eruneCodes_24dps(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st;
static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st)) return g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val, &g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)(heff_unbox_f32(v_a_2414) / heff_unbox_f32(v_b_2421))))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st;
static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st)) return g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
  return heff_global(&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val, &g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init);
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = (g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(v_a_2412, v_b_2417));
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2418})});
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1, 2, 1, (V[]){v_a_241})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10, 36, "a primitive given what is not `Bits`");
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st;
static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st)) return g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val, &g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init);
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  V v_x1_242 = heff_tr(heff_call(v_a_241, 1, (V[]){v_d_240}));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Ok: {
    V v_v_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Ok = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_v_243)) {
    case TAG_VFun: {
      V v_ru_24v_243_24VFun = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFun, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0)});
    }
    case TAG_VCons: {
      V v_ru_24v_243_24VCons = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VCons, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1)});
    }
    case TAG_VTag: {
      heff_take_n(v_v_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2)});
    }
    case TAG_VInt: {
      V v_ru_24v_243_24VInt = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3)});
    }
    case TAG_VFloat: {
      V v_ru_24v_243_24VFloat = heff_take_reuse_na(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4)});
    }
    case TAG_VFloat32: {
      V v_ru_24v_243_24VFloat32 = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat32, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5)});
    }
    case TAG_VStr: {
      V v_ru_24v_243_24VStr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VStr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6)});
    }
    case TAG_VRune: {
      V v_ru_24v_243_24VRune = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VRune, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7)});
    }
    case TAG_VArr: {
      V v_ru_24v_243_24VArr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VArr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8)});
    }
    case TAG_VBytes: {
      V v_ru_24v_243_24VBytes = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VBytes, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9)});
    }
    case TAG_VBits: {
      V v_n_2415 = heff_field(v_v_243, 0);
      heff_take_n(v_v_243, 1ULL, 2);
      return heff_tag_at_n(v_ru_24x1_242_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_n_2415})});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10)});
    }
    default: return heff_nomatch(v_v_243);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2417 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Bug = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_242_24Bug, TAG_Bug, 1, (V[]){v_what_2417});
  }
  default: return heff_nomatch(v_x1_242);
  }
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str1, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str2, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str3, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str4, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str5, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str6, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str7, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str8, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str9, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str10, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str11, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str12, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str13, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str14, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str15, 6, "intAnd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str16, 5, "intOr");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str17, 6, "intXor");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str18, 6, "intShl");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str19, 6, "intShr");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str20, 8, "floatAdd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str21, 8, "floatSub");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str22, 8, "floatMul");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str23, 8, "floatDiv");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str24, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str25, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str26, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str27, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str28, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str29, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str30, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str31, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str32, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str33, 9, "floatShow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str34, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str35, 9, "floatSqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str36, 10, "floatFloor");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str37, 8, "floatSin");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str38, 8, "floatCos");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str39, 8, "floatTan");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str40, 9, "floatAsin");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str41, 9, "floatAcos");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str42, 9, "floatAtan");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str43, 10, "floatAtan2");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str44, 8, "floatExp");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str45, 8, "floatLog");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str46, 8, "floatPow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str47, 11, "arrayLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str48, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str49, 32, "an index in range, of no element");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str50, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str51, 13, "arrayGenerate");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str52, 13, "arrayFromList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str53, 11, "arrayToList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str54, 14, "arrayReplicate");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str55, 10, "arraySlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str56, 11, "arrayAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str57, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str58, 9, "strLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str59, 8, "strSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str60, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str61, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str62, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str63, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str64, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str65, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str66, 10, "strCompare");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str67, 7, "strHash");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str68, 7, "intHash");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str69, 8, "trieSlot");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str70, 7, "strFind");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str71, 9, "strByteAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str72, 11, "strFromByte");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str73, 9, "strRuneAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str74, 12, "strRuneWidth");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str75, 12, "strRuneCount");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str76, 7, "strToJS");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str77, 9, "strFromJS");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str78, 11, "bytesLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str79, 7, "bytesAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str80, 10, "bytesSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str81, 11, "bytesAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str82, 11, "bytesConcat");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str83, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str84, 7, "bytesEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str85, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str86, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str87, 13, "bytesFromList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str88, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str89, 11, "bytesToList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str90, 15, "bytesFromString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str91, 13, "bytesAsString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str92, 13, "bytesToString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str93, 10, "bytesIntAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str94, 10, "bytesOfInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str95, 10, "bytesHasAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str96, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str97, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str98, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str99, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str100, 10, "bitsLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str101, 9, "bitsIntAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str102, 9, "bitsOfInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str103, 10, "bitsConcat");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str104, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str105, 9, "bitsSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str106, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str107, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str108, 9, "bitsBytes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str109, 6, "bitsEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str110, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str111, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str112, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str113, 9, "floatBits");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str114, 11, "floatOfBits");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str115, 6, "runeEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str116, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str117, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str118, 6, "runeLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str119, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str120, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str121, 6, "runeLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str122, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str123, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str124, 9, "runeToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str125, 4, "keep");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str126, 11, "runeFromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str127, 8, "strRunes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str128, 10, "strOfRunes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str129, 13, "no primitive ");
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam0, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam1, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam2, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam3, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam4, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam5, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam6, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam7, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam8, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam9, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam10, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam11, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam12, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam13, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam14, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam15, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam16, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam17, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam18, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam19, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam20, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam21, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam22, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam23, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam24, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam26, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam25, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam28, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam27, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam31, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam30, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam37_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam37, 1, 0};
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam35, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam34, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam39, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam38, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam41, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam40, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam43, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam42, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam46, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam45_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam45, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam50_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam50, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam49_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam49, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam52_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam52, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam53_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam53, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam56_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam56, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam57_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam57, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam58_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam58, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam59_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam59, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam60_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam60, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam61_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam61, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam64_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam64, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam66_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam66, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam68_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam68, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam69_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam69, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam71_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam71, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam73_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam73, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam74_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam74, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam75_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam75, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam76_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam76, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam77_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam77, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam79_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam79, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam82_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam82, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam83_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam83, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam84_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam84, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam85_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam85, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam86_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam86, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam87_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam87, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam88_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam88, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam89_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam89, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam93_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam93, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam96_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam96, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam99_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam99, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam103_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam103, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam106_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam106, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam107_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam107, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam110(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam110_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam110, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam111(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam111_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam111, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam113(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam112(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam112_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam112, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam115(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam114(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam114_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam114, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam117(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam116(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam116_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam116, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam118(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam118_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam118, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam119(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam119, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam120(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam120_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam120, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam121(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam121_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam121, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam123(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam123, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam122(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam122_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam122, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam124(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam124, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam125(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam125_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam125, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam126(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam126_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam126, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam127(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eprim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eprim(V v_p_240) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str0), 2)) {
    heff_drop(v_p_240);
    return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get());
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str1), 2)) {
      heff_drop(v_p_240);
      return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get());
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str2), 2)) {
        heff_drop(v_p_240);
        return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get());
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str3), 2)) {
          heff_drop(v_p_240);
          HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam0_clo));
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str4), 2)) {
            heff_drop(v_p_240);
            HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam1_clo));
          } else {
            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str5), 2)) {
              heff_drop(v_p_240);
              HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam2_clo));
            } else {
              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str8), 2)) {
                heff_drop(v_p_240);
                HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam3_clo));
              } else {
                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str11), 2)) {
                  heff_drop(v_p_240);
                  HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam4_clo));
                } else {
                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str14), 2)) {
                    heff_drop(v_p_240);
                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam5_clo)});
                  } else {
                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str15), 2)) {
                      heff_drop(v_p_240);
                      return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get());
                    } else {
                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str16), 2)) {
                        heff_drop(v_p_240);
                        HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam6_clo));
                      } else {
                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str17), 2)) {
                          heff_drop(v_p_240);
                          HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam7_clo));
                        } else {
                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str18), 2)) {
                            heff_drop(v_p_240);
                            HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam8_clo));
                          } else {
                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str19), 2)) {
                              heff_drop(v_p_240);
                              HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam9_clo));
                            } else {
                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str20), 2)) {
                                heff_drop(v_p_240);
                                return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get());
                              } else {
                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str21), 2)) {
                                  heff_drop(v_p_240);
                                  return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get());
                                } else {
                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str22), 2)) {
                                    heff_drop(v_p_240);
                                    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get());
                                  } else {
                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str23), 2)) {
                                      heff_drop(v_p_240);
                                      return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get());
                                    } else {
                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str24), 2)) {
                                        heff_drop(v_p_240);
                                        HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam10_clo));
                                      } else {
                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str27), 2)) {
                                          heff_drop(v_p_240);
                                          HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam11_clo));
                                        } else {
                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str30), 2)) {
                                            heff_drop(v_p_240);
                                            HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam12_clo));
                                          } else {
                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str33), 2)) {
                                              heff_drop(v_p_240);
                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam13_clo)});
                                            } else {
                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str34), 2)) {
                                                heff_drop(v_p_240);
                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam14_clo)});
                                              } else {
                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str35), 2)) {
                                                  heff_drop(v_p_240);
                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam15_clo)});
                                                } else {
                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str36), 2)) {
                                                    heff_drop(v_p_240);
                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam16_clo)});
                                                  } else {
                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str37), 2)) {
                                                      heff_drop(v_p_240);
                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam17_clo)});
                                                    } else {
                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str38), 2)) {
                                                        heff_drop(v_p_240);
                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam18_clo)});
                                                      } else {
                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str39), 2)) {
                                                          heff_drop(v_p_240);
                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam19_clo)});
                                                        } else {
                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str40), 2)) {
                                                            heff_drop(v_p_240);
                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam20_clo)});
                                                          } else {
                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str41), 2)) {
                                                              heff_drop(v_p_240);
                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam21_clo)});
                                                            } else {
                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str42), 2)) {
                                                                heff_drop(v_p_240);
                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam22_clo)});
                                                              } else {
                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str43), 2)) {
                                                                  heff_drop(v_p_240);
                                                                  return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get());
                                                                } else {
                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str44), 2)) {
                                                                    heff_drop(v_p_240);
                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam23_clo)});
                                                                  } else {
                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str45), 2)) {
                                                                      heff_drop(v_p_240);
                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam24_clo)});
                                                                    } else {
                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str46), 2)) {
                                                                        heff_drop(v_p_240);
                                                                        return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get());
                                                                      } else {
                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str47), 2)) {
                                                                          heff_drop(v_p_240);
                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam25_clo)});
                                                                        } else {
                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str48), 2)) {
                                                                            heff_drop(v_p_240);
                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam27_clo)});
                                                                          } else {
                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str50), 2)) {
                                                                              heff_drop(v_p_240);
                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam30_clo)});
                                                                            } else {
                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str51), 2)) {
                                                                                heff_drop(v_p_240);
                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam34_clo)});
                                                                              } else {
                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str52), 2)) {
                                                                                  heff_drop(v_p_240);
                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam38_clo)});
                                                                                } else {
                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str53), 2)) {
                                                                                    heff_drop(v_p_240);
                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam40_clo)});
                                                                                  } else {
                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str54), 2)) {
                                                                                      heff_drop(v_p_240);
                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam42_clo)});
                                                                                    } else {
                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str55), 2)) {
                                                                                        heff_drop(v_p_240);
                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam45_clo)});
                                                                                      } else {
                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str56), 2)) {
                                                                                          heff_drop(v_p_240);
                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam49_clo)});
                                                                                        } else {
                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str57), 2)) {
                                                                                            heff_drop(v_p_240);
                                                                                            return heff_dup(g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get());
                                                                                          } else {
                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str58), 2)) {
                                                                                              heff_drop(v_p_240);
                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam52_clo)});
                                                                                            } else {
                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str59), 2)) {
                                                                                                heff_drop(v_p_240);
                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam53_clo)});
                                                                                              } else {
                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str60), 2)) {
                                                                                                  heff_drop(v_p_240);
                                                                                                  HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam56_clo));
                                                                                                } else {
                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str63), 2)) {
                                                                                                    heff_drop(v_p_240);
                                                                                                    HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam57_clo));
                                                                                                  } else {
                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str66), 2)) {
                                                                                                      heff_drop(v_p_240);
                                                                                                      HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam58_clo));
                                                                                                    } else {
                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str67), 2)) {
                                                                                                        heff_drop(v_p_240);
                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam59_clo)});
                                                                                                      } else {
                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str68), 2)) {
                                                                                                          heff_drop(v_p_240);
                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam60_clo)});
                                                                                                        } else {
                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str69), 2)) {
                                                                                                            heff_drop(v_p_240);
                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam61_clo)});
                                                                                                          } else {
                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str70), 2)) {
                                                                                                              heff_drop(v_p_240);
                                                                                                              HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam64_clo));
                                                                                                            } else {
                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str71), 2)) {
                                                                                                                heff_drop(v_p_240);
                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam66_clo)});
                                                                                                              } else {
                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str72), 2)) {
                                                                                                                  heff_drop(v_p_240);
                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam68_clo)});
                                                                                                                } else {
                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str73), 2)) {
                                                                                                                    heff_drop(v_p_240);
                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam69_clo)});
                                                                                                                  } else {
                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str74), 2)) {
                                                                                                                      heff_drop(v_p_240);
                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam71_clo)});
                                                                                                                    } else {
                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str75), 2)) {
                                                                                                                        heff_drop(v_p_240);
                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam73_clo)});
                                                                                                                      } else {
                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str76), 2)) {
                                                                                                                          heff_drop(v_p_240);
                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam74_clo)});
                                                                                                                        } else {
                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str77), 2)) {
                                                                                                                            heff_drop(v_p_240);
                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam75_clo)});
                                                                                                                          } else {
                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str78), 2)) {
                                                                                                                              heff_drop(v_p_240);
                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam76_clo)});
                                                                                                                            } else {
                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str79), 2)) {
                                                                                                                                heff_drop(v_p_240);
                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam77_clo)});
                                                                                                                              } else {
                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str80), 2)) {
                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam79_clo)});
                                                                                                                                } else {
                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str81), 2)) {
                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                    return heff_dup(g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get());
                                                                                                                                  } else {
                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str82), 2)) {
                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam82_clo)});
                                                                                                                                    } else {
                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str84), 2)) {
                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                        HEFF_LAST return g_heff_2ecompile_2einterp_2ebytes2(((V)&g_heff_2ecompile_2einterp_2eprim_lam83_clo));
                                                                                                                                      } else {
                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str87), 2)) {
                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam84_clo)});
                                                                                                                                        } else {
                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str89), 2)) {
                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam85_clo)});
                                                                                                                                          } else {
                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str90), 2)) {
                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam86_clo)});
                                                                                                                                            } else {
                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str91), 2)) {
                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam87_clo)});
                                                                                                                                              } else {
                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str92), 2)) {
                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam88_clo)});
                                                                                                                                                } else {
                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str93), 2)) {
                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam89_clo)});
                                                                                                                                                  } else {
                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str94), 2)) {
                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam93_clo)});
                                                                                                                                                    } else {
                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str95), 2)) {
                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam96_clo)});
                                                                                                                                                      } else {
                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str100), 2)) {
                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                          return heff_dup(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get());
                                                                                                                                                        } else {
                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str101), 2)) {
                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                            HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam99_clo));
                                                                                                                                                          } else {
                                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str102), 2)) {
                                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam103_clo)});
                                                                                                                                                            } else {
                                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str103), 2)) {
                                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam106_clo)});
                                                                                                                                                              } else {
                                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str105), 2)) {
                                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                                  HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam107_clo));
                                                                                                                                                                } else {
                                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str107), 2)) {
                                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam110_clo)});
                                                                                                                                                                  } else {
                                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str108), 2)) {
                                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                                      HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam111_clo));
                                                                                                                                                                    } else {
                                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str109), 2)) {
                                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                                        HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam112_clo));
                                                                                                                                                                      } else {
                                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str113), 2)) {
                                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam114_clo)});
                                                                                                                                                                        } else {
                                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str114), 2)) {
                                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam116_clo)});
                                                                                                                                                                          } else {
                                                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str115), 2)) {
                                                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                                                              HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam118_clo));
                                                                                                                                                                            } else {
                                                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str118), 2)) {
                                                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                                                HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam119_clo));
                                                                                                                                                                              } else {
                                                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str121), 2)) {
                                                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                                                  HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam120_clo));
                                                                                                                                                                                } else {
                                                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str124), 2)) {
                                                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam121_clo)});
                                                                                                                                                                                  } else {
                                                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str125), 2)) {
                                                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam122_clo)});
                                                                                                                                                                                    } else {
                                                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str126), 2)) {
                                                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam124_clo)});
                                                                                                                                                                                      } else {
                                                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str127), 2)) {
                                                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam125_clo)});
                                                                                                                                                                                        } else {
                                                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str128), 2)) {
                                                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam126_clo)});
                                                                                                                                                                                          } else {
                                                                                                                                                                                            HeffT2 v_t_241843 = (g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(v_p_240));
                                                                                                                                                                                            {
                                                                                                                                                                                              V v_field_241845 = v_t_241843.f[1];
                                                                                                                                                                                              int64_t v_tag_241844 = ((int64_t)v_t_241843.f[0]);
                                                                                                                                                                                              if ((v_tag_241844 == ((int64_t)0ULL))) {
                                                                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                                                                V v_fp_241847 = v_field_241845;
                                                                                                                                                                                                HEFF_LAST return g_heff_2ecompile_2einterp_2efixedPrimV(v_fp_241847);
                                                                                                                                                                                              } else {
                                                                                                                                                                                                heff_drop(v_field_241845);
                                                                                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam127, 2, 1, (V[]){v_p_240})});
                                                                                                                                                                                              }
                                                                                                                                                                                            }
                                                                                                                                                                                          }
                                                                                                                                                                                        }
                                                                                                                                                                                      }
                                                                                                                                                                                    }
                                                                                                                                                                                  }
                                                                                                                                                                                }
                                                                                                                                                                              }
                                                                                                                                                                            }
                                                                                                                                                                          }
                                                                                                                                                                        }
                                                                                                                                                                      }
                                                                                                                                                                    }
                                                                                                                                                                  }
                                                                                                                                                                }
                                                                                                                                                              }
                                                                                                                                                            }
                                                                                                                                                          }
                                                                                                                                                        }
                                                                                                                                                      }
                                                                                                                                                    }
                                                                                                                                                  }
                                                                                                                                                }
                                                                                                                                              }
                                                                                                                                            }
                                                                                                                                          }
                                                                                                                                        }
                                                                                                                                      }
                                                                                                                                    }
                                                                                                                                  }
                                                                                                                                }
                                                                                                                              }
                                                                                                                            }
                                                                                                                          }
                                                                                                                        }
                                                                                                                      }
                                                                                                                    }
                                                                                                                  }
                                                                                                                }
                                                                                                              }
                                                                                                            }
                                                                                                          }
                                                                                                        }
                                                                                                      }
                                                                                                    }
                                                                                                  }
                                                                                                }
                                                                                              }
                                                                                            }
                                                                                          }
                                                                                        }
                                                                                      }
                                                                                    }
                                                                                  }
                                                                                }
                                                                              }
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eprim(a[0]);
}
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_b_246 = args[1];
  if (heff_intEq_c_lent(v_b_246, MK_INT(0LL), 2)) {
    heff_drop(v_a_245);
    heff_drop(v_b_246);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){MK_INT(0LL)})});
  } else {
    V v_t_248 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_245, v_b_246)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_248});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args) {
  V v_a_2410 = args[0];
  V v_b_2411 = args[1];
  if (heff_intEq_c_lent(v_b_2411, MK_INT(0LL), 2)) {
    heff_drop(v_b_2411);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_2410})});
  } else {
    V v_t_2413 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMod(v_a_2410, v_b_2411)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2413});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args) {
  V v_a_2415 = args[0];
  V v_b_2416 = args[1];
  V v_t_2418;
  if (heff_intEq_c(v_a_2415, v_b_2416)) {
    v_t_2418 = ((V)&g_heff_2ecompile_2einterp_2eprim_str6);
  } else {
    v_t_2418 = ((V)&g_heff_2ecompile_2einterp_2eprim_str7);
  }
  V v_t_2419 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2419});
}
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args) {
  V v_a_2421 = args[0];
  V v_b_2422 = args[1];
  V v_t_2424;
  if (heff_intLt_c(v_a_2421, v_b_2422)) {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2eprim_str9);
  } else {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2eprim_str10);
  }
  V v_t_2425 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2425});
}
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args) {
  V v_a_2427 = args[0];
  V v_b_2428 = args[1];
  V v_t_2430;
  if (heff_intLe_c(v_a_2427, v_b_2428)) {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2eprim_str12);
  } else {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2eprim_str13);
  }
  V v_t_2431 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2431});
}
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args) {
  V v_d_2433 = args[0];
  V v_a_2434 = args[1];
  V v_x1_2435 = heff_tr(heff_call(v_a_2434, 1, (V[]){v_d_2433}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_Ok: {
    V v_v_2436 = heff_field(v_x1_2435, 0);
    V v_ru_24x1_2435_24Ok = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
    switch (heff_tag_of(v_v_2436)) {
    case TAG_VFun: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2436, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_2441 = heff_field(v_v_2436, 0);
      V v_ru_24v_2436_24VInt = heff_take_reuse_n(v_v_2436, 1ULL, 1);
      V v_t_2442 = heff_tag_at_n(v_ru_24v_2436_24VInt, TAG_VStr, 1, (V[]){heff_intShow(v_a_2441)});
      return heff_tag_at_n(v_ru_24x1_2435_24Ok, TAG_Ok, 1, (V[]){v_t_2442});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2436, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_2436);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2451 = heff_field(v_x1_2435, 0);
    V v_ru_24x1_2435_24Bug = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2435_24Bug, TAG_Bug, 1, (V[]){v_what_2451});
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args) {
  V v_a_2454 = args[0];
  V v_b_2455 = args[1];
  V v_t_2456 = (g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), v_a_2454, v_b_2455));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2456})});
}
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args) {
  V v_a_2458 = args[0];
  V v_b_2459 = args[1];
  V v_t_2460 = (g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(MK_INT(2LL), v_a_2458, v_b_2459));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2460})});
}
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args) {
  V v_a_2462 = args[0];
  V v_b_2463 = args[1];
  if (heff_intLt_c_lent(v_b_2463, MK_INT(0LL), 2)) {
    V v_k_2465 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2463)));
    V v_t_2466 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2462, v_k_2465)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2466});
  } else {
    V v_k_2467 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2463));
    V v_t_2468 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2462, v_k_2467)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2468});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args) {
  V v_a_2470 = args[0];
  V v_b_2471 = args[1];
  if (heff_intLt_c_lent(v_b_2471, MK_INT(0LL), 2)) {
    V v_k_2473 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2471)));
    V v_t_2474 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2470, v_k_2473)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2474});
  } else {
    V v_k_2475 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2471));
    V v_t_2476 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2470, v_k_2475)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2476});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args) {
  V v_box_24a_2482 = args[0];
  V v_box_24b_2483 = args[1];
  double v_a_2482 = heff_unbox_f64(v_box_24a_2482);
  double v_b_2483 = heff_unbox_f64(v_box_24b_2483);
  V v_t_2485;
  if ((v_a_2482 == v_b_2483)) {
    v_t_2485 = ((V)&g_heff_2ecompile_2einterp_2eprim_str25);
  } else {
    v_t_2485 = ((V)&g_heff_2ecompile_2einterp_2eprim_str26);
  }
  V v_t_2486 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2485, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2486});
}
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args) {
  V v_box_24a_2488 = args[0];
  V v_box_24b_2489 = args[1];
  double v_a_2488 = heff_unbox_f64(v_box_24a_2488);
  double v_b_2489 = heff_unbox_f64(v_box_24b_2489);
  V v_t_2491;
  if ((v_a_2488 < v_b_2489)) {
    v_t_2491 = ((V)&g_heff_2ecompile_2einterp_2eprim_str28);
  } else {
    v_t_2491 = ((V)&g_heff_2ecompile_2einterp_2eprim_str29);
  }
  V v_t_2492 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2491, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2492});
}
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args) {
  V v_box_24a_2494 = args[0];
  V v_box_24b_2495 = args[1];
  double v_a_2494 = heff_unbox_f64(v_box_24a_2494);
  double v_b_2495 = heff_unbox_f64(v_box_24b_2495);
  V v_t_2497;
  if ((v_a_2494 <= v_b_2495)) {
    v_t_2497 = ((V)&g_heff_2ecompile_2einterp_2eprim_str31);
  } else {
    v_t_2497 = ((V)&g_heff_2ecompile_2einterp_2eprim_str32);
  }
  V v_t_2498 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2497, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2498});
}
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args) {
  V v_d_24100 = args[0];
  V v_a_24101 = args[1];
  V v_x1_24102 = heff_tr(heff_call(v_a_24101, 1, (V[]){v_d_24100}));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_Ok: {
    V v_v_24103 = heff_field(v_x1_24102, 0);
    V v_ru_24x1_24102_24Ok = heff_take_reuse_n(v_x1_24102, 1ULL, 1);
    switch (heff_tag_of(v_v_24103)) {
    case TAG_VFun: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24103, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      V v_a_24109 = heff_tget_v(v_v_24103, 0);
      V v_ru_24v_24103_24VFloat = heff_take_reuse_na(v_v_24103, 0ULL, 1);
      V v_t_24110 = heff_tag_at_n(v_ru_24v_24103_24VFloat, TAG_VStr, 1, (V[]){heff_floatShow(v_a_24109)});
      return heff_tag_at_n(v_ru_24x1_24102_24Ok, TAG_Ok, 1, (V[]){v_t_24110});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24103, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24103);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24118 = heff_field(v_x1_24102, 0);
    V v_ru_24x1_24102_24Bug = heff_take_reuse_n(v_x1_24102, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24102_24Bug, TAG_Bug, 1, (V[]){v_what_24118});
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args) {
  V v_d_24120 = args[0];
  V v_a_24121 = args[1];
  V v_x1_24122 = heff_tr(heff_call(v_a_24121, 1, (V[]){v_d_24120}));
  switch (heff_tag_of(v_x1_24122)) {
  case TAG_Ok: {
    V v_v_24123 = heff_field(v_x1_24122, 0);
    V v_ru_24x1_24122_24Ok = heff_take_reuse_n(v_x1_24122, 1ULL, 1);
    switch (heff_tag_of(v_v_24123)) {
    case TAG_VFun: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24123, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24128 = heff_field(v_v_24123, 0);
      V v_ru_24v_24123_24VInt = heff_take_reuse_n(v_v_24123, 1ULL, 1);
      V v_t_24129 = heff_tag_at_nf(v_ru_24v_24123_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(heff_from_int_f64(v_a_24128))});
      return heff_tag_at_n(v_ru_24x1_24122_24Ok, TAG_Ok, 1, (V[]){v_t_24129});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24123, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24123);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24138 = heff_field(v_x1_24122, 0);
    V v_ru_24x1_24122_24Bug = heff_take_reuse_n(v_x1_24122, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24122_24Bug, TAG_Bug, 1, (V[]){v_what_24138});
  }
  default: return heff_nomatch(v_x1_24122);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args) {
  V v_d_24140 = args[0];
  V v_a_24141 = args[1];
  V v_x1_24142 = heff_tr(heff_call(v_a_24141, 1, (V[]){v_d_24140}));
  switch (heff_tag_of(v_x1_24142)) {
  case TAG_Ok: {
    V v_v_24143 = heff_field(v_x1_24142, 0);
    V v_ru_24x1_24142_24Ok = heff_take_reuse_n(v_x1_24142, 1ULL, 1);
    switch (heff_tag_of(v_v_24143)) {
    case TAG_VFun: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24143, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24149 = heff_tflat_f64(v_v_24143, 0);
      V v_ru_24v_24143_24VFloat = heff_take_reuse_na(v_v_24143, 0ULL, 1);
      V v_t_24150 = heff_tag_at_nf(v_ru_24v_24143_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(sqrt(v_a_24149))});
      return heff_tag_at_n(v_ru_24x1_24142_24Ok, TAG_Ok, 1, (V[]){v_t_24150});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24143, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24143);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24158 = heff_field(v_x1_24142, 0);
    V v_ru_24x1_24142_24Bug = heff_take_reuse_n(v_x1_24142, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24142_24Bug, TAG_Bug, 1, (V[]){v_what_24158});
  }
  default: return heff_nomatch(v_x1_24142);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args) {
  V v_d_24160 = args[0];
  V v_a_24161 = args[1];
  V v_x1_24162 = heff_tr(heff_call(v_a_24161, 1, (V[]){v_d_24160}));
  switch (heff_tag_of(v_x1_24162)) {
  case TAG_Ok: {
    V v_v_24163 = heff_field(v_x1_24162, 0);
    V v_ru_24x1_24162_24Ok = heff_take_reuse_n(v_x1_24162, 1ULL, 1);
    switch (heff_tag_of(v_v_24163)) {
    case TAG_VFun: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24163, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24169 = heff_tflat_f64(v_v_24163, 0);
      V v_ru_24v_24163_24VFloat = heff_take_reuse_na(v_v_24163, 0ULL, 1);
      if (((v_a_24169 - v_a_24169) == (0.0))) {
        V v_t_24171 = heff_tag_at_n(v_ru_24v_24163_24VFloat, TAG_VInt, 1, (V[]){heff_floor_f64(v_a_24169)});
        return heff_tag_at_n(v_ru_24x1_24162_24Ok, TAG_Ok, 1, (V[]){v_t_24171});
      } else {
        heff_drop_cell(v_ru_24v_24163_24VFloat, 1);
        return heff_tag_at_n(v_ru_24x1_24162_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){MK_INT(0LL)})});
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24163, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24163);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24179 = heff_field(v_x1_24162, 0);
    V v_ru_24x1_24162_24Bug = heff_take_reuse_n(v_x1_24162, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24162_24Bug, TAG_Bug, 1, (V[]){v_what_24179});
  }
  default: return heff_nomatch(v_x1_24162);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args) {
  V v_d_24181 = args[0];
  V v_a_24182 = args[1];
  V v_x1_24183 = heff_tr(heff_call(v_a_24182, 1, (V[]){v_d_24181}));
  switch (heff_tag_of(v_x1_24183)) {
  case TAG_Ok: {
    V v_v_24184 = heff_field(v_x1_24183, 0);
    V v_ru_24x1_24183_24Ok = heff_take_reuse_n(v_x1_24183, 1ULL, 1);
    switch (heff_tag_of(v_v_24184)) {
    case TAG_VFun: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24184, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24190 = heff_tflat_f64(v_v_24184, 0);
      V v_ru_24v_24184_24VFloat = heff_take_reuse_na(v_v_24184, 0ULL, 1);
      V v_t_24191 = heff_tag_at_nf(v_ru_24v_24184_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(sin(v_a_24190))});
      return heff_tag_at_n(v_ru_24x1_24183_24Ok, TAG_Ok, 1, (V[]){v_t_24191});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24184, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24184);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24199 = heff_field(v_x1_24183, 0);
    V v_ru_24x1_24183_24Bug = heff_take_reuse_n(v_x1_24183, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24183_24Bug, TAG_Bug, 1, (V[]){v_what_24199});
  }
  default: return heff_nomatch(v_x1_24183);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args) {
  V v_d_24201 = args[0];
  V v_a_24202 = args[1];
  V v_x1_24203 = heff_tr(heff_call(v_a_24202, 1, (V[]){v_d_24201}));
  switch (heff_tag_of(v_x1_24203)) {
  case TAG_Ok: {
    V v_v_24204 = heff_field(v_x1_24203, 0);
    V v_ru_24x1_24203_24Ok = heff_take_reuse_n(v_x1_24203, 1ULL, 1);
    switch (heff_tag_of(v_v_24204)) {
    case TAG_VFun: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24204, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24210 = heff_tflat_f64(v_v_24204, 0);
      V v_ru_24v_24204_24VFloat = heff_take_reuse_na(v_v_24204, 0ULL, 1);
      V v_t_24211 = heff_tag_at_nf(v_ru_24v_24204_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(cos(v_a_24210))});
      return heff_tag_at_n(v_ru_24x1_24203_24Ok, TAG_Ok, 1, (V[]){v_t_24211});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24204, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24204);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24219 = heff_field(v_x1_24203, 0);
    V v_ru_24x1_24203_24Bug = heff_take_reuse_n(v_x1_24203, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24203_24Bug, TAG_Bug, 1, (V[]){v_what_24219});
  }
  default: return heff_nomatch(v_x1_24203);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args) {
  V v_d_24221 = args[0];
  V v_a_24222 = args[1];
  V v_x1_24223 = heff_tr(heff_call(v_a_24222, 1, (V[]){v_d_24221}));
  switch (heff_tag_of(v_x1_24223)) {
  case TAG_Ok: {
    V v_v_24224 = heff_field(v_x1_24223, 0);
    V v_ru_24x1_24223_24Ok = heff_take_reuse_n(v_x1_24223, 1ULL, 1);
    switch (heff_tag_of(v_v_24224)) {
    case TAG_VFun: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24224, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24230 = heff_tflat_f64(v_v_24224, 0);
      V v_ru_24v_24224_24VFloat = heff_take_reuse_na(v_v_24224, 0ULL, 1);
      V v_t_24231 = heff_tag_at_nf(v_ru_24v_24224_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(tan(v_a_24230))});
      return heff_tag_at_n(v_ru_24x1_24223_24Ok, TAG_Ok, 1, (V[]){v_t_24231});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24224, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24224);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24239 = heff_field(v_x1_24223, 0);
    V v_ru_24x1_24223_24Bug = heff_take_reuse_n(v_x1_24223, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24223_24Bug, TAG_Bug, 1, (V[]){v_what_24239});
  }
  default: return heff_nomatch(v_x1_24223);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args) {
  V v_d_24241 = args[0];
  V v_a_24242 = args[1];
  V v_x1_24243 = heff_tr(heff_call(v_a_24242, 1, (V[]){v_d_24241}));
  switch (heff_tag_of(v_x1_24243)) {
  case TAG_Ok: {
    V v_v_24244 = heff_field(v_x1_24243, 0);
    V v_ru_24x1_24243_24Ok = heff_take_reuse_n(v_x1_24243, 1ULL, 1);
    switch (heff_tag_of(v_v_24244)) {
    case TAG_VFun: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24244, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24250 = heff_tflat_f64(v_v_24244, 0);
      V v_ru_24v_24244_24VFloat = heff_take_reuse_na(v_v_24244, 0ULL, 1);
      V v_t_24251 = heff_tag_at_nf(v_ru_24v_24244_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(asin(v_a_24250))});
      return heff_tag_at_n(v_ru_24x1_24243_24Ok, TAG_Ok, 1, (V[]){v_t_24251});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24244, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24244);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24259 = heff_field(v_x1_24243, 0);
    V v_ru_24x1_24243_24Bug = heff_take_reuse_n(v_x1_24243, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24243_24Bug, TAG_Bug, 1, (V[]){v_what_24259});
  }
  default: return heff_nomatch(v_x1_24243);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args) {
  V v_d_24261 = args[0];
  V v_a_24262 = args[1];
  V v_x1_24263 = heff_tr(heff_call(v_a_24262, 1, (V[]){v_d_24261}));
  switch (heff_tag_of(v_x1_24263)) {
  case TAG_Ok: {
    V v_v_24264 = heff_field(v_x1_24263, 0);
    V v_ru_24x1_24263_24Ok = heff_take_reuse_n(v_x1_24263, 1ULL, 1);
    switch (heff_tag_of(v_v_24264)) {
    case TAG_VFun: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24264, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24270 = heff_tflat_f64(v_v_24264, 0);
      V v_ru_24v_24264_24VFloat = heff_take_reuse_na(v_v_24264, 0ULL, 1);
      V v_t_24271 = heff_tag_at_nf(v_ru_24v_24264_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(acos(v_a_24270))});
      return heff_tag_at_n(v_ru_24x1_24263_24Ok, TAG_Ok, 1, (V[]){v_t_24271});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24264, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24264);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24279 = heff_field(v_x1_24263, 0);
    V v_ru_24x1_24263_24Bug = heff_take_reuse_n(v_x1_24263, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24263_24Bug, TAG_Bug, 1, (V[]){v_what_24279});
  }
  default: return heff_nomatch(v_x1_24263);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args) {
  V v_d_24281 = args[0];
  V v_a_24282 = args[1];
  V v_x1_24283 = heff_tr(heff_call(v_a_24282, 1, (V[]){v_d_24281}));
  switch (heff_tag_of(v_x1_24283)) {
  case TAG_Ok: {
    V v_v_24284 = heff_field(v_x1_24283, 0);
    V v_ru_24x1_24283_24Ok = heff_take_reuse_n(v_x1_24283, 1ULL, 1);
    switch (heff_tag_of(v_v_24284)) {
    case TAG_VFun: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24284, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24290 = heff_tflat_f64(v_v_24284, 0);
      V v_ru_24v_24284_24VFloat = heff_take_reuse_na(v_v_24284, 0ULL, 1);
      V v_t_24291 = heff_tag_at_nf(v_ru_24v_24284_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(atan(v_a_24290))});
      return heff_tag_at_n(v_ru_24x1_24283_24Ok, TAG_Ok, 1, (V[]){v_t_24291});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24284, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24284);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24299 = heff_field(v_x1_24283, 0);
    V v_ru_24x1_24283_24Bug = heff_take_reuse_n(v_x1_24283, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24283_24Bug, TAG_Bug, 1, (V[]){v_what_24299});
  }
  default: return heff_nomatch(v_x1_24283);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args) {
  V v_d_24302 = args[0];
  V v_a_24303 = args[1];
  V v_x1_24304 = heff_tr(heff_call(v_a_24303, 1, (V[]){v_d_24302}));
  switch (heff_tag_of(v_x1_24304)) {
  case TAG_Ok: {
    V v_v_24305 = heff_field(v_x1_24304, 0);
    V v_ru_24x1_24304_24Ok = heff_take_reuse_n(v_x1_24304, 1ULL, 1);
    switch (heff_tag_of(v_v_24305)) {
    case TAG_VFun: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24305, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24311 = heff_tflat_f64(v_v_24305, 0);
      V v_ru_24v_24305_24VFloat = heff_take_reuse_na(v_v_24305, 0ULL, 1);
      V v_t_24312 = heff_tag_at_nf(v_ru_24v_24305_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(exp(v_a_24311))});
      return heff_tag_at_n(v_ru_24x1_24304_24Ok, TAG_Ok, 1, (V[]){v_t_24312});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24305, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24305);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24320 = heff_field(v_x1_24304, 0);
    V v_ru_24x1_24304_24Bug = heff_take_reuse_n(v_x1_24304, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24304_24Bug, TAG_Bug, 1, (V[]){v_what_24320});
  }
  default: return heff_nomatch(v_x1_24304);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args) {
  V v_d_24322 = args[0];
  V v_a_24323 = args[1];
  V v_x1_24324 = heff_tr(heff_call(v_a_24323, 1, (V[]){v_d_24322}));
  switch (heff_tag_of(v_x1_24324)) {
  case TAG_Ok: {
    V v_v_24325 = heff_field(v_x1_24324, 0);
    V v_ru_24x1_24324_24Ok = heff_take_reuse_n(v_x1_24324, 1ULL, 1);
    switch (heff_tag_of(v_v_24325)) {
    case TAG_VFun: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24325, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24331 = heff_tflat_f64(v_v_24325, 0);
      V v_ru_24v_24325_24VFloat = heff_take_reuse_na(v_v_24325, 0ULL, 1);
      V v_t_24332 = heff_tag_at_nf(v_ru_24v_24325_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(log(v_a_24331))});
      return heff_tag_at_n(v_ru_24x1_24324_24Ok, TAG_Ok, 1, (V[]){v_t_24332});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24325, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24325);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24340 = heff_field(v_x1_24324, 0);
    V v_ru_24x1_24324_24Bug = heff_take_reuse_n(v_x1_24324, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24324_24Bug, TAG_Bug, 1, (V[]){v_what_24340});
  }
  default: return heff_nomatch(v_x1_24324);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args) {
  V v_d_24345 = args[0];
  V v_a_24346 = args[1];
  V v_x1_24347 = heff_tr(heff_call(v_a_24346, 1, (V[]){v_d_24345}));
  switch (heff_tag_of(v_x1_24347)) {
  case TAG_Ok: {
    V v_v_24348 = heff_field(v_x1_24347, 0);
    V v_ru_24x1_24347_24Ok = heff_take_reuse_n(v_x1_24347, 1ULL, 1);
    switch (heff_tag_of(v_v_24348)) {
    case TAG_VFun: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24348, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24358 = heff_field(v_v_24348, 0);
      heff_take_n(v_v_24348, 1ULL, 1);
      V v_t_24359 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_xs_24358); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      return heff_tag_at_n(v_ru_24x1_24347_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24359})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24348, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24348);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24363 = heff_field(v_x1_24347, 0);
    V v_ru_24x1_24347_24Bug = heff_take_reuse_n(v_x1_24347, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24347_24Bug, TAG_Bug, 1, (V[]){v_what_24363});
  }
  default: return heff_nomatch(v_x1_24347);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args) {
  V v_d_24343 = args[0];
  V v_u_24344 = args[1];
  heff_drop(v_d_24343);
  heff_drop(v_u_24344);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam26_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args) {
  V v_d_24381 = args[0];
  V v_a_24382 = args[1];
  V v_xs_24380 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24383 = heff_tr(heff_call(v_a_24382, 1, (V[]){v_d_24381}));
  switch (heff_tag_of(v_x1_24383)) {
  case TAG_Ok: {
    V v_v_24384 = heff_field(v_x1_24383, 0);
    V v_ru_24x1_24383_24Ok = heff_take_reuse_n(v_x1_24383, 1ULL, 1);
    switch (heff_tag_of(v_v_24384)) {
    case TAG_VFun: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24384, 0ULL, 2);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24389 = heff_field(v_v_24384, 0);
      V v_ru_24v_24384_24VInt = heff_take_reuse_n(v_v_24384, 1ULL, 1);
      if (heff_intLe_c_lent(MK_INT(0LL), v_a_24389, 1)) {
        V v_t_24391 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24380)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        if (heff_intLt_c_lent(v_a_24389, v_t_24391, 2)) {
          HeffT2 v_t_24393 = (g_heff_2ecompile_2einterp_2enthV_24cpr(heff_arrayToList(v_xs_24380), v_a_24389));
          {
            V v_field_24395 = v_t_24393.f[1];
            int64_t v_tag_24394 = ((int64_t)v_t_24393.f[0]);
            if ((v_tag_24394 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24v_24384_24VInt, 1);
              V v_v_24397 = v_field_24395;
              return heff_tag_at_n(v_ru_24x1_24383_24Ok, TAG_Ok, 1, (V[]){v_v_24397});
            } else {
              heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
              heff_drop(v_field_24395);
              return heff_tag_at_n(v_ru_24v_24384_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str49)});
            }
          }
        } else {
          heff_drop(v_xs_24380);
          heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
          heff_drop(v_a_24389);
          heff_drop_cell(v_ru_24v_24384_24VInt, 1);
          return NTAG(TAG_Abn);
        }
      } else {
        heff_drop(v_xs_24380);
        heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
        heff_drop(v_a_24389);
        heff_drop_cell(v_ru_24v_24384_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24384, 0ULL, 2);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24384);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24380);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24380);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24406 = heff_field(v_x1_24383, 0);
    V v_ru_24x1_24383_24Bug = heff_take_reuse_n(v_x1_24383, 1ULL, 1);
    heff_drop(v_xs_24380);
    return heff_tag_at_n(v_ru_24x1_24383_24Bug, TAG_Bug, 1, (V[]){v_what_24406});
  }
  default: return heff_nomatch(v_x1_24383);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args) {
  V v_d_24367 = args[0];
  V v_a_24368 = args[1];
  V v_x1_24369 = heff_tr(heff_call(v_a_24368, 1, (V[]){v_d_24367}));
  switch (heff_tag_of(v_x1_24369)) {
  case TAG_Ok: {
    V v_v_24370 = heff_field(v_x1_24369, 0);
    V v_ru_24x1_24369_24Ok = heff_take_reuse_n(v_x1_24369, 1ULL, 1);
    switch (heff_tag_of(v_v_24370)) {
    case TAG_VFun: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24370, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24380 = heff_field(v_v_24370, 0);
      heff_take_n(v_v_24370, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24369_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam29, 2, 1, (V[]){v_xs_24380})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24370, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24370);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24410 = heff_field(v_x1_24369, 0);
    V v_ru_24x1_24369_24Bug = heff_take_reuse_n(v_x1_24369, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24369_24Bug, TAG_Bug, 1, (V[]){v_what_24410});
  }
  default: return heff_nomatch(v_x1_24369);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args) {
  V v_d_24365 = args[0];
  V v_u_24366 = args[1];
  heff_drop(v_d_24365);
  heff_drop(v_u_24366);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam28_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args) {
  V v_d_24437 = args[0];
  V v_x_24438 = args[1];
  V v_a_24436 = heff_env(self)[0];
  V v_xs_24427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24439 = heff_tr(heff_call(v_x_24438, 1, (V[]){v_d_24437}));
  switch (heff_tag_of(v_x1_24439)) {
  case TAG_Ok: {
    V v_v_24440 = heff_field(v_x1_24439, 0);
    V v_ru_24x1_24439_24Ok = heff_take_reuse_n(v_x1_24439, 1ULL, 1);
    if (heff_intLe_c_lent(MK_INT(0LL), v_a_24436, 1)) {
      V v_t_24442 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24427)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (heff_intLt_c_lent(v_a_24436, v_t_24442, 2)) {
        V v_t_24444 = (g_heff_2ecompile_2einterp_2esetAt(heff_arrayToList(v_xs_24427), v_a_24436, v_v_24440));
        V v_t_24445 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24444)});
        return heff_tag_at_n(v_ru_24x1_24439_24Ok, TAG_Ok, 1, (V[]){v_t_24445});
      } else {
        heff_drop(v_a_24436);
        heff_drop(v_v_24440);
        return heff_tag_at_n(v_ru_24x1_24439_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VArr, 1, (V[]){v_xs_24427})});
      }
    } else {
      heff_drop(v_a_24436);
      heff_drop(v_v_24440);
      return heff_tag_at_n(v_ru_24x1_24439_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VArr, 1, (V[]){v_xs_24427})});
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24436);
    heff_drop(v_xs_24427);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24436);
    heff_drop(v_xs_24427);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24446 = heff_field(v_x1_24439, 0);
    V v_ru_24x1_24439_24Bug = heff_take_reuse_n(v_x1_24439, 1ULL, 1);
    heff_drop(v_a_24436);
    heff_drop(v_xs_24427);
    return heff_tag_at_n(v_ru_24x1_24439_24Bug, TAG_Bug, 1, (V[]){v_what_24446});
  }
  default: return heff_nomatch(v_x1_24439);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args) {
  V v_d_24428 = args[0];
  V v_a_24429 = args[1];
  V v_xs_24427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24430 = heff_tr(heff_call(v_a_24429, 1, (V[]){v_d_24428}));
  switch (heff_tag_of(v_x1_24430)) {
  case TAG_Ok: {
    V v_v_24431 = heff_field(v_x1_24430, 0);
    V v_ru_24x1_24430_24Ok = heff_take_reuse_n(v_x1_24430, 1ULL, 1);
    switch (heff_tag_of(v_v_24431)) {
    case TAG_VFun: {
      heff_take_n(v_v_24431, 0ULL, 1);
      heff_drop(v_xs_24427);
      heff_drop_cell(v_ru_24x1_24430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24431, 0ULL, 1);
      heff_drop(v_xs_24427);
      heff_drop_cell(v_ru_24x1_24430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24431, 0ULL, 2);
      heff_drop(v_xs_24427);
      heff_drop_cell(v_ru_24x1_24430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24436 = heff_field(v_v_24431, 0);
      heff_take_n(v_v_24431, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24430_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam33, 2, 2, (V[]){v_a_24436, v_xs_24427})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24431, 0ULL, 1);
      heff_drop(v_xs_24427);
      heff_drop_cell(v_ru_24x1_24430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24431, 0ULL, 1);
      heff_drop(v_xs_24427);
      heff_drop_cell(v_ru_24x1_24430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24431, 0ULL, 1);
      heff_drop(v_xs_24427);
      heff_drop_cell(v_ru_24x1_24430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24431, 0ULL, 1);
      heff_drop(v_xs_24427);
      heff_drop_cell(v_ru_24x1_24430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24431, 0ULL, 1);
      heff_drop(v_xs_24427);
      heff_drop_cell(v_ru_24x1_24430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24431, 0ULL, 1);
      heff_drop(v_xs_24427);
      heff_drop_cell(v_ru_24x1_24430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24431, 0ULL, 2);
      heff_drop(v_xs_24427);
      heff_drop_cell(v_ru_24x1_24430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24427);
      heff_drop_cell(v_ru_24x1_24430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24431);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24427);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24427);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24455 = heff_field(v_x1_24430, 0);
    V v_ru_24x1_24430_24Bug = heff_take_reuse_n(v_x1_24430, 1ULL, 1);
    heff_drop(v_xs_24427);
    return heff_tag_at_n(v_ru_24x1_24430_24Bug, TAG_Bug, 1, (V[]){v_what_24455});
  }
  default: return heff_nomatch(v_x1_24430);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args) {
  V v_d_24414 = args[0];
  V v_a_24415 = args[1];
  V v_x1_24416 = heff_tr(heff_call(v_a_24415, 1, (V[]){v_d_24414}));
  switch (heff_tag_of(v_x1_24416)) {
  case TAG_Ok: {
    V v_v_24417 = heff_field(v_x1_24416, 0);
    V v_ru_24x1_24416_24Ok = heff_take_reuse_n(v_x1_24416, 1ULL, 1);
    switch (heff_tag_of(v_v_24417)) {
    case TAG_VFun: {
      heff_take_n(v_v_24417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24417, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24427 = heff_field(v_v_24417, 0);
      heff_take_n(v_v_24417, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24416_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam32, 2, 1, (V[]){v_xs_24427})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24417, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24417);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24459 = heff_field(v_x1_24416, 0);
    V v_ru_24x1_24416_24Bug = heff_take_reuse_n(v_x1_24416, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24416_24Bug, TAG_Bug, 1, (V[]){v_what_24459});
  }
  default: return heff_nomatch(v_x1_24416);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args) {
  V v_d_24412 = args[0];
  V v_u_24413 = args[1];
  heff_drop(v_d_24412);
  heff_drop(v_u_24413);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam31_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args) {
  V v_vs_24476 = args[0];
  V v_t_24477 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_vs_24476)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24477});
}
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args) {
  V v_d_24472 = args[0];
  V v_f_24473 = args[1];
  V v_a_24471 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24474 = heff_tr(heff_call(v_f_24473, 1, (V[]){heff_dup(v_d_24472)}));
  switch (heff_tag_of(v_x1_24474)) {
  case TAG_Ok: {
    V v_v_24475 = heff_field(v_x1_24474, 0);
    heff_take_n(v_x1_24474, 1ULL, 1);
    return (g_heff_2ecompile_2einterp_2egenGo(v_d_24472, MK_INT(0LL), v_a_24471, v_v_24475, ((V)&g_heff_2ecompile_2einterp_2eprim_lam37_clo)));
  }
  case TAG_Abn: {
    heff_drop(v_d_24472);
    heff_drop(v_a_24471);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_24472);
    heff_drop(v_a_24471);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24478 = heff_field(v_x1_24474, 0);
    V v_ru_24x1_24474_24Bug = heff_take_reuse_n(v_x1_24474, 1ULL, 1);
    heff_drop(v_d_24472);
    heff_drop(v_a_24471);
    return heff_tag_at_n(v_ru_24x1_24474_24Bug, TAG_Bug, 1, (V[]){v_what_24478});
  }
  default: return heff_nomatch(v_x1_24474);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args) {
  V v_d_24463 = args[0];
  V v_a_24464 = args[1];
  V v_x1_24465 = heff_tr(heff_call(v_a_24464, 1, (V[]){v_d_24463}));
  switch (heff_tag_of(v_x1_24465)) {
  case TAG_Ok: {
    V v_v_24466 = heff_field(v_x1_24465, 0);
    V v_ru_24x1_24465_24Ok = heff_take_reuse_n(v_x1_24465, 1ULL, 1);
    switch (heff_tag_of(v_v_24466)) {
    case TAG_VFun: {
      heff_take_n(v_v_24466, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24466, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24466, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24471 = heff_field(v_v_24466, 0);
      heff_take_n(v_v_24466, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24465_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam36, 2, 1, (V[]){v_a_24471})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24466, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24466, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24466, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24466, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24466, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24466, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24466, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24466);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24487 = heff_field(v_x1_24465, 0);
    V v_ru_24x1_24465_24Bug = heff_take_reuse_n(v_x1_24465, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24465_24Bug, TAG_Bug, 1, (V[]){v_what_24487});
  }
  default: return heff_nomatch(v_x1_24465);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args) {
  V v_d_24461 = args[0];
  V v_u_24462 = args[1];
  heff_drop(v_d_24461);
  heff_drop(v_u_24462);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam35_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args) {
  V v_d_24491 = args[0];
  V v_l_24492 = args[1];
  V v_x1_24493 = heff_tr(heff_call(v_l_24492, 1, (V[]){v_d_24491}));
  switch (heff_tag_of(v_x1_24493)) {
  case TAG_Ok: {
    V v_v_24494 = heff_field(v_x1_24493, 0);
    V v_ru_24x1_24493_24Ok = heff_take_reuse_n(v_x1_24493, 1ULL, 1);
    V v_t_24495 = (g_heff_2ecompile_2einterp_2efromListV(v_v_24494, NTAG(TAG_Nil)));
    V v_t_24496 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24495)});
    return heff_tag_at_n(v_ru_24x1_24493_24Ok, TAG_Ok, 1, (V[]){v_t_24496});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24497 = heff_field(v_x1_24493, 0);
    V v_ru_24x1_24493_24Bug = heff_take_reuse_n(v_x1_24493, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24493_24Bug, TAG_Bug, 1, (V[]){v_what_24497});
  }
  default: return heff_nomatch(v_x1_24493);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args) {
  V v_d_24489 = args[0];
  V v_u_24490 = args[1];
  heff_drop(v_d_24489);
  heff_drop(v_u_24490);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam39_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args) {
  V v_d_24501 = args[0];
  V v_a_24502 = args[1];
  V v_x1_24503 = heff_tr(heff_call(v_a_24502, 1, (V[]){v_d_24501}));
  switch (heff_tag_of(v_x1_24503)) {
  case TAG_Ok: {
    V v_v_24504 = heff_field(v_x1_24503, 0);
    V v_ru_24x1_24503_24Ok = heff_take_reuse_n(v_x1_24503, 1ULL, 1);
    switch (heff_tag_of(v_v_24504)) {
    case TAG_VFun: {
      heff_take_n(v_v_24504, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24503_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24504, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24503_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24504, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24503_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24504, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24503_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24504, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24503_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24504, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24503_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24504, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24503_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24504, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24503_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24514 = heff_field(v_v_24504, 0);
      heff_take_n(v_v_24504, 1ULL, 1);
      V v_t_24515 = (g_heff_2ecompile_2einterp_2etoListV(heff_arrayToList(v_xs_24514)));
      return heff_tag_at_n(v_ru_24x1_24503_24Ok, TAG_Ok, 1, (V[]){v_t_24515});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24504, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24503_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24504, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24503_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24503_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24504);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24519 = heff_field(v_x1_24503, 0);
    V v_ru_24x1_24503_24Bug = heff_take_reuse_n(v_x1_24503, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24503_24Bug, TAG_Bug, 1, (V[]){v_what_24519});
  }
  default: return heff_nomatch(v_x1_24503);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args) {
  V v_d_24499 = args[0];
  V v_u_24500 = args[1];
  heff_drop(v_d_24499);
  heff_drop(v_u_24500);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam41_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args) {
  V v_d_24532 = args[0];
  V v_x_24533 = args[1];
  V v_a_24531 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24534 = heff_tr(heff_call(v_x_24533, 1, (V[]){v_d_24532}));
  switch (heff_tag_of(v_x1_24534)) {
  case TAG_Ok: {
    V v_v_24535 = heff_field(v_x1_24534, 0);
    V v_ru_24x1_24534_24Ok = heff_take_reuse_n(v_x1_24534, 1ULL, 1);
    V v_t_24536 = (g_list_2ereplicate(v_a_24531, v_v_24535));
    V v_t_24537 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24536)});
    return heff_tag_at_n(v_ru_24x1_24534_24Ok, TAG_Ok, 1, (V[]){v_t_24537});
  }
  case TAG_Abn: {
    heff_drop(v_a_24531);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24531);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24538 = heff_field(v_x1_24534, 0);
    V v_ru_24x1_24534_24Bug = heff_take_reuse_n(v_x1_24534, 1ULL, 1);
    heff_drop(v_a_24531);
    return heff_tag_at_n(v_ru_24x1_24534_24Bug, TAG_Bug, 1, (V[]){v_what_24538});
  }
  default: return heff_nomatch(v_x1_24534);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args) {
  V v_d_24523 = args[0];
  V v_a_24524 = args[1];
  V v_x1_24525 = heff_tr(heff_call(v_a_24524, 1, (V[]){v_d_24523}));
  switch (heff_tag_of(v_x1_24525)) {
  case TAG_Ok: {
    V v_v_24526 = heff_field(v_x1_24525, 0);
    V v_ru_24x1_24525_24Ok = heff_take_reuse_n(v_x1_24525, 1ULL, 1);
    switch (heff_tag_of(v_v_24526)) {
    case TAG_VFun: {
      heff_take_n(v_v_24526, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24526, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24526, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24531 = heff_field(v_v_24526, 0);
      heff_take_n(v_v_24526, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24525_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam44, 2, 1, (V[]){v_a_24531})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24526, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24526, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24526, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24526, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24526, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24526, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24526, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24526);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24547 = heff_field(v_x1_24525, 0);
    V v_ru_24x1_24525_24Bug = heff_take_reuse_n(v_x1_24525, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24525_24Bug, TAG_Bug, 1, (V[]){v_what_24547});
  }
  default: return heff_nomatch(v_x1_24525);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args) {
  V v_d_24521 = args[0];
  V v_u_24522 = args[1];
  heff_drop(v_d_24521);
  heff_drop(v_u_24522);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam43_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args) {
  V v_d_24574 = args[0];
  V v_a_24575 = args[1];
  V v_xs_24564 = heff_env(self)[0];
  V v_a_24573 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24576 = heff_tr(heff_call(v_a_24575, 1, (V[]){v_d_24574}));
  switch (heff_tag_of(v_x1_24576)) {
  case TAG_Ok: {
    V v_v_24577 = heff_field(v_x1_24576, 0);
    V v_ru_24x1_24576_24Ok = heff_take_reuse_n(v_x1_24576, 1ULL, 1);
    switch (heff_tag_of(v_v_24577)) {
    case TAG_VFun: {
      heff_take_n(v_v_24577, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop(v_a_24573);
      heff_drop_cell(v_ru_24x1_24576_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24577, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop(v_a_24573);
      heff_drop_cell(v_ru_24x1_24576_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24577, 0ULL, 2);
      heff_drop(v_xs_24564);
      heff_drop(v_a_24573);
      heff_drop_cell(v_ru_24x1_24576_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24582 = heff_field(v_v_24577, 0);
      V v_ru_24v_24577_24VInt = heff_take_reuse_n(v_v_24577, 1ULL, 1);
      V v_t_24583 = ({ V b_0 = heff_arrayToList(v_xs_24564); V a_1 = v_a_24573; V a_2 = v_a_24582; V r_ = (g_heff_2ecompile_2einterp_2esliceV(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V v_t_24584 = heff_tag_at_n(v_ru_24v_24577_24VInt, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24583)});
      return heff_tag_at_n(v_ru_24x1_24576_24Ok, TAG_Ok, 1, (V[]){v_t_24584});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24577, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop(v_a_24573);
      heff_drop_cell(v_ru_24x1_24576_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24577, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop(v_a_24573);
      heff_drop_cell(v_ru_24x1_24576_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24577, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop(v_a_24573);
      heff_drop_cell(v_ru_24x1_24576_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24577, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop(v_a_24573);
      heff_drop_cell(v_ru_24x1_24576_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24577, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop(v_a_24573);
      heff_drop_cell(v_ru_24x1_24576_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24577, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop(v_a_24573);
      heff_drop_cell(v_ru_24x1_24576_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24577, 0ULL, 2);
      heff_drop(v_xs_24564);
      heff_drop(v_a_24573);
      heff_drop_cell(v_ru_24x1_24576_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24564);
      heff_drop(v_a_24573);
      heff_drop_cell(v_ru_24x1_24576_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24577);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24564);
    heff_drop(v_a_24573);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24564);
    heff_drop(v_a_24573);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24593 = heff_field(v_x1_24576, 0);
    V v_ru_24x1_24576_24Bug = heff_take_reuse_n(v_x1_24576, 1ULL, 1);
    heff_drop(v_xs_24564);
    heff_drop(v_a_24573);
    return heff_tag_at_n(v_ru_24x1_24576_24Bug, TAG_Bug, 1, (V[]){v_what_24593});
  }
  default: return heff_nomatch(v_x1_24576);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args) {
  V v_d_24565 = args[0];
  V v_a_24566 = args[1];
  V v_xs_24564 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24567 = heff_tr(heff_call(v_a_24566, 1, (V[]){v_d_24565}));
  switch (heff_tag_of(v_x1_24567)) {
  case TAG_Ok: {
    V v_v_24568 = heff_field(v_x1_24567, 0);
    V v_ru_24x1_24567_24Ok = heff_take_reuse_n(v_x1_24567, 1ULL, 1);
    switch (heff_tag_of(v_v_24568)) {
    case TAG_VFun: {
      heff_take_n(v_v_24568, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop_cell(v_ru_24x1_24567_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24568, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop_cell(v_ru_24x1_24567_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24568, 0ULL, 2);
      heff_drop(v_xs_24564);
      heff_drop_cell(v_ru_24x1_24567_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24573 = heff_field(v_v_24568, 0);
      heff_take_n(v_v_24568, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24567_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam48, 2, 2, (V[]){v_xs_24564, v_a_24573})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24568, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop_cell(v_ru_24x1_24567_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24568, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop_cell(v_ru_24x1_24567_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24568, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop_cell(v_ru_24x1_24567_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24568, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop_cell(v_ru_24x1_24567_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24568, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop_cell(v_ru_24x1_24567_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24568, 0ULL, 1);
      heff_drop(v_xs_24564);
      heff_drop_cell(v_ru_24x1_24567_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24568, 0ULL, 2);
      heff_drop(v_xs_24564);
      heff_drop_cell(v_ru_24x1_24567_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24564);
      heff_drop_cell(v_ru_24x1_24567_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24568);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24564);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24564);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24602 = heff_field(v_x1_24567, 0);
    V v_ru_24x1_24567_24Bug = heff_take_reuse_n(v_x1_24567, 1ULL, 1);
    heff_drop(v_xs_24564);
    return heff_tag_at_n(v_ru_24x1_24567_24Bug, TAG_Bug, 1, (V[]){v_what_24602});
  }
  default: return heff_nomatch(v_x1_24567);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args) {
  V v_d_24551 = args[0];
  V v_a_24552 = args[1];
  V v_x1_24553 = heff_tr(heff_call(v_a_24552, 1, (V[]){v_d_24551}));
  switch (heff_tag_of(v_x1_24553)) {
  case TAG_Ok: {
    V v_v_24554 = heff_field(v_x1_24553, 0);
    V v_ru_24x1_24553_24Ok = heff_take_reuse_n(v_x1_24553, 1ULL, 1);
    switch (heff_tag_of(v_v_24554)) {
    case TAG_VFun: {
      heff_take_n(v_v_24554, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24554, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24554, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24554, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24554, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24554, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24554, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24554, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24564 = heff_field(v_v_24554, 0);
      heff_take_n(v_v_24554, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24553_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam47, 2, 1, (V[]){v_xs_24564})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24554, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24554, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24554);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24606 = heff_field(v_x1_24553, 0);
    V v_ru_24x1_24553_24Bug = heff_take_reuse_n(v_x1_24553, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24553_24Bug, TAG_Bug, 1, (V[]){v_what_24606});
  }
  default: return heff_nomatch(v_x1_24553);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args) {
  V v_d_24549 = args[0];
  V v_u_24550 = args[1];
  heff_drop(v_d_24549);
  heff_drop(v_u_24550);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam46_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args) {
  V v_d_24624 = args[0];
  V v_a_24625 = args[1];
  V v_xs_24623 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24626 = heff_tr(heff_call(v_a_24625, 1, (V[]){v_d_24624}));
  switch (heff_tag_of(v_x1_24626)) {
  case TAG_Ok: {
    V v_v_24627 = heff_field(v_x1_24626, 0);
    V v_ru_24x1_24626_24Ok = heff_take_reuse_n(v_x1_24626, 1ULL, 1);
    switch (heff_tag_of(v_v_24627)) {
    case TAG_VFun: {
      heff_take_n(v_v_24627, 0ULL, 1);
      heff_drop(v_xs_24623);
      heff_drop_cell(v_ru_24x1_24626_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24627, 0ULL, 1);
      heff_drop(v_xs_24623);
      heff_drop_cell(v_ru_24x1_24626_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24627, 0ULL, 2);
      heff_drop(v_xs_24623);
      heff_drop_cell(v_ru_24x1_24626_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24627, 0ULL, 1);
      heff_drop(v_xs_24623);
      heff_drop_cell(v_ru_24x1_24626_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24627, 0ULL, 1);
      heff_drop(v_xs_24623);
      heff_drop_cell(v_ru_24x1_24626_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24627, 0ULL, 1);
      heff_drop(v_xs_24623);
      heff_drop_cell(v_ru_24x1_24626_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24627, 0ULL, 1);
      heff_drop(v_xs_24623);
      heff_drop_cell(v_ru_24x1_24626_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24627, 0ULL, 1);
      heff_drop(v_xs_24623);
      heff_drop_cell(v_ru_24x1_24626_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24637 = heff_field(v_v_24627, 0);
      V v_ru_24v_24627_24VArr = heff_take_reuse_n(v_v_24627, 1ULL, 1);
      V v_t_24638 = (g_prelude_2e_2b_2b(heff_arrayToList(v_xs_24623), heff_arrayToList(v_xs_24637)));
      V v_t_24639 = heff_tag_at_n(v_ru_24v_24627_24VArr, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24638)});
      return heff_tag_at_n(v_ru_24x1_24626_24Ok, TAG_Ok, 1, (V[]){v_t_24639});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24627, 0ULL, 1);
      heff_drop(v_xs_24623);
      heff_drop_cell(v_ru_24x1_24626_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24627, 0ULL, 2);
      heff_drop(v_xs_24623);
      heff_drop_cell(v_ru_24x1_24626_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24623);
      heff_drop_cell(v_ru_24x1_24626_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24627);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24623);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24623);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24643 = heff_field(v_x1_24626, 0);
    V v_ru_24x1_24626_24Bug = heff_take_reuse_n(v_x1_24626, 1ULL, 1);
    heff_drop(v_xs_24623);
    return heff_tag_at_n(v_ru_24x1_24626_24Bug, TAG_Bug, 1, (V[]){v_what_24643});
  }
  default: return heff_nomatch(v_x1_24626);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args) {
  V v_d_24610 = args[0];
  V v_a_24611 = args[1];
  V v_x1_24612 = heff_tr(heff_call(v_a_24611, 1, (V[]){v_d_24610}));
  switch (heff_tag_of(v_x1_24612)) {
  case TAG_Ok: {
    V v_v_24613 = heff_field(v_x1_24612, 0);
    V v_ru_24x1_24612_24Ok = heff_take_reuse_n(v_x1_24612, 1ULL, 1);
    switch (heff_tag_of(v_v_24613)) {
    case TAG_VFun: {
      heff_take_n(v_v_24613, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24612_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24613, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24612_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24613, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24612_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24613, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24612_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24613, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24612_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24613, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24612_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24613, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24612_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24613, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24612_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24623 = heff_field(v_v_24613, 0);
      heff_take_n(v_v_24613, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24612_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam51, 2, 1, (V[]){v_xs_24623})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24613, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24612_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24613, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24612_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24612_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24613);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24647 = heff_field(v_x1_24612, 0);
    V v_ru_24x1_24612_24Bug = heff_take_reuse_n(v_x1_24612, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24612_24Bug, TAG_Bug, 1, (V[]){v_what_24647});
  }
  default: return heff_nomatch(v_x1_24612);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args) {
  V v_d_24608 = args[0];
  V v_u_24609 = args[1];
  heff_drop(v_d_24608);
  heff_drop(v_u_24609);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam50_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args) {
  V v_d_24650 = args[0];
  V v_a_24651 = args[1];
  V v_x1_24652 = heff_tr(heff_call(v_a_24651, 1, (V[]){v_d_24650}));
  switch (heff_tag_of(v_x1_24652)) {
  case TAG_Ok: {
    V v_v_24653 = heff_field(v_x1_24652, 0);
    V v_ru_24x1_24652_24Ok = heff_take_reuse_n(v_x1_24652, 1ULL, 1);
    switch (heff_tag_of(v_v_24653)) {
    case TAG_VFun: {
      heff_take_n(v_v_24653, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24652_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24653, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24652_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24653, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24652_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24653, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24652_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24653, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24652_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24653, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24652_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24661 = heff_field(v_v_24653, 0);
      V v_ru_24v_24653_24VStr = heff_take_reuse_n(v_v_24653, 1ULL, 1);
      V v_t_24662 = heff_tag_at_n(v_ru_24v_24653_24VStr, TAG_VInt, 1, (V[]){heff_strLength(v_a_24661)});
      return heff_tag_at_n(v_ru_24x1_24652_24Ok, TAG_Ok, 1, (V[]){v_t_24662});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24653, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24652_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24653, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24652_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24653, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24652_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24653, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24652_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24652_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24653);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24668 = heff_field(v_x1_24652, 0);
    V v_ru_24x1_24652_24Bug = heff_take_reuse_n(v_x1_24652, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24652_24Bug, TAG_Bug, 1, (V[]){v_what_24668});
  }
  default: return heff_nomatch(v_x1_24652);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args) {
  V v_d_24691 = args[0];
  V v_a_24692 = args[1];
  V v_a_24681 = heff_env(self)[0];
  V v_a_24690 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24693 = heff_tr(heff_call(v_a_24692, 1, (V[]){v_d_24691}));
  switch (heff_tag_of(v_x1_24693)) {
  case TAG_Ok: {
    V v_v_24694 = heff_field(v_x1_24693, 0);
    V v_ru_24x1_24693_24Ok = heff_take_reuse_n(v_x1_24693, 1ULL, 1);
    switch (heff_tag_of(v_v_24694)) {
    case TAG_VFun: {
      heff_take_n(v_v_24694, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop(v_a_24690);
      heff_drop_cell(v_ru_24x1_24693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24694, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop(v_a_24690);
      heff_drop_cell(v_ru_24x1_24693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24694, 0ULL, 2);
      heff_drop(v_a_24681);
      heff_drop(v_a_24690);
      heff_drop_cell(v_ru_24x1_24693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24699 = heff_field(v_v_24694, 0);
      V v_ru_24v_24694_24VInt = heff_take_reuse_n(v_v_24694, 1ULL, 1);
      V v_t_24700 = heff_tag_at_n(v_ru_24v_24694_24VInt, TAG_VStr, 1, (V[]){heff_strSlice(v_a_24681, v_a_24690, v_a_24699)});
      return heff_tag_at_n(v_ru_24x1_24693_24Ok, TAG_Ok, 1, (V[]){v_t_24700});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24694, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop(v_a_24690);
      heff_drop_cell(v_ru_24x1_24693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24694, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop(v_a_24690);
      heff_drop_cell(v_ru_24x1_24693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24694, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop(v_a_24690);
      heff_drop_cell(v_ru_24x1_24693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24694, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop(v_a_24690);
      heff_drop_cell(v_ru_24x1_24693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24694, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop(v_a_24690);
      heff_drop_cell(v_ru_24x1_24693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24694, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop(v_a_24690);
      heff_drop_cell(v_ru_24x1_24693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24694, 0ULL, 2);
      heff_drop(v_a_24681);
      heff_drop(v_a_24690);
      heff_drop_cell(v_ru_24x1_24693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24681);
      heff_drop(v_a_24690);
      heff_drop_cell(v_ru_24x1_24693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24694);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24681);
    heff_drop(v_a_24690);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24681);
    heff_drop(v_a_24690);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24709 = heff_field(v_x1_24693, 0);
    V v_ru_24x1_24693_24Bug = heff_take_reuse_n(v_x1_24693, 1ULL, 1);
    heff_drop(v_a_24681);
    heff_drop(v_a_24690);
    return heff_tag_at_n(v_ru_24x1_24693_24Bug, TAG_Bug, 1, (V[]){v_what_24709});
  }
  default: return heff_nomatch(v_x1_24693);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args) {
  V v_d_24682 = args[0];
  V v_a_24683 = args[1];
  V v_a_24681 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24684 = heff_tr(heff_call(v_a_24683, 1, (V[]){v_d_24682}));
  switch (heff_tag_of(v_x1_24684)) {
  case TAG_Ok: {
    V v_v_24685 = heff_field(v_x1_24684, 0);
    V v_ru_24x1_24684_24Ok = heff_take_reuse_n(v_x1_24684, 1ULL, 1);
    switch (heff_tag_of(v_v_24685)) {
    case TAG_VFun: {
      heff_take_n(v_v_24685, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop_cell(v_ru_24x1_24684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24685, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop_cell(v_ru_24x1_24684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24685, 0ULL, 2);
      heff_drop(v_a_24681);
      heff_drop_cell(v_ru_24x1_24684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24690 = heff_field(v_v_24685, 0);
      heff_take_n(v_v_24685, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24684_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam55, 2, 2, (V[]){v_a_24681, v_a_24690})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24685, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop_cell(v_ru_24x1_24684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24685, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop_cell(v_ru_24x1_24684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24685, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop_cell(v_ru_24x1_24684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24685, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop_cell(v_ru_24x1_24684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24685, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop_cell(v_ru_24x1_24684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24685, 0ULL, 1);
      heff_drop(v_a_24681);
      heff_drop_cell(v_ru_24x1_24684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24685, 0ULL, 2);
      heff_drop(v_a_24681);
      heff_drop_cell(v_ru_24x1_24684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24681);
      heff_drop_cell(v_ru_24x1_24684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24685);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24681);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24681);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24718 = heff_field(v_x1_24684, 0);
    V v_ru_24x1_24684_24Bug = heff_take_reuse_n(v_x1_24684, 1ULL, 1);
    heff_drop(v_a_24681);
    return heff_tag_at_n(v_ru_24x1_24684_24Bug, TAG_Bug, 1, (V[]){v_what_24718});
  }
  default: return heff_nomatch(v_x1_24684);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args) {
  V v_d_24670 = args[0];
  V v_a_24671 = args[1];
  V v_x1_24672 = heff_tr(heff_call(v_a_24671, 1, (V[]){v_d_24670}));
  switch (heff_tag_of(v_x1_24672)) {
  case TAG_Ok: {
    V v_v_24673 = heff_field(v_x1_24672, 0);
    V v_ru_24x1_24672_24Ok = heff_take_reuse_n(v_x1_24672, 1ULL, 1);
    switch (heff_tag_of(v_v_24673)) {
    case TAG_VFun: {
      heff_take_n(v_v_24673, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24672_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24673, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24672_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24673, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24672_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24673, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24672_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24673, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24672_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24673, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24672_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24681 = heff_field(v_v_24673, 0);
      heff_take_n(v_v_24673, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24672_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam54, 2, 1, (V[]){v_a_24681})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24673, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24672_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24673, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24672_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24673, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24672_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24673, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24672_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24672_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24673);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24724 = heff_field(v_x1_24672, 0);
    V v_ru_24x1_24672_24Bug = heff_take_reuse_n(v_x1_24672, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24672_24Bug, TAG_Bug, 1, (V[]){v_what_24724});
  }
  default: return heff_nomatch(v_x1_24672);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args) {
  V v_a_24726 = args[0];
  V v_b_24727 = args[1];
  V v_t_24729;
  if (heff_strEq_c(v_a_24726, v_b_24727)) {
    v_t_24729 = ((V)&g_heff_2ecompile_2einterp_2eprim_str61);
  } else {
    v_t_24729 = ((V)&g_heff_2ecompile_2einterp_2eprim_str62);
  }
  V v_t_24730 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24729, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24730});
}
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args) {
  V v_a_24732 = args[0];
  V v_b_24733 = args[1];
  V v_t_24735;
  if (heff_strLt_c(v_a_24732, v_b_24733)) {
    v_t_24735 = ((V)&g_heff_2ecompile_2einterp_2eprim_str64);
  } else {
    v_t_24735 = ((V)&g_heff_2ecompile_2einterp_2eprim_str65);
  }
  V v_t_24736 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24735, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24736});
}
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args) {
  V v_a_24738 = args[0];
  V v_b_24739 = args[1];
  V v_t_24742;
  if (heff_strLt_c_lent(v_a_24738, v_b_24739, 0)) {
    heff_drop(v_a_24738);
    heff_drop(v_b_24739);
    v_t_24742 = MK_INT(-1LL);
  } else {
    if (heff_strEq_c(v_a_24738, v_b_24739)) {
      v_t_24742 = MK_INT(0LL);
    } else {
      v_t_24742 = MK_INT(1LL);
    }
  }
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24742})});
}
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args) {
  V v_d_24744 = args[0];
  V v_a_24745 = args[1];
  V v_x1_24746 = heff_tr(heff_call(v_a_24745, 1, (V[]){v_d_24744}));
  switch (heff_tag_of(v_x1_24746)) {
  case TAG_Ok: {
    V v_v_24747 = heff_field(v_x1_24746, 0);
    V v_ru_24x1_24746_24Ok = heff_take_reuse_n(v_x1_24746, 1ULL, 1);
    switch (heff_tag_of(v_v_24747)) {
    case TAG_VFun: {
      heff_take_n(v_v_24747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24747, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24755 = heff_field(v_v_24747, 0);
      V v_ru_24v_24747_24VStr = heff_take_reuse_n(v_v_24747, 1ULL, 1);
      V v_t_24756 = ({ V a_0 = v_a_24755; V a_1 = MK_INT(0LL); V a_2 = heff_strLength_lent(v_a_24755, 0); V r_ = (g_heff_2ecompile_2einterp_2ehashFrom(a_0, a_1, a_2)); heff_drop(v_a_24755); r_; });
      V v_t_24757 = (g_heff_2ecompile_2einterp_2efmix64(v_t_24756));
      V v_t_24758 = heff_tag_at_n(v_ru_24v_24747_24VStr, TAG_VInt, 1, (V[]){heff_intDiv(v_t_24757, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_24746_24Ok, TAG_Ok, 1, (V[]){v_t_24758});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24747, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24747);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24764 = heff_field(v_x1_24746, 0);
    V v_ru_24x1_24746_24Bug = heff_take_reuse_n(v_x1_24746, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24746_24Bug, TAG_Bug, 1, (V[]){v_what_24764});
  }
  default: return heff_nomatch(v_x1_24746);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args) {
  V v_d_24766 = args[0];
  V v_a_24767 = args[1];
  V v_x1_24768 = heff_tr(heff_call(v_a_24767, 1, (V[]){v_d_24766}));
  switch (heff_tag_of(v_x1_24768)) {
  case TAG_Ok: {
    V v_v_24769 = heff_field(v_x1_24768, 0);
    V v_ru_24x1_24768_24Ok = heff_take_reuse_n(v_x1_24768, 1ULL, 1);
    switch (heff_tag_of(v_v_24769)) {
    case TAG_VFun: {
      heff_take_n(v_v_24769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24769, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24774 = heff_field(v_v_24769, 0);
      V v_ru_24v_24769_24VInt = heff_take_reuse_n(v_v_24769, 1ULL, 1);
      V v_t_24775 = heff_intAdd(heff_intMod(v_a_24774, heff_dup(g_heff_2ecompile_2einterp_2eword64_get())), heff_dup(g_heff_2ecompile_2einterp_2eword64_get()));
      V v_t_24776 = (g_heff_2ecompile_2einterp_2efmix64(heff_intMod(v_t_24775, heff_dup(g_heff_2ecompile_2einterp_2eword64_get()))));
      V v_t_24777 = heff_tag_at_n(v_ru_24v_24769_24VInt, TAG_VInt, 1, (V[]){heff_intDiv(v_t_24776, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_24768_24Ok, TAG_Ok, 1, (V[]){v_t_24777});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24769, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24769);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24786 = heff_field(v_x1_24768, 0);
    V v_ru_24x1_24768_24Bug = heff_take_reuse_n(v_x1_24768, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24768_24Bug, TAG_Bug, 1, (V[]){v_what_24786});
  }
  default: return heff_nomatch(v_x1_24768);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args) {
  V v_d_24806 = args[0];
  V v_a_24807 = args[1];
  V v_a_24796 = heff_env(self)[0];
  V v_a_24805 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24808 = heff_tr(heff_call(v_a_24807, 1, (V[]){v_d_24806}));
  switch (heff_tag_of(v_x1_24808)) {
  case TAG_Ok: {
    V v_v_24809 = heff_field(v_x1_24808, 0);
    V v_ru_24x1_24808_24Ok = heff_take_reuse_n(v_x1_24808, 1ULL, 1);
    switch (heff_tag_of(v_v_24809)) {
    case TAG_VFun: {
      heff_take_n(v_v_24809, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop(v_a_24805);
      heff_drop_cell(v_ru_24x1_24808_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24809, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop(v_a_24805);
      heff_drop_cell(v_ru_24x1_24808_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24809, 0ULL, 2);
      heff_drop(v_a_24796);
      heff_drop(v_a_24805);
      heff_drop_cell(v_ru_24x1_24808_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24814 = heff_field(v_v_24809, 0);
      heff_take_n(v_v_24809, 1ULL, 1);
      V v_t_24815 = (g_heff_2ecompile_2einterp_2etrieSlotOf(v_a_24796, v_a_24805, v_a_24814));
      return heff_tag_at_n(v_ru_24x1_24808_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24815})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24809, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop(v_a_24805);
      heff_drop_cell(v_ru_24x1_24808_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24809, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop(v_a_24805);
      heff_drop_cell(v_ru_24x1_24808_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24809, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop(v_a_24805);
      heff_drop_cell(v_ru_24x1_24808_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24809, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop(v_a_24805);
      heff_drop_cell(v_ru_24x1_24808_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24809, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop(v_a_24805);
      heff_drop_cell(v_ru_24x1_24808_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24809, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop(v_a_24805);
      heff_drop_cell(v_ru_24x1_24808_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24809, 0ULL, 2);
      heff_drop(v_a_24796);
      heff_drop(v_a_24805);
      heff_drop_cell(v_ru_24x1_24808_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24796);
      heff_drop(v_a_24805);
      heff_drop_cell(v_ru_24x1_24808_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24809);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24796);
    heff_drop(v_a_24805);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24796);
    heff_drop(v_a_24805);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24824 = heff_field(v_x1_24808, 0);
    V v_ru_24x1_24808_24Bug = heff_take_reuse_n(v_x1_24808, 1ULL, 1);
    heff_drop(v_a_24796);
    heff_drop(v_a_24805);
    return heff_tag_at_n(v_ru_24x1_24808_24Bug, TAG_Bug, 1, (V[]){v_what_24824});
  }
  default: return heff_nomatch(v_x1_24808);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args) {
  V v_d_24797 = args[0];
  V v_a_24798 = args[1];
  V v_a_24796 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24799 = heff_tr(heff_call(v_a_24798, 1, (V[]){v_d_24797}));
  switch (heff_tag_of(v_x1_24799)) {
  case TAG_Ok: {
    V v_v_24800 = heff_field(v_x1_24799, 0);
    V v_ru_24x1_24799_24Ok = heff_take_reuse_n(v_x1_24799, 1ULL, 1);
    switch (heff_tag_of(v_v_24800)) {
    case TAG_VFun: {
      heff_take_n(v_v_24800, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop_cell(v_ru_24x1_24799_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24800, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop_cell(v_ru_24x1_24799_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24800, 0ULL, 2);
      heff_drop(v_a_24796);
      heff_drop_cell(v_ru_24x1_24799_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24805 = heff_field(v_v_24800, 0);
      heff_take_n(v_v_24800, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24799_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam63, 2, 2, (V[]){v_a_24796, v_a_24805})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24800, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop_cell(v_ru_24x1_24799_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24800, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop_cell(v_ru_24x1_24799_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24800, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop_cell(v_ru_24x1_24799_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24800, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop_cell(v_ru_24x1_24799_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24800, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop_cell(v_ru_24x1_24799_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24800, 0ULL, 1);
      heff_drop(v_a_24796);
      heff_drop_cell(v_ru_24x1_24799_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24800, 0ULL, 2);
      heff_drop(v_a_24796);
      heff_drop_cell(v_ru_24x1_24799_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24796);
      heff_drop_cell(v_ru_24x1_24799_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24800);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24796);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24796);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24833 = heff_field(v_x1_24799, 0);
    V v_ru_24x1_24799_24Bug = heff_take_reuse_n(v_x1_24799, 1ULL, 1);
    heff_drop(v_a_24796);
    return heff_tag_at_n(v_ru_24x1_24799_24Bug, TAG_Bug, 1, (V[]){v_what_24833});
  }
  default: return heff_nomatch(v_x1_24799);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args) {
  V v_d_24788 = args[0];
  V v_a_24789 = args[1];
  V v_x1_24790 = heff_tr(heff_call(v_a_24789, 1, (V[]){v_d_24788}));
  switch (heff_tag_of(v_x1_24790)) {
  case TAG_Ok: {
    V v_v_24791 = heff_field(v_x1_24790, 0);
    V v_ru_24x1_24790_24Ok = heff_take_reuse_n(v_x1_24790, 1ULL, 1);
    switch (heff_tag_of(v_v_24791)) {
    case TAG_VFun: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24791, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24796 = heff_field(v_v_24791, 0);
      heff_take_n(v_v_24791, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24790_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam62, 2, 1, (V[]){v_a_24796})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24791, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24791, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24791);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24842 = heff_field(v_x1_24790, 0);
    V v_ru_24x1_24790_24Bug = heff_take_reuse_n(v_x1_24790, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24790_24Bug, TAG_Bug, 1, (V[]){v_what_24842});
  }
  default: return heff_nomatch(v_x1_24790);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args) {
  V v_d_24846 = args[0];
  V v_a_24847 = args[1];
  V v_n_24844 = heff_env(self)[0];
  V v_a_24845 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24848 = heff_tr(heff_call(v_a_24847, 1, (V[]){v_d_24846}));
  switch (heff_tag_of(v_x1_24848)) {
  case TAG_Ok: {
    V v_v_24849 = heff_field(v_x1_24848, 0);
    V v_ru_24x1_24848_24Ok = heff_take_reuse_n(v_x1_24848, 1ULL, 1);
    switch (heff_tag_of(v_v_24849)) {
    case TAG_VFun: {
      heff_take_n(v_v_24849, 0ULL, 1);
      heff_drop(v_n_24844);
      heff_drop(v_a_24845);
      heff_drop_cell(v_ru_24x1_24848_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24849, 0ULL, 1);
      heff_drop(v_n_24844);
      heff_drop(v_a_24845);
      heff_drop_cell(v_ru_24x1_24848_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24849, 0ULL, 2);
      heff_drop(v_n_24844);
      heff_drop(v_a_24845);
      heff_drop_cell(v_ru_24x1_24848_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24854 = heff_field(v_v_24849, 0);
      heff_take_n(v_v_24849, 1ULL, 1);
      V v_t_24856;
      if (heff_intLe_c_lent(MK_INT(0LL), v_a_24854, 1)) {
        v_t_24856 = v_a_24854;
      } else {
        heff_drop(v_a_24854);
        v_t_24856 = MK_INT(0LL);
      }
      V v_j_24857 = heff_strFind(v_n_24844, v_a_24845, v_t_24856);
      V v_t_24859;
      if (heff_intLt_c_lent(v_j_24857, MK_INT(0LL), 2)) {
        heff_drop(v_j_24857);
        v_t_24859 = MK_INT(-1LL);
      } else {
        v_t_24859 = v_j_24857;
      }
      return heff_tag_at_n(v_ru_24x1_24848_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24859})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24849, 0ULL, 1);
      heff_drop(v_n_24844);
      heff_drop(v_a_24845);
      heff_drop_cell(v_ru_24x1_24848_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24849, 0ULL, 1);
      heff_drop(v_n_24844);
      heff_drop(v_a_24845);
      heff_drop_cell(v_ru_24x1_24848_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24849, 0ULL, 1);
      heff_drop(v_n_24844);
      heff_drop(v_a_24845);
      heff_drop_cell(v_ru_24x1_24848_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24849, 0ULL, 1);
      heff_drop(v_n_24844);
      heff_drop(v_a_24845);
      heff_drop_cell(v_ru_24x1_24848_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24849, 0ULL, 1);
      heff_drop(v_n_24844);
      heff_drop(v_a_24845);
      heff_drop_cell(v_ru_24x1_24848_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24849, 0ULL, 1);
      heff_drop(v_n_24844);
      heff_drop(v_a_24845);
      heff_drop_cell(v_ru_24x1_24848_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24849, 0ULL, 2);
      heff_drop(v_n_24844);
      heff_drop(v_a_24845);
      heff_drop_cell(v_ru_24x1_24848_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_n_24844);
      heff_drop(v_a_24845);
      heff_drop_cell(v_ru_24x1_24848_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24849);
    }
  }
  case TAG_Abn: {
    heff_drop(v_n_24844);
    heff_drop(v_a_24845);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_n_24844);
    heff_drop(v_a_24845);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24868 = heff_field(v_x1_24848, 0);
    V v_ru_24x1_24848_24Bug = heff_take_reuse_n(v_x1_24848, 1ULL, 1);
    heff_drop(v_n_24844);
    heff_drop(v_a_24845);
    return heff_tag_at_n(v_ru_24x1_24848_24Bug, TAG_Bug, 1, (V[]){v_what_24868});
  }
  default: return heff_nomatch(v_x1_24848);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args) {
  V v_n_24844 = args[0];
  V v_a_24845 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam65, 2, 2, (V[]){v_n_24844, v_a_24845})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args) {
  V v_d_24882 = args[0];
  V v_a_24883 = args[1];
  V v_a_24881 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24884 = heff_tr(heff_call(v_a_24883, 1, (V[]){v_d_24882}));
  switch (heff_tag_of(v_x1_24884)) {
  case TAG_Ok: {
    V v_v_24885 = heff_field(v_x1_24884, 0);
    V v_ru_24x1_24884_24Ok = heff_take_reuse_n(v_x1_24884, 1ULL, 1);
    switch (heff_tag_of(v_v_24885)) {
    case TAG_VFun: {
      heff_take_n(v_v_24885, 0ULL, 1);
      heff_drop(v_a_24881);
      heff_drop_cell(v_ru_24x1_24884_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24885, 0ULL, 1);
      heff_drop(v_a_24881);
      heff_drop_cell(v_ru_24x1_24884_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24885, 0ULL, 2);
      heff_drop(v_a_24881);
      heff_drop_cell(v_ru_24x1_24884_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24890 = heff_field(v_v_24885, 0);
      V v_ru_24v_24885_24VInt = heff_take_reuse_n(v_v_24885, 1ULL, 1);
      V v_t_24891 = heff_tag_at_n(v_ru_24v_24885_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_24881, v_a_24890)});
      return heff_tag_at_n(v_ru_24x1_24884_24Ok, TAG_Ok, 1, (V[]){v_t_24891});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24885, 0ULL, 1);
      heff_drop(v_a_24881);
      heff_drop_cell(v_ru_24x1_24884_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24885, 0ULL, 1);
      heff_drop(v_a_24881);
      heff_drop_cell(v_ru_24x1_24884_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24885, 0ULL, 1);
      heff_drop(v_a_24881);
      heff_drop_cell(v_ru_24x1_24884_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24885, 0ULL, 1);
      heff_drop(v_a_24881);
      heff_drop_cell(v_ru_24x1_24884_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24885, 0ULL, 1);
      heff_drop(v_a_24881);
      heff_drop_cell(v_ru_24x1_24884_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24885, 0ULL, 1);
      heff_drop(v_a_24881);
      heff_drop_cell(v_ru_24x1_24884_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24885, 0ULL, 2);
      heff_drop(v_a_24881);
      heff_drop_cell(v_ru_24x1_24884_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24881);
      heff_drop_cell(v_ru_24x1_24884_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24885);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24881);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24881);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24900 = heff_field(v_x1_24884, 0);
    V v_ru_24x1_24884_24Bug = heff_take_reuse_n(v_x1_24884, 1ULL, 1);
    heff_drop(v_a_24881);
    return heff_tag_at_n(v_ru_24x1_24884_24Bug, TAG_Bug, 1, (V[]){v_what_24900});
  }
  default: return heff_nomatch(v_x1_24884);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args) {
  V v_d_24870 = args[0];
  V v_a_24871 = args[1];
  V v_x1_24872 = heff_tr(heff_call(v_a_24871, 1, (V[]){v_d_24870}));
  switch (heff_tag_of(v_x1_24872)) {
  case TAG_Ok: {
    V v_v_24873 = heff_field(v_x1_24872, 0);
    V v_ru_24x1_24872_24Ok = heff_take_reuse_n(v_x1_24872, 1ULL, 1);
    switch (heff_tag_of(v_v_24873)) {
    case TAG_VFun: {
      heff_take_n(v_v_24873, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24872_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24873, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24872_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24873, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24872_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24873, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24872_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24873, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24872_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24873, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24872_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24881 = heff_field(v_v_24873, 0);
      heff_take_n(v_v_24873, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24872_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam67, 2, 1, (V[]){v_a_24881})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24873, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24872_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24873, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24872_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24873, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24872_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24873, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24872_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24872_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24873);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24906 = heff_field(v_x1_24872, 0);
    V v_ru_24x1_24872_24Bug = heff_take_reuse_n(v_x1_24872, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24872_24Bug, TAG_Bug, 1, (V[]){v_what_24906});
  }
  default: return heff_nomatch(v_x1_24872);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args) {
  V v_d_24908 = args[0];
  V v_a_24909 = args[1];
  V v_x1_24910 = heff_tr(heff_call(v_a_24909, 1, (V[]){v_d_24908}));
  switch (heff_tag_of(v_x1_24910)) {
  case TAG_Ok: {
    V v_v_24911 = heff_field(v_x1_24910, 0);
    V v_ru_24x1_24910_24Ok = heff_take_reuse_n(v_x1_24910, 1ULL, 1);
    switch (heff_tag_of(v_v_24911)) {
    case TAG_VFun: {
      heff_take_n(v_v_24911, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24910_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24911, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24910_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24911, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24910_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24916 = heff_field(v_v_24911, 0);
      heff_take_n(v_v_24911, 1ULL, 1);
      V v_t_24917 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_a_24916)));
      return heff_tag_at_n(v_ru_24x1_24910_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_24917})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24911, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24910_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24911, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24910_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24911, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24910_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24911, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24910_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24911, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24910_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24911, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24910_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24911, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24910_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24910_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24911);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24926 = heff_field(v_x1_24910, 0);
    V v_ru_24x1_24910_24Bug = heff_take_reuse_n(v_x1_24910, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24910_24Bug, TAG_Bug, 1, (V[]){v_what_24926});
  }
  default: return heff_nomatch(v_x1_24910);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args) {
  V v_d_24940 = args[0];
  V v_a_24941 = args[1];
  V v_a_24939 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24942 = heff_tr(heff_call(v_a_24941, 1, (V[]){v_d_24940}));
  switch (heff_tag_of(v_x1_24942)) {
  case TAG_Ok: {
    V v_v_24943 = heff_field(v_x1_24942, 0);
    V v_ru_24x1_24942_24Ok = heff_take_reuse_n(v_x1_24942, 1ULL, 1);
    switch (heff_tag_of(v_v_24943)) {
    case TAG_VFun: {
      heff_take_n(v_v_24943, 0ULL, 1);
      heff_drop(v_a_24939);
      heff_drop_cell(v_ru_24x1_24942_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24943, 0ULL, 1);
      heff_drop(v_a_24939);
      heff_drop_cell(v_ru_24x1_24942_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24943, 0ULL, 2);
      heff_drop(v_a_24939);
      heff_drop_cell(v_ru_24x1_24942_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24948 = heff_field(v_v_24943, 0);
      heff_take_n(v_v_24943, 1ULL, 1);
      V v_t_24949 = heff_runeToInt(heff_strRuneAt(v_a_24939, v_a_24948));
      return heff_tag_at_n(v_ru_24x1_24942_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VRune, 1, (V[]){v_t_24949})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24943, 0ULL, 1);
      heff_drop(v_a_24939);
      heff_drop_cell(v_ru_24x1_24942_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24943, 0ULL, 1);
      heff_drop(v_a_24939);
      heff_drop_cell(v_ru_24x1_24942_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24943, 0ULL, 1);
      heff_drop(v_a_24939);
      heff_drop_cell(v_ru_24x1_24942_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24943, 0ULL, 1);
      heff_drop(v_a_24939);
      heff_drop_cell(v_ru_24x1_24942_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24943, 0ULL, 1);
      heff_drop(v_a_24939);
      heff_drop_cell(v_ru_24x1_24942_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24943, 0ULL, 1);
      heff_drop(v_a_24939);
      heff_drop_cell(v_ru_24x1_24942_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24943, 0ULL, 2);
      heff_drop(v_a_24939);
      heff_drop_cell(v_ru_24x1_24942_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24939);
      heff_drop_cell(v_ru_24x1_24942_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24943);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24939);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24939);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24958 = heff_field(v_x1_24942, 0);
    V v_ru_24x1_24942_24Bug = heff_take_reuse_n(v_x1_24942, 1ULL, 1);
    heff_drop(v_a_24939);
    return heff_tag_at_n(v_ru_24x1_24942_24Bug, TAG_Bug, 1, (V[]){v_what_24958});
  }
  default: return heff_nomatch(v_x1_24942);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args) {
  V v_d_24928 = args[0];
  V v_a_24929 = args[1];
  V v_x1_24930 = heff_tr(heff_call(v_a_24929, 1, (V[]){v_d_24928}));
  switch (heff_tag_of(v_x1_24930)) {
  case TAG_Ok: {
    V v_v_24931 = heff_field(v_x1_24930, 0);
    V v_ru_24x1_24930_24Ok = heff_take_reuse_n(v_x1_24930, 1ULL, 1);
    switch (heff_tag_of(v_v_24931)) {
    case TAG_VFun: {
      heff_take_n(v_v_24931, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24930_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24931, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24930_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24931, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24930_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24931, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24930_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24931, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24930_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24931, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24930_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24939 = heff_field(v_v_24931, 0);
      heff_take_n(v_v_24931, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24930_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam70, 2, 1, (V[]){v_a_24939})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24931, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24930_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24931, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24930_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24931, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24930_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24931, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24930_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24930_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24931);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24964 = heff_field(v_x1_24930, 0);
    V v_ru_24x1_24930_24Bug = heff_take_reuse_n(v_x1_24930, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24930_24Bug, TAG_Bug, 1, (V[]){v_what_24964});
  }
  default: return heff_nomatch(v_x1_24930);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args) {
  V v_d_24978 = args[0];
  V v_a_24979 = args[1];
  V v_a_24977 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24980 = heff_tr(heff_call(v_a_24979, 1, (V[]){v_d_24978}));
  switch (heff_tag_of(v_x1_24980)) {
  case TAG_Ok: {
    V v_v_24981 = heff_field(v_x1_24980, 0);
    V v_ru_24x1_24980_24Ok = heff_take_reuse_n(v_x1_24980, 1ULL, 1);
    switch (heff_tag_of(v_v_24981)) {
    case TAG_VFun: {
      heff_take_n(v_v_24981, 0ULL, 1);
      heff_drop(v_a_24977);
      heff_drop_cell(v_ru_24x1_24980_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24981, 0ULL, 1);
      heff_drop(v_a_24977);
      heff_drop_cell(v_ru_24x1_24980_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24981, 0ULL, 2);
      heff_drop(v_a_24977);
      heff_drop_cell(v_ru_24x1_24980_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24986 = heff_field(v_v_24981, 0);
      V v_ru_24v_24981_24VInt = heff_take_reuse_n(v_v_24981, 1ULL, 1);
      V v_t_24987 = heff_tag_at_n(v_ru_24v_24981_24VInt, TAG_VInt, 1, (V[]){heff_strRuneWidth(v_a_24977, v_a_24986)});
      return heff_tag_at_n(v_ru_24x1_24980_24Ok, TAG_Ok, 1, (V[]){v_t_24987});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24981, 0ULL, 1);
      heff_drop(v_a_24977);
      heff_drop_cell(v_ru_24x1_24980_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24981, 0ULL, 1);
      heff_drop(v_a_24977);
      heff_drop_cell(v_ru_24x1_24980_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24981, 0ULL, 1);
      heff_drop(v_a_24977);
      heff_drop_cell(v_ru_24x1_24980_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24981, 0ULL, 1);
      heff_drop(v_a_24977);
      heff_drop_cell(v_ru_24x1_24980_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24981, 0ULL, 1);
      heff_drop(v_a_24977);
      heff_drop_cell(v_ru_24x1_24980_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24981, 0ULL, 1);
      heff_drop(v_a_24977);
      heff_drop_cell(v_ru_24x1_24980_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24981, 0ULL, 2);
      heff_drop(v_a_24977);
      heff_drop_cell(v_ru_24x1_24980_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24977);
      heff_drop_cell(v_ru_24x1_24980_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24981);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24977);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24977);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24996 = heff_field(v_x1_24980, 0);
    V v_ru_24x1_24980_24Bug = heff_take_reuse_n(v_x1_24980, 1ULL, 1);
    heff_drop(v_a_24977);
    return heff_tag_at_n(v_ru_24x1_24980_24Bug, TAG_Bug, 1, (V[]){v_what_24996});
  }
  default: return heff_nomatch(v_x1_24980);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args) {
  V v_d_24966 = args[0];
  V v_a_24967 = args[1];
  V v_x1_24968 = heff_tr(heff_call(v_a_24967, 1, (V[]){v_d_24966}));
  switch (heff_tag_of(v_x1_24968)) {
  case TAG_Ok: {
    V v_v_24969 = heff_field(v_x1_24968, 0);
    V v_ru_24x1_24968_24Ok = heff_take_reuse_n(v_x1_24968, 1ULL, 1);
    switch (heff_tag_of(v_v_24969)) {
    case TAG_VFun: {
      heff_take_n(v_v_24969, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24968_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24969, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24968_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24969, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24968_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24969, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24968_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24969, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24968_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24969, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24968_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24977 = heff_field(v_v_24969, 0);
      heff_take_n(v_v_24969, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24968_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam72, 2, 1, (V[]){v_a_24977})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24969, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24968_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24969, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24968_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24969, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24968_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24969, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24968_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24968_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24969);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241002 = heff_field(v_x1_24968, 0);
    V v_ru_24x1_24968_24Bug = heff_take_reuse_n(v_x1_24968, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24968_24Bug, TAG_Bug, 1, (V[]){v_what_241002});
  }
  default: return heff_nomatch(v_x1_24968);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args) {
  V v_d_241004 = args[0];
  V v_a_241005 = args[1];
  V v_x1_241006 = heff_tr(heff_call(v_a_241005, 1, (V[]){v_d_241004}));
  switch (heff_tag_of(v_x1_241006)) {
  case TAG_Ok: {
    V v_v_241007 = heff_field(v_x1_241006, 0);
    V v_ru_24x1_241006_24Ok = heff_take_reuse_n(v_x1_241006, 1ULL, 1);
    switch (heff_tag_of(v_v_241007)) {
    case TAG_VFun: {
      heff_take_n(v_v_241007, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241006_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241007, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241006_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241007, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241006_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241007, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241006_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241007, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241006_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241007, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241006_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241015 = heff_field(v_v_241007, 0);
      V v_ru_24v_241007_24VStr = heff_take_reuse_n(v_v_241007, 1ULL, 1);
      V v_t_241016 = heff_tag_at_n(v_ru_24v_241007_24VStr, TAG_VInt, 1, (V[]){heff_strRuneCount(v_a_241015)});
      return heff_tag_at_n(v_ru_24x1_241006_24Ok, TAG_Ok, 1, (V[]){v_t_241016});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241007, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241006_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241007, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241006_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241007, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241006_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241007, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241006_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241006_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241007);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241022 = heff_field(v_x1_241006, 0);
    V v_ru_24x1_241006_24Bug = heff_take_reuse_n(v_x1_241006, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241006_24Bug, TAG_Bug, 1, (V[]){v_what_241022});
  }
  default: return heff_nomatch(v_x1_241006);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args) {
  V v_d_241024 = args[0];
  V v_a_241025 = args[1];
  V v_x1_241026 = heff_tr(heff_call(v_a_241025, 1, (V[]){v_d_241024}));
  switch (heff_tag_of(v_x1_241026)) {
  case TAG_Ok: {
    V v_v_241027 = heff_field(v_x1_241026, 0);
    V v_ru_24x1_241026_24Ok = heff_take_reuse_n(v_x1_241026, 1ULL, 1);
    switch (heff_tag_of(v_v_241027)) {
    case TAG_VFun: {
      heff_take_n(v_v_241027, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241026_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241027, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241026_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241027, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241026_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241027, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241026_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241027, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241026_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241027, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241026_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241035 = heff_field(v_v_241027, 0);
      heff_take_n(v_v_241027, 1ULL, 1);
      V v_t_241036 = heff_strOfRunes(heff_strRunes(v_a_241035));
      return heff_tag_at_n(v_ru_24x1_241026_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_241036})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241027, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241026_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241027, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241026_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241027, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241026_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241027, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241026_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241026_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241027);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241042 = heff_field(v_x1_241026, 0);
    V v_ru_24x1_241026_24Bug = heff_take_reuse_n(v_x1_241026, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241026_24Bug, TAG_Bug, 1, (V[]){v_what_241042});
  }
  default: return heff_nomatch(v_x1_241026);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args) {
  V v_d_241044 = args[0];
  V v_a_241045 = args[1];
  V v_x1_241046 = heff_tr(heff_call(v_a_241045, 1, (V[]){v_d_241044}));
  switch (heff_tag_of(v_x1_241046)) {
  case TAG_Ok: {
    V v_v_241047 = heff_field(v_x1_241046, 0);
    V v_ru_24x1_241046_24Ok = heff_take_reuse_n(v_x1_241046, 1ULL, 1);
    switch (heff_tag_of(v_v_241047)) {
    case TAG_VFun: {
      heff_take_n(v_v_241047, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241046_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241047, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241046_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241047, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241046_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241047, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241046_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241047, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241046_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241047, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241046_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241055 = heff_field(v_v_241047, 0);
      heff_take_n(v_v_241047, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241046_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_a_241055})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241047, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241046_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241047, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241046_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241047, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241046_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241047, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241046_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241046_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241047);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241061 = heff_field(v_x1_241046, 0);
    V v_ru_24x1_241046_24Bug = heff_take_reuse_n(v_x1_241046, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241046_24Bug, TAG_Bug, 1, (V[]){v_what_241061});
  }
  default: return heff_nomatch(v_x1_241046);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args) {
  V v_d_241063 = args[0];
  V v_a_241064 = args[1];
  V v_x1_241065 = heff_tr(heff_call(v_a_241064, 1, (V[]){v_d_241063}));
  switch (heff_tag_of(v_x1_241065)) {
  case TAG_Ok: {
    V v_v_241066 = heff_field(v_x1_241065, 0);
    V v_ru_24x1_241065_24Ok = heff_take_reuse_n(v_x1_241065, 1ULL, 1);
    switch (heff_tag_of(v_v_241066)) {
    case TAG_VFun: {
      heff_take_n(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241066, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241066, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241077 = heff_field(v_v_241066, 0);
      V v_ru_24v_241066_24VBytes = heff_take_reuse_n(v_v_241066, 1ULL, 1);
      V v_t_241078 = heff_tag_at_n(v_ru_24v_241066_24VBytes, TAG_VInt, 1, (V[]){heff_strLength(v_a_241077)});
      return heff_tag_at_n(v_ru_24x1_241065_24Ok, TAG_Ok, 1, (V[]){v_t_241078});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241066, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241065_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241066);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241081 = heff_field(v_x1_241065, 0);
    V v_ru_24x1_241065_24Bug = heff_take_reuse_n(v_x1_241065, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241065_24Bug, TAG_Bug, 1, (V[]){v_what_241081});
  }
  default: return heff_nomatch(v_x1_241065);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args) {
  V v_d_241098 = args[0];
  V v_a_241099 = args[1];
  V v_a_241097 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241100 = heff_tr(heff_call(v_a_241099, 1, (V[]){v_d_241098}));
  switch (heff_tag_of(v_x1_241100)) {
  case TAG_Ok: {
    V v_v_241101 = heff_field(v_x1_241100, 0);
    V v_ru_24x1_241100_24Ok = heff_take_reuse_n(v_x1_241100, 1ULL, 1);
    switch (heff_tag_of(v_v_241101)) {
    case TAG_VFun: {
      heff_take_n(v_v_241101, 0ULL, 1);
      heff_drop(v_a_241097);
      heff_drop_cell(v_ru_24x1_241100_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241101, 0ULL, 1);
      heff_drop(v_a_241097);
      heff_drop_cell(v_ru_24x1_241100_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241101, 0ULL, 2);
      heff_drop(v_a_241097);
      heff_drop_cell(v_ru_24x1_241100_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241106 = heff_field(v_v_241101, 0);
      V v_ru_24v_241101_24VInt = heff_take_reuse_n(v_v_241101, 1ULL, 1);
      if (heff_intLe_c_lent(MK_INT(0LL), v_a_241106, 1)) {
        if (heff_intLt_c(heff_dup(v_a_241106), heff_strLength_lent(v_a_241097, 0))) {
          V v_t_241109 = heff_tag_at_n(v_ru_24v_241101_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_241097, v_a_241106)});
          return heff_tag_at_n(v_ru_24x1_241100_24Ok, TAG_Ok, 1, (V[]){v_t_241109});
        } else {
          heff_drop(v_a_241097);
          heff_drop_cell(v_ru_24x1_241100_24Ok, 1);
          heff_drop(v_a_241106);
          heff_drop_cell(v_ru_24v_241101_24VInt, 1);
          return NTAG(TAG_Abn);
        }
      } else {
        heff_drop(v_a_241097);
        heff_drop_cell(v_ru_24x1_241100_24Ok, 1);
        heff_drop(v_a_241106);
        heff_drop_cell(v_ru_24v_241101_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241101, 0ULL, 1);
      heff_drop(v_a_241097);
      heff_drop_cell(v_ru_24x1_241100_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241101, 0ULL, 1);
      heff_drop(v_a_241097);
      heff_drop_cell(v_ru_24x1_241100_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241101, 0ULL, 1);
      heff_drop(v_a_241097);
      heff_drop_cell(v_ru_24x1_241100_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241101, 0ULL, 1);
      heff_drop(v_a_241097);
      heff_drop_cell(v_ru_24x1_241100_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241101, 0ULL, 1);
      heff_drop(v_a_241097);
      heff_drop_cell(v_ru_24x1_241100_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241101, 0ULL, 1);
      heff_drop(v_a_241097);
      heff_drop_cell(v_ru_24x1_241100_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241101, 0ULL, 2);
      heff_drop(v_a_241097);
      heff_drop_cell(v_ru_24x1_241100_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241097);
      heff_drop_cell(v_ru_24x1_241100_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241101);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241097);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241097);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241118 = heff_field(v_x1_241100, 0);
    V v_ru_24x1_241100_24Bug = heff_take_reuse_n(v_x1_241100, 1ULL, 1);
    heff_drop(v_a_241097);
    return heff_tag_at_n(v_ru_24x1_241100_24Bug, TAG_Bug, 1, (V[]){v_what_241118});
  }
  default: return heff_nomatch(v_x1_241100);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args) {
  V v_d_241083 = args[0];
  V v_a_241084 = args[1];
  V v_x1_241085 = heff_tr(heff_call(v_a_241084, 1, (V[]){v_d_241083}));
  switch (heff_tag_of(v_x1_241085)) {
  case TAG_Ok: {
    V v_v_241086 = heff_field(v_x1_241085, 0);
    V v_ru_24x1_241085_24Ok = heff_take_reuse_n(v_x1_241085, 1ULL, 1);
    switch (heff_tag_of(v_v_241086)) {
    case TAG_VFun: {
      heff_take_n(v_v_241086, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241085_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241086, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241085_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241086, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241085_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241086, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241085_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241086, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241085_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241086, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241085_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241086, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241085_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241086, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241085_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241086, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241085_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241097 = heff_field(v_v_241086, 0);
      heff_take_n(v_v_241086, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241085_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam78, 2, 1, (V[]){v_a_241097})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241086, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241085_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241085_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241086);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241121 = heff_field(v_x1_241085, 0);
    V v_ru_24x1_241085_24Bug = heff_take_reuse_n(v_x1_241085, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241085_24Bug, TAG_Bug, 1, (V[]){v_what_241121});
  }
  default: return heff_nomatch(v_x1_241085);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args) {
  V v_d_241147 = args[0];
  V v_a_241148 = args[1];
  V v_a_241137 = heff_env(self)[0];
  V v_a_241146 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241149 = heff_tr(heff_call(v_a_241148, 1, (V[]){v_d_241147}));
  switch (heff_tag_of(v_x1_241149)) {
  case TAG_Ok: {
    V v_v_241150 = heff_field(v_x1_241149, 0);
    V v_ru_24x1_241149_24Ok = heff_take_reuse_n(v_x1_241149, 1ULL, 1);
    switch (heff_tag_of(v_v_241150)) {
    case TAG_VFun: {
      heff_take_n(v_v_241150, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop(v_a_241146);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241150, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop(v_a_241146);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241150, 0ULL, 2);
      heff_drop(v_a_241137);
      heff_drop(v_a_241146);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241155 = heff_field(v_v_241150, 0);
      V v_ru_24v_241150_24VInt = heff_take_reuse_n(v_v_241150, 1ULL, 1);
      V v_t_241156 = heff_tag_at_n(v_ru_24v_241150_24VInt, TAG_VBytes, 1, (V[]){heff_strSlice(v_a_241137, v_a_241146, v_a_241155)});
      return heff_tag_at_n(v_ru_24x1_241149_24Ok, TAG_Ok, 1, (V[]){v_t_241156});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241150, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop(v_a_241146);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241150, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop(v_a_241146);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241150, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop(v_a_241146);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241150, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop(v_a_241146);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241150, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop(v_a_241146);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241150, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop(v_a_241146);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241150, 0ULL, 2);
      heff_drop(v_a_241137);
      heff_drop(v_a_241146);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241137);
      heff_drop(v_a_241146);
      heff_drop_cell(v_ru_24x1_241149_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241150);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241137);
    heff_drop(v_a_241146);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241137);
    heff_drop(v_a_241146);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241165 = heff_field(v_x1_241149, 0);
    V v_ru_24x1_241149_24Bug = heff_take_reuse_n(v_x1_241149, 1ULL, 1);
    heff_drop(v_a_241137);
    heff_drop(v_a_241146);
    return heff_tag_at_n(v_ru_24x1_241149_24Bug, TAG_Bug, 1, (V[]){v_what_241165});
  }
  default: return heff_nomatch(v_x1_241149);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args) {
  V v_d_241138 = args[0];
  V v_a_241139 = args[1];
  V v_a_241137 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241140 = heff_tr(heff_call(v_a_241139, 1, (V[]){v_d_241138}));
  switch (heff_tag_of(v_x1_241140)) {
  case TAG_Ok: {
    V v_v_241141 = heff_field(v_x1_241140, 0);
    V v_ru_24x1_241140_24Ok = heff_take_reuse_n(v_x1_241140, 1ULL, 1);
    switch (heff_tag_of(v_v_241141)) {
    case TAG_VFun: {
      heff_take_n(v_v_241141, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop_cell(v_ru_24x1_241140_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241141, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop_cell(v_ru_24x1_241140_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241141, 0ULL, 2);
      heff_drop(v_a_241137);
      heff_drop_cell(v_ru_24x1_241140_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241146 = heff_field(v_v_241141, 0);
      heff_take_n(v_v_241141, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241140_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam81, 2, 2, (V[]){v_a_241137, v_a_241146})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241141, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop_cell(v_ru_24x1_241140_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241141, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop_cell(v_ru_24x1_241140_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241141, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop_cell(v_ru_24x1_241140_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241141, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop_cell(v_ru_24x1_241140_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241141, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop_cell(v_ru_24x1_241140_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241141, 0ULL, 1);
      heff_drop(v_a_241137);
      heff_drop_cell(v_ru_24x1_241140_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241141, 0ULL, 2);
      heff_drop(v_a_241137);
      heff_drop_cell(v_ru_24x1_241140_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241137);
      heff_drop_cell(v_ru_24x1_241140_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241141);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241137);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241137);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241174 = heff_field(v_x1_241140, 0);
    V v_ru_24x1_241140_24Bug = heff_take_reuse_n(v_x1_241140, 1ULL, 1);
    heff_drop(v_a_241137);
    return heff_tag_at_n(v_ru_24x1_241140_24Bug, TAG_Bug, 1, (V[]){v_what_241174});
  }
  default: return heff_nomatch(v_x1_241140);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args) {
  V v_d_241123 = args[0];
  V v_a_241124 = args[1];
  V v_x1_241125 = heff_tr(heff_call(v_a_241124, 1, (V[]){v_d_241123}));
  switch (heff_tag_of(v_x1_241125)) {
  case TAG_Ok: {
    V v_v_241126 = heff_field(v_x1_241125, 0);
    V v_ru_24x1_241125_24Ok = heff_take_reuse_n(v_x1_241125, 1ULL, 1);
    switch (heff_tag_of(v_v_241126)) {
    case TAG_VFun: {
      heff_take_n(v_v_241126, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241125_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241126, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241125_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241126, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241125_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241126, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241125_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241126, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241125_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241126, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241125_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241126, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241125_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241126, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241125_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241126, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241125_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241137 = heff_field(v_v_241126, 0);
      heff_take_n(v_v_241126, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241125_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam80, 2, 1, (V[]){v_a_241137})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241126, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241125_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241125_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241126);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241177 = heff_field(v_x1_241125, 0);
    V v_ru_24x1_241125_24Bug = heff_take_reuse_n(v_x1_241125, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241125_24Bug, TAG_Bug, 1, (V[]){v_what_241177});
  }
  default: return heff_nomatch(v_x1_241125);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args) {
  V v_d_241180 = args[0];
  V v_l_241181 = args[1];
  V v_x1_241182 = heff_tr(heff_call(v_l_241181, 1, (V[]){v_d_241180}));
  switch (heff_tag_of(v_x1_241182)) {
  case TAG_Ok: {
    V v_v_241183 = heff_field(v_x1_241182, 0);
    heff_take_n(v_x1_241182, 1ULL, 1);
    V v_t_241184 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241183, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_241184; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str83); V r_ = (g_heff_2ecompile_2einterp_2ebytesJoined(a_0, a_1)); heff_drop(v_t_241184); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241185 = heff_field(v_x1_241182, 0);
    V v_ru_24x1_241182_24Bug = heff_take_reuse_n(v_x1_241182, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241182_24Bug, TAG_Bug, 1, (V[]){v_what_241185});
  }
  default: return heff_nomatch(v_x1_241182);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args) {
  V v_a_241187 = args[0];
  V v_b_241188 = args[1];
  V v_t_241190;
  if (heff_strEq_c(v_a_241187, v_b_241188)) {
    v_t_241190 = ((V)&g_heff_2ecompile_2einterp_2eprim_str85);
  } else {
    v_t_241190 = ((V)&g_heff_2ecompile_2einterp_2eprim_str86);
  }
  V v_t_241191 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241190, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241191});
}
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args) {
  V v_d_241193 = args[0];
  V v_l_241194 = args[1];
  V v_x1_241195 = heff_tr(heff_call(v_l_241194, 1, (V[]){v_d_241193}));
  switch (heff_tag_of(v_x1_241195)) {
  case TAG_Ok: {
    V v_v_241196 = heff_field(v_x1_241195, 0);
    V v_ru_24x1_241195_24Ok = heff_take_reuse_n(v_x1_241195, 1ULL, 1);
    V v_t_241197 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241196, NTAG(TAG_Nil)));
    V v_t_241198 = ({ V a_0 = v_t_241197; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str88); V r_ = (g_heff_2ecompile_2einterp_2ebyteString(a_0, a_1)); heff_drop(v_t_241197); r_; });
    return heff_tag_at_n(v_ru_24x1_241195_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_t_241198})});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241199 = heff_field(v_x1_241195, 0);
    V v_ru_24x1_241195_24Bug = heff_take_reuse_n(v_x1_241195, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241195_24Bug, TAG_Bug, 1, (V[]){v_what_241199});
  }
  default: return heff_nomatch(v_x1_241195);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args) {
  V v_d_241201 = args[0];
  V v_a_241202 = args[1];
  V v_x1_241203 = heff_tr(heff_call(v_a_241202, 1, (V[]){v_d_241201}));
  switch (heff_tag_of(v_x1_241203)) {
  case TAG_Ok: {
    V v_v_241204 = heff_field(v_x1_241203, 0);
    V v_ru_24x1_241203_24Ok = heff_take_reuse_n(v_x1_241203, 1ULL, 1);
    switch (heff_tag_of(v_v_241204)) {
    case TAG_VFun: {
      heff_take_n(v_v_241204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241204, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241215 = heff_field(v_v_241204, 0);
      heff_take_n(v_v_241204, 1ULL, 1);
      int64_t v_t_241216 = (heff_unbox_word(heff_strLength_lent(v_a_241215, 0)) - ((int64_t)1ULL));
      V v_t_241217 = ({ V a_0 = v_a_241215; V a_1 = MK_INT(0LL); V a_2 = heff_box_word(v_t_241216); V r_ = (g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(a_0, a_1, a_2)); heff_drop(v_a_241215); r_; });
      return heff_tag_at_n(v_ru_24x1_241203_24Ok, TAG_Ok, 1, (V[]){v_t_241217});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241204, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241204);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241220 = heff_field(v_x1_241203, 0);
    V v_ru_24x1_241203_24Bug = heff_take_reuse_n(v_x1_241203, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241203_24Bug, TAG_Bug, 1, (V[]){v_what_241220});
  }
  default: return heff_nomatch(v_x1_241203);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args) {
  V v_d_241222 = args[0];
  V v_a_241223 = args[1];
  V v_x1_241224 = heff_tr(heff_call(v_a_241223, 1, (V[]){v_d_241222}));
  switch (heff_tag_of(v_x1_241224)) {
  case TAG_Ok: {
    V v_v_241225 = heff_field(v_x1_241224, 0);
    V v_ru_24x1_241224_24Ok = heff_take_reuse_n(v_x1_241224, 1ULL, 1);
    switch (heff_tag_of(v_v_241225)) {
    case TAG_VFun: {
      heff_take_n(v_v_241225, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241224_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241225, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241224_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241225, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241224_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241225, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241224_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241225, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241224_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241225, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241224_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241233 = heff_field(v_v_241225, 0);
      heff_take_n(v_v_241225, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241224_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_a_241233})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241225, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241224_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241225, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241224_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241225, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241224_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241225, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241224_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241224_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241225);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241239 = heff_field(v_x1_241224, 0);
    V v_ru_24x1_241224_24Bug = heff_take_reuse_n(v_x1_241224, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241224_24Bug, TAG_Bug, 1, (V[]){v_what_241239});
  }
  default: return heff_nomatch(v_x1_241224);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args) {
  V v_d_241241 = args[0];
  V v_a_241242 = args[1];
  V v_x1_241243 = heff_tr(heff_call(v_a_241242, 1, (V[]){v_d_241241}));
  switch (heff_tag_of(v_x1_241243)) {
  case TAG_Ok: {
    V v_v_241244 = heff_field(v_x1_241243, 0);
    V v_ru_24x1_241243_24Ok = heff_take_reuse_n(v_x1_241243, 1ULL, 1);
    switch (heff_tag_of(v_v_241244)) {
    case TAG_VFun: {
      heff_take_n(v_v_241244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241244, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241255 = heff_field(v_v_241244, 0);
      heff_take_n(v_v_241244, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241243_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_a_241255})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241244, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241244);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241258 = heff_field(v_x1_241243, 0);
    V v_ru_24x1_241243_24Bug = heff_take_reuse_n(v_x1_241243, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241243_24Bug, TAG_Bug, 1, (V[]){v_what_241258});
  }
  default: return heff_nomatch(v_x1_241243);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args) {
  V v_d_241260 = args[0];
  V v_a_241261 = args[1];
  V v_x1_241262 = heff_tr(heff_call(v_a_241261, 1, (V[]){v_d_241260}));
  switch (heff_tag_of(v_x1_241262)) {
  case TAG_Ok: {
    V v_v_241263 = heff_field(v_x1_241262, 0);
    V v_ru_24x1_241262_24Ok = heff_take_reuse_n(v_x1_241262, 1ULL, 1);
    switch (heff_tag_of(v_v_241263)) {
    case TAG_VFun: {
      heff_take_n(v_v_241263, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241262_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241263, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241262_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241263, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241262_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241263, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241262_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241263, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241262_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241263, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241262_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241263, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241262_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241263, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241262_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241263, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241262_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241274 = heff_field(v_v_241263, 0);
      heff_take_n(v_v_241263, 1ULL, 1);
      V v_t_241275 = (g_rune_2evalidFrom(v_a_241274, MK_INT(0LL)));
      V v_t_241276;
      if ((heff_dup(v_t_241275) == NTAG(TAG_True))) {
        heff_drop(v_t_241275);
        v_t_241276 = v_a_241274;
      } else {
        heff_drop(v_t_241275);
        v_t_241276 = heff_strOfRunes(heff_strRunes(v_a_241274));
      }
      return heff_tag_at_n(v_ru_24x1_241262_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_241276})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241263, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241262_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241262_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241263);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241279 = heff_field(v_x1_241262, 0);
    V v_ru_24x1_241262_24Bug = heff_take_reuse_n(v_x1_241262, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241262_24Bug, TAG_Bug, 1, (V[]){v_what_241279});
  }
  default: return heff_nomatch(v_x1_241262);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args) {
  V v_d_241314 = args[0];
  V v_a_241315 = args[1];
  V v_a_241295 = heff_env(self)[0];
  V v_a_241304 = heff_env(self)[1];
  V v_a_241313 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241316 = heff_tr(heff_call(v_a_241315, 1, (V[]){v_d_241314}));
  switch (heff_tag_of(v_x1_241316)) {
  case TAG_Ok: {
    V v_v_241317 = heff_field(v_x1_241316, 0);
    heff_take_n(v_x1_241316, 1ULL, 1);
    switch (heff_tag_of(v_v_241317)) {
    case TAG_VFun: {
      heff_take_n(v_v_241317, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop(v_a_241313);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241317, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop(v_a_241313);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241317, 0ULL, 2);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop(v_a_241313);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241322 = heff_field(v_v_241317, 0);
      heff_take_n(v_v_241317, 1ULL, 1);
      V v_t_241323 = heff_intMul(heff_strLength_lent(v_a_241295, 0), MK_INT(8LL));
      return ({ V a_0 = v_a_241295; V a_1 = v_t_241323; V a_2 = v_a_241304; V a_3 = v_a_241313; V a_4 = v_a_241322; V r_ = (g_heff_2ecompile_2einterp_2eintAtV(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_a_241295); r_; });
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241317, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop(v_a_241313);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241317, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop(v_a_241313);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241317, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop(v_a_241313);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241317, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop(v_a_241313);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241317, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop(v_a_241313);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241317, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop(v_a_241313);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241317, 0ULL, 2);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop(v_a_241313);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop(v_a_241313);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241317);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241295);
    heff_drop(v_a_241304);
    heff_drop(v_a_241313);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241295);
    heff_drop(v_a_241304);
    heff_drop(v_a_241313);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241332 = heff_field(v_x1_241316, 0);
    V v_ru_24x1_241316_24Bug = heff_take_reuse_n(v_x1_241316, 1ULL, 1);
    heff_drop(v_a_241295);
    heff_drop(v_a_241304);
    heff_drop(v_a_241313);
    return heff_tag_at_n(v_ru_24x1_241316_24Bug, TAG_Bug, 1, (V[]){v_what_241332});
  }
  default: return heff_nomatch(v_x1_241316);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args) {
  V v_d_241305 = args[0];
  V v_a_241306 = args[1];
  V v_a_241295 = heff_env(self)[0];
  V v_a_241304 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241307 = heff_tr(heff_call(v_a_241306, 1, (V[]){v_d_241305}));
  switch (heff_tag_of(v_x1_241307)) {
  case TAG_Ok: {
    V v_v_241308 = heff_field(v_x1_241307, 0);
    V v_ru_24x1_241307_24Ok = heff_take_reuse_n(v_x1_241307, 1ULL, 1);
    switch (heff_tag_of(v_v_241308)) {
    case TAG_VFun: {
      heff_take_n(v_v_241308, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop_cell(v_ru_24x1_241307_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241308, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop_cell(v_ru_24x1_241307_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241308, 0ULL, 2);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop_cell(v_ru_24x1_241307_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241313 = heff_field(v_v_241308, 0);
      heff_take_n(v_v_241308, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241307_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam92, 2, 3, (V[]){v_a_241295, v_a_241304, v_a_241313})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241308, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop_cell(v_ru_24x1_241307_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241308, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop_cell(v_ru_24x1_241307_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241308, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop_cell(v_ru_24x1_241307_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241308, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop_cell(v_ru_24x1_241307_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241308, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop_cell(v_ru_24x1_241307_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241308, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop_cell(v_ru_24x1_241307_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241308, 0ULL, 2);
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop_cell(v_ru_24x1_241307_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241295);
      heff_drop(v_a_241304);
      heff_drop_cell(v_ru_24x1_241307_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241308);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241295);
    heff_drop(v_a_241304);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241295);
    heff_drop(v_a_241304);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241341 = heff_field(v_x1_241307, 0);
    V v_ru_24x1_241307_24Bug = heff_take_reuse_n(v_x1_241307, 1ULL, 1);
    heff_drop(v_a_241295);
    heff_drop(v_a_241304);
    return heff_tag_at_n(v_ru_24x1_241307_24Bug, TAG_Bug, 1, (V[]){v_what_241341});
  }
  default: return heff_nomatch(v_x1_241307);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args) {
  V v_d_241296 = args[0];
  V v_a_241297 = args[1];
  V v_a_241295 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241298 = heff_tr(heff_call(v_a_241297, 1, (V[]){v_d_241296}));
  switch (heff_tag_of(v_x1_241298)) {
  case TAG_Ok: {
    V v_v_241299 = heff_field(v_x1_241298, 0);
    V v_ru_24x1_241298_24Ok = heff_take_reuse_n(v_x1_241298, 1ULL, 1);
    switch (heff_tag_of(v_v_241299)) {
    case TAG_VFun: {
      heff_take_n(v_v_241299, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241299, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241299, 0ULL, 2);
      heff_drop(v_a_241295);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241304 = heff_field(v_v_241299, 0);
      heff_take_n(v_v_241299, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241298_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam91, 2, 2, (V[]){v_a_241295, v_a_241304})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241299, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241299, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241299, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241299, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241299, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241299, 0ULL, 1);
      heff_drop(v_a_241295);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241299, 0ULL, 2);
      heff_drop(v_a_241295);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241295);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241299);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241295);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241295);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241350 = heff_field(v_x1_241298, 0);
    V v_ru_24x1_241298_24Bug = heff_take_reuse_n(v_x1_241298, 1ULL, 1);
    heff_drop(v_a_241295);
    return heff_tag_at_n(v_ru_24x1_241298_24Bug, TAG_Bug, 1, (V[]){v_what_241350});
  }
  default: return heff_nomatch(v_x1_241298);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args) {
  V v_d_241281 = args[0];
  V v_a_241282 = args[1];
  V v_x1_241283 = heff_tr(heff_call(v_a_241282, 1, (V[]){v_d_241281}));
  switch (heff_tag_of(v_x1_241283)) {
  case TAG_Ok: {
    V v_v_241284 = heff_field(v_x1_241283, 0);
    V v_ru_24x1_241283_24Ok = heff_take_reuse_n(v_x1_241283, 1ULL, 1);
    switch (heff_tag_of(v_v_241284)) {
    case TAG_VFun: {
      heff_take_n(v_v_241284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241284, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241295 = heff_field(v_v_241284, 0);
      heff_take_n(v_v_241284, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241283_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam90, 2, 1, (V[]){v_a_241295})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241284, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241284);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241353 = heff_field(v_x1_241283, 0);
    V v_ru_24x1_241283_24Bug = heff_take_reuse_n(v_x1_241283, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241283_24Bug, TAG_Bug, 1, (V[]){v_what_241353});
  }
  default: return heff_nomatch(v_x1_241283);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args) {
  V v_d_241373 = args[0];
  V v_a_241374 = args[1];
  V v_a_241363 = heff_env(self)[0];
  V v_a_241372 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241375 = heff_tr(heff_call(v_a_241374, 1, (V[]){v_d_241373}));
  switch (heff_tag_of(v_x1_241375)) {
  case TAG_Ok: {
    V v_v_241376 = heff_field(v_x1_241375, 0);
    heff_take_n(v_x1_241375, 1ULL, 1);
    switch (heff_tag_of(v_v_241376)) {
    case TAG_VFun: {
      heff_take_n(v_v_241376, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop(v_a_241372);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241376, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop(v_a_241372);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241376, 0ULL, 2);
      heff_drop(v_a_241363);
      heff_drop(v_a_241372);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241381 = heff_field(v_v_241376, 0);
      heff_take_n(v_v_241376, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2ebytesOfIntV(v_a_241363, v_a_241372, v_a_241381));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241376, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop(v_a_241372);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241376, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop(v_a_241372);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241376, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop(v_a_241372);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241376, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop(v_a_241372);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241376, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop(v_a_241372);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241376, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop(v_a_241372);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241376, 0ULL, 2);
      heff_drop(v_a_241363);
      heff_drop(v_a_241372);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241363);
      heff_drop(v_a_241372);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241376);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241363);
    heff_drop(v_a_241372);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241363);
    heff_drop(v_a_241372);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241390 = heff_field(v_x1_241375, 0);
    V v_ru_24x1_241375_24Bug = heff_take_reuse_n(v_x1_241375, 1ULL, 1);
    heff_drop(v_a_241363);
    heff_drop(v_a_241372);
    return heff_tag_at_n(v_ru_24x1_241375_24Bug, TAG_Bug, 1, (V[]){v_what_241390});
  }
  default: return heff_nomatch(v_x1_241375);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args) {
  V v_d_241364 = args[0];
  V v_a_241365 = args[1];
  V v_a_241363 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241366 = heff_tr(heff_call(v_a_241365, 1, (V[]){v_d_241364}));
  switch (heff_tag_of(v_x1_241366)) {
  case TAG_Ok: {
    V v_v_241367 = heff_field(v_x1_241366, 0);
    V v_ru_24x1_241366_24Ok = heff_take_reuse_n(v_x1_241366, 1ULL, 1);
    switch (heff_tag_of(v_v_241367)) {
    case TAG_VFun: {
      heff_take_n(v_v_241367, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop_cell(v_ru_24x1_241366_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241367, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop_cell(v_ru_24x1_241366_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241367, 0ULL, 2);
      heff_drop(v_a_241363);
      heff_drop_cell(v_ru_24x1_241366_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241372 = heff_field(v_v_241367, 0);
      heff_take_n(v_v_241367, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241366_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam95, 2, 2, (V[]){v_a_241363, v_a_241372})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241367, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop_cell(v_ru_24x1_241366_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241367, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop_cell(v_ru_24x1_241366_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241367, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop_cell(v_ru_24x1_241366_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241367, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop_cell(v_ru_24x1_241366_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241367, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop_cell(v_ru_24x1_241366_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241367, 0ULL, 1);
      heff_drop(v_a_241363);
      heff_drop_cell(v_ru_24x1_241366_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241367, 0ULL, 2);
      heff_drop(v_a_241363);
      heff_drop_cell(v_ru_24x1_241366_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241363);
      heff_drop_cell(v_ru_24x1_241366_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241367);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241363);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241363);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241399 = heff_field(v_x1_241366, 0);
    V v_ru_24x1_241366_24Bug = heff_take_reuse_n(v_x1_241366, 1ULL, 1);
    heff_drop(v_a_241363);
    return heff_tag_at_n(v_ru_24x1_241366_24Bug, TAG_Bug, 1, (V[]){v_what_241399});
  }
  default: return heff_nomatch(v_x1_241366);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args) {
  V v_d_241355 = args[0];
  V v_a_241356 = args[1];
  V v_x1_241357 = heff_tr(heff_call(v_a_241356, 1, (V[]){v_d_241355}));
  switch (heff_tag_of(v_x1_241357)) {
  case TAG_Ok: {
    V v_v_241358 = heff_field(v_x1_241357, 0);
    V v_ru_24x1_241357_24Ok = heff_take_reuse_n(v_x1_241357, 1ULL, 1);
    switch (heff_tag_of(v_v_241358)) {
    case TAG_VFun: {
      heff_take_n(v_v_241358, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241357_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241358, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241357_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241358, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241357_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241363 = heff_field(v_v_241358, 0);
      heff_take_n(v_v_241358, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241357_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam94, 2, 1, (V[]){v_a_241363})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241358, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241357_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241358, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241357_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241358, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241357_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241358, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241357_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241358, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241357_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241358, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241357_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241358, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241357_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241357_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241358);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241408 = heff_field(v_x1_241357, 0);
    V v_ru_24x1_241357_24Bug = heff_take_reuse_n(v_x1_241357, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241357_24Bug, TAG_Bug, 1, (V[]){v_what_241408});
  }
  default: return heff_nomatch(v_x1_241357);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args) {
  V v_d_241434 = args[0];
  V v_a_241435 = args[1];
  V v_a_241433 = heff_env(self)[0];
  V v_a_241424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241436 = heff_tr(heff_call(v_a_241435, 1, (V[]){v_d_241434}));
  switch (heff_tag_of(v_x1_241436)) {
  case TAG_Ok: {
    V v_v_241437 = heff_field(v_x1_241436, 0);
    V v_ru_24x1_241436_24Ok = heff_take_reuse_n(v_x1_241436, 1ULL, 1);
    switch (heff_tag_of(v_v_241437)) {
    case TAG_VFun: {
      heff_take_n(v_v_241437, 0ULL, 1);
      heff_drop(v_a_241433);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241437, 0ULL, 1);
      heff_drop(v_a_241433);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241437, 0ULL, 2);
      heff_drop(v_a_241433);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241437, 0ULL, 1);
      heff_drop(v_a_241433);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241437, 0ULL, 1);
      heff_drop(v_a_241433);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241437, 0ULL, 1);
      heff_drop(v_a_241433);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241437, 0ULL, 1);
      heff_drop(v_a_241433);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241437, 0ULL, 1);
      heff_drop(v_a_241433);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241437, 0ULL, 1);
      heff_drop(v_a_241433);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241448 = heff_field(v_v_241437, 0);
      heff_take_n(v_v_241437, 1ULL, 1);
      V v_t_241454;
      if (heff_intLe_c_lent(MK_INT(0LL), v_a_241433, 1)) {
        V v_t_241450 = heff_intAdd(heff_dup(v_a_241433), heff_strLength_lent(v_a_241448, 0));
        if (heff_intLe_c(v_t_241450, heff_strLength_lent(v_a_241424, 0))) {
          V v_t_241452 = heff_intAdd(heff_dup(v_a_241433), heff_strLength_lent(v_a_241448, 0));
          if (heff_strEq_c(heff_strSlice(v_a_241424, v_a_241433, v_t_241452), v_a_241448)) {
            v_t_241454 = ((V)&g_heff_2ecompile_2einterp_2eprim_str96);
          } else {
            v_t_241454 = ((V)&g_heff_2ecompile_2einterp_2eprim_str97);
          }
        } else {
          heff_drop(v_a_241433);
          heff_drop(v_a_241424);
          heff_drop(v_a_241448);
          v_t_241454 = ((V)&g_heff_2ecompile_2einterp_2eprim_str98);
        }
      } else {
        heff_drop(v_a_241433);
        heff_drop(v_a_241424);
        heff_drop(v_a_241448);
        v_t_241454 = ((V)&g_heff_2ecompile_2einterp_2eprim_str99);
      }
      V v_t_241455 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241454, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_241436_24Ok, TAG_Ok, 1, (V[]){v_t_241455});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241437, 0ULL, 2);
      heff_drop(v_a_241433);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241433);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241437);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241433);
    heff_drop(v_a_241424);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241433);
    heff_drop(v_a_241424);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241458 = heff_field(v_x1_241436, 0);
    V v_ru_24x1_241436_24Bug = heff_take_reuse_n(v_x1_241436, 1ULL, 1);
    heff_drop(v_a_241433);
    heff_drop(v_a_241424);
    return heff_tag_at_n(v_ru_24x1_241436_24Bug, TAG_Bug, 1, (V[]){v_what_241458});
  }
  default: return heff_nomatch(v_x1_241436);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args) {
  V v_d_241425 = args[0];
  V v_a_241426 = args[1];
  V v_a_241424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241427 = heff_tr(heff_call(v_a_241426, 1, (V[]){v_d_241425}));
  switch (heff_tag_of(v_x1_241427)) {
  case TAG_Ok: {
    V v_v_241428 = heff_field(v_x1_241427, 0);
    V v_ru_24x1_241427_24Ok = heff_take_reuse_n(v_x1_241427, 1ULL, 1);
    switch (heff_tag_of(v_v_241428)) {
    case TAG_VFun: {
      heff_take_n(v_v_241428, 0ULL, 1);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241428, 0ULL, 1);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241428, 0ULL, 2);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241433 = heff_field(v_v_241428, 0);
      heff_take_n(v_v_241428, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241427_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam98, 2, 2, (V[]){v_a_241433, v_a_241424})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241428, 0ULL, 1);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241428, 0ULL, 1);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241428, 0ULL, 1);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241428, 0ULL, 1);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241428, 0ULL, 1);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241428, 0ULL, 1);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241428, 0ULL, 2);
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241424);
      heff_drop_cell(v_ru_24x1_241427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241428);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241424);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241424);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241467 = heff_field(v_x1_241427, 0);
    V v_ru_24x1_241427_24Bug = heff_take_reuse_n(v_x1_241427, 1ULL, 1);
    heff_drop(v_a_241424);
    return heff_tag_at_n(v_ru_24x1_241427_24Bug, TAG_Bug, 1, (V[]){v_what_241467});
  }
  default: return heff_nomatch(v_x1_241427);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args) {
  V v_d_241410 = args[0];
  V v_a_241411 = args[1];
  V v_x1_241412 = heff_tr(heff_call(v_a_241411, 1, (V[]){v_d_241410}));
  switch (heff_tag_of(v_x1_241412)) {
  case TAG_Ok: {
    V v_v_241413 = heff_field(v_x1_241412, 0);
    V v_ru_24x1_241412_24Ok = heff_take_reuse_n(v_x1_241412, 1ULL, 1);
    switch (heff_tag_of(v_v_241413)) {
    case TAG_VFun: {
      heff_take_n(v_v_241413, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241412_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241413, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241412_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241413, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241412_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241413, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241412_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241413, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241412_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241413, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241412_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241413, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241412_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241413, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241412_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241413, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241412_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241424 = heff_field(v_v_241413, 0);
      heff_take_n(v_v_241413, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241412_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam97, 2, 1, (V[]){v_a_241424})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241413, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241412_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241412_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241413);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241470 = heff_field(v_x1_241412, 0);
    V v_ru_24x1_241412_24Bug = heff_take_reuse_n(v_x1_241412, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241412_24Bug, TAG_Bug, 1, (V[]){v_what_241470});
  }
  default: return heff_nomatch(v_x1_241412);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args) {
  V v_d_241493 = args[0];
  V v_a_241494 = args[1];
  V v_s_241474 = heff_env(self)[0];
  V v_m_241473 = heff_env(self)[1];
  V v_a_241483 = heff_env(self)[2];
  V v_a_241492 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_241495 = heff_tr(heff_call(v_a_241494, 1, (V[]){v_d_241493}));
  switch (heff_tag_of(v_x1_241495)) {
  case TAG_Ok: {
    V v_v_241496 = heff_field(v_x1_241495, 0);
    heff_take_n(v_x1_241495, 1ULL, 1);
    switch (heff_tag_of(v_v_241496)) {
    case TAG_VFun: {
      heff_take_n(v_v_241496, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop(v_a_241492);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241496, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop(v_a_241492);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241496, 0ULL, 2);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop(v_a_241492);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241501 = heff_field(v_v_241496, 0);
      heff_take_n(v_v_241496, 1ULL, 1);
      return ({ V a_0 = v_s_241474; V a_1 = v_m_241473; V a_2 = v_a_241483; V a_3 = v_a_241492; V a_4 = v_a_241501; V r_ = (g_heff_2ecompile_2einterp_2eintAtV(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_241474); r_; });
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241496, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop(v_a_241492);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241496, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop(v_a_241492);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241496, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop(v_a_241492);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241496, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop(v_a_241492);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241496, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop(v_a_241492);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241496, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop(v_a_241492);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241496, 0ULL, 2);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop(v_a_241492);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop(v_a_241492);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241496);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241474);
    heff_drop(v_m_241473);
    heff_drop(v_a_241483);
    heff_drop(v_a_241492);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241474);
    heff_drop(v_m_241473);
    heff_drop(v_a_241483);
    heff_drop(v_a_241492);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241510 = heff_field(v_x1_241495, 0);
    V v_ru_24x1_241495_24Bug = heff_take_reuse_n(v_x1_241495, 1ULL, 1);
    heff_drop(v_s_241474);
    heff_drop(v_m_241473);
    heff_drop(v_a_241483);
    heff_drop(v_a_241492);
    return heff_tag_at_n(v_ru_24x1_241495_24Bug, TAG_Bug, 1, (V[]){v_what_241510});
  }
  default: return heff_nomatch(v_x1_241495);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args) {
  V v_d_241484 = args[0];
  V v_a_241485 = args[1];
  V v_s_241474 = heff_env(self)[0];
  V v_m_241473 = heff_env(self)[1];
  V v_a_241483 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241486 = heff_tr(heff_call(v_a_241485, 1, (V[]){v_d_241484}));
  switch (heff_tag_of(v_x1_241486)) {
  case TAG_Ok: {
    V v_v_241487 = heff_field(v_x1_241486, 0);
    V v_ru_24x1_241486_24Ok = heff_take_reuse_n(v_x1_241486, 1ULL, 1);
    switch (heff_tag_of(v_v_241487)) {
    case TAG_VFun: {
      heff_take_n(v_v_241487, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop_cell(v_ru_24x1_241486_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241487, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop_cell(v_ru_24x1_241486_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241487, 0ULL, 2);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop_cell(v_ru_24x1_241486_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241492 = heff_field(v_v_241487, 0);
      heff_take_n(v_v_241487, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241486_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam102, 2, 4, (V[]){v_s_241474, v_m_241473, v_a_241483, v_a_241492})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241487, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop_cell(v_ru_24x1_241486_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241487, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop_cell(v_ru_24x1_241486_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241487, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop_cell(v_ru_24x1_241486_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241487, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop_cell(v_ru_24x1_241486_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241487, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop_cell(v_ru_24x1_241486_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241487, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop_cell(v_ru_24x1_241486_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241487, 0ULL, 2);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop_cell(v_ru_24x1_241486_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop(v_a_241483);
      heff_drop_cell(v_ru_24x1_241486_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241487);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241474);
    heff_drop(v_m_241473);
    heff_drop(v_a_241483);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241474);
    heff_drop(v_m_241473);
    heff_drop(v_a_241483);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241519 = heff_field(v_x1_241486, 0);
    V v_ru_24x1_241486_24Bug = heff_take_reuse_n(v_x1_241486, 1ULL, 1);
    heff_drop(v_s_241474);
    heff_drop(v_m_241473);
    heff_drop(v_a_241483);
    return heff_tag_at_n(v_ru_24x1_241486_24Bug, TAG_Bug, 1, (V[]){v_what_241519});
  }
  default: return heff_nomatch(v_x1_241486);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args) {
  V v_d_241475 = args[0];
  V v_a_241476 = args[1];
  V v_s_241474 = heff_env(self)[0];
  V v_m_241473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241477 = heff_tr(heff_call(v_a_241476, 1, (V[]){v_d_241475}));
  switch (heff_tag_of(v_x1_241477)) {
  case TAG_Ok: {
    V v_v_241478 = heff_field(v_x1_241477, 0);
    V v_ru_24x1_241477_24Ok = heff_take_reuse_n(v_x1_241477, 1ULL, 1);
    switch (heff_tag_of(v_v_241478)) {
    case TAG_VFun: {
      heff_take_n(v_v_241478, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop_cell(v_ru_24x1_241477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241478, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop_cell(v_ru_24x1_241477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241478, 0ULL, 2);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop_cell(v_ru_24x1_241477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241483 = heff_field(v_v_241478, 0);
      heff_take_n(v_v_241478, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241477_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam101, 2, 3, (V[]){v_s_241474, v_m_241473, v_a_241483})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241478, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop_cell(v_ru_24x1_241477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241478, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop_cell(v_ru_24x1_241477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241478, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop_cell(v_ru_24x1_241477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241478, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop_cell(v_ru_24x1_241477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241478, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop_cell(v_ru_24x1_241477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241478, 0ULL, 1);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop_cell(v_ru_24x1_241477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241478, 0ULL, 2);
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop_cell(v_ru_24x1_241477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241474);
      heff_drop(v_m_241473);
      heff_drop_cell(v_ru_24x1_241477_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241478);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241474);
    heff_drop(v_m_241473);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241474);
    heff_drop(v_m_241473);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241528 = heff_field(v_x1_241477, 0);
    V v_ru_24x1_241477_24Bug = heff_take_reuse_n(v_x1_241477, 1ULL, 1);
    heff_drop(v_s_241474);
    heff_drop(v_m_241473);
    return heff_tag_at_n(v_ru_24x1_241477_24Bug, TAG_Bug, 1, (V[]){v_what_241528});
  }
  default: return heff_nomatch(v_x1_241477);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args) {
  V v_m_241473 = args[0];
  V v_s_241474 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam100, 2, 2, (V[]){v_s_241474, v_m_241473})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args) {
  V v_d_241548 = args[0];
  V v_a_241549 = args[1];
  V v_a_241538 = heff_env(self)[0];
  V v_a_241547 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241550 = heff_tr(heff_call(v_a_241549, 1, (V[]){v_d_241548}));
  switch (heff_tag_of(v_x1_241550)) {
  case TAG_Ok: {
    V v_v_241551 = heff_field(v_x1_241550, 0);
    heff_take_n(v_x1_241550, 1ULL, 1);
    switch (heff_tag_of(v_v_241551)) {
    case TAG_VFun: {
      heff_take_n(v_v_241551, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop(v_a_241547);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241551, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop(v_a_241547);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241551, 0ULL, 2);
      heff_drop(v_a_241538);
      heff_drop(v_a_241547);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241556 = heff_field(v_v_241551, 0);
      heff_take_n(v_v_241551, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2ebitsOfIntV(v_a_241538, v_a_241547, v_a_241556));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241551, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop(v_a_241547);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241551, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop(v_a_241547);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241551, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop(v_a_241547);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241551, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop(v_a_241547);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241551, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop(v_a_241547);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241551, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop(v_a_241547);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241551, 0ULL, 2);
      heff_drop(v_a_241538);
      heff_drop(v_a_241547);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241538);
      heff_drop(v_a_241547);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241551);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241538);
    heff_drop(v_a_241547);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241538);
    heff_drop(v_a_241547);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241565 = heff_field(v_x1_241550, 0);
    V v_ru_24x1_241550_24Bug = heff_take_reuse_n(v_x1_241550, 1ULL, 1);
    heff_drop(v_a_241538);
    heff_drop(v_a_241547);
    return heff_tag_at_n(v_ru_24x1_241550_24Bug, TAG_Bug, 1, (V[]){v_what_241565});
  }
  default: return heff_nomatch(v_x1_241550);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args) {
  V v_d_241539 = args[0];
  V v_a_241540 = args[1];
  V v_a_241538 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241541 = heff_tr(heff_call(v_a_241540, 1, (V[]){v_d_241539}));
  switch (heff_tag_of(v_x1_241541)) {
  case TAG_Ok: {
    V v_v_241542 = heff_field(v_x1_241541, 0);
    V v_ru_24x1_241541_24Ok = heff_take_reuse_n(v_x1_241541, 1ULL, 1);
    switch (heff_tag_of(v_v_241542)) {
    case TAG_VFun: {
      heff_take_n(v_v_241542, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop_cell(v_ru_24x1_241541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241542, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop_cell(v_ru_24x1_241541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241542, 0ULL, 2);
      heff_drop(v_a_241538);
      heff_drop_cell(v_ru_24x1_241541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241547 = heff_field(v_v_241542, 0);
      heff_take_n(v_v_241542, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241541_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam105, 2, 2, (V[]){v_a_241538, v_a_241547})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241542, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop_cell(v_ru_24x1_241541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241542, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop_cell(v_ru_24x1_241541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241542, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop_cell(v_ru_24x1_241541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241542, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop_cell(v_ru_24x1_241541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241542, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop_cell(v_ru_24x1_241541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241542, 0ULL, 1);
      heff_drop(v_a_241538);
      heff_drop_cell(v_ru_24x1_241541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241542, 0ULL, 2);
      heff_drop(v_a_241538);
      heff_drop_cell(v_ru_24x1_241541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241538);
      heff_drop_cell(v_ru_24x1_241541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241542);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241538);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241538);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241574 = heff_field(v_x1_241541, 0);
    V v_ru_24x1_241541_24Bug = heff_take_reuse_n(v_x1_241541, 1ULL, 1);
    heff_drop(v_a_241538);
    return heff_tag_at_n(v_ru_24x1_241541_24Bug, TAG_Bug, 1, (V[]){v_what_241574});
  }
  default: return heff_nomatch(v_x1_241541);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args) {
  V v_d_241530 = args[0];
  V v_a_241531 = args[1];
  V v_x1_241532 = heff_tr(heff_call(v_a_241531, 1, (V[]){v_d_241530}));
  switch (heff_tag_of(v_x1_241532)) {
  case TAG_Ok: {
    V v_v_241533 = heff_field(v_x1_241532, 0);
    V v_ru_24x1_241532_24Ok = heff_take_reuse_n(v_x1_241532, 1ULL, 1);
    switch (heff_tag_of(v_v_241533)) {
    case TAG_VFun: {
      heff_take_n(v_v_241533, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241532_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241533, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241532_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241533, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241532_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241538 = heff_field(v_v_241533, 0);
      heff_take_n(v_v_241533, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241532_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam104, 2, 1, (V[]){v_a_241538})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241533, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241532_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241533, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241532_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241533, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241532_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241533, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241532_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241533, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241532_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241533, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241532_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241533, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241532_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241532_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241533);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241583 = heff_field(v_x1_241532, 0);
    V v_ru_24x1_241532_24Bug = heff_take_reuse_n(v_x1_241532, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241532_24Bug, TAG_Bug, 1, (V[]){v_what_241583});
  }
  default: return heff_nomatch(v_x1_241532);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args) {
  V v_d_241585 = args[0];
  V v_l_241586 = args[1];
  V v_x1_241587 = heff_tr(heff_call(v_l_241586, 1, (V[]){v_d_241585}));
  switch (heff_tag_of(v_x1_241587)) {
  case TAG_Ok: {
    V v_v_241588 = heff_field(v_x1_241587, 0);
    heff_take_n(v_x1_241587, 1ULL, 1);
    V v_t_241589 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241588, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_241589; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2einterp_2eprim_str104); V r_ = (g_heff_2ecompile_2einterp_2ebitsJoined(a_0, a_1, a_2)); heff_drop(v_t_241589); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241590 = heff_field(v_x1_241587, 0);
    V v_ru_24x1_241587_24Bug = heff_take_reuse_n(v_x1_241587, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241587_24Bug, TAG_Bug, 1, (V[]){v_what_241590});
  }
  default: return heff_nomatch(v_x1_241587);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args) {
  V v_d_241603 = args[0];
  V v_a_241604 = args[1];
  V v_a_241602 = heff_env(self)[0];
  V v_m_241592 = heff_env(self)[1];
  V v_s_241593 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241605 = heff_tr(heff_call(v_a_241604, 1, (V[]){v_d_241603}));
  switch (heff_tag_of(v_x1_241605)) {
  case TAG_Ok: {
    V v_v_241606 = heff_field(v_x1_241605, 0);
    V v_ru_24x1_241605_24Ok = heff_take_reuse_n(v_x1_241605, 1ULL, 1);
    switch (heff_tag_of(v_v_241606)) {
    case TAG_VFun: {
      heff_take_n(v_v_241606, 0ULL, 1);
      heff_drop(v_a_241602);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241605_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241606, 0ULL, 1);
      heff_drop(v_a_241602);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241605_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241606, 0ULL, 2);
      heff_drop(v_a_241602);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241605_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241611 = heff_field(v_v_241606, 0);
      heff_take_n(v_v_241606, 1ULL, 1);
      if (heff_intLt_c_lent(v_a_241602, MK_INT(0LL), 2)) {
        heff_drop(v_a_241602);
        heff_drop(v_m_241592);
        heff_drop(v_s_241593);
        heff_drop_cell(v_ru_24x1_241605_24Ok, 1);
        heff_drop(v_a_241611);
        return NTAG(TAG_Abn);
      } else {
        if (heff_intLt_c_lent(v_a_241611, MK_INT(0LL), 2)) {
          heff_drop(v_a_241602);
          heff_drop(v_m_241592);
          heff_drop(v_s_241593);
          heff_drop_cell(v_ru_24x1_241605_24Ok, 1);
          heff_drop(v_a_241611);
          return NTAG(TAG_Abn);
        } else {
          if (heff_intLt_c(v_m_241592, heff_intAdd(heff_dup(v_a_241602), heff_dup(v_a_241611)))) {
            heff_drop(v_a_241602);
            heff_drop(v_s_241593);
            heff_drop_cell(v_ru_24x1_241605_24Ok, 1);
            heff_drop(v_a_241611);
            return NTAG(TAG_Abn);
          } else {
            V v_t_241615 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str106); V a_2 = v_s_241593; V a_3 = heff_dup(v_a_241602); V a_4 = heff_intAdd(v_a_241602, heff_dup(v_a_241611)); V r_ = (g_heff_2ecompile_2einterp_2ebitsCopy(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_241593); r_; });
            return heff_tag_at_n(v_ru_24x1_241605_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_a_241611, v_t_241615})});
          }
        }
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241606, 0ULL, 1);
      heff_drop(v_a_241602);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241605_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241606, 0ULL, 1);
      heff_drop(v_a_241602);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241605_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241606, 0ULL, 1);
      heff_drop(v_a_241602);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241605_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241606, 0ULL, 1);
      heff_drop(v_a_241602);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241605_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241606, 0ULL, 1);
      heff_drop(v_a_241602);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241605_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241606, 0ULL, 1);
      heff_drop(v_a_241602);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241605_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241606, 0ULL, 2);
      heff_drop(v_a_241602);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241605_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241602);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241605_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241606);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241602);
    heff_drop(v_m_241592);
    heff_drop(v_s_241593);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241602);
    heff_drop(v_m_241592);
    heff_drop(v_s_241593);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241624 = heff_field(v_x1_241605, 0);
    V v_ru_24x1_241605_24Bug = heff_take_reuse_n(v_x1_241605, 1ULL, 1);
    heff_drop(v_a_241602);
    heff_drop(v_m_241592);
    heff_drop(v_s_241593);
    return heff_tag_at_n(v_ru_24x1_241605_24Bug, TAG_Bug, 1, (V[]){v_what_241624});
  }
  default: return heff_nomatch(v_x1_241605);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args) {
  V v_d_241594 = args[0];
  V v_a_241595 = args[1];
  V v_m_241592 = heff_env(self)[0];
  V v_s_241593 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241596 = heff_tr(heff_call(v_a_241595, 1, (V[]){v_d_241594}));
  switch (heff_tag_of(v_x1_241596)) {
  case TAG_Ok: {
    V v_v_241597 = heff_field(v_x1_241596, 0);
    V v_ru_24x1_241596_24Ok = heff_take_reuse_n(v_x1_241596, 1ULL, 1);
    switch (heff_tag_of(v_v_241597)) {
    case TAG_VFun: {
      heff_take_n(v_v_241597, 0ULL, 1);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241596_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241597, 0ULL, 1);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241596_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241597, 0ULL, 2);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241596_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241602 = heff_field(v_v_241597, 0);
      heff_take_n(v_v_241597, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241596_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam109, 2, 3, (V[]){v_a_241602, v_m_241592, v_s_241593})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241597, 0ULL, 1);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241596_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241597, 0ULL, 1);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241596_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241597, 0ULL, 1);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241596_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241597, 0ULL, 1);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241596_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241597, 0ULL, 1);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241596_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241597, 0ULL, 1);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241596_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241597, 0ULL, 2);
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241596_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_m_241592);
      heff_drop(v_s_241593);
      heff_drop_cell(v_ru_24x1_241596_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241597);
    }
  }
  case TAG_Abn: {
    heff_drop(v_m_241592);
    heff_drop(v_s_241593);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_m_241592);
    heff_drop(v_s_241593);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241633 = heff_field(v_x1_241596, 0);
    V v_ru_24x1_241596_24Bug = heff_take_reuse_n(v_x1_241596, 1ULL, 1);
    heff_drop(v_m_241592);
    heff_drop(v_s_241593);
    return heff_tag_at_n(v_ru_24x1_241596_24Bug, TAG_Bug, 1, (V[]){v_what_241633});
  }
  default: return heff_nomatch(v_x1_241596);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args) {
  V v_m_241592 = args[0];
  V v_s_241593 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam108, 2, 2, (V[]){v_m_241592, v_s_241593})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam110(V self, V *args) {
  V v_d_241635 = args[0];
  V v_a_241636 = args[1];
  V v_x1_241637 = heff_tr(heff_call(v_a_241636, 1, (V[]){v_d_241635}));
  switch (heff_tag_of(v_x1_241637)) {
  case TAG_Ok: {
    V v_v_241638 = heff_field(v_x1_241637, 0);
    V v_ru_24x1_241637_24Ok = heff_take_reuse_n(v_x1_241637, 1ULL, 1);
    switch (heff_tag_of(v_v_241638)) {
    case TAG_VFun: {
      heff_take_n(v_v_241638, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241637_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241638, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241637_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241638, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241637_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241638, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241637_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241638, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241637_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241638, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241637_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241638, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241637_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241638, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241637_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241638, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241637_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241649 = heff_field(v_v_241638, 0);
      heff_take_n(v_v_241638, 1ULL, 1);
      V v_t_241650 = heff_intMul(heff_strLength_lent(v_a_241649, 0), MK_INT(8LL));
      return heff_tag_at_n(v_ru_24x1_241637_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_t_241650, v_a_241649})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241638, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241637_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241637_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241638);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241653 = heff_field(v_x1_241637, 0);
    V v_ru_24x1_241637_24Bug = heff_take_reuse_n(v_x1_241637, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241637_24Bug, TAG_Bug, 1, (V[]){v_what_241653});
  }
  default: return heff_nomatch(v_x1_241637);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam111(V self, V *args) {
  V v_n_241655 = args[0];
  V v_s_241656 = args[1];
  if ((heff_unbox_word(heff_intMod(v_n_241655, MK_INT(8LL))) == ((int64_t)0ULL))) {
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_s_241656})});
  } else {
    heff_drop(v_s_241656);
    return NTAG(TAG_Abn);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam113(V self, V *args) {
  V v_m_241661 = args[0];
  V v_t_241662 = args[1];
  V v_n_241659 = heff_env(self)[0];
  V v_s_241660 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_241665;
  if (heff_intEq_c(v_n_241659, v_m_241661)) {
    if (heff_strEq_c(v_s_241660, v_t_241662)) {
      v_t_241665 = ((V)&g_heff_2ecompile_2einterp_2eprim_str110);
    } else {
      v_t_241665 = ((V)&g_heff_2ecompile_2einterp_2eprim_str111);
    }
  } else {
    heff_drop(v_t_241662);
    heff_drop(v_s_241660);
    v_t_241665 = ((V)&g_heff_2ecompile_2einterp_2eprim_str112);
  }
  V v_t_241666 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241665, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241666});
}
V g_heff_2ecompile_2einterp_2eprim_lam112(V self, V *args) {
  V v_n_241659 = args[0];
  V v_s_241660 = args[1];
  V v_t_241667 = (g_heff_2ecompile_2einterp_2ebits1(heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam113, 2, 2, (V[]){v_n_241659, v_s_241660})));
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241667});
}
V g_heff_2ecompile_2einterp_2eprim_lam115(V self, V *args) {
  V v_d_241678 = args[0];
  V v_a_241679 = args[1];
  V v_a_241677 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241680 = heff_tr(heff_call(v_a_241679, 1, (V[]){v_d_241678}));
  switch (heff_tag_of(v_x1_241680)) {
  case TAG_Ok: {
    V v_v_241681 = heff_field(v_x1_241680, 0);
    V v_ru_24x1_241680_24Ok = heff_take_reuse_n(v_x1_241680, 1ULL, 1);
    switch (heff_tag_of(v_v_241681)) {
    case TAG_VFun: {
      heff_take_n(v_v_241681, 0ULL, 1);
      heff_drop(v_a_241677);
      heff_drop_cell(v_ru_24x1_241680_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241681, 0ULL, 1);
      heff_drop(v_a_241677);
      heff_drop_cell(v_ru_24x1_241680_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241681, 0ULL, 2);
      heff_drop(v_a_241677);
      heff_drop_cell(v_ru_24x1_241680_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241681, 0ULL, 1);
      heff_drop(v_a_241677);
      heff_drop_cell(v_ru_24x1_241680_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_241687 = heff_tflat_f64(v_v_241681, 0);
      heff_take_na(v_v_241681, 0ULL, 1);
      if (heff_intEq_c_lent(v_a_241677, MK_INT(64LL), 2)) {
        heff_drop(v_a_241677);
        V v_t_241689 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(11LL), MK_INT(52LL), v_a_241687));
        return heff_tag_at_n(v_ru_24x1_241680_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_241689})});
      } else {
        if (heff_intEq_c(v_a_241677, MK_INT(32LL))) {
          double v_t_241691 = ((double)((float)v_a_241687));
          V v_t_241692 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(8LL), MK_INT(23LL), v_t_241691));
          return heff_tag_at_n(v_ru_24x1_241680_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_241692})});
        } else {
          heff_drop_cell(v_ru_24x1_241680_24Ok, 1);
          return NTAG(TAG_Abn);
        }
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241681, 0ULL, 1);
      heff_drop(v_a_241677);
      heff_drop_cell(v_ru_24x1_241680_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241681, 0ULL, 1);
      heff_drop(v_a_241677);
      heff_drop_cell(v_ru_24x1_241680_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241681, 0ULL, 1);
      heff_drop(v_a_241677);
      heff_drop_cell(v_ru_24x1_241680_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241681, 0ULL, 1);
      heff_drop(v_a_241677);
      heff_drop_cell(v_ru_24x1_241680_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241681, 0ULL, 1);
      heff_drop(v_a_241677);
      heff_drop_cell(v_ru_24x1_241680_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241681, 0ULL, 2);
      heff_drop(v_a_241677);
      heff_drop_cell(v_ru_24x1_241680_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241677);
      heff_drop_cell(v_ru_24x1_241680_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_241681);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241677);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241677);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241700 = heff_field(v_x1_241680, 0);
    V v_ru_24x1_241680_24Bug = heff_take_reuse_n(v_x1_241680, 1ULL, 1);
    heff_drop(v_a_241677);
    return heff_tag_at_n(v_ru_24x1_241680_24Bug, TAG_Bug, 1, (V[]){v_what_241700});
  }
  default: return heff_nomatch(v_x1_241680);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam114(V self, V *args) {
  V v_d_241669 = args[0];
  V v_a_241670 = args[1];
  V v_x1_241671 = heff_tr(heff_call(v_a_241670, 1, (V[]){v_d_241669}));
  switch (heff_tag_of(v_x1_241671)) {
  case TAG_Ok: {
    V v_v_241672 = heff_field(v_x1_241671, 0);
    V v_ru_24x1_241671_24Ok = heff_take_reuse_n(v_x1_241671, 1ULL, 1);
    switch (heff_tag_of(v_v_241672)) {
    case TAG_VFun: {
      heff_take_n(v_v_241672, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241671_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241672, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241671_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241672, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241671_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241677 = heff_field(v_v_241672, 0);
      heff_take_n(v_v_241672, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241671_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam115, 2, 1, (V[]){v_a_241677})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241672, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241671_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241672, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241671_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241672, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241671_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241672, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241671_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241672, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241671_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241672, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241671_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241672, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241671_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241671_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241672);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241709 = heff_field(v_x1_241671, 0);
    V v_ru_24x1_241671_24Bug = heff_take_reuse_n(v_x1_241671, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241671_24Bug, TAG_Bug, 1, (V[]){v_what_241709});
  }
  default: return heff_nomatch(v_x1_241671);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam117(V self, V *args) {
  V v_d_241720 = args[0];
  V v_a_241721 = args[1];
  V v_a_241719 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241722 = heff_tr(heff_call(v_a_241721, 1, (V[]){v_d_241720}));
  switch (heff_tag_of(v_x1_241722)) {
  case TAG_Ok: {
    V v_v_241723 = heff_field(v_x1_241722, 0);
    heff_take_n(v_x1_241722, 1ULL, 1);
    switch (heff_tag_of(v_v_241723)) {
    case TAG_VFun: {
      heff_take_n(v_v_241723, 0ULL, 1);
      heff_drop(v_a_241719);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241723, 0ULL, 1);
      heff_drop(v_a_241719);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241723, 0ULL, 2);
      heff_drop(v_a_241719);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241728 = heff_field(v_v_241723, 0);
      heff_take_n(v_v_241723, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2efloatOfBitsV(v_a_241719, v_a_241728));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241723, 0ULL, 1);
      heff_drop(v_a_241719);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241723, 0ULL, 1);
      heff_drop(v_a_241719);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241723, 0ULL, 1);
      heff_drop(v_a_241719);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241723, 0ULL, 1);
      heff_drop(v_a_241719);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241723, 0ULL, 1);
      heff_drop(v_a_241719);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241723, 0ULL, 1);
      heff_drop(v_a_241719);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241723, 0ULL, 2);
      heff_drop(v_a_241719);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241719);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241723);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241719);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241719);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241737 = heff_field(v_x1_241722, 0);
    V v_ru_24x1_241722_24Bug = heff_take_reuse_n(v_x1_241722, 1ULL, 1);
    heff_drop(v_a_241719);
    return heff_tag_at_n(v_ru_24x1_241722_24Bug, TAG_Bug, 1, (V[]){v_what_241737});
  }
  default: return heff_nomatch(v_x1_241722);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam116(V self, V *args) {
  V v_d_241711 = args[0];
  V v_a_241712 = args[1];
  V v_x1_241713 = heff_tr(heff_call(v_a_241712, 1, (V[]){v_d_241711}));
  switch (heff_tag_of(v_x1_241713)) {
  case TAG_Ok: {
    V v_v_241714 = heff_field(v_x1_241713, 0);
    V v_ru_24x1_241713_24Ok = heff_take_reuse_n(v_x1_241713, 1ULL, 1);
    switch (heff_tag_of(v_v_241714)) {
    case TAG_VFun: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241714, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241719 = heff_field(v_v_241714, 0);
      heff_take_n(v_v_241714, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241713_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam117, 2, 1, (V[]){v_a_241719})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241714, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241714);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241746 = heff_field(v_x1_241713, 0);
    V v_ru_24x1_241713_24Bug = heff_take_reuse_n(v_x1_241713, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241713_24Bug, TAG_Bug, 1, (V[]){v_what_241746});
  }
  default: return heff_nomatch(v_x1_241713);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam118(V self, V *args) {
  V v_a_241748 = args[0];
  V v_b_241749 = args[1];
  V v_t_241751;
  if (heff_intEq_c(v_a_241748, v_b_241749)) {
    v_t_241751 = ((V)&g_heff_2ecompile_2einterp_2eprim_str116);
  } else {
    v_t_241751 = ((V)&g_heff_2ecompile_2einterp_2eprim_str117);
  }
  V v_t_241752 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241751, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241752});
}
V g_heff_2ecompile_2einterp_2eprim_lam119(V self, V *args) {
  V v_a_241754 = args[0];
  V v_b_241755 = args[1];
  V v_t_241757;
  if (heff_intLt_c(v_a_241754, v_b_241755)) {
    v_t_241757 = ((V)&g_heff_2ecompile_2einterp_2eprim_str119);
  } else {
    v_t_241757 = ((V)&g_heff_2ecompile_2einterp_2eprim_str120);
  }
  V v_t_241758 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241757, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241758});
}
V g_heff_2ecompile_2einterp_2eprim_lam120(V self, V *args) {
  V v_a_241760 = args[0];
  V v_b_241761 = args[1];
  V v_t_241763;
  if (heff_intLe_c(v_a_241760, v_b_241761)) {
    v_t_241763 = ((V)&g_heff_2ecompile_2einterp_2eprim_str122);
  } else {
    v_t_241763 = ((V)&g_heff_2ecompile_2einterp_2eprim_str123);
  }
  V v_t_241764 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241763, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241764});
}
V g_heff_2ecompile_2einterp_2eprim_lam121(V self, V *args) {
  V v_d_241766 = args[0];
  V v_a_241767 = args[1];
  V v_x1_241768 = heff_tr(heff_call(v_a_241767, 1, (V[]){v_d_241766}));
  switch (heff_tag_of(v_x1_241768)) {
  case TAG_Ok: {
    V v_v_241769 = heff_field(v_x1_241768, 0);
    V v_ru_24x1_241768_24Ok = heff_take_reuse_n(v_x1_241768, 1ULL, 1);
    switch (heff_tag_of(v_v_241769)) {
    case TAG_VFun: {
      heff_take_n(v_v_241769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241769, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VRune: {
      V v_a_241778 = heff_field(v_v_241769, 0);
      heff_take_n(v_v_241769, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241768_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_241778})});
    }
    case TAG_VArr: {
      heff_take_n(v_v_241769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241769, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241769, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241768_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    default: return heff_nomatch(v_v_241769);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241783 = heff_field(v_x1_241768, 0);
    V v_ru_24x1_241768_24Bug = heff_take_reuse_n(v_x1_241768, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241768_24Bug, TAG_Bug, 1, (V[]){v_what_241783});
  }
  default: return heff_nomatch(v_x1_241768);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam123(V self, V *args) {
  V v_d_241787 = args[0];
  V v_a_241788 = args[1];
  V f_ = v_a_241788;
  args[0] = v_d_241787;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2einterp_2eprim_lam122(V self, V *args) {
  V v_d_241785 = args[0];
  V v_u_241786 = args[1];
  heff_drop(v_d_241785);
  heff_drop(v_u_241786);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam123_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam124(V self, V *args) {
  V v_d_241790 = args[0];
  V v_a_241791 = args[1];
  V v_x1_241792 = heff_tr(heff_call(v_a_241791, 1, (V[]){v_d_241790}));
  switch (heff_tag_of(v_x1_241792)) {
  case TAG_Ok: {
    V v_v_241793 = heff_field(v_x1_241792, 0);
    V v_ru_24x1_241792_24Ok = heff_take_reuse_n(v_x1_241792, 1ULL, 1);
    switch (heff_tag_of(v_v_241793)) {
    case TAG_VFun: {
      heff_take_n(v_v_241793, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241792_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241793, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241792_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241793, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241792_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241798 = heff_field(v_v_241793, 0);
      heff_take_n(v_v_241793, 1ULL, 1);
      V v_t_241799 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_241800 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_241801 = heff_intSub(v_a_241798, heff_intSub(MK_INT(0LL), v_t_241800));
      V v_t_241802 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(32LL)));
      V v_t_241803 = heff_intAdd(heff_intSub(MK_INT(0LL), v_t_241799), heff_intMod(v_t_241801, v_t_241802));
      return heff_tag_at_n(v_ru_24x1_241792_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VRune, 1, (V[]){v_t_241803})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241793, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241792_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241793, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241792_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241793, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241792_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241793, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241792_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241793, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241792_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241793, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241792_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241793, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241792_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241792_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241793);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241812 = heff_field(v_x1_241792, 0);
    V v_ru_24x1_241792_24Bug = heff_take_reuse_n(v_x1_241792, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241792_24Bug, TAG_Bug, 1, (V[]){v_what_241812});
  }
  default: return heff_nomatch(v_x1_241792);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam125(V self, V *args) {
  V v_d_241814 = args[0];
  V v_a_241815 = args[1];
  V v_x1_241816 = heff_tr(heff_call(v_a_241815, 1, (V[]){v_d_241814}));
  switch (heff_tag_of(v_x1_241816)) {
  case TAG_Ok: {
    V v_v_241817 = heff_field(v_x1_241816, 0);
    V v_ru_24x1_241816_24Ok = heff_take_reuse_n(v_x1_241816, 1ULL, 1);
    switch (heff_tag_of(v_v_241817)) {
    case TAG_VFun: {
      heff_take_n(v_v_241817, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241816_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241817, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241816_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241817, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241816_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241817, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241816_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241817, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241816_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241817, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241816_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241825 = heff_field(v_v_241817, 0);
      heff_take_n(v_v_241817, 1ULL, 1);
      V v_t_241826 = (g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(heff_strRunes(v_a_241825)));
      return heff_tag_at_n(v_ru_24x1_241816_24Ok, TAG_Ok, 1, (V[]){v_t_241826});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241817, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241816_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241817, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241816_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241817, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241816_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241817, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241816_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241816_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241817);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241832 = heff_field(v_x1_241816, 0);
    V v_ru_24x1_241816_24Bug = heff_take_reuse_n(v_x1_241816, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241816_24Bug, TAG_Bug, 1, (V[]){v_what_241832});
  }
  default: return heff_nomatch(v_x1_241816);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam126(V self, V *args) {
  V v_d_241834 = args[0];
  V v_l_241835 = args[1];
  V v_x1_241836 = heff_tr(heff_call(v_l_241835, 1, (V[]){v_d_241834}));
  switch (heff_tag_of(v_x1_241836)) {
  case TAG_Ok: {
    V v_v_241837 = heff_field(v_x1_241836, 0);
    V v_ru_24x1_241836_24Ok = heff_take_reuse_n(v_x1_241836, 1ULL, 1);
    V v_t_241838 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241837, NTAG(TAG_Nil)));
    V v_t_241839 = (g_heff_2ecompile_2einterp_2eruneCodes(v_t_241838));
    V v_t_241840 = (g_list_2emap(heff_dup(g_runeFromInt_get()), v_t_241839));
    V v_t_241841 = heff_tag_n(TAG_VStr, 1, (V[]){heff_strOfRunes(v_t_241840)});
    return heff_tag_at_n(v_ru_24x1_241836_24Ok, TAG_Ok, 1, (V[]){v_t_241841});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241842 = heff_field(v_x1_241836, 0);
    V v_ru_24x1_241836_24Bug = heff_take_reuse_n(v_x1_241836, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241836_24Bug, TAG_Bug, 1, (V[]){v_what_241842});
  }
  default: return heff_nomatch(v_x1_241836);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam127(V self, V *args) {
  V v_d_241848 = args[0];
  V v_a_241849 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241848);
  heff_drop(v_a_241849);
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprim_str129), v_p_240)});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str0, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str3, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str6, 2, "{ ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str7, 2, " }");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str9, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str10, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str11, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str15, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str16, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str17, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str20, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str21, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str22, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str23, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str24, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str25, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str26, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str27, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str28, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str29, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str30, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str31, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str32, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str33, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str34, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str35, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str36, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str37, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str38, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str39, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str40, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str41, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str42, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str43, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str44, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str45, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str46, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str47, 1, ")");
Clo g_heff_2ecompile_2einterp_2eshowValGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eshowValGo_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eshowValGo(V v_inArg_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VFun: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_243 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_243, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str0))) {
        V v_t_245 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str1), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str2)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VCons: {
    V v_fs_246 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_t_247 = heff_arrayToList(heff_take_field(v_fs_246, 0));
    V v_t_248 = heff_arrayToList(heff_get_n(v_fs_246, 2, 3));
    V v_t_249 = (g_heff_2eutil_2edict_2ezipKV(v_t_247, v_t_248));
    V v_x2_2410 = (g_list_2emap_24s1427000880x1925304966(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str3), v_t_249));
    V v_t_2413;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_xs_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str5); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str7)));
  }
  case TAG_VTag: {
    V v_x_2414 = heff_field(v_v_241, 0);
    V v_vs_2415 = heff_field(v_v_241, 1);
    V v_ru_24v_241_24VTag = heff_take_reuse_n(v_v_241, 3ULL, 2);
    HeffT2 v_t_2416 = (g_heff_2ecompile_2einterp_2elistValsGo_24cpr(heff_tag_at_n(v_ru_24v_241_24VTag, TAG_VTag, 2, (V[]){heff_dup(v_x_2414), heff_dup(v_vs_2415)}), NTAG(TAG_Nil)));
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        heff_drop(v_x_2414);
        heff_drop(v_vs_2415);
        V v_items_2420 = v_field_2418;
        V v_x2_2421 = (g_list_2emap_24s391931963x434308123(v_items_2420));
        V v_t_2424;
        switch (heff_tag_of(v_x2_2421)) {
        case TAG_Nil: {
          v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2422 = heff_field(v_x2_2421, 0);
          V v_xs_2423 = heff_field(v_x2_2421, 1);
          heff_take_n(v_x2_2421, 3ULL, 2);
          v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str9); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2421);
        }
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str10), heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str11)));
      } else {
        heff_drop(v_field_2418);
        switch (heff_tag_of(v_vs_2415)) {
        case TAG_Nil: {
          return v_x_2414;
        }
        case TAG_Cons: {
          if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
            V v_x2_2427 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str12), v_vs_2415));
            V v_t_2430;
            switch (heff_tag_of(v_x2_2427)) {
            case TAG_Nil: {
              v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str13);
              break;
            }
            case TAG_Cons: {
              V v_x_2428 = heff_field(v_x2_2427, 0);
              V v_xs_2429 = heff_field(v_x2_2427, 1);
              heff_take_n(v_x2_2427, 3ULL, 2);
              v_t_2430 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str14); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2427);
            }
            V v_t_2431 = heff_strAppend(v_x_2414, heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str15)));
            return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str16), v_t_2431);
          } else {
            V v_x2_2432 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str17), v_vs_2415));
            V v_t_2435;
            switch (heff_tag_of(v_x2_2432)) {
            case TAG_Nil: {
              v_t_2435 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str18);
              break;
            }
            case TAG_Cons: {
              V v_x_2433 = heff_field(v_x2_2432, 0);
              V v_xs_2434 = heff_field(v_x2_2432, 1);
              heff_take_n(v_x2_2432, 3ULL, 2);
              v_t_2435 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str19); V a_1 = v_x_2433; V a_2 = v_xs_2434; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2434); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2432);
            }
            return heff_strAppend(v_x_2414, v_t_2435);
          }
        }
        default: return heff_nomatch(v_vs_2415);
        }
      }
    }
  }
  case TAG_VInt: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2437 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2437, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str20))) {
        V v_t_2439 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str21), heff_strAppend(v_t_2439, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str22)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VFloat: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2441 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2441, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str23))) {
        V v_t_2443 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str24), heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str25)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VFloat32: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2445 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2445, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str26))) {
        V v_t_2447 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str27), heff_strAppend(v_t_2447, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str28)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VStr: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2449 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2449, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str29))) {
        V v_t_2451 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str30), heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str31)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VRune: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2453 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2453, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str32))) {
        V v_t_2455 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str33), heff_strAppend(v_t_2455, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str34)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VArr: {
    V v_xs_2456 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_x2_2457 = (g_list_2emap_24s391931963x434308123(heff_arrayToList(v_xs_2456)));
    V v_t_2460;
    switch (heff_tag_of(v_x2_2457)) {
    case TAG_Nil: {
      v_t_2460 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2458 = heff_field(v_x2_2457, 0);
      V v_xs_2459 = heff_field(v_x2_2457, 1);
      heff_take_n(v_x2_2457, 3ULL, 2);
      v_t_2460 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str36); V a_1 = v_x_2458; V a_2 = v_xs_2459; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2459); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2457);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str37), heff_strAppend(v_t_2460, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str38)));
  }
  case TAG_VBytes: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2462 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2462, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str39))) {
        V v_t_2464 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str40), heff_strAppend(v_t_2464, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str41)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VBits: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2467 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2467, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str42))) {
        V v_t_2469 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str43), heff_strAppend(v_t_2469, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str44)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
    }
  }
  case TAG_VErased: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2470 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2470, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str45))) {
        V v_t_2472 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str46), heff_strAppend(v_t_2472, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str47)));
      } else {
        return (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      }
    } else {
      return (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2eshowValGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_lam0, 1, 0};
Clo g_heff_2ecompile_2einterp_2eapplyErased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eapplyErased(V v_n_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_r_241)) {
  case TAG_RSucceeded: {
    V v_r1_242 = heff_dup(heff_field(v_r_241, 0));
    switch (heff_tag_of(v_r1_242)) {
    case TAG_VFun: {
      V v_f_243 = heff_field(v_r1_242, 0);
      V v_ru_24r1_242_24VFun = heff_take_reuse_n(v_r1_242, 1ULL, 1);
      heff_drop_tag(v_r_241, 1);
      if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
        heff_drop(v_n_240);
        return heff_tag_n(TAG_RSucceeded, 1, (V[]){heff_tag_at_n(v_ru_24r1_242_24VFun, TAG_VFun, 1, (V[]){v_f_243})});
      } else {
        heff_drop_cell(v_ru_24r1_242_24VFun, 1);
        V v_x1_246 = heff_tr(heff_call(v_f_243, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo)}));
        V v_t_249;
        switch (heff_tag_of(v_x1_246)) {
        case TAG_Ok: {
          V v_v_247 = heff_field(v_x1_246, 0);
          V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
          v_t_249 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_RSucceeded, 1, (V[]){v_v_247});
          break;
        }
        case TAG_Abn: {
          v_t_249 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          v_t_249 = NTAG(TAG_RDiverged);
          break;
        }
        case TAG_Bug: {
          V v_what_248 = heff_field(v_x1_246, 0);
          V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
          v_t_249 = heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_RBug, 1, (V[]){v_what_248});
          break;
        }
        default: heff_nomatch(v_x1_246);
        }
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_t_249;
        v_n_240 = t_0;
        v_r_241 = t_1;
        goto top;
      }
    }
    case TAG_VCons: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VTag: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VInt: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat: {
      heff_take_na(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat32: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VStr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VRune: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VArr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBytes: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBits: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VErased: {
      heff_drop(v_n_240);
      return v_r_241;
    }
    default: return heff_nomatch(v_r1_242);
    }
  }
  case TAG_RAbandoned: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RDiverged: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RBug: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  default: return heff_nomatch(v_r_241);
  }
}
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eapplyErased(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args) {
  V v_d_245 = args[0];
  heff_drop(v_d_245);
  return heff_tag_n(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
}
Clo g_heff_2ecompile_2einterp_2ereachGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ereachGlobals_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ereachGlobals(V v_gs_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_gs_240, 7);
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_seen_241, v_k_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      V v_t_2410 = heff_bool(((v_tag_246 == ((int64_t)0ULL)) && ({ V v_x_249 = heff_dup(v_field_247); int c_ = 1; heff_drop(v_x_249); c_; })));
      heff_drop(v_field_247);
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_k_243);
        heff_drop(v_t_2410);
        V t_0 = v_gs_240;
        V t_1 = v_seen_241;
        V t_2 = v_rest_244;
        v_gs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_2410);
        V v_t_2411 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_seen_241, heff_dup(v_k_243), NTAG(TAG_MkUnit)));
        HeffT2 v_t_2412 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_gs_240, 1), v_k_243));
        V v_t_2429;
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            heff_drop(v_k_243);
            V v_e_2416 = v_field_2414;
            V v_t_2417 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_get_n(v_e_2416, 0, 4)));
            v_t_2429 = (g_heff_2eelab_2erename_2enubFirst(v_t_2417));
          } else {
            heff_drop(v_field_2414);
            HeffT2 v_t_2418 = ({ V a_0 = heff_rfield(v_gs_240, 2); V a_1 = v_k_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_k_243); r_; });
            {
              V v_field_2420 = v_t_2418.f[1];
              int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
              if ((v_tag_2419 == ((int64_t)0ULL))) {
                V v_k2_2422 = v_field_2420;
                HeffT2 v_t_2423 = ({ V a_0 = heff_rfield(v_gs_240, 1); V a_1 = v_k2_2422; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_k2_2422); r_; });
                {
                  V v_field_2425 = v_t_2423.f[1];
                  int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                  if ((v_tag_2424 == ((int64_t)0ULL))) {
                    V v_entry_2427 = v_field_2425;
                    V v_t_2428 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_get_n(v_entry_2427, 0, 4)));
                    v_t_2429 = (g_heff_2eelab_2erename_2enubFirst(v_t_2428));
                  } else {
                    heff_drop(v_field_2425);
                    v_t_2429 = NTAG(TAG_Nil);
                  }
                }
              } else {
                heff_drop(v_field_2420);
                v_t_2429 = NTAG(TAG_Nil);
              }
            }
          }
        }
        V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2429, v_rest_244));
        V t_0 = v_gs_240;
        V t_1 = v_t_2411;
        V t_2 = v_t_2430;
        v_gs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2einterp_2ereachGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ereachGlobals(a[0], a[1], a[2]);
}