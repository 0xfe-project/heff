// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_Ok 9325
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_keys 9783995
#define LBL_values 1123329101
V g_heff_2ecompile_2einterp_2eapplyErased(V, V);
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eapplyErased_clo;
V g_heff_2ecompile_2einterp_2ebits1(V);
V g_heff_2ecompile_2einterp_2ebits1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebits1_clo;
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void);
V g_heff_2ecompile_2einterp_2ebitsCopy(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsCopy_clo;
V g_heff_2ecompile_2einterp_2ebitsJoined(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsJoined_clo;
V g_heff_2ecompile_2einterp_2ebitsOfIntV(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsOfIntV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsOfIntV_clo;
V g_heff_2ecompile_2einterp_2ebyteString(V, V);
V g_heff_2ecompile_2einterp_2ebyteString_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebyteString_clo;
V g_heff_2ecompile_2einterp_2ebytes2(V);
V g_heff_2ecompile_2einterp_2ebytes2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytes2_clo;
V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get(void);
V g_heff_2ecompile_2einterp_2ebytesJoined(V, V);
V g_heff_2ecompile_2einterp_2ebytesJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesJoined_clo;
V g_heff_2ecompile_2einterp_2ebytesOfIntV(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfIntV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfIntV_clo;
V g_heff_2ecompile_2einterp_2ebytesOfNat(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfNat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfNat_clo;
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void);
V g_heff_2ecompile_2einterp_2efixedPrimV(V);
V g_heff_2ecompile_2einterp_2efixedPrimV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedPrimV_clo;
V g_heff_2ecompile_2einterp_2efloat2(V);
V g_heff_2ecompile_2einterp_2efloat2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloat2_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get(void);
V g_heff_2ecompile_2einterp_2efloatOfBitsV(V, V);
V g_heff_2ecompile_2einterp_2efloatOfBitsV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloatOfBitsV_clo;
V g_heff_2ecompile_2einterp_2efloatTake2(V, V, V);
V g_heff_2ecompile_2einterp_2efloatTake2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloatTake2_clo;
V g_heff_2ecompile_2einterp_2efromListV(V, V);
V g_heff_2ecompile_2einterp_2efromListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efromListV_clo;
V g_heff_2ecompile_2einterp_2egenGo(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2egenGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2egenGo_clo;
V g_heff_2ecompile_2einterp_2eieeeBits_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeBits(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeBits_clo;
V g_heff_2ecompile_2einterp_2eieeeMagnitude_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeMagnitude(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeMagnitude_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeMagnitude_clo;
double g_heff_2ecompile_2einterp_2eieeeOf_w(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeOf_clo;
V g_heff_2ecompile_2einterp_2eint2(V);
V g_heff_2ecompile_2einterp_2eint2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eint2_clo;
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void);
V g_heff_2ecompile_2einterp_2eintAtV(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintAtV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintAtV_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_clo;
V g_heff_2ecompile_2einterp_2elistValsGo(V, V);
V g_heff_2ecompile_2einterp_2elistValsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elistValsGo_clo;
V g_heff_2ecompile_2einterp_2elittleOut(V, V);
V g_heff_2ecompile_2einterp_2elittleOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elittleOut_clo;
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotARune_get(void);
V g_heff_2ecompile_2einterp_2enotAString_get(void);
V g_heff_2ecompile_2einterp_2enotAnArray_get(void);
V g_heff_2ecompile_2einterp_2enotAnInt_get(void);
V g_heff_2ecompile_2einterp_2enotBytes_get(void);
V g_heff_2ecompile_2einterp_2enthTh(V, V);
V g_heff_2ecompile_2einterp_2enthTh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2enthTh_clo;
V g_heff_2ecompile_2einterp_2enthV(V, V);
V g_heff_2ecompile_2einterp_2enthV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2enthV_clo;
V g_heff_2ecompile_2einterp_2eprim(V);
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eprim_clo;
V g_heff_2ecompile_2einterp_2erune2(V);
V g_heff_2ecompile_2einterp_2erune2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2erune2_clo;
V g_heff_2ecompile_2einterp_2eruneCodes(V);
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_clo;
V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V, V);
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo;
V g_heff_2ecompile_2einterp_2escalarV(V);
V g_heff_2ecompile_2einterp_2escalarV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2escalarV_clo;
V g_heff_2ecompile_2einterp_2esetAt(V, V, V);
V g_heff_2ecompile_2einterp_2esetAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esetAt_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2einterp_2estr2(V);
V g_heff_2ecompile_2einterp_2estr2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2estr2_clo;
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get(void);
V g_heff_2ecompile_2einterp_2etoListV(V);
V g_heff_2ecompile_2einterp_2etoListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(V, V, V);
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(V);
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_clo;
V g_heff_2ecompile_2einterp_2etwoTo(V);
V g_heff_2ecompile_2einterp_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoTo_clo;
V g_heff_2ecompile_2einterp_2ewordOf(V, V, V);
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ewordOf_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1427000880x1925304966(V, V);
V g_list_2emap_24s1427000880x1925304966_entry(V self, V *a);
extern Clo g_list_2emap_24s1427000880x1925304966_clo;
V g_list_2emap_24s391931963x434308123(V);
V g_list_2emap_24s391931963x434308123_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_clo;
V g_list_2emap_24s503834852x510769098(V, V);
V g_list_2emap_24s503834852x510769098_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_rune_2efromInt_get(void);
V g_rune_2evalidFrom(V, V);
V g_rune_2evalidFrom_entry(V self, V *a);
extern Clo g_rune_2evalidFrom_clo;
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAnInt_str0, 38, "a primitive given what is not an `Int`");

static V g_heff_2ecompile_2einterp_2enotAnInt_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAnInt_st;
static V g_heff_2ecompile_2einterp_2enotAnInt_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAnInt_str0)});
}
V g_heff_2ecompile_2einterp_2enotAnInt_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAnInt_st)) return g_heff_2ecompile_2einterp_2enotAnInt_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAnInt_val, &g_heff_2ecompile_2einterp_2enotAnInt_st, g_heff_2ecompile_2einterp_2enotAnInt_init);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAFloat64_str0, 41, "a primitive given what is not a `Float64`");

static V g_heff_2ecompile_2einterp_2enotAFloat64_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAFloat64_st;
static V g_heff_2ecompile_2einterp_2enotAFloat64_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAFloat64_str0)});
}
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAFloat64_st)) return g_heff_2ecompile_2einterp_2enotAFloat64_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAFloat64_val, &g_heff_2ecompile_2einterp_2enotAFloat64_st, g_heff_2ecompile_2einterp_2enotAFloat64_init);
}
Clo g_heff_2ecompile_2einterp_2efloatTake2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloatTake2_entry, 3, 0};

V g_heff_2ecompile_2einterp_2efloatTake2(V v_f_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_VFun: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VCons: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VTag: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VInt: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VFloat: {
    V v_a_248 = heff_tget_v(v_x2_241, 0);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_VFun: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      V v_b_2414 = heff_tget_v(v_x3_242, 0);
      return heff_tail(v_f_240, 2, (V[]){v_a_248, v_b_2414});
    }
    case TAG_VFloat32: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_VFloat32: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VStr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VRune: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VArr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VBytes: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VBits: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VErased: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2efloatTake2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2einterp_2efloatTake2(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2einterp_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ewordOf_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ewordOf(V v_n_240, V v_f_241, V v_v_242) {
top: ;
  if (heff_intEq_c(heff_intMod(v_f_241, MK_INT(2LL)), MK_INT(1LL))) {
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_245 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_246 = heff_intAdd(heff_intMod(v_v_242, v_t_244), v_t_245);
    V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    return (g_heff_2ecompile_2einterp_2elittleOut(heff_intMod(v_t_246, v_t_247), v_n_240));
  } else {
    V v_t_248 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_2410 = heff_intAdd(heff_intMod(v_v_242, v_t_248), v_t_249);
    V v_t_2411 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_240));
    return heff_intMod(v_t_2410, v_t_2411);
  }
}
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ewordOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsOfIntV_str0, 0, "");
Clo g_heff_2ecompile_2einterp_2ebitsOfIntV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsOfIntV_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ebitsOfIntV(V v_n_240, V v_f_241, V v_v_242) {
top: ;
  if (heff_intLt_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_f_241);
    heff_drop(v_v_242);
    return NTAG(TAG_Abn);
  } else {
    if (heff_intLt_c(MK_INT(64LL), heff_dup(v_n_240))) {
      heff_drop(v_n_240);
      heff_drop(v_f_241);
      heff_drop(v_v_242);
      return NTAG(TAG_Abn);
    } else {
      V v_w_245 = (g_heff_2ecompile_2einterp_2ewordOf(heff_dup(v_n_240), v_f_241, v_v_242));
      V v_t_246 = heff_intDiv(heff_intAdd(heff_dup(v_n_240), MK_INT(7LL)), MK_INT(8LL));
      V v_t_247 = heff_intDiv(heff_intAdd(heff_dup(v_n_240), MK_INT(7LL)), MK_INT(8LL));
      V v_t_248 = heff_intSub(heff_intMul(v_t_247, MK_INT(8LL)), heff_dup(v_n_240));
      V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(v_t_248));
      V v_t_2410 = (g_heff_2ecompile_2einterp_2ebytesOfNat(v_t_246, heff_intMul(v_w_245, v_t_249), ((V)&g_heff_2ecompile_2einterp_2ebitsOfIntV_str0)));
      return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_n_240, v_t_2410})});
    }
  }
}
V g_heff_2ecompile_2einterp_2ebitsOfIntV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitsOfIntV(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2eieeeBits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eieeeBits_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eieeeBits_w(V v_eb_240, V v_fb_241, double v_x_242) {
top: ;
  V v_t_244 = heff_bool(!(v_x_242 == v_x_242));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = (g_heff_2ecompile_2einterp_2etwoTo(v_eb_240));
    V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_fb_241)));
    V v_t_247 = heff_intMul(heff_intSub(v_t_245, MK_INT(1LL)), v_t_246);
    V v_t_248 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intSub(v_fb_241, MK_INT(1LL))));
    return heff_intAdd(v_t_247, v_t_248);
  } else {
    heff_drop(v_t_244);
    if ((v_x_242 < (0.0))) {
      V v_t_2410 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intAdd(heff_dup(v_eb_240), heff_dup(v_fb_241))));
      V v_t_2411 = (g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, ((0.0) - v_x_242)));
      return heff_intAdd(v_t_2410, v_t_2411);
    } else {
      if ((v_x_242 == (0.0))) {
        if ((((1.0) / v_x_242) < (0.0))) {
          V v_t_2414 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intAdd(heff_dup(v_eb_240), heff_dup(v_fb_241))));
          V v_t_2415 = (g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, ((0.0) - v_x_242)));
          return heff_intAdd(v_t_2414, v_t_2415);
        } else {
          HEFF_LAST return g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, v_x_242);
        }
      } else {
        HEFF_LAST return g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, v_x_242);
      }
    }
  }
}
V g_heff_2ecompile_2einterp_2eieeeBits(V v_eb_240, V v_fb_241, V v_box_24x_242) {
  double v_x_242 = heff_unbox_f64(v_box_24x_242);
  return (g_heff_2ecompile_2einterp_2eieeeBits_w(v_eb_240, v_fb_241, v_x_242));
}
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eieeeBits(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2efloatOfBitsV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloatOfBitsV_entry, 2, 0};

V g_heff_2ecompile_2einterp_2efloatOfBitsV(V v_n_240, V v_u_241) {
top: ;
  if (heff_intEq_c(heff_dup(v_n_240), MK_INT(64LL))) {
    heff_drop(v_n_240);
    V v_t_243 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    V v_t_245 = heff_intAdd(heff_intMod(v_u_241, v_t_243), v_t_244);
    V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    double v_t_247 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(11LL), MK_INT(52LL), heff_intMod(v_t_245, v_t_246)));
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_nf(TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_247)})});
  } else {
    if (heff_intEq_c(v_n_240, MK_INT(32LL))) {
      V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      V v_t_2410 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      V v_t_2411 = heff_intAdd(heff_intMod(v_u_241, v_t_249), v_t_2410);
      V v_t_2412 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      double v_t_2413 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(8LL), MK_INT(23LL), heff_intMod(v_t_2411, v_t_2412)));
      return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_nf(TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_2413)})});
    } else {
      heff_drop(v_u_241);
      return NTAG(TAG_Abn);
    }
  }
}
V g_heff_2ecompile_2einterp_2efloatOfBitsV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efloatOfBitsV(a[0], a[1]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eruneCodes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_VFun: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2411 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2411, heff_hole()});
      V v_u_2413 = (g_heff_2ecompile_2einterp_2eruneCodes_24dps(v_rest_242, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eruneCodes(a[0]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_VFun: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2412 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2412, heff_hole()});
      V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2413;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eruneCodes_24dps(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st;
static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st)) return g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val, &g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)(heff_unbox_f32(v_a_2414) / heff_unbox_f32(v_b_2421))))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st;
static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st)) return g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
  return heff_global(&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val, &g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init);
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = (g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(v_a_2412, v_b_2417));
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2418})});
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1, 2, 1, (V[]){v_a_241})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10, 36, "a primitive given what is not `Bits`");
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st;
static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st)) return g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val, &g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init);
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  V v_x1_242 = heff_tr(heff_call(v_a_241, 1, (V[]){v_d_240}));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Ok: {
    V v_v_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Ok = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_v_243)) {
    case TAG_VFun: {
      V v_ru_24v_243_24VFun = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFun, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0)});
    }
    case TAG_VCons: {
      V v_ru_24v_243_24VCons = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VCons, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1)});
    }
    case TAG_VTag: {
      heff_take_n(v_v_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2)});
    }
    case TAG_VInt: {
      V v_ru_24v_243_24VInt = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3)});
    }
    case TAG_VFloat: {
      V v_ru_24v_243_24VFloat = heff_take_reuse_na(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4)});
    }
    case TAG_VFloat32: {
      V v_ru_24v_243_24VFloat32 = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat32, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5)});
    }
    case TAG_VStr: {
      V v_ru_24v_243_24VStr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VStr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6)});
    }
    case TAG_VRune: {
      V v_ru_24v_243_24VRune = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VRune, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7)});
    }
    case TAG_VArr: {
      V v_ru_24v_243_24VArr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VArr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8)});
    }
    case TAG_VBytes: {
      V v_ru_24v_243_24VBytes = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VBytes, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9)});
    }
    case TAG_VBits: {
      V v_n_2415 = heff_field(v_v_243, 0);
      heff_take_n(v_v_243, 1ULL, 2);
      return heff_tag_at_n(v_ru_24x1_242_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_n_2415})});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10)});
    }
    default: return heff_nomatch(v_v_243);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2417 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Bug = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_242_24Bug, TAG_Bug, 1, (V[]){v_what_2417});
  }
  default: return heff_nomatch(v_x1_242);
  }
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str1, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str2, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str3, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str4, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str5, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str6, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str7, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str8, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str9, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str10, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str11, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str12, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str13, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str14, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str15, 6, "intAnd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str16, 5, "intOr");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str17, 6, "intXor");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str18, 6, "intShl");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str19, 6, "intShr");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str20, 8, "floatAdd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str21, 8, "floatSub");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str22, 8, "floatMul");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str23, 8, "floatDiv");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str24, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str25, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str26, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str27, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str28, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str29, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str30, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str31, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str32, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str33, 9, "floatShow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str34, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str35, 9, "floatSqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str36, 10, "floatFloor");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str37, 8, "floatSin");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str38, 8, "floatCos");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str39, 8, "floatTan");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str40, 9, "floatAsin");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str41, 9, "floatAcos");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str42, 9, "floatAtan");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str43, 10, "floatAtan2");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str44, 8, "floatExp");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str45, 8, "floatLog");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str46, 8, "floatPow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str47, 11, "arrayLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str48, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str49, 32, "an index in range, of no element");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str50, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str51, 13, "arrayGenerate");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str52, 13, "arrayFromList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str53, 11, "arrayToList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str54, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str55, 9, "strLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str56, 8, "strSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str57, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str58, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str59, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str60, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str61, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str62, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str63, 10, "strCompare");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str64, 7, "strFind");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str65, 9, "strByteAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str66, 11, "strFromByte");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str67, 9, "strRuneAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str68, 12, "strRuneWidth");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str69, 12, "strRuneCount");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str70, 7, "strToJS");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str71, 9, "strFromJS");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str72, 11, "bytesLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str73, 7, "bytesAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str74, 10, "bytesSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str75, 11, "bytesAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str76, 11, "bytesConcat");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str77, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str78, 7, "bytesEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str79, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str80, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str81, 13, "bytesFromList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str82, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str83, 11, "bytesToList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str84, 15, "bytesFromString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str85, 13, "bytesToString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str86, 10, "bytesIntAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str87, 10, "bytesOfInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str88, 10, "bytesHasAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str89, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str90, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str91, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str92, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str93, 10, "bitsLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str94, 9, "bitsIntAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str95, 9, "bitsOfInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str96, 10, "bitsConcat");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str97, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str98, 9, "bitsSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str99, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str100, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str101, 9, "bitsBytes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str102, 6, "bitsEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str103, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str104, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str105, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str106, 9, "floatBits");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str107, 11, "floatOfBits");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str108, 6, "runeEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str109, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str110, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str111, 6, "runeLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str112, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str113, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str114, 6, "runeLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str115, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str116, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str117, 9, "runeToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str118, 11, "runeFromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str119, 8, "strRunes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str120, 10, "strOfRunes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str121, 13, "no primitive ");
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam0, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam1, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam2, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam3, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam4, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam5, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam6, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam7, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam8, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam9, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam10, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam11, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam12, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam13, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam14, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam15, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam16, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam17, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam18, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam19, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam20, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam21, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam22, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam23, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam24, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam26, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam25, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam28, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam27, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam31, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam30, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam37_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam37, 1, 0};
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam35, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam34, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam39, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam38, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam41, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam40, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam42, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam43, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam46, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam47, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam48_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam48, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam49_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam49, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam51, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam53_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam53, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam54_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam54, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam56_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam56, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam58_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam58, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam59_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam59, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam60_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam60, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam61_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam61, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam62_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam62, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam64_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam64, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam67_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam67, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam68_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam68, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam69_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam69, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam70_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam70, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam71_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam71, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam72_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam72, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam73_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam73, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam77_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam77, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam80_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam80, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam83_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam83, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam87_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam87, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam90_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam90, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam91_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam91, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam94_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam94, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam95_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam95, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam96_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam96, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam98_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam98, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam100_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam100, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam102_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam102, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam103_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam103, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam104_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam104, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam105_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam105, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam106_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam106, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam107_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam107, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam108_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam108, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eprim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eprim(V v_p_240) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str0), 2)) {
    heff_drop(v_p_240);
    return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get());
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str1), 2)) {
      heff_drop(v_p_240);
      return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get());
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str2), 2)) {
        heff_drop(v_p_240);
        return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get());
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str3), 2)) {
          heff_drop(v_p_240);
          HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam0_clo));
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str4), 2)) {
            heff_drop(v_p_240);
            HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam1_clo));
          } else {
            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str5), 2)) {
              heff_drop(v_p_240);
              HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam2_clo));
            } else {
              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str8), 2)) {
                heff_drop(v_p_240);
                HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam3_clo));
              } else {
                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str11), 2)) {
                  heff_drop(v_p_240);
                  HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam4_clo));
                } else {
                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str14), 2)) {
                    heff_drop(v_p_240);
                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam5_clo)});
                  } else {
                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str15), 2)) {
                      heff_drop(v_p_240);
                      return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get());
                    } else {
                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str16), 2)) {
                        heff_drop(v_p_240);
                        HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam6_clo));
                      } else {
                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str17), 2)) {
                          heff_drop(v_p_240);
                          HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam7_clo));
                        } else {
                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str18), 2)) {
                            heff_drop(v_p_240);
                            HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam8_clo));
                          } else {
                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str19), 2)) {
                              heff_drop(v_p_240);
                              HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam9_clo));
                            } else {
                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str20), 2)) {
                                heff_drop(v_p_240);
                                return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get());
                              } else {
                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str21), 2)) {
                                  heff_drop(v_p_240);
                                  return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get());
                                } else {
                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str22), 2)) {
                                    heff_drop(v_p_240);
                                    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get());
                                  } else {
                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str23), 2)) {
                                      heff_drop(v_p_240);
                                      return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get());
                                    } else {
                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str24), 2)) {
                                        heff_drop(v_p_240);
                                        HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam10_clo));
                                      } else {
                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str27), 2)) {
                                          heff_drop(v_p_240);
                                          HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam11_clo));
                                        } else {
                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str30), 2)) {
                                            heff_drop(v_p_240);
                                            HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam12_clo));
                                          } else {
                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str33), 2)) {
                                              heff_drop(v_p_240);
                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam13_clo)});
                                            } else {
                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str34), 2)) {
                                                heff_drop(v_p_240);
                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam14_clo)});
                                              } else {
                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str35), 2)) {
                                                  heff_drop(v_p_240);
                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam15_clo)});
                                                } else {
                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str36), 2)) {
                                                    heff_drop(v_p_240);
                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam16_clo)});
                                                  } else {
                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str37), 2)) {
                                                      heff_drop(v_p_240);
                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam17_clo)});
                                                    } else {
                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str38), 2)) {
                                                        heff_drop(v_p_240);
                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam18_clo)});
                                                      } else {
                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str39), 2)) {
                                                          heff_drop(v_p_240);
                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam19_clo)});
                                                        } else {
                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str40), 2)) {
                                                            heff_drop(v_p_240);
                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam20_clo)});
                                                          } else {
                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str41), 2)) {
                                                              heff_drop(v_p_240);
                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam21_clo)});
                                                            } else {
                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str42), 2)) {
                                                                heff_drop(v_p_240);
                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam22_clo)});
                                                              } else {
                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str43), 2)) {
                                                                  heff_drop(v_p_240);
                                                                  return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get());
                                                                } else {
                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str44), 2)) {
                                                                    heff_drop(v_p_240);
                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam23_clo)});
                                                                  } else {
                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str45), 2)) {
                                                                      heff_drop(v_p_240);
                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam24_clo)});
                                                                    } else {
                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str46), 2)) {
                                                                        heff_drop(v_p_240);
                                                                        return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get());
                                                                      } else {
                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str47), 2)) {
                                                                          heff_drop(v_p_240);
                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam25_clo)});
                                                                        } else {
                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str48), 2)) {
                                                                            heff_drop(v_p_240);
                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam27_clo)});
                                                                          } else {
                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str50), 2)) {
                                                                              heff_drop(v_p_240);
                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam30_clo)});
                                                                            } else {
                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str51), 2)) {
                                                                                heff_drop(v_p_240);
                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam34_clo)});
                                                                              } else {
                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str52), 2)) {
                                                                                  heff_drop(v_p_240);
                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam38_clo)});
                                                                                } else {
                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str53), 2)) {
                                                                                    heff_drop(v_p_240);
                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam40_clo)});
                                                                                  } else {
                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str54), 2)) {
                                                                                      heff_drop(v_p_240);
                                                                                      return heff_dup(g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get());
                                                                                    } else {
                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str55), 2)) {
                                                                                        heff_drop(v_p_240);
                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam42_clo)});
                                                                                      } else {
                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str56), 2)) {
                                                                                          heff_drop(v_p_240);
                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam43_clo)});
                                                                                        } else {
                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str57), 2)) {
                                                                                            heff_drop(v_p_240);
                                                                                            HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam46_clo));
                                                                                          } else {
                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str60), 2)) {
                                                                                              heff_drop(v_p_240);
                                                                                              HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam47_clo));
                                                                                            } else {
                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str63), 2)) {
                                                                                                heff_drop(v_p_240);
                                                                                                HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam48_clo));
                                                                                              } else {
                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str64), 2)) {
                                                                                                  heff_drop(v_p_240);
                                                                                                  HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam49_clo));
                                                                                                } else {
                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str65), 2)) {
                                                                                                    heff_drop(v_p_240);
                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam51_clo)});
                                                                                                  } else {
                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str66), 2)) {
                                                                                                      heff_drop(v_p_240);
                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam53_clo)});
                                                                                                    } else {
                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str67), 2)) {
                                                                                                        heff_drop(v_p_240);
                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam54_clo)});
                                                                                                      } else {
                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str68), 2)) {
                                                                                                          heff_drop(v_p_240);
                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam56_clo)});
                                                                                                        } else {
                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str69), 2)) {
                                                                                                            heff_drop(v_p_240);
                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam58_clo)});
                                                                                                          } else {
                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str70), 2)) {
                                                                                                              heff_drop(v_p_240);
                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam59_clo)});
                                                                                                            } else {
                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str71), 2)) {
                                                                                                                heff_drop(v_p_240);
                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam60_clo)});
                                                                                                              } else {
                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str72), 2)) {
                                                                                                                  heff_drop(v_p_240);
                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam61_clo)});
                                                                                                                } else {
                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str73), 2)) {
                                                                                                                    heff_drop(v_p_240);
                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam62_clo)});
                                                                                                                  } else {
                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str74), 2)) {
                                                                                                                      heff_drop(v_p_240);
                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam64_clo)});
                                                                                                                    } else {
                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str75), 2)) {
                                                                                                                        heff_drop(v_p_240);
                                                                                                                        return heff_dup(g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get());
                                                                                                                      } else {
                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str76), 2)) {
                                                                                                                          heff_drop(v_p_240);
                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam67_clo)});
                                                                                                                        } else {
                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str78), 2)) {
                                                                                                                            heff_drop(v_p_240);
                                                                                                                            HEFF_LAST return g_heff_2ecompile_2einterp_2ebytes2(((V)&g_heff_2ecompile_2einterp_2eprim_lam68_clo));
                                                                                                                          } else {
                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str81), 2)) {
                                                                                                                              heff_drop(v_p_240);
                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam69_clo)});
                                                                                                                            } else {
                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str83), 2)) {
                                                                                                                                heff_drop(v_p_240);
                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam70_clo)});
                                                                                                                              } else {
                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str84), 2)) {
                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam71_clo)});
                                                                                                                                } else {
                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str85), 2)) {
                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam72_clo)});
                                                                                                                                  } else {
                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str86), 2)) {
                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam73_clo)});
                                                                                                                                    } else {
                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str87), 2)) {
                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam77_clo)});
                                                                                                                                      } else {
                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str88), 2)) {
                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam80_clo)});
                                                                                                                                        } else {
                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str93), 2)) {
                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                            return heff_dup(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get());
                                                                                                                                          } else {
                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str94), 2)) {
                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                              HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam83_clo));
                                                                                                                                            } else {
                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str95), 2)) {
                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam87_clo)});
                                                                                                                                              } else {
                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str96), 2)) {
                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam90_clo)});
                                                                                                                                                } else {
                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str98), 2)) {
                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                    HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam91_clo));
                                                                                                                                                  } else {
                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str100), 2)) {
                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam94_clo)});
                                                                                                                                                    } else {
                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str101), 2)) {
                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                        HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam95_clo));
                                                                                                                                                      } else {
                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str102), 2)) {
                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                          HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam96_clo));
                                                                                                                                                        } else {
                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str106), 2)) {
                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam98_clo)});
                                                                                                                                                          } else {
                                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str107), 2)) {
                                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam100_clo)});
                                                                                                                                                            } else {
                                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str108), 2)) {
                                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                                HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam102_clo));
                                                                                                                                                              } else {
                                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str111), 2)) {
                                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                                  HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam103_clo));
                                                                                                                                                                } else {
                                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str114), 2)) {
                                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                                    HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam104_clo));
                                                                                                                                                                  } else {
                                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str117), 2)) {
                                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam105_clo)});
                                                                                                                                                                    } else {
                                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str118), 2)) {
                                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam106_clo)});
                                                                                                                                                                      } else {
                                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str119), 2)) {
                                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam107_clo)});
                                                                                                                                                                        } else {
                                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str120), 2)) {
                                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam108_clo)});
                                                                                                                                                                          } else {
                                                                                                                                                                            V v_t_241588 = (g_heff_2eelab_2efixed_2efixedPrimOf(heff_dup(v_p_240)));
                                                                                                                                                                            switch (heff_tag_of(v_t_241588)) {
                                                                                                                                                                            case TAG_Nothing: {
                                                                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam109, 2, 1, (V[]){v_p_240})});
                                                                                                                                                                            }
                                                                                                                                                                            case TAG_Just: {
                                                                                                                                                                              V v_fp_241591 = heff_field(v_t_241588, 0);
                                                                                                                                                                              heff_take_n(v_t_241588, 1ULL, 1);
                                                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                                                              HEFF_LAST return g_heff_2ecompile_2einterp_2efixedPrimV(v_fp_241591);
                                                                                                                                                                            }
                                                                                                                                                                            default: return heff_nomatch(v_t_241588);
                                                                                                                                                                            }
                                                                                                                                                                          }
                                                                                                                                                                        }
                                                                                                                                                                      }
                                                                                                                                                                    }
                                                                                                                                                                  }
                                                                                                                                                                }
                                                                                                                                                              }
                                                                                                                                                            }
                                                                                                                                                          }
                                                                                                                                                        }
                                                                                                                                                      }
                                                                                                                                                    }
                                                                                                                                                  }
                                                                                                                                                }
                                                                                                                                              }
                                                                                                                                            }
                                                                                                                                          }
                                                                                                                                        }
                                                                                                                                      }
                                                                                                                                    }
                                                                                                                                  }
                                                                                                                                }
                                                                                                                              }
                                                                                                                            }
                                                                                                                          }
                                                                                                                        }
                                                                                                                      }
                                                                                                                    }
                                                                                                                  }
                                                                                                                }
                                                                                                              }
                                                                                                            }
                                                                                                          }
                                                                                                        }
                                                                                                      }
                                                                                                    }
                                                                                                  }
                                                                                                }
                                                                                              }
                                                                                            }
                                                                                          }
                                                                                        }
                                                                                      }
                                                                                    }
                                                                                  }
                                                                                }
                                                                              }
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eprim(a[0]);
}
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_b_246 = args[1];
  if (heff_intEq_c(heff_dup(v_b_246), MK_INT(0LL))) {
    heff_drop(v_a_245);
    heff_drop(v_b_246);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){MK_INT(0LL)})});
  } else {
    V v_t_248 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_245, v_b_246)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_248});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args) {
  V v_a_2410 = args[0];
  V v_b_2411 = args[1];
  if (heff_intEq_c(heff_dup(v_b_2411), MK_INT(0LL))) {
    heff_drop(v_b_2411);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_2410})});
  } else {
    V v_t_2413 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMod(v_a_2410, v_b_2411)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2413});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args) {
  V v_a_2415 = args[0];
  V v_b_2416 = args[1];
  V v_t_2418;
  if (heff_intEq_c(v_a_2415, v_b_2416)) {
    v_t_2418 = ((V)&g_heff_2ecompile_2einterp_2eprim_str6);
  } else {
    v_t_2418 = ((V)&g_heff_2ecompile_2einterp_2eprim_str7);
  }
  V v_t_2419 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2419});
}
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args) {
  V v_a_2421 = args[0];
  V v_b_2422 = args[1];
  V v_t_2424;
  if (heff_intLt_c(v_a_2421, v_b_2422)) {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2eprim_str9);
  } else {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2eprim_str10);
  }
  V v_t_2425 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2425});
}
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args) {
  V v_a_2427 = args[0];
  V v_b_2428 = args[1];
  V v_t_2430;
  if (heff_intLe_c(v_a_2427, v_b_2428)) {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2eprim_str12);
  } else {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2eprim_str13);
  }
  V v_t_2431 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2431});
}
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args) {
  V v_d_2433 = args[0];
  V v_a_2434 = args[1];
  V v_x1_2435 = heff_tr(heff_call(v_a_2434, 1, (V[]){v_d_2433}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_Ok: {
    V v_v_2436 = heff_field(v_x1_2435, 0);
    V v_ru_24x1_2435_24Ok = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
    switch (heff_tag_of(v_v_2436)) {
    case TAG_VFun: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2436, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_2441 = heff_field(v_v_2436, 0);
      V v_ru_24v_2436_24VInt = heff_take_reuse_n(v_v_2436, 1ULL, 1);
      V v_t_2442 = heff_tag_at_n(v_ru_24v_2436_24VInt, TAG_VStr, 1, (V[]){heff_intShow(v_a_2441)});
      return heff_tag_at_n(v_ru_24x1_2435_24Ok, TAG_Ok, 1, (V[]){v_t_2442});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2436, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_2436);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2451 = heff_field(v_x1_2435, 0);
    V v_ru_24x1_2435_24Bug = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2435_24Bug, TAG_Bug, 1, (V[]){v_what_2451});
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args) {
  V v_a_2454 = args[0];
  V v_b_2455 = args[1];
  V v_t_2456 = (g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), v_a_2454, v_b_2455));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2456})});
}
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args) {
  V v_a_2458 = args[0];
  V v_b_2459 = args[1];
  V v_t_2460 = (g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(MK_INT(2LL), v_a_2458, v_b_2459));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2460})});
}
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args) {
  V v_a_2462 = args[0];
  V v_b_2463 = args[1];
  if (heff_intLt_c(heff_dup(v_b_2463), MK_INT(0LL))) {
    V v_k_2465 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2463)));
    V v_t_2466 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2462, v_k_2465)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2466});
  } else {
    V v_k_2467 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2463));
    V v_t_2468 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2462, v_k_2467)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2468});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args) {
  V v_a_2470 = args[0];
  V v_b_2471 = args[1];
  if (heff_intLt_c(heff_dup(v_b_2471), MK_INT(0LL))) {
    V v_k_2473 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2471)));
    V v_t_2474 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2470, v_k_2473)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2474});
  } else {
    V v_k_2475 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2471));
    V v_t_2476 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2470, v_k_2475)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2476});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args) {
  V v_box_24a_2482 = args[0];
  V v_box_24b_2483 = args[1];
  double v_a_2482 = heff_unbox_f64(v_box_24a_2482);
  double v_b_2483 = heff_unbox_f64(v_box_24b_2483);
  V v_t_2485;
  if ((v_a_2482 == v_b_2483)) {
    v_t_2485 = ((V)&g_heff_2ecompile_2einterp_2eprim_str25);
  } else {
    v_t_2485 = ((V)&g_heff_2ecompile_2einterp_2eprim_str26);
  }
  V v_t_2486 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2485, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2486});
}
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args) {
  V v_box_24a_2488 = args[0];
  V v_box_24b_2489 = args[1];
  double v_a_2488 = heff_unbox_f64(v_box_24a_2488);
  double v_b_2489 = heff_unbox_f64(v_box_24b_2489);
  V v_t_2491;
  if ((v_a_2488 < v_b_2489)) {
    v_t_2491 = ((V)&g_heff_2ecompile_2einterp_2eprim_str28);
  } else {
    v_t_2491 = ((V)&g_heff_2ecompile_2einterp_2eprim_str29);
  }
  V v_t_2492 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2491, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2492});
}
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args) {
  V v_box_24a_2494 = args[0];
  V v_box_24b_2495 = args[1];
  double v_a_2494 = heff_unbox_f64(v_box_24a_2494);
  double v_b_2495 = heff_unbox_f64(v_box_24b_2495);
  V v_t_2497;
  if ((v_a_2494 <= v_b_2495)) {
    v_t_2497 = ((V)&g_heff_2ecompile_2einterp_2eprim_str31);
  } else {
    v_t_2497 = ((V)&g_heff_2ecompile_2einterp_2eprim_str32);
  }
  V v_t_2498 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2497, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2498});
}
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args) {
  V v_d_24100 = args[0];
  V v_a_24101 = args[1];
  V v_x1_24102 = heff_tr(heff_call(v_a_24101, 1, (V[]){v_d_24100}));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_Ok: {
    V v_v_24103 = heff_field(v_x1_24102, 0);
    V v_ru_24x1_24102_24Ok = heff_take_reuse_n(v_x1_24102, 1ULL, 1);
    switch (heff_tag_of(v_v_24103)) {
    case TAG_VFun: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24103, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      V v_a_24109 = heff_tget_v(v_v_24103, 0);
      V v_ru_24v_24103_24VFloat = heff_take_reuse_na(v_v_24103, 0ULL, 1);
      V v_t_24110 = heff_tag_at_n(v_ru_24v_24103_24VFloat, TAG_VStr, 1, (V[]){heff_floatShow(v_a_24109)});
      return heff_tag_at_n(v_ru_24x1_24102_24Ok, TAG_Ok, 1, (V[]){v_t_24110});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24103, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24103);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24118 = heff_field(v_x1_24102, 0);
    V v_ru_24x1_24102_24Bug = heff_take_reuse_n(v_x1_24102, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24102_24Bug, TAG_Bug, 1, (V[]){v_what_24118});
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args) {
  V v_d_24120 = args[0];
  V v_a_24121 = args[1];
  V v_x1_24122 = heff_tr(heff_call(v_a_24121, 1, (V[]){v_d_24120}));
  switch (heff_tag_of(v_x1_24122)) {
  case TAG_Ok: {
    V v_v_24123 = heff_field(v_x1_24122, 0);
    V v_ru_24x1_24122_24Ok = heff_take_reuse_n(v_x1_24122, 1ULL, 1);
    switch (heff_tag_of(v_v_24123)) {
    case TAG_VFun: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24123, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24128 = heff_field(v_v_24123, 0);
      V v_ru_24v_24123_24VInt = heff_take_reuse_n(v_v_24123, 1ULL, 1);
      V v_t_24129 = heff_tag_at_nf(v_ru_24v_24123_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(heff_from_int_f64(v_a_24128))});
      return heff_tag_at_n(v_ru_24x1_24122_24Ok, TAG_Ok, 1, (V[]){v_t_24129});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24123, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24123);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24138 = heff_field(v_x1_24122, 0);
    V v_ru_24x1_24122_24Bug = heff_take_reuse_n(v_x1_24122, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24122_24Bug, TAG_Bug, 1, (V[]){v_what_24138});
  }
  default: return heff_nomatch(v_x1_24122);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args) {
  V v_d_24140 = args[0];
  V v_a_24141 = args[1];
  V v_x1_24142 = heff_tr(heff_call(v_a_24141, 1, (V[]){v_d_24140}));
  switch (heff_tag_of(v_x1_24142)) {
  case TAG_Ok: {
    V v_v_24143 = heff_field(v_x1_24142, 0);
    V v_ru_24x1_24142_24Ok = heff_take_reuse_n(v_x1_24142, 1ULL, 1);
    switch (heff_tag_of(v_v_24143)) {
    case TAG_VFun: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24143, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24149 = heff_tflat_f64(v_v_24143, 0);
      V v_ru_24v_24143_24VFloat = heff_take_reuse_na(v_v_24143, 0ULL, 1);
      V v_t_24150 = heff_tag_at_nf(v_ru_24v_24143_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(sqrt(v_a_24149))});
      return heff_tag_at_n(v_ru_24x1_24142_24Ok, TAG_Ok, 1, (V[]){v_t_24150});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24143, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24143);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24158 = heff_field(v_x1_24142, 0);
    V v_ru_24x1_24142_24Bug = heff_take_reuse_n(v_x1_24142, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24142_24Bug, TAG_Bug, 1, (V[]){v_what_24158});
  }
  default: return heff_nomatch(v_x1_24142);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args) {
  V v_d_24160 = args[0];
  V v_a_24161 = args[1];
  V v_x1_24162 = heff_tr(heff_call(v_a_24161, 1, (V[]){v_d_24160}));
  switch (heff_tag_of(v_x1_24162)) {
  case TAG_Ok: {
    V v_v_24163 = heff_field(v_x1_24162, 0);
    V v_ru_24x1_24162_24Ok = heff_take_reuse_n(v_x1_24162, 1ULL, 1);
    switch (heff_tag_of(v_v_24163)) {
    case TAG_VFun: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24163, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24169 = heff_tflat_f64(v_v_24163, 0);
      V v_ru_24v_24163_24VFloat = heff_take_reuse_na(v_v_24163, 0ULL, 1);
      if (((v_a_24169 - v_a_24169) == (0.0))) {
        V v_t_24171 = heff_tag_at_n(v_ru_24v_24163_24VFloat, TAG_VInt, 1, (V[]){heff_floor_f64(v_a_24169)});
        return heff_tag_at_n(v_ru_24x1_24162_24Ok, TAG_Ok, 1, (V[]){v_t_24171});
      } else {
        heff_drop_cell(v_ru_24v_24163_24VFloat, 1);
        return heff_tag_at_n(v_ru_24x1_24162_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){MK_INT(0LL)})});
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24163, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24163);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24179 = heff_field(v_x1_24162, 0);
    V v_ru_24x1_24162_24Bug = heff_take_reuse_n(v_x1_24162, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24162_24Bug, TAG_Bug, 1, (V[]){v_what_24179});
  }
  default: return heff_nomatch(v_x1_24162);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args) {
  V v_d_24181 = args[0];
  V v_a_24182 = args[1];
  V v_x1_24183 = heff_tr(heff_call(v_a_24182, 1, (V[]){v_d_24181}));
  switch (heff_tag_of(v_x1_24183)) {
  case TAG_Ok: {
    V v_v_24184 = heff_field(v_x1_24183, 0);
    V v_ru_24x1_24183_24Ok = heff_take_reuse_n(v_x1_24183, 1ULL, 1);
    switch (heff_tag_of(v_v_24184)) {
    case TAG_VFun: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24184, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24190 = heff_tflat_f64(v_v_24184, 0);
      V v_ru_24v_24184_24VFloat = heff_take_reuse_na(v_v_24184, 0ULL, 1);
      V v_t_24191 = heff_tag_at_nf(v_ru_24v_24184_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(sin(v_a_24190))});
      return heff_tag_at_n(v_ru_24x1_24183_24Ok, TAG_Ok, 1, (V[]){v_t_24191});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24184, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24184);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24199 = heff_field(v_x1_24183, 0);
    V v_ru_24x1_24183_24Bug = heff_take_reuse_n(v_x1_24183, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24183_24Bug, TAG_Bug, 1, (V[]){v_what_24199});
  }
  default: return heff_nomatch(v_x1_24183);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args) {
  V v_d_24201 = args[0];
  V v_a_24202 = args[1];
  V v_x1_24203 = heff_tr(heff_call(v_a_24202, 1, (V[]){v_d_24201}));
  switch (heff_tag_of(v_x1_24203)) {
  case TAG_Ok: {
    V v_v_24204 = heff_field(v_x1_24203, 0);
    V v_ru_24x1_24203_24Ok = heff_take_reuse_n(v_x1_24203, 1ULL, 1);
    switch (heff_tag_of(v_v_24204)) {
    case TAG_VFun: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24204, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24210 = heff_tflat_f64(v_v_24204, 0);
      V v_ru_24v_24204_24VFloat = heff_take_reuse_na(v_v_24204, 0ULL, 1);
      V v_t_24211 = heff_tag_at_nf(v_ru_24v_24204_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(cos(v_a_24210))});
      return heff_tag_at_n(v_ru_24x1_24203_24Ok, TAG_Ok, 1, (V[]){v_t_24211});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24204, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24204);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24219 = heff_field(v_x1_24203, 0);
    V v_ru_24x1_24203_24Bug = heff_take_reuse_n(v_x1_24203, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24203_24Bug, TAG_Bug, 1, (V[]){v_what_24219});
  }
  default: return heff_nomatch(v_x1_24203);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args) {
  V v_d_24221 = args[0];
  V v_a_24222 = args[1];
  V v_x1_24223 = heff_tr(heff_call(v_a_24222, 1, (V[]){v_d_24221}));
  switch (heff_tag_of(v_x1_24223)) {
  case TAG_Ok: {
    V v_v_24224 = heff_field(v_x1_24223, 0);
    V v_ru_24x1_24223_24Ok = heff_take_reuse_n(v_x1_24223, 1ULL, 1);
    switch (heff_tag_of(v_v_24224)) {
    case TAG_VFun: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24224, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24230 = heff_tflat_f64(v_v_24224, 0);
      V v_ru_24v_24224_24VFloat = heff_take_reuse_na(v_v_24224, 0ULL, 1);
      V v_t_24231 = heff_tag_at_nf(v_ru_24v_24224_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(tan(v_a_24230))});
      return heff_tag_at_n(v_ru_24x1_24223_24Ok, TAG_Ok, 1, (V[]){v_t_24231});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24224, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24224);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24239 = heff_field(v_x1_24223, 0);
    V v_ru_24x1_24223_24Bug = heff_take_reuse_n(v_x1_24223, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24223_24Bug, TAG_Bug, 1, (V[]){v_what_24239});
  }
  default: return heff_nomatch(v_x1_24223);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args) {
  V v_d_24241 = args[0];
  V v_a_24242 = args[1];
  V v_x1_24243 = heff_tr(heff_call(v_a_24242, 1, (V[]){v_d_24241}));
  switch (heff_tag_of(v_x1_24243)) {
  case TAG_Ok: {
    V v_v_24244 = heff_field(v_x1_24243, 0);
    V v_ru_24x1_24243_24Ok = heff_take_reuse_n(v_x1_24243, 1ULL, 1);
    switch (heff_tag_of(v_v_24244)) {
    case TAG_VFun: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24244, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24250 = heff_tflat_f64(v_v_24244, 0);
      V v_ru_24v_24244_24VFloat = heff_take_reuse_na(v_v_24244, 0ULL, 1);
      V v_t_24251 = heff_tag_at_nf(v_ru_24v_24244_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(asin(v_a_24250))});
      return heff_tag_at_n(v_ru_24x1_24243_24Ok, TAG_Ok, 1, (V[]){v_t_24251});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24244, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24244);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24259 = heff_field(v_x1_24243, 0);
    V v_ru_24x1_24243_24Bug = heff_take_reuse_n(v_x1_24243, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24243_24Bug, TAG_Bug, 1, (V[]){v_what_24259});
  }
  default: return heff_nomatch(v_x1_24243);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args) {
  V v_d_24261 = args[0];
  V v_a_24262 = args[1];
  V v_x1_24263 = heff_tr(heff_call(v_a_24262, 1, (V[]){v_d_24261}));
  switch (heff_tag_of(v_x1_24263)) {
  case TAG_Ok: {
    V v_v_24264 = heff_field(v_x1_24263, 0);
    V v_ru_24x1_24263_24Ok = heff_take_reuse_n(v_x1_24263, 1ULL, 1);
    switch (heff_tag_of(v_v_24264)) {
    case TAG_VFun: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24264, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24270 = heff_tflat_f64(v_v_24264, 0);
      V v_ru_24v_24264_24VFloat = heff_take_reuse_na(v_v_24264, 0ULL, 1);
      V v_t_24271 = heff_tag_at_nf(v_ru_24v_24264_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(acos(v_a_24270))});
      return heff_tag_at_n(v_ru_24x1_24263_24Ok, TAG_Ok, 1, (V[]){v_t_24271});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24264, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24264);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24279 = heff_field(v_x1_24263, 0);
    V v_ru_24x1_24263_24Bug = heff_take_reuse_n(v_x1_24263, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24263_24Bug, TAG_Bug, 1, (V[]){v_what_24279});
  }
  default: return heff_nomatch(v_x1_24263);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args) {
  V v_d_24281 = args[0];
  V v_a_24282 = args[1];
  V v_x1_24283 = heff_tr(heff_call(v_a_24282, 1, (V[]){v_d_24281}));
  switch (heff_tag_of(v_x1_24283)) {
  case TAG_Ok: {
    V v_v_24284 = heff_field(v_x1_24283, 0);
    V v_ru_24x1_24283_24Ok = heff_take_reuse_n(v_x1_24283, 1ULL, 1);
    switch (heff_tag_of(v_v_24284)) {
    case TAG_VFun: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24284, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24290 = heff_tflat_f64(v_v_24284, 0);
      V v_ru_24v_24284_24VFloat = heff_take_reuse_na(v_v_24284, 0ULL, 1);
      V v_t_24291 = heff_tag_at_nf(v_ru_24v_24284_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(atan(v_a_24290))});
      return heff_tag_at_n(v_ru_24x1_24283_24Ok, TAG_Ok, 1, (V[]){v_t_24291});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24284, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24284);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24299 = heff_field(v_x1_24283, 0);
    V v_ru_24x1_24283_24Bug = heff_take_reuse_n(v_x1_24283, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24283_24Bug, TAG_Bug, 1, (V[]){v_what_24299});
  }
  default: return heff_nomatch(v_x1_24283);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args) {
  V v_d_24302 = args[0];
  V v_a_24303 = args[1];
  V v_x1_24304 = heff_tr(heff_call(v_a_24303, 1, (V[]){v_d_24302}));
  switch (heff_tag_of(v_x1_24304)) {
  case TAG_Ok: {
    V v_v_24305 = heff_field(v_x1_24304, 0);
    V v_ru_24x1_24304_24Ok = heff_take_reuse_n(v_x1_24304, 1ULL, 1);
    switch (heff_tag_of(v_v_24305)) {
    case TAG_VFun: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24305, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24311 = heff_tflat_f64(v_v_24305, 0);
      V v_ru_24v_24305_24VFloat = heff_take_reuse_na(v_v_24305, 0ULL, 1);
      V v_t_24312 = heff_tag_at_nf(v_ru_24v_24305_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(exp(v_a_24311))});
      return heff_tag_at_n(v_ru_24x1_24304_24Ok, TAG_Ok, 1, (V[]){v_t_24312});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24305, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24305);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24320 = heff_field(v_x1_24304, 0);
    V v_ru_24x1_24304_24Bug = heff_take_reuse_n(v_x1_24304, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24304_24Bug, TAG_Bug, 1, (V[]){v_what_24320});
  }
  default: return heff_nomatch(v_x1_24304);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args) {
  V v_d_24322 = args[0];
  V v_a_24323 = args[1];
  V v_x1_24324 = heff_tr(heff_call(v_a_24323, 1, (V[]){v_d_24322}));
  switch (heff_tag_of(v_x1_24324)) {
  case TAG_Ok: {
    V v_v_24325 = heff_field(v_x1_24324, 0);
    V v_ru_24x1_24324_24Ok = heff_take_reuse_n(v_x1_24324, 1ULL, 1);
    switch (heff_tag_of(v_v_24325)) {
    case TAG_VFun: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24325, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24331 = heff_tflat_f64(v_v_24325, 0);
      V v_ru_24v_24325_24VFloat = heff_take_reuse_na(v_v_24325, 0ULL, 1);
      V v_t_24332 = heff_tag_at_nf(v_ru_24v_24325_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(log(v_a_24331))});
      return heff_tag_at_n(v_ru_24x1_24324_24Ok, TAG_Ok, 1, (V[]){v_t_24332});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24325, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24325);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24340 = heff_field(v_x1_24324, 0);
    V v_ru_24x1_24324_24Bug = heff_take_reuse_n(v_x1_24324, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24324_24Bug, TAG_Bug, 1, (V[]){v_what_24340});
  }
  default: return heff_nomatch(v_x1_24324);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args) {
  V v_d_24345 = args[0];
  V v_a_24346 = args[1];
  V v_x1_24347 = heff_tr(heff_call(v_a_24346, 1, (V[]){v_d_24345}));
  switch (heff_tag_of(v_x1_24347)) {
  case TAG_Ok: {
    V v_v_24348 = heff_field(v_x1_24347, 0);
    V v_ru_24x1_24347_24Ok = heff_take_reuse_n(v_x1_24347, 1ULL, 1);
    switch (heff_tag_of(v_v_24348)) {
    case TAG_VFun: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24348, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24358 = heff_field(v_v_24348, 0);
      heff_take_n(v_v_24348, 1ULL, 1);
      V v_t_24359 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_xs_24358); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      return heff_tag_at_n(v_ru_24x1_24347_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24359})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24348, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24348);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24363 = heff_field(v_x1_24347, 0);
    V v_ru_24x1_24347_24Bug = heff_take_reuse_n(v_x1_24347, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24347_24Bug, TAG_Bug, 1, (V[]){v_what_24363});
  }
  default: return heff_nomatch(v_x1_24347);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args) {
  V v_d_24343 = args[0];
  V v_u_24344 = args[1];
  heff_drop(v_d_24343);
  heff_drop(v_u_24344);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam26_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args) {
  V v_d_24381 = args[0];
  V v_a_24382 = args[1];
  V v_xs_24380 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24383 = heff_tr(heff_call(v_a_24382, 1, (V[]){v_d_24381}));
  switch (heff_tag_of(v_x1_24383)) {
  case TAG_Ok: {
    V v_v_24384 = heff_field(v_x1_24383, 0);
    V v_ru_24x1_24383_24Ok = heff_take_reuse_n(v_x1_24383, 1ULL, 1);
    switch (heff_tag_of(v_v_24384)) {
    case TAG_VFun: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24384, 0ULL, 2);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24389 = heff_field(v_v_24384, 0);
      V v_ru_24v_24384_24VInt = heff_take_reuse_n(v_v_24384, 1ULL, 1);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_a_24389))) {
        V v_t_24391 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24380)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        if (heff_intLt_c(heff_dup(v_a_24389), v_t_24391)) {
          V v_t_24393 = ({ V b_0 = heff_arrayToList(v_xs_24380); V a_1 = v_a_24389; V r_ = (g_heff_2ecompile_2einterp_2enthV(b_0, a_1)); heff_drop(b_0); r_; });
          switch (heff_tag_of(v_t_24393)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
            return heff_tag_at_n(v_ru_24v_24384_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str49)});
          }
          case TAG_Just: {
            V v_v_24394 = heff_field(v_t_24393, 0);
            heff_take_n(v_t_24393, 1ULL, 1);
            heff_drop_cell(v_ru_24v_24384_24VInt, 1);
            return heff_tag_at_n(v_ru_24x1_24383_24Ok, TAG_Ok, 1, (V[]){v_v_24394});
          }
          default: return heff_nomatch(v_t_24393);
          }
        } else {
          heff_drop(v_xs_24380);
          heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
          heff_drop(v_a_24389);
          heff_drop_cell(v_ru_24v_24384_24VInt, 1);
          return NTAG(TAG_Abn);
        }
      } else {
        heff_drop(v_xs_24380);
        heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
        heff_drop(v_a_24389);
        heff_drop_cell(v_ru_24v_24384_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24384, 0ULL, 2);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24384);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24380);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24380);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24403 = heff_field(v_x1_24383, 0);
    V v_ru_24x1_24383_24Bug = heff_take_reuse_n(v_x1_24383, 1ULL, 1);
    heff_drop(v_xs_24380);
    return heff_tag_at_n(v_ru_24x1_24383_24Bug, TAG_Bug, 1, (V[]){v_what_24403});
  }
  default: return heff_nomatch(v_x1_24383);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args) {
  V v_d_24367 = args[0];
  V v_a_24368 = args[1];
  V v_x1_24369 = heff_tr(heff_call(v_a_24368, 1, (V[]){v_d_24367}));
  switch (heff_tag_of(v_x1_24369)) {
  case TAG_Ok: {
    V v_v_24370 = heff_field(v_x1_24369, 0);
    V v_ru_24x1_24369_24Ok = heff_take_reuse_n(v_x1_24369, 1ULL, 1);
    switch (heff_tag_of(v_v_24370)) {
    case TAG_VFun: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24370, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24380 = heff_field(v_v_24370, 0);
      heff_take_n(v_v_24370, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24369_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam29, 2, 1, (V[]){v_xs_24380})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24370, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24370);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24407 = heff_field(v_x1_24369, 0);
    V v_ru_24x1_24369_24Bug = heff_take_reuse_n(v_x1_24369, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24369_24Bug, TAG_Bug, 1, (V[]){v_what_24407});
  }
  default: return heff_nomatch(v_x1_24369);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args) {
  V v_d_24365 = args[0];
  V v_u_24366 = args[1];
  heff_drop(v_d_24365);
  heff_drop(v_u_24366);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam28_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args) {
  V v_d_24434 = args[0];
  V v_x_24435 = args[1];
  V v_a_24433 = heff_env(self)[0];
  V v_xs_24424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24436 = heff_tr(heff_call(v_x_24435, 1, (V[]){v_d_24434}));
  switch (heff_tag_of(v_x1_24436)) {
  case TAG_Ok: {
    V v_v_24437 = heff_field(v_x1_24436, 0);
    V v_ru_24x1_24436_24Ok = heff_take_reuse_n(v_x1_24436, 1ULL, 1);
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_a_24433))) {
      V v_t_24439 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24424)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (heff_intLt_c(heff_dup(v_a_24433), v_t_24439)) {
        V v_t_24441 = (g_heff_2ecompile_2einterp_2esetAt(heff_arrayToList(v_xs_24424), v_a_24433, v_v_24437));
        V v_t_24442 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24441)});
        return heff_tag_at_n(v_ru_24x1_24436_24Ok, TAG_Ok, 1, (V[]){v_t_24442});
      } else {
        heff_drop(v_a_24433);
        heff_drop(v_v_24437);
        return heff_tag_at_n(v_ru_24x1_24436_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VArr, 1, (V[]){v_xs_24424})});
      }
    } else {
      heff_drop(v_a_24433);
      heff_drop(v_v_24437);
      return heff_tag_at_n(v_ru_24x1_24436_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VArr, 1, (V[]){v_xs_24424})});
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24433);
    heff_drop(v_xs_24424);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24433);
    heff_drop(v_xs_24424);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24443 = heff_field(v_x1_24436, 0);
    V v_ru_24x1_24436_24Bug = heff_take_reuse_n(v_x1_24436, 1ULL, 1);
    heff_drop(v_a_24433);
    heff_drop(v_xs_24424);
    return heff_tag_at_n(v_ru_24x1_24436_24Bug, TAG_Bug, 1, (V[]){v_what_24443});
  }
  default: return heff_nomatch(v_x1_24436);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args) {
  V v_d_24425 = args[0];
  V v_a_24426 = args[1];
  V v_xs_24424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24427 = heff_tr(heff_call(v_a_24426, 1, (V[]){v_d_24425}));
  switch (heff_tag_of(v_x1_24427)) {
  case TAG_Ok: {
    V v_v_24428 = heff_field(v_x1_24427, 0);
    V v_ru_24x1_24427_24Ok = heff_take_reuse_n(v_x1_24427, 1ULL, 1);
    switch (heff_tag_of(v_v_24428)) {
    case TAG_VFun: {
      heff_take_n(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24428, 0ULL, 2);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24433 = heff_field(v_v_24428, 0);
      heff_take_n(v_v_24428, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24427_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam33, 2, 2, (V[]){v_a_24433, v_xs_24424})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24428, 0ULL, 2);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24428);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24424);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24424);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24452 = heff_field(v_x1_24427, 0);
    V v_ru_24x1_24427_24Bug = heff_take_reuse_n(v_x1_24427, 1ULL, 1);
    heff_drop(v_xs_24424);
    return heff_tag_at_n(v_ru_24x1_24427_24Bug, TAG_Bug, 1, (V[]){v_what_24452});
  }
  default: return heff_nomatch(v_x1_24427);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args) {
  V v_d_24411 = args[0];
  V v_a_24412 = args[1];
  V v_x1_24413 = heff_tr(heff_call(v_a_24412, 1, (V[]){v_d_24411}));
  switch (heff_tag_of(v_x1_24413)) {
  case TAG_Ok: {
    V v_v_24414 = heff_field(v_x1_24413, 0);
    V v_ru_24x1_24413_24Ok = heff_take_reuse_n(v_x1_24413, 1ULL, 1);
    switch (heff_tag_of(v_v_24414)) {
    case TAG_VFun: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24414, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24424 = heff_field(v_v_24414, 0);
      heff_take_n(v_v_24414, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24413_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam32, 2, 1, (V[]){v_xs_24424})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24414, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24414);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24456 = heff_field(v_x1_24413, 0);
    V v_ru_24x1_24413_24Bug = heff_take_reuse_n(v_x1_24413, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24413_24Bug, TAG_Bug, 1, (V[]){v_what_24456});
  }
  default: return heff_nomatch(v_x1_24413);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args) {
  V v_d_24409 = args[0];
  V v_u_24410 = args[1];
  heff_drop(v_d_24409);
  heff_drop(v_u_24410);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam31_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args) {
  V v_vs_24473 = args[0];
  V v_t_24474 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_vs_24473)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24474});
}
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args) {
  V v_d_24469 = args[0];
  V v_f_24470 = args[1];
  V v_a_24468 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24471 = heff_tr(heff_call(v_f_24470, 1, (V[]){heff_dup(v_d_24469)}));
  switch (heff_tag_of(v_x1_24471)) {
  case TAG_Ok: {
    V v_v_24472 = heff_field(v_x1_24471, 0);
    heff_take_n(v_x1_24471, 1ULL, 1);
    return (g_heff_2ecompile_2einterp_2egenGo(v_d_24469, MK_INT(0LL), v_a_24468, v_v_24472, ((V)&g_heff_2ecompile_2einterp_2eprim_lam37_clo)));
  }
  case TAG_Abn: {
    heff_drop(v_d_24469);
    heff_drop(v_a_24468);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_24469);
    heff_drop(v_a_24468);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24475 = heff_field(v_x1_24471, 0);
    V v_ru_24x1_24471_24Bug = heff_take_reuse_n(v_x1_24471, 1ULL, 1);
    heff_drop(v_d_24469);
    heff_drop(v_a_24468);
    return heff_tag_at_n(v_ru_24x1_24471_24Bug, TAG_Bug, 1, (V[]){v_what_24475});
  }
  default: return heff_nomatch(v_x1_24471);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args) {
  V v_d_24460 = args[0];
  V v_a_24461 = args[1];
  V v_x1_24462 = heff_tr(heff_call(v_a_24461, 1, (V[]){v_d_24460}));
  switch (heff_tag_of(v_x1_24462)) {
  case TAG_Ok: {
    V v_v_24463 = heff_field(v_x1_24462, 0);
    V v_ru_24x1_24462_24Ok = heff_take_reuse_n(v_x1_24462, 1ULL, 1);
    switch (heff_tag_of(v_v_24463)) {
    case TAG_VFun: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24463, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24468 = heff_field(v_v_24463, 0);
      heff_take_n(v_v_24463, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24462_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam36, 2, 1, (V[]){v_a_24468})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24463, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24463);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24484 = heff_field(v_x1_24462, 0);
    V v_ru_24x1_24462_24Bug = heff_take_reuse_n(v_x1_24462, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24462_24Bug, TAG_Bug, 1, (V[]){v_what_24484});
  }
  default: return heff_nomatch(v_x1_24462);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args) {
  V v_d_24458 = args[0];
  V v_u_24459 = args[1];
  heff_drop(v_d_24458);
  heff_drop(v_u_24459);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam35_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args) {
  V v_d_24488 = args[0];
  V v_l_24489 = args[1];
  V v_x1_24490 = heff_tr(heff_call(v_l_24489, 1, (V[]){v_d_24488}));
  switch (heff_tag_of(v_x1_24490)) {
  case TAG_Ok: {
    V v_v_24491 = heff_field(v_x1_24490, 0);
    V v_ru_24x1_24490_24Ok = heff_take_reuse_n(v_x1_24490, 1ULL, 1);
    V v_t_24492 = (g_heff_2ecompile_2einterp_2efromListV(v_v_24491, NTAG(TAG_Nil)));
    V v_t_24493 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24492)});
    return heff_tag_at_n(v_ru_24x1_24490_24Ok, TAG_Ok, 1, (V[]){v_t_24493});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24494 = heff_field(v_x1_24490, 0);
    V v_ru_24x1_24490_24Bug = heff_take_reuse_n(v_x1_24490, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24490_24Bug, TAG_Bug, 1, (V[]){v_what_24494});
  }
  default: return heff_nomatch(v_x1_24490);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args) {
  V v_d_24486 = args[0];
  V v_u_24487 = args[1];
  heff_drop(v_d_24486);
  heff_drop(v_u_24487);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam39_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args) {
  V v_d_24498 = args[0];
  V v_a_24499 = args[1];
  V v_x1_24500 = heff_tr(heff_call(v_a_24499, 1, (V[]){v_d_24498}));
  switch (heff_tag_of(v_x1_24500)) {
  case TAG_Ok: {
    V v_v_24501 = heff_field(v_x1_24500, 0);
    V v_ru_24x1_24500_24Ok = heff_take_reuse_n(v_x1_24500, 1ULL, 1);
    switch (heff_tag_of(v_v_24501)) {
    case TAG_VFun: {
      heff_take_n(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24501, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24511 = heff_field(v_v_24501, 0);
      heff_take_n(v_v_24501, 1ULL, 1);
      V v_t_24512 = (g_heff_2ecompile_2einterp_2etoListV(heff_arrayToList(v_xs_24511)));
      return heff_tag_at_n(v_ru_24x1_24500_24Ok, TAG_Ok, 1, (V[]){v_t_24512});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24501, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24501);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24516 = heff_field(v_x1_24500, 0);
    V v_ru_24x1_24500_24Bug = heff_take_reuse_n(v_x1_24500, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24500_24Bug, TAG_Bug, 1, (V[]){v_what_24516});
  }
  default: return heff_nomatch(v_x1_24500);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args) {
  V v_d_24496 = args[0];
  V v_u_24497 = args[1];
  heff_drop(v_d_24496);
  heff_drop(v_u_24497);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam41_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args) {
  V v_d_24519 = args[0];
  V v_a_24520 = args[1];
  V v_x1_24521 = heff_tr(heff_call(v_a_24520, 1, (V[]){v_d_24519}));
  switch (heff_tag_of(v_x1_24521)) {
  case TAG_Ok: {
    V v_v_24522 = heff_field(v_x1_24521, 0);
    V v_ru_24x1_24521_24Ok = heff_take_reuse_n(v_x1_24521, 1ULL, 1);
    switch (heff_tag_of(v_v_24522)) {
    case TAG_VFun: {
      heff_take_n(v_v_24522, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24521_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24522, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24521_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24522, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24521_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24522, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24521_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24522, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24521_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24522, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24521_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24530 = heff_field(v_v_24522, 0);
      V v_ru_24v_24522_24VStr = heff_take_reuse_n(v_v_24522, 1ULL, 1);
      V v_t_24531 = heff_tag_at_n(v_ru_24v_24522_24VStr, TAG_VInt, 1, (V[]){heff_strLength(v_a_24530)});
      return heff_tag_at_n(v_ru_24x1_24521_24Ok, TAG_Ok, 1, (V[]){v_t_24531});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24522, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24521_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24522, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24521_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24522, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24521_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24522, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24521_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24521_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24522);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24537 = heff_field(v_x1_24521, 0);
    V v_ru_24x1_24521_24Bug = heff_take_reuse_n(v_x1_24521, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24521_24Bug, TAG_Bug, 1, (V[]){v_what_24537});
  }
  default: return heff_nomatch(v_x1_24521);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args) {
  V v_d_24560 = args[0];
  V v_a_24561 = args[1];
  V v_a_24550 = heff_env(self)[0];
  V v_a_24559 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24562 = heff_tr(heff_call(v_a_24561, 1, (V[]){v_d_24560}));
  switch (heff_tag_of(v_x1_24562)) {
  case TAG_Ok: {
    V v_v_24563 = heff_field(v_x1_24562, 0);
    V v_ru_24x1_24562_24Ok = heff_take_reuse_n(v_x1_24562, 1ULL, 1);
    switch (heff_tag_of(v_v_24563)) {
    case TAG_VFun: {
      heff_take_n(v_v_24563, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop(v_a_24559);
      heff_drop_cell(v_ru_24x1_24562_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24563, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop(v_a_24559);
      heff_drop_cell(v_ru_24x1_24562_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24563, 0ULL, 2);
      heff_drop(v_a_24550);
      heff_drop(v_a_24559);
      heff_drop_cell(v_ru_24x1_24562_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24568 = heff_field(v_v_24563, 0);
      V v_ru_24v_24563_24VInt = heff_take_reuse_n(v_v_24563, 1ULL, 1);
      V v_t_24569 = heff_tag_at_n(v_ru_24v_24563_24VInt, TAG_VStr, 1, (V[]){heff_strSlice(v_a_24550, v_a_24559, v_a_24568)});
      return heff_tag_at_n(v_ru_24x1_24562_24Ok, TAG_Ok, 1, (V[]){v_t_24569});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24563, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop(v_a_24559);
      heff_drop_cell(v_ru_24x1_24562_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24563, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop(v_a_24559);
      heff_drop_cell(v_ru_24x1_24562_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24563, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop(v_a_24559);
      heff_drop_cell(v_ru_24x1_24562_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24563, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop(v_a_24559);
      heff_drop_cell(v_ru_24x1_24562_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24563, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop(v_a_24559);
      heff_drop_cell(v_ru_24x1_24562_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24563, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop(v_a_24559);
      heff_drop_cell(v_ru_24x1_24562_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24563, 0ULL, 2);
      heff_drop(v_a_24550);
      heff_drop(v_a_24559);
      heff_drop_cell(v_ru_24x1_24562_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24550);
      heff_drop(v_a_24559);
      heff_drop_cell(v_ru_24x1_24562_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24563);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24550);
    heff_drop(v_a_24559);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24550);
    heff_drop(v_a_24559);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24578 = heff_field(v_x1_24562, 0);
    V v_ru_24x1_24562_24Bug = heff_take_reuse_n(v_x1_24562, 1ULL, 1);
    heff_drop(v_a_24550);
    heff_drop(v_a_24559);
    return heff_tag_at_n(v_ru_24x1_24562_24Bug, TAG_Bug, 1, (V[]){v_what_24578});
  }
  default: return heff_nomatch(v_x1_24562);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args) {
  V v_d_24551 = args[0];
  V v_a_24552 = args[1];
  V v_a_24550 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24553 = heff_tr(heff_call(v_a_24552, 1, (V[]){v_d_24551}));
  switch (heff_tag_of(v_x1_24553)) {
  case TAG_Ok: {
    V v_v_24554 = heff_field(v_x1_24553, 0);
    V v_ru_24x1_24553_24Ok = heff_take_reuse_n(v_x1_24553, 1ULL, 1);
    switch (heff_tag_of(v_v_24554)) {
    case TAG_VFun: {
      heff_take_n(v_v_24554, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24554, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24554, 0ULL, 2);
      heff_drop(v_a_24550);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24559 = heff_field(v_v_24554, 0);
      heff_take_n(v_v_24554, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24553_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam45, 2, 2, (V[]){v_a_24550, v_a_24559})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24554, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24554, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24554, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24554, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24554, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24554, 0ULL, 1);
      heff_drop(v_a_24550);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24554, 0ULL, 2);
      heff_drop(v_a_24550);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24550);
      heff_drop_cell(v_ru_24x1_24553_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24554);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24550);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24550);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24587 = heff_field(v_x1_24553, 0);
    V v_ru_24x1_24553_24Bug = heff_take_reuse_n(v_x1_24553, 1ULL, 1);
    heff_drop(v_a_24550);
    return heff_tag_at_n(v_ru_24x1_24553_24Bug, TAG_Bug, 1, (V[]){v_what_24587});
  }
  default: return heff_nomatch(v_x1_24553);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args) {
  V v_d_24539 = args[0];
  V v_a_24540 = args[1];
  V v_x1_24541 = heff_tr(heff_call(v_a_24540, 1, (V[]){v_d_24539}));
  switch (heff_tag_of(v_x1_24541)) {
  case TAG_Ok: {
    V v_v_24542 = heff_field(v_x1_24541, 0);
    V v_ru_24x1_24541_24Ok = heff_take_reuse_n(v_x1_24541, 1ULL, 1);
    switch (heff_tag_of(v_v_24542)) {
    case TAG_VFun: {
      heff_take_n(v_v_24542, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24542, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24542, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24542, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24542, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24542, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24550 = heff_field(v_v_24542, 0);
      heff_take_n(v_v_24542, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24541_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam44, 2, 1, (V[]){v_a_24550})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24542, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24542, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24542, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24542, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24541_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24542);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24593 = heff_field(v_x1_24541, 0);
    V v_ru_24x1_24541_24Bug = heff_take_reuse_n(v_x1_24541, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24541_24Bug, TAG_Bug, 1, (V[]){v_what_24593});
  }
  default: return heff_nomatch(v_x1_24541);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args) {
  V v_a_24595 = args[0];
  V v_b_24596 = args[1];
  V v_t_24598;
  if (heff_strEq_c(v_a_24595, v_b_24596)) {
    v_t_24598 = ((V)&g_heff_2ecompile_2einterp_2eprim_str58);
  } else {
    v_t_24598 = ((V)&g_heff_2ecompile_2einterp_2eprim_str59);
  }
  V v_t_24599 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24598, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24599});
}
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args) {
  V v_a_24601 = args[0];
  V v_b_24602 = args[1];
  V v_t_24604;
  if (heff_strLt_c(v_a_24601, v_b_24602)) {
    v_t_24604 = ((V)&g_heff_2ecompile_2einterp_2eprim_str61);
  } else {
    v_t_24604 = ((V)&g_heff_2ecompile_2einterp_2eprim_str62);
  }
  V v_t_24605 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24604, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24605});
}
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args) {
  V v_a_24607 = args[0];
  V v_b_24608 = args[1];
  V v_t_24611;
  if (heff_strLt_c_lent(v_a_24607, v_b_24608, 0)) {
    heff_drop(v_a_24607);
    heff_drop(v_b_24608);
    v_t_24611 = MK_INT(-1LL);
  } else {
    if (heff_strEq_c(v_a_24607, v_b_24608)) {
      v_t_24611 = MK_INT(0LL);
    } else {
      v_t_24611 = MK_INT(1LL);
    }
  }
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24611})});
}
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args) {
  V v_d_24615 = args[0];
  V v_a_24616 = args[1];
  V v_n_24613 = heff_env(self)[0];
  V v_a_24614 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24617 = heff_tr(heff_call(v_a_24616, 1, (V[]){v_d_24615}));
  switch (heff_tag_of(v_x1_24617)) {
  case TAG_Ok: {
    V v_v_24618 = heff_field(v_x1_24617, 0);
    V v_ru_24x1_24617_24Ok = heff_take_reuse_n(v_x1_24617, 1ULL, 1);
    switch (heff_tag_of(v_v_24618)) {
    case TAG_VFun: {
      heff_take_n(v_v_24618, 0ULL, 1);
      heff_drop(v_n_24613);
      heff_drop(v_a_24614);
      heff_drop_cell(v_ru_24x1_24617_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24618, 0ULL, 1);
      heff_drop(v_n_24613);
      heff_drop(v_a_24614);
      heff_drop_cell(v_ru_24x1_24617_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24618, 0ULL, 2);
      heff_drop(v_n_24613);
      heff_drop(v_a_24614);
      heff_drop_cell(v_ru_24x1_24617_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24623 = heff_field(v_v_24618, 0);
      heff_take_n(v_v_24618, 1ULL, 1);
      V v_t_24625;
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_a_24623))) {
        v_t_24625 = v_a_24623;
      } else {
        heff_drop(v_a_24623);
        v_t_24625 = MK_INT(0LL);
      }
      V v_j_24626 = heff_strFind(v_n_24613, v_a_24614, v_t_24625);
      V v_t_24628;
      if (heff_intLt_c(heff_dup(v_j_24626), MK_INT(0LL))) {
        heff_drop(v_j_24626);
        v_t_24628 = MK_INT(-1LL);
      } else {
        v_t_24628 = v_j_24626;
      }
      return heff_tag_at_n(v_ru_24x1_24617_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24628})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24618, 0ULL, 1);
      heff_drop(v_n_24613);
      heff_drop(v_a_24614);
      heff_drop_cell(v_ru_24x1_24617_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24618, 0ULL, 1);
      heff_drop(v_n_24613);
      heff_drop(v_a_24614);
      heff_drop_cell(v_ru_24x1_24617_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24618, 0ULL, 1);
      heff_drop(v_n_24613);
      heff_drop(v_a_24614);
      heff_drop_cell(v_ru_24x1_24617_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24618, 0ULL, 1);
      heff_drop(v_n_24613);
      heff_drop(v_a_24614);
      heff_drop_cell(v_ru_24x1_24617_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24618, 0ULL, 1);
      heff_drop(v_n_24613);
      heff_drop(v_a_24614);
      heff_drop_cell(v_ru_24x1_24617_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24618, 0ULL, 1);
      heff_drop(v_n_24613);
      heff_drop(v_a_24614);
      heff_drop_cell(v_ru_24x1_24617_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24618, 0ULL, 2);
      heff_drop(v_n_24613);
      heff_drop(v_a_24614);
      heff_drop_cell(v_ru_24x1_24617_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_n_24613);
      heff_drop(v_a_24614);
      heff_drop_cell(v_ru_24x1_24617_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24618);
    }
  }
  case TAG_Abn: {
    heff_drop(v_n_24613);
    heff_drop(v_a_24614);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_n_24613);
    heff_drop(v_a_24614);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24637 = heff_field(v_x1_24617, 0);
    V v_ru_24x1_24617_24Bug = heff_take_reuse_n(v_x1_24617, 1ULL, 1);
    heff_drop(v_n_24613);
    heff_drop(v_a_24614);
    return heff_tag_at_n(v_ru_24x1_24617_24Bug, TAG_Bug, 1, (V[]){v_what_24637});
  }
  default: return heff_nomatch(v_x1_24617);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args) {
  V v_n_24613 = args[0];
  V v_a_24614 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam50, 2, 2, (V[]){v_n_24613, v_a_24614})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args) {
  V v_d_24651 = args[0];
  V v_a_24652 = args[1];
  V v_a_24650 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24653 = heff_tr(heff_call(v_a_24652, 1, (V[]){v_d_24651}));
  switch (heff_tag_of(v_x1_24653)) {
  case TAG_Ok: {
    V v_v_24654 = heff_field(v_x1_24653, 0);
    V v_ru_24x1_24653_24Ok = heff_take_reuse_n(v_x1_24653, 1ULL, 1);
    switch (heff_tag_of(v_v_24654)) {
    case TAG_VFun: {
      heff_take_n(v_v_24654, 0ULL, 1);
      heff_drop(v_a_24650);
      heff_drop_cell(v_ru_24x1_24653_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24654, 0ULL, 1);
      heff_drop(v_a_24650);
      heff_drop_cell(v_ru_24x1_24653_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24654, 0ULL, 2);
      heff_drop(v_a_24650);
      heff_drop_cell(v_ru_24x1_24653_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24659 = heff_field(v_v_24654, 0);
      V v_ru_24v_24654_24VInt = heff_take_reuse_n(v_v_24654, 1ULL, 1);
      V v_t_24660 = heff_tag_at_n(v_ru_24v_24654_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_24650, v_a_24659)});
      return heff_tag_at_n(v_ru_24x1_24653_24Ok, TAG_Ok, 1, (V[]){v_t_24660});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24654, 0ULL, 1);
      heff_drop(v_a_24650);
      heff_drop_cell(v_ru_24x1_24653_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24654, 0ULL, 1);
      heff_drop(v_a_24650);
      heff_drop_cell(v_ru_24x1_24653_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24654, 0ULL, 1);
      heff_drop(v_a_24650);
      heff_drop_cell(v_ru_24x1_24653_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24654, 0ULL, 1);
      heff_drop(v_a_24650);
      heff_drop_cell(v_ru_24x1_24653_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24654, 0ULL, 1);
      heff_drop(v_a_24650);
      heff_drop_cell(v_ru_24x1_24653_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24654, 0ULL, 1);
      heff_drop(v_a_24650);
      heff_drop_cell(v_ru_24x1_24653_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24654, 0ULL, 2);
      heff_drop(v_a_24650);
      heff_drop_cell(v_ru_24x1_24653_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24650);
      heff_drop_cell(v_ru_24x1_24653_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24654);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24650);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24650);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24669 = heff_field(v_x1_24653, 0);
    V v_ru_24x1_24653_24Bug = heff_take_reuse_n(v_x1_24653, 1ULL, 1);
    heff_drop(v_a_24650);
    return heff_tag_at_n(v_ru_24x1_24653_24Bug, TAG_Bug, 1, (V[]){v_what_24669});
  }
  default: return heff_nomatch(v_x1_24653);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args) {
  V v_d_24639 = args[0];
  V v_a_24640 = args[1];
  V v_x1_24641 = heff_tr(heff_call(v_a_24640, 1, (V[]){v_d_24639}));
  switch (heff_tag_of(v_x1_24641)) {
  case TAG_Ok: {
    V v_v_24642 = heff_field(v_x1_24641, 0);
    V v_ru_24x1_24641_24Ok = heff_take_reuse_n(v_x1_24641, 1ULL, 1);
    switch (heff_tag_of(v_v_24642)) {
    case TAG_VFun: {
      heff_take_n(v_v_24642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24642, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24650 = heff_field(v_v_24642, 0);
      heff_take_n(v_v_24642, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24641_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam52, 2, 1, (V[]){v_a_24650})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24642, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24642);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24675 = heff_field(v_x1_24641, 0);
    V v_ru_24x1_24641_24Bug = heff_take_reuse_n(v_x1_24641, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24641_24Bug, TAG_Bug, 1, (V[]){v_what_24675});
  }
  default: return heff_nomatch(v_x1_24641);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args) {
  V v_d_24677 = args[0];
  V v_a_24678 = args[1];
  V v_x1_24679 = heff_tr(heff_call(v_a_24678, 1, (V[]){v_d_24677}));
  switch (heff_tag_of(v_x1_24679)) {
  case TAG_Ok: {
    V v_v_24680 = heff_field(v_x1_24679, 0);
    V v_ru_24x1_24679_24Ok = heff_take_reuse_n(v_x1_24679, 1ULL, 1);
    switch (heff_tag_of(v_v_24680)) {
    case TAG_VFun: {
      heff_take_n(v_v_24680, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24679_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24680, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24679_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24680, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24679_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24685 = heff_field(v_v_24680, 0);
      heff_take_n(v_v_24680, 1ULL, 1);
      V v_t_24686 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_a_24685)));
      return heff_tag_at_n(v_ru_24x1_24679_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_24686})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24680, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24679_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24680, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24679_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24680, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24679_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24680, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24679_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24680, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24679_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24680, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24679_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24680, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24679_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24679_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24680);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24695 = heff_field(v_x1_24679, 0);
    V v_ru_24x1_24679_24Bug = heff_take_reuse_n(v_x1_24679, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24679_24Bug, TAG_Bug, 1, (V[]){v_what_24695});
  }
  default: return heff_nomatch(v_x1_24679);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args) {
  V v_d_24709 = args[0];
  V v_a_24710 = args[1];
  V v_a_24708 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24711 = heff_tr(heff_call(v_a_24710, 1, (V[]){v_d_24709}));
  switch (heff_tag_of(v_x1_24711)) {
  case TAG_Ok: {
    V v_v_24712 = heff_field(v_x1_24711, 0);
    V v_ru_24x1_24711_24Ok = heff_take_reuse_n(v_x1_24711, 1ULL, 1);
    switch (heff_tag_of(v_v_24712)) {
    case TAG_VFun: {
      heff_take_n(v_v_24712, 0ULL, 1);
      heff_drop(v_a_24708);
      heff_drop_cell(v_ru_24x1_24711_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24712, 0ULL, 1);
      heff_drop(v_a_24708);
      heff_drop_cell(v_ru_24x1_24711_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24712, 0ULL, 2);
      heff_drop(v_a_24708);
      heff_drop_cell(v_ru_24x1_24711_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24717 = heff_field(v_v_24712, 0);
      heff_take_n(v_v_24712, 1ULL, 1);
      V v_t_24718 = heff_runeToInt(heff_strRuneAt(v_a_24708, v_a_24717));
      return heff_tag_at_n(v_ru_24x1_24711_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VRune, 1, (V[]){v_t_24718})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24712, 0ULL, 1);
      heff_drop(v_a_24708);
      heff_drop_cell(v_ru_24x1_24711_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24712, 0ULL, 1);
      heff_drop(v_a_24708);
      heff_drop_cell(v_ru_24x1_24711_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24712, 0ULL, 1);
      heff_drop(v_a_24708);
      heff_drop_cell(v_ru_24x1_24711_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24712, 0ULL, 1);
      heff_drop(v_a_24708);
      heff_drop_cell(v_ru_24x1_24711_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24712, 0ULL, 1);
      heff_drop(v_a_24708);
      heff_drop_cell(v_ru_24x1_24711_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24712, 0ULL, 1);
      heff_drop(v_a_24708);
      heff_drop_cell(v_ru_24x1_24711_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24712, 0ULL, 2);
      heff_drop(v_a_24708);
      heff_drop_cell(v_ru_24x1_24711_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24708);
      heff_drop_cell(v_ru_24x1_24711_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24712);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24708);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24708);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24727 = heff_field(v_x1_24711, 0);
    V v_ru_24x1_24711_24Bug = heff_take_reuse_n(v_x1_24711, 1ULL, 1);
    heff_drop(v_a_24708);
    return heff_tag_at_n(v_ru_24x1_24711_24Bug, TAG_Bug, 1, (V[]){v_what_24727});
  }
  default: return heff_nomatch(v_x1_24711);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args) {
  V v_d_24697 = args[0];
  V v_a_24698 = args[1];
  V v_x1_24699 = heff_tr(heff_call(v_a_24698, 1, (V[]){v_d_24697}));
  switch (heff_tag_of(v_x1_24699)) {
  case TAG_Ok: {
    V v_v_24700 = heff_field(v_x1_24699, 0);
    V v_ru_24x1_24699_24Ok = heff_take_reuse_n(v_x1_24699, 1ULL, 1);
    switch (heff_tag_of(v_v_24700)) {
    case TAG_VFun: {
      heff_take_n(v_v_24700, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24700, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24700, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24700, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24700, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24700, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24708 = heff_field(v_v_24700, 0);
      heff_take_n(v_v_24700, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24699_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam55, 2, 1, (V[]){v_a_24708})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24700, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24700, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24700, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24700, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24700);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24733 = heff_field(v_x1_24699, 0);
    V v_ru_24x1_24699_24Bug = heff_take_reuse_n(v_x1_24699, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24699_24Bug, TAG_Bug, 1, (V[]){v_what_24733});
  }
  default: return heff_nomatch(v_x1_24699);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args) {
  V v_d_24747 = args[0];
  V v_a_24748 = args[1];
  V v_a_24746 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24749 = heff_tr(heff_call(v_a_24748, 1, (V[]){v_d_24747}));
  switch (heff_tag_of(v_x1_24749)) {
  case TAG_Ok: {
    V v_v_24750 = heff_field(v_x1_24749, 0);
    V v_ru_24x1_24749_24Ok = heff_take_reuse_n(v_x1_24749, 1ULL, 1);
    switch (heff_tag_of(v_v_24750)) {
    case TAG_VFun: {
      heff_take_n(v_v_24750, 0ULL, 1);
      heff_drop(v_a_24746);
      heff_drop_cell(v_ru_24x1_24749_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24750, 0ULL, 1);
      heff_drop(v_a_24746);
      heff_drop_cell(v_ru_24x1_24749_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24750, 0ULL, 2);
      heff_drop(v_a_24746);
      heff_drop_cell(v_ru_24x1_24749_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24755 = heff_field(v_v_24750, 0);
      V v_ru_24v_24750_24VInt = heff_take_reuse_n(v_v_24750, 1ULL, 1);
      V v_t_24756 = heff_tag_at_n(v_ru_24v_24750_24VInt, TAG_VInt, 1, (V[]){heff_strRuneWidth(v_a_24746, v_a_24755)});
      return heff_tag_at_n(v_ru_24x1_24749_24Ok, TAG_Ok, 1, (V[]){v_t_24756});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24750, 0ULL, 1);
      heff_drop(v_a_24746);
      heff_drop_cell(v_ru_24x1_24749_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24750, 0ULL, 1);
      heff_drop(v_a_24746);
      heff_drop_cell(v_ru_24x1_24749_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24750, 0ULL, 1);
      heff_drop(v_a_24746);
      heff_drop_cell(v_ru_24x1_24749_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24750, 0ULL, 1);
      heff_drop(v_a_24746);
      heff_drop_cell(v_ru_24x1_24749_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24750, 0ULL, 1);
      heff_drop(v_a_24746);
      heff_drop_cell(v_ru_24x1_24749_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24750, 0ULL, 1);
      heff_drop(v_a_24746);
      heff_drop_cell(v_ru_24x1_24749_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24750, 0ULL, 2);
      heff_drop(v_a_24746);
      heff_drop_cell(v_ru_24x1_24749_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24746);
      heff_drop_cell(v_ru_24x1_24749_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24750);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24746);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24746);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24765 = heff_field(v_x1_24749, 0);
    V v_ru_24x1_24749_24Bug = heff_take_reuse_n(v_x1_24749, 1ULL, 1);
    heff_drop(v_a_24746);
    return heff_tag_at_n(v_ru_24x1_24749_24Bug, TAG_Bug, 1, (V[]){v_what_24765});
  }
  default: return heff_nomatch(v_x1_24749);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args) {
  V v_d_24735 = args[0];
  V v_a_24736 = args[1];
  V v_x1_24737 = heff_tr(heff_call(v_a_24736, 1, (V[]){v_d_24735}));
  switch (heff_tag_of(v_x1_24737)) {
  case TAG_Ok: {
    V v_v_24738 = heff_field(v_x1_24737, 0);
    V v_ru_24x1_24737_24Ok = heff_take_reuse_n(v_x1_24737, 1ULL, 1);
    switch (heff_tag_of(v_v_24738)) {
    case TAG_VFun: {
      heff_take_n(v_v_24738, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24737_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24738, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24737_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24738, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24737_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24738, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24737_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24738, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24737_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24738, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24737_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24746 = heff_field(v_v_24738, 0);
      heff_take_n(v_v_24738, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24737_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam57, 2, 1, (V[]){v_a_24746})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24738, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24737_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24738, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24737_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24738, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24737_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24738, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24737_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24737_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24738);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24771 = heff_field(v_x1_24737, 0);
    V v_ru_24x1_24737_24Bug = heff_take_reuse_n(v_x1_24737, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24737_24Bug, TAG_Bug, 1, (V[]){v_what_24771});
  }
  default: return heff_nomatch(v_x1_24737);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args) {
  V v_d_24773 = args[0];
  V v_a_24774 = args[1];
  V v_x1_24775 = heff_tr(heff_call(v_a_24774, 1, (V[]){v_d_24773}));
  switch (heff_tag_of(v_x1_24775)) {
  case TAG_Ok: {
    V v_v_24776 = heff_field(v_x1_24775, 0);
    V v_ru_24x1_24775_24Ok = heff_take_reuse_n(v_x1_24775, 1ULL, 1);
    switch (heff_tag_of(v_v_24776)) {
    case TAG_VFun: {
      heff_take_n(v_v_24776, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24775_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24776, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24775_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24776, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24775_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24776, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24775_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24776, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24775_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24776, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24775_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24784 = heff_field(v_v_24776, 0);
      V v_ru_24v_24776_24VStr = heff_take_reuse_n(v_v_24776, 1ULL, 1);
      V v_t_24785 = heff_tag_at_n(v_ru_24v_24776_24VStr, TAG_VInt, 1, (V[]){heff_strRuneCount(v_a_24784)});
      return heff_tag_at_n(v_ru_24x1_24775_24Ok, TAG_Ok, 1, (V[]){v_t_24785});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24776, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24775_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24776, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24775_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24776, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24775_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24776, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24775_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24775_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24776);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24791 = heff_field(v_x1_24775, 0);
    V v_ru_24x1_24775_24Bug = heff_take_reuse_n(v_x1_24775, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24775_24Bug, TAG_Bug, 1, (V[]){v_what_24791});
  }
  default: return heff_nomatch(v_x1_24775);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args) {
  V v_d_24793 = args[0];
  V v_a_24794 = args[1];
  V v_x1_24795 = heff_tr(heff_call(v_a_24794, 1, (V[]){v_d_24793}));
  switch (heff_tag_of(v_x1_24795)) {
  case TAG_Ok: {
    V v_v_24796 = heff_field(v_x1_24795, 0);
    V v_ru_24x1_24795_24Ok = heff_take_reuse_n(v_x1_24795, 1ULL, 1);
    switch (heff_tag_of(v_v_24796)) {
    case TAG_VFun: {
      heff_take_n(v_v_24796, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24795_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24796, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24795_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24796, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24795_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24796, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24795_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24796, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24795_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24796, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24795_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24804 = heff_field(v_v_24796, 0);
      heff_take_n(v_v_24796, 1ULL, 1);
      V v_t_24805 = heff_strOfRunes(heff_strRunes(v_a_24804));
      return heff_tag_at_n(v_ru_24x1_24795_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_24805})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24796, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24795_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24796, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24795_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24796, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24795_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24796, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24795_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24795_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24796);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24811 = heff_field(v_x1_24795, 0);
    V v_ru_24x1_24795_24Bug = heff_take_reuse_n(v_x1_24795, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24795_24Bug, TAG_Bug, 1, (V[]){v_what_24811});
  }
  default: return heff_nomatch(v_x1_24795);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args) {
  V v_d_24813 = args[0];
  V v_a_24814 = args[1];
  V v_x1_24815 = heff_tr(heff_call(v_a_24814, 1, (V[]){v_d_24813}));
  switch (heff_tag_of(v_x1_24815)) {
  case TAG_Ok: {
    V v_v_24816 = heff_field(v_x1_24815, 0);
    V v_ru_24x1_24815_24Ok = heff_take_reuse_n(v_x1_24815, 1ULL, 1);
    switch (heff_tag_of(v_v_24816)) {
    case TAG_VFun: {
      heff_take_n(v_v_24816, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24815_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24816, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24815_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24816, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24815_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24816, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24815_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24816, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24815_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24816, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24815_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24824 = heff_field(v_v_24816, 0);
      heff_take_n(v_v_24816, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24815_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_a_24824})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24816, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24815_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24816, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24815_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24816, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24815_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24816, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24815_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24815_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24816);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24830 = heff_field(v_x1_24815, 0);
    V v_ru_24x1_24815_24Bug = heff_take_reuse_n(v_x1_24815, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24815_24Bug, TAG_Bug, 1, (V[]){v_what_24830});
  }
  default: return heff_nomatch(v_x1_24815);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args) {
  V v_d_24832 = args[0];
  V v_a_24833 = args[1];
  V v_x1_24834 = heff_tr(heff_call(v_a_24833, 1, (V[]){v_d_24832}));
  switch (heff_tag_of(v_x1_24834)) {
  case TAG_Ok: {
    V v_v_24835 = heff_field(v_x1_24834, 0);
    V v_ru_24x1_24834_24Ok = heff_take_reuse_n(v_x1_24834, 1ULL, 1);
    switch (heff_tag_of(v_v_24835)) {
    case TAG_VFun: {
      heff_take_n(v_v_24835, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24834_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24835, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24834_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24835, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24834_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24835, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24834_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24835, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24834_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24835, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24834_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24835, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24834_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24835, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24834_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24835, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24834_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_24846 = heff_field(v_v_24835, 0);
      V v_ru_24v_24835_24VBytes = heff_take_reuse_n(v_v_24835, 1ULL, 1);
      V v_t_24847 = heff_tag_at_n(v_ru_24v_24835_24VBytes, TAG_VInt, 1, (V[]){heff_strLength(v_a_24846)});
      return heff_tag_at_n(v_ru_24x1_24834_24Ok, TAG_Ok, 1, (V[]){v_t_24847});
    }
    case TAG_VBits: {
      heff_take_n(v_v_24835, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24834_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24834_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_24835);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24850 = heff_field(v_x1_24834, 0);
    V v_ru_24x1_24834_24Bug = heff_take_reuse_n(v_x1_24834, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24834_24Bug, TAG_Bug, 1, (V[]){v_what_24850});
  }
  default: return heff_nomatch(v_x1_24834);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args) {
  V v_d_24867 = args[0];
  V v_a_24868 = args[1];
  V v_a_24866 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24869 = heff_tr(heff_call(v_a_24868, 1, (V[]){v_d_24867}));
  switch (heff_tag_of(v_x1_24869)) {
  case TAG_Ok: {
    V v_v_24870 = heff_field(v_x1_24869, 0);
    V v_ru_24x1_24869_24Ok = heff_take_reuse_n(v_x1_24869, 1ULL, 1);
    switch (heff_tag_of(v_v_24870)) {
    case TAG_VFun: {
      heff_take_n(v_v_24870, 0ULL, 1);
      heff_drop(v_a_24866);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24870, 0ULL, 1);
      heff_drop(v_a_24866);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24870, 0ULL, 2);
      heff_drop(v_a_24866);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24875 = heff_field(v_v_24870, 0);
      V v_ru_24v_24870_24VInt = heff_take_reuse_n(v_v_24870, 1ULL, 1);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_a_24875))) {
        if (heff_intLt_c(heff_dup(v_a_24875), heff_strLength_lent(v_a_24866, 0))) {
          V v_t_24878 = heff_tag_at_n(v_ru_24v_24870_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_24866, v_a_24875)});
          return heff_tag_at_n(v_ru_24x1_24869_24Ok, TAG_Ok, 1, (V[]){v_t_24878});
        } else {
          heff_drop(v_a_24866);
          heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
          heff_drop(v_a_24875);
          heff_drop_cell(v_ru_24v_24870_24VInt, 1);
          return NTAG(TAG_Abn);
        }
      } else {
        heff_drop(v_a_24866);
        heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
        heff_drop(v_a_24875);
        heff_drop_cell(v_ru_24v_24870_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24870, 0ULL, 1);
      heff_drop(v_a_24866);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24870, 0ULL, 1);
      heff_drop(v_a_24866);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24870, 0ULL, 1);
      heff_drop(v_a_24866);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24870, 0ULL, 1);
      heff_drop(v_a_24866);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24870, 0ULL, 1);
      heff_drop(v_a_24866);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24870, 0ULL, 1);
      heff_drop(v_a_24866);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24870, 0ULL, 2);
      heff_drop(v_a_24866);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24866);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24870);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24866);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24866);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24887 = heff_field(v_x1_24869, 0);
    V v_ru_24x1_24869_24Bug = heff_take_reuse_n(v_x1_24869, 1ULL, 1);
    heff_drop(v_a_24866);
    return heff_tag_at_n(v_ru_24x1_24869_24Bug, TAG_Bug, 1, (V[]){v_what_24887});
  }
  default: return heff_nomatch(v_x1_24869);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args) {
  V v_d_24852 = args[0];
  V v_a_24853 = args[1];
  V v_x1_24854 = heff_tr(heff_call(v_a_24853, 1, (V[]){v_d_24852}));
  switch (heff_tag_of(v_x1_24854)) {
  case TAG_Ok: {
    V v_v_24855 = heff_field(v_x1_24854, 0);
    V v_ru_24x1_24854_24Ok = heff_take_reuse_n(v_x1_24854, 1ULL, 1);
    switch (heff_tag_of(v_v_24855)) {
    case TAG_VFun: {
      heff_take_n(v_v_24855, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24855, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24855, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24855, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24855, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24855, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24855, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24855, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24855, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_24866 = heff_field(v_v_24855, 0);
      heff_take_n(v_v_24855, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24854_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam63, 2, 1, (V[]){v_a_24866})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_24855, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_24855);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24890 = heff_field(v_x1_24854, 0);
    V v_ru_24x1_24854_24Bug = heff_take_reuse_n(v_x1_24854, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24854_24Bug, TAG_Bug, 1, (V[]){v_what_24890});
  }
  default: return heff_nomatch(v_x1_24854);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args) {
  V v_d_24916 = args[0];
  V v_a_24917 = args[1];
  V v_a_24906 = heff_env(self)[0];
  V v_a_24915 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24918 = heff_tr(heff_call(v_a_24917, 1, (V[]){v_d_24916}));
  switch (heff_tag_of(v_x1_24918)) {
  case TAG_Ok: {
    V v_v_24919 = heff_field(v_x1_24918, 0);
    V v_ru_24x1_24918_24Ok = heff_take_reuse_n(v_x1_24918, 1ULL, 1);
    switch (heff_tag_of(v_v_24919)) {
    case TAG_VFun: {
      heff_take_n(v_v_24919, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop(v_a_24915);
      heff_drop_cell(v_ru_24x1_24918_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24919, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop(v_a_24915);
      heff_drop_cell(v_ru_24x1_24918_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24919, 0ULL, 2);
      heff_drop(v_a_24906);
      heff_drop(v_a_24915);
      heff_drop_cell(v_ru_24x1_24918_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24924 = heff_field(v_v_24919, 0);
      V v_ru_24v_24919_24VInt = heff_take_reuse_n(v_v_24919, 1ULL, 1);
      V v_t_24925 = heff_tag_at_n(v_ru_24v_24919_24VInt, TAG_VBytes, 1, (V[]){heff_strSlice(v_a_24906, v_a_24915, v_a_24924)});
      return heff_tag_at_n(v_ru_24x1_24918_24Ok, TAG_Ok, 1, (V[]){v_t_24925});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24919, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop(v_a_24915);
      heff_drop_cell(v_ru_24x1_24918_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24919, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop(v_a_24915);
      heff_drop_cell(v_ru_24x1_24918_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24919, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop(v_a_24915);
      heff_drop_cell(v_ru_24x1_24918_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24919, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop(v_a_24915);
      heff_drop_cell(v_ru_24x1_24918_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24919, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop(v_a_24915);
      heff_drop_cell(v_ru_24x1_24918_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24919, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop(v_a_24915);
      heff_drop_cell(v_ru_24x1_24918_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24919, 0ULL, 2);
      heff_drop(v_a_24906);
      heff_drop(v_a_24915);
      heff_drop_cell(v_ru_24x1_24918_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24906);
      heff_drop(v_a_24915);
      heff_drop_cell(v_ru_24x1_24918_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24919);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24906);
    heff_drop(v_a_24915);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24906);
    heff_drop(v_a_24915);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24934 = heff_field(v_x1_24918, 0);
    V v_ru_24x1_24918_24Bug = heff_take_reuse_n(v_x1_24918, 1ULL, 1);
    heff_drop(v_a_24906);
    heff_drop(v_a_24915);
    return heff_tag_at_n(v_ru_24x1_24918_24Bug, TAG_Bug, 1, (V[]){v_what_24934});
  }
  default: return heff_nomatch(v_x1_24918);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args) {
  V v_d_24907 = args[0];
  V v_a_24908 = args[1];
  V v_a_24906 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24909 = heff_tr(heff_call(v_a_24908, 1, (V[]){v_d_24907}));
  switch (heff_tag_of(v_x1_24909)) {
  case TAG_Ok: {
    V v_v_24910 = heff_field(v_x1_24909, 0);
    V v_ru_24x1_24909_24Ok = heff_take_reuse_n(v_x1_24909, 1ULL, 1);
    switch (heff_tag_of(v_v_24910)) {
    case TAG_VFun: {
      heff_take_n(v_v_24910, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop_cell(v_ru_24x1_24909_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24910, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop_cell(v_ru_24x1_24909_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24910, 0ULL, 2);
      heff_drop(v_a_24906);
      heff_drop_cell(v_ru_24x1_24909_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24915 = heff_field(v_v_24910, 0);
      heff_take_n(v_v_24910, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24909_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam66, 2, 2, (V[]){v_a_24906, v_a_24915})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24910, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop_cell(v_ru_24x1_24909_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24910, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop_cell(v_ru_24x1_24909_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24910, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop_cell(v_ru_24x1_24909_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24910, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop_cell(v_ru_24x1_24909_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24910, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop_cell(v_ru_24x1_24909_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24910, 0ULL, 1);
      heff_drop(v_a_24906);
      heff_drop_cell(v_ru_24x1_24909_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24910, 0ULL, 2);
      heff_drop(v_a_24906);
      heff_drop_cell(v_ru_24x1_24909_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24906);
      heff_drop_cell(v_ru_24x1_24909_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24910);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24906);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24906);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24943 = heff_field(v_x1_24909, 0);
    V v_ru_24x1_24909_24Bug = heff_take_reuse_n(v_x1_24909, 1ULL, 1);
    heff_drop(v_a_24906);
    return heff_tag_at_n(v_ru_24x1_24909_24Bug, TAG_Bug, 1, (V[]){v_what_24943});
  }
  default: return heff_nomatch(v_x1_24909);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args) {
  V v_d_24892 = args[0];
  V v_a_24893 = args[1];
  V v_x1_24894 = heff_tr(heff_call(v_a_24893, 1, (V[]){v_d_24892}));
  switch (heff_tag_of(v_x1_24894)) {
  case TAG_Ok: {
    V v_v_24895 = heff_field(v_x1_24894, 0);
    V v_ru_24x1_24894_24Ok = heff_take_reuse_n(v_x1_24894, 1ULL, 1);
    switch (heff_tag_of(v_v_24895)) {
    case TAG_VFun: {
      heff_take_n(v_v_24895, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24894_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24895, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24894_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24895, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24894_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24895, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24894_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24895, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24894_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24895, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24894_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24895, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24894_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24895, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24894_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24895, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24894_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_24906 = heff_field(v_v_24895, 0);
      heff_take_n(v_v_24895, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24894_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam65, 2, 1, (V[]){v_a_24906})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_24895, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24894_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24894_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_24895);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24946 = heff_field(v_x1_24894, 0);
    V v_ru_24x1_24894_24Bug = heff_take_reuse_n(v_x1_24894, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24894_24Bug, TAG_Bug, 1, (V[]){v_what_24946});
  }
  default: return heff_nomatch(v_x1_24894);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args) {
  V v_d_24949 = args[0];
  V v_l_24950 = args[1];
  V v_x1_24951 = heff_tr(heff_call(v_l_24950, 1, (V[]){v_d_24949}));
  switch (heff_tag_of(v_x1_24951)) {
  case TAG_Ok: {
    V v_v_24952 = heff_field(v_x1_24951, 0);
    heff_take_n(v_x1_24951, 1ULL, 1);
    V v_t_24953 = (g_heff_2ecompile_2einterp_2efromListV(v_v_24952, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_24953; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str77); V r_ = (g_heff_2ecompile_2einterp_2ebytesJoined(a_0, a_1)); heff_drop(v_t_24953); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24954 = heff_field(v_x1_24951, 0);
    V v_ru_24x1_24951_24Bug = heff_take_reuse_n(v_x1_24951, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24951_24Bug, TAG_Bug, 1, (V[]){v_what_24954});
  }
  default: return heff_nomatch(v_x1_24951);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args) {
  V v_a_24956 = args[0];
  V v_b_24957 = args[1];
  V v_t_24959;
  if (heff_strEq_c(v_a_24956, v_b_24957)) {
    v_t_24959 = ((V)&g_heff_2ecompile_2einterp_2eprim_str79);
  } else {
    v_t_24959 = ((V)&g_heff_2ecompile_2einterp_2eprim_str80);
  }
  V v_t_24960 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24959, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24960});
}
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args) {
  V v_d_24962 = args[0];
  V v_l_24963 = args[1];
  V v_x1_24964 = heff_tr(heff_call(v_l_24963, 1, (V[]){v_d_24962}));
  switch (heff_tag_of(v_x1_24964)) {
  case TAG_Ok: {
    V v_v_24965 = heff_field(v_x1_24964, 0);
    V v_ru_24x1_24964_24Ok = heff_take_reuse_n(v_x1_24964, 1ULL, 1);
    V v_t_24966 = (g_heff_2ecompile_2einterp_2efromListV(v_v_24965, NTAG(TAG_Nil)));
    V v_t_24967 = ({ V a_0 = v_t_24966; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str82); V r_ = (g_heff_2ecompile_2einterp_2ebyteString(a_0, a_1)); heff_drop(v_t_24966); r_; });
    return heff_tag_at_n(v_ru_24x1_24964_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_t_24967})});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24968 = heff_field(v_x1_24964, 0);
    V v_ru_24x1_24964_24Bug = heff_take_reuse_n(v_x1_24964, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24964_24Bug, TAG_Bug, 1, (V[]){v_what_24968});
  }
  default: return heff_nomatch(v_x1_24964);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args) {
  V v_d_24970 = args[0];
  V v_a_24971 = args[1];
  V v_x1_24972 = heff_tr(heff_call(v_a_24971, 1, (V[]){v_d_24970}));
  switch (heff_tag_of(v_x1_24972)) {
  case TAG_Ok: {
    V v_v_24973 = heff_field(v_x1_24972, 0);
    V v_ru_24x1_24972_24Ok = heff_take_reuse_n(v_x1_24972, 1ULL, 1);
    switch (heff_tag_of(v_v_24973)) {
    case TAG_VFun: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24973, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_24984 = heff_field(v_v_24973, 0);
      heff_take_n(v_v_24973, 1ULL, 1);
      V v_t_24985 = heff_intSub(heff_strLength_lent(v_a_24984, 0), MK_INT(1LL));
      V v_t_24986 = (g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(v_a_24984, MK_INT(0LL), v_t_24985));
      return heff_tag_at_n(v_ru_24x1_24972_24Ok, TAG_Ok, 1, (V[]){v_t_24986});
    }
    case TAG_VBits: {
      heff_take_n(v_v_24973, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_24973);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24989 = heff_field(v_x1_24972, 0);
    V v_ru_24x1_24972_24Bug = heff_take_reuse_n(v_x1_24972, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24972_24Bug, TAG_Bug, 1, (V[]){v_what_24989});
  }
  default: return heff_nomatch(v_x1_24972);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args) {
  V v_d_24991 = args[0];
  V v_a_24992 = args[1];
  V v_x1_24993 = heff_tr(heff_call(v_a_24992, 1, (V[]){v_d_24991}));
  switch (heff_tag_of(v_x1_24993)) {
  case TAG_Ok: {
    V v_v_24994 = heff_field(v_x1_24993, 0);
    V v_ru_24x1_24993_24Ok = heff_take_reuse_n(v_x1_24993, 1ULL, 1);
    switch (heff_tag_of(v_v_24994)) {
    case TAG_VFun: {
      heff_take_n(v_v_24994, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24993_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24994, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24993_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24994, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24993_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24994, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24993_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24994, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24993_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24994, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24993_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241002 = heff_field(v_v_24994, 0);
      heff_take_n(v_v_24994, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24993_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_a_241002})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24994, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24993_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24994, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24993_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24994, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24993_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24994, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24993_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24993_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24994);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241008 = heff_field(v_x1_24993, 0);
    V v_ru_24x1_24993_24Bug = heff_take_reuse_n(v_x1_24993, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24993_24Bug, TAG_Bug, 1, (V[]){v_what_241008});
  }
  default: return heff_nomatch(v_x1_24993);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args) {
  V v_d_241010 = args[0];
  V v_a_241011 = args[1];
  V v_x1_241012 = heff_tr(heff_call(v_a_241011, 1, (V[]){v_d_241010}));
  switch (heff_tag_of(v_x1_241012)) {
  case TAG_Ok: {
    V v_v_241013 = heff_field(v_x1_241012, 0);
    V v_ru_24x1_241012_24Ok = heff_take_reuse_n(v_x1_241012, 1ULL, 1);
    switch (heff_tag_of(v_v_241013)) {
    case TAG_VFun: {
      heff_take_n(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241013, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241024 = heff_field(v_v_241013, 0);
      heff_take_n(v_v_241013, 1ULL, 1);
      V v_t_241025 = (g_rune_2evalidFrom(heff_dup(v_a_241024), MK_INT(0LL)));
      V v_t_241026;
      if ((heff_dup(v_t_241025) == NTAG(TAG_True))) {
        heff_drop(v_t_241025);
        v_t_241026 = v_a_241024;
      } else {
        heff_drop(v_t_241025);
        v_t_241026 = heff_strOfRunes(heff_strRunes(v_a_241024));
      }
      return heff_tag_at_n(v_ru_24x1_241012_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_241026})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241013, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241013);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241029 = heff_field(v_x1_241012, 0);
    V v_ru_24x1_241012_24Bug = heff_take_reuse_n(v_x1_241012, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241012_24Bug, TAG_Bug, 1, (V[]){v_what_241029});
  }
  default: return heff_nomatch(v_x1_241012);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args) {
  V v_d_241064 = args[0];
  V v_a_241065 = args[1];
  V v_a_241045 = heff_env(self)[0];
  V v_a_241054 = heff_env(self)[1];
  V v_a_241063 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241066 = heff_tr(heff_call(v_a_241065, 1, (V[]){v_d_241064}));
  switch (heff_tag_of(v_x1_241066)) {
  case TAG_Ok: {
    V v_v_241067 = heff_field(v_x1_241066, 0);
    heff_take_n(v_x1_241066, 1ULL, 1);
    switch (heff_tag_of(v_v_241067)) {
    case TAG_VFun: {
      heff_take_n(v_v_241067, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop(v_a_241063);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241067, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop(v_a_241063);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241067, 0ULL, 2);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop(v_a_241063);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241072 = heff_field(v_v_241067, 0);
      heff_take_n(v_v_241067, 1ULL, 1);
      V v_t_241073 = heff_intMul(heff_strLength_lent(v_a_241045, 0), MK_INT(8LL));
      return (g_heff_2ecompile_2einterp_2eintAtV(v_a_241045, v_t_241073, v_a_241054, v_a_241063, v_a_241072));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241067, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop(v_a_241063);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241067, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop(v_a_241063);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241067, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop(v_a_241063);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241067, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop(v_a_241063);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241067, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop(v_a_241063);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241067, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop(v_a_241063);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241067, 0ULL, 2);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop(v_a_241063);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop(v_a_241063);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241067);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241045);
    heff_drop(v_a_241054);
    heff_drop(v_a_241063);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241045);
    heff_drop(v_a_241054);
    heff_drop(v_a_241063);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241082 = heff_field(v_x1_241066, 0);
    V v_ru_24x1_241066_24Bug = heff_take_reuse_n(v_x1_241066, 1ULL, 1);
    heff_drop(v_a_241045);
    heff_drop(v_a_241054);
    heff_drop(v_a_241063);
    return heff_tag_at_n(v_ru_24x1_241066_24Bug, TAG_Bug, 1, (V[]){v_what_241082});
  }
  default: return heff_nomatch(v_x1_241066);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args) {
  V v_d_241055 = args[0];
  V v_a_241056 = args[1];
  V v_a_241045 = heff_env(self)[0];
  V v_a_241054 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241057 = heff_tr(heff_call(v_a_241056, 1, (V[]){v_d_241055}));
  switch (heff_tag_of(v_x1_241057)) {
  case TAG_Ok: {
    V v_v_241058 = heff_field(v_x1_241057, 0);
    V v_ru_24x1_241057_24Ok = heff_take_reuse_n(v_x1_241057, 1ULL, 1);
    switch (heff_tag_of(v_v_241058)) {
    case TAG_VFun: {
      heff_take_n(v_v_241058, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop_cell(v_ru_24x1_241057_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241058, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop_cell(v_ru_24x1_241057_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241058, 0ULL, 2);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop_cell(v_ru_24x1_241057_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241063 = heff_field(v_v_241058, 0);
      heff_take_n(v_v_241058, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241057_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam76, 2, 3, (V[]){v_a_241045, v_a_241054, v_a_241063})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241058, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop_cell(v_ru_24x1_241057_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241058, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop_cell(v_ru_24x1_241057_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241058, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop_cell(v_ru_24x1_241057_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241058, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop_cell(v_ru_24x1_241057_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241058, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop_cell(v_ru_24x1_241057_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241058, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop_cell(v_ru_24x1_241057_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241058, 0ULL, 2);
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop_cell(v_ru_24x1_241057_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241045);
      heff_drop(v_a_241054);
      heff_drop_cell(v_ru_24x1_241057_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241058);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241045);
    heff_drop(v_a_241054);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241045);
    heff_drop(v_a_241054);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241091 = heff_field(v_x1_241057, 0);
    V v_ru_24x1_241057_24Bug = heff_take_reuse_n(v_x1_241057, 1ULL, 1);
    heff_drop(v_a_241045);
    heff_drop(v_a_241054);
    return heff_tag_at_n(v_ru_24x1_241057_24Bug, TAG_Bug, 1, (V[]){v_what_241091});
  }
  default: return heff_nomatch(v_x1_241057);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args) {
  V v_d_241046 = args[0];
  V v_a_241047 = args[1];
  V v_a_241045 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241048 = heff_tr(heff_call(v_a_241047, 1, (V[]){v_d_241046}));
  switch (heff_tag_of(v_x1_241048)) {
  case TAG_Ok: {
    V v_v_241049 = heff_field(v_x1_241048, 0);
    V v_ru_24x1_241048_24Ok = heff_take_reuse_n(v_x1_241048, 1ULL, 1);
    switch (heff_tag_of(v_v_241049)) {
    case TAG_VFun: {
      heff_take_n(v_v_241049, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop_cell(v_ru_24x1_241048_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241049, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop_cell(v_ru_24x1_241048_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241049, 0ULL, 2);
      heff_drop(v_a_241045);
      heff_drop_cell(v_ru_24x1_241048_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241054 = heff_field(v_v_241049, 0);
      heff_take_n(v_v_241049, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241048_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam75, 2, 2, (V[]){v_a_241045, v_a_241054})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241049, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop_cell(v_ru_24x1_241048_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241049, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop_cell(v_ru_24x1_241048_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241049, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop_cell(v_ru_24x1_241048_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241049, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop_cell(v_ru_24x1_241048_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241049, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop_cell(v_ru_24x1_241048_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241049, 0ULL, 1);
      heff_drop(v_a_241045);
      heff_drop_cell(v_ru_24x1_241048_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241049, 0ULL, 2);
      heff_drop(v_a_241045);
      heff_drop_cell(v_ru_24x1_241048_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241045);
      heff_drop_cell(v_ru_24x1_241048_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241049);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241045);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241045);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241100 = heff_field(v_x1_241048, 0);
    V v_ru_24x1_241048_24Bug = heff_take_reuse_n(v_x1_241048, 1ULL, 1);
    heff_drop(v_a_241045);
    return heff_tag_at_n(v_ru_24x1_241048_24Bug, TAG_Bug, 1, (V[]){v_what_241100});
  }
  default: return heff_nomatch(v_x1_241048);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args) {
  V v_d_241031 = args[0];
  V v_a_241032 = args[1];
  V v_x1_241033 = heff_tr(heff_call(v_a_241032, 1, (V[]){v_d_241031}));
  switch (heff_tag_of(v_x1_241033)) {
  case TAG_Ok: {
    V v_v_241034 = heff_field(v_x1_241033, 0);
    V v_ru_24x1_241033_24Ok = heff_take_reuse_n(v_x1_241033, 1ULL, 1);
    switch (heff_tag_of(v_v_241034)) {
    case TAG_VFun: {
      heff_take_n(v_v_241034, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241033_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241034, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241033_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241034, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241033_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241034, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241033_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241034, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241033_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241034, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241033_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241034, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241033_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241034, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241033_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241034, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241033_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241045 = heff_field(v_v_241034, 0);
      heff_take_n(v_v_241034, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241033_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam74, 2, 1, (V[]){v_a_241045})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241034, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241033_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241033_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241034);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241103 = heff_field(v_x1_241033, 0);
    V v_ru_24x1_241033_24Bug = heff_take_reuse_n(v_x1_241033, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241033_24Bug, TAG_Bug, 1, (V[]){v_what_241103});
  }
  default: return heff_nomatch(v_x1_241033);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args) {
  V v_d_241123 = args[0];
  V v_a_241124 = args[1];
  V v_a_241113 = heff_env(self)[0];
  V v_a_241122 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241125 = heff_tr(heff_call(v_a_241124, 1, (V[]){v_d_241123}));
  switch (heff_tag_of(v_x1_241125)) {
  case TAG_Ok: {
    V v_v_241126 = heff_field(v_x1_241125, 0);
    heff_take_n(v_x1_241125, 1ULL, 1);
    switch (heff_tag_of(v_v_241126)) {
    case TAG_VFun: {
      heff_take_n(v_v_241126, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop(v_a_241122);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241126, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop(v_a_241122);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241126, 0ULL, 2);
      heff_drop(v_a_241113);
      heff_drop(v_a_241122);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241131 = heff_field(v_v_241126, 0);
      heff_take_n(v_v_241126, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2ebytesOfIntV(v_a_241113, v_a_241122, v_a_241131));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241126, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop(v_a_241122);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241126, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop(v_a_241122);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241126, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop(v_a_241122);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241126, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop(v_a_241122);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241126, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop(v_a_241122);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241126, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop(v_a_241122);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241126, 0ULL, 2);
      heff_drop(v_a_241113);
      heff_drop(v_a_241122);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241113);
      heff_drop(v_a_241122);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241126);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241113);
    heff_drop(v_a_241122);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241113);
    heff_drop(v_a_241122);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241140 = heff_field(v_x1_241125, 0);
    V v_ru_24x1_241125_24Bug = heff_take_reuse_n(v_x1_241125, 1ULL, 1);
    heff_drop(v_a_241113);
    heff_drop(v_a_241122);
    return heff_tag_at_n(v_ru_24x1_241125_24Bug, TAG_Bug, 1, (V[]){v_what_241140});
  }
  default: return heff_nomatch(v_x1_241125);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args) {
  V v_d_241114 = args[0];
  V v_a_241115 = args[1];
  V v_a_241113 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241116 = heff_tr(heff_call(v_a_241115, 1, (V[]){v_d_241114}));
  switch (heff_tag_of(v_x1_241116)) {
  case TAG_Ok: {
    V v_v_241117 = heff_field(v_x1_241116, 0);
    V v_ru_24x1_241116_24Ok = heff_take_reuse_n(v_x1_241116, 1ULL, 1);
    switch (heff_tag_of(v_v_241117)) {
    case TAG_VFun: {
      heff_take_n(v_v_241117, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop_cell(v_ru_24x1_241116_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241117, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop_cell(v_ru_24x1_241116_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241117, 0ULL, 2);
      heff_drop(v_a_241113);
      heff_drop_cell(v_ru_24x1_241116_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241122 = heff_field(v_v_241117, 0);
      heff_take_n(v_v_241117, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241116_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam79, 2, 2, (V[]){v_a_241113, v_a_241122})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241117, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop_cell(v_ru_24x1_241116_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241117, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop_cell(v_ru_24x1_241116_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241117, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop_cell(v_ru_24x1_241116_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241117, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop_cell(v_ru_24x1_241116_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241117, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop_cell(v_ru_24x1_241116_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241117, 0ULL, 1);
      heff_drop(v_a_241113);
      heff_drop_cell(v_ru_24x1_241116_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241117, 0ULL, 2);
      heff_drop(v_a_241113);
      heff_drop_cell(v_ru_24x1_241116_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241113);
      heff_drop_cell(v_ru_24x1_241116_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241117);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241113);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241113);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241149 = heff_field(v_x1_241116, 0);
    V v_ru_24x1_241116_24Bug = heff_take_reuse_n(v_x1_241116, 1ULL, 1);
    heff_drop(v_a_241113);
    return heff_tag_at_n(v_ru_24x1_241116_24Bug, TAG_Bug, 1, (V[]){v_what_241149});
  }
  default: return heff_nomatch(v_x1_241116);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args) {
  V v_d_241105 = args[0];
  V v_a_241106 = args[1];
  V v_x1_241107 = heff_tr(heff_call(v_a_241106, 1, (V[]){v_d_241105}));
  switch (heff_tag_of(v_x1_241107)) {
  case TAG_Ok: {
    V v_v_241108 = heff_field(v_x1_241107, 0);
    V v_ru_24x1_241107_24Ok = heff_take_reuse_n(v_x1_241107, 1ULL, 1);
    switch (heff_tag_of(v_v_241108)) {
    case TAG_VFun: {
      heff_take_n(v_v_241108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241108, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241113 = heff_field(v_v_241108, 0);
      heff_take_n(v_v_241108, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241107_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam78, 2, 1, (V[]){v_a_241113})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241108, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241108, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241107_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241108);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241158 = heff_field(v_x1_241107, 0);
    V v_ru_24x1_241107_24Bug = heff_take_reuse_n(v_x1_241107, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241107_24Bug, TAG_Bug, 1, (V[]){v_what_241158});
  }
  default: return heff_nomatch(v_x1_241107);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args) {
  V v_d_241184 = args[0];
  V v_a_241185 = args[1];
  V v_a_241183 = heff_env(self)[0];
  V v_a_241174 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241186 = heff_tr(heff_call(v_a_241185, 1, (V[]){v_d_241184}));
  switch (heff_tag_of(v_x1_241186)) {
  case TAG_Ok: {
    V v_v_241187 = heff_field(v_x1_241186, 0);
    V v_ru_24x1_241186_24Ok = heff_take_reuse_n(v_x1_241186, 1ULL, 1);
    switch (heff_tag_of(v_v_241187)) {
    case TAG_VFun: {
      heff_take_n(v_v_241187, 0ULL, 1);
      heff_drop(v_a_241183);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241186_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241187, 0ULL, 1);
      heff_drop(v_a_241183);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241186_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241187, 0ULL, 2);
      heff_drop(v_a_241183);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241186_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241187, 0ULL, 1);
      heff_drop(v_a_241183);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241186_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241187, 0ULL, 1);
      heff_drop(v_a_241183);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241186_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241187, 0ULL, 1);
      heff_drop(v_a_241183);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241186_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241187, 0ULL, 1);
      heff_drop(v_a_241183);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241186_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241187, 0ULL, 1);
      heff_drop(v_a_241183);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241186_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241187, 0ULL, 1);
      heff_drop(v_a_241183);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241186_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241198 = heff_field(v_v_241187, 0);
      heff_take_n(v_v_241187, 1ULL, 1);
      V v_t_241204;
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_a_241183))) {
        V v_t_241200 = heff_intAdd(heff_dup(v_a_241183), heff_strLength_lent(v_a_241198, 0));
        if (heff_intLe_c(v_t_241200, heff_strLength_lent(v_a_241174, 0))) {
          V v_t_241202 = heff_intAdd(heff_dup(v_a_241183), heff_strLength_lent(v_a_241198, 0));
          if (heff_strEq_c(heff_strSlice(v_a_241174, v_a_241183, v_t_241202), v_a_241198)) {
            v_t_241204 = ((V)&g_heff_2ecompile_2einterp_2eprim_str89);
          } else {
            v_t_241204 = ((V)&g_heff_2ecompile_2einterp_2eprim_str90);
          }
        } else {
          heff_drop(v_a_241183);
          heff_drop(v_a_241174);
          heff_drop(v_a_241198);
          v_t_241204 = ((V)&g_heff_2ecompile_2einterp_2eprim_str91);
        }
      } else {
        heff_drop(v_a_241183);
        heff_drop(v_a_241174);
        heff_drop(v_a_241198);
        v_t_241204 = ((V)&g_heff_2ecompile_2einterp_2eprim_str92);
      }
      V v_t_241205 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241204, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_241186_24Ok, TAG_Ok, 1, (V[]){v_t_241205});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241187, 0ULL, 2);
      heff_drop(v_a_241183);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241186_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241183);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241186_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241187);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241183);
    heff_drop(v_a_241174);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241183);
    heff_drop(v_a_241174);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241208 = heff_field(v_x1_241186, 0);
    V v_ru_24x1_241186_24Bug = heff_take_reuse_n(v_x1_241186, 1ULL, 1);
    heff_drop(v_a_241183);
    heff_drop(v_a_241174);
    return heff_tag_at_n(v_ru_24x1_241186_24Bug, TAG_Bug, 1, (V[]){v_what_241208});
  }
  default: return heff_nomatch(v_x1_241186);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args) {
  V v_d_241175 = args[0];
  V v_a_241176 = args[1];
  V v_a_241174 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241177 = heff_tr(heff_call(v_a_241176, 1, (V[]){v_d_241175}));
  switch (heff_tag_of(v_x1_241177)) {
  case TAG_Ok: {
    V v_v_241178 = heff_field(v_x1_241177, 0);
    V v_ru_24x1_241177_24Ok = heff_take_reuse_n(v_x1_241177, 1ULL, 1);
    switch (heff_tag_of(v_v_241178)) {
    case TAG_VFun: {
      heff_take_n(v_v_241178, 0ULL, 1);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241177_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241178, 0ULL, 1);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241177_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241178, 0ULL, 2);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241177_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241183 = heff_field(v_v_241178, 0);
      heff_take_n(v_v_241178, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241177_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam82, 2, 2, (V[]){v_a_241183, v_a_241174})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241178, 0ULL, 1);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241177_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241178, 0ULL, 1);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241177_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241178, 0ULL, 1);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241177_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241178, 0ULL, 1);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241177_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241178, 0ULL, 1);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241177_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241178, 0ULL, 1);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241177_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241178, 0ULL, 2);
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241177_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241174);
      heff_drop_cell(v_ru_24x1_241177_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241178);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241174);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241174);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241217 = heff_field(v_x1_241177, 0);
    V v_ru_24x1_241177_24Bug = heff_take_reuse_n(v_x1_241177, 1ULL, 1);
    heff_drop(v_a_241174);
    return heff_tag_at_n(v_ru_24x1_241177_24Bug, TAG_Bug, 1, (V[]){v_what_241217});
  }
  default: return heff_nomatch(v_x1_241177);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args) {
  V v_d_241160 = args[0];
  V v_a_241161 = args[1];
  V v_x1_241162 = heff_tr(heff_call(v_a_241161, 1, (V[]){v_d_241160}));
  switch (heff_tag_of(v_x1_241162)) {
  case TAG_Ok: {
    V v_v_241163 = heff_field(v_x1_241162, 0);
    V v_ru_24x1_241162_24Ok = heff_take_reuse_n(v_x1_241162, 1ULL, 1);
    switch (heff_tag_of(v_v_241163)) {
    case TAG_VFun: {
      heff_take_n(v_v_241163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241163, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241174 = heff_field(v_v_241163, 0);
      heff_take_n(v_v_241163, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241162_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam81, 2, 1, (V[]){v_a_241174})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241163, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241163);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241220 = heff_field(v_x1_241162, 0);
    V v_ru_24x1_241162_24Bug = heff_take_reuse_n(v_x1_241162, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241162_24Bug, TAG_Bug, 1, (V[]){v_what_241220});
  }
  default: return heff_nomatch(v_x1_241162);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args) {
  V v_d_241243 = args[0];
  V v_a_241244 = args[1];
  V v_s_241224 = heff_env(self)[0];
  V v_m_241223 = heff_env(self)[1];
  V v_a_241233 = heff_env(self)[2];
  V v_a_241242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_241245 = heff_tr(heff_call(v_a_241244, 1, (V[]){v_d_241243}));
  switch (heff_tag_of(v_x1_241245)) {
  case TAG_Ok: {
    V v_v_241246 = heff_field(v_x1_241245, 0);
    heff_take_n(v_x1_241245, 1ULL, 1);
    switch (heff_tag_of(v_v_241246)) {
    case TAG_VFun: {
      heff_take_n(v_v_241246, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop(v_a_241242);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241246, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop(v_a_241242);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241246, 0ULL, 2);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop(v_a_241242);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241251 = heff_field(v_v_241246, 0);
      heff_take_n(v_v_241246, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2eintAtV(v_s_241224, v_m_241223, v_a_241233, v_a_241242, v_a_241251));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241246, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop(v_a_241242);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241246, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop(v_a_241242);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241246, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop(v_a_241242);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241246, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop(v_a_241242);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241246, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop(v_a_241242);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241246, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop(v_a_241242);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241246, 0ULL, 2);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop(v_a_241242);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop(v_a_241242);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241224);
    heff_drop(v_m_241223);
    heff_drop(v_a_241233);
    heff_drop(v_a_241242);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241224);
    heff_drop(v_m_241223);
    heff_drop(v_a_241233);
    heff_drop(v_a_241242);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241260 = heff_field(v_x1_241245, 0);
    V v_ru_24x1_241245_24Bug = heff_take_reuse_n(v_x1_241245, 1ULL, 1);
    heff_drop(v_s_241224);
    heff_drop(v_m_241223);
    heff_drop(v_a_241233);
    heff_drop(v_a_241242);
    return heff_tag_at_n(v_ru_24x1_241245_24Bug, TAG_Bug, 1, (V[]){v_what_241260});
  }
  default: return heff_nomatch(v_x1_241245);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args) {
  V v_d_241234 = args[0];
  V v_a_241235 = args[1];
  V v_s_241224 = heff_env(self)[0];
  V v_m_241223 = heff_env(self)[1];
  V v_a_241233 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241236 = heff_tr(heff_call(v_a_241235, 1, (V[]){v_d_241234}));
  switch (heff_tag_of(v_x1_241236)) {
  case TAG_Ok: {
    V v_v_241237 = heff_field(v_x1_241236, 0);
    V v_ru_24x1_241236_24Ok = heff_take_reuse_n(v_x1_241236, 1ULL, 1);
    switch (heff_tag_of(v_v_241237)) {
    case TAG_VFun: {
      heff_take_n(v_v_241237, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop_cell(v_ru_24x1_241236_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241237, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop_cell(v_ru_24x1_241236_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241237, 0ULL, 2);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop_cell(v_ru_24x1_241236_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241242 = heff_field(v_v_241237, 0);
      heff_take_n(v_v_241237, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241236_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam86, 2, 4, (V[]){v_s_241224, v_m_241223, v_a_241233, v_a_241242})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241237, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop_cell(v_ru_24x1_241236_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241237, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop_cell(v_ru_24x1_241236_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241237, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop_cell(v_ru_24x1_241236_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241237, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop_cell(v_ru_24x1_241236_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241237, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop_cell(v_ru_24x1_241236_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241237, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop_cell(v_ru_24x1_241236_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241237, 0ULL, 2);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop_cell(v_ru_24x1_241236_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop(v_a_241233);
      heff_drop_cell(v_ru_24x1_241236_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241237);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241224);
    heff_drop(v_m_241223);
    heff_drop(v_a_241233);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241224);
    heff_drop(v_m_241223);
    heff_drop(v_a_241233);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241269 = heff_field(v_x1_241236, 0);
    V v_ru_24x1_241236_24Bug = heff_take_reuse_n(v_x1_241236, 1ULL, 1);
    heff_drop(v_s_241224);
    heff_drop(v_m_241223);
    heff_drop(v_a_241233);
    return heff_tag_at_n(v_ru_24x1_241236_24Bug, TAG_Bug, 1, (V[]){v_what_241269});
  }
  default: return heff_nomatch(v_x1_241236);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args) {
  V v_d_241225 = args[0];
  V v_a_241226 = args[1];
  V v_s_241224 = heff_env(self)[0];
  V v_m_241223 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241227 = heff_tr(heff_call(v_a_241226, 1, (V[]){v_d_241225}));
  switch (heff_tag_of(v_x1_241227)) {
  case TAG_Ok: {
    V v_v_241228 = heff_field(v_x1_241227, 0);
    V v_ru_24x1_241227_24Ok = heff_take_reuse_n(v_x1_241227, 1ULL, 1);
    switch (heff_tag_of(v_v_241228)) {
    case TAG_VFun: {
      heff_take_n(v_v_241228, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop_cell(v_ru_24x1_241227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241228, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop_cell(v_ru_24x1_241227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241228, 0ULL, 2);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop_cell(v_ru_24x1_241227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241233 = heff_field(v_v_241228, 0);
      heff_take_n(v_v_241228, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241227_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam85, 2, 3, (V[]){v_s_241224, v_m_241223, v_a_241233})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241228, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop_cell(v_ru_24x1_241227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241228, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop_cell(v_ru_24x1_241227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241228, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop_cell(v_ru_24x1_241227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241228, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop_cell(v_ru_24x1_241227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241228, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop_cell(v_ru_24x1_241227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241228, 0ULL, 1);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop_cell(v_ru_24x1_241227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241228, 0ULL, 2);
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop_cell(v_ru_24x1_241227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241224);
      heff_drop(v_m_241223);
      heff_drop_cell(v_ru_24x1_241227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241228);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241224);
    heff_drop(v_m_241223);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241224);
    heff_drop(v_m_241223);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241278 = heff_field(v_x1_241227, 0);
    V v_ru_24x1_241227_24Bug = heff_take_reuse_n(v_x1_241227, 1ULL, 1);
    heff_drop(v_s_241224);
    heff_drop(v_m_241223);
    return heff_tag_at_n(v_ru_24x1_241227_24Bug, TAG_Bug, 1, (V[]){v_what_241278});
  }
  default: return heff_nomatch(v_x1_241227);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args) {
  V v_m_241223 = args[0];
  V v_s_241224 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam84, 2, 2, (V[]){v_s_241224, v_m_241223})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args) {
  V v_d_241298 = args[0];
  V v_a_241299 = args[1];
  V v_a_241288 = heff_env(self)[0];
  V v_a_241297 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241300 = heff_tr(heff_call(v_a_241299, 1, (V[]){v_d_241298}));
  switch (heff_tag_of(v_x1_241300)) {
  case TAG_Ok: {
    V v_v_241301 = heff_field(v_x1_241300, 0);
    heff_take_n(v_x1_241300, 1ULL, 1);
    switch (heff_tag_of(v_v_241301)) {
    case TAG_VFun: {
      heff_take_n(v_v_241301, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop(v_a_241297);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241301, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop(v_a_241297);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241301, 0ULL, 2);
      heff_drop(v_a_241288);
      heff_drop(v_a_241297);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241306 = heff_field(v_v_241301, 0);
      heff_take_n(v_v_241301, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2ebitsOfIntV(v_a_241288, v_a_241297, v_a_241306));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241301, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop(v_a_241297);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241301, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop(v_a_241297);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241301, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop(v_a_241297);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241301, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop(v_a_241297);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241301, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop(v_a_241297);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241301, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop(v_a_241297);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241301, 0ULL, 2);
      heff_drop(v_a_241288);
      heff_drop(v_a_241297);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241288);
      heff_drop(v_a_241297);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241301);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241288);
    heff_drop(v_a_241297);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241288);
    heff_drop(v_a_241297);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241315 = heff_field(v_x1_241300, 0);
    V v_ru_24x1_241300_24Bug = heff_take_reuse_n(v_x1_241300, 1ULL, 1);
    heff_drop(v_a_241288);
    heff_drop(v_a_241297);
    return heff_tag_at_n(v_ru_24x1_241300_24Bug, TAG_Bug, 1, (V[]){v_what_241315});
  }
  default: return heff_nomatch(v_x1_241300);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args) {
  V v_d_241289 = args[0];
  V v_a_241290 = args[1];
  V v_a_241288 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241291 = heff_tr(heff_call(v_a_241290, 1, (V[]){v_d_241289}));
  switch (heff_tag_of(v_x1_241291)) {
  case TAG_Ok: {
    V v_v_241292 = heff_field(v_x1_241291, 0);
    V v_ru_24x1_241291_24Ok = heff_take_reuse_n(v_x1_241291, 1ULL, 1);
    switch (heff_tag_of(v_v_241292)) {
    case TAG_VFun: {
      heff_take_n(v_v_241292, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop_cell(v_ru_24x1_241291_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241292, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop_cell(v_ru_24x1_241291_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241292, 0ULL, 2);
      heff_drop(v_a_241288);
      heff_drop_cell(v_ru_24x1_241291_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241297 = heff_field(v_v_241292, 0);
      heff_take_n(v_v_241292, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241291_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam89, 2, 2, (V[]){v_a_241288, v_a_241297})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241292, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop_cell(v_ru_24x1_241291_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241292, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop_cell(v_ru_24x1_241291_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241292, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop_cell(v_ru_24x1_241291_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241292, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop_cell(v_ru_24x1_241291_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241292, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop_cell(v_ru_24x1_241291_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241292, 0ULL, 1);
      heff_drop(v_a_241288);
      heff_drop_cell(v_ru_24x1_241291_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241292, 0ULL, 2);
      heff_drop(v_a_241288);
      heff_drop_cell(v_ru_24x1_241291_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241288);
      heff_drop_cell(v_ru_24x1_241291_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241292);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241288);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241288);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241324 = heff_field(v_x1_241291, 0);
    V v_ru_24x1_241291_24Bug = heff_take_reuse_n(v_x1_241291, 1ULL, 1);
    heff_drop(v_a_241288);
    return heff_tag_at_n(v_ru_24x1_241291_24Bug, TAG_Bug, 1, (V[]){v_what_241324});
  }
  default: return heff_nomatch(v_x1_241291);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args) {
  V v_d_241280 = args[0];
  V v_a_241281 = args[1];
  V v_x1_241282 = heff_tr(heff_call(v_a_241281, 1, (V[]){v_d_241280}));
  switch (heff_tag_of(v_x1_241282)) {
  case TAG_Ok: {
    V v_v_241283 = heff_field(v_x1_241282, 0);
    V v_ru_24x1_241282_24Ok = heff_take_reuse_n(v_x1_241282, 1ULL, 1);
    switch (heff_tag_of(v_v_241283)) {
    case TAG_VFun: {
      heff_take_n(v_v_241283, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241282_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241283, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241282_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241283, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241282_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241288 = heff_field(v_v_241283, 0);
      heff_take_n(v_v_241283, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241282_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam88, 2, 1, (V[]){v_a_241288})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241283, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241282_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241283, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241282_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241283, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241282_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241283, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241282_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241283, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241282_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241283, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241282_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241283, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241282_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241282_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241283);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241333 = heff_field(v_x1_241282, 0);
    V v_ru_24x1_241282_24Bug = heff_take_reuse_n(v_x1_241282, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241282_24Bug, TAG_Bug, 1, (V[]){v_what_241333});
  }
  default: return heff_nomatch(v_x1_241282);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args) {
  V v_d_241335 = args[0];
  V v_l_241336 = args[1];
  V v_x1_241337 = heff_tr(heff_call(v_l_241336, 1, (V[]){v_d_241335}));
  switch (heff_tag_of(v_x1_241337)) {
  case TAG_Ok: {
    V v_v_241338 = heff_field(v_x1_241337, 0);
    heff_take_n(v_x1_241337, 1ULL, 1);
    V v_t_241339 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241338, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_241339; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2einterp_2eprim_str97); V r_ = (g_heff_2ecompile_2einterp_2ebitsJoined(a_0, a_1, a_2)); heff_drop(v_t_241339); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241340 = heff_field(v_x1_241337, 0);
    V v_ru_24x1_241337_24Bug = heff_take_reuse_n(v_x1_241337, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241337_24Bug, TAG_Bug, 1, (V[]){v_what_241340});
  }
  default: return heff_nomatch(v_x1_241337);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args) {
  V v_d_241353 = args[0];
  V v_a_241354 = args[1];
  V v_a_241352 = heff_env(self)[0];
  V v_m_241342 = heff_env(self)[1];
  V v_s_241343 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241355 = heff_tr(heff_call(v_a_241354, 1, (V[]){v_d_241353}));
  switch (heff_tag_of(v_x1_241355)) {
  case TAG_Ok: {
    V v_v_241356 = heff_field(v_x1_241355, 0);
    V v_ru_24x1_241355_24Ok = heff_take_reuse_n(v_x1_241355, 1ULL, 1);
    switch (heff_tag_of(v_v_241356)) {
    case TAG_VFun: {
      heff_take_n(v_v_241356, 0ULL, 1);
      heff_drop(v_a_241352);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241356, 0ULL, 1);
      heff_drop(v_a_241352);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241356, 0ULL, 2);
      heff_drop(v_a_241352);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241361 = heff_field(v_v_241356, 0);
      heff_take_n(v_v_241356, 1ULL, 1);
      if (heff_intLt_c(heff_dup(v_a_241352), MK_INT(0LL))) {
        heff_drop(v_a_241352);
        heff_drop(v_m_241342);
        heff_drop(v_s_241343);
        heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
        heff_drop(v_a_241361);
        return NTAG(TAG_Abn);
      } else {
        if (heff_intLt_c(heff_dup(v_a_241361), MK_INT(0LL))) {
          heff_drop(v_a_241352);
          heff_drop(v_m_241342);
          heff_drop(v_s_241343);
          heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
          heff_drop(v_a_241361);
          return NTAG(TAG_Abn);
        } else {
          if (heff_intLt_c(v_m_241342, heff_intAdd(heff_dup(v_a_241352), heff_dup(v_a_241361)))) {
            heff_drop(v_a_241352);
            heff_drop(v_s_241343);
            heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
            heff_drop(v_a_241361);
            return NTAG(TAG_Abn);
          } else {
            V v_t_241365 = (g_heff_2ecompile_2einterp_2ebitsCopy(MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2eprim_str99), v_s_241343, heff_dup(v_a_241352), heff_intAdd(v_a_241352, heff_dup(v_a_241361))));
            return heff_tag_at_n(v_ru_24x1_241355_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_a_241361, v_t_241365})});
          }
        }
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241356, 0ULL, 1);
      heff_drop(v_a_241352);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241356, 0ULL, 1);
      heff_drop(v_a_241352);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241356, 0ULL, 1);
      heff_drop(v_a_241352);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241356, 0ULL, 1);
      heff_drop(v_a_241352);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241356, 0ULL, 1);
      heff_drop(v_a_241352);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241356, 0ULL, 1);
      heff_drop(v_a_241352);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241356, 0ULL, 2);
      heff_drop(v_a_241352);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241352);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241355_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241356);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241352);
    heff_drop(v_m_241342);
    heff_drop(v_s_241343);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241352);
    heff_drop(v_m_241342);
    heff_drop(v_s_241343);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241374 = heff_field(v_x1_241355, 0);
    V v_ru_24x1_241355_24Bug = heff_take_reuse_n(v_x1_241355, 1ULL, 1);
    heff_drop(v_a_241352);
    heff_drop(v_m_241342);
    heff_drop(v_s_241343);
    return heff_tag_at_n(v_ru_24x1_241355_24Bug, TAG_Bug, 1, (V[]){v_what_241374});
  }
  default: return heff_nomatch(v_x1_241355);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args) {
  V v_d_241344 = args[0];
  V v_a_241345 = args[1];
  V v_m_241342 = heff_env(self)[0];
  V v_s_241343 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241346 = heff_tr(heff_call(v_a_241345, 1, (V[]){v_d_241344}));
  switch (heff_tag_of(v_x1_241346)) {
  case TAG_Ok: {
    V v_v_241347 = heff_field(v_x1_241346, 0);
    V v_ru_24x1_241346_24Ok = heff_take_reuse_n(v_x1_241346, 1ULL, 1);
    switch (heff_tag_of(v_v_241347)) {
    case TAG_VFun: {
      heff_take_n(v_v_241347, 0ULL, 1);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241346_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241347, 0ULL, 1);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241346_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241347, 0ULL, 2);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241346_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241352 = heff_field(v_v_241347, 0);
      heff_take_n(v_v_241347, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241346_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam93, 2, 3, (V[]){v_a_241352, v_m_241342, v_s_241343})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241347, 0ULL, 1);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241346_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241347, 0ULL, 1);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241346_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241347, 0ULL, 1);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241346_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241347, 0ULL, 1);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241346_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241347, 0ULL, 1);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241346_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241347, 0ULL, 1);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241346_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241347, 0ULL, 2);
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241346_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_m_241342);
      heff_drop(v_s_241343);
      heff_drop_cell(v_ru_24x1_241346_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241347);
    }
  }
  case TAG_Abn: {
    heff_drop(v_m_241342);
    heff_drop(v_s_241343);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_m_241342);
    heff_drop(v_s_241343);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241383 = heff_field(v_x1_241346, 0);
    V v_ru_24x1_241346_24Bug = heff_take_reuse_n(v_x1_241346, 1ULL, 1);
    heff_drop(v_m_241342);
    heff_drop(v_s_241343);
    return heff_tag_at_n(v_ru_24x1_241346_24Bug, TAG_Bug, 1, (V[]){v_what_241383});
  }
  default: return heff_nomatch(v_x1_241346);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args) {
  V v_m_241342 = args[0];
  V v_s_241343 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam92, 2, 2, (V[]){v_m_241342, v_s_241343})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args) {
  V v_d_241385 = args[0];
  V v_a_241386 = args[1];
  V v_x1_241387 = heff_tr(heff_call(v_a_241386, 1, (V[]){v_d_241385}));
  switch (heff_tag_of(v_x1_241387)) {
  case TAG_Ok: {
    V v_v_241388 = heff_field(v_x1_241387, 0);
    V v_ru_24x1_241387_24Ok = heff_take_reuse_n(v_x1_241387, 1ULL, 1);
    switch (heff_tag_of(v_v_241388)) {
    case TAG_VFun: {
      heff_take_n(v_v_241388, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241388, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241388, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241388, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241388, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241388, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241388, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241388, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241388, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241399 = heff_field(v_v_241388, 0);
      heff_take_n(v_v_241388, 1ULL, 1);
      V v_t_241400 = heff_intMul(heff_strLength_lent(v_a_241399, 0), MK_INT(8LL));
      return heff_tag_at_n(v_ru_24x1_241387_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_t_241400, v_a_241399})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241388, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241388);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241403 = heff_field(v_x1_241387, 0);
    V v_ru_24x1_241387_24Bug = heff_take_reuse_n(v_x1_241387, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241387_24Bug, TAG_Bug, 1, (V[]){v_what_241403});
  }
  default: return heff_nomatch(v_x1_241387);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args) {
  V v_n_241405 = args[0];
  V v_s_241406 = args[1];
  if (heff_intEq_c(heff_intMod(v_n_241405, MK_INT(8LL)), MK_INT(0LL))) {
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_s_241406})});
  } else {
    heff_drop(v_s_241406);
    return NTAG(TAG_Abn);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args) {
  V v_m_241411 = args[0];
  V v_t_241412 = args[1];
  V v_n_241409 = heff_env(self)[0];
  V v_s_241410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_241415;
  if (heff_intEq_c(v_n_241409, v_m_241411)) {
    if (heff_strEq_c(v_s_241410, v_t_241412)) {
      v_t_241415 = ((V)&g_heff_2ecompile_2einterp_2eprim_str103);
    } else {
      v_t_241415 = ((V)&g_heff_2ecompile_2einterp_2eprim_str104);
    }
  } else {
    heff_drop(v_t_241412);
    heff_drop(v_s_241410);
    v_t_241415 = ((V)&g_heff_2ecompile_2einterp_2eprim_str105);
  }
  V v_t_241416 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241415, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241416});
}
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args) {
  V v_n_241409 = args[0];
  V v_s_241410 = args[1];
  V v_t_241417 = (g_heff_2ecompile_2einterp_2ebits1(heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam97, 2, 2, (V[]){v_n_241409, v_s_241410})));
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241417});
}
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args) {
  V v_d_241428 = args[0];
  V v_a_241429 = args[1];
  V v_a_241427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241430 = heff_tr(heff_call(v_a_241429, 1, (V[]){v_d_241428}));
  switch (heff_tag_of(v_x1_241430)) {
  case TAG_Ok: {
    V v_v_241431 = heff_field(v_x1_241430, 0);
    V v_ru_24x1_241430_24Ok = heff_take_reuse_n(v_x1_241430, 1ULL, 1);
    switch (heff_tag_of(v_v_241431)) {
    case TAG_VFun: {
      heff_take_n(v_v_241431, 0ULL, 1);
      heff_drop(v_a_241427);
      heff_drop_cell(v_ru_24x1_241430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241431, 0ULL, 1);
      heff_drop(v_a_241427);
      heff_drop_cell(v_ru_24x1_241430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241431, 0ULL, 2);
      heff_drop(v_a_241427);
      heff_drop_cell(v_ru_24x1_241430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241431, 0ULL, 1);
      heff_drop(v_a_241427);
      heff_drop_cell(v_ru_24x1_241430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_241437 = heff_tflat_f64(v_v_241431, 0);
      heff_take_na(v_v_241431, 0ULL, 1);
      if (heff_intEq_c(heff_dup(v_a_241427), MK_INT(64LL))) {
        heff_drop(v_a_241427);
        V v_t_241439 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(11LL), MK_INT(52LL), v_a_241437));
        return heff_tag_at_n(v_ru_24x1_241430_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_241439})});
      } else {
        if (heff_intEq_c(v_a_241427, MK_INT(32LL))) {
          double v_t_241441 = ((double)((float)v_a_241437));
          V v_t_241442 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(8LL), MK_INT(23LL), v_t_241441));
          return heff_tag_at_n(v_ru_24x1_241430_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_241442})});
        } else {
          heff_drop_cell(v_ru_24x1_241430_24Ok, 1);
          return NTAG(TAG_Abn);
        }
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241431, 0ULL, 1);
      heff_drop(v_a_241427);
      heff_drop_cell(v_ru_24x1_241430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241431, 0ULL, 1);
      heff_drop(v_a_241427);
      heff_drop_cell(v_ru_24x1_241430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241431, 0ULL, 1);
      heff_drop(v_a_241427);
      heff_drop_cell(v_ru_24x1_241430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241431, 0ULL, 1);
      heff_drop(v_a_241427);
      heff_drop_cell(v_ru_24x1_241430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241431, 0ULL, 1);
      heff_drop(v_a_241427);
      heff_drop_cell(v_ru_24x1_241430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241431, 0ULL, 2);
      heff_drop(v_a_241427);
      heff_drop_cell(v_ru_24x1_241430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241427);
      heff_drop_cell(v_ru_24x1_241430_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_241431);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241427);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241427);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241450 = heff_field(v_x1_241430, 0);
    V v_ru_24x1_241430_24Bug = heff_take_reuse_n(v_x1_241430, 1ULL, 1);
    heff_drop(v_a_241427);
    return heff_tag_at_n(v_ru_24x1_241430_24Bug, TAG_Bug, 1, (V[]){v_what_241450});
  }
  default: return heff_nomatch(v_x1_241430);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args) {
  V v_d_241419 = args[0];
  V v_a_241420 = args[1];
  V v_x1_241421 = heff_tr(heff_call(v_a_241420, 1, (V[]){v_d_241419}));
  switch (heff_tag_of(v_x1_241421)) {
  case TAG_Ok: {
    V v_v_241422 = heff_field(v_x1_241421, 0);
    V v_ru_24x1_241421_24Ok = heff_take_reuse_n(v_x1_241421, 1ULL, 1);
    switch (heff_tag_of(v_v_241422)) {
    case TAG_VFun: {
      heff_take_n(v_v_241422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241422, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241427 = heff_field(v_v_241422, 0);
      heff_take_n(v_v_241422, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241421_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam99, 2, 1, (V[]){v_a_241427})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241422, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241422);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241459 = heff_field(v_x1_241421, 0);
    V v_ru_24x1_241421_24Bug = heff_take_reuse_n(v_x1_241421, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241421_24Bug, TAG_Bug, 1, (V[]){v_what_241459});
  }
  default: return heff_nomatch(v_x1_241421);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args) {
  V v_d_241470 = args[0];
  V v_a_241471 = args[1];
  V v_a_241469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241472 = heff_tr(heff_call(v_a_241471, 1, (V[]){v_d_241470}));
  switch (heff_tag_of(v_x1_241472)) {
  case TAG_Ok: {
    V v_v_241473 = heff_field(v_x1_241472, 0);
    heff_take_n(v_x1_241472, 1ULL, 1);
    switch (heff_tag_of(v_v_241473)) {
    case TAG_VFun: {
      heff_take_n(v_v_241473, 0ULL, 1);
      heff_drop(v_a_241469);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241473, 0ULL, 1);
      heff_drop(v_a_241469);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241473, 0ULL, 2);
      heff_drop(v_a_241469);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241478 = heff_field(v_v_241473, 0);
      heff_take_n(v_v_241473, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2efloatOfBitsV(v_a_241469, v_a_241478));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241473, 0ULL, 1);
      heff_drop(v_a_241469);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241473, 0ULL, 1);
      heff_drop(v_a_241469);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241473, 0ULL, 1);
      heff_drop(v_a_241469);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241473, 0ULL, 1);
      heff_drop(v_a_241469);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241473, 0ULL, 1);
      heff_drop(v_a_241469);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241473, 0ULL, 1);
      heff_drop(v_a_241469);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241473, 0ULL, 2);
      heff_drop(v_a_241469);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241469);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241473);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241469);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241469);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241487 = heff_field(v_x1_241472, 0);
    V v_ru_24x1_241472_24Bug = heff_take_reuse_n(v_x1_241472, 1ULL, 1);
    heff_drop(v_a_241469);
    return heff_tag_at_n(v_ru_24x1_241472_24Bug, TAG_Bug, 1, (V[]){v_what_241487});
  }
  default: return heff_nomatch(v_x1_241472);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args) {
  V v_d_241461 = args[0];
  V v_a_241462 = args[1];
  V v_x1_241463 = heff_tr(heff_call(v_a_241462, 1, (V[]){v_d_241461}));
  switch (heff_tag_of(v_x1_241463)) {
  case TAG_Ok: {
    V v_v_241464 = heff_field(v_x1_241463, 0);
    V v_ru_24x1_241463_24Ok = heff_take_reuse_n(v_x1_241463, 1ULL, 1);
    switch (heff_tag_of(v_v_241464)) {
    case TAG_VFun: {
      heff_take_n(v_v_241464, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241463_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241464, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241463_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241464, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241463_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241469 = heff_field(v_v_241464, 0);
      heff_take_n(v_v_241464, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241463_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam101, 2, 1, (V[]){v_a_241469})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241464, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241463_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241464, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241463_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241464, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241463_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241464, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241463_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241464, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241463_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241464, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241463_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241464, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241463_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241463_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241464);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241496 = heff_field(v_x1_241463, 0);
    V v_ru_24x1_241463_24Bug = heff_take_reuse_n(v_x1_241463, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241463_24Bug, TAG_Bug, 1, (V[]){v_what_241496});
  }
  default: return heff_nomatch(v_x1_241463);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args) {
  V v_a_241498 = args[0];
  V v_b_241499 = args[1];
  V v_t_241501;
  if (heff_intEq_c(v_a_241498, v_b_241499)) {
    v_t_241501 = ((V)&g_heff_2ecompile_2einterp_2eprim_str109);
  } else {
    v_t_241501 = ((V)&g_heff_2ecompile_2einterp_2eprim_str110);
  }
  V v_t_241502 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241501, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241502});
}
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args) {
  V v_a_241504 = args[0];
  V v_b_241505 = args[1];
  V v_t_241507;
  if (heff_intLt_c(v_a_241504, v_b_241505)) {
    v_t_241507 = ((V)&g_heff_2ecompile_2einterp_2eprim_str112);
  } else {
    v_t_241507 = ((V)&g_heff_2ecompile_2einterp_2eprim_str113);
  }
  V v_t_241508 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241507, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241508});
}
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args) {
  V v_a_241510 = args[0];
  V v_b_241511 = args[1];
  V v_t_241513;
  if (heff_intLe_c(v_a_241510, v_b_241511)) {
    v_t_241513 = ((V)&g_heff_2ecompile_2einterp_2eprim_str115);
  } else {
    v_t_241513 = ((V)&g_heff_2ecompile_2einterp_2eprim_str116);
  }
  V v_t_241514 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241513, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241514});
}
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args) {
  V v_d_241516 = args[0];
  V v_a_241517 = args[1];
  V v_x1_241518 = heff_tr(heff_call(v_a_241517, 1, (V[]){v_d_241516}));
  switch (heff_tag_of(v_x1_241518)) {
  case TAG_Ok: {
    V v_v_241519 = heff_field(v_x1_241518, 0);
    V v_ru_24x1_241518_24Ok = heff_take_reuse_n(v_x1_241518, 1ULL, 1);
    switch (heff_tag_of(v_v_241519)) {
    case TAG_VFun: {
      heff_take_n(v_v_241519, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241518_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241519, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241518_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241519, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241518_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241519, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241518_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241519, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241518_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241519, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241518_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241519, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241518_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VRune: {
      V v_a_241528 = heff_field(v_v_241519, 0);
      heff_take_n(v_v_241519, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241518_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_241528})});
    }
    case TAG_VArr: {
      heff_take_n(v_v_241519, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241518_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241519, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241518_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241519, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241518_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241518_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    default: return heff_nomatch(v_v_241519);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241533 = heff_field(v_x1_241518, 0);
    V v_ru_24x1_241518_24Bug = heff_take_reuse_n(v_x1_241518, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241518_24Bug, TAG_Bug, 1, (V[]){v_what_241533});
  }
  default: return heff_nomatch(v_x1_241518);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args) {
  V v_d_241535 = args[0];
  V v_a_241536 = args[1];
  V v_x1_241537 = heff_tr(heff_call(v_a_241536, 1, (V[]){v_d_241535}));
  switch (heff_tag_of(v_x1_241537)) {
  case TAG_Ok: {
    V v_v_241538 = heff_field(v_x1_241537, 0);
    V v_ru_24x1_241537_24Ok = heff_take_reuse_n(v_x1_241537, 1ULL, 1);
    switch (heff_tag_of(v_v_241538)) {
    case TAG_VFun: {
      heff_take_n(v_v_241538, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241537_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241538, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241537_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241538, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241537_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241543 = heff_field(v_v_241538, 0);
      heff_take_n(v_v_241538, 1ULL, 1);
      V v_t_241544 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_241545 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_241546 = heff_intSub(v_a_241543, heff_intSub(MK_INT(0LL), v_t_241545));
      V v_t_241547 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(32LL)));
      V v_t_241548 = heff_intAdd(heff_intSub(MK_INT(0LL), v_t_241544), heff_intMod(v_t_241546, v_t_241547));
      return heff_tag_at_n(v_ru_24x1_241537_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VRune, 1, (V[]){v_t_241548})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241538, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241537_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241538, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241537_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241538, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241537_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241538, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241537_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241538, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241537_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241538, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241537_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241538, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241537_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241537_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241538);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241557 = heff_field(v_x1_241537, 0);
    V v_ru_24x1_241537_24Bug = heff_take_reuse_n(v_x1_241537, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241537_24Bug, TAG_Bug, 1, (V[]){v_what_241557});
  }
  default: return heff_nomatch(v_x1_241537);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args) {
  V v_d_241559 = args[0];
  V v_a_241560 = args[1];
  V v_x1_241561 = heff_tr(heff_call(v_a_241560, 1, (V[]){v_d_241559}));
  switch (heff_tag_of(v_x1_241561)) {
  case TAG_Ok: {
    V v_v_241562 = heff_field(v_x1_241561, 0);
    V v_ru_24x1_241561_24Ok = heff_take_reuse_n(v_x1_241561, 1ULL, 1);
    switch (heff_tag_of(v_v_241562)) {
    case TAG_VFun: {
      heff_take_n(v_v_241562, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241561_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241562, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241561_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241562, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241561_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241562, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241561_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241562, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241561_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241562, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241561_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241570 = heff_field(v_v_241562, 0);
      heff_take_n(v_v_241562, 1ULL, 1);
      V v_t_241571 = (g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(heff_strRunes(v_a_241570)));
      return heff_tag_at_n(v_ru_24x1_241561_24Ok, TAG_Ok, 1, (V[]){v_t_241571});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241562, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241561_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241562, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241561_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241562, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241561_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241562, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241561_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241561_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241562);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241577 = heff_field(v_x1_241561, 0);
    V v_ru_24x1_241561_24Bug = heff_take_reuse_n(v_x1_241561, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241561_24Bug, TAG_Bug, 1, (V[]){v_what_241577});
  }
  default: return heff_nomatch(v_x1_241561);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args) {
  V v_d_241579 = args[0];
  V v_l_241580 = args[1];
  V v_x1_241581 = heff_tr(heff_call(v_l_241580, 1, (V[]){v_d_241579}));
  switch (heff_tag_of(v_x1_241581)) {
  case TAG_Ok: {
    V v_v_241582 = heff_field(v_x1_241581, 0);
    V v_ru_24x1_241581_24Ok = heff_take_reuse_n(v_x1_241581, 1ULL, 1);
    V v_t_241583 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241582, NTAG(TAG_Nil)));
    V v_t_241584 = (g_heff_2ecompile_2einterp_2eruneCodes(v_t_241583));
    V v_t_241585 = (g_list_2emap(heff_dup(g_rune_2efromInt_get()), v_t_241584));
    V v_t_241586 = heff_tag_n(TAG_VStr, 1, (V[]){heff_strOfRunes(v_t_241585)});
    return heff_tag_at_n(v_ru_24x1_241581_24Ok, TAG_Ok, 1, (V[]){v_t_241586});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241587 = heff_field(v_x1_241581, 0);
    V v_ru_24x1_241581_24Bug = heff_take_reuse_n(v_x1_241581, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241581_24Bug, TAG_Bug, 1, (V[]){v_what_241587});
  }
  default: return heff_nomatch(v_x1_241581);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args) {
  V v_d_241589 = args[0];
  V v_a_241590 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241589);
  heff_drop(v_a_241590);
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprim_str121), v_p_240)});
}
Clo g_heff_2ecompile_2einterp_2enthTh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2enthTh_entry, 2, 0};

V g_heff_2ecompile_2einterp_2enthTh(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2enthTh_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2enthTh(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str0, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str3, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str6, 2, "{ ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str7, 2, " }");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str8, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str12, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str13, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str17, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str18, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str19, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str20, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str21, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str22, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str23, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str24, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str25, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str26, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str27, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str28, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str29, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str30, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str31, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str32, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str33, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str34, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str35, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str36, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str37, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str38, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str39, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str40, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str41, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str42, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str43, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str44, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str45, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str46, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str47, 1, ")");
Clo g_heff_2ecompile_2einterp_2eshowValGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eshowValGo_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eshowValGo(V v_inArg_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VFun: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_243 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_243, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str0))) {
        V v_t_245 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str1), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str2)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VCons: {
    V v_fs_246 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_t_247 = heff_arrayToList(heff_take_field(v_fs_246, 0));
    V v_t_248 = heff_arrayToList(heff_get_n(v_fs_246, 2, 3));
    V v_t_249 = (g_heff_2eutil_2edict_2ezipKV(v_t_247, v_t_248));
    V v_x2_2410 = (g_list_2emap_24s1427000880x1925304966(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str3), v_t_249));
    V v_t_2413;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_xs_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str5); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str7)));
  }
  case TAG_VTag: {
    V v_x_2414 = heff_field(v_v_241, 0);
    V v_vs_2415 = heff_field(v_v_241, 1);
    V v_ru_24v_241_24VTag = heff_take_reuse_n(v_v_241, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2einterp_2elistValsGo(heff_tag_at_n(v_ru_24v_241_24VTag, TAG_VTag, 2, (V[]){heff_dup(v_x_2414), heff_dup(v_vs_2415)}), NTAG(TAG_Nil)));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_vs_2415)) {
      case TAG_Nil: {
        return v_x_2414;
      }
      case TAG_Cons: {
        if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
          V v_x2_2419 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str8), v_vs_2415));
          V v_t_2422;
          switch (heff_tag_of(v_x2_2419)) {
          case TAG_Nil: {
            v_t_2422 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str9);
            break;
          }
          case TAG_Cons: {
            V v_x_2420 = heff_field(v_x2_2419, 0);
            V v_xs_2421 = heff_field(v_x2_2419, 1);
            heff_take_n(v_x2_2419, 3ULL, 2);
            v_t_2422 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str10); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2419);
          }
          V v_t_2423 = heff_strAppend(v_x_2414, heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str11)));
          return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str12), v_t_2423);
        } else {
          V v_x2_2424 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str13), v_vs_2415));
          V v_t_2427;
          switch (heff_tag_of(v_x2_2424)) {
          case TAG_Nil: {
            v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str14);
            break;
          }
          case TAG_Cons: {
            V v_x_2425 = heff_field(v_x2_2424, 0);
            V v_xs_2426 = heff_field(v_x2_2424, 1);
            heff_take_n(v_x2_2424, 3ULL, 2);
            v_t_2427 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str15); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2424);
          }
          return heff_strAppend(v_x_2414, v_t_2427);
        }
      }
      default: return heff_nomatch(v_vs_2415);
      }
    }
    case TAG_Just: {
      V v_items_2428 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      heff_drop(v_x_2414);
      heff_drop(v_vs_2415);
      V v_x2_2429 = (g_list_2emap_24s391931963x434308123(v_items_2428));
      V v_t_2432;
      switch (heff_tag_of(v_x2_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str16);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_x2_2429, 0);
        V v_xs_2431 = heff_field(v_x2_2429, 1);
        heff_take_n(v_x2_2429, 3ULL, 2);
        v_t_2432 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str17); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2429);
      }
      return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str18), heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str19)));
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  case TAG_VInt: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2434 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2434, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str20))) {
        V v_t_2436 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str21), heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str22)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VFloat: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2438 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2438, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str23))) {
        V v_t_2440 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str24), heff_strAppend(v_t_2440, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str25)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VFloat32: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2442 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2442, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str26))) {
        V v_t_2444 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str27), heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str28)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VStr: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2446 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2446, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str29))) {
        V v_t_2448 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str30), heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str31)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VRune: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2450 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2450, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str32))) {
        V v_t_2452 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str33), heff_strAppend(v_t_2452, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str34)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VArr: {
    V v_xs_2453 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_x2_2454 = (g_list_2emap_24s391931963x434308123(heff_arrayToList(v_xs_2453)));
    V v_t_2457;
    switch (heff_tag_of(v_x2_2454)) {
    case TAG_Nil: {
      v_t_2457 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2455 = heff_field(v_x2_2454, 0);
      V v_xs_2456 = heff_field(v_x2_2454, 1);
      heff_take_n(v_x2_2454, 3ULL, 2);
      v_t_2457 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str36); V a_1 = v_x_2455; V a_2 = v_xs_2456; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2456); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2454);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str37), heff_strAppend(v_t_2457, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str38)));
  }
  case TAG_VBytes: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2459 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2459, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str39))) {
        V v_t_2461 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str40), heff_strAppend(v_t_2461, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str41)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VBits: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2464 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2464, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str42))) {
        V v_t_2466 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str43), heff_strAppend(v_t_2466, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str44)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
    }
  }
  case TAG_VErased: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2467 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2467, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str45))) {
        V v_t_2469 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str46), heff_strAppend(v_t_2469, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str47)));
      } else {
        return (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      }
    } else {
      return (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2eshowValGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_lam0, 1, 0};
Clo g_heff_2ecompile_2einterp_2eapplyErased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eapplyErased(V v_n_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_r_241)) {
  case TAG_RSucceeded: {
    V v_r1_242 = heff_dup(heff_field(v_r_241, 0));
    switch (heff_tag_of(v_r1_242)) {
    case TAG_VFun: {
      V v_f_243 = heff_field(v_r1_242, 0);
      V v_ru_24r1_242_24VFun = heff_take_reuse_n(v_r1_242, 1ULL, 1);
      heff_drop_tag(v_r_241, 1);
      if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
        heff_drop(v_n_240);
        return heff_tag_n(TAG_RSucceeded, 1, (V[]){heff_tag_at_n(v_ru_24r1_242_24VFun, TAG_VFun, 1, (V[]){v_f_243})});
      } else {
        heff_drop_cell(v_ru_24r1_242_24VFun, 1);
        V v_x1_246 = heff_tr(heff_call(v_f_243, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo)}));
        V v_t_249;
        switch (heff_tag_of(v_x1_246)) {
        case TAG_Ok: {
          V v_v_247 = heff_field(v_x1_246, 0);
          V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
          v_t_249 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_RSucceeded, 1, (V[]){v_v_247});
          break;
        }
        case TAG_Abn: {
          v_t_249 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          v_t_249 = NTAG(TAG_RDiverged);
          break;
        }
        case TAG_Bug: {
          V v_what_248 = heff_field(v_x1_246, 0);
          V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
          v_t_249 = heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_RBug, 1, (V[]){v_what_248});
          break;
        }
        default: heff_nomatch(v_x1_246);
        }
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_t_249;
        v_n_240 = t_0;
        v_r_241 = t_1;
        goto top;
      }
    }
    case TAG_VCons: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VTag: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VInt: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat: {
      heff_take_na(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat32: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VStr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VRune: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VArr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBytes: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBits: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VErased: {
      heff_drop(v_n_240);
      return v_r_241;
    }
    default: return heff_nomatch(v_r1_242);
    }
  }
  case TAG_RAbandoned: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RDiverged: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RBug: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  default: return heff_nomatch(v_r_241);
  }
}
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eapplyErased(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args) {
  V v_d_245 = args[0];
  heff_drop(v_d_245);
  return heff_tag_n(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
}