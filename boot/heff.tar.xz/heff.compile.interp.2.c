// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_Ok 9325
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_keys 9783995
#define LBL_values 1123329101
V g_heff_2ecompile_2einterp_2eapplyErased(V, V);
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eapplyErased_clo;
V g_heff_2ecompile_2einterp_2ebits1(V);
V g_heff_2ecompile_2einterp_2ebits1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebits1_clo;
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void);
V g_heff_2ecompile_2einterp_2ebitsCopy(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsCopy_clo;
V g_heff_2ecompile_2einterp_2ebitsJoined(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsJoined_clo;
V g_heff_2ecompile_2einterp_2ebitsOfIntV(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsOfIntV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsOfIntV_clo;
V g_heff_2ecompile_2einterp_2ebyteString(V, V);
V g_heff_2ecompile_2einterp_2ebyteString_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebyteString_clo;
V g_heff_2ecompile_2einterp_2ebytes2(V);
V g_heff_2ecompile_2einterp_2ebytes2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytes2_clo;
V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get(void);
V g_heff_2ecompile_2einterp_2ebytesJoined(V, V);
V g_heff_2ecompile_2einterp_2ebytesJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesJoined_clo;
V g_heff_2ecompile_2einterp_2ebytesOfIntV(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfIntV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfIntV_clo;
V g_heff_2ecompile_2einterp_2ebytesOfNat(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfNat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfNat_clo;
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void);
V g_heff_2ecompile_2einterp_2efixedPrimV(V);
V g_heff_2ecompile_2einterp_2efixedPrimV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedPrimV_clo;
V g_heff_2ecompile_2einterp_2efloat2(V);
V g_heff_2ecompile_2einterp_2efloat2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloat2_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get(void);
V g_heff_2ecompile_2einterp_2efloatOfBitsV(V, V);
V g_heff_2ecompile_2einterp_2efloatOfBitsV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloatOfBitsV_clo;
V g_heff_2ecompile_2einterp_2efloatTake2(V, V, V);
V g_heff_2ecompile_2einterp_2efloatTake2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloatTake2_clo;
V g_heff_2ecompile_2einterp_2efmix64(V);
V g_heff_2ecompile_2einterp_2efmix64_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efmix64_clo;
V g_heff_2ecompile_2einterp_2efromListV(V, V);
V g_heff_2ecompile_2einterp_2efromListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efromListV_clo;
V g_heff_2ecompile_2einterp_2egenGo(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2egenGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2egenGo_clo;
V g_heff_2ecompile_2einterp_2ehashFrom(V, V, V);
V g_heff_2ecompile_2einterp_2ehashFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ehashFrom_clo;
V g_heff_2ecompile_2einterp_2eieeeBits_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeBits(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeBits_clo;
V g_heff_2ecompile_2einterp_2eieeeMagnitude_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeMagnitude(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeMagnitude_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeMagnitude_clo;
double g_heff_2ecompile_2einterp_2eieeeOf_w(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeOf_clo;
V g_heff_2ecompile_2einterp_2eint2(V);
V g_heff_2ecompile_2einterp_2eint2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eint2_clo;
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void);
V g_heff_2ecompile_2einterp_2eintAtV(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintAtV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintAtV_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_clo;
V g_heff_2ecompile_2einterp_2elistValsGo(V, V);
V g_heff_2ecompile_2einterp_2elistValsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elistValsGo_clo;
V g_heff_2ecompile_2einterp_2elittleOut(V, V);
V g_heff_2ecompile_2einterp_2elittleOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elittleOut_clo;
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotARune_get(void);
V g_heff_2ecompile_2einterp_2enotAString_get(void);
V g_heff_2ecompile_2einterp_2enotAnArray_get(void);
V g_heff_2ecompile_2einterp_2enotAnInt_get(void);
V g_heff_2ecompile_2einterp_2enotBytes_get(void);
V g_heff_2ecompile_2einterp_2enthTh(V, V);
V g_heff_2ecompile_2einterp_2enthTh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2enthTh_clo;
V g_heff_2ecompile_2einterp_2enthV(V, V);
V g_heff_2ecompile_2einterp_2enthV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2enthV_clo;
V g_heff_2ecompile_2einterp_2eprim(V);
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eprim_clo;
V g_heff_2ecompile_2einterp_2erune2(V);
V g_heff_2ecompile_2einterp_2erune2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2erune2_clo;
V g_heff_2ecompile_2einterp_2eruneCodes(V);
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_clo;
V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V, V);
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo;
V g_heff_2ecompile_2einterp_2escalarV(V);
V g_heff_2ecompile_2einterp_2escalarV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2escalarV_clo;
V g_heff_2ecompile_2einterp_2esetAt(V, V, V);
V g_heff_2ecompile_2einterp_2esetAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esetAt_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2einterp_2esliceV(V, V, V);
V g_heff_2ecompile_2einterp_2esliceV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esliceV_clo;
V g_heff_2ecompile_2einterp_2estr2(V);
V g_heff_2ecompile_2einterp_2estr2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2estr2_clo;
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get(void);
V g_heff_2ecompile_2einterp_2etoListV(V);
V g_heff_2ecompile_2einterp_2etoListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(V, V, V);
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(V);
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_clo;
V g_heff_2ecompile_2einterp_2etrieSlotOf(V, V, V);
V g_heff_2ecompile_2einterp_2etrieSlotOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etrieSlotOf_clo;
V g_heff_2ecompile_2einterp_2etwoTo(V);
V g_heff_2ecompile_2einterp_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoTo_clo;
V g_heff_2ecompile_2einterp_2eword64_get(void);
V g_heff_2ecompile_2einterp_2ewordOf(V, V, V);
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ewordOf_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1427000880x1925304966(V, V);
V g_list_2emap_24s1427000880x1925304966_entry(V self, V *a);
extern Clo g_list_2emap_24s1427000880x1925304966_clo;
V g_list_2emap_24s391931963x434308123(V);
V g_list_2emap_24s391931963x434308123_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_clo;
V g_list_2emap_24s503834852x510769098(V, V);
V g_list_2emap_24s503834852x510769098_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_rune_2evalidFrom(V, V);
V g_rune_2evalidFrom_entry(V self, V *a);
extern Clo g_rune_2evalidFrom_clo;
V g_runeFromInt_get(void);
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAnInt_str0, 38, "a primitive given what is not an `Int`");

static V g_heff_2ecompile_2einterp_2enotAnInt_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAnInt_st;
static V g_heff_2ecompile_2einterp_2enotAnInt_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAnInt_str0)});
}
V g_heff_2ecompile_2einterp_2enotAnInt_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAnInt_st)) return g_heff_2ecompile_2einterp_2enotAnInt_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAnInt_val, &g_heff_2ecompile_2einterp_2enotAnInt_st, g_heff_2ecompile_2einterp_2enotAnInt_init);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAFloat64_str0, 41, "a primitive given what is not a `Float64`");

static V g_heff_2ecompile_2einterp_2enotAFloat64_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAFloat64_st;
static V g_heff_2ecompile_2einterp_2enotAFloat64_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAFloat64_str0)});
}
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAFloat64_st)) return g_heff_2ecompile_2einterp_2enotAFloat64_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAFloat64_val, &g_heff_2ecompile_2einterp_2enotAFloat64_st, g_heff_2ecompile_2einterp_2enotAFloat64_init);
}
Clo g_heff_2ecompile_2einterp_2efloatTake2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloatTake2_entry, 3, 0};

V g_heff_2ecompile_2einterp_2efloatTake2(V v_f_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_VFun: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VCons: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VTag: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VInt: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VFloat: {
    V v_a_248 = heff_tget_v(v_x2_241, 0);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_VFun: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      V v_b_2414 = heff_tget_v(v_x3_242, 0);
      return heff_tail(v_f_240, 2, (V[]){v_a_248, v_b_2414});
    }
    case TAG_VFloat32: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_VFloat32: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VStr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VRune: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VArr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VBytes: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VBits: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VErased: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2efloatTake2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2einterp_2efloatTake2(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2einterp_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ewordOf_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ewordOf(V v_n_240, V v_f_241, V v_v_242) {
top: ;
  if (heff_intEq_c(heff_intMod(v_f_241, MK_INT(2LL)), MK_INT(1LL))) {
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_245 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_246 = heff_intAdd(heff_intMod(v_v_242, v_t_244), v_t_245);
    V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    return (g_heff_2ecompile_2einterp_2elittleOut(heff_intMod(v_t_246, v_t_247), v_n_240));
  } else {
    V v_t_248 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_2410 = heff_intAdd(heff_intMod(v_v_242, v_t_248), v_t_249);
    V v_t_2411 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_240));
    return heff_intMod(v_t_2410, v_t_2411);
  }
}
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ewordOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsOfIntV_str0, 0, "");
Clo g_heff_2ecompile_2einterp_2ebitsOfIntV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsOfIntV_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ebitsOfIntV(V v_n_240, V v_f_241, V v_v_242) {
top: ;
  if (heff_intLt_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_f_241);
    heff_drop(v_v_242);
    return NTAG(TAG_Abn);
  } else {
    if (heff_intLt_c(MK_INT(64LL), heff_dup(v_n_240))) {
      heff_drop(v_n_240);
      heff_drop(v_f_241);
      heff_drop(v_v_242);
      return NTAG(TAG_Abn);
    } else {
      V v_w_245 = (g_heff_2ecompile_2einterp_2ewordOf(heff_dup(v_n_240), v_f_241, v_v_242));
      V v_t_246 = heff_intDiv(heff_intAdd(heff_dup(v_n_240), MK_INT(7LL)), MK_INT(8LL));
      V v_t_247 = heff_intDiv(heff_intAdd(heff_dup(v_n_240), MK_INT(7LL)), MK_INT(8LL));
      V v_t_248 = heff_intSub(heff_intMul(v_t_247, MK_INT(8LL)), heff_dup(v_n_240));
      V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(v_t_248));
      V v_t_2410 = (g_heff_2ecompile_2einterp_2ebytesOfNat(v_t_246, heff_intMul(v_w_245, v_t_249), ((V)&g_heff_2ecompile_2einterp_2ebitsOfIntV_str0)));
      return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_n_240, v_t_2410})});
    }
  }
}
V g_heff_2ecompile_2einterp_2ebitsOfIntV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitsOfIntV(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2eieeeBits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eieeeBits_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eieeeBits_w(V v_eb_240, V v_fb_241, double v_x_242) {
top: ;
  V v_t_244 = heff_bool(!(v_x_242 == v_x_242));
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    V v_t_245 = (g_heff_2ecompile_2einterp_2etwoTo(v_eb_240));
    V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_fb_241)));
    V v_t_247 = heff_intMul(heff_intSub(v_t_245, MK_INT(1LL)), v_t_246);
    V v_t_248 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intSub(v_fb_241, MK_INT(1LL))));
    return heff_intAdd(v_t_247, v_t_248);
  } else {
    heff_drop(v_t_244);
    if ((v_x_242 < (0.0))) {
      V v_t_2410 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intAdd(heff_dup(v_eb_240), heff_dup(v_fb_241))));
      V v_t_2411 = (g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, ((0.0) - v_x_242)));
      return heff_intAdd(v_t_2410, v_t_2411);
    } else {
      if ((v_x_242 == (0.0))) {
        if ((((1.0) / v_x_242) < (0.0))) {
          V v_t_2414 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intAdd(heff_dup(v_eb_240), heff_dup(v_fb_241))));
          V v_t_2415 = (g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, ((0.0) - v_x_242)));
          return heff_intAdd(v_t_2414, v_t_2415);
        } else {
          HEFF_LAST return g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, v_x_242);
        }
      } else {
        HEFF_LAST return g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, v_x_242);
      }
    }
  }
}
V g_heff_2ecompile_2einterp_2eieeeBits(V v_eb_240, V v_fb_241, V v_box_24x_242) {
  double v_x_242 = heff_unbox_f64(v_box_24x_242);
  return (g_heff_2ecompile_2einterp_2eieeeBits_w(v_eb_240, v_fb_241, v_x_242));
}
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eieeeBits(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2efloatOfBitsV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloatOfBitsV_entry, 2, 0};

V g_heff_2ecompile_2einterp_2efloatOfBitsV(V v_n_240, V v_u_241) {
top: ;
  if (heff_intEq_c(heff_dup(v_n_240), MK_INT(64LL))) {
    heff_drop(v_n_240);
    V v_t_243 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    V v_t_245 = heff_intAdd(heff_intMod(v_u_241, v_t_243), v_t_244);
    V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    double v_t_247 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(11LL), MK_INT(52LL), heff_intMod(v_t_245, v_t_246)));
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_nf(TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_247)})});
  } else {
    if (heff_intEq_c(v_n_240, MK_INT(32LL))) {
      V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      V v_t_2410 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      V v_t_2411 = heff_intAdd(heff_intMod(v_u_241, v_t_249), v_t_2410);
      V v_t_2412 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      double v_t_2413 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(8LL), MK_INT(23LL), heff_intMod(v_t_2411, v_t_2412)));
      return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_nf(TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_2413)})});
    } else {
      heff_drop(v_u_241);
      return NTAG(TAG_Abn);
    }
  }
}
V g_heff_2ecompile_2einterp_2efloatOfBitsV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efloatOfBitsV(a[0], a[1]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eruneCodes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_VFun: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2411 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2411, heff_hole()});
      V v_u_2413 = (g_heff_2ecompile_2einterp_2eruneCodes_24dps(v_rest_242, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eruneCodes(a[0]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_VFun: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2412 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2412, heff_hole()});
      V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2413;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eruneCodes_24dps(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st;
static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st)) return g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val, &g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)(heff_unbox_f32(v_a_2414) / heff_unbox_f32(v_b_2421))))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st;
static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st)) return g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
  return heff_global(&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val, &g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init);
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = (g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(v_a_2412, v_b_2417));
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2418})});
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1, 2, 1, (V[]){v_a_241})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10, 36, "a primitive given what is not `Bits`");
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st;
static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st)) return g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val, &g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init);
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  V v_x1_242 = heff_tr(heff_call(v_a_241, 1, (V[]){v_d_240}));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Ok: {
    V v_v_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Ok = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_v_243)) {
    case TAG_VFun: {
      V v_ru_24v_243_24VFun = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFun, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0)});
    }
    case TAG_VCons: {
      V v_ru_24v_243_24VCons = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VCons, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1)});
    }
    case TAG_VTag: {
      heff_take_n(v_v_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2)});
    }
    case TAG_VInt: {
      V v_ru_24v_243_24VInt = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3)});
    }
    case TAG_VFloat: {
      V v_ru_24v_243_24VFloat = heff_take_reuse_na(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4)});
    }
    case TAG_VFloat32: {
      V v_ru_24v_243_24VFloat32 = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat32, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5)});
    }
    case TAG_VStr: {
      V v_ru_24v_243_24VStr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VStr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6)});
    }
    case TAG_VRune: {
      V v_ru_24v_243_24VRune = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VRune, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7)});
    }
    case TAG_VArr: {
      V v_ru_24v_243_24VArr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VArr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8)});
    }
    case TAG_VBytes: {
      V v_ru_24v_243_24VBytes = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VBytes, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9)});
    }
    case TAG_VBits: {
      V v_n_2415 = heff_field(v_v_243, 0);
      heff_take_n(v_v_243, 1ULL, 2);
      return heff_tag_at_n(v_ru_24x1_242_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_n_2415})});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10)});
    }
    default: return heff_nomatch(v_v_243);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2417 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Bug = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_242_24Bug, TAG_Bug, 1, (V[]){v_what_2417});
  }
  default: return heff_nomatch(v_x1_242);
  }
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str1, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str2, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str3, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str4, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str5, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str6, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str7, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str8, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str9, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str10, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str11, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str12, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str13, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str14, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str15, 6, "intAnd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str16, 5, "intOr");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str17, 6, "intXor");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str18, 6, "intShl");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str19, 6, "intShr");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str20, 8, "floatAdd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str21, 8, "floatSub");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str22, 8, "floatMul");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str23, 8, "floatDiv");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str24, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str25, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str26, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str27, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str28, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str29, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str30, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str31, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str32, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str33, 9, "floatShow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str34, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str35, 9, "floatSqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str36, 10, "floatFloor");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str37, 8, "floatSin");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str38, 8, "floatCos");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str39, 8, "floatTan");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str40, 9, "floatAsin");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str41, 9, "floatAcos");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str42, 9, "floatAtan");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str43, 10, "floatAtan2");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str44, 8, "floatExp");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str45, 8, "floatLog");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str46, 8, "floatPow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str47, 11, "arrayLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str48, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str49, 32, "an index in range, of no element");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str50, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str51, 13, "arrayGenerate");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str52, 13, "arrayFromList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str53, 11, "arrayToList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str54, 14, "arrayReplicate");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str55, 10, "arraySlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str56, 11, "arrayAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str57, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str58, 9, "strLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str59, 8, "strSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str60, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str61, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str62, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str63, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str64, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str65, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str66, 10, "strCompare");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str67, 7, "strHash");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str68, 7, "intHash");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str69, 8, "trieSlot");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str70, 7, "strFind");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str71, 9, "strByteAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str72, 11, "strFromByte");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str73, 9, "strRuneAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str74, 12, "strRuneWidth");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str75, 12, "strRuneCount");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str76, 7, "strToJS");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str77, 9, "strFromJS");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str78, 11, "bytesLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str79, 7, "bytesAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str80, 10, "bytesSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str81, 11, "bytesAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str82, 11, "bytesConcat");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str83, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str84, 7, "bytesEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str85, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str86, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str87, 13, "bytesFromList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str88, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str89, 11, "bytesToList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str90, 15, "bytesFromString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str91, 13, "bytesToString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str92, 10, "bytesIntAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str93, 10, "bytesOfInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str94, 10, "bytesHasAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str95, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str96, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str97, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str98, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str99, 10, "bitsLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str100, 9, "bitsIntAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str101, 9, "bitsOfInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str102, 10, "bitsConcat");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str103, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str104, 9, "bitsSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str105, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str106, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str107, 9, "bitsBytes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str108, 6, "bitsEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str109, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str110, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str111, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str112, 9, "floatBits");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str113, 11, "floatOfBits");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str114, 6, "runeEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str115, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str116, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str117, 6, "runeLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str118, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str119, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str120, 6, "runeLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str121, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str122, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str123, 9, "runeToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str124, 11, "runeFromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str125, 8, "strRunes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str126, 10, "strOfRunes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str127, 13, "no primitive ");
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam0, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam1, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam2, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam3, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam4, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam5, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam6, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam7, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam8, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam9, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam10, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam11, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam12, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam13, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam14, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam15, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam16, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam17, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam18, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam19, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam20, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam21, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam22, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam23, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam24, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam26, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam25, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam28, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam27, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam31, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam30, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam37_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam37, 1, 0};
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam35, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam34, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam39, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam38, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam41, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam40, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam43, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam42, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam46, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam45_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam45, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam50_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam50, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam49_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam49, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam52_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam52, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam53_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam53, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam56_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam56, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam57_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam57, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam58_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam58, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam59_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam59, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam60_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam60, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam61_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam61, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam64_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam64, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam66_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam66, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam68_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam68, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam69_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam69, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam71_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam71, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam73_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam73, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam74_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam74, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam75_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam75, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam76_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam76, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam77_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam77, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam79_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam79, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam82_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam82, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam83_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam83, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam84_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam84, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam85_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam85, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam86_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam86, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam87_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam87, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam88_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam88, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam92_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam92, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam95_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam95, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam98_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam98, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam102_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam102, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam105_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam105, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam106_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam106, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam109_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam109, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam110(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam110_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam110, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam112(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam111(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam111_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam111, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam114(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam113(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam113_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam113, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam116(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam115(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam115_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam115, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam117(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam117_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam117, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam118(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam118_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam118, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam119(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam119, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam120(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam120_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam120, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam121(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam121_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam121, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam122(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam122_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam122, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam123(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam123, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam124(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eprim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eprim(V v_p_240) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str0), 2)) {
    heff_drop(v_p_240);
    return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get());
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str1), 2)) {
      heff_drop(v_p_240);
      return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get());
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str2), 2)) {
        heff_drop(v_p_240);
        return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get());
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str3), 2)) {
          heff_drop(v_p_240);
          HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam0_clo));
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str4), 2)) {
            heff_drop(v_p_240);
            HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam1_clo));
          } else {
            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str5), 2)) {
              heff_drop(v_p_240);
              HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam2_clo));
            } else {
              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str8), 2)) {
                heff_drop(v_p_240);
                HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam3_clo));
              } else {
                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str11), 2)) {
                  heff_drop(v_p_240);
                  HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam4_clo));
                } else {
                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str14), 2)) {
                    heff_drop(v_p_240);
                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam5_clo)});
                  } else {
                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str15), 2)) {
                      heff_drop(v_p_240);
                      return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get());
                    } else {
                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str16), 2)) {
                        heff_drop(v_p_240);
                        HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam6_clo));
                      } else {
                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str17), 2)) {
                          heff_drop(v_p_240);
                          HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam7_clo));
                        } else {
                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str18), 2)) {
                            heff_drop(v_p_240);
                            HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam8_clo));
                          } else {
                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str19), 2)) {
                              heff_drop(v_p_240);
                              HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam9_clo));
                            } else {
                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str20), 2)) {
                                heff_drop(v_p_240);
                                return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get());
                              } else {
                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str21), 2)) {
                                  heff_drop(v_p_240);
                                  return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get());
                                } else {
                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str22), 2)) {
                                    heff_drop(v_p_240);
                                    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get());
                                  } else {
                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str23), 2)) {
                                      heff_drop(v_p_240);
                                      return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get());
                                    } else {
                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str24), 2)) {
                                        heff_drop(v_p_240);
                                        HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam10_clo));
                                      } else {
                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str27), 2)) {
                                          heff_drop(v_p_240);
                                          HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam11_clo));
                                        } else {
                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str30), 2)) {
                                            heff_drop(v_p_240);
                                            HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam12_clo));
                                          } else {
                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str33), 2)) {
                                              heff_drop(v_p_240);
                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam13_clo)});
                                            } else {
                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str34), 2)) {
                                                heff_drop(v_p_240);
                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam14_clo)});
                                              } else {
                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str35), 2)) {
                                                  heff_drop(v_p_240);
                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam15_clo)});
                                                } else {
                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str36), 2)) {
                                                    heff_drop(v_p_240);
                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam16_clo)});
                                                  } else {
                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str37), 2)) {
                                                      heff_drop(v_p_240);
                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam17_clo)});
                                                    } else {
                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str38), 2)) {
                                                        heff_drop(v_p_240);
                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam18_clo)});
                                                      } else {
                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str39), 2)) {
                                                          heff_drop(v_p_240);
                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam19_clo)});
                                                        } else {
                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str40), 2)) {
                                                            heff_drop(v_p_240);
                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam20_clo)});
                                                          } else {
                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str41), 2)) {
                                                              heff_drop(v_p_240);
                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam21_clo)});
                                                            } else {
                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str42), 2)) {
                                                                heff_drop(v_p_240);
                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam22_clo)});
                                                              } else {
                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str43), 2)) {
                                                                  heff_drop(v_p_240);
                                                                  return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get());
                                                                } else {
                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str44), 2)) {
                                                                    heff_drop(v_p_240);
                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam23_clo)});
                                                                  } else {
                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str45), 2)) {
                                                                      heff_drop(v_p_240);
                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam24_clo)});
                                                                    } else {
                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str46), 2)) {
                                                                        heff_drop(v_p_240);
                                                                        return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get());
                                                                      } else {
                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str47), 2)) {
                                                                          heff_drop(v_p_240);
                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam25_clo)});
                                                                        } else {
                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str48), 2)) {
                                                                            heff_drop(v_p_240);
                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam27_clo)});
                                                                          } else {
                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str50), 2)) {
                                                                              heff_drop(v_p_240);
                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam30_clo)});
                                                                            } else {
                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str51), 2)) {
                                                                                heff_drop(v_p_240);
                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam34_clo)});
                                                                              } else {
                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str52), 2)) {
                                                                                  heff_drop(v_p_240);
                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam38_clo)});
                                                                                } else {
                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str53), 2)) {
                                                                                    heff_drop(v_p_240);
                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam40_clo)});
                                                                                  } else {
                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str54), 2)) {
                                                                                      heff_drop(v_p_240);
                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam42_clo)});
                                                                                    } else {
                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str55), 2)) {
                                                                                        heff_drop(v_p_240);
                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam45_clo)});
                                                                                      } else {
                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str56), 2)) {
                                                                                          heff_drop(v_p_240);
                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam49_clo)});
                                                                                        } else {
                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str57), 2)) {
                                                                                            heff_drop(v_p_240);
                                                                                            return heff_dup(g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get());
                                                                                          } else {
                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str58), 2)) {
                                                                                              heff_drop(v_p_240);
                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam52_clo)});
                                                                                            } else {
                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str59), 2)) {
                                                                                                heff_drop(v_p_240);
                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam53_clo)});
                                                                                              } else {
                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str60), 2)) {
                                                                                                  heff_drop(v_p_240);
                                                                                                  HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam56_clo));
                                                                                                } else {
                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str63), 2)) {
                                                                                                    heff_drop(v_p_240);
                                                                                                    HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam57_clo));
                                                                                                  } else {
                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str66), 2)) {
                                                                                                      heff_drop(v_p_240);
                                                                                                      HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam58_clo));
                                                                                                    } else {
                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str67), 2)) {
                                                                                                        heff_drop(v_p_240);
                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam59_clo)});
                                                                                                      } else {
                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str68), 2)) {
                                                                                                          heff_drop(v_p_240);
                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam60_clo)});
                                                                                                        } else {
                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str69), 2)) {
                                                                                                            heff_drop(v_p_240);
                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam61_clo)});
                                                                                                          } else {
                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str70), 2)) {
                                                                                                              heff_drop(v_p_240);
                                                                                                              HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam64_clo));
                                                                                                            } else {
                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str71), 2)) {
                                                                                                                heff_drop(v_p_240);
                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam66_clo)});
                                                                                                              } else {
                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str72), 2)) {
                                                                                                                  heff_drop(v_p_240);
                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam68_clo)});
                                                                                                                } else {
                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str73), 2)) {
                                                                                                                    heff_drop(v_p_240);
                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam69_clo)});
                                                                                                                  } else {
                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str74), 2)) {
                                                                                                                      heff_drop(v_p_240);
                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam71_clo)});
                                                                                                                    } else {
                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str75), 2)) {
                                                                                                                        heff_drop(v_p_240);
                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam73_clo)});
                                                                                                                      } else {
                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str76), 2)) {
                                                                                                                          heff_drop(v_p_240);
                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam74_clo)});
                                                                                                                        } else {
                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str77), 2)) {
                                                                                                                            heff_drop(v_p_240);
                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam75_clo)});
                                                                                                                          } else {
                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str78), 2)) {
                                                                                                                              heff_drop(v_p_240);
                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam76_clo)});
                                                                                                                            } else {
                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str79), 2)) {
                                                                                                                                heff_drop(v_p_240);
                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam77_clo)});
                                                                                                                              } else {
                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str80), 2)) {
                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam79_clo)});
                                                                                                                                } else {
                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str81), 2)) {
                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                    return heff_dup(g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get());
                                                                                                                                  } else {
                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str82), 2)) {
                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam82_clo)});
                                                                                                                                    } else {
                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str84), 2)) {
                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                        HEFF_LAST return g_heff_2ecompile_2einterp_2ebytes2(((V)&g_heff_2ecompile_2einterp_2eprim_lam83_clo));
                                                                                                                                      } else {
                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str87), 2)) {
                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam84_clo)});
                                                                                                                                        } else {
                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str89), 2)) {
                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam85_clo)});
                                                                                                                                          } else {
                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str90), 2)) {
                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam86_clo)});
                                                                                                                                            } else {
                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str91), 2)) {
                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam87_clo)});
                                                                                                                                              } else {
                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str92), 2)) {
                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam88_clo)});
                                                                                                                                                } else {
                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str93), 2)) {
                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam92_clo)});
                                                                                                                                                  } else {
                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str94), 2)) {
                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam95_clo)});
                                                                                                                                                    } else {
                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str99), 2)) {
                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                        return heff_dup(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get());
                                                                                                                                                      } else {
                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str100), 2)) {
                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                          HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam98_clo));
                                                                                                                                                        } else {
                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str101), 2)) {
                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam102_clo)});
                                                                                                                                                          } else {
                                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str102), 2)) {
                                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam105_clo)});
                                                                                                                                                            } else {
                                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str104), 2)) {
                                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                                HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam106_clo));
                                                                                                                                                              } else {
                                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str106), 2)) {
                                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam109_clo)});
                                                                                                                                                                } else {
                                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str107), 2)) {
                                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                                    HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam110_clo));
                                                                                                                                                                  } else {
                                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str108), 2)) {
                                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                                      HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam111_clo));
                                                                                                                                                                    } else {
                                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str112), 2)) {
                                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam113_clo)});
                                                                                                                                                                      } else {
                                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str113), 2)) {
                                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam115_clo)});
                                                                                                                                                                        } else {
                                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str114), 2)) {
                                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                                            HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam117_clo));
                                                                                                                                                                          } else {
                                                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str117), 2)) {
                                                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                                                              HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam118_clo));
                                                                                                                                                                            } else {
                                                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str120), 2)) {
                                                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                                                HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam119_clo));
                                                                                                                                                                              } else {
                                                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str123), 2)) {
                                                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam120_clo)});
                                                                                                                                                                                } else {
                                                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str124), 2)) {
                                                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam121_clo)});
                                                                                                                                                                                  } else {
                                                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str125), 2)) {
                                                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam122_clo)});
                                                                                                                                                                                    } else {
                                                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str126), 2)) {
                                                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam123_clo)});
                                                                                                                                                                                      } else {
                                                                                                                                                                                        V v_t_241816 = (g_heff_2eelab_2efixed_2efixedPrimOf(heff_dup(v_p_240)));
                                                                                                                                                                                        switch (heff_tag_of(v_t_241816)) {
                                                                                                                                                                                        case TAG_Nothing: {
                                                                                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam124, 2, 1, (V[]){v_p_240})});
                                                                                                                                                                                        }
                                                                                                                                                                                        case TAG_Just: {
                                                                                                                                                                                          V v_fp_241819 = heff_field(v_t_241816, 0);
                                                                                                                                                                                          heff_take_n(v_t_241816, 1ULL, 1);
                                                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                                                          HEFF_LAST return g_heff_2ecompile_2einterp_2efixedPrimV(v_fp_241819);
                                                                                                                                                                                        }
                                                                                                                                                                                        default: return heff_nomatch(v_t_241816);
                                                                                                                                                                                        }
                                                                                                                                                                                      }
                                                                                                                                                                                    }
                                                                                                                                                                                  }
                                                                                                                                                                                }
                                                                                                                                                                              }
                                                                                                                                                                            }
                                                                                                                                                                          }
                                                                                                                                                                        }
                                                                                                                                                                      }
                                                                                                                                                                    }
                                                                                                                                                                  }
                                                                                                                                                                }
                                                                                                                                                              }
                                                                                                                                                            }
                                                                                                                                                          }
                                                                                                                                                        }
                                                                                                                                                      }
                                                                                                                                                    }
                                                                                                                                                  }
                                                                                                                                                }
                                                                                                                                              }
                                                                                                                                            }
                                                                                                                                          }
                                                                                                                                        }
                                                                                                                                      }
                                                                                                                                    }
                                                                                                                                  }
                                                                                                                                }
                                                                                                                              }
                                                                                                                            }
                                                                                                                          }
                                                                                                                        }
                                                                                                                      }
                                                                                                                    }
                                                                                                                  }
                                                                                                                }
                                                                                                              }
                                                                                                            }
                                                                                                          }
                                                                                                        }
                                                                                                      }
                                                                                                    }
                                                                                                  }
                                                                                                }
                                                                                              }
                                                                                            }
                                                                                          }
                                                                                        }
                                                                                      }
                                                                                    }
                                                                                  }
                                                                                }
                                                                              }
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eprim(a[0]);
}
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_b_246 = args[1];
  if (heff_intEq_c(heff_dup(v_b_246), MK_INT(0LL))) {
    heff_drop(v_a_245);
    heff_drop(v_b_246);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){MK_INT(0LL)})});
  } else {
    V v_t_248 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_245, v_b_246)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_248});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args) {
  V v_a_2410 = args[0];
  V v_b_2411 = args[1];
  if (heff_intEq_c(heff_dup(v_b_2411), MK_INT(0LL))) {
    heff_drop(v_b_2411);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_2410})});
  } else {
    V v_t_2413 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMod(v_a_2410, v_b_2411)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2413});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args) {
  V v_a_2415 = args[0];
  V v_b_2416 = args[1];
  V v_t_2418;
  if (heff_intEq_c(v_a_2415, v_b_2416)) {
    v_t_2418 = ((V)&g_heff_2ecompile_2einterp_2eprim_str6);
  } else {
    v_t_2418 = ((V)&g_heff_2ecompile_2einterp_2eprim_str7);
  }
  V v_t_2419 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2419});
}
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args) {
  V v_a_2421 = args[0];
  V v_b_2422 = args[1];
  V v_t_2424;
  if (heff_intLt_c(v_a_2421, v_b_2422)) {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2eprim_str9);
  } else {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2eprim_str10);
  }
  V v_t_2425 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2425});
}
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args) {
  V v_a_2427 = args[0];
  V v_b_2428 = args[1];
  V v_t_2430;
  if (heff_intLe_c(v_a_2427, v_b_2428)) {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2eprim_str12);
  } else {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2eprim_str13);
  }
  V v_t_2431 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2431});
}
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args) {
  V v_d_2433 = args[0];
  V v_a_2434 = args[1];
  V v_x1_2435 = heff_tr(heff_call(v_a_2434, 1, (V[]){v_d_2433}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_Ok: {
    V v_v_2436 = heff_field(v_x1_2435, 0);
    V v_ru_24x1_2435_24Ok = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
    switch (heff_tag_of(v_v_2436)) {
    case TAG_VFun: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2436, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_2441 = heff_field(v_v_2436, 0);
      V v_ru_24v_2436_24VInt = heff_take_reuse_n(v_v_2436, 1ULL, 1);
      V v_t_2442 = heff_tag_at_n(v_ru_24v_2436_24VInt, TAG_VStr, 1, (V[]){heff_intShow(v_a_2441)});
      return heff_tag_at_n(v_ru_24x1_2435_24Ok, TAG_Ok, 1, (V[]){v_t_2442});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2436, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_2436);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2451 = heff_field(v_x1_2435, 0);
    V v_ru_24x1_2435_24Bug = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2435_24Bug, TAG_Bug, 1, (V[]){v_what_2451});
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args) {
  V v_a_2454 = args[0];
  V v_b_2455 = args[1];
  V v_t_2456 = (g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), v_a_2454, v_b_2455));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2456})});
}
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args) {
  V v_a_2458 = args[0];
  V v_b_2459 = args[1];
  V v_t_2460 = (g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(MK_INT(2LL), v_a_2458, v_b_2459));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2460})});
}
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args) {
  V v_a_2462 = args[0];
  V v_b_2463 = args[1];
  if (heff_intLt_c(heff_dup(v_b_2463), MK_INT(0LL))) {
    V v_k_2465 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2463)));
    V v_t_2466 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2462, v_k_2465)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2466});
  } else {
    V v_k_2467 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2463));
    V v_t_2468 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2462, v_k_2467)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2468});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args) {
  V v_a_2470 = args[0];
  V v_b_2471 = args[1];
  if (heff_intLt_c(heff_dup(v_b_2471), MK_INT(0LL))) {
    V v_k_2473 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2471)));
    V v_t_2474 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2470, v_k_2473)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2474});
  } else {
    V v_k_2475 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2471));
    V v_t_2476 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2470, v_k_2475)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2476});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args) {
  V v_box_24a_2482 = args[0];
  V v_box_24b_2483 = args[1];
  double v_a_2482 = heff_unbox_f64(v_box_24a_2482);
  double v_b_2483 = heff_unbox_f64(v_box_24b_2483);
  V v_t_2485;
  if ((v_a_2482 == v_b_2483)) {
    v_t_2485 = ((V)&g_heff_2ecompile_2einterp_2eprim_str25);
  } else {
    v_t_2485 = ((V)&g_heff_2ecompile_2einterp_2eprim_str26);
  }
  V v_t_2486 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2485, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2486});
}
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args) {
  V v_box_24a_2488 = args[0];
  V v_box_24b_2489 = args[1];
  double v_a_2488 = heff_unbox_f64(v_box_24a_2488);
  double v_b_2489 = heff_unbox_f64(v_box_24b_2489);
  V v_t_2491;
  if ((v_a_2488 < v_b_2489)) {
    v_t_2491 = ((V)&g_heff_2ecompile_2einterp_2eprim_str28);
  } else {
    v_t_2491 = ((V)&g_heff_2ecompile_2einterp_2eprim_str29);
  }
  V v_t_2492 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2491, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2492});
}
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args) {
  V v_box_24a_2494 = args[0];
  V v_box_24b_2495 = args[1];
  double v_a_2494 = heff_unbox_f64(v_box_24a_2494);
  double v_b_2495 = heff_unbox_f64(v_box_24b_2495);
  V v_t_2497;
  if ((v_a_2494 <= v_b_2495)) {
    v_t_2497 = ((V)&g_heff_2ecompile_2einterp_2eprim_str31);
  } else {
    v_t_2497 = ((V)&g_heff_2ecompile_2einterp_2eprim_str32);
  }
  V v_t_2498 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2497, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2498});
}
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args) {
  V v_d_24100 = args[0];
  V v_a_24101 = args[1];
  V v_x1_24102 = heff_tr(heff_call(v_a_24101, 1, (V[]){v_d_24100}));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_Ok: {
    V v_v_24103 = heff_field(v_x1_24102, 0);
    V v_ru_24x1_24102_24Ok = heff_take_reuse_n(v_x1_24102, 1ULL, 1);
    switch (heff_tag_of(v_v_24103)) {
    case TAG_VFun: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24103, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      V v_a_24109 = heff_tget_v(v_v_24103, 0);
      V v_ru_24v_24103_24VFloat = heff_take_reuse_na(v_v_24103, 0ULL, 1);
      V v_t_24110 = heff_tag_at_n(v_ru_24v_24103_24VFloat, TAG_VStr, 1, (V[]){heff_floatShow(v_a_24109)});
      return heff_tag_at_n(v_ru_24x1_24102_24Ok, TAG_Ok, 1, (V[]){v_t_24110});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24103, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24103, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24102_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24103);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24118 = heff_field(v_x1_24102, 0);
    V v_ru_24x1_24102_24Bug = heff_take_reuse_n(v_x1_24102, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24102_24Bug, TAG_Bug, 1, (V[]){v_what_24118});
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args) {
  V v_d_24120 = args[0];
  V v_a_24121 = args[1];
  V v_x1_24122 = heff_tr(heff_call(v_a_24121, 1, (V[]){v_d_24120}));
  switch (heff_tag_of(v_x1_24122)) {
  case TAG_Ok: {
    V v_v_24123 = heff_field(v_x1_24122, 0);
    V v_ru_24x1_24122_24Ok = heff_take_reuse_n(v_x1_24122, 1ULL, 1);
    switch (heff_tag_of(v_v_24123)) {
    case TAG_VFun: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24123, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24128 = heff_field(v_v_24123, 0);
      V v_ru_24v_24123_24VInt = heff_take_reuse_n(v_v_24123, 1ULL, 1);
      V v_t_24129 = heff_tag_at_nf(v_ru_24v_24123_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(heff_from_int_f64(v_a_24128))});
      return heff_tag_at_n(v_ru_24x1_24122_24Ok, TAG_Ok, 1, (V[]){v_t_24129});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24123, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24123);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24138 = heff_field(v_x1_24122, 0);
    V v_ru_24x1_24122_24Bug = heff_take_reuse_n(v_x1_24122, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24122_24Bug, TAG_Bug, 1, (V[]){v_what_24138});
  }
  default: return heff_nomatch(v_x1_24122);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args) {
  V v_d_24140 = args[0];
  V v_a_24141 = args[1];
  V v_x1_24142 = heff_tr(heff_call(v_a_24141, 1, (V[]){v_d_24140}));
  switch (heff_tag_of(v_x1_24142)) {
  case TAG_Ok: {
    V v_v_24143 = heff_field(v_x1_24142, 0);
    V v_ru_24x1_24142_24Ok = heff_take_reuse_n(v_x1_24142, 1ULL, 1);
    switch (heff_tag_of(v_v_24143)) {
    case TAG_VFun: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24143, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24149 = heff_tflat_f64(v_v_24143, 0);
      V v_ru_24v_24143_24VFloat = heff_take_reuse_na(v_v_24143, 0ULL, 1);
      V v_t_24150 = heff_tag_at_nf(v_ru_24v_24143_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(sqrt(v_a_24149))});
      return heff_tag_at_n(v_ru_24x1_24142_24Ok, TAG_Ok, 1, (V[]){v_t_24150});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24143, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24143, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24142_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24143);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24158 = heff_field(v_x1_24142, 0);
    V v_ru_24x1_24142_24Bug = heff_take_reuse_n(v_x1_24142, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24142_24Bug, TAG_Bug, 1, (V[]){v_what_24158});
  }
  default: return heff_nomatch(v_x1_24142);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args) {
  V v_d_24160 = args[0];
  V v_a_24161 = args[1];
  V v_x1_24162 = heff_tr(heff_call(v_a_24161, 1, (V[]){v_d_24160}));
  switch (heff_tag_of(v_x1_24162)) {
  case TAG_Ok: {
    V v_v_24163 = heff_field(v_x1_24162, 0);
    V v_ru_24x1_24162_24Ok = heff_take_reuse_n(v_x1_24162, 1ULL, 1);
    switch (heff_tag_of(v_v_24163)) {
    case TAG_VFun: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24163, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24169 = heff_tflat_f64(v_v_24163, 0);
      V v_ru_24v_24163_24VFloat = heff_take_reuse_na(v_v_24163, 0ULL, 1);
      if (((v_a_24169 - v_a_24169) == (0.0))) {
        V v_t_24171 = heff_tag_at_n(v_ru_24v_24163_24VFloat, TAG_VInt, 1, (V[]){heff_floor_f64(v_a_24169)});
        return heff_tag_at_n(v_ru_24x1_24162_24Ok, TAG_Ok, 1, (V[]){v_t_24171});
      } else {
        heff_drop_cell(v_ru_24v_24163_24VFloat, 1);
        return heff_tag_at_n(v_ru_24x1_24162_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){MK_INT(0LL)})});
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24163, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24163, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24162_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24163);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24179 = heff_field(v_x1_24162, 0);
    V v_ru_24x1_24162_24Bug = heff_take_reuse_n(v_x1_24162, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24162_24Bug, TAG_Bug, 1, (V[]){v_what_24179});
  }
  default: return heff_nomatch(v_x1_24162);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args) {
  V v_d_24181 = args[0];
  V v_a_24182 = args[1];
  V v_x1_24183 = heff_tr(heff_call(v_a_24182, 1, (V[]){v_d_24181}));
  switch (heff_tag_of(v_x1_24183)) {
  case TAG_Ok: {
    V v_v_24184 = heff_field(v_x1_24183, 0);
    V v_ru_24x1_24183_24Ok = heff_take_reuse_n(v_x1_24183, 1ULL, 1);
    switch (heff_tag_of(v_v_24184)) {
    case TAG_VFun: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24184, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24190 = heff_tflat_f64(v_v_24184, 0);
      V v_ru_24v_24184_24VFloat = heff_take_reuse_na(v_v_24184, 0ULL, 1);
      V v_t_24191 = heff_tag_at_nf(v_ru_24v_24184_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(sin(v_a_24190))});
      return heff_tag_at_n(v_ru_24x1_24183_24Ok, TAG_Ok, 1, (V[]){v_t_24191});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24184, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24184, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24183_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24184);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24199 = heff_field(v_x1_24183, 0);
    V v_ru_24x1_24183_24Bug = heff_take_reuse_n(v_x1_24183, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24183_24Bug, TAG_Bug, 1, (V[]){v_what_24199});
  }
  default: return heff_nomatch(v_x1_24183);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args) {
  V v_d_24201 = args[0];
  V v_a_24202 = args[1];
  V v_x1_24203 = heff_tr(heff_call(v_a_24202, 1, (V[]){v_d_24201}));
  switch (heff_tag_of(v_x1_24203)) {
  case TAG_Ok: {
    V v_v_24204 = heff_field(v_x1_24203, 0);
    V v_ru_24x1_24203_24Ok = heff_take_reuse_n(v_x1_24203, 1ULL, 1);
    switch (heff_tag_of(v_v_24204)) {
    case TAG_VFun: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24204, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24210 = heff_tflat_f64(v_v_24204, 0);
      V v_ru_24v_24204_24VFloat = heff_take_reuse_na(v_v_24204, 0ULL, 1);
      V v_t_24211 = heff_tag_at_nf(v_ru_24v_24204_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(cos(v_a_24210))});
      return heff_tag_at_n(v_ru_24x1_24203_24Ok, TAG_Ok, 1, (V[]){v_t_24211});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24204, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24204, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24203_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24204);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24219 = heff_field(v_x1_24203, 0);
    V v_ru_24x1_24203_24Bug = heff_take_reuse_n(v_x1_24203, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24203_24Bug, TAG_Bug, 1, (V[]){v_what_24219});
  }
  default: return heff_nomatch(v_x1_24203);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args) {
  V v_d_24221 = args[0];
  V v_a_24222 = args[1];
  V v_x1_24223 = heff_tr(heff_call(v_a_24222, 1, (V[]){v_d_24221}));
  switch (heff_tag_of(v_x1_24223)) {
  case TAG_Ok: {
    V v_v_24224 = heff_field(v_x1_24223, 0);
    V v_ru_24x1_24223_24Ok = heff_take_reuse_n(v_x1_24223, 1ULL, 1);
    switch (heff_tag_of(v_v_24224)) {
    case TAG_VFun: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24224, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24230 = heff_tflat_f64(v_v_24224, 0);
      V v_ru_24v_24224_24VFloat = heff_take_reuse_na(v_v_24224, 0ULL, 1);
      V v_t_24231 = heff_tag_at_nf(v_ru_24v_24224_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(tan(v_a_24230))});
      return heff_tag_at_n(v_ru_24x1_24223_24Ok, TAG_Ok, 1, (V[]){v_t_24231});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24224, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24224, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24223_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24224);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24239 = heff_field(v_x1_24223, 0);
    V v_ru_24x1_24223_24Bug = heff_take_reuse_n(v_x1_24223, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24223_24Bug, TAG_Bug, 1, (V[]){v_what_24239});
  }
  default: return heff_nomatch(v_x1_24223);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args) {
  V v_d_24241 = args[0];
  V v_a_24242 = args[1];
  V v_x1_24243 = heff_tr(heff_call(v_a_24242, 1, (V[]){v_d_24241}));
  switch (heff_tag_of(v_x1_24243)) {
  case TAG_Ok: {
    V v_v_24244 = heff_field(v_x1_24243, 0);
    V v_ru_24x1_24243_24Ok = heff_take_reuse_n(v_x1_24243, 1ULL, 1);
    switch (heff_tag_of(v_v_24244)) {
    case TAG_VFun: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24244, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24250 = heff_tflat_f64(v_v_24244, 0);
      V v_ru_24v_24244_24VFloat = heff_take_reuse_na(v_v_24244, 0ULL, 1);
      V v_t_24251 = heff_tag_at_nf(v_ru_24v_24244_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(asin(v_a_24250))});
      return heff_tag_at_n(v_ru_24x1_24243_24Ok, TAG_Ok, 1, (V[]){v_t_24251});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24244, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24244, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24243_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24244);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24259 = heff_field(v_x1_24243, 0);
    V v_ru_24x1_24243_24Bug = heff_take_reuse_n(v_x1_24243, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24243_24Bug, TAG_Bug, 1, (V[]){v_what_24259});
  }
  default: return heff_nomatch(v_x1_24243);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args) {
  V v_d_24261 = args[0];
  V v_a_24262 = args[1];
  V v_x1_24263 = heff_tr(heff_call(v_a_24262, 1, (V[]){v_d_24261}));
  switch (heff_tag_of(v_x1_24263)) {
  case TAG_Ok: {
    V v_v_24264 = heff_field(v_x1_24263, 0);
    V v_ru_24x1_24263_24Ok = heff_take_reuse_n(v_x1_24263, 1ULL, 1);
    switch (heff_tag_of(v_v_24264)) {
    case TAG_VFun: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24264, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24270 = heff_tflat_f64(v_v_24264, 0);
      V v_ru_24v_24264_24VFloat = heff_take_reuse_na(v_v_24264, 0ULL, 1);
      V v_t_24271 = heff_tag_at_nf(v_ru_24v_24264_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(acos(v_a_24270))});
      return heff_tag_at_n(v_ru_24x1_24263_24Ok, TAG_Ok, 1, (V[]){v_t_24271});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24264, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24264, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24263_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24264);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24279 = heff_field(v_x1_24263, 0);
    V v_ru_24x1_24263_24Bug = heff_take_reuse_n(v_x1_24263, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24263_24Bug, TAG_Bug, 1, (V[]){v_what_24279});
  }
  default: return heff_nomatch(v_x1_24263);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args) {
  V v_d_24281 = args[0];
  V v_a_24282 = args[1];
  V v_x1_24283 = heff_tr(heff_call(v_a_24282, 1, (V[]){v_d_24281}));
  switch (heff_tag_of(v_x1_24283)) {
  case TAG_Ok: {
    V v_v_24284 = heff_field(v_x1_24283, 0);
    V v_ru_24x1_24283_24Ok = heff_take_reuse_n(v_x1_24283, 1ULL, 1);
    switch (heff_tag_of(v_v_24284)) {
    case TAG_VFun: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24284, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24290 = heff_tflat_f64(v_v_24284, 0);
      V v_ru_24v_24284_24VFloat = heff_take_reuse_na(v_v_24284, 0ULL, 1);
      V v_t_24291 = heff_tag_at_nf(v_ru_24v_24284_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(atan(v_a_24290))});
      return heff_tag_at_n(v_ru_24x1_24283_24Ok, TAG_Ok, 1, (V[]){v_t_24291});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24284, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24284, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24283_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24284);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24299 = heff_field(v_x1_24283, 0);
    V v_ru_24x1_24283_24Bug = heff_take_reuse_n(v_x1_24283, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24283_24Bug, TAG_Bug, 1, (V[]){v_what_24299});
  }
  default: return heff_nomatch(v_x1_24283);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args) {
  V v_d_24302 = args[0];
  V v_a_24303 = args[1];
  V v_x1_24304 = heff_tr(heff_call(v_a_24303, 1, (V[]){v_d_24302}));
  switch (heff_tag_of(v_x1_24304)) {
  case TAG_Ok: {
    V v_v_24305 = heff_field(v_x1_24304, 0);
    V v_ru_24x1_24304_24Ok = heff_take_reuse_n(v_x1_24304, 1ULL, 1);
    switch (heff_tag_of(v_v_24305)) {
    case TAG_VFun: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24305, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24311 = heff_tflat_f64(v_v_24305, 0);
      V v_ru_24v_24305_24VFloat = heff_take_reuse_na(v_v_24305, 0ULL, 1);
      V v_t_24312 = heff_tag_at_nf(v_ru_24v_24305_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(exp(v_a_24311))});
      return heff_tag_at_n(v_ru_24x1_24304_24Ok, TAG_Ok, 1, (V[]){v_t_24312});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24305, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24305, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24305);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24320 = heff_field(v_x1_24304, 0);
    V v_ru_24x1_24304_24Bug = heff_take_reuse_n(v_x1_24304, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24304_24Bug, TAG_Bug, 1, (V[]){v_what_24320});
  }
  default: return heff_nomatch(v_x1_24304);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args) {
  V v_d_24322 = args[0];
  V v_a_24323 = args[1];
  V v_x1_24324 = heff_tr(heff_call(v_a_24323, 1, (V[]){v_d_24322}));
  switch (heff_tag_of(v_x1_24324)) {
  case TAG_Ok: {
    V v_v_24325 = heff_field(v_x1_24324, 0);
    V v_ru_24x1_24324_24Ok = heff_take_reuse_n(v_x1_24324, 1ULL, 1);
    switch (heff_tag_of(v_v_24325)) {
    case TAG_VFun: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24325, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24331 = heff_tflat_f64(v_v_24325, 0);
      V v_ru_24v_24325_24VFloat = heff_take_reuse_na(v_v_24325, 0ULL, 1);
      V v_t_24332 = heff_tag_at_nf(v_ru_24v_24325_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(log(v_a_24331))});
      return heff_tag_at_n(v_ru_24x1_24324_24Ok, TAG_Ok, 1, (V[]){v_t_24332});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24325, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24325, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24324_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24325);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24340 = heff_field(v_x1_24324, 0);
    V v_ru_24x1_24324_24Bug = heff_take_reuse_n(v_x1_24324, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24324_24Bug, TAG_Bug, 1, (V[]){v_what_24340});
  }
  default: return heff_nomatch(v_x1_24324);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args) {
  V v_d_24345 = args[0];
  V v_a_24346 = args[1];
  V v_x1_24347 = heff_tr(heff_call(v_a_24346, 1, (V[]){v_d_24345}));
  switch (heff_tag_of(v_x1_24347)) {
  case TAG_Ok: {
    V v_v_24348 = heff_field(v_x1_24347, 0);
    V v_ru_24x1_24347_24Ok = heff_take_reuse_n(v_x1_24347, 1ULL, 1);
    switch (heff_tag_of(v_v_24348)) {
    case TAG_VFun: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24348, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24358 = heff_field(v_v_24348, 0);
      heff_take_n(v_v_24348, 1ULL, 1);
      V v_t_24359 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_xs_24358); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      return heff_tag_at_n(v_ru_24x1_24347_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24359})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24348, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24348, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24347_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24348);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24363 = heff_field(v_x1_24347, 0);
    V v_ru_24x1_24347_24Bug = heff_take_reuse_n(v_x1_24347, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24347_24Bug, TAG_Bug, 1, (V[]){v_what_24363});
  }
  default: return heff_nomatch(v_x1_24347);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args) {
  V v_d_24343 = args[0];
  V v_u_24344 = args[1];
  heff_drop(v_d_24343);
  heff_drop(v_u_24344);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam26_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args) {
  V v_d_24381 = args[0];
  V v_a_24382 = args[1];
  V v_xs_24380 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24383 = heff_tr(heff_call(v_a_24382, 1, (V[]){v_d_24381}));
  switch (heff_tag_of(v_x1_24383)) {
  case TAG_Ok: {
    V v_v_24384 = heff_field(v_x1_24383, 0);
    V v_ru_24x1_24383_24Ok = heff_take_reuse_n(v_x1_24383, 1ULL, 1);
    switch (heff_tag_of(v_v_24384)) {
    case TAG_VFun: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24384, 0ULL, 2);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24389 = heff_field(v_v_24384, 0);
      V v_ru_24v_24384_24VInt = heff_take_reuse_n(v_v_24384, 1ULL, 1);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_a_24389))) {
        V v_t_24391 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24380)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        if (heff_intLt_c(heff_dup(v_a_24389), v_t_24391)) {
          V v_t_24393 = ({ V b_0 = heff_arrayToList(v_xs_24380); V a_1 = v_a_24389; V r_ = (g_heff_2ecompile_2einterp_2enthV(b_0, a_1)); heff_drop(b_0); r_; });
          switch (heff_tag_of(v_t_24393)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
            return heff_tag_at_n(v_ru_24v_24384_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str49)});
          }
          case TAG_Just: {
            V v_v_24394 = heff_field(v_t_24393, 0);
            heff_take_n(v_t_24393, 1ULL, 1);
            heff_drop_cell(v_ru_24v_24384_24VInt, 1);
            return heff_tag_at_n(v_ru_24x1_24383_24Ok, TAG_Ok, 1, (V[]){v_v_24394});
          }
          default: return heff_nomatch(v_t_24393);
          }
        } else {
          heff_drop(v_xs_24380);
          heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
          heff_drop(v_a_24389);
          heff_drop_cell(v_ru_24v_24384_24VInt, 1);
          return NTAG(TAG_Abn);
        }
      } else {
        heff_drop(v_xs_24380);
        heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
        heff_drop(v_a_24389);
        heff_drop_cell(v_ru_24v_24384_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24384, 0ULL, 1);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24384, 0ULL, 2);
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24380);
      heff_drop_cell(v_ru_24x1_24383_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24384);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24380);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24380);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24403 = heff_field(v_x1_24383, 0);
    V v_ru_24x1_24383_24Bug = heff_take_reuse_n(v_x1_24383, 1ULL, 1);
    heff_drop(v_xs_24380);
    return heff_tag_at_n(v_ru_24x1_24383_24Bug, TAG_Bug, 1, (V[]){v_what_24403});
  }
  default: return heff_nomatch(v_x1_24383);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args) {
  V v_d_24367 = args[0];
  V v_a_24368 = args[1];
  V v_x1_24369 = heff_tr(heff_call(v_a_24368, 1, (V[]){v_d_24367}));
  switch (heff_tag_of(v_x1_24369)) {
  case TAG_Ok: {
    V v_v_24370 = heff_field(v_x1_24369, 0);
    V v_ru_24x1_24369_24Ok = heff_take_reuse_n(v_x1_24369, 1ULL, 1);
    switch (heff_tag_of(v_v_24370)) {
    case TAG_VFun: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24370, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24380 = heff_field(v_v_24370, 0);
      heff_take_n(v_v_24370, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24369_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam29, 2, 1, (V[]){v_xs_24380})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24370, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24370, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24369_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24370);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24407 = heff_field(v_x1_24369, 0);
    V v_ru_24x1_24369_24Bug = heff_take_reuse_n(v_x1_24369, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24369_24Bug, TAG_Bug, 1, (V[]){v_what_24407});
  }
  default: return heff_nomatch(v_x1_24369);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args) {
  V v_d_24365 = args[0];
  V v_u_24366 = args[1];
  heff_drop(v_d_24365);
  heff_drop(v_u_24366);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam28_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args) {
  V v_d_24434 = args[0];
  V v_x_24435 = args[1];
  V v_a_24433 = heff_env(self)[0];
  V v_xs_24424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24436 = heff_tr(heff_call(v_x_24435, 1, (V[]){v_d_24434}));
  switch (heff_tag_of(v_x1_24436)) {
  case TAG_Ok: {
    V v_v_24437 = heff_field(v_x1_24436, 0);
    V v_ru_24x1_24436_24Ok = heff_take_reuse_n(v_x1_24436, 1ULL, 1);
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_a_24433))) {
      V v_t_24439 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24424)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (heff_intLt_c(heff_dup(v_a_24433), v_t_24439)) {
        V v_t_24441 = (g_heff_2ecompile_2einterp_2esetAt(heff_arrayToList(v_xs_24424), v_a_24433, v_v_24437));
        V v_t_24442 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24441)});
        return heff_tag_at_n(v_ru_24x1_24436_24Ok, TAG_Ok, 1, (V[]){v_t_24442});
      } else {
        heff_drop(v_a_24433);
        heff_drop(v_v_24437);
        return heff_tag_at_n(v_ru_24x1_24436_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VArr, 1, (V[]){v_xs_24424})});
      }
    } else {
      heff_drop(v_a_24433);
      heff_drop(v_v_24437);
      return heff_tag_at_n(v_ru_24x1_24436_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VArr, 1, (V[]){v_xs_24424})});
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24433);
    heff_drop(v_xs_24424);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24433);
    heff_drop(v_xs_24424);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24443 = heff_field(v_x1_24436, 0);
    V v_ru_24x1_24436_24Bug = heff_take_reuse_n(v_x1_24436, 1ULL, 1);
    heff_drop(v_a_24433);
    heff_drop(v_xs_24424);
    return heff_tag_at_n(v_ru_24x1_24436_24Bug, TAG_Bug, 1, (V[]){v_what_24443});
  }
  default: return heff_nomatch(v_x1_24436);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args) {
  V v_d_24425 = args[0];
  V v_a_24426 = args[1];
  V v_xs_24424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24427 = heff_tr(heff_call(v_a_24426, 1, (V[]){v_d_24425}));
  switch (heff_tag_of(v_x1_24427)) {
  case TAG_Ok: {
    V v_v_24428 = heff_field(v_x1_24427, 0);
    V v_ru_24x1_24427_24Ok = heff_take_reuse_n(v_x1_24427, 1ULL, 1);
    switch (heff_tag_of(v_v_24428)) {
    case TAG_VFun: {
      heff_take_n(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24428, 0ULL, 2);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24433 = heff_field(v_v_24428, 0);
      heff_take_n(v_v_24428, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24427_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam33, 2, 2, (V[]){v_a_24433, v_xs_24424})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24428, 0ULL, 1);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24428, 0ULL, 2);
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24424);
      heff_drop_cell(v_ru_24x1_24427_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24428);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24424);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24424);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24452 = heff_field(v_x1_24427, 0);
    V v_ru_24x1_24427_24Bug = heff_take_reuse_n(v_x1_24427, 1ULL, 1);
    heff_drop(v_xs_24424);
    return heff_tag_at_n(v_ru_24x1_24427_24Bug, TAG_Bug, 1, (V[]){v_what_24452});
  }
  default: return heff_nomatch(v_x1_24427);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args) {
  V v_d_24411 = args[0];
  V v_a_24412 = args[1];
  V v_x1_24413 = heff_tr(heff_call(v_a_24412, 1, (V[]){v_d_24411}));
  switch (heff_tag_of(v_x1_24413)) {
  case TAG_Ok: {
    V v_v_24414 = heff_field(v_x1_24413, 0);
    V v_ru_24x1_24413_24Ok = heff_take_reuse_n(v_x1_24413, 1ULL, 1);
    switch (heff_tag_of(v_v_24414)) {
    case TAG_VFun: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24414, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24424 = heff_field(v_v_24414, 0);
      heff_take_n(v_v_24414, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24413_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam32, 2, 1, (V[]){v_xs_24424})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24414, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24414);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24456 = heff_field(v_x1_24413, 0);
    V v_ru_24x1_24413_24Bug = heff_take_reuse_n(v_x1_24413, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24413_24Bug, TAG_Bug, 1, (V[]){v_what_24456});
  }
  default: return heff_nomatch(v_x1_24413);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args) {
  V v_d_24409 = args[0];
  V v_u_24410 = args[1];
  heff_drop(v_d_24409);
  heff_drop(v_u_24410);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam31_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args) {
  V v_vs_24473 = args[0];
  V v_t_24474 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_vs_24473)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24474});
}
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args) {
  V v_d_24469 = args[0];
  V v_f_24470 = args[1];
  V v_a_24468 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24471 = heff_tr(heff_call(v_f_24470, 1, (V[]){heff_dup(v_d_24469)}));
  switch (heff_tag_of(v_x1_24471)) {
  case TAG_Ok: {
    V v_v_24472 = heff_field(v_x1_24471, 0);
    heff_take_n(v_x1_24471, 1ULL, 1);
    return (g_heff_2ecompile_2einterp_2egenGo(v_d_24469, MK_INT(0LL), v_a_24468, v_v_24472, ((V)&g_heff_2ecompile_2einterp_2eprim_lam37_clo)));
  }
  case TAG_Abn: {
    heff_drop(v_d_24469);
    heff_drop(v_a_24468);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_24469);
    heff_drop(v_a_24468);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24475 = heff_field(v_x1_24471, 0);
    V v_ru_24x1_24471_24Bug = heff_take_reuse_n(v_x1_24471, 1ULL, 1);
    heff_drop(v_d_24469);
    heff_drop(v_a_24468);
    return heff_tag_at_n(v_ru_24x1_24471_24Bug, TAG_Bug, 1, (V[]){v_what_24475});
  }
  default: return heff_nomatch(v_x1_24471);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args) {
  V v_d_24460 = args[0];
  V v_a_24461 = args[1];
  V v_x1_24462 = heff_tr(heff_call(v_a_24461, 1, (V[]){v_d_24460}));
  switch (heff_tag_of(v_x1_24462)) {
  case TAG_Ok: {
    V v_v_24463 = heff_field(v_x1_24462, 0);
    V v_ru_24x1_24462_24Ok = heff_take_reuse_n(v_x1_24462, 1ULL, 1);
    switch (heff_tag_of(v_v_24463)) {
    case TAG_VFun: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24463, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24468 = heff_field(v_v_24463, 0);
      heff_take_n(v_v_24463, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24462_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam36, 2, 1, (V[]){v_a_24468})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24463, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24463, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24462_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24463);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24484 = heff_field(v_x1_24462, 0);
    V v_ru_24x1_24462_24Bug = heff_take_reuse_n(v_x1_24462, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24462_24Bug, TAG_Bug, 1, (V[]){v_what_24484});
  }
  default: return heff_nomatch(v_x1_24462);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args) {
  V v_d_24458 = args[0];
  V v_u_24459 = args[1];
  heff_drop(v_d_24458);
  heff_drop(v_u_24459);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam35_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args) {
  V v_d_24488 = args[0];
  V v_l_24489 = args[1];
  V v_x1_24490 = heff_tr(heff_call(v_l_24489, 1, (V[]){v_d_24488}));
  switch (heff_tag_of(v_x1_24490)) {
  case TAG_Ok: {
    V v_v_24491 = heff_field(v_x1_24490, 0);
    V v_ru_24x1_24490_24Ok = heff_take_reuse_n(v_x1_24490, 1ULL, 1);
    V v_t_24492 = (g_heff_2ecompile_2einterp_2efromListV(v_v_24491, NTAG(TAG_Nil)));
    V v_t_24493 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24492)});
    return heff_tag_at_n(v_ru_24x1_24490_24Ok, TAG_Ok, 1, (V[]){v_t_24493});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24494 = heff_field(v_x1_24490, 0);
    V v_ru_24x1_24490_24Bug = heff_take_reuse_n(v_x1_24490, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24490_24Bug, TAG_Bug, 1, (V[]){v_what_24494});
  }
  default: return heff_nomatch(v_x1_24490);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args) {
  V v_d_24486 = args[0];
  V v_u_24487 = args[1];
  heff_drop(v_d_24486);
  heff_drop(v_u_24487);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam39_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args) {
  V v_d_24498 = args[0];
  V v_a_24499 = args[1];
  V v_x1_24500 = heff_tr(heff_call(v_a_24499, 1, (V[]){v_d_24498}));
  switch (heff_tag_of(v_x1_24500)) {
  case TAG_Ok: {
    V v_v_24501 = heff_field(v_x1_24500, 0);
    V v_ru_24x1_24500_24Ok = heff_take_reuse_n(v_x1_24500, 1ULL, 1);
    switch (heff_tag_of(v_v_24501)) {
    case TAG_VFun: {
      heff_take_n(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24501, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24511 = heff_field(v_v_24501, 0);
      heff_take_n(v_v_24501, 1ULL, 1);
      V v_t_24512 = (g_heff_2ecompile_2einterp_2etoListV(heff_arrayToList(v_xs_24511)));
      return heff_tag_at_n(v_ru_24x1_24500_24Ok, TAG_Ok, 1, (V[]){v_t_24512});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24501, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24501, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24500_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24501);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24516 = heff_field(v_x1_24500, 0);
    V v_ru_24x1_24500_24Bug = heff_take_reuse_n(v_x1_24500, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24500_24Bug, TAG_Bug, 1, (V[]){v_what_24516});
  }
  default: return heff_nomatch(v_x1_24500);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args) {
  V v_d_24496 = args[0];
  V v_u_24497 = args[1];
  heff_drop(v_d_24496);
  heff_drop(v_u_24497);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam41_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args) {
  V v_d_24529 = args[0];
  V v_x_24530 = args[1];
  V v_a_24528 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24531 = heff_tr(heff_call(v_x_24530, 1, (V[]){v_d_24529}));
  switch (heff_tag_of(v_x1_24531)) {
  case TAG_Ok: {
    V v_v_24532 = heff_field(v_x1_24531, 0);
    V v_ru_24x1_24531_24Ok = heff_take_reuse_n(v_x1_24531, 1ULL, 1);
    V v_t_24533 = (g_list_2ereplicate(v_a_24528, v_v_24532));
    V v_t_24534 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24533)});
    return heff_tag_at_n(v_ru_24x1_24531_24Ok, TAG_Ok, 1, (V[]){v_t_24534});
  }
  case TAG_Abn: {
    heff_drop(v_a_24528);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24528);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24535 = heff_field(v_x1_24531, 0);
    V v_ru_24x1_24531_24Bug = heff_take_reuse_n(v_x1_24531, 1ULL, 1);
    heff_drop(v_a_24528);
    return heff_tag_at_n(v_ru_24x1_24531_24Bug, TAG_Bug, 1, (V[]){v_what_24535});
  }
  default: return heff_nomatch(v_x1_24531);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args) {
  V v_d_24520 = args[0];
  V v_a_24521 = args[1];
  V v_x1_24522 = heff_tr(heff_call(v_a_24521, 1, (V[]){v_d_24520}));
  switch (heff_tag_of(v_x1_24522)) {
  case TAG_Ok: {
    V v_v_24523 = heff_field(v_x1_24522, 0);
    V v_ru_24x1_24522_24Ok = heff_take_reuse_n(v_x1_24522, 1ULL, 1);
    switch (heff_tag_of(v_v_24523)) {
    case TAG_VFun: {
      heff_take_n(v_v_24523, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24522_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24523, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24522_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24523, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24522_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24528 = heff_field(v_v_24523, 0);
      heff_take_n(v_v_24523, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24522_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam44, 2, 1, (V[]){v_a_24528})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24523, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24522_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24523, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24522_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24523, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24522_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24523, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24522_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24523, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24522_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24523, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24522_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24523, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24522_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24522_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24523);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24544 = heff_field(v_x1_24522, 0);
    V v_ru_24x1_24522_24Bug = heff_take_reuse_n(v_x1_24522, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24522_24Bug, TAG_Bug, 1, (V[]){v_what_24544});
  }
  default: return heff_nomatch(v_x1_24522);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args) {
  V v_d_24518 = args[0];
  V v_u_24519 = args[1];
  heff_drop(v_d_24518);
  heff_drop(v_u_24519);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam43_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args) {
  V v_d_24571 = args[0];
  V v_a_24572 = args[1];
  V v_xs_24561 = heff_env(self)[0];
  V v_a_24570 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24573 = heff_tr(heff_call(v_a_24572, 1, (V[]){v_d_24571}));
  switch (heff_tag_of(v_x1_24573)) {
  case TAG_Ok: {
    V v_v_24574 = heff_field(v_x1_24573, 0);
    V v_ru_24x1_24573_24Ok = heff_take_reuse_n(v_x1_24573, 1ULL, 1);
    switch (heff_tag_of(v_v_24574)) {
    case TAG_VFun: {
      heff_take_n(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop(v_a_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop(v_a_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24574, 0ULL, 2);
      heff_drop(v_xs_24561);
      heff_drop(v_a_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24579 = heff_field(v_v_24574, 0);
      V v_ru_24v_24574_24VInt = heff_take_reuse_n(v_v_24574, 1ULL, 1);
      V v_t_24580 = (g_heff_2ecompile_2einterp_2esliceV(heff_arrayToList(v_xs_24561), v_a_24570, v_a_24579));
      V v_t_24581 = heff_tag_at_n(v_ru_24v_24574_24VInt, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24580)});
      return heff_tag_at_n(v_ru_24x1_24573_24Ok, TAG_Ok, 1, (V[]){v_t_24581});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop(v_a_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop(v_a_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop(v_a_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop(v_a_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop(v_a_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop(v_a_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24574, 0ULL, 2);
      heff_drop(v_xs_24561);
      heff_drop(v_a_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24561);
      heff_drop(v_a_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24574);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24561);
    heff_drop(v_a_24570);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24561);
    heff_drop(v_a_24570);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24590 = heff_field(v_x1_24573, 0);
    V v_ru_24x1_24573_24Bug = heff_take_reuse_n(v_x1_24573, 1ULL, 1);
    heff_drop(v_xs_24561);
    heff_drop(v_a_24570);
    return heff_tag_at_n(v_ru_24x1_24573_24Bug, TAG_Bug, 1, (V[]){v_what_24590});
  }
  default: return heff_nomatch(v_x1_24573);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args) {
  V v_d_24562 = args[0];
  V v_a_24563 = args[1];
  V v_xs_24561 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24564 = heff_tr(heff_call(v_a_24563, 1, (V[]){v_d_24562}));
  switch (heff_tag_of(v_x1_24564)) {
  case TAG_Ok: {
    V v_v_24565 = heff_field(v_x1_24564, 0);
    V v_ru_24x1_24564_24Ok = heff_take_reuse_n(v_x1_24564, 1ULL, 1);
    switch (heff_tag_of(v_v_24565)) {
    case TAG_VFun: {
      heff_take_n(v_v_24565, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop_cell(v_ru_24x1_24564_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24565, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop_cell(v_ru_24x1_24564_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24565, 0ULL, 2);
      heff_drop(v_xs_24561);
      heff_drop_cell(v_ru_24x1_24564_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24570 = heff_field(v_v_24565, 0);
      heff_take_n(v_v_24565, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24564_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam48, 2, 2, (V[]){v_xs_24561, v_a_24570})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24565, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop_cell(v_ru_24x1_24564_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24565, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop_cell(v_ru_24x1_24564_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24565, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop_cell(v_ru_24x1_24564_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24565, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop_cell(v_ru_24x1_24564_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24565, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop_cell(v_ru_24x1_24564_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24565, 0ULL, 1);
      heff_drop(v_xs_24561);
      heff_drop_cell(v_ru_24x1_24564_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24565, 0ULL, 2);
      heff_drop(v_xs_24561);
      heff_drop_cell(v_ru_24x1_24564_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24561);
      heff_drop_cell(v_ru_24x1_24564_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24565);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24561);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24561);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24599 = heff_field(v_x1_24564, 0);
    V v_ru_24x1_24564_24Bug = heff_take_reuse_n(v_x1_24564, 1ULL, 1);
    heff_drop(v_xs_24561);
    return heff_tag_at_n(v_ru_24x1_24564_24Bug, TAG_Bug, 1, (V[]){v_what_24599});
  }
  default: return heff_nomatch(v_x1_24564);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args) {
  V v_d_24548 = args[0];
  V v_a_24549 = args[1];
  V v_x1_24550 = heff_tr(heff_call(v_a_24549, 1, (V[]){v_d_24548}));
  switch (heff_tag_of(v_x1_24550)) {
  case TAG_Ok: {
    V v_v_24551 = heff_field(v_x1_24550, 0);
    V v_ru_24x1_24550_24Ok = heff_take_reuse_n(v_x1_24550, 1ULL, 1);
    switch (heff_tag_of(v_v_24551)) {
    case TAG_VFun: {
      heff_take_n(v_v_24551, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24550_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24551, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24550_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24551, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24550_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24551, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24550_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24551, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24550_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24551, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24550_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24551, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24550_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24551, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24550_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24561 = heff_field(v_v_24551, 0);
      heff_take_n(v_v_24551, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24550_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam47, 2, 1, (V[]){v_xs_24561})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24551, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24550_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24551, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24550_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24550_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24551);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24603 = heff_field(v_x1_24550, 0);
    V v_ru_24x1_24550_24Bug = heff_take_reuse_n(v_x1_24550, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24550_24Bug, TAG_Bug, 1, (V[]){v_what_24603});
  }
  default: return heff_nomatch(v_x1_24550);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args) {
  V v_d_24546 = args[0];
  V v_u_24547 = args[1];
  heff_drop(v_d_24546);
  heff_drop(v_u_24547);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam46_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args) {
  V v_d_24621 = args[0];
  V v_a_24622 = args[1];
  V v_xs_24620 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24623 = heff_tr(heff_call(v_a_24622, 1, (V[]){v_d_24621}));
  switch (heff_tag_of(v_x1_24623)) {
  case TAG_Ok: {
    V v_v_24624 = heff_field(v_x1_24623, 0);
    V v_ru_24x1_24623_24Ok = heff_take_reuse_n(v_x1_24623, 1ULL, 1);
    switch (heff_tag_of(v_v_24624)) {
    case TAG_VFun: {
      heff_take_n(v_v_24624, 0ULL, 1);
      heff_drop(v_xs_24620);
      heff_drop_cell(v_ru_24x1_24623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24624, 0ULL, 1);
      heff_drop(v_xs_24620);
      heff_drop_cell(v_ru_24x1_24623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24624, 0ULL, 2);
      heff_drop(v_xs_24620);
      heff_drop_cell(v_ru_24x1_24623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24624, 0ULL, 1);
      heff_drop(v_xs_24620);
      heff_drop_cell(v_ru_24x1_24623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24624, 0ULL, 1);
      heff_drop(v_xs_24620);
      heff_drop_cell(v_ru_24x1_24623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24624, 0ULL, 1);
      heff_drop(v_xs_24620);
      heff_drop_cell(v_ru_24x1_24623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24624, 0ULL, 1);
      heff_drop(v_xs_24620);
      heff_drop_cell(v_ru_24x1_24623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24624, 0ULL, 1);
      heff_drop(v_xs_24620);
      heff_drop_cell(v_ru_24x1_24623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24634 = heff_field(v_v_24624, 0);
      V v_ru_24v_24624_24VArr = heff_take_reuse_n(v_v_24624, 1ULL, 1);
      V v_t_24635 = (g_prelude_2e_2b_2b(heff_arrayToList(v_xs_24620), heff_arrayToList(v_xs_24634)));
      V v_t_24636 = heff_tag_at_n(v_ru_24v_24624_24VArr, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24635)});
      return heff_tag_at_n(v_ru_24x1_24623_24Ok, TAG_Ok, 1, (V[]){v_t_24636});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24624, 0ULL, 1);
      heff_drop(v_xs_24620);
      heff_drop_cell(v_ru_24x1_24623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24624, 0ULL, 2);
      heff_drop(v_xs_24620);
      heff_drop_cell(v_ru_24x1_24623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24620);
      heff_drop_cell(v_ru_24x1_24623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24624);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24620);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24620);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24640 = heff_field(v_x1_24623, 0);
    V v_ru_24x1_24623_24Bug = heff_take_reuse_n(v_x1_24623, 1ULL, 1);
    heff_drop(v_xs_24620);
    return heff_tag_at_n(v_ru_24x1_24623_24Bug, TAG_Bug, 1, (V[]){v_what_24640});
  }
  default: return heff_nomatch(v_x1_24623);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args) {
  V v_d_24607 = args[0];
  V v_a_24608 = args[1];
  V v_x1_24609 = heff_tr(heff_call(v_a_24608, 1, (V[]){v_d_24607}));
  switch (heff_tag_of(v_x1_24609)) {
  case TAG_Ok: {
    V v_v_24610 = heff_field(v_x1_24609, 0);
    V v_ru_24x1_24609_24Ok = heff_take_reuse_n(v_x1_24609, 1ULL, 1);
    switch (heff_tag_of(v_v_24610)) {
    case TAG_VFun: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24610, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24610, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24620 = heff_field(v_v_24610, 0);
      heff_take_n(v_v_24610, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24609_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam51, 2, 1, (V[]){v_xs_24620})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24610, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24610);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24644 = heff_field(v_x1_24609, 0);
    V v_ru_24x1_24609_24Bug = heff_take_reuse_n(v_x1_24609, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24609_24Bug, TAG_Bug, 1, (V[]){v_what_24644});
  }
  default: return heff_nomatch(v_x1_24609);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args) {
  V v_d_24605 = args[0];
  V v_u_24606 = args[1];
  heff_drop(v_d_24605);
  heff_drop(v_u_24606);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam50_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args) {
  V v_d_24647 = args[0];
  V v_a_24648 = args[1];
  V v_x1_24649 = heff_tr(heff_call(v_a_24648, 1, (V[]){v_d_24647}));
  switch (heff_tag_of(v_x1_24649)) {
  case TAG_Ok: {
    V v_v_24650 = heff_field(v_x1_24649, 0);
    V v_ru_24x1_24649_24Ok = heff_take_reuse_n(v_x1_24649, 1ULL, 1);
    switch (heff_tag_of(v_v_24650)) {
    case TAG_VFun: {
      heff_take_n(v_v_24650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24650, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24658 = heff_field(v_v_24650, 0);
      V v_ru_24v_24650_24VStr = heff_take_reuse_n(v_v_24650, 1ULL, 1);
      V v_t_24659 = heff_tag_at_n(v_ru_24v_24650_24VStr, TAG_VInt, 1, (V[]){heff_strLength(v_a_24658)});
      return heff_tag_at_n(v_ru_24x1_24649_24Ok, TAG_Ok, 1, (V[]){v_t_24659});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24650, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24650);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24665 = heff_field(v_x1_24649, 0);
    V v_ru_24x1_24649_24Bug = heff_take_reuse_n(v_x1_24649, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24649_24Bug, TAG_Bug, 1, (V[]){v_what_24665});
  }
  default: return heff_nomatch(v_x1_24649);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args) {
  V v_d_24688 = args[0];
  V v_a_24689 = args[1];
  V v_a_24678 = heff_env(self)[0];
  V v_a_24687 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24690 = heff_tr(heff_call(v_a_24689, 1, (V[]){v_d_24688}));
  switch (heff_tag_of(v_x1_24690)) {
  case TAG_Ok: {
    V v_v_24691 = heff_field(v_x1_24690, 0);
    V v_ru_24x1_24690_24Ok = heff_take_reuse_n(v_x1_24690, 1ULL, 1);
    switch (heff_tag_of(v_v_24691)) {
    case TAG_VFun: {
      heff_take_n(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24691, 0ULL, 2);
      heff_drop(v_a_24678);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24696 = heff_field(v_v_24691, 0);
      V v_ru_24v_24691_24VInt = heff_take_reuse_n(v_v_24691, 1ULL, 1);
      V v_t_24697 = heff_tag_at_n(v_ru_24v_24691_24VInt, TAG_VStr, 1, (V[]){heff_strSlice(v_a_24678, v_a_24687, v_a_24696)});
      return heff_tag_at_n(v_ru_24x1_24690_24Ok, TAG_Ok, 1, (V[]){v_t_24697});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24691, 0ULL, 2);
      heff_drop(v_a_24678);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24678);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24691);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24678);
    heff_drop(v_a_24687);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24678);
    heff_drop(v_a_24687);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24706 = heff_field(v_x1_24690, 0);
    V v_ru_24x1_24690_24Bug = heff_take_reuse_n(v_x1_24690, 1ULL, 1);
    heff_drop(v_a_24678);
    heff_drop(v_a_24687);
    return heff_tag_at_n(v_ru_24x1_24690_24Bug, TAG_Bug, 1, (V[]){v_what_24706});
  }
  default: return heff_nomatch(v_x1_24690);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args) {
  V v_d_24679 = args[0];
  V v_a_24680 = args[1];
  V v_a_24678 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24681 = heff_tr(heff_call(v_a_24680, 1, (V[]){v_d_24679}));
  switch (heff_tag_of(v_x1_24681)) {
  case TAG_Ok: {
    V v_v_24682 = heff_field(v_x1_24681, 0);
    V v_ru_24x1_24681_24Ok = heff_take_reuse_n(v_x1_24681, 1ULL, 1);
    switch (heff_tag_of(v_v_24682)) {
    case TAG_VFun: {
      heff_take_n(v_v_24682, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop_cell(v_ru_24x1_24681_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24682, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop_cell(v_ru_24x1_24681_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24682, 0ULL, 2);
      heff_drop(v_a_24678);
      heff_drop_cell(v_ru_24x1_24681_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24687 = heff_field(v_v_24682, 0);
      heff_take_n(v_v_24682, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24681_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam55, 2, 2, (V[]){v_a_24678, v_a_24687})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24682, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop_cell(v_ru_24x1_24681_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24682, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop_cell(v_ru_24x1_24681_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24682, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop_cell(v_ru_24x1_24681_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24682, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop_cell(v_ru_24x1_24681_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24682, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop_cell(v_ru_24x1_24681_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24682, 0ULL, 1);
      heff_drop(v_a_24678);
      heff_drop_cell(v_ru_24x1_24681_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24682, 0ULL, 2);
      heff_drop(v_a_24678);
      heff_drop_cell(v_ru_24x1_24681_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24678);
      heff_drop_cell(v_ru_24x1_24681_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24682);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24678);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24678);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24715 = heff_field(v_x1_24681, 0);
    V v_ru_24x1_24681_24Bug = heff_take_reuse_n(v_x1_24681, 1ULL, 1);
    heff_drop(v_a_24678);
    return heff_tag_at_n(v_ru_24x1_24681_24Bug, TAG_Bug, 1, (V[]){v_what_24715});
  }
  default: return heff_nomatch(v_x1_24681);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args) {
  V v_d_24667 = args[0];
  V v_a_24668 = args[1];
  V v_x1_24669 = heff_tr(heff_call(v_a_24668, 1, (V[]){v_d_24667}));
  switch (heff_tag_of(v_x1_24669)) {
  case TAG_Ok: {
    V v_v_24670 = heff_field(v_x1_24669, 0);
    V v_ru_24x1_24669_24Ok = heff_take_reuse_n(v_x1_24669, 1ULL, 1);
    switch (heff_tag_of(v_v_24670)) {
    case TAG_VFun: {
      heff_take_n(v_v_24670, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24669_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24670, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24669_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24670, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24669_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24670, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24669_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24670, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24669_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24670, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24669_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24678 = heff_field(v_v_24670, 0);
      heff_take_n(v_v_24670, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24669_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam54, 2, 1, (V[]){v_a_24678})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24670, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24669_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24670, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24669_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24670, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24669_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24670, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24669_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24669_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24670);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24721 = heff_field(v_x1_24669, 0);
    V v_ru_24x1_24669_24Bug = heff_take_reuse_n(v_x1_24669, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24669_24Bug, TAG_Bug, 1, (V[]){v_what_24721});
  }
  default: return heff_nomatch(v_x1_24669);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args) {
  V v_a_24723 = args[0];
  V v_b_24724 = args[1];
  V v_t_24726;
  if (heff_strEq_c(v_a_24723, v_b_24724)) {
    v_t_24726 = ((V)&g_heff_2ecompile_2einterp_2eprim_str61);
  } else {
    v_t_24726 = ((V)&g_heff_2ecompile_2einterp_2eprim_str62);
  }
  V v_t_24727 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24726, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24727});
}
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args) {
  V v_a_24729 = args[0];
  V v_b_24730 = args[1];
  V v_t_24732;
  if (heff_strLt_c(v_a_24729, v_b_24730)) {
    v_t_24732 = ((V)&g_heff_2ecompile_2einterp_2eprim_str64);
  } else {
    v_t_24732 = ((V)&g_heff_2ecompile_2einterp_2eprim_str65);
  }
  V v_t_24733 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24732, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24733});
}
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args) {
  V v_a_24735 = args[0];
  V v_b_24736 = args[1];
  V v_t_24739;
  if (heff_strLt_c_lent(v_a_24735, v_b_24736, 0)) {
    heff_drop(v_a_24735);
    heff_drop(v_b_24736);
    v_t_24739 = MK_INT(-1LL);
  } else {
    if (heff_strEq_c(v_a_24735, v_b_24736)) {
      v_t_24739 = MK_INT(0LL);
    } else {
      v_t_24739 = MK_INT(1LL);
    }
  }
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24739})});
}
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args) {
  V v_d_24741 = args[0];
  V v_a_24742 = args[1];
  V v_x1_24743 = heff_tr(heff_call(v_a_24742, 1, (V[]){v_d_24741}));
  switch (heff_tag_of(v_x1_24743)) {
  case TAG_Ok: {
    V v_v_24744 = heff_field(v_x1_24743, 0);
    V v_ru_24x1_24743_24Ok = heff_take_reuse_n(v_x1_24743, 1ULL, 1);
    switch (heff_tag_of(v_v_24744)) {
    case TAG_VFun: {
      heff_take_n(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24744, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24752 = heff_field(v_v_24744, 0);
      V v_ru_24v_24744_24VStr = heff_take_reuse_n(v_v_24744, 1ULL, 1);
      V v_t_24753 = (g_heff_2ecompile_2einterp_2ehashFrom(heff_dup(v_a_24752), MK_INT(0LL), heff_strLength(v_a_24752)));
      V v_t_24754 = (g_heff_2ecompile_2einterp_2efmix64(v_t_24753));
      V v_t_24755 = heff_tag_at_n(v_ru_24v_24744_24VStr, TAG_VInt, 1, (V[]){heff_intDiv(v_t_24754, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_24743_24Ok, TAG_Ok, 1, (V[]){v_t_24755});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24744, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24744);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24761 = heff_field(v_x1_24743, 0);
    V v_ru_24x1_24743_24Bug = heff_take_reuse_n(v_x1_24743, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24743_24Bug, TAG_Bug, 1, (V[]){v_what_24761});
  }
  default: return heff_nomatch(v_x1_24743);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args) {
  V v_d_24763 = args[0];
  V v_a_24764 = args[1];
  V v_x1_24765 = heff_tr(heff_call(v_a_24764, 1, (V[]){v_d_24763}));
  switch (heff_tag_of(v_x1_24765)) {
  case TAG_Ok: {
    V v_v_24766 = heff_field(v_x1_24765, 0);
    V v_ru_24x1_24765_24Ok = heff_take_reuse_n(v_x1_24765, 1ULL, 1);
    switch (heff_tag_of(v_v_24766)) {
    case TAG_VFun: {
      heff_take_n(v_v_24766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24766, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24771 = heff_field(v_v_24766, 0);
      V v_ru_24v_24766_24VInt = heff_take_reuse_n(v_v_24766, 1ULL, 1);
      V v_t_24772 = heff_intAdd(heff_intMod(v_a_24771, heff_dup(g_heff_2ecompile_2einterp_2eword64_get())), heff_dup(g_heff_2ecompile_2einterp_2eword64_get()));
      V v_t_24773 = (g_heff_2ecompile_2einterp_2efmix64(heff_intMod(v_t_24772, heff_dup(g_heff_2ecompile_2einterp_2eword64_get()))));
      V v_t_24774 = heff_tag_at_n(v_ru_24v_24766_24VInt, TAG_VInt, 1, (V[]){heff_intDiv(v_t_24773, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_24765_24Ok, TAG_Ok, 1, (V[]){v_t_24774});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24766, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24766);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24783 = heff_field(v_x1_24765, 0);
    V v_ru_24x1_24765_24Bug = heff_take_reuse_n(v_x1_24765, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24765_24Bug, TAG_Bug, 1, (V[]){v_what_24783});
  }
  default: return heff_nomatch(v_x1_24765);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args) {
  V v_d_24803 = args[0];
  V v_a_24804 = args[1];
  V v_a_24793 = heff_env(self)[0];
  V v_a_24802 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24805 = heff_tr(heff_call(v_a_24804, 1, (V[]){v_d_24803}));
  switch (heff_tag_of(v_x1_24805)) {
  case TAG_Ok: {
    V v_v_24806 = heff_field(v_x1_24805, 0);
    V v_ru_24x1_24805_24Ok = heff_take_reuse_n(v_x1_24805, 1ULL, 1);
    switch (heff_tag_of(v_v_24806)) {
    case TAG_VFun: {
      heff_take_n(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24806, 0ULL, 2);
      heff_drop(v_a_24793);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24811 = heff_field(v_v_24806, 0);
      heff_take_n(v_v_24806, 1ULL, 1);
      V v_t_24812 = (g_heff_2ecompile_2einterp_2etrieSlotOf(v_a_24793, v_a_24802, v_a_24811));
      return heff_tag_at_n(v_ru_24x1_24805_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24812})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24806, 0ULL, 2);
      heff_drop(v_a_24793);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24793);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24806);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24793);
    heff_drop(v_a_24802);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24793);
    heff_drop(v_a_24802);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24821 = heff_field(v_x1_24805, 0);
    V v_ru_24x1_24805_24Bug = heff_take_reuse_n(v_x1_24805, 1ULL, 1);
    heff_drop(v_a_24793);
    heff_drop(v_a_24802);
    return heff_tag_at_n(v_ru_24x1_24805_24Bug, TAG_Bug, 1, (V[]){v_what_24821});
  }
  default: return heff_nomatch(v_x1_24805);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args) {
  V v_d_24794 = args[0];
  V v_a_24795 = args[1];
  V v_a_24793 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24796 = heff_tr(heff_call(v_a_24795, 1, (V[]){v_d_24794}));
  switch (heff_tag_of(v_x1_24796)) {
  case TAG_Ok: {
    V v_v_24797 = heff_field(v_x1_24796, 0);
    V v_ru_24x1_24796_24Ok = heff_take_reuse_n(v_x1_24796, 1ULL, 1);
    switch (heff_tag_of(v_v_24797)) {
    case TAG_VFun: {
      heff_take_n(v_v_24797, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24797, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24797, 0ULL, 2);
      heff_drop(v_a_24793);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24802 = heff_field(v_v_24797, 0);
      heff_take_n(v_v_24797, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24796_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam63, 2, 2, (V[]){v_a_24793, v_a_24802})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24797, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24797, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24797, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24797, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24797, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24797, 0ULL, 1);
      heff_drop(v_a_24793);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24797, 0ULL, 2);
      heff_drop(v_a_24793);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24793);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24797);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24793);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24793);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24830 = heff_field(v_x1_24796, 0);
    V v_ru_24x1_24796_24Bug = heff_take_reuse_n(v_x1_24796, 1ULL, 1);
    heff_drop(v_a_24793);
    return heff_tag_at_n(v_ru_24x1_24796_24Bug, TAG_Bug, 1, (V[]){v_what_24830});
  }
  default: return heff_nomatch(v_x1_24796);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args) {
  V v_d_24785 = args[0];
  V v_a_24786 = args[1];
  V v_x1_24787 = heff_tr(heff_call(v_a_24786, 1, (V[]){v_d_24785}));
  switch (heff_tag_of(v_x1_24787)) {
  case TAG_Ok: {
    V v_v_24788 = heff_field(v_x1_24787, 0);
    V v_ru_24x1_24787_24Ok = heff_take_reuse_n(v_x1_24787, 1ULL, 1);
    switch (heff_tag_of(v_v_24788)) {
    case TAG_VFun: {
      heff_take_n(v_v_24788, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24788, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24788, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24793 = heff_field(v_v_24788, 0);
      heff_take_n(v_v_24788, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24787_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam62, 2, 1, (V[]){v_a_24793})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24788, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24788, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24788, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24788, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24788, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24788, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24788, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24787_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24788);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24839 = heff_field(v_x1_24787, 0);
    V v_ru_24x1_24787_24Bug = heff_take_reuse_n(v_x1_24787, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24787_24Bug, TAG_Bug, 1, (V[]){v_what_24839});
  }
  default: return heff_nomatch(v_x1_24787);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args) {
  V v_d_24843 = args[0];
  V v_a_24844 = args[1];
  V v_n_24841 = heff_env(self)[0];
  V v_a_24842 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24845 = heff_tr(heff_call(v_a_24844, 1, (V[]){v_d_24843}));
  switch (heff_tag_of(v_x1_24845)) {
  case TAG_Ok: {
    V v_v_24846 = heff_field(v_x1_24845, 0);
    V v_ru_24x1_24845_24Ok = heff_take_reuse_n(v_x1_24845, 1ULL, 1);
    switch (heff_tag_of(v_v_24846)) {
    case TAG_VFun: {
      heff_take_n(v_v_24846, 0ULL, 1);
      heff_drop(v_n_24841);
      heff_drop(v_a_24842);
      heff_drop_cell(v_ru_24x1_24845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24846, 0ULL, 1);
      heff_drop(v_n_24841);
      heff_drop(v_a_24842);
      heff_drop_cell(v_ru_24x1_24845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24846, 0ULL, 2);
      heff_drop(v_n_24841);
      heff_drop(v_a_24842);
      heff_drop_cell(v_ru_24x1_24845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24851 = heff_field(v_v_24846, 0);
      heff_take_n(v_v_24846, 1ULL, 1);
      V v_t_24853;
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_a_24851))) {
        v_t_24853 = v_a_24851;
      } else {
        heff_drop(v_a_24851);
        v_t_24853 = MK_INT(0LL);
      }
      V v_j_24854 = heff_strFind(v_n_24841, v_a_24842, v_t_24853);
      V v_t_24856;
      if (heff_intLt_c(heff_dup(v_j_24854), MK_INT(0LL))) {
        heff_drop(v_j_24854);
        v_t_24856 = MK_INT(-1LL);
      } else {
        v_t_24856 = v_j_24854;
      }
      return heff_tag_at_n(v_ru_24x1_24845_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24856})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24846, 0ULL, 1);
      heff_drop(v_n_24841);
      heff_drop(v_a_24842);
      heff_drop_cell(v_ru_24x1_24845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24846, 0ULL, 1);
      heff_drop(v_n_24841);
      heff_drop(v_a_24842);
      heff_drop_cell(v_ru_24x1_24845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24846, 0ULL, 1);
      heff_drop(v_n_24841);
      heff_drop(v_a_24842);
      heff_drop_cell(v_ru_24x1_24845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24846, 0ULL, 1);
      heff_drop(v_n_24841);
      heff_drop(v_a_24842);
      heff_drop_cell(v_ru_24x1_24845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24846, 0ULL, 1);
      heff_drop(v_n_24841);
      heff_drop(v_a_24842);
      heff_drop_cell(v_ru_24x1_24845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24846, 0ULL, 1);
      heff_drop(v_n_24841);
      heff_drop(v_a_24842);
      heff_drop_cell(v_ru_24x1_24845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24846, 0ULL, 2);
      heff_drop(v_n_24841);
      heff_drop(v_a_24842);
      heff_drop_cell(v_ru_24x1_24845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_n_24841);
      heff_drop(v_a_24842);
      heff_drop_cell(v_ru_24x1_24845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24846);
    }
  }
  case TAG_Abn: {
    heff_drop(v_n_24841);
    heff_drop(v_a_24842);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_n_24841);
    heff_drop(v_a_24842);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24865 = heff_field(v_x1_24845, 0);
    V v_ru_24x1_24845_24Bug = heff_take_reuse_n(v_x1_24845, 1ULL, 1);
    heff_drop(v_n_24841);
    heff_drop(v_a_24842);
    return heff_tag_at_n(v_ru_24x1_24845_24Bug, TAG_Bug, 1, (V[]){v_what_24865});
  }
  default: return heff_nomatch(v_x1_24845);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args) {
  V v_n_24841 = args[0];
  V v_a_24842 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam65, 2, 2, (V[]){v_n_24841, v_a_24842})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args) {
  V v_d_24879 = args[0];
  V v_a_24880 = args[1];
  V v_a_24878 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24881 = heff_tr(heff_call(v_a_24880, 1, (V[]){v_d_24879}));
  switch (heff_tag_of(v_x1_24881)) {
  case TAG_Ok: {
    V v_v_24882 = heff_field(v_x1_24881, 0);
    V v_ru_24x1_24881_24Ok = heff_take_reuse_n(v_x1_24881, 1ULL, 1);
    switch (heff_tag_of(v_v_24882)) {
    case TAG_VFun: {
      heff_take_n(v_v_24882, 0ULL, 1);
      heff_drop(v_a_24878);
      heff_drop_cell(v_ru_24x1_24881_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24882, 0ULL, 1);
      heff_drop(v_a_24878);
      heff_drop_cell(v_ru_24x1_24881_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24882, 0ULL, 2);
      heff_drop(v_a_24878);
      heff_drop_cell(v_ru_24x1_24881_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24887 = heff_field(v_v_24882, 0);
      V v_ru_24v_24882_24VInt = heff_take_reuse_n(v_v_24882, 1ULL, 1);
      V v_t_24888 = heff_tag_at_n(v_ru_24v_24882_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_24878, v_a_24887)});
      return heff_tag_at_n(v_ru_24x1_24881_24Ok, TAG_Ok, 1, (V[]){v_t_24888});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24882, 0ULL, 1);
      heff_drop(v_a_24878);
      heff_drop_cell(v_ru_24x1_24881_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24882, 0ULL, 1);
      heff_drop(v_a_24878);
      heff_drop_cell(v_ru_24x1_24881_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24882, 0ULL, 1);
      heff_drop(v_a_24878);
      heff_drop_cell(v_ru_24x1_24881_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24882, 0ULL, 1);
      heff_drop(v_a_24878);
      heff_drop_cell(v_ru_24x1_24881_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24882, 0ULL, 1);
      heff_drop(v_a_24878);
      heff_drop_cell(v_ru_24x1_24881_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24882, 0ULL, 1);
      heff_drop(v_a_24878);
      heff_drop_cell(v_ru_24x1_24881_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24882, 0ULL, 2);
      heff_drop(v_a_24878);
      heff_drop_cell(v_ru_24x1_24881_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24878);
      heff_drop_cell(v_ru_24x1_24881_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24882);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24878);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24878);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24897 = heff_field(v_x1_24881, 0);
    V v_ru_24x1_24881_24Bug = heff_take_reuse_n(v_x1_24881, 1ULL, 1);
    heff_drop(v_a_24878);
    return heff_tag_at_n(v_ru_24x1_24881_24Bug, TAG_Bug, 1, (V[]){v_what_24897});
  }
  default: return heff_nomatch(v_x1_24881);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args) {
  V v_d_24867 = args[0];
  V v_a_24868 = args[1];
  V v_x1_24869 = heff_tr(heff_call(v_a_24868, 1, (V[]){v_d_24867}));
  switch (heff_tag_of(v_x1_24869)) {
  case TAG_Ok: {
    V v_v_24870 = heff_field(v_x1_24869, 0);
    V v_ru_24x1_24869_24Ok = heff_take_reuse_n(v_x1_24869, 1ULL, 1);
    switch (heff_tag_of(v_v_24870)) {
    case TAG_VFun: {
      heff_take_n(v_v_24870, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24870, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24870, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24870, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24870, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24870, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24878 = heff_field(v_v_24870, 0);
      heff_take_n(v_v_24870, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24869_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam67, 2, 1, (V[]){v_a_24878})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24870, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24870, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24870, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24870, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24869_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24870);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24903 = heff_field(v_x1_24869, 0);
    V v_ru_24x1_24869_24Bug = heff_take_reuse_n(v_x1_24869, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24869_24Bug, TAG_Bug, 1, (V[]){v_what_24903});
  }
  default: return heff_nomatch(v_x1_24869);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args) {
  V v_d_24905 = args[0];
  V v_a_24906 = args[1];
  V v_x1_24907 = heff_tr(heff_call(v_a_24906, 1, (V[]){v_d_24905}));
  switch (heff_tag_of(v_x1_24907)) {
  case TAG_Ok: {
    V v_v_24908 = heff_field(v_x1_24907, 0);
    V v_ru_24x1_24907_24Ok = heff_take_reuse_n(v_x1_24907, 1ULL, 1);
    switch (heff_tag_of(v_v_24908)) {
    case TAG_VFun: {
      heff_take_n(v_v_24908, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24907_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24908, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24907_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24908, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24907_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24913 = heff_field(v_v_24908, 0);
      heff_take_n(v_v_24908, 1ULL, 1);
      V v_t_24914 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_a_24913)));
      return heff_tag_at_n(v_ru_24x1_24907_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_24914})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24908, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24907_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24908, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24907_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24908, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24907_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24908, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24907_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24908, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24907_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24908, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24907_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24908, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24907_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24907_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24908);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24923 = heff_field(v_x1_24907, 0);
    V v_ru_24x1_24907_24Bug = heff_take_reuse_n(v_x1_24907, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24907_24Bug, TAG_Bug, 1, (V[]){v_what_24923});
  }
  default: return heff_nomatch(v_x1_24907);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args) {
  V v_d_24937 = args[0];
  V v_a_24938 = args[1];
  V v_a_24936 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24939 = heff_tr(heff_call(v_a_24938, 1, (V[]){v_d_24937}));
  switch (heff_tag_of(v_x1_24939)) {
  case TAG_Ok: {
    V v_v_24940 = heff_field(v_x1_24939, 0);
    V v_ru_24x1_24939_24Ok = heff_take_reuse_n(v_x1_24939, 1ULL, 1);
    switch (heff_tag_of(v_v_24940)) {
    case TAG_VFun: {
      heff_take_n(v_v_24940, 0ULL, 1);
      heff_drop(v_a_24936);
      heff_drop_cell(v_ru_24x1_24939_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24940, 0ULL, 1);
      heff_drop(v_a_24936);
      heff_drop_cell(v_ru_24x1_24939_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24940, 0ULL, 2);
      heff_drop(v_a_24936);
      heff_drop_cell(v_ru_24x1_24939_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24945 = heff_field(v_v_24940, 0);
      heff_take_n(v_v_24940, 1ULL, 1);
      V v_t_24946 = heff_runeToInt(heff_strRuneAt(v_a_24936, v_a_24945));
      return heff_tag_at_n(v_ru_24x1_24939_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VRune, 1, (V[]){v_t_24946})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24940, 0ULL, 1);
      heff_drop(v_a_24936);
      heff_drop_cell(v_ru_24x1_24939_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24940, 0ULL, 1);
      heff_drop(v_a_24936);
      heff_drop_cell(v_ru_24x1_24939_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24940, 0ULL, 1);
      heff_drop(v_a_24936);
      heff_drop_cell(v_ru_24x1_24939_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24940, 0ULL, 1);
      heff_drop(v_a_24936);
      heff_drop_cell(v_ru_24x1_24939_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24940, 0ULL, 1);
      heff_drop(v_a_24936);
      heff_drop_cell(v_ru_24x1_24939_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24940, 0ULL, 1);
      heff_drop(v_a_24936);
      heff_drop_cell(v_ru_24x1_24939_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24940, 0ULL, 2);
      heff_drop(v_a_24936);
      heff_drop_cell(v_ru_24x1_24939_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24936);
      heff_drop_cell(v_ru_24x1_24939_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24940);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24936);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24936);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24955 = heff_field(v_x1_24939, 0);
    V v_ru_24x1_24939_24Bug = heff_take_reuse_n(v_x1_24939, 1ULL, 1);
    heff_drop(v_a_24936);
    return heff_tag_at_n(v_ru_24x1_24939_24Bug, TAG_Bug, 1, (V[]){v_what_24955});
  }
  default: return heff_nomatch(v_x1_24939);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args) {
  V v_d_24925 = args[0];
  V v_a_24926 = args[1];
  V v_x1_24927 = heff_tr(heff_call(v_a_24926, 1, (V[]){v_d_24925}));
  switch (heff_tag_of(v_x1_24927)) {
  case TAG_Ok: {
    V v_v_24928 = heff_field(v_x1_24927, 0);
    V v_ru_24x1_24927_24Ok = heff_take_reuse_n(v_x1_24927, 1ULL, 1);
    switch (heff_tag_of(v_v_24928)) {
    case TAG_VFun: {
      heff_take_n(v_v_24928, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24928, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24928, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24928, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24928, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24928, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24936 = heff_field(v_v_24928, 0);
      heff_take_n(v_v_24928, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24927_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam70, 2, 1, (V[]){v_a_24936})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24928, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24928, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24928, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24928, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24928);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24961 = heff_field(v_x1_24927, 0);
    V v_ru_24x1_24927_24Bug = heff_take_reuse_n(v_x1_24927, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24927_24Bug, TAG_Bug, 1, (V[]){v_what_24961});
  }
  default: return heff_nomatch(v_x1_24927);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args) {
  V v_d_24975 = args[0];
  V v_a_24976 = args[1];
  V v_a_24974 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24977 = heff_tr(heff_call(v_a_24976, 1, (V[]){v_d_24975}));
  switch (heff_tag_of(v_x1_24977)) {
  case TAG_Ok: {
    V v_v_24978 = heff_field(v_x1_24977, 0);
    V v_ru_24x1_24977_24Ok = heff_take_reuse_n(v_x1_24977, 1ULL, 1);
    switch (heff_tag_of(v_v_24978)) {
    case TAG_VFun: {
      heff_take_n(v_v_24978, 0ULL, 1);
      heff_drop(v_a_24974);
      heff_drop_cell(v_ru_24x1_24977_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24978, 0ULL, 1);
      heff_drop(v_a_24974);
      heff_drop_cell(v_ru_24x1_24977_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24978, 0ULL, 2);
      heff_drop(v_a_24974);
      heff_drop_cell(v_ru_24x1_24977_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24983 = heff_field(v_v_24978, 0);
      V v_ru_24v_24978_24VInt = heff_take_reuse_n(v_v_24978, 1ULL, 1);
      V v_t_24984 = heff_tag_at_n(v_ru_24v_24978_24VInt, TAG_VInt, 1, (V[]){heff_strRuneWidth(v_a_24974, v_a_24983)});
      return heff_tag_at_n(v_ru_24x1_24977_24Ok, TAG_Ok, 1, (V[]){v_t_24984});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24978, 0ULL, 1);
      heff_drop(v_a_24974);
      heff_drop_cell(v_ru_24x1_24977_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24978, 0ULL, 1);
      heff_drop(v_a_24974);
      heff_drop_cell(v_ru_24x1_24977_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24978, 0ULL, 1);
      heff_drop(v_a_24974);
      heff_drop_cell(v_ru_24x1_24977_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24978, 0ULL, 1);
      heff_drop(v_a_24974);
      heff_drop_cell(v_ru_24x1_24977_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24978, 0ULL, 1);
      heff_drop(v_a_24974);
      heff_drop_cell(v_ru_24x1_24977_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24978, 0ULL, 1);
      heff_drop(v_a_24974);
      heff_drop_cell(v_ru_24x1_24977_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24978, 0ULL, 2);
      heff_drop(v_a_24974);
      heff_drop_cell(v_ru_24x1_24977_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24974);
      heff_drop_cell(v_ru_24x1_24977_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24978);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24974);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24974);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24993 = heff_field(v_x1_24977, 0);
    V v_ru_24x1_24977_24Bug = heff_take_reuse_n(v_x1_24977, 1ULL, 1);
    heff_drop(v_a_24974);
    return heff_tag_at_n(v_ru_24x1_24977_24Bug, TAG_Bug, 1, (V[]){v_what_24993});
  }
  default: return heff_nomatch(v_x1_24977);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args) {
  V v_d_24963 = args[0];
  V v_a_24964 = args[1];
  V v_x1_24965 = heff_tr(heff_call(v_a_24964, 1, (V[]){v_d_24963}));
  switch (heff_tag_of(v_x1_24965)) {
  case TAG_Ok: {
    V v_v_24966 = heff_field(v_x1_24965, 0);
    V v_ru_24x1_24965_24Ok = heff_take_reuse_n(v_x1_24965, 1ULL, 1);
    switch (heff_tag_of(v_v_24966)) {
    case TAG_VFun: {
      heff_take_n(v_v_24966, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24965_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24966, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24965_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24966, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24965_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24966, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24965_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24966, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24965_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24966, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24965_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24974 = heff_field(v_v_24966, 0);
      heff_take_n(v_v_24966, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24965_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam72, 2, 1, (V[]){v_a_24974})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24966, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24965_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24966, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24965_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24966, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24965_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24966, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24965_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24965_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24966);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24999 = heff_field(v_x1_24965, 0);
    V v_ru_24x1_24965_24Bug = heff_take_reuse_n(v_x1_24965, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24965_24Bug, TAG_Bug, 1, (V[]){v_what_24999});
  }
  default: return heff_nomatch(v_x1_24965);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args) {
  V v_d_241001 = args[0];
  V v_a_241002 = args[1];
  V v_x1_241003 = heff_tr(heff_call(v_a_241002, 1, (V[]){v_d_241001}));
  switch (heff_tag_of(v_x1_241003)) {
  case TAG_Ok: {
    V v_v_241004 = heff_field(v_x1_241003, 0);
    V v_ru_24x1_241003_24Ok = heff_take_reuse_n(v_x1_241003, 1ULL, 1);
    switch (heff_tag_of(v_v_241004)) {
    case TAG_VFun: {
      heff_take_n(v_v_241004, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241004, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241004, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241004, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241004, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241004, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241012 = heff_field(v_v_241004, 0);
      V v_ru_24v_241004_24VStr = heff_take_reuse_n(v_v_241004, 1ULL, 1);
      V v_t_241013 = heff_tag_at_n(v_ru_24v_241004_24VStr, TAG_VInt, 1, (V[]){heff_strRuneCount(v_a_241012)});
      return heff_tag_at_n(v_ru_24x1_241003_24Ok, TAG_Ok, 1, (V[]){v_t_241013});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241004, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241004, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241004, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241004, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241003_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241004);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241019 = heff_field(v_x1_241003, 0);
    V v_ru_24x1_241003_24Bug = heff_take_reuse_n(v_x1_241003, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241003_24Bug, TAG_Bug, 1, (V[]){v_what_241019});
  }
  default: return heff_nomatch(v_x1_241003);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args) {
  V v_d_241021 = args[0];
  V v_a_241022 = args[1];
  V v_x1_241023 = heff_tr(heff_call(v_a_241022, 1, (V[]){v_d_241021}));
  switch (heff_tag_of(v_x1_241023)) {
  case TAG_Ok: {
    V v_v_241024 = heff_field(v_x1_241023, 0);
    V v_ru_24x1_241023_24Ok = heff_take_reuse_n(v_x1_241023, 1ULL, 1);
    switch (heff_tag_of(v_v_241024)) {
    case TAG_VFun: {
      heff_take_n(v_v_241024, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241023_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241024, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241023_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241024, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241023_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241024, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241023_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241024, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241023_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241024, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241023_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241032 = heff_field(v_v_241024, 0);
      heff_take_n(v_v_241024, 1ULL, 1);
      V v_t_241033 = heff_strOfRunes(heff_strRunes(v_a_241032));
      return heff_tag_at_n(v_ru_24x1_241023_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_241033})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241024, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241023_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241024, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241023_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241024, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241023_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241024, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241023_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241023_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241024);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241039 = heff_field(v_x1_241023, 0);
    V v_ru_24x1_241023_24Bug = heff_take_reuse_n(v_x1_241023, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241023_24Bug, TAG_Bug, 1, (V[]){v_what_241039});
  }
  default: return heff_nomatch(v_x1_241023);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args) {
  V v_d_241041 = args[0];
  V v_a_241042 = args[1];
  V v_x1_241043 = heff_tr(heff_call(v_a_241042, 1, (V[]){v_d_241041}));
  switch (heff_tag_of(v_x1_241043)) {
  case TAG_Ok: {
    V v_v_241044 = heff_field(v_x1_241043, 0);
    V v_ru_24x1_241043_24Ok = heff_take_reuse_n(v_x1_241043, 1ULL, 1);
    switch (heff_tag_of(v_v_241044)) {
    case TAG_VFun: {
      heff_take_n(v_v_241044, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241043_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241044, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241043_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241044, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241043_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241044, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241043_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241044, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241043_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241044, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241043_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241052 = heff_field(v_v_241044, 0);
      heff_take_n(v_v_241044, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241043_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_a_241052})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241044, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241043_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241044, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241043_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241044, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241043_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241044, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241043_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241043_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241044);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241058 = heff_field(v_x1_241043, 0);
    V v_ru_24x1_241043_24Bug = heff_take_reuse_n(v_x1_241043, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241043_24Bug, TAG_Bug, 1, (V[]){v_what_241058});
  }
  default: return heff_nomatch(v_x1_241043);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args) {
  V v_d_241060 = args[0];
  V v_a_241061 = args[1];
  V v_x1_241062 = heff_tr(heff_call(v_a_241061, 1, (V[]){v_d_241060}));
  switch (heff_tag_of(v_x1_241062)) {
  case TAG_Ok: {
    V v_v_241063 = heff_field(v_x1_241062, 0);
    V v_ru_24x1_241062_24Ok = heff_take_reuse_n(v_x1_241062, 1ULL, 1);
    switch (heff_tag_of(v_v_241063)) {
    case TAG_VFun: {
      heff_take_n(v_v_241063, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241062_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241063, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241062_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241063, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241062_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241063, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241062_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241063, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241062_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241063, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241062_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241063, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241062_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241063, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241062_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241063, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241062_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241074 = heff_field(v_v_241063, 0);
      V v_ru_24v_241063_24VBytes = heff_take_reuse_n(v_v_241063, 1ULL, 1);
      V v_t_241075 = heff_tag_at_n(v_ru_24v_241063_24VBytes, TAG_VInt, 1, (V[]){heff_strLength(v_a_241074)});
      return heff_tag_at_n(v_ru_24x1_241062_24Ok, TAG_Ok, 1, (V[]){v_t_241075});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241063, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241062_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241062_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241063);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241078 = heff_field(v_x1_241062, 0);
    V v_ru_24x1_241062_24Bug = heff_take_reuse_n(v_x1_241062, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241062_24Bug, TAG_Bug, 1, (V[]){v_what_241078});
  }
  default: return heff_nomatch(v_x1_241062);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args) {
  V v_d_241095 = args[0];
  V v_a_241096 = args[1];
  V v_a_241094 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241097 = heff_tr(heff_call(v_a_241096, 1, (V[]){v_d_241095}));
  switch (heff_tag_of(v_x1_241097)) {
  case TAG_Ok: {
    V v_v_241098 = heff_field(v_x1_241097, 0);
    V v_ru_24x1_241097_24Ok = heff_take_reuse_n(v_x1_241097, 1ULL, 1);
    switch (heff_tag_of(v_v_241098)) {
    case TAG_VFun: {
      heff_take_n(v_v_241098, 0ULL, 1);
      heff_drop(v_a_241094);
      heff_drop_cell(v_ru_24x1_241097_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241098, 0ULL, 1);
      heff_drop(v_a_241094);
      heff_drop_cell(v_ru_24x1_241097_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241098, 0ULL, 2);
      heff_drop(v_a_241094);
      heff_drop_cell(v_ru_24x1_241097_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241103 = heff_field(v_v_241098, 0);
      V v_ru_24v_241098_24VInt = heff_take_reuse_n(v_v_241098, 1ULL, 1);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_a_241103))) {
        if (heff_intLt_c(heff_dup(v_a_241103), heff_strLength_lent(v_a_241094, 0))) {
          V v_t_241106 = heff_tag_at_n(v_ru_24v_241098_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_241094, v_a_241103)});
          return heff_tag_at_n(v_ru_24x1_241097_24Ok, TAG_Ok, 1, (V[]){v_t_241106});
        } else {
          heff_drop(v_a_241094);
          heff_drop_cell(v_ru_24x1_241097_24Ok, 1);
          heff_drop(v_a_241103);
          heff_drop_cell(v_ru_24v_241098_24VInt, 1);
          return NTAG(TAG_Abn);
        }
      } else {
        heff_drop(v_a_241094);
        heff_drop_cell(v_ru_24x1_241097_24Ok, 1);
        heff_drop(v_a_241103);
        heff_drop_cell(v_ru_24v_241098_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241098, 0ULL, 1);
      heff_drop(v_a_241094);
      heff_drop_cell(v_ru_24x1_241097_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241098, 0ULL, 1);
      heff_drop(v_a_241094);
      heff_drop_cell(v_ru_24x1_241097_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241098, 0ULL, 1);
      heff_drop(v_a_241094);
      heff_drop_cell(v_ru_24x1_241097_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241098, 0ULL, 1);
      heff_drop(v_a_241094);
      heff_drop_cell(v_ru_24x1_241097_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241098, 0ULL, 1);
      heff_drop(v_a_241094);
      heff_drop_cell(v_ru_24x1_241097_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241098, 0ULL, 1);
      heff_drop(v_a_241094);
      heff_drop_cell(v_ru_24x1_241097_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241098, 0ULL, 2);
      heff_drop(v_a_241094);
      heff_drop_cell(v_ru_24x1_241097_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241094);
      heff_drop_cell(v_ru_24x1_241097_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241098);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241094);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241094);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241115 = heff_field(v_x1_241097, 0);
    V v_ru_24x1_241097_24Bug = heff_take_reuse_n(v_x1_241097, 1ULL, 1);
    heff_drop(v_a_241094);
    return heff_tag_at_n(v_ru_24x1_241097_24Bug, TAG_Bug, 1, (V[]){v_what_241115});
  }
  default: return heff_nomatch(v_x1_241097);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args) {
  V v_d_241080 = args[0];
  V v_a_241081 = args[1];
  V v_x1_241082 = heff_tr(heff_call(v_a_241081, 1, (V[]){v_d_241080}));
  switch (heff_tag_of(v_x1_241082)) {
  case TAG_Ok: {
    V v_v_241083 = heff_field(v_x1_241082, 0);
    V v_ru_24x1_241082_24Ok = heff_take_reuse_n(v_x1_241082, 1ULL, 1);
    switch (heff_tag_of(v_v_241083)) {
    case TAG_VFun: {
      heff_take_n(v_v_241083, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241082_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241083, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241082_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241083, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241082_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241083, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241082_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241083, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241082_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241083, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241082_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241083, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241082_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241083, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241082_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241083, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241082_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241094 = heff_field(v_v_241083, 0);
      heff_take_n(v_v_241083, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241082_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam78, 2, 1, (V[]){v_a_241094})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241083, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241082_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241082_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241083);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241118 = heff_field(v_x1_241082, 0);
    V v_ru_24x1_241082_24Bug = heff_take_reuse_n(v_x1_241082, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241082_24Bug, TAG_Bug, 1, (V[]){v_what_241118});
  }
  default: return heff_nomatch(v_x1_241082);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args) {
  V v_d_241144 = args[0];
  V v_a_241145 = args[1];
  V v_a_241134 = heff_env(self)[0];
  V v_a_241143 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241146 = heff_tr(heff_call(v_a_241145, 1, (V[]){v_d_241144}));
  switch (heff_tag_of(v_x1_241146)) {
  case TAG_Ok: {
    V v_v_241147 = heff_field(v_x1_241146, 0);
    V v_ru_24x1_241146_24Ok = heff_take_reuse_n(v_x1_241146, 1ULL, 1);
    switch (heff_tag_of(v_v_241147)) {
    case TAG_VFun: {
      heff_take_n(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241147, 0ULL, 2);
      heff_drop(v_a_241134);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241152 = heff_field(v_v_241147, 0);
      V v_ru_24v_241147_24VInt = heff_take_reuse_n(v_v_241147, 1ULL, 1);
      V v_t_241153 = heff_tag_at_n(v_ru_24v_241147_24VInt, TAG_VBytes, 1, (V[]){heff_strSlice(v_a_241134, v_a_241143, v_a_241152)});
      return heff_tag_at_n(v_ru_24x1_241146_24Ok, TAG_Ok, 1, (V[]){v_t_241153});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241147, 0ULL, 2);
      heff_drop(v_a_241134);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241134);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241147);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241134);
    heff_drop(v_a_241143);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241134);
    heff_drop(v_a_241143);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241162 = heff_field(v_x1_241146, 0);
    V v_ru_24x1_241146_24Bug = heff_take_reuse_n(v_x1_241146, 1ULL, 1);
    heff_drop(v_a_241134);
    heff_drop(v_a_241143);
    return heff_tag_at_n(v_ru_24x1_241146_24Bug, TAG_Bug, 1, (V[]){v_what_241162});
  }
  default: return heff_nomatch(v_x1_241146);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args) {
  V v_d_241135 = args[0];
  V v_a_241136 = args[1];
  V v_a_241134 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241137 = heff_tr(heff_call(v_a_241136, 1, (V[]){v_d_241135}));
  switch (heff_tag_of(v_x1_241137)) {
  case TAG_Ok: {
    V v_v_241138 = heff_field(v_x1_241137, 0);
    V v_ru_24x1_241137_24Ok = heff_take_reuse_n(v_x1_241137, 1ULL, 1);
    switch (heff_tag_of(v_v_241138)) {
    case TAG_VFun: {
      heff_take_n(v_v_241138, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop_cell(v_ru_24x1_241137_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241138, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop_cell(v_ru_24x1_241137_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241138, 0ULL, 2);
      heff_drop(v_a_241134);
      heff_drop_cell(v_ru_24x1_241137_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241143 = heff_field(v_v_241138, 0);
      heff_take_n(v_v_241138, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241137_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam81, 2, 2, (V[]){v_a_241134, v_a_241143})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241138, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop_cell(v_ru_24x1_241137_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241138, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop_cell(v_ru_24x1_241137_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241138, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop_cell(v_ru_24x1_241137_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241138, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop_cell(v_ru_24x1_241137_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241138, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop_cell(v_ru_24x1_241137_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241138, 0ULL, 1);
      heff_drop(v_a_241134);
      heff_drop_cell(v_ru_24x1_241137_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241138, 0ULL, 2);
      heff_drop(v_a_241134);
      heff_drop_cell(v_ru_24x1_241137_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241134);
      heff_drop_cell(v_ru_24x1_241137_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241138);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241134);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241134);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241171 = heff_field(v_x1_241137, 0);
    V v_ru_24x1_241137_24Bug = heff_take_reuse_n(v_x1_241137, 1ULL, 1);
    heff_drop(v_a_241134);
    return heff_tag_at_n(v_ru_24x1_241137_24Bug, TAG_Bug, 1, (V[]){v_what_241171});
  }
  default: return heff_nomatch(v_x1_241137);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args) {
  V v_d_241120 = args[0];
  V v_a_241121 = args[1];
  V v_x1_241122 = heff_tr(heff_call(v_a_241121, 1, (V[]){v_d_241120}));
  switch (heff_tag_of(v_x1_241122)) {
  case TAG_Ok: {
    V v_v_241123 = heff_field(v_x1_241122, 0);
    V v_ru_24x1_241122_24Ok = heff_take_reuse_n(v_x1_241122, 1ULL, 1);
    switch (heff_tag_of(v_v_241123)) {
    case TAG_VFun: {
      heff_take_n(v_v_241123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241123, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241123, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241134 = heff_field(v_v_241123, 0);
      heff_take_n(v_v_241123, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241122_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam80, 2, 1, (V[]){v_a_241134})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241123, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241122_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241123);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241174 = heff_field(v_x1_241122, 0);
    V v_ru_24x1_241122_24Bug = heff_take_reuse_n(v_x1_241122, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241122_24Bug, TAG_Bug, 1, (V[]){v_what_241174});
  }
  default: return heff_nomatch(v_x1_241122);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args) {
  V v_d_241177 = args[0];
  V v_l_241178 = args[1];
  V v_x1_241179 = heff_tr(heff_call(v_l_241178, 1, (V[]){v_d_241177}));
  switch (heff_tag_of(v_x1_241179)) {
  case TAG_Ok: {
    V v_v_241180 = heff_field(v_x1_241179, 0);
    heff_take_n(v_x1_241179, 1ULL, 1);
    V v_t_241181 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241180, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_241181; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str83); V r_ = (g_heff_2ecompile_2einterp_2ebytesJoined(a_0, a_1)); heff_drop(v_t_241181); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241182 = heff_field(v_x1_241179, 0);
    V v_ru_24x1_241179_24Bug = heff_take_reuse_n(v_x1_241179, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241179_24Bug, TAG_Bug, 1, (V[]){v_what_241182});
  }
  default: return heff_nomatch(v_x1_241179);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args) {
  V v_a_241184 = args[0];
  V v_b_241185 = args[1];
  V v_t_241187;
  if (heff_strEq_c(v_a_241184, v_b_241185)) {
    v_t_241187 = ((V)&g_heff_2ecompile_2einterp_2eprim_str85);
  } else {
    v_t_241187 = ((V)&g_heff_2ecompile_2einterp_2eprim_str86);
  }
  V v_t_241188 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241187, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241188});
}
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args) {
  V v_d_241190 = args[0];
  V v_l_241191 = args[1];
  V v_x1_241192 = heff_tr(heff_call(v_l_241191, 1, (V[]){v_d_241190}));
  switch (heff_tag_of(v_x1_241192)) {
  case TAG_Ok: {
    V v_v_241193 = heff_field(v_x1_241192, 0);
    V v_ru_24x1_241192_24Ok = heff_take_reuse_n(v_x1_241192, 1ULL, 1);
    V v_t_241194 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241193, NTAG(TAG_Nil)));
    V v_t_241195 = ({ V a_0 = v_t_241194; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str88); V r_ = (g_heff_2ecompile_2einterp_2ebyteString(a_0, a_1)); heff_drop(v_t_241194); r_; });
    return heff_tag_at_n(v_ru_24x1_241192_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_t_241195})});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241196 = heff_field(v_x1_241192, 0);
    V v_ru_24x1_241192_24Bug = heff_take_reuse_n(v_x1_241192, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241192_24Bug, TAG_Bug, 1, (V[]){v_what_241196});
  }
  default: return heff_nomatch(v_x1_241192);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args) {
  V v_d_241198 = args[0];
  V v_a_241199 = args[1];
  V v_x1_241200 = heff_tr(heff_call(v_a_241199, 1, (V[]){v_d_241198}));
  switch (heff_tag_of(v_x1_241200)) {
  case TAG_Ok: {
    V v_v_241201 = heff_field(v_x1_241200, 0);
    V v_ru_24x1_241200_24Ok = heff_take_reuse_n(v_x1_241200, 1ULL, 1);
    switch (heff_tag_of(v_v_241201)) {
    case TAG_VFun: {
      heff_take_n(v_v_241201, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241201, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241201, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241201, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241201, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241201, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241201, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241201, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241201, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241212 = heff_field(v_v_241201, 0);
      heff_take_n(v_v_241201, 1ULL, 1);
      V v_t_241213 = heff_intSub(heff_strLength_lent(v_a_241212, 0), MK_INT(1LL));
      V v_t_241214 = (g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(v_a_241212, MK_INT(0LL), v_t_241213));
      return heff_tag_at_n(v_ru_24x1_241200_24Ok, TAG_Ok, 1, (V[]){v_t_241214});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241201, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241201);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241217 = heff_field(v_x1_241200, 0);
    V v_ru_24x1_241200_24Bug = heff_take_reuse_n(v_x1_241200, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241200_24Bug, TAG_Bug, 1, (V[]){v_what_241217});
  }
  default: return heff_nomatch(v_x1_241200);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args) {
  V v_d_241219 = args[0];
  V v_a_241220 = args[1];
  V v_x1_241221 = heff_tr(heff_call(v_a_241220, 1, (V[]){v_d_241219}));
  switch (heff_tag_of(v_x1_241221)) {
  case TAG_Ok: {
    V v_v_241222 = heff_field(v_x1_241221, 0);
    V v_ru_24x1_241221_24Ok = heff_take_reuse_n(v_x1_241221, 1ULL, 1);
    switch (heff_tag_of(v_v_241222)) {
    case TAG_VFun: {
      heff_take_n(v_v_241222, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241221_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241222, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241221_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241222, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241221_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241222, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241221_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241222, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241221_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241222, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241221_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241230 = heff_field(v_v_241222, 0);
      heff_take_n(v_v_241222, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241221_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_a_241230})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241222, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241221_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241222, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241221_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241222, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241221_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241222, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241221_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241221_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241222);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241236 = heff_field(v_x1_241221, 0);
    V v_ru_24x1_241221_24Bug = heff_take_reuse_n(v_x1_241221, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241221_24Bug, TAG_Bug, 1, (V[]){v_what_241236});
  }
  default: return heff_nomatch(v_x1_241221);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args) {
  V v_d_241238 = args[0];
  V v_a_241239 = args[1];
  V v_x1_241240 = heff_tr(heff_call(v_a_241239, 1, (V[]){v_d_241238}));
  switch (heff_tag_of(v_x1_241240)) {
  case TAG_Ok: {
    V v_v_241241 = heff_field(v_x1_241240, 0);
    V v_ru_24x1_241240_24Ok = heff_take_reuse_n(v_x1_241240, 1ULL, 1);
    switch (heff_tag_of(v_v_241241)) {
    case TAG_VFun: {
      heff_take_n(v_v_241241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241240_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241240_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241240_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241240_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241240_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241240_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241240_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241240_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241240_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241252 = heff_field(v_v_241241, 0);
      heff_take_n(v_v_241241, 1ULL, 1);
      V v_t_241253 = (g_rune_2evalidFrom(heff_dup(v_a_241252), MK_INT(0LL)));
      V v_t_241254;
      if ((heff_dup(v_t_241253) == NTAG(TAG_True))) {
        heff_drop(v_t_241253);
        v_t_241254 = v_a_241252;
      } else {
        heff_drop(v_t_241253);
        v_t_241254 = heff_strOfRunes(heff_strRunes(v_a_241252));
      }
      return heff_tag_at_n(v_ru_24x1_241240_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_241254})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241240_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241240_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241241);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241257 = heff_field(v_x1_241240, 0);
    V v_ru_24x1_241240_24Bug = heff_take_reuse_n(v_x1_241240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241240_24Bug, TAG_Bug, 1, (V[]){v_what_241257});
  }
  default: return heff_nomatch(v_x1_241240);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args) {
  V v_d_241292 = args[0];
  V v_a_241293 = args[1];
  V v_a_241273 = heff_env(self)[0];
  V v_a_241282 = heff_env(self)[1];
  V v_a_241291 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241294 = heff_tr(heff_call(v_a_241293, 1, (V[]){v_d_241292}));
  switch (heff_tag_of(v_x1_241294)) {
  case TAG_Ok: {
    V v_v_241295 = heff_field(v_x1_241294, 0);
    heff_take_n(v_x1_241294, 1ULL, 1);
    switch (heff_tag_of(v_v_241295)) {
    case TAG_VFun: {
      heff_take_n(v_v_241295, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop(v_a_241291);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241295, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop(v_a_241291);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241295, 0ULL, 2);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop(v_a_241291);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241300 = heff_field(v_v_241295, 0);
      heff_take_n(v_v_241295, 1ULL, 1);
      V v_t_241301 = heff_intMul(heff_strLength_lent(v_a_241273, 0), MK_INT(8LL));
      return (g_heff_2ecompile_2einterp_2eintAtV(v_a_241273, v_t_241301, v_a_241282, v_a_241291, v_a_241300));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241295, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop(v_a_241291);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241295, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop(v_a_241291);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241295, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop(v_a_241291);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241295, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop(v_a_241291);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241295, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop(v_a_241291);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241295, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop(v_a_241291);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241295, 0ULL, 2);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop(v_a_241291);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop(v_a_241291);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241295);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241273);
    heff_drop(v_a_241282);
    heff_drop(v_a_241291);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241273);
    heff_drop(v_a_241282);
    heff_drop(v_a_241291);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241310 = heff_field(v_x1_241294, 0);
    V v_ru_24x1_241294_24Bug = heff_take_reuse_n(v_x1_241294, 1ULL, 1);
    heff_drop(v_a_241273);
    heff_drop(v_a_241282);
    heff_drop(v_a_241291);
    return heff_tag_at_n(v_ru_24x1_241294_24Bug, TAG_Bug, 1, (V[]){v_what_241310});
  }
  default: return heff_nomatch(v_x1_241294);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args) {
  V v_d_241283 = args[0];
  V v_a_241284 = args[1];
  V v_a_241273 = heff_env(self)[0];
  V v_a_241282 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241285 = heff_tr(heff_call(v_a_241284, 1, (V[]){v_d_241283}));
  switch (heff_tag_of(v_x1_241285)) {
  case TAG_Ok: {
    V v_v_241286 = heff_field(v_x1_241285, 0);
    V v_ru_24x1_241285_24Ok = heff_take_reuse_n(v_x1_241285, 1ULL, 1);
    switch (heff_tag_of(v_v_241286)) {
    case TAG_VFun: {
      heff_take_n(v_v_241286, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop_cell(v_ru_24x1_241285_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241286, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop_cell(v_ru_24x1_241285_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241286, 0ULL, 2);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop_cell(v_ru_24x1_241285_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241291 = heff_field(v_v_241286, 0);
      heff_take_n(v_v_241286, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241285_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam91, 2, 3, (V[]){v_a_241273, v_a_241282, v_a_241291})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241286, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop_cell(v_ru_24x1_241285_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241286, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop_cell(v_ru_24x1_241285_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241286, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop_cell(v_ru_24x1_241285_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241286, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop_cell(v_ru_24x1_241285_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241286, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop_cell(v_ru_24x1_241285_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241286, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop_cell(v_ru_24x1_241285_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241286, 0ULL, 2);
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop_cell(v_ru_24x1_241285_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241273);
      heff_drop(v_a_241282);
      heff_drop_cell(v_ru_24x1_241285_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241286);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241273);
    heff_drop(v_a_241282);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241273);
    heff_drop(v_a_241282);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241319 = heff_field(v_x1_241285, 0);
    V v_ru_24x1_241285_24Bug = heff_take_reuse_n(v_x1_241285, 1ULL, 1);
    heff_drop(v_a_241273);
    heff_drop(v_a_241282);
    return heff_tag_at_n(v_ru_24x1_241285_24Bug, TAG_Bug, 1, (V[]){v_what_241319});
  }
  default: return heff_nomatch(v_x1_241285);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args) {
  V v_d_241274 = args[0];
  V v_a_241275 = args[1];
  V v_a_241273 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241276 = heff_tr(heff_call(v_a_241275, 1, (V[]){v_d_241274}));
  switch (heff_tag_of(v_x1_241276)) {
  case TAG_Ok: {
    V v_v_241277 = heff_field(v_x1_241276, 0);
    V v_ru_24x1_241276_24Ok = heff_take_reuse_n(v_x1_241276, 1ULL, 1);
    switch (heff_tag_of(v_v_241277)) {
    case TAG_VFun: {
      heff_take_n(v_v_241277, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop_cell(v_ru_24x1_241276_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241277, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop_cell(v_ru_24x1_241276_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241277, 0ULL, 2);
      heff_drop(v_a_241273);
      heff_drop_cell(v_ru_24x1_241276_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241282 = heff_field(v_v_241277, 0);
      heff_take_n(v_v_241277, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241276_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam90, 2, 2, (V[]){v_a_241273, v_a_241282})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241277, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop_cell(v_ru_24x1_241276_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241277, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop_cell(v_ru_24x1_241276_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241277, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop_cell(v_ru_24x1_241276_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241277, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop_cell(v_ru_24x1_241276_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241277, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop_cell(v_ru_24x1_241276_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241277, 0ULL, 1);
      heff_drop(v_a_241273);
      heff_drop_cell(v_ru_24x1_241276_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241277, 0ULL, 2);
      heff_drop(v_a_241273);
      heff_drop_cell(v_ru_24x1_241276_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241273);
      heff_drop_cell(v_ru_24x1_241276_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241277);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241273);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241273);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241328 = heff_field(v_x1_241276, 0);
    V v_ru_24x1_241276_24Bug = heff_take_reuse_n(v_x1_241276, 1ULL, 1);
    heff_drop(v_a_241273);
    return heff_tag_at_n(v_ru_24x1_241276_24Bug, TAG_Bug, 1, (V[]){v_what_241328});
  }
  default: return heff_nomatch(v_x1_241276);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args) {
  V v_d_241259 = args[0];
  V v_a_241260 = args[1];
  V v_x1_241261 = heff_tr(heff_call(v_a_241260, 1, (V[]){v_d_241259}));
  switch (heff_tag_of(v_x1_241261)) {
  case TAG_Ok: {
    V v_v_241262 = heff_field(v_x1_241261, 0);
    V v_ru_24x1_241261_24Ok = heff_take_reuse_n(v_x1_241261, 1ULL, 1);
    switch (heff_tag_of(v_v_241262)) {
    case TAG_VFun: {
      heff_take_n(v_v_241262, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241261_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241262, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241261_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241262, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241261_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241262, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241261_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241262, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241261_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241262, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241261_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241262, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241261_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241262, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241261_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241262, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241261_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241273 = heff_field(v_v_241262, 0);
      heff_take_n(v_v_241262, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241261_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam89, 2, 1, (V[]){v_a_241273})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241262, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241261_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241261_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241262);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241331 = heff_field(v_x1_241261, 0);
    V v_ru_24x1_241261_24Bug = heff_take_reuse_n(v_x1_241261, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241261_24Bug, TAG_Bug, 1, (V[]){v_what_241331});
  }
  default: return heff_nomatch(v_x1_241261);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args) {
  V v_d_241351 = args[0];
  V v_a_241352 = args[1];
  V v_a_241341 = heff_env(self)[0];
  V v_a_241350 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241353 = heff_tr(heff_call(v_a_241352, 1, (V[]){v_d_241351}));
  switch (heff_tag_of(v_x1_241353)) {
  case TAG_Ok: {
    V v_v_241354 = heff_field(v_x1_241353, 0);
    heff_take_n(v_x1_241353, 1ULL, 1);
    switch (heff_tag_of(v_v_241354)) {
    case TAG_VFun: {
      heff_take_n(v_v_241354, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop(v_a_241350);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241354, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop(v_a_241350);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241354, 0ULL, 2);
      heff_drop(v_a_241341);
      heff_drop(v_a_241350);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241359 = heff_field(v_v_241354, 0);
      heff_take_n(v_v_241354, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2ebytesOfIntV(v_a_241341, v_a_241350, v_a_241359));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241354, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop(v_a_241350);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241354, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop(v_a_241350);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241354, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop(v_a_241350);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241354, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop(v_a_241350);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241354, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop(v_a_241350);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241354, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop(v_a_241350);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241354, 0ULL, 2);
      heff_drop(v_a_241341);
      heff_drop(v_a_241350);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241341);
      heff_drop(v_a_241350);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241354);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241341);
    heff_drop(v_a_241350);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241341);
    heff_drop(v_a_241350);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241368 = heff_field(v_x1_241353, 0);
    V v_ru_24x1_241353_24Bug = heff_take_reuse_n(v_x1_241353, 1ULL, 1);
    heff_drop(v_a_241341);
    heff_drop(v_a_241350);
    return heff_tag_at_n(v_ru_24x1_241353_24Bug, TAG_Bug, 1, (V[]){v_what_241368});
  }
  default: return heff_nomatch(v_x1_241353);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args) {
  V v_d_241342 = args[0];
  V v_a_241343 = args[1];
  V v_a_241341 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241344 = heff_tr(heff_call(v_a_241343, 1, (V[]){v_d_241342}));
  switch (heff_tag_of(v_x1_241344)) {
  case TAG_Ok: {
    V v_v_241345 = heff_field(v_x1_241344, 0);
    V v_ru_24x1_241344_24Ok = heff_take_reuse_n(v_x1_241344, 1ULL, 1);
    switch (heff_tag_of(v_v_241345)) {
    case TAG_VFun: {
      heff_take_n(v_v_241345, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop_cell(v_ru_24x1_241344_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241345, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop_cell(v_ru_24x1_241344_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241345, 0ULL, 2);
      heff_drop(v_a_241341);
      heff_drop_cell(v_ru_24x1_241344_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241350 = heff_field(v_v_241345, 0);
      heff_take_n(v_v_241345, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241344_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam94, 2, 2, (V[]){v_a_241341, v_a_241350})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241345, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop_cell(v_ru_24x1_241344_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241345, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop_cell(v_ru_24x1_241344_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241345, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop_cell(v_ru_24x1_241344_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241345, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop_cell(v_ru_24x1_241344_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241345, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop_cell(v_ru_24x1_241344_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241345, 0ULL, 1);
      heff_drop(v_a_241341);
      heff_drop_cell(v_ru_24x1_241344_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241345, 0ULL, 2);
      heff_drop(v_a_241341);
      heff_drop_cell(v_ru_24x1_241344_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241341);
      heff_drop_cell(v_ru_24x1_241344_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241345);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241341);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241341);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241377 = heff_field(v_x1_241344, 0);
    V v_ru_24x1_241344_24Bug = heff_take_reuse_n(v_x1_241344, 1ULL, 1);
    heff_drop(v_a_241341);
    return heff_tag_at_n(v_ru_24x1_241344_24Bug, TAG_Bug, 1, (V[]){v_what_241377});
  }
  default: return heff_nomatch(v_x1_241344);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args) {
  V v_d_241333 = args[0];
  V v_a_241334 = args[1];
  V v_x1_241335 = heff_tr(heff_call(v_a_241334, 1, (V[]){v_d_241333}));
  switch (heff_tag_of(v_x1_241335)) {
  case TAG_Ok: {
    V v_v_241336 = heff_field(v_x1_241335, 0);
    V v_ru_24x1_241335_24Ok = heff_take_reuse_n(v_x1_241335, 1ULL, 1);
    switch (heff_tag_of(v_v_241336)) {
    case TAG_VFun: {
      heff_take_n(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241336, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241341 = heff_field(v_v_241336, 0);
      heff_take_n(v_v_241336, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241335_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam93, 2, 1, (V[]){v_a_241341})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241336, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241336);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241386 = heff_field(v_x1_241335, 0);
    V v_ru_24x1_241335_24Bug = heff_take_reuse_n(v_x1_241335, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241335_24Bug, TAG_Bug, 1, (V[]){v_what_241386});
  }
  default: return heff_nomatch(v_x1_241335);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args) {
  V v_d_241412 = args[0];
  V v_a_241413 = args[1];
  V v_a_241411 = heff_env(self)[0];
  V v_a_241402 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241414 = heff_tr(heff_call(v_a_241413, 1, (V[]){v_d_241412}));
  switch (heff_tag_of(v_x1_241414)) {
  case TAG_Ok: {
    V v_v_241415 = heff_field(v_x1_241414, 0);
    V v_ru_24x1_241414_24Ok = heff_take_reuse_n(v_x1_241414, 1ULL, 1);
    switch (heff_tag_of(v_v_241415)) {
    case TAG_VFun: {
      heff_take_n(v_v_241415, 0ULL, 1);
      heff_drop(v_a_241411);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241414_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241415, 0ULL, 1);
      heff_drop(v_a_241411);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241414_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241415, 0ULL, 2);
      heff_drop(v_a_241411);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241414_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241415, 0ULL, 1);
      heff_drop(v_a_241411);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241414_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241415, 0ULL, 1);
      heff_drop(v_a_241411);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241414_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241415, 0ULL, 1);
      heff_drop(v_a_241411);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241414_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241415, 0ULL, 1);
      heff_drop(v_a_241411);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241414_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241415, 0ULL, 1);
      heff_drop(v_a_241411);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241414_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241415, 0ULL, 1);
      heff_drop(v_a_241411);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241414_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241426 = heff_field(v_v_241415, 0);
      heff_take_n(v_v_241415, 1ULL, 1);
      V v_t_241432;
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_a_241411))) {
        V v_t_241428 = heff_intAdd(heff_dup(v_a_241411), heff_strLength_lent(v_a_241426, 0));
        if (heff_intLe_c(v_t_241428, heff_strLength_lent(v_a_241402, 0))) {
          V v_t_241430 = heff_intAdd(heff_dup(v_a_241411), heff_strLength_lent(v_a_241426, 0));
          if (heff_strEq_c(heff_strSlice(v_a_241402, v_a_241411, v_t_241430), v_a_241426)) {
            v_t_241432 = ((V)&g_heff_2ecompile_2einterp_2eprim_str95);
          } else {
            v_t_241432 = ((V)&g_heff_2ecompile_2einterp_2eprim_str96);
          }
        } else {
          heff_drop(v_a_241411);
          heff_drop(v_a_241402);
          heff_drop(v_a_241426);
          v_t_241432 = ((V)&g_heff_2ecompile_2einterp_2eprim_str97);
        }
      } else {
        heff_drop(v_a_241411);
        heff_drop(v_a_241402);
        heff_drop(v_a_241426);
        v_t_241432 = ((V)&g_heff_2ecompile_2einterp_2eprim_str98);
      }
      V v_t_241433 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241432, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_241414_24Ok, TAG_Ok, 1, (V[]){v_t_241433});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241415, 0ULL, 2);
      heff_drop(v_a_241411);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241414_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241411);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241414_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241415);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241411);
    heff_drop(v_a_241402);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241411);
    heff_drop(v_a_241402);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241436 = heff_field(v_x1_241414, 0);
    V v_ru_24x1_241414_24Bug = heff_take_reuse_n(v_x1_241414, 1ULL, 1);
    heff_drop(v_a_241411);
    heff_drop(v_a_241402);
    return heff_tag_at_n(v_ru_24x1_241414_24Bug, TAG_Bug, 1, (V[]){v_what_241436});
  }
  default: return heff_nomatch(v_x1_241414);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args) {
  V v_d_241403 = args[0];
  V v_a_241404 = args[1];
  V v_a_241402 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241405 = heff_tr(heff_call(v_a_241404, 1, (V[]){v_d_241403}));
  switch (heff_tag_of(v_x1_241405)) {
  case TAG_Ok: {
    V v_v_241406 = heff_field(v_x1_241405, 0);
    V v_ru_24x1_241405_24Ok = heff_take_reuse_n(v_x1_241405, 1ULL, 1);
    switch (heff_tag_of(v_v_241406)) {
    case TAG_VFun: {
      heff_take_n(v_v_241406, 0ULL, 1);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241405_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241406, 0ULL, 1);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241405_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241406, 0ULL, 2);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241405_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241411 = heff_field(v_v_241406, 0);
      heff_take_n(v_v_241406, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241405_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam97, 2, 2, (V[]){v_a_241411, v_a_241402})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241406, 0ULL, 1);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241405_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241406, 0ULL, 1);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241405_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241406, 0ULL, 1);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241405_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241406, 0ULL, 1);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241405_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241406, 0ULL, 1);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241405_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241406, 0ULL, 1);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241405_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241406, 0ULL, 2);
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241405_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241402);
      heff_drop_cell(v_ru_24x1_241405_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241406);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241402);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241402);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241445 = heff_field(v_x1_241405, 0);
    V v_ru_24x1_241405_24Bug = heff_take_reuse_n(v_x1_241405, 1ULL, 1);
    heff_drop(v_a_241402);
    return heff_tag_at_n(v_ru_24x1_241405_24Bug, TAG_Bug, 1, (V[]){v_what_241445});
  }
  default: return heff_nomatch(v_x1_241405);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args) {
  V v_d_241388 = args[0];
  V v_a_241389 = args[1];
  V v_x1_241390 = heff_tr(heff_call(v_a_241389, 1, (V[]){v_d_241388}));
  switch (heff_tag_of(v_x1_241390)) {
  case TAG_Ok: {
    V v_v_241391 = heff_field(v_x1_241390, 0);
    V v_ru_24x1_241390_24Ok = heff_take_reuse_n(v_x1_241390, 1ULL, 1);
    switch (heff_tag_of(v_v_241391)) {
    case TAG_VFun: {
      heff_take_n(v_v_241391, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241390_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241391, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241390_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241391, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241390_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241391, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241390_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241391, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241390_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241391, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241390_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241391, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241390_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241391, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241390_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241391, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241390_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241402 = heff_field(v_v_241391, 0);
      heff_take_n(v_v_241391, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241390_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam96, 2, 1, (V[]){v_a_241402})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241391, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241390_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241390_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241391);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241448 = heff_field(v_x1_241390, 0);
    V v_ru_24x1_241390_24Bug = heff_take_reuse_n(v_x1_241390, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241390_24Bug, TAG_Bug, 1, (V[]){v_what_241448});
  }
  default: return heff_nomatch(v_x1_241390);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args) {
  V v_d_241471 = args[0];
  V v_a_241472 = args[1];
  V v_s_241452 = heff_env(self)[0];
  V v_m_241451 = heff_env(self)[1];
  V v_a_241461 = heff_env(self)[2];
  V v_a_241470 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_241473 = heff_tr(heff_call(v_a_241472, 1, (V[]){v_d_241471}));
  switch (heff_tag_of(v_x1_241473)) {
  case TAG_Ok: {
    V v_v_241474 = heff_field(v_x1_241473, 0);
    heff_take_n(v_x1_241473, 1ULL, 1);
    switch (heff_tag_of(v_v_241474)) {
    case TAG_VFun: {
      heff_take_n(v_v_241474, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop(v_a_241470);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241474, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop(v_a_241470);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241474, 0ULL, 2);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop(v_a_241470);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241479 = heff_field(v_v_241474, 0);
      heff_take_n(v_v_241474, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2eintAtV(v_s_241452, v_m_241451, v_a_241461, v_a_241470, v_a_241479));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241474, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop(v_a_241470);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241474, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop(v_a_241470);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241474, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop(v_a_241470);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241474, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop(v_a_241470);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241474, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop(v_a_241470);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241474, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop(v_a_241470);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241474, 0ULL, 2);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop(v_a_241470);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop(v_a_241470);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241474);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241452);
    heff_drop(v_m_241451);
    heff_drop(v_a_241461);
    heff_drop(v_a_241470);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241452);
    heff_drop(v_m_241451);
    heff_drop(v_a_241461);
    heff_drop(v_a_241470);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241488 = heff_field(v_x1_241473, 0);
    V v_ru_24x1_241473_24Bug = heff_take_reuse_n(v_x1_241473, 1ULL, 1);
    heff_drop(v_s_241452);
    heff_drop(v_m_241451);
    heff_drop(v_a_241461);
    heff_drop(v_a_241470);
    return heff_tag_at_n(v_ru_24x1_241473_24Bug, TAG_Bug, 1, (V[]){v_what_241488});
  }
  default: return heff_nomatch(v_x1_241473);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args) {
  V v_d_241462 = args[0];
  V v_a_241463 = args[1];
  V v_s_241452 = heff_env(self)[0];
  V v_m_241451 = heff_env(self)[1];
  V v_a_241461 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241464 = heff_tr(heff_call(v_a_241463, 1, (V[]){v_d_241462}));
  switch (heff_tag_of(v_x1_241464)) {
  case TAG_Ok: {
    V v_v_241465 = heff_field(v_x1_241464, 0);
    V v_ru_24x1_241464_24Ok = heff_take_reuse_n(v_x1_241464, 1ULL, 1);
    switch (heff_tag_of(v_v_241465)) {
    case TAG_VFun: {
      heff_take_n(v_v_241465, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241465, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241465, 0ULL, 2);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241470 = heff_field(v_v_241465, 0);
      heff_take_n(v_v_241465, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241464_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam101, 2, 4, (V[]){v_s_241452, v_m_241451, v_a_241461, v_a_241470})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241465, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241465, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241465, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241465, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241465, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241465, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241465, 0ULL, 2);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241465);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241452);
    heff_drop(v_m_241451);
    heff_drop(v_a_241461);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241452);
    heff_drop(v_m_241451);
    heff_drop(v_a_241461);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241497 = heff_field(v_x1_241464, 0);
    V v_ru_24x1_241464_24Bug = heff_take_reuse_n(v_x1_241464, 1ULL, 1);
    heff_drop(v_s_241452);
    heff_drop(v_m_241451);
    heff_drop(v_a_241461);
    return heff_tag_at_n(v_ru_24x1_241464_24Bug, TAG_Bug, 1, (V[]){v_what_241497});
  }
  default: return heff_nomatch(v_x1_241464);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args) {
  V v_d_241453 = args[0];
  V v_a_241454 = args[1];
  V v_s_241452 = heff_env(self)[0];
  V v_m_241451 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241455 = heff_tr(heff_call(v_a_241454, 1, (V[]){v_d_241453}));
  switch (heff_tag_of(v_x1_241455)) {
  case TAG_Ok: {
    V v_v_241456 = heff_field(v_x1_241455, 0);
    V v_ru_24x1_241455_24Ok = heff_take_reuse_n(v_x1_241455, 1ULL, 1);
    switch (heff_tag_of(v_v_241456)) {
    case TAG_VFun: {
      heff_take_n(v_v_241456, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241456, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241456, 0ULL, 2);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241461 = heff_field(v_v_241456, 0);
      heff_take_n(v_v_241456, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241455_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam100, 2, 3, (V[]){v_s_241452, v_m_241451, v_a_241461})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241456, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241456, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241456, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241456, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241456, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241456, 0ULL, 1);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241456, 0ULL, 2);
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241452);
      heff_drop(v_m_241451);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241456);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241452);
    heff_drop(v_m_241451);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241452);
    heff_drop(v_m_241451);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241506 = heff_field(v_x1_241455, 0);
    V v_ru_24x1_241455_24Bug = heff_take_reuse_n(v_x1_241455, 1ULL, 1);
    heff_drop(v_s_241452);
    heff_drop(v_m_241451);
    return heff_tag_at_n(v_ru_24x1_241455_24Bug, TAG_Bug, 1, (V[]){v_what_241506});
  }
  default: return heff_nomatch(v_x1_241455);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args) {
  V v_m_241451 = args[0];
  V v_s_241452 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam99, 2, 2, (V[]){v_s_241452, v_m_241451})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args) {
  V v_d_241526 = args[0];
  V v_a_241527 = args[1];
  V v_a_241516 = heff_env(self)[0];
  V v_a_241525 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241528 = heff_tr(heff_call(v_a_241527, 1, (V[]){v_d_241526}));
  switch (heff_tag_of(v_x1_241528)) {
  case TAG_Ok: {
    V v_v_241529 = heff_field(v_x1_241528, 0);
    heff_take_n(v_x1_241528, 1ULL, 1);
    switch (heff_tag_of(v_v_241529)) {
    case TAG_VFun: {
      heff_take_n(v_v_241529, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop(v_a_241525);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241529, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop(v_a_241525);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241529, 0ULL, 2);
      heff_drop(v_a_241516);
      heff_drop(v_a_241525);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241534 = heff_field(v_v_241529, 0);
      heff_take_n(v_v_241529, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2ebitsOfIntV(v_a_241516, v_a_241525, v_a_241534));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241529, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop(v_a_241525);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241529, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop(v_a_241525);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241529, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop(v_a_241525);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241529, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop(v_a_241525);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241529, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop(v_a_241525);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241529, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop(v_a_241525);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241529, 0ULL, 2);
      heff_drop(v_a_241516);
      heff_drop(v_a_241525);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241516);
      heff_drop(v_a_241525);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241529);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241516);
    heff_drop(v_a_241525);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241516);
    heff_drop(v_a_241525);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241543 = heff_field(v_x1_241528, 0);
    V v_ru_24x1_241528_24Bug = heff_take_reuse_n(v_x1_241528, 1ULL, 1);
    heff_drop(v_a_241516);
    heff_drop(v_a_241525);
    return heff_tag_at_n(v_ru_24x1_241528_24Bug, TAG_Bug, 1, (V[]){v_what_241543});
  }
  default: return heff_nomatch(v_x1_241528);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args) {
  V v_d_241517 = args[0];
  V v_a_241518 = args[1];
  V v_a_241516 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241519 = heff_tr(heff_call(v_a_241518, 1, (V[]){v_d_241517}));
  switch (heff_tag_of(v_x1_241519)) {
  case TAG_Ok: {
    V v_v_241520 = heff_field(v_x1_241519, 0);
    V v_ru_24x1_241519_24Ok = heff_take_reuse_n(v_x1_241519, 1ULL, 1);
    switch (heff_tag_of(v_v_241520)) {
    case TAG_VFun: {
      heff_take_n(v_v_241520, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop_cell(v_ru_24x1_241519_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241520, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop_cell(v_ru_24x1_241519_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241520, 0ULL, 2);
      heff_drop(v_a_241516);
      heff_drop_cell(v_ru_24x1_241519_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241525 = heff_field(v_v_241520, 0);
      heff_take_n(v_v_241520, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241519_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam104, 2, 2, (V[]){v_a_241516, v_a_241525})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241520, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop_cell(v_ru_24x1_241519_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241520, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop_cell(v_ru_24x1_241519_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241520, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop_cell(v_ru_24x1_241519_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241520, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop_cell(v_ru_24x1_241519_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241520, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop_cell(v_ru_24x1_241519_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241520, 0ULL, 1);
      heff_drop(v_a_241516);
      heff_drop_cell(v_ru_24x1_241519_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241520, 0ULL, 2);
      heff_drop(v_a_241516);
      heff_drop_cell(v_ru_24x1_241519_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241516);
      heff_drop_cell(v_ru_24x1_241519_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241520);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241516);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241516);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241552 = heff_field(v_x1_241519, 0);
    V v_ru_24x1_241519_24Bug = heff_take_reuse_n(v_x1_241519, 1ULL, 1);
    heff_drop(v_a_241516);
    return heff_tag_at_n(v_ru_24x1_241519_24Bug, TAG_Bug, 1, (V[]){v_what_241552});
  }
  default: return heff_nomatch(v_x1_241519);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args) {
  V v_d_241508 = args[0];
  V v_a_241509 = args[1];
  V v_x1_241510 = heff_tr(heff_call(v_a_241509, 1, (V[]){v_d_241508}));
  switch (heff_tag_of(v_x1_241510)) {
  case TAG_Ok: {
    V v_v_241511 = heff_field(v_x1_241510, 0);
    V v_ru_24x1_241510_24Ok = heff_take_reuse_n(v_x1_241510, 1ULL, 1);
    switch (heff_tag_of(v_v_241511)) {
    case TAG_VFun: {
      heff_take_n(v_v_241511, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241510_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241511, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241510_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241511, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241510_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241516 = heff_field(v_v_241511, 0);
      heff_take_n(v_v_241511, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241510_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam103, 2, 1, (V[]){v_a_241516})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241511, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241510_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241511, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241510_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241511, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241510_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241511, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241510_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241511, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241510_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241511, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241510_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241511, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241510_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241510_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241511);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241561 = heff_field(v_x1_241510, 0);
    V v_ru_24x1_241510_24Bug = heff_take_reuse_n(v_x1_241510, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241510_24Bug, TAG_Bug, 1, (V[]){v_what_241561});
  }
  default: return heff_nomatch(v_x1_241510);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args) {
  V v_d_241563 = args[0];
  V v_l_241564 = args[1];
  V v_x1_241565 = heff_tr(heff_call(v_l_241564, 1, (V[]){v_d_241563}));
  switch (heff_tag_of(v_x1_241565)) {
  case TAG_Ok: {
    V v_v_241566 = heff_field(v_x1_241565, 0);
    heff_take_n(v_x1_241565, 1ULL, 1);
    V v_t_241567 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241566, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_241567; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2einterp_2eprim_str103); V r_ = (g_heff_2ecompile_2einterp_2ebitsJoined(a_0, a_1, a_2)); heff_drop(v_t_241567); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241568 = heff_field(v_x1_241565, 0);
    V v_ru_24x1_241565_24Bug = heff_take_reuse_n(v_x1_241565, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241565_24Bug, TAG_Bug, 1, (V[]){v_what_241568});
  }
  default: return heff_nomatch(v_x1_241565);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args) {
  V v_d_241581 = args[0];
  V v_a_241582 = args[1];
  V v_a_241580 = heff_env(self)[0];
  V v_m_241570 = heff_env(self)[1];
  V v_s_241571 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241583 = heff_tr(heff_call(v_a_241582, 1, (V[]){v_d_241581}));
  switch (heff_tag_of(v_x1_241583)) {
  case TAG_Ok: {
    V v_v_241584 = heff_field(v_x1_241583, 0);
    V v_ru_24x1_241583_24Ok = heff_take_reuse_n(v_x1_241583, 1ULL, 1);
    switch (heff_tag_of(v_v_241584)) {
    case TAG_VFun: {
      heff_take_n(v_v_241584, 0ULL, 1);
      heff_drop(v_a_241580);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241583_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241584, 0ULL, 1);
      heff_drop(v_a_241580);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241583_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241584, 0ULL, 2);
      heff_drop(v_a_241580);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241583_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241589 = heff_field(v_v_241584, 0);
      heff_take_n(v_v_241584, 1ULL, 1);
      if (heff_intLt_c(heff_dup(v_a_241580), MK_INT(0LL))) {
        heff_drop(v_a_241580);
        heff_drop(v_m_241570);
        heff_drop(v_s_241571);
        heff_drop_cell(v_ru_24x1_241583_24Ok, 1);
        heff_drop(v_a_241589);
        return NTAG(TAG_Abn);
      } else {
        if (heff_intLt_c(heff_dup(v_a_241589), MK_INT(0LL))) {
          heff_drop(v_a_241580);
          heff_drop(v_m_241570);
          heff_drop(v_s_241571);
          heff_drop_cell(v_ru_24x1_241583_24Ok, 1);
          heff_drop(v_a_241589);
          return NTAG(TAG_Abn);
        } else {
          if (heff_intLt_c(v_m_241570, heff_intAdd(heff_dup(v_a_241580), heff_dup(v_a_241589)))) {
            heff_drop(v_a_241580);
            heff_drop(v_s_241571);
            heff_drop_cell(v_ru_24x1_241583_24Ok, 1);
            heff_drop(v_a_241589);
            return NTAG(TAG_Abn);
          } else {
            V v_t_241593 = (g_heff_2ecompile_2einterp_2ebitsCopy(MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2eprim_str105), v_s_241571, heff_dup(v_a_241580), heff_intAdd(v_a_241580, heff_dup(v_a_241589))));
            return heff_tag_at_n(v_ru_24x1_241583_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_a_241589, v_t_241593})});
          }
        }
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241584, 0ULL, 1);
      heff_drop(v_a_241580);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241583_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241584, 0ULL, 1);
      heff_drop(v_a_241580);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241583_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241584, 0ULL, 1);
      heff_drop(v_a_241580);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241583_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241584, 0ULL, 1);
      heff_drop(v_a_241580);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241583_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241584, 0ULL, 1);
      heff_drop(v_a_241580);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241583_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241584, 0ULL, 1);
      heff_drop(v_a_241580);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241583_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241584, 0ULL, 2);
      heff_drop(v_a_241580);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241583_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241580);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241583_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241584);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241580);
    heff_drop(v_m_241570);
    heff_drop(v_s_241571);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241580);
    heff_drop(v_m_241570);
    heff_drop(v_s_241571);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241602 = heff_field(v_x1_241583, 0);
    V v_ru_24x1_241583_24Bug = heff_take_reuse_n(v_x1_241583, 1ULL, 1);
    heff_drop(v_a_241580);
    heff_drop(v_m_241570);
    heff_drop(v_s_241571);
    return heff_tag_at_n(v_ru_24x1_241583_24Bug, TAG_Bug, 1, (V[]){v_what_241602});
  }
  default: return heff_nomatch(v_x1_241583);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args) {
  V v_d_241572 = args[0];
  V v_a_241573 = args[1];
  V v_m_241570 = heff_env(self)[0];
  V v_s_241571 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241574 = heff_tr(heff_call(v_a_241573, 1, (V[]){v_d_241572}));
  switch (heff_tag_of(v_x1_241574)) {
  case TAG_Ok: {
    V v_v_241575 = heff_field(v_x1_241574, 0);
    V v_ru_24x1_241574_24Ok = heff_take_reuse_n(v_x1_241574, 1ULL, 1);
    switch (heff_tag_of(v_v_241575)) {
    case TAG_VFun: {
      heff_take_n(v_v_241575, 0ULL, 1);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241574_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241575, 0ULL, 1);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241574_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241575, 0ULL, 2);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241574_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241580 = heff_field(v_v_241575, 0);
      heff_take_n(v_v_241575, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241574_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam108, 2, 3, (V[]){v_a_241580, v_m_241570, v_s_241571})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241575, 0ULL, 1);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241574_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241575, 0ULL, 1);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241574_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241575, 0ULL, 1);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241574_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241575, 0ULL, 1);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241574_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241575, 0ULL, 1);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241574_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241575, 0ULL, 1);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241574_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241575, 0ULL, 2);
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241574_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_m_241570);
      heff_drop(v_s_241571);
      heff_drop_cell(v_ru_24x1_241574_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241575);
    }
  }
  case TAG_Abn: {
    heff_drop(v_m_241570);
    heff_drop(v_s_241571);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_m_241570);
    heff_drop(v_s_241571);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241611 = heff_field(v_x1_241574, 0);
    V v_ru_24x1_241574_24Bug = heff_take_reuse_n(v_x1_241574, 1ULL, 1);
    heff_drop(v_m_241570);
    heff_drop(v_s_241571);
    return heff_tag_at_n(v_ru_24x1_241574_24Bug, TAG_Bug, 1, (V[]){v_what_241611});
  }
  default: return heff_nomatch(v_x1_241574);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args) {
  V v_m_241570 = args[0];
  V v_s_241571 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam107, 2, 2, (V[]){v_m_241570, v_s_241571})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args) {
  V v_d_241613 = args[0];
  V v_a_241614 = args[1];
  V v_x1_241615 = heff_tr(heff_call(v_a_241614, 1, (V[]){v_d_241613}));
  switch (heff_tag_of(v_x1_241615)) {
  case TAG_Ok: {
    V v_v_241616 = heff_field(v_x1_241615, 0);
    V v_ru_24x1_241615_24Ok = heff_take_reuse_n(v_x1_241615, 1ULL, 1);
    switch (heff_tag_of(v_v_241616)) {
    case TAG_VFun: {
      heff_take_n(v_v_241616, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241615_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241616, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241615_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241616, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241615_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241616, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241615_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241616, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241615_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241616, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241615_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241616, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241615_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241616, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241615_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241616, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241615_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241627 = heff_field(v_v_241616, 0);
      heff_take_n(v_v_241616, 1ULL, 1);
      V v_t_241628 = heff_intMul(heff_strLength_lent(v_a_241627, 0), MK_INT(8LL));
      return heff_tag_at_n(v_ru_24x1_241615_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_t_241628, v_a_241627})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241616, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241615_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241615_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241616);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241631 = heff_field(v_x1_241615, 0);
    V v_ru_24x1_241615_24Bug = heff_take_reuse_n(v_x1_241615, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241615_24Bug, TAG_Bug, 1, (V[]){v_what_241631});
  }
  default: return heff_nomatch(v_x1_241615);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam110(V self, V *args) {
  V v_n_241633 = args[0];
  V v_s_241634 = args[1];
  if (heff_intEq_c(heff_intMod(v_n_241633, MK_INT(8LL)), MK_INT(0LL))) {
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_s_241634})});
  } else {
    heff_drop(v_s_241634);
    return NTAG(TAG_Abn);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam112(V self, V *args) {
  V v_m_241639 = args[0];
  V v_t_241640 = args[1];
  V v_n_241637 = heff_env(self)[0];
  V v_s_241638 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_241643;
  if (heff_intEq_c(v_n_241637, v_m_241639)) {
    if (heff_strEq_c(v_s_241638, v_t_241640)) {
      v_t_241643 = ((V)&g_heff_2ecompile_2einterp_2eprim_str109);
    } else {
      v_t_241643 = ((V)&g_heff_2ecompile_2einterp_2eprim_str110);
    }
  } else {
    heff_drop(v_t_241640);
    heff_drop(v_s_241638);
    v_t_241643 = ((V)&g_heff_2ecompile_2einterp_2eprim_str111);
  }
  V v_t_241644 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241643, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241644});
}
V g_heff_2ecompile_2einterp_2eprim_lam111(V self, V *args) {
  V v_n_241637 = args[0];
  V v_s_241638 = args[1];
  V v_t_241645 = (g_heff_2ecompile_2einterp_2ebits1(heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam112, 2, 2, (V[]){v_n_241637, v_s_241638})));
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241645});
}
V g_heff_2ecompile_2einterp_2eprim_lam114(V self, V *args) {
  V v_d_241656 = args[0];
  V v_a_241657 = args[1];
  V v_a_241655 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241658 = heff_tr(heff_call(v_a_241657, 1, (V[]){v_d_241656}));
  switch (heff_tag_of(v_x1_241658)) {
  case TAG_Ok: {
    V v_v_241659 = heff_field(v_x1_241658, 0);
    V v_ru_24x1_241658_24Ok = heff_take_reuse_n(v_x1_241658, 1ULL, 1);
    switch (heff_tag_of(v_v_241659)) {
    case TAG_VFun: {
      heff_take_n(v_v_241659, 0ULL, 1);
      heff_drop(v_a_241655);
      heff_drop_cell(v_ru_24x1_241658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241659, 0ULL, 1);
      heff_drop(v_a_241655);
      heff_drop_cell(v_ru_24x1_241658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241659, 0ULL, 2);
      heff_drop(v_a_241655);
      heff_drop_cell(v_ru_24x1_241658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241659, 0ULL, 1);
      heff_drop(v_a_241655);
      heff_drop_cell(v_ru_24x1_241658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_241665 = heff_tflat_f64(v_v_241659, 0);
      heff_take_na(v_v_241659, 0ULL, 1);
      if (heff_intEq_c(heff_dup(v_a_241655), MK_INT(64LL))) {
        heff_drop(v_a_241655);
        V v_t_241667 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(11LL), MK_INT(52LL), v_a_241665));
        return heff_tag_at_n(v_ru_24x1_241658_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_241667})});
      } else {
        if (heff_intEq_c(v_a_241655, MK_INT(32LL))) {
          double v_t_241669 = ((double)((float)v_a_241665));
          V v_t_241670 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(8LL), MK_INT(23LL), v_t_241669));
          return heff_tag_at_n(v_ru_24x1_241658_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_241670})});
        } else {
          heff_drop_cell(v_ru_24x1_241658_24Ok, 1);
          return NTAG(TAG_Abn);
        }
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241659, 0ULL, 1);
      heff_drop(v_a_241655);
      heff_drop_cell(v_ru_24x1_241658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241659, 0ULL, 1);
      heff_drop(v_a_241655);
      heff_drop_cell(v_ru_24x1_241658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241659, 0ULL, 1);
      heff_drop(v_a_241655);
      heff_drop_cell(v_ru_24x1_241658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241659, 0ULL, 1);
      heff_drop(v_a_241655);
      heff_drop_cell(v_ru_24x1_241658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241659, 0ULL, 1);
      heff_drop(v_a_241655);
      heff_drop_cell(v_ru_24x1_241658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241659, 0ULL, 2);
      heff_drop(v_a_241655);
      heff_drop_cell(v_ru_24x1_241658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241655);
      heff_drop_cell(v_ru_24x1_241658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_241659);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241655);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241655);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241678 = heff_field(v_x1_241658, 0);
    V v_ru_24x1_241658_24Bug = heff_take_reuse_n(v_x1_241658, 1ULL, 1);
    heff_drop(v_a_241655);
    return heff_tag_at_n(v_ru_24x1_241658_24Bug, TAG_Bug, 1, (V[]){v_what_241678});
  }
  default: return heff_nomatch(v_x1_241658);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam113(V self, V *args) {
  V v_d_241647 = args[0];
  V v_a_241648 = args[1];
  V v_x1_241649 = heff_tr(heff_call(v_a_241648, 1, (V[]){v_d_241647}));
  switch (heff_tag_of(v_x1_241649)) {
  case TAG_Ok: {
    V v_v_241650 = heff_field(v_x1_241649, 0);
    V v_ru_24x1_241649_24Ok = heff_take_reuse_n(v_x1_241649, 1ULL, 1);
    switch (heff_tag_of(v_v_241650)) {
    case TAG_VFun: {
      heff_take_n(v_v_241650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241650, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241655 = heff_field(v_v_241650, 0);
      heff_take_n(v_v_241650, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241649_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam114, 2, 1, (V[]){v_a_241655})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241650, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241650, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241649_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241650);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241687 = heff_field(v_x1_241649, 0);
    V v_ru_24x1_241649_24Bug = heff_take_reuse_n(v_x1_241649, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241649_24Bug, TAG_Bug, 1, (V[]){v_what_241687});
  }
  default: return heff_nomatch(v_x1_241649);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam116(V self, V *args) {
  V v_d_241698 = args[0];
  V v_a_241699 = args[1];
  V v_a_241697 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241700 = heff_tr(heff_call(v_a_241699, 1, (V[]){v_d_241698}));
  switch (heff_tag_of(v_x1_241700)) {
  case TAG_Ok: {
    V v_v_241701 = heff_field(v_x1_241700, 0);
    heff_take_n(v_x1_241700, 1ULL, 1);
    switch (heff_tag_of(v_v_241701)) {
    case TAG_VFun: {
      heff_take_n(v_v_241701, 0ULL, 1);
      heff_drop(v_a_241697);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241701, 0ULL, 1);
      heff_drop(v_a_241697);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241701, 0ULL, 2);
      heff_drop(v_a_241697);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241706 = heff_field(v_v_241701, 0);
      heff_take_n(v_v_241701, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2efloatOfBitsV(v_a_241697, v_a_241706));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241701, 0ULL, 1);
      heff_drop(v_a_241697);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241701, 0ULL, 1);
      heff_drop(v_a_241697);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241701, 0ULL, 1);
      heff_drop(v_a_241697);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241701, 0ULL, 1);
      heff_drop(v_a_241697);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241701, 0ULL, 1);
      heff_drop(v_a_241697);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241701, 0ULL, 1);
      heff_drop(v_a_241697);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241701, 0ULL, 2);
      heff_drop(v_a_241697);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241697);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241701);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241697);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241697);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241715 = heff_field(v_x1_241700, 0);
    V v_ru_24x1_241700_24Bug = heff_take_reuse_n(v_x1_241700, 1ULL, 1);
    heff_drop(v_a_241697);
    return heff_tag_at_n(v_ru_24x1_241700_24Bug, TAG_Bug, 1, (V[]){v_what_241715});
  }
  default: return heff_nomatch(v_x1_241700);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam115(V self, V *args) {
  V v_d_241689 = args[0];
  V v_a_241690 = args[1];
  V v_x1_241691 = heff_tr(heff_call(v_a_241690, 1, (V[]){v_d_241689}));
  switch (heff_tag_of(v_x1_241691)) {
  case TAG_Ok: {
    V v_v_241692 = heff_field(v_x1_241691, 0);
    V v_ru_24x1_241691_24Ok = heff_take_reuse_n(v_x1_241691, 1ULL, 1);
    switch (heff_tag_of(v_v_241692)) {
    case TAG_VFun: {
      heff_take_n(v_v_241692, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241691_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241692, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241691_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241692, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241691_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241697 = heff_field(v_v_241692, 0);
      heff_take_n(v_v_241692, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241691_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam116, 2, 1, (V[]){v_a_241697})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241692, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241691_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241692, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241691_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241692, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241691_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241692, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241691_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241692, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241691_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241692, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241691_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241692, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241691_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241691_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241692);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241724 = heff_field(v_x1_241691, 0);
    V v_ru_24x1_241691_24Bug = heff_take_reuse_n(v_x1_241691, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241691_24Bug, TAG_Bug, 1, (V[]){v_what_241724});
  }
  default: return heff_nomatch(v_x1_241691);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam117(V self, V *args) {
  V v_a_241726 = args[0];
  V v_b_241727 = args[1];
  V v_t_241729;
  if (heff_intEq_c(v_a_241726, v_b_241727)) {
    v_t_241729 = ((V)&g_heff_2ecompile_2einterp_2eprim_str115);
  } else {
    v_t_241729 = ((V)&g_heff_2ecompile_2einterp_2eprim_str116);
  }
  V v_t_241730 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241729, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241730});
}
V g_heff_2ecompile_2einterp_2eprim_lam118(V self, V *args) {
  V v_a_241732 = args[0];
  V v_b_241733 = args[1];
  V v_t_241735;
  if (heff_intLt_c(v_a_241732, v_b_241733)) {
    v_t_241735 = ((V)&g_heff_2ecompile_2einterp_2eprim_str118);
  } else {
    v_t_241735 = ((V)&g_heff_2ecompile_2einterp_2eprim_str119);
  }
  V v_t_241736 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241735, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241736});
}
V g_heff_2ecompile_2einterp_2eprim_lam119(V self, V *args) {
  V v_a_241738 = args[0];
  V v_b_241739 = args[1];
  V v_t_241741;
  if (heff_intLe_c(v_a_241738, v_b_241739)) {
    v_t_241741 = ((V)&g_heff_2ecompile_2einterp_2eprim_str121);
  } else {
    v_t_241741 = ((V)&g_heff_2ecompile_2einterp_2eprim_str122);
  }
  V v_t_241742 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241741, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241742});
}
V g_heff_2ecompile_2einterp_2eprim_lam120(V self, V *args) {
  V v_d_241744 = args[0];
  V v_a_241745 = args[1];
  V v_x1_241746 = heff_tr(heff_call(v_a_241745, 1, (V[]){v_d_241744}));
  switch (heff_tag_of(v_x1_241746)) {
  case TAG_Ok: {
    V v_v_241747 = heff_field(v_x1_241746, 0);
    V v_ru_24x1_241746_24Ok = heff_take_reuse_n(v_x1_241746, 1ULL, 1);
    switch (heff_tag_of(v_v_241747)) {
    case TAG_VFun: {
      heff_take_n(v_v_241747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241747, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VRune: {
      V v_a_241756 = heff_field(v_v_241747, 0);
      heff_take_n(v_v_241747, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241746_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_241756})});
    }
    case TAG_VArr: {
      heff_take_n(v_v_241747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241747, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241747, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241746_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    default: return heff_nomatch(v_v_241747);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241761 = heff_field(v_x1_241746, 0);
    V v_ru_24x1_241746_24Bug = heff_take_reuse_n(v_x1_241746, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241746_24Bug, TAG_Bug, 1, (V[]){v_what_241761});
  }
  default: return heff_nomatch(v_x1_241746);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam121(V self, V *args) {
  V v_d_241763 = args[0];
  V v_a_241764 = args[1];
  V v_x1_241765 = heff_tr(heff_call(v_a_241764, 1, (V[]){v_d_241763}));
  switch (heff_tag_of(v_x1_241765)) {
  case TAG_Ok: {
    V v_v_241766 = heff_field(v_x1_241765, 0);
    V v_ru_24x1_241765_24Ok = heff_take_reuse_n(v_x1_241765, 1ULL, 1);
    switch (heff_tag_of(v_v_241766)) {
    case TAG_VFun: {
      heff_take_n(v_v_241766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241766, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241771 = heff_field(v_v_241766, 0);
      heff_take_n(v_v_241766, 1ULL, 1);
      V v_t_241772 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_241773 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_241774 = heff_intSub(v_a_241771, heff_intSub(MK_INT(0LL), v_t_241773));
      V v_t_241775 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(32LL)));
      V v_t_241776 = heff_intAdd(heff_intSub(MK_INT(0LL), v_t_241772), heff_intMod(v_t_241774, v_t_241775));
      return heff_tag_at_n(v_ru_24x1_241765_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VRune, 1, (V[]){v_t_241776})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241766, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241766, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241765_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241766);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241785 = heff_field(v_x1_241765, 0);
    V v_ru_24x1_241765_24Bug = heff_take_reuse_n(v_x1_241765, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241765_24Bug, TAG_Bug, 1, (V[]){v_what_241785});
  }
  default: return heff_nomatch(v_x1_241765);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam122(V self, V *args) {
  V v_d_241787 = args[0];
  V v_a_241788 = args[1];
  V v_x1_241789 = heff_tr(heff_call(v_a_241788, 1, (V[]){v_d_241787}));
  switch (heff_tag_of(v_x1_241789)) {
  case TAG_Ok: {
    V v_v_241790 = heff_field(v_x1_241789, 0);
    V v_ru_24x1_241789_24Ok = heff_take_reuse_n(v_x1_241789, 1ULL, 1);
    switch (heff_tag_of(v_v_241790)) {
    case TAG_VFun: {
      heff_take_n(v_v_241790, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241790, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241790, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241790, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241790, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241790, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241798 = heff_field(v_v_241790, 0);
      heff_take_n(v_v_241790, 1ULL, 1);
      V v_t_241799 = (g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(heff_strRunes(v_a_241798)));
      return heff_tag_at_n(v_ru_24x1_241789_24Ok, TAG_Ok, 1, (V[]){v_t_241799});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241790, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241790, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241790, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241790, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241790);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241805 = heff_field(v_x1_241789, 0);
    V v_ru_24x1_241789_24Bug = heff_take_reuse_n(v_x1_241789, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241789_24Bug, TAG_Bug, 1, (V[]){v_what_241805});
  }
  default: return heff_nomatch(v_x1_241789);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam123(V self, V *args) {
  V v_d_241807 = args[0];
  V v_l_241808 = args[1];
  V v_x1_241809 = heff_tr(heff_call(v_l_241808, 1, (V[]){v_d_241807}));
  switch (heff_tag_of(v_x1_241809)) {
  case TAG_Ok: {
    V v_v_241810 = heff_field(v_x1_241809, 0);
    V v_ru_24x1_241809_24Ok = heff_take_reuse_n(v_x1_241809, 1ULL, 1);
    V v_t_241811 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241810, NTAG(TAG_Nil)));
    V v_t_241812 = (g_heff_2ecompile_2einterp_2eruneCodes(v_t_241811));
    V v_t_241813 = (g_list_2emap(heff_dup(g_runeFromInt_get()), v_t_241812));
    V v_t_241814 = heff_tag_n(TAG_VStr, 1, (V[]){heff_strOfRunes(v_t_241813)});
    return heff_tag_at_n(v_ru_24x1_241809_24Ok, TAG_Ok, 1, (V[]){v_t_241814});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241815 = heff_field(v_x1_241809, 0);
    V v_ru_24x1_241809_24Bug = heff_take_reuse_n(v_x1_241809, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241809_24Bug, TAG_Bug, 1, (V[]){v_what_241815});
  }
  default: return heff_nomatch(v_x1_241809);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam124(V self, V *args) {
  V v_d_241817 = args[0];
  V v_a_241818 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241817);
  heff_drop(v_a_241818);
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprim_str127), v_p_240)});
}
Clo g_heff_2ecompile_2einterp_2enthTh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2enthTh_entry, 2, 0};

V g_heff_2ecompile_2einterp_2enthTh(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2enthTh_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2enthTh(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str0, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str3, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str6, 2, "{ ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str7, 2, " }");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str8, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str12, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str13, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str17, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str18, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str19, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str20, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str21, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str22, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str23, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str24, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str25, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str26, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str27, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str28, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str29, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str30, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str31, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str32, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str33, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str34, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str35, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str36, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str37, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str38, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str39, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str40, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str41, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str42, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str43, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str44, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str45, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str46, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str47, 1, ")");
Clo g_heff_2ecompile_2einterp_2eshowValGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eshowValGo_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eshowValGo(V v_inArg_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VFun: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_243 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_243, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str0))) {
        V v_t_245 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str1), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str2)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VCons: {
    V v_fs_246 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_t_247 = heff_arrayToList(heff_take_field(v_fs_246, 0));
    V v_t_248 = heff_arrayToList(heff_get_n(v_fs_246, 2, 3));
    V v_t_249 = (g_heff_2eutil_2edict_2ezipKV(v_t_247, v_t_248));
    V v_x2_2410 = (g_list_2emap_24s1427000880x1925304966(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str3), v_t_249));
    V v_t_2413;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_xs_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str5); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str7)));
  }
  case TAG_VTag: {
    V v_x_2414 = heff_field(v_v_241, 0);
    V v_vs_2415 = heff_field(v_v_241, 1);
    V v_ru_24v_241_24VTag = heff_take_reuse_n(v_v_241, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2einterp_2elistValsGo(heff_tag_at_n(v_ru_24v_241_24VTag, TAG_VTag, 2, (V[]){heff_dup(v_x_2414), heff_dup(v_vs_2415)}), NTAG(TAG_Nil)));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_vs_2415)) {
      case TAG_Nil: {
        return v_x_2414;
      }
      case TAG_Cons: {
        if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
          V v_x2_2419 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str8), v_vs_2415));
          V v_t_2422;
          switch (heff_tag_of(v_x2_2419)) {
          case TAG_Nil: {
            v_t_2422 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str9);
            break;
          }
          case TAG_Cons: {
            V v_x_2420 = heff_field(v_x2_2419, 0);
            V v_xs_2421 = heff_field(v_x2_2419, 1);
            heff_take_n(v_x2_2419, 3ULL, 2);
            v_t_2422 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str10); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2419);
          }
          V v_t_2423 = heff_strAppend(v_x_2414, heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str11)));
          return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str12), v_t_2423);
        } else {
          V v_x2_2424 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str13), v_vs_2415));
          V v_t_2427;
          switch (heff_tag_of(v_x2_2424)) {
          case TAG_Nil: {
            v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str14);
            break;
          }
          case TAG_Cons: {
            V v_x_2425 = heff_field(v_x2_2424, 0);
            V v_xs_2426 = heff_field(v_x2_2424, 1);
            heff_take_n(v_x2_2424, 3ULL, 2);
            v_t_2427 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str15); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2424);
          }
          return heff_strAppend(v_x_2414, v_t_2427);
        }
      }
      default: return heff_nomatch(v_vs_2415);
      }
    }
    case TAG_Just: {
      V v_items_2428 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      heff_drop(v_x_2414);
      heff_drop(v_vs_2415);
      V v_x2_2429 = (g_list_2emap_24s391931963x434308123(v_items_2428));
      V v_t_2432;
      switch (heff_tag_of(v_x2_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str16);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_x2_2429, 0);
        V v_xs_2431 = heff_field(v_x2_2429, 1);
        heff_take_n(v_x2_2429, 3ULL, 2);
        v_t_2432 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str17); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2429);
      }
      return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str18), heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str19)));
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  case TAG_VInt: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2434 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2434, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str20))) {
        V v_t_2436 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str21), heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str22)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VFloat: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2438 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2438, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str23))) {
        V v_t_2440 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str24), heff_strAppend(v_t_2440, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str25)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VFloat32: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2442 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2442, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str26))) {
        V v_t_2444 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str27), heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str28)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VStr: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2446 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2446, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str29))) {
        V v_t_2448 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str30), heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str31)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VRune: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2450 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2450, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str32))) {
        V v_t_2452 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str33), heff_strAppend(v_t_2452, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str34)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VArr: {
    V v_xs_2453 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_x2_2454 = (g_list_2emap_24s391931963x434308123(heff_arrayToList(v_xs_2453)));
    V v_t_2457;
    switch (heff_tag_of(v_x2_2454)) {
    case TAG_Nil: {
      v_t_2457 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2455 = heff_field(v_x2_2454, 0);
      V v_xs_2456 = heff_field(v_x2_2454, 1);
      heff_take_n(v_x2_2454, 3ULL, 2);
      v_t_2457 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str36); V a_1 = v_x_2455; V a_2 = v_xs_2456; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2456); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2454);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str37), heff_strAppend(v_t_2457, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str38)));
  }
  case TAG_VBytes: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2459 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2459, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str39))) {
        V v_t_2461 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str40), heff_strAppend(v_t_2461, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str41)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VBits: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2464 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2464, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str42))) {
        V v_t_2466 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str43), heff_strAppend(v_t_2466, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str44)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
    }
  }
  case TAG_VErased: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2467 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2467, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str45))) {
        V v_t_2469 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str46), heff_strAppend(v_t_2469, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str47)));
      } else {
        return (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      }
    } else {
      return (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2eshowValGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_lam0, 1, 0};
Clo g_heff_2ecompile_2einterp_2eapplyErased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eapplyErased(V v_n_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_r_241)) {
  case TAG_RSucceeded: {
    V v_r1_242 = heff_dup(heff_field(v_r_241, 0));
    switch (heff_tag_of(v_r1_242)) {
    case TAG_VFun: {
      V v_f_243 = heff_field(v_r1_242, 0);
      V v_ru_24r1_242_24VFun = heff_take_reuse_n(v_r1_242, 1ULL, 1);
      heff_drop_tag(v_r_241, 1);
      if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
        heff_drop(v_n_240);
        return heff_tag_n(TAG_RSucceeded, 1, (V[]){heff_tag_at_n(v_ru_24r1_242_24VFun, TAG_VFun, 1, (V[]){v_f_243})});
      } else {
        heff_drop_cell(v_ru_24r1_242_24VFun, 1);
        V v_x1_246 = heff_tr(heff_call(v_f_243, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo)}));
        V v_t_249;
        switch (heff_tag_of(v_x1_246)) {
        case TAG_Ok: {
          V v_v_247 = heff_field(v_x1_246, 0);
          V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
          v_t_249 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_RSucceeded, 1, (V[]){v_v_247});
          break;
        }
        case TAG_Abn: {
          v_t_249 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          v_t_249 = NTAG(TAG_RDiverged);
          break;
        }
        case TAG_Bug: {
          V v_what_248 = heff_field(v_x1_246, 0);
          V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
          v_t_249 = heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_RBug, 1, (V[]){v_what_248});
          break;
        }
        default: heff_nomatch(v_x1_246);
        }
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_t_249;
        v_n_240 = t_0;
        v_r_241 = t_1;
        goto top;
      }
    }
    case TAG_VCons: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VTag: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VInt: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat: {
      heff_take_na(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat32: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VStr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VRune: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VArr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBytes: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBits: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VErased: {
      heff_drop(v_n_240);
      return v_r_241;
    }
    default: return heff_nomatch(v_r1_242);
    }
  }
  case TAG_RAbandoned: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RDiverged: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RBug: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  default: return heff_nomatch(v_r_241);
  }
}
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eapplyErased(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args) {
  V v_d_245 = args[0];
  heff_drop(v_d_245);
  return heff_tag_n(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
}