// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_Ok 9325
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_aliases 1464806715
#define LBL_entries 787768015
#define LBL_keys 9783995
#define LBL_syntax 1059664654
#define LBL_values 1123329101
V g_heff_2ecompile_2einterp_2eapplyErased(V, V);
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eapplyErased_clo;
V g_heff_2ecompile_2einterp_2ebits1(V);
V g_heff_2ecompile_2einterp_2ebits1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebits1_clo;
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void);
V g_heff_2ecompile_2einterp_2ebitsCopy(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsCopy_clo;
V g_heff_2ecompile_2einterp_2ebitsJoined(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsJoined_clo;
V g_heff_2ecompile_2einterp_2ebitsOfIntV(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsOfIntV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsOfIntV_clo;
V g_heff_2ecompile_2einterp_2ebyteString(V, V);
V g_heff_2ecompile_2einterp_2ebyteString_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebyteString_clo;
V g_heff_2ecompile_2einterp_2ebytes2(V);
V g_heff_2ecompile_2einterp_2ebytes2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytes2_clo;
V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get(void);
V g_heff_2ecompile_2einterp_2ebytesJoined(V, V);
V g_heff_2ecompile_2einterp_2ebytesJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesJoined_clo;
V g_heff_2ecompile_2einterp_2ebytesOfIntV(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfIntV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfIntV_clo;
V g_heff_2ecompile_2einterp_2ebytesOfNat(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfNat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfNat_clo;
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void);
V g_heff_2ecompile_2einterp_2efixedPrimV(V);
V g_heff_2ecompile_2einterp_2efixedPrimV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedPrimV_clo;
V g_heff_2ecompile_2einterp_2efloat2(V);
V g_heff_2ecompile_2einterp_2efloat2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloat2_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get(void);
V g_heff_2ecompile_2einterp_2efloatOfBitsV(V, V);
V g_heff_2ecompile_2einterp_2efloatOfBitsV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloatOfBitsV_clo;
V g_heff_2ecompile_2einterp_2efloatTake2(V, V, V);
V g_heff_2ecompile_2einterp_2efloatTake2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloatTake2_clo;
V g_heff_2ecompile_2einterp_2efmix64(V);
V g_heff_2ecompile_2einterp_2efmix64_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efmix64_clo;
V g_heff_2ecompile_2einterp_2efromListV(V, V);
V g_heff_2ecompile_2einterp_2efromListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efromListV_clo;
V g_heff_2ecompile_2einterp_2egenGo(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2egenGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2egenGo_clo;
V g_heff_2ecompile_2einterp_2ehashFrom(V, V, V);
V g_heff_2ecompile_2einterp_2ehashFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ehashFrom_clo;
V g_heff_2ecompile_2einterp_2eieeeBits_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeBits(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeBits_clo;
V g_heff_2ecompile_2einterp_2eieeeMagnitude_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeMagnitude(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeMagnitude_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeMagnitude_clo;
double g_heff_2ecompile_2einterp_2eieeeOf_w(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeOf_clo;
V g_heff_2ecompile_2einterp_2eint2(V);
V g_heff_2ecompile_2einterp_2eint2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eint2_clo;
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void);
V g_heff_2ecompile_2einterp_2eintAtV(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintAtV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintAtV_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_clo;
HeffT2 g_heff_2ecompile_2einterp_2elistValsGo_24cpr(V, V);
V g_heff_2ecompile_2einterp_2elittleOut(V, V);
V g_heff_2ecompile_2einterp_2elittleOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elittleOut_clo;
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotARune_get(void);
V g_heff_2ecompile_2einterp_2enotAString_get(void);
V g_heff_2ecompile_2einterp_2enotAnArray_get(void);
V g_heff_2ecompile_2einterp_2enotAnInt_get(void);
V g_heff_2ecompile_2einterp_2enotBytes_get(void);
HeffT2 g_heff_2ecompile_2einterp_2enthV_24cpr(V, V);
V g_heff_2ecompile_2einterp_2eprim(V);
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eprim_clo;
V g_heff_2ecompile_2einterp_2ereachGlobals(V, V, V);
V g_heff_2ecompile_2einterp_2ereachGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ereachGlobals_clo;
V g_heff_2ecompile_2einterp_2erune2(V);
V g_heff_2ecompile_2einterp_2erune2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2erune2_clo;
V g_heff_2ecompile_2einterp_2eruneCodes(V);
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_clo;
V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V, V);
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo;
V g_heff_2ecompile_2einterp_2escalarV(V);
V g_heff_2ecompile_2einterp_2escalarV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2escalarV_clo;
V g_heff_2ecompile_2einterp_2esetAt(V, V, V);
V g_heff_2ecompile_2einterp_2esetAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esetAt_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2einterp_2esliceV(V, V, V);
V g_heff_2ecompile_2einterp_2esliceV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esliceV_clo;
V g_heff_2ecompile_2einterp_2estr2(V);
V g_heff_2ecompile_2einterp_2estr2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2estr2_clo;
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get(void);
V g_heff_2ecompile_2einterp_2etoListV(V);
V g_heff_2ecompile_2einterp_2etoListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(V, V, V);
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(V);
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_clo;
V g_heff_2ecompile_2einterp_2etrieSlotOf(V, V, V);
V g_heff_2ecompile_2einterp_2etrieSlotOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etrieSlotOf_clo;
V g_heff_2ecompile_2einterp_2etwoTo(V);
V g_heff_2ecompile_2einterp_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoTo_clo;
V g_heff_2ecompile_2einterp_2eword64_get(void);
V g_heff_2ecompile_2einterp_2ewordOf(V, V, V);
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ewordOf_clo;
HeffT2 g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(V);
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2erename_2enubFirst(V);
V g_heff_2eelab_2erename_2enubFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2enubFirst_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1427000880x1925304966(V, V);
V g_list_2emap_24s1427000880x1925304966_entry(V self, V *a);
extern Clo g_list_2emap_24s1427000880x1925304966_clo;
V g_list_2emap_24s391931963x434308123(V);
V g_list_2emap_24s391931963x434308123_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_clo;
V g_list_2emap_24s503834852x510769098(V, V);
V g_list_2emap_24s503834852x510769098_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_rune_2evalidFrom(V, V);
V g_rune_2evalidFrom_entry(V self, V *a);
extern Clo g_rune_2evalidFrom_clo;
V g_runeFromInt_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAnInt_str0, 38, "a primitive given what is not an `Int`");

static V g_heff_2ecompile_2einterp_2enotAnInt_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAnInt_st;
static V g_heff_2ecompile_2einterp_2enotAnInt_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAnInt_str0)});
}
V g_heff_2ecompile_2einterp_2enotAnInt_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAnInt_st)) return g_heff_2ecompile_2einterp_2enotAnInt_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAnInt_val, &g_heff_2ecompile_2einterp_2enotAnInt_st, g_heff_2ecompile_2einterp_2enotAnInt_init);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAFloat64_str0, 41, "a primitive given what is not a `Float64`");

static V g_heff_2ecompile_2einterp_2enotAFloat64_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAFloat64_st;
static V g_heff_2ecompile_2einterp_2enotAFloat64_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAFloat64_str0)});
}
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAFloat64_st)) return g_heff_2ecompile_2einterp_2enotAFloat64_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAFloat64_val, &g_heff_2ecompile_2einterp_2enotAFloat64_st, g_heff_2ecompile_2einterp_2enotAFloat64_init);
}
Clo g_heff_2ecompile_2einterp_2efloatTake2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloatTake2_entry, 3, 0};

V g_heff_2ecompile_2einterp_2efloatTake2(V v_f_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_VFun: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VCons: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VTag: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VInt: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VFloat: {
    V v_a_248 = heff_tget_v(v_x2_241, 0);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_VFun: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      V v_b_2414 = heff_tget_v(v_x3_242, 0);
      return heff_tail(v_f_240, 2, (V[]){v_a_248, v_b_2414});
    }
    case TAG_VFloat32: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_VFloat32: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VStr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VRune: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VArr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VBytes: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VBits: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VErased: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2efloatTake2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2einterp_2efloatTake2(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2einterp_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ewordOf_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ewordOf(V v_n_240, V v_f_241, V v_v_242) {
top: ;
  if ((heff_unbox_word(heff_intMod(v_f_241, MK_INT(2LL))) == ((int64_t)1ULL))) {
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_245 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_246 = heff_intAdd(heff_intMod(v_v_242, v_t_244), v_t_245);
    V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    return (g_heff_2ecompile_2einterp_2elittleOut(heff_intMod(v_t_246, v_t_247), v_n_240));
  } else {
    V v_t_248 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_2410 = heff_intAdd(heff_intMod(v_v_242, v_t_248), v_t_249);
    V v_t_2411 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_240));
    return heff_intMod(v_t_2410, v_t_2411);
  }
}
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ewordOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsOfIntV_str0, 0, "");
Clo g_heff_2ecompile_2einterp_2ebitsOfIntV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsOfIntV_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ebitsOfIntV(V v_n_240, V v_f_241, V v_v_242) {
top: ;
  if (heff_intLt_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_f_241);
    heff_drop(v_v_242);
    return NTAG(TAG_Abn);
  } else {
    if (heff_intLt_c_lent(MK_INT(64LL), v_n_240, 1)) {
      heff_drop(v_n_240);
      heff_drop(v_f_241);
      heff_drop(v_v_242);
      return NTAG(TAG_Abn);
    } else {
      V v_w_245 = (g_heff_2ecompile_2einterp_2ewordOf(heff_dup(v_n_240), v_f_241, v_v_242));
      int64_t v_t_246 = ((heff_peek_word(v_n_240) + ((int64_t)7ULL)) / ((int64_t)8ULL));
      int64_t v_t_247 = ((heff_peek_word(v_n_240) + ((int64_t)7ULL)) / ((int64_t)8ULL));
      int64_t v_t_248 = ((v_t_247 * ((int64_t)8ULL)) - heff_peek_word(v_n_240));
      V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word(v_t_248)));
      V v_t_2410 = (g_heff_2ecompile_2einterp_2ebytesOfNat(heff_box_word(v_t_246), heff_intMul(v_w_245, v_t_249), ((V)&g_heff_2ecompile_2einterp_2ebitsOfIntV_str0)));
      return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_n_240, v_t_2410})});
    }
  }
}
V g_heff_2ecompile_2einterp_2ebitsOfIntV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitsOfIntV(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2eieeeBits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eieeeBits_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eieeeBits_w(V v_eb_240, V v_fb_241, double v_x_242) {
top: ;
  if ((v_x_242 == v_x_242)) {
    if ((v_x_242 < (0.0))) {
      V v_t_245 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_eb_240) + heff_peek_word(v_fb_241)))));
      V v_t_246 = (g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, ((0.0) - v_x_242)));
      return heff_intAdd(v_t_245, v_t_246);
    } else {
      if ((v_x_242 == (0.0))) {
        if ((((1.0) / v_x_242) < (0.0))) {
          V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_eb_240) + heff_peek_word(v_fb_241)))));
          V v_t_2410 = (g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, ((0.0) - v_x_242)));
          return heff_intAdd(v_t_249, v_t_2410);
        } else {
          HEFF_LAST return g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, v_x_242);
        }
      } else {
        HEFF_LAST return g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, v_x_242);
      }
    }
  } else {
    V v_t_2411 = (g_heff_2ecompile_2einterp_2etwoTo(v_eb_240));
    V v_t_2412 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_fb_241)));
    V v_t_2413 = heff_intMul(heff_intSub(v_t_2411, MK_INT(1LL)), v_t_2412);
    V v_t_2414 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_unbox_word(v_fb_241) - ((int64_t)1ULL)))));
    return heff_intAdd(v_t_2413, v_t_2414);
  }
}
V g_heff_2ecompile_2einterp_2eieeeBits(V v_eb_240, V v_fb_241, V v_box_24x_242) {
  double v_x_242 = heff_unbox_f64(v_box_24x_242);
  return (g_heff_2ecompile_2einterp_2eieeeBits_w(v_eb_240, v_fb_241, v_x_242));
}
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eieeeBits(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2efloatOfBitsV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloatOfBitsV_entry, 2, 0};

V g_heff_2ecompile_2einterp_2efloatOfBitsV(V v_n_240, V v_u_241) {
top: ;
  if (heff_intEq_c_lent(v_n_240, MK_INT(64LL), 2)) {
    heff_drop(v_n_240);
    V v_t_243 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    V v_t_245 = heff_intAdd(heff_intMod(v_u_241, v_t_243), v_t_244);
    V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    double v_t_247 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(11LL), MK_INT(52LL), heff_intMod(v_t_245, v_t_246)));
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_nf(TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_247)})});
  } else {
    if (heff_intEq_c(v_n_240, MK_INT(32LL))) {
      V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      V v_t_2410 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      V v_t_2411 = heff_intAdd(heff_intMod(v_u_241, v_t_249), v_t_2410);
      V v_t_2412 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      double v_t_2413 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(8LL), MK_INT(23LL), heff_intMod(v_t_2411, v_t_2412)));
      return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_nf(TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_2413)})});
    } else {
      heff_drop(v_u_241);
      return NTAG(TAG_Abn);
    }
  }
}
V g_heff_2ecompile_2einterp_2efloatOfBitsV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efloatOfBitsV(a[0], a[1]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eruneCodes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_VFun: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2411 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2411, heff_hole()});
      V v_u_2413 = (g_heff_2ecompile_2einterp_2eruneCodes_24dps(v_rest_242, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eruneCodes(a[0]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_VFun: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2412 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2412, heff_hole()});
      V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2413;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eruneCodes_24dps(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st;
static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st)) return g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val, &g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)(heff_unbox_f32(v_a_2414) / heff_unbox_f32(v_b_2421))))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st;
static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st)) return g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
  return heff_global(&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val, &g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init);
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = (g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(v_a_2412, v_b_2417));
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2418})});
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1, 2, 1, (V[]){v_a_241})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10, 36, "a primitive given what is not `Bits`");
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st;
static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st)) return g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val, &g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init);
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  V v_x1_242 = heff_tr(heff_call(v_a_241, 1, (V[]){v_d_240}));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Ok: {
    V v_v_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Ok = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_v_243)) {
    case TAG_VFun: {
      V v_ru_24v_243_24VFun = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFun, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0)});
    }
    case TAG_VCons: {
      V v_ru_24v_243_24VCons = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VCons, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1)});
    }
    case TAG_VTag: {
      heff_take_n(v_v_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2)});
    }
    case TAG_VInt: {
      V v_ru_24v_243_24VInt = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3)});
    }
    case TAG_VFloat: {
      V v_ru_24v_243_24VFloat = heff_take_reuse_na(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4)});
    }
    case TAG_VFloat32: {
      V v_ru_24v_243_24VFloat32 = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat32, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5)});
    }
    case TAG_VStr: {
      V v_ru_24v_243_24VStr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VStr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6)});
    }
    case TAG_VRune: {
      V v_ru_24v_243_24VRune = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VRune, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7)});
    }
    case TAG_VArr: {
      V v_ru_24v_243_24VArr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VArr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8)});
    }
    case TAG_VBytes: {
      V v_ru_24v_243_24VBytes = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VBytes, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9)});
    }
    case TAG_VBits: {
      V v_n_2415 = heff_field(v_v_243, 0);
      heff_take_n(v_v_243, 1ULL, 2);
      return heff_tag_at_n(v_ru_24x1_242_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_n_2415})});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10)});
    }
    default: return heff_nomatch(v_v_243);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2417 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Bug = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_242_24Bug, TAG_Bug, 1, (V[]){v_what_2417});
  }
  default: return heff_nomatch(v_x1_242);
  }
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str1, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str2, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str3, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str4, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str5, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str6, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str7, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str8, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str9, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str10, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str11, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str12, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str13, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str14, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str15, 9, "onWindows");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str16, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str17, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str18, 6, "intAnd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str19, 5, "intOr");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str20, 6, "intXor");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str21, 6, "intShl");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str22, 6, "intShr");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str23, 8, "floatAdd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str24, 8, "floatSub");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str25, 8, "floatMul");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str26, 8, "floatDiv");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str27, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str28, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str29, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str30, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str31, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str32, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str33, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str34, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str35, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str36, 9, "floatShow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str37, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str38, 9, "floatSqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str39, 10, "floatFloor");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str40, 8, "floatSin");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str41, 8, "floatCos");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str42, 8, "floatTan");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str43, 9, "floatAsin");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str44, 9, "floatAcos");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str45, 9, "floatAtan");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str46, 10, "floatAtan2");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str47, 8, "floatExp");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str48, 8, "floatLog");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str49, 8, "floatPow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str50, 11, "arrayLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str51, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str52, 32, "an index in range, of no element");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str53, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str54, 13, "arrayGenerate");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str55, 13, "arrayFromList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str56, 11, "arrayToList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str57, 14, "arrayReplicate");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str58, 10, "arraySlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str59, 11, "arrayAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str60, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str61, 9, "strLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str62, 8, "strSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str63, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str64, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str65, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str66, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str67, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str68, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str69, 10, "strCompare");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str70, 7, "strHash");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str71, 7, "intHash");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str72, 8, "trieSlot");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str73, 7, "strFind");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str74, 9, "strByteAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str75, 11, "strFromByte");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str76, 9, "strRuneAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str77, 12, "strRuneWidth");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str78, 12, "strRuneCount");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str79, 7, "strToJS");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str80, 9, "strFromJS");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str81, 11, "bytesLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str82, 7, "bytesAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str83, 10, "bytesSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str84, 11, "bytesAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str85, 11, "bytesConcat");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str86, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str87, 7, "bytesEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str88, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str89, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str90, 13, "bytesFromList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str91, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str92, 11, "bytesToList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str93, 15, "bytesFromString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str94, 13, "bytesAsString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str95, 13, "bytesToString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str96, 10, "bytesIntAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str97, 10, "bytesOfInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str98, 10, "bytesHasAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str99, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str100, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str101, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str102, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str103, 10, "bitsLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str104, 9, "bitsIntAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str105, 9, "bitsOfInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str106, 10, "bitsConcat");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str107, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str108, 9, "bitsSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str109, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str110, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str111, 9, "bitsBytes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str112, 6, "bitsEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str113, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str114, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str115, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str116, 9, "floatBits");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str117, 11, "floatOfBits");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str118, 6, "runeEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str119, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str120, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str121, 6, "runeLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str122, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str123, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str124, 6, "runeLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str125, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str126, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str127, 9, "runeToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str128, 4, "keep");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str129, 11, "runeFromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str130, 8, "strRunes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str131, 10, "strOfRunes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str132, 13, "no primitive ");
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam0, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam1, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam2, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam3, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam4, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam5, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam6, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam7, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam8, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam9, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam10, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam11, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam12, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam13, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam14, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam15, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam16, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam17, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam18, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam19, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam20, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam21, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam22, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam23, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam24, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam25, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam27, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam26, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam29, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam28, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam32, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam31, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam38, 1, 0};
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam36, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam35, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam40, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam39, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam42, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam41, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam44_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam44, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam43, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam47, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam46, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam51, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam50_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam50, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam53_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam53, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam54_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam54, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam57_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam57, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam58_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam58, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam59_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam59, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam60_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam60, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam61_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam61, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam62_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam62, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam65_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam65, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam67_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam67, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam69_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam69, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam70_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam70, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam72_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam72, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam74_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam74, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam75_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam75, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam76_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam76, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam77_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam77, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam78_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam78, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam80_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam80, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam83_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam83, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam84_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam84, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam85_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam85, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam86_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam86, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam87_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam87, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam88_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam88, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam89_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam89, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam90_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam90, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam94_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam94, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam97_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam97, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam100_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam100, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam104_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam104, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam107_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam107, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam110(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam108_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam108, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam111(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam111_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam111, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam112(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam112_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam112, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam114(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam113(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam113_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam113, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam116(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam115(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam115_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam115, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam118(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam117(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam117_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam117, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam119(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam119, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam120(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam120_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam120, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam121(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam121_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam121, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam122(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam122_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam122, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam124(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam124, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam123(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam123, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam125(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam125_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam125, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam126(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam126_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam126, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam127(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam127_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam127, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam128(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eprim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eprim(V v_p_240) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str0), 2)) {
    heff_drop(v_p_240);
    return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get());
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str1), 2)) {
      heff_drop(v_p_240);
      return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get());
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str2), 2)) {
        heff_drop(v_p_240);
        return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get());
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str3), 2)) {
          heff_drop(v_p_240);
          HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam0_clo));
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str4), 2)) {
            heff_drop(v_p_240);
            HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam1_clo));
          } else {
            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str5), 2)) {
              heff_drop(v_p_240);
              HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam2_clo));
            } else {
              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str8), 2)) {
                heff_drop(v_p_240);
                HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam3_clo));
              } else {
                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str11), 2)) {
                  heff_drop(v_p_240);
                  HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam4_clo));
                } else {
                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str14), 2)) {
                    heff_drop(v_p_240);
                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam5_clo)});
                  } else {
                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str15), 2)) {
                      heff_drop(v_p_240);
                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam6_clo)});
                    } else {
                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str18), 2)) {
                        heff_drop(v_p_240);
                        return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get());
                      } else {
                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str19), 2)) {
                          heff_drop(v_p_240);
                          HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam7_clo));
                        } else {
                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str20), 2)) {
                            heff_drop(v_p_240);
                            HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam8_clo));
                          } else {
                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str21), 2)) {
                              heff_drop(v_p_240);
                              HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam9_clo));
                            } else {
                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str22), 2)) {
                                heff_drop(v_p_240);
                                HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam10_clo));
                              } else {
                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str23), 2)) {
                                  heff_drop(v_p_240);
                                  return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get());
                                } else {
                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str24), 2)) {
                                    heff_drop(v_p_240);
                                    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get());
                                  } else {
                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str25), 2)) {
                                      heff_drop(v_p_240);
                                      return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get());
                                    } else {
                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str26), 2)) {
                                        heff_drop(v_p_240);
                                        return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get());
                                      } else {
                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str27), 2)) {
                                          heff_drop(v_p_240);
                                          HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam11_clo));
                                        } else {
                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str30), 2)) {
                                            heff_drop(v_p_240);
                                            HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam12_clo));
                                          } else {
                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str33), 2)) {
                                              heff_drop(v_p_240);
                                              HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam13_clo));
                                            } else {
                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str36), 2)) {
                                                heff_drop(v_p_240);
                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam14_clo)});
                                              } else {
                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str37), 2)) {
                                                  heff_drop(v_p_240);
                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam15_clo)});
                                                } else {
                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str38), 2)) {
                                                    heff_drop(v_p_240);
                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam16_clo)});
                                                  } else {
                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str39), 2)) {
                                                      heff_drop(v_p_240);
                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam17_clo)});
                                                    } else {
                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str40), 2)) {
                                                        heff_drop(v_p_240);
                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam18_clo)});
                                                      } else {
                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str41), 2)) {
                                                          heff_drop(v_p_240);
                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam19_clo)});
                                                        } else {
                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str42), 2)) {
                                                            heff_drop(v_p_240);
                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam20_clo)});
                                                          } else {
                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str43), 2)) {
                                                              heff_drop(v_p_240);
                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam21_clo)});
                                                            } else {
                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str44), 2)) {
                                                                heff_drop(v_p_240);
                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam22_clo)});
                                                              } else {
                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str45), 2)) {
                                                                  heff_drop(v_p_240);
                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam23_clo)});
                                                                } else {
                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str46), 2)) {
                                                                    heff_drop(v_p_240);
                                                                    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get());
                                                                  } else {
                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str47), 2)) {
                                                                      heff_drop(v_p_240);
                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam24_clo)});
                                                                    } else {
                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str48), 2)) {
                                                                        heff_drop(v_p_240);
                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam25_clo)});
                                                                      } else {
                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str49), 2)) {
                                                                          heff_drop(v_p_240);
                                                                          return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get());
                                                                        } else {
                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str50), 2)) {
                                                                            heff_drop(v_p_240);
                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam26_clo)});
                                                                          } else {
                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str51), 2)) {
                                                                              heff_drop(v_p_240);
                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam28_clo)});
                                                                            } else {
                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str53), 2)) {
                                                                                heff_drop(v_p_240);
                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam31_clo)});
                                                                              } else {
                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str54), 2)) {
                                                                                  heff_drop(v_p_240);
                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam35_clo)});
                                                                                } else {
                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str55), 2)) {
                                                                                    heff_drop(v_p_240);
                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam39_clo)});
                                                                                  } else {
                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str56), 2)) {
                                                                                      heff_drop(v_p_240);
                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam41_clo)});
                                                                                    } else {
                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str57), 2)) {
                                                                                        heff_drop(v_p_240);
                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam43_clo)});
                                                                                      } else {
                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str58), 2)) {
                                                                                          heff_drop(v_p_240);
                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam46_clo)});
                                                                                        } else {
                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str59), 2)) {
                                                                                            heff_drop(v_p_240);
                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam50_clo)});
                                                                                          } else {
                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str60), 2)) {
                                                                                              heff_drop(v_p_240);
                                                                                              return heff_dup(g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get());
                                                                                            } else {
                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str61), 2)) {
                                                                                                heff_drop(v_p_240);
                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam53_clo)});
                                                                                              } else {
                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str62), 2)) {
                                                                                                  heff_drop(v_p_240);
                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam54_clo)});
                                                                                                } else {
                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str63), 2)) {
                                                                                                    heff_drop(v_p_240);
                                                                                                    HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam57_clo));
                                                                                                  } else {
                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str66), 2)) {
                                                                                                      heff_drop(v_p_240);
                                                                                                      HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam58_clo));
                                                                                                    } else {
                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str69), 2)) {
                                                                                                        heff_drop(v_p_240);
                                                                                                        HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam59_clo));
                                                                                                      } else {
                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str70), 2)) {
                                                                                                          heff_drop(v_p_240);
                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam60_clo)});
                                                                                                        } else {
                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str71), 2)) {
                                                                                                            heff_drop(v_p_240);
                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam61_clo)});
                                                                                                          } else {
                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str72), 2)) {
                                                                                                              heff_drop(v_p_240);
                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam62_clo)});
                                                                                                            } else {
                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str73), 2)) {
                                                                                                                heff_drop(v_p_240);
                                                                                                                HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam65_clo));
                                                                                                              } else {
                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str74), 2)) {
                                                                                                                  heff_drop(v_p_240);
                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam67_clo)});
                                                                                                                } else {
                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str75), 2)) {
                                                                                                                    heff_drop(v_p_240);
                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam69_clo)});
                                                                                                                  } else {
                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str76), 2)) {
                                                                                                                      heff_drop(v_p_240);
                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam70_clo)});
                                                                                                                    } else {
                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str77), 2)) {
                                                                                                                        heff_drop(v_p_240);
                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam72_clo)});
                                                                                                                      } else {
                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str78), 2)) {
                                                                                                                          heff_drop(v_p_240);
                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam74_clo)});
                                                                                                                        } else {
                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str79), 2)) {
                                                                                                                            heff_drop(v_p_240);
                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam75_clo)});
                                                                                                                          } else {
                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str80), 2)) {
                                                                                                                              heff_drop(v_p_240);
                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam76_clo)});
                                                                                                                            } else {
                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str81), 2)) {
                                                                                                                                heff_drop(v_p_240);
                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam77_clo)});
                                                                                                                              } else {
                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str82), 2)) {
                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam78_clo)});
                                                                                                                                } else {
                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str83), 2)) {
                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam80_clo)});
                                                                                                                                  } else {
                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str84), 2)) {
                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                      return heff_dup(g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get());
                                                                                                                                    } else {
                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str85), 2)) {
                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam83_clo)});
                                                                                                                                      } else {
                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str87), 2)) {
                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                          HEFF_LAST return g_heff_2ecompile_2einterp_2ebytes2(((V)&g_heff_2ecompile_2einterp_2eprim_lam84_clo));
                                                                                                                                        } else {
                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str90), 2)) {
                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam85_clo)});
                                                                                                                                          } else {
                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str92), 2)) {
                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam86_clo)});
                                                                                                                                            } else {
                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str93), 2)) {
                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam87_clo)});
                                                                                                                                              } else {
                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str94), 2)) {
                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam88_clo)});
                                                                                                                                                } else {
                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str95), 2)) {
                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam89_clo)});
                                                                                                                                                  } else {
                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str96), 2)) {
                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam90_clo)});
                                                                                                                                                    } else {
                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str97), 2)) {
                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam94_clo)});
                                                                                                                                                      } else {
                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str98), 2)) {
                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam97_clo)});
                                                                                                                                                        } else {
                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str103), 2)) {
                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                            return heff_dup(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get());
                                                                                                                                                          } else {
                                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str104), 2)) {
                                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                                              HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam100_clo));
                                                                                                                                                            } else {
                                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str105), 2)) {
                                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam104_clo)});
                                                                                                                                                              } else {
                                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str106), 2)) {
                                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam107_clo)});
                                                                                                                                                                } else {
                                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str108), 2)) {
                                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                                    HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam108_clo));
                                                                                                                                                                  } else {
                                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str110), 2)) {
                                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam111_clo)});
                                                                                                                                                                    } else {
                                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str111), 2)) {
                                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                                        HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam112_clo));
                                                                                                                                                                      } else {
                                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str112), 2)) {
                                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                                          HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam113_clo));
                                                                                                                                                                        } else {
                                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str116), 2)) {
                                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam115_clo)});
                                                                                                                                                                          } else {
                                                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str117), 2)) {
                                                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam117_clo)});
                                                                                                                                                                            } else {
                                                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str118), 2)) {
                                                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                                                HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam119_clo));
                                                                                                                                                                              } else {
                                                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str121), 2)) {
                                                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                                                  HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam120_clo));
                                                                                                                                                                                } else {
                                                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str124), 2)) {
                                                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                                                    HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam121_clo));
                                                                                                                                                                                  } else {
                                                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str127), 2)) {
                                                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam122_clo)});
                                                                                                                                                                                    } else {
                                                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str128), 2)) {
                                                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam123_clo)});
                                                                                                                                                                                      } else {
                                                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str129), 2)) {
                                                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam125_clo)});
                                                                                                                                                                                        } else {
                                                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str130), 2)) {
                                                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam126_clo)});
                                                                                                                                                                                          } else {
                                                                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str131), 2)) {
                                                                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam127_clo)});
                                                                                                                                                                                            } else {
                                                                                                                                                                                              HeffT2 v_t_241849 = (g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(v_p_240));
                                                                                                                                                                                              {
                                                                                                                                                                                                V v_field_241851 = v_t_241849.f[1];
                                                                                                                                                                                                int64_t v_tag_241850 = ((int64_t)v_t_241849.f[0]);
                                                                                                                                                                                                if ((v_tag_241850 == ((int64_t)0ULL))) {
                                                                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                                                                  V v_fp_241853 = v_field_241851;
                                                                                                                                                                                                  HEFF_LAST return g_heff_2ecompile_2einterp_2efixedPrimV(v_fp_241853);
                                                                                                                                                                                                } else {
                                                                                                                                                                                                  heff_drop(v_field_241851);
                                                                                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam128, 2, 1, (V[]){v_p_240})});
                                                                                                                                                                                                }
                                                                                                                                                                                              }
                                                                                                                                                                                            }
                                                                                                                                                                                          }
                                                                                                                                                                                        }
                                                                                                                                                                                      }
                                                                                                                                                                                    }
                                                                                                                                                                                  }
                                                                                                                                                                                }
                                                                                                                                                                              }
                                                                                                                                                                            }
                                                                                                                                                                          }
                                                                                                                                                                        }
                                                                                                                                                                      }
                                                                                                                                                                    }
                                                                                                                                                                  }
                                                                                                                                                                }
                                                                                                                                                              }
                                                                                                                                                            }
                                                                                                                                                          }
                                                                                                                                                        }
                                                                                                                                                      }
                                                                                                                                                    }
                                                                                                                                                  }
                                                                                                                                                }
                                                                                                                                              }
                                                                                                                                            }
                                                                                                                                          }
                                                                                                                                        }
                                                                                                                                      }
                                                                                                                                    }
                                                                                                                                  }
                                                                                                                                }
                                                                                                                              }
                                                                                                                            }
                                                                                                                          }
                                                                                                                        }
                                                                                                                      }
                                                                                                                    }
                                                                                                                  }
                                                                                                                }
                                                                                                              }
                                                                                                            }
                                                                                                          }
                                                                                                        }
                                                                                                      }
                                                                                                    }
                                                                                                  }
                                                                                                }
                                                                                              }
                                                                                            }
                                                                                          }
                                                                                        }
                                                                                      }
                                                                                    }
                                                                                  }
                                                                                }
                                                                              }
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eprim(a[0]);
}
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_b_246 = args[1];
  if (heff_intEq_c_lent(v_b_246, MK_INT(0LL), 2)) {
    heff_drop(v_a_245);
    heff_drop(v_b_246);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){MK_INT(0LL)})});
  } else {
    V v_t_248 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_245, v_b_246)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_248});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args) {
  V v_a_2410 = args[0];
  V v_b_2411 = args[1];
  if (heff_intEq_c_lent(v_b_2411, MK_INT(0LL), 2)) {
    heff_drop(v_b_2411);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_2410})});
  } else {
    V v_t_2413 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMod(v_a_2410, v_b_2411)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2413});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args) {
  V v_a_2415 = args[0];
  V v_b_2416 = args[1];
  V v_t_2418;
  if (heff_intEq_c(v_a_2415, v_b_2416)) {
    v_t_2418 = ((V)&g_heff_2ecompile_2einterp_2eprim_str6);
  } else {
    v_t_2418 = ((V)&g_heff_2ecompile_2einterp_2eprim_str7);
  }
  V v_t_2419 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2419});
}
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args) {
  V v_a_2421 = args[0];
  V v_b_2422 = args[1];
  V v_t_2424;
  if (heff_intLt_c(v_a_2421, v_b_2422)) {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2eprim_str9);
  } else {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2eprim_str10);
  }
  V v_t_2425 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2425});
}
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args) {
  V v_a_2427 = args[0];
  V v_b_2428 = args[1];
  V v_t_2430;
  if (heff_intLe_c(v_a_2427, v_b_2428)) {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2eprim_str12);
  } else {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2eprim_str13);
  }
  V v_t_2431 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2431});
}
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args) {
  V v_d_2433 = args[0];
  V v_a_2434 = args[1];
  V v_x1_2435 = heff_tr(heff_call(v_a_2434, 1, (V[]){v_d_2433}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_Ok: {
    V v_v_2436 = heff_field(v_x1_2435, 0);
    V v_ru_24x1_2435_24Ok = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
    switch (heff_tag_of(v_v_2436)) {
    case TAG_VFun: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2436, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_2441 = heff_field(v_v_2436, 0);
      V v_ru_24v_2436_24VInt = heff_take_reuse_n(v_v_2436, 1ULL, 1);
      V v_t_2442 = heff_tag_at_n(v_ru_24v_2436_24VInt, TAG_VStr, 1, (V[]){heff_intShow(v_a_2441)});
      return heff_tag_at_n(v_ru_24x1_2435_24Ok, TAG_Ok, 1, (V[]){v_t_2442});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2436, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_2436);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2451 = heff_field(v_x1_2435, 0);
    V v_ru_24x1_2435_24Bug = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2435_24Bug, TAG_Bug, 1, (V[]){v_what_2451});
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args) {
  V v_d_2453 = args[0];
  V v_a_2454 = args[1];
  heff_drop(v_d_2453);
  heff_drop(v_a_2454);
  V v_t_2455 = heff_onWindows(NTAG(TAG_MkUnit));
  V v_t_2456;
  if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
    heff_drop(v_t_2455);
    v_t_2456 = ((V)&g_heff_2ecompile_2einterp_2eprim_str16);
  } else {
    heff_drop(v_t_2455);
    v_t_2456 = ((V)&g_heff_2ecompile_2einterp_2eprim_str17);
  }
  V v_t_2457 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2456, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2457});
}
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args) {
  V v_a_2460 = args[0];
  V v_b_2461 = args[1];
  V v_t_2462 = (g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), v_a_2460, v_b_2461));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2462})});
}
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args) {
  V v_a_2464 = args[0];
  V v_b_2465 = args[1];
  V v_t_2466 = (g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(MK_INT(2LL), v_a_2464, v_b_2465));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2466})});
}
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args) {
  V v_a_2468 = args[0];
  V v_b_2469 = args[1];
  if (heff_intLt_c_lent(v_b_2469, MK_INT(0LL), 2)) {
    V v_k_2471 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2469)));
    V v_t_2472 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2468, v_k_2471)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2472});
  } else {
    V v_k_2473 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2469));
    V v_t_2474 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2468, v_k_2473)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2474});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args) {
  V v_a_2476 = args[0];
  V v_b_2477 = args[1];
  if (heff_intLt_c_lent(v_b_2477, MK_INT(0LL), 2)) {
    V v_k_2479 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2477)));
    V v_t_2480 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2476, v_k_2479)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2480});
  } else {
    V v_k_2481 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2477));
    V v_t_2482 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2476, v_k_2481)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2482});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args) {
  V v_box_24a_2488 = args[0];
  V v_box_24b_2489 = args[1];
  double v_a_2488 = heff_unbox_f64(v_box_24a_2488);
  double v_b_2489 = heff_unbox_f64(v_box_24b_2489);
  V v_t_2491;
  if ((v_a_2488 == v_b_2489)) {
    v_t_2491 = ((V)&g_heff_2ecompile_2einterp_2eprim_str28);
  } else {
    v_t_2491 = ((V)&g_heff_2ecompile_2einterp_2eprim_str29);
  }
  V v_t_2492 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2491, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2492});
}
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args) {
  V v_box_24a_2494 = args[0];
  V v_box_24b_2495 = args[1];
  double v_a_2494 = heff_unbox_f64(v_box_24a_2494);
  double v_b_2495 = heff_unbox_f64(v_box_24b_2495);
  V v_t_2497;
  if ((v_a_2494 < v_b_2495)) {
    v_t_2497 = ((V)&g_heff_2ecompile_2einterp_2eprim_str31);
  } else {
    v_t_2497 = ((V)&g_heff_2ecompile_2einterp_2eprim_str32);
  }
  V v_t_2498 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2497, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2498});
}
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args) {
  V v_box_24a_24100 = args[0];
  V v_box_24b_24101 = args[1];
  double v_a_24100 = heff_unbox_f64(v_box_24a_24100);
  double v_b_24101 = heff_unbox_f64(v_box_24b_24101);
  V v_t_24103;
  if ((v_a_24100 <= v_b_24101)) {
    v_t_24103 = ((V)&g_heff_2ecompile_2einterp_2eprim_str34);
  } else {
    v_t_24103 = ((V)&g_heff_2ecompile_2einterp_2eprim_str35);
  }
  V v_t_24104 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24103, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24104});
}
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args) {
  V v_d_24106 = args[0];
  V v_a_24107 = args[1];
  V v_x1_24108 = heff_tr(heff_call(v_a_24107, 1, (V[]){v_d_24106}));
  switch (heff_tag_of(v_x1_24108)) {
  case TAG_Ok: {
    V v_v_24109 = heff_field(v_x1_24108, 0);
    V v_ru_24x1_24108_24Ok = heff_take_reuse_n(v_x1_24108, 1ULL, 1);
    switch (heff_tag_of(v_v_24109)) {
    case TAG_VFun: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24109, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      V v_a_24115 = heff_tget_v(v_v_24109, 0);
      V v_ru_24v_24109_24VFloat = heff_take_reuse_na(v_v_24109, 0ULL, 1);
      V v_t_24116 = heff_tag_at_n(v_ru_24v_24109_24VFloat, TAG_VStr, 1, (V[]){heff_floatShow(v_a_24115)});
      return heff_tag_at_n(v_ru_24x1_24108_24Ok, TAG_Ok, 1, (V[]){v_t_24116});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24109, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24109);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24124 = heff_field(v_x1_24108, 0);
    V v_ru_24x1_24108_24Bug = heff_take_reuse_n(v_x1_24108, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24108_24Bug, TAG_Bug, 1, (V[]){v_what_24124});
  }
  default: return heff_nomatch(v_x1_24108);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args) {
  V v_d_24126 = args[0];
  V v_a_24127 = args[1];
  V v_x1_24128 = heff_tr(heff_call(v_a_24127, 1, (V[]){v_d_24126}));
  switch (heff_tag_of(v_x1_24128)) {
  case TAG_Ok: {
    V v_v_24129 = heff_field(v_x1_24128, 0);
    V v_ru_24x1_24128_24Ok = heff_take_reuse_n(v_x1_24128, 1ULL, 1);
    switch (heff_tag_of(v_v_24129)) {
    case TAG_VFun: {
      heff_take_n(v_v_24129, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24129, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24129, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24134 = heff_field(v_v_24129, 0);
      V v_ru_24v_24129_24VInt = heff_take_reuse_n(v_v_24129, 1ULL, 1);
      V v_t_24135 = heff_tag_at_nf(v_ru_24v_24129_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(heff_from_int_f64(v_a_24134))});
      return heff_tag_at_n(v_ru_24x1_24128_24Ok, TAG_Ok, 1, (V[]){v_t_24135});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24129, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24129, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24129, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24129, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24129, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24129, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24129, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24128_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24129);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24144 = heff_field(v_x1_24128, 0);
    V v_ru_24x1_24128_24Bug = heff_take_reuse_n(v_x1_24128, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24128_24Bug, TAG_Bug, 1, (V[]){v_what_24144});
  }
  default: return heff_nomatch(v_x1_24128);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args) {
  V v_d_24146 = args[0];
  V v_a_24147 = args[1];
  V v_x1_24148 = heff_tr(heff_call(v_a_24147, 1, (V[]){v_d_24146}));
  switch (heff_tag_of(v_x1_24148)) {
  case TAG_Ok: {
    V v_v_24149 = heff_field(v_x1_24148, 0);
    V v_ru_24x1_24148_24Ok = heff_take_reuse_n(v_x1_24148, 1ULL, 1);
    switch (heff_tag_of(v_v_24149)) {
    case TAG_VFun: {
      heff_take_n(v_v_24149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24149, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24155 = heff_tflat_f64(v_v_24149, 0);
      V v_ru_24v_24149_24VFloat = heff_take_reuse_na(v_v_24149, 0ULL, 1);
      V v_t_24156 = heff_tag_at_nf(v_ru_24v_24149_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(sqrt(v_a_24155))});
      return heff_tag_at_n(v_ru_24x1_24148_24Ok, TAG_Ok, 1, (V[]){v_t_24156});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24149, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24149);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24164 = heff_field(v_x1_24148, 0);
    V v_ru_24x1_24148_24Bug = heff_take_reuse_n(v_x1_24148, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24148_24Bug, TAG_Bug, 1, (V[]){v_what_24164});
  }
  default: return heff_nomatch(v_x1_24148);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args) {
  V v_d_24166 = args[0];
  V v_a_24167 = args[1];
  V v_x1_24168 = heff_tr(heff_call(v_a_24167, 1, (V[]){v_d_24166}));
  switch (heff_tag_of(v_x1_24168)) {
  case TAG_Ok: {
    V v_v_24169 = heff_field(v_x1_24168, 0);
    V v_ru_24x1_24168_24Ok = heff_take_reuse_n(v_x1_24168, 1ULL, 1);
    switch (heff_tag_of(v_v_24169)) {
    case TAG_VFun: {
      heff_take_n(v_v_24169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24169, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24175 = heff_tflat_f64(v_v_24169, 0);
      V v_ru_24v_24169_24VFloat = heff_take_reuse_na(v_v_24169, 0ULL, 1);
      if (((v_a_24175 - v_a_24175) == (0.0))) {
        V v_t_24177 = heff_tag_at_n(v_ru_24v_24169_24VFloat, TAG_VInt, 1, (V[]){heff_floor_f64(v_a_24175)});
        return heff_tag_at_n(v_ru_24x1_24168_24Ok, TAG_Ok, 1, (V[]){v_t_24177});
      } else {
        heff_drop_cell(v_ru_24v_24169_24VFloat, 1);
        return heff_tag_at_n(v_ru_24x1_24168_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){MK_INT(0LL)})});
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24169, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24169, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24168_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24169);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24185 = heff_field(v_x1_24168, 0);
    V v_ru_24x1_24168_24Bug = heff_take_reuse_n(v_x1_24168, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24168_24Bug, TAG_Bug, 1, (V[]){v_what_24185});
  }
  default: return heff_nomatch(v_x1_24168);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args) {
  V v_d_24187 = args[0];
  V v_a_24188 = args[1];
  V v_x1_24189 = heff_tr(heff_call(v_a_24188, 1, (V[]){v_d_24187}));
  switch (heff_tag_of(v_x1_24189)) {
  case TAG_Ok: {
    V v_v_24190 = heff_field(v_x1_24189, 0);
    V v_ru_24x1_24189_24Ok = heff_take_reuse_n(v_x1_24189, 1ULL, 1);
    switch (heff_tag_of(v_v_24190)) {
    case TAG_VFun: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24190, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24196 = heff_tflat_f64(v_v_24190, 0);
      V v_ru_24v_24190_24VFloat = heff_take_reuse_na(v_v_24190, 0ULL, 1);
      V v_t_24197 = heff_tag_at_nf(v_ru_24v_24190_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(sin(v_a_24196))});
      return heff_tag_at_n(v_ru_24x1_24189_24Ok, TAG_Ok, 1, (V[]){v_t_24197});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24190, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24190);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24205 = heff_field(v_x1_24189, 0);
    V v_ru_24x1_24189_24Bug = heff_take_reuse_n(v_x1_24189, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24189_24Bug, TAG_Bug, 1, (V[]){v_what_24205});
  }
  default: return heff_nomatch(v_x1_24189);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args) {
  V v_d_24207 = args[0];
  V v_a_24208 = args[1];
  V v_x1_24209 = heff_tr(heff_call(v_a_24208, 1, (V[]){v_d_24207}));
  switch (heff_tag_of(v_x1_24209)) {
  case TAG_Ok: {
    V v_v_24210 = heff_field(v_x1_24209, 0);
    V v_ru_24x1_24209_24Ok = heff_take_reuse_n(v_x1_24209, 1ULL, 1);
    switch (heff_tag_of(v_v_24210)) {
    case TAG_VFun: {
      heff_take_n(v_v_24210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24210, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24216 = heff_tflat_f64(v_v_24210, 0);
      V v_ru_24v_24210_24VFloat = heff_take_reuse_na(v_v_24210, 0ULL, 1);
      V v_t_24217 = heff_tag_at_nf(v_ru_24v_24210_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(cos(v_a_24216))});
      return heff_tag_at_n(v_ru_24x1_24209_24Ok, TAG_Ok, 1, (V[]){v_t_24217});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24210, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24210);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24225 = heff_field(v_x1_24209, 0);
    V v_ru_24x1_24209_24Bug = heff_take_reuse_n(v_x1_24209, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24209_24Bug, TAG_Bug, 1, (V[]){v_what_24225});
  }
  default: return heff_nomatch(v_x1_24209);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args) {
  V v_d_24227 = args[0];
  V v_a_24228 = args[1];
  V v_x1_24229 = heff_tr(heff_call(v_a_24228, 1, (V[]){v_d_24227}));
  switch (heff_tag_of(v_x1_24229)) {
  case TAG_Ok: {
    V v_v_24230 = heff_field(v_x1_24229, 0);
    V v_ru_24x1_24229_24Ok = heff_take_reuse_n(v_x1_24229, 1ULL, 1);
    switch (heff_tag_of(v_v_24230)) {
    case TAG_VFun: {
      heff_take_n(v_v_24230, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24230, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24230, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24230, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24236 = heff_tflat_f64(v_v_24230, 0);
      V v_ru_24v_24230_24VFloat = heff_take_reuse_na(v_v_24230, 0ULL, 1);
      V v_t_24237 = heff_tag_at_nf(v_ru_24v_24230_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(tan(v_a_24236))});
      return heff_tag_at_n(v_ru_24x1_24229_24Ok, TAG_Ok, 1, (V[]){v_t_24237});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24230, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24230, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24230, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24230, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24230, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24230, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24229_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24230);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24245 = heff_field(v_x1_24229, 0);
    V v_ru_24x1_24229_24Bug = heff_take_reuse_n(v_x1_24229, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24229_24Bug, TAG_Bug, 1, (V[]){v_what_24245});
  }
  default: return heff_nomatch(v_x1_24229);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args) {
  V v_d_24247 = args[0];
  V v_a_24248 = args[1];
  V v_x1_24249 = heff_tr(heff_call(v_a_24248, 1, (V[]){v_d_24247}));
  switch (heff_tag_of(v_x1_24249)) {
  case TAG_Ok: {
    V v_v_24250 = heff_field(v_x1_24249, 0);
    V v_ru_24x1_24249_24Ok = heff_take_reuse_n(v_x1_24249, 1ULL, 1);
    switch (heff_tag_of(v_v_24250)) {
    case TAG_VFun: {
      heff_take_n(v_v_24250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24250, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24256 = heff_tflat_f64(v_v_24250, 0);
      V v_ru_24v_24250_24VFloat = heff_take_reuse_na(v_v_24250, 0ULL, 1);
      V v_t_24257 = heff_tag_at_nf(v_ru_24v_24250_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(asin(v_a_24256))});
      return heff_tag_at_n(v_ru_24x1_24249_24Ok, TAG_Ok, 1, (V[]){v_t_24257});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24250, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24250);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24265 = heff_field(v_x1_24249, 0);
    V v_ru_24x1_24249_24Bug = heff_take_reuse_n(v_x1_24249, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24249_24Bug, TAG_Bug, 1, (V[]){v_what_24265});
  }
  default: return heff_nomatch(v_x1_24249);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args) {
  V v_d_24267 = args[0];
  V v_a_24268 = args[1];
  V v_x1_24269 = heff_tr(heff_call(v_a_24268, 1, (V[]){v_d_24267}));
  switch (heff_tag_of(v_x1_24269)) {
  case TAG_Ok: {
    V v_v_24270 = heff_field(v_x1_24269, 0);
    V v_ru_24x1_24269_24Ok = heff_take_reuse_n(v_x1_24269, 1ULL, 1);
    switch (heff_tag_of(v_v_24270)) {
    case TAG_VFun: {
      heff_take_n(v_v_24270, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24269_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24270, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24269_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24270, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24269_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24270, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24269_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24276 = heff_tflat_f64(v_v_24270, 0);
      V v_ru_24v_24270_24VFloat = heff_take_reuse_na(v_v_24270, 0ULL, 1);
      V v_t_24277 = heff_tag_at_nf(v_ru_24v_24270_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(acos(v_a_24276))});
      return heff_tag_at_n(v_ru_24x1_24269_24Ok, TAG_Ok, 1, (V[]){v_t_24277});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24270, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24269_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24270, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24269_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24270, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24269_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24270, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24269_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24270, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24269_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24270, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24269_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24269_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24270);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24285 = heff_field(v_x1_24269, 0);
    V v_ru_24x1_24269_24Bug = heff_take_reuse_n(v_x1_24269, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24269_24Bug, TAG_Bug, 1, (V[]){v_what_24285});
  }
  default: return heff_nomatch(v_x1_24269);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args) {
  V v_d_24287 = args[0];
  V v_a_24288 = args[1];
  V v_x1_24289 = heff_tr(heff_call(v_a_24288, 1, (V[]){v_d_24287}));
  switch (heff_tag_of(v_x1_24289)) {
  case TAG_Ok: {
    V v_v_24290 = heff_field(v_x1_24289, 0);
    V v_ru_24x1_24289_24Ok = heff_take_reuse_n(v_x1_24289, 1ULL, 1);
    switch (heff_tag_of(v_v_24290)) {
    case TAG_VFun: {
      heff_take_n(v_v_24290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24290, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24296 = heff_tflat_f64(v_v_24290, 0);
      V v_ru_24v_24290_24VFloat = heff_take_reuse_na(v_v_24290, 0ULL, 1);
      V v_t_24297 = heff_tag_at_nf(v_ru_24v_24290_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(atan(v_a_24296))});
      return heff_tag_at_n(v_ru_24x1_24289_24Ok, TAG_Ok, 1, (V[]){v_t_24297});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24290, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24290);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24305 = heff_field(v_x1_24289, 0);
    V v_ru_24x1_24289_24Bug = heff_take_reuse_n(v_x1_24289, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24289_24Bug, TAG_Bug, 1, (V[]){v_what_24305});
  }
  default: return heff_nomatch(v_x1_24289);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args) {
  V v_d_24308 = args[0];
  V v_a_24309 = args[1];
  V v_x1_24310 = heff_tr(heff_call(v_a_24309, 1, (V[]){v_d_24308}));
  switch (heff_tag_of(v_x1_24310)) {
  case TAG_Ok: {
    V v_v_24311 = heff_field(v_x1_24310, 0);
    V v_ru_24x1_24310_24Ok = heff_take_reuse_n(v_x1_24310, 1ULL, 1);
    switch (heff_tag_of(v_v_24311)) {
    case TAG_VFun: {
      heff_take_n(v_v_24311, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24310_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24311, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24310_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24311, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24310_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24311, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24310_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24317 = heff_tflat_f64(v_v_24311, 0);
      V v_ru_24v_24311_24VFloat = heff_take_reuse_na(v_v_24311, 0ULL, 1);
      V v_t_24318 = heff_tag_at_nf(v_ru_24v_24311_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(exp(v_a_24317))});
      return heff_tag_at_n(v_ru_24x1_24310_24Ok, TAG_Ok, 1, (V[]){v_t_24318});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24311, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24310_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24311, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24310_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24311, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24310_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24311, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24310_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24311, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24310_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24311, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24310_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24310_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24311);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24326 = heff_field(v_x1_24310, 0);
    V v_ru_24x1_24310_24Bug = heff_take_reuse_n(v_x1_24310, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24310_24Bug, TAG_Bug, 1, (V[]){v_what_24326});
  }
  default: return heff_nomatch(v_x1_24310);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args) {
  V v_d_24328 = args[0];
  V v_a_24329 = args[1];
  V v_x1_24330 = heff_tr(heff_call(v_a_24329, 1, (V[]){v_d_24328}));
  switch (heff_tag_of(v_x1_24330)) {
  case TAG_Ok: {
    V v_v_24331 = heff_field(v_x1_24330, 0);
    V v_ru_24x1_24330_24Ok = heff_take_reuse_n(v_x1_24330, 1ULL, 1);
    switch (heff_tag_of(v_v_24331)) {
    case TAG_VFun: {
      heff_take_n(v_v_24331, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24330_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24331, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24330_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24331, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24330_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24331, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24330_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24337 = heff_tflat_f64(v_v_24331, 0);
      V v_ru_24v_24331_24VFloat = heff_take_reuse_na(v_v_24331, 0ULL, 1);
      V v_t_24338 = heff_tag_at_nf(v_ru_24v_24331_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(log(v_a_24337))});
      return heff_tag_at_n(v_ru_24x1_24330_24Ok, TAG_Ok, 1, (V[]){v_t_24338});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24331, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24330_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24331, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24330_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24331, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24330_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24331, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24330_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24331, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24330_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24331, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24330_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24330_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24331);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24346 = heff_field(v_x1_24330, 0);
    V v_ru_24x1_24330_24Bug = heff_take_reuse_n(v_x1_24330, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24330_24Bug, TAG_Bug, 1, (V[]){v_what_24346});
  }
  default: return heff_nomatch(v_x1_24330);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args) {
  V v_d_24351 = args[0];
  V v_a_24352 = args[1];
  V v_x1_24353 = heff_tr(heff_call(v_a_24352, 1, (V[]){v_d_24351}));
  switch (heff_tag_of(v_x1_24353)) {
  case TAG_Ok: {
    V v_v_24354 = heff_field(v_x1_24353, 0);
    V v_ru_24x1_24353_24Ok = heff_take_reuse_n(v_x1_24353, 1ULL, 1);
    switch (heff_tag_of(v_v_24354)) {
    case TAG_VFun: {
      heff_take_n(v_v_24354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24354, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24364 = heff_field(v_v_24354, 0);
      heff_take_n(v_v_24354, 1ULL, 1);
      V v_t_24365 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_xs_24364); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      return heff_tag_at_n(v_ru_24x1_24353_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24365})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24354, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24354);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24369 = heff_field(v_x1_24353, 0);
    V v_ru_24x1_24353_24Bug = heff_take_reuse_n(v_x1_24353, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24353_24Bug, TAG_Bug, 1, (V[]){v_what_24369});
  }
  default: return heff_nomatch(v_x1_24353);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args) {
  V v_d_24349 = args[0];
  V v_u_24350 = args[1];
  heff_drop(v_d_24349);
  heff_drop(v_u_24350);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam27_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args) {
  V v_d_24387 = args[0];
  V v_a_24388 = args[1];
  V v_xs_24386 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24389 = heff_tr(heff_call(v_a_24388, 1, (V[]){v_d_24387}));
  switch (heff_tag_of(v_x1_24389)) {
  case TAG_Ok: {
    V v_v_24390 = heff_field(v_x1_24389, 0);
    V v_ru_24x1_24389_24Ok = heff_take_reuse_n(v_x1_24389, 1ULL, 1);
    switch (heff_tag_of(v_v_24390)) {
    case TAG_VFun: {
      heff_take_n(v_v_24390, 0ULL, 1);
      heff_drop(v_xs_24386);
      heff_drop_cell(v_ru_24x1_24389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24390, 0ULL, 1);
      heff_drop(v_xs_24386);
      heff_drop_cell(v_ru_24x1_24389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24390, 0ULL, 2);
      heff_drop(v_xs_24386);
      heff_drop_cell(v_ru_24x1_24389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24395 = heff_field(v_v_24390, 0);
      V v_ru_24v_24390_24VInt = heff_take_reuse_n(v_v_24390, 1ULL, 1);
      if (heff_intLe_c_lent(MK_INT(0LL), v_a_24395, 1)) {
        V v_t_24397 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24386)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        if (heff_intLt_c_lent(v_a_24395, v_t_24397, 2)) {
          HeffT2 v_t_24399 = (g_heff_2ecompile_2einterp_2enthV_24cpr(heff_arrayToList(v_xs_24386), v_a_24395));
          {
            V v_field_24401 = v_t_24399.f[1];
            int64_t v_tag_24400 = ((int64_t)v_t_24399.f[0]);
            if ((v_tag_24400 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24v_24390_24VInt, 1);
              V v_v_24403 = v_field_24401;
              return heff_tag_at_n(v_ru_24x1_24389_24Ok, TAG_Ok, 1, (V[]){v_v_24403});
            } else {
              heff_drop_cell(v_ru_24x1_24389_24Ok, 1);
              heff_drop(v_field_24401);
              return heff_tag_at_n(v_ru_24v_24390_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str52)});
            }
          }
        } else {
          heff_drop(v_xs_24386);
          heff_drop_cell(v_ru_24x1_24389_24Ok, 1);
          heff_drop(v_a_24395);
          heff_drop_cell(v_ru_24v_24390_24VInt, 1);
          return NTAG(TAG_Abn);
        }
      } else {
        heff_drop(v_xs_24386);
        heff_drop_cell(v_ru_24x1_24389_24Ok, 1);
        heff_drop(v_a_24395);
        heff_drop_cell(v_ru_24v_24390_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24390, 0ULL, 1);
      heff_drop(v_xs_24386);
      heff_drop_cell(v_ru_24x1_24389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24390, 0ULL, 1);
      heff_drop(v_xs_24386);
      heff_drop_cell(v_ru_24x1_24389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24390, 0ULL, 1);
      heff_drop(v_xs_24386);
      heff_drop_cell(v_ru_24x1_24389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24390, 0ULL, 1);
      heff_drop(v_xs_24386);
      heff_drop_cell(v_ru_24x1_24389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24390, 0ULL, 1);
      heff_drop(v_xs_24386);
      heff_drop_cell(v_ru_24x1_24389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24390, 0ULL, 1);
      heff_drop(v_xs_24386);
      heff_drop_cell(v_ru_24x1_24389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24390, 0ULL, 2);
      heff_drop(v_xs_24386);
      heff_drop_cell(v_ru_24x1_24389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24386);
      heff_drop_cell(v_ru_24x1_24389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24390);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24386);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24386);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24412 = heff_field(v_x1_24389, 0);
    V v_ru_24x1_24389_24Bug = heff_take_reuse_n(v_x1_24389, 1ULL, 1);
    heff_drop(v_xs_24386);
    return heff_tag_at_n(v_ru_24x1_24389_24Bug, TAG_Bug, 1, (V[]){v_what_24412});
  }
  default: return heff_nomatch(v_x1_24389);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args) {
  V v_d_24373 = args[0];
  V v_a_24374 = args[1];
  V v_x1_24375 = heff_tr(heff_call(v_a_24374, 1, (V[]){v_d_24373}));
  switch (heff_tag_of(v_x1_24375)) {
  case TAG_Ok: {
    V v_v_24376 = heff_field(v_x1_24375, 0);
    V v_ru_24x1_24375_24Ok = heff_take_reuse_n(v_x1_24375, 1ULL, 1);
    switch (heff_tag_of(v_v_24376)) {
    case TAG_VFun: {
      heff_take_n(v_v_24376, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24375_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24376, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24375_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24376, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24375_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24376, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24375_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24376, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24375_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24376, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24375_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24376, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24375_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24376, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24375_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24386 = heff_field(v_v_24376, 0);
      heff_take_n(v_v_24376, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24375_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam30, 2, 1, (V[]){v_xs_24386})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24376, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24375_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24376, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24375_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24375_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24376);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24416 = heff_field(v_x1_24375, 0);
    V v_ru_24x1_24375_24Bug = heff_take_reuse_n(v_x1_24375, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24375_24Bug, TAG_Bug, 1, (V[]){v_what_24416});
  }
  default: return heff_nomatch(v_x1_24375);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args) {
  V v_d_24371 = args[0];
  V v_u_24372 = args[1];
  heff_drop(v_d_24371);
  heff_drop(v_u_24372);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam29_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args) {
  V v_d_24443 = args[0];
  V v_x_24444 = args[1];
  V v_a_24442 = heff_env(self)[0];
  V v_xs_24433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24445 = heff_tr(heff_call(v_x_24444, 1, (V[]){v_d_24443}));
  switch (heff_tag_of(v_x1_24445)) {
  case TAG_Ok: {
    V v_v_24446 = heff_field(v_x1_24445, 0);
    V v_ru_24x1_24445_24Ok = heff_take_reuse_n(v_x1_24445, 1ULL, 1);
    if (heff_intLe_c_lent(MK_INT(0LL), v_a_24442, 1)) {
      V v_t_24448 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24433)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (heff_intLt_c_lent(v_a_24442, v_t_24448, 2)) {
        V v_t_24450 = (g_heff_2ecompile_2einterp_2esetAt(heff_arrayToList(v_xs_24433), v_a_24442, v_v_24446));
        V v_t_24451 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24450)});
        return heff_tag_at_n(v_ru_24x1_24445_24Ok, TAG_Ok, 1, (V[]){v_t_24451});
      } else {
        heff_drop(v_a_24442);
        heff_drop(v_v_24446);
        return heff_tag_at_n(v_ru_24x1_24445_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VArr, 1, (V[]){v_xs_24433})});
      }
    } else {
      heff_drop(v_a_24442);
      heff_drop(v_v_24446);
      return heff_tag_at_n(v_ru_24x1_24445_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VArr, 1, (V[]){v_xs_24433})});
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24442);
    heff_drop(v_xs_24433);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24442);
    heff_drop(v_xs_24433);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24452 = heff_field(v_x1_24445, 0);
    V v_ru_24x1_24445_24Bug = heff_take_reuse_n(v_x1_24445, 1ULL, 1);
    heff_drop(v_a_24442);
    heff_drop(v_xs_24433);
    return heff_tag_at_n(v_ru_24x1_24445_24Bug, TAG_Bug, 1, (V[]){v_what_24452});
  }
  default: return heff_nomatch(v_x1_24445);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args) {
  V v_d_24434 = args[0];
  V v_a_24435 = args[1];
  V v_xs_24433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24436 = heff_tr(heff_call(v_a_24435, 1, (V[]){v_d_24434}));
  switch (heff_tag_of(v_x1_24436)) {
  case TAG_Ok: {
    V v_v_24437 = heff_field(v_x1_24436, 0);
    V v_ru_24x1_24436_24Ok = heff_take_reuse_n(v_x1_24436, 1ULL, 1);
    switch (heff_tag_of(v_v_24437)) {
    case TAG_VFun: {
      heff_take_n(v_v_24437, 0ULL, 1);
      heff_drop(v_xs_24433);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24437, 0ULL, 1);
      heff_drop(v_xs_24433);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24437, 0ULL, 2);
      heff_drop(v_xs_24433);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24442 = heff_field(v_v_24437, 0);
      heff_take_n(v_v_24437, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24436_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam34, 2, 2, (V[]){v_a_24442, v_xs_24433})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24437, 0ULL, 1);
      heff_drop(v_xs_24433);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24437, 0ULL, 1);
      heff_drop(v_xs_24433);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24437, 0ULL, 1);
      heff_drop(v_xs_24433);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24437, 0ULL, 1);
      heff_drop(v_xs_24433);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24437, 0ULL, 1);
      heff_drop(v_xs_24433);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24437, 0ULL, 1);
      heff_drop(v_xs_24433);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24437, 0ULL, 2);
      heff_drop(v_xs_24433);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24433);
      heff_drop_cell(v_ru_24x1_24436_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24437);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24433);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24433);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24461 = heff_field(v_x1_24436, 0);
    V v_ru_24x1_24436_24Bug = heff_take_reuse_n(v_x1_24436, 1ULL, 1);
    heff_drop(v_xs_24433);
    return heff_tag_at_n(v_ru_24x1_24436_24Bug, TAG_Bug, 1, (V[]){v_what_24461});
  }
  default: return heff_nomatch(v_x1_24436);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args) {
  V v_d_24420 = args[0];
  V v_a_24421 = args[1];
  V v_x1_24422 = heff_tr(heff_call(v_a_24421, 1, (V[]){v_d_24420}));
  switch (heff_tag_of(v_x1_24422)) {
  case TAG_Ok: {
    V v_v_24423 = heff_field(v_x1_24422, 0);
    V v_ru_24x1_24422_24Ok = heff_take_reuse_n(v_x1_24422, 1ULL, 1);
    switch (heff_tag_of(v_v_24423)) {
    case TAG_VFun: {
      heff_take_n(v_v_24423, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24422_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24423, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24422_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24423, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24422_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24423, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24422_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24423, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24422_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24423, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24422_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24423, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24422_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24423, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24422_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24433 = heff_field(v_v_24423, 0);
      heff_take_n(v_v_24423, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24422_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam33, 2, 1, (V[]){v_xs_24433})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24423, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24422_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24423, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24422_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24422_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24423);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24465 = heff_field(v_x1_24422, 0);
    V v_ru_24x1_24422_24Bug = heff_take_reuse_n(v_x1_24422, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24422_24Bug, TAG_Bug, 1, (V[]){v_what_24465});
  }
  default: return heff_nomatch(v_x1_24422);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args) {
  V v_d_24418 = args[0];
  V v_u_24419 = args[1];
  heff_drop(v_d_24418);
  heff_drop(v_u_24419);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam32_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args) {
  V v_vs_24482 = args[0];
  V v_t_24483 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_vs_24482)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24483});
}
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args) {
  V v_d_24478 = args[0];
  V v_f_24479 = args[1];
  V v_a_24477 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24480 = heff_tr(heff_call(v_f_24479, 1, (V[]){heff_dup(v_d_24478)}));
  switch (heff_tag_of(v_x1_24480)) {
  case TAG_Ok: {
    V v_v_24481 = heff_field(v_x1_24480, 0);
    heff_take_n(v_x1_24480, 1ULL, 1);
    return (g_heff_2ecompile_2einterp_2egenGo(v_d_24478, MK_INT(0LL), v_a_24477, v_v_24481, ((V)&g_heff_2ecompile_2einterp_2eprim_lam38_clo)));
  }
  case TAG_Abn: {
    heff_drop(v_d_24478);
    heff_drop(v_a_24477);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_24478);
    heff_drop(v_a_24477);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24484 = heff_field(v_x1_24480, 0);
    V v_ru_24x1_24480_24Bug = heff_take_reuse_n(v_x1_24480, 1ULL, 1);
    heff_drop(v_d_24478);
    heff_drop(v_a_24477);
    return heff_tag_at_n(v_ru_24x1_24480_24Bug, TAG_Bug, 1, (V[]){v_what_24484});
  }
  default: return heff_nomatch(v_x1_24480);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args) {
  V v_d_24469 = args[0];
  V v_a_24470 = args[1];
  V v_x1_24471 = heff_tr(heff_call(v_a_24470, 1, (V[]){v_d_24469}));
  switch (heff_tag_of(v_x1_24471)) {
  case TAG_Ok: {
    V v_v_24472 = heff_field(v_x1_24471, 0);
    V v_ru_24x1_24471_24Ok = heff_take_reuse_n(v_x1_24471, 1ULL, 1);
    switch (heff_tag_of(v_v_24472)) {
    case TAG_VFun: {
      heff_take_n(v_v_24472, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24471_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24472, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24471_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24472, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24471_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24477 = heff_field(v_v_24472, 0);
      heff_take_n(v_v_24472, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24471_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam37, 2, 1, (V[]){v_a_24477})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24472, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24471_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24472, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24471_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24472, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24471_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24472, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24471_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24472, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24471_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24472, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24471_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24472, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24471_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24471_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24472);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24493 = heff_field(v_x1_24471, 0);
    V v_ru_24x1_24471_24Bug = heff_take_reuse_n(v_x1_24471, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24471_24Bug, TAG_Bug, 1, (V[]){v_what_24493});
  }
  default: return heff_nomatch(v_x1_24471);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args) {
  V v_d_24467 = args[0];
  V v_u_24468 = args[1];
  heff_drop(v_d_24467);
  heff_drop(v_u_24468);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam36_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args) {
  V v_d_24497 = args[0];
  V v_l_24498 = args[1];
  V v_x1_24499 = heff_tr(heff_call(v_l_24498, 1, (V[]){v_d_24497}));
  switch (heff_tag_of(v_x1_24499)) {
  case TAG_Ok: {
    V v_v_24500 = heff_field(v_x1_24499, 0);
    V v_ru_24x1_24499_24Ok = heff_take_reuse_n(v_x1_24499, 1ULL, 1);
    V v_t_24501 = (g_heff_2ecompile_2einterp_2efromListV(v_v_24500, NTAG(TAG_Nil)));
    V v_t_24502 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24501)});
    return heff_tag_at_n(v_ru_24x1_24499_24Ok, TAG_Ok, 1, (V[]){v_t_24502});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24503 = heff_field(v_x1_24499, 0);
    V v_ru_24x1_24499_24Bug = heff_take_reuse_n(v_x1_24499, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24499_24Bug, TAG_Bug, 1, (V[]){v_what_24503});
  }
  default: return heff_nomatch(v_x1_24499);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args) {
  V v_d_24495 = args[0];
  V v_u_24496 = args[1];
  heff_drop(v_d_24495);
  heff_drop(v_u_24496);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam40_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args) {
  V v_d_24507 = args[0];
  V v_a_24508 = args[1];
  V v_x1_24509 = heff_tr(heff_call(v_a_24508, 1, (V[]){v_d_24507}));
  switch (heff_tag_of(v_x1_24509)) {
  case TAG_Ok: {
    V v_v_24510 = heff_field(v_x1_24509, 0);
    V v_ru_24x1_24509_24Ok = heff_take_reuse_n(v_x1_24509, 1ULL, 1);
    switch (heff_tag_of(v_v_24510)) {
    case TAG_VFun: {
      heff_take_n(v_v_24510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24510, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24520 = heff_field(v_v_24510, 0);
      heff_take_n(v_v_24510, 1ULL, 1);
      V v_t_24521 = (g_heff_2ecompile_2einterp_2etoListV(heff_arrayToList(v_xs_24520)));
      return heff_tag_at_n(v_ru_24x1_24509_24Ok, TAG_Ok, 1, (V[]){v_t_24521});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24510, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24510);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24525 = heff_field(v_x1_24509, 0);
    V v_ru_24x1_24509_24Bug = heff_take_reuse_n(v_x1_24509, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24509_24Bug, TAG_Bug, 1, (V[]){v_what_24525});
  }
  default: return heff_nomatch(v_x1_24509);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args) {
  V v_d_24505 = args[0];
  V v_u_24506 = args[1];
  heff_drop(v_d_24505);
  heff_drop(v_u_24506);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam42_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args) {
  V v_d_24538 = args[0];
  V v_x_24539 = args[1];
  V v_a_24537 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24540 = heff_tr(heff_call(v_x_24539, 1, (V[]){v_d_24538}));
  switch (heff_tag_of(v_x1_24540)) {
  case TAG_Ok: {
    V v_v_24541 = heff_field(v_x1_24540, 0);
    V v_ru_24x1_24540_24Ok = heff_take_reuse_n(v_x1_24540, 1ULL, 1);
    V v_t_24542 = (g_list_2ereplicate(v_a_24537, v_v_24541));
    V v_t_24543 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24542)});
    return heff_tag_at_n(v_ru_24x1_24540_24Ok, TAG_Ok, 1, (V[]){v_t_24543});
  }
  case TAG_Abn: {
    heff_drop(v_a_24537);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24537);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24544 = heff_field(v_x1_24540, 0);
    V v_ru_24x1_24540_24Bug = heff_take_reuse_n(v_x1_24540, 1ULL, 1);
    heff_drop(v_a_24537);
    return heff_tag_at_n(v_ru_24x1_24540_24Bug, TAG_Bug, 1, (V[]){v_what_24544});
  }
  default: return heff_nomatch(v_x1_24540);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args) {
  V v_d_24529 = args[0];
  V v_a_24530 = args[1];
  V v_x1_24531 = heff_tr(heff_call(v_a_24530, 1, (V[]){v_d_24529}));
  switch (heff_tag_of(v_x1_24531)) {
  case TAG_Ok: {
    V v_v_24532 = heff_field(v_x1_24531, 0);
    V v_ru_24x1_24531_24Ok = heff_take_reuse_n(v_x1_24531, 1ULL, 1);
    switch (heff_tag_of(v_v_24532)) {
    case TAG_VFun: {
      heff_take_n(v_v_24532, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24531_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24532, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24531_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24532, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24531_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24537 = heff_field(v_v_24532, 0);
      heff_take_n(v_v_24532, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24531_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam45, 2, 1, (V[]){v_a_24537})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24532, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24531_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24532, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24531_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24532, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24531_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24532, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24531_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24532, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24531_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24532, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24531_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24532, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24531_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24531_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24532);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24553 = heff_field(v_x1_24531, 0);
    V v_ru_24x1_24531_24Bug = heff_take_reuse_n(v_x1_24531, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24531_24Bug, TAG_Bug, 1, (V[]){v_what_24553});
  }
  default: return heff_nomatch(v_x1_24531);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args) {
  V v_d_24527 = args[0];
  V v_u_24528 = args[1];
  heff_drop(v_d_24527);
  heff_drop(v_u_24528);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam44_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args) {
  V v_d_24580 = args[0];
  V v_a_24581 = args[1];
  V v_xs_24570 = heff_env(self)[0];
  V v_a_24579 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24582 = heff_tr(heff_call(v_a_24581, 1, (V[]){v_d_24580}));
  switch (heff_tag_of(v_x1_24582)) {
  case TAG_Ok: {
    V v_v_24583 = heff_field(v_x1_24582, 0);
    V v_ru_24x1_24582_24Ok = heff_take_reuse_n(v_x1_24582, 1ULL, 1);
    switch (heff_tag_of(v_v_24583)) {
    case TAG_VFun: {
      heff_take_n(v_v_24583, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop(v_a_24579);
      heff_drop_cell(v_ru_24x1_24582_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24583, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop(v_a_24579);
      heff_drop_cell(v_ru_24x1_24582_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24583, 0ULL, 2);
      heff_drop(v_xs_24570);
      heff_drop(v_a_24579);
      heff_drop_cell(v_ru_24x1_24582_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24588 = heff_field(v_v_24583, 0);
      V v_ru_24v_24583_24VInt = heff_take_reuse_n(v_v_24583, 1ULL, 1);
      V v_t_24589 = ({ V b_0 = heff_arrayToList(v_xs_24570); V a_1 = v_a_24579; V a_2 = v_a_24588; V r_ = (g_heff_2ecompile_2einterp_2esliceV(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V v_t_24590 = heff_tag_at_n(v_ru_24v_24583_24VInt, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24589)});
      return heff_tag_at_n(v_ru_24x1_24582_24Ok, TAG_Ok, 1, (V[]){v_t_24590});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24583, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop(v_a_24579);
      heff_drop_cell(v_ru_24x1_24582_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24583, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop(v_a_24579);
      heff_drop_cell(v_ru_24x1_24582_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24583, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop(v_a_24579);
      heff_drop_cell(v_ru_24x1_24582_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24583, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop(v_a_24579);
      heff_drop_cell(v_ru_24x1_24582_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24583, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop(v_a_24579);
      heff_drop_cell(v_ru_24x1_24582_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24583, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop(v_a_24579);
      heff_drop_cell(v_ru_24x1_24582_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24583, 0ULL, 2);
      heff_drop(v_xs_24570);
      heff_drop(v_a_24579);
      heff_drop_cell(v_ru_24x1_24582_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24570);
      heff_drop(v_a_24579);
      heff_drop_cell(v_ru_24x1_24582_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24583);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24570);
    heff_drop(v_a_24579);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24570);
    heff_drop(v_a_24579);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24599 = heff_field(v_x1_24582, 0);
    V v_ru_24x1_24582_24Bug = heff_take_reuse_n(v_x1_24582, 1ULL, 1);
    heff_drop(v_xs_24570);
    heff_drop(v_a_24579);
    return heff_tag_at_n(v_ru_24x1_24582_24Bug, TAG_Bug, 1, (V[]){v_what_24599});
  }
  default: return heff_nomatch(v_x1_24582);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args) {
  V v_d_24571 = args[0];
  V v_a_24572 = args[1];
  V v_xs_24570 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24573 = heff_tr(heff_call(v_a_24572, 1, (V[]){v_d_24571}));
  switch (heff_tag_of(v_x1_24573)) {
  case TAG_Ok: {
    V v_v_24574 = heff_field(v_x1_24573, 0);
    V v_ru_24x1_24573_24Ok = heff_take_reuse_n(v_x1_24573, 1ULL, 1);
    switch (heff_tag_of(v_v_24574)) {
    case TAG_VFun: {
      heff_take_n(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24574, 0ULL, 2);
      heff_drop(v_xs_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24579 = heff_field(v_v_24574, 0);
      heff_take_n(v_v_24574, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24573_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam49, 2, 2, (V[]){v_xs_24570, v_a_24579})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24574, 0ULL, 1);
      heff_drop(v_xs_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24574, 0ULL, 2);
      heff_drop(v_xs_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24570);
      heff_drop_cell(v_ru_24x1_24573_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24574);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24570);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24570);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24608 = heff_field(v_x1_24573, 0);
    V v_ru_24x1_24573_24Bug = heff_take_reuse_n(v_x1_24573, 1ULL, 1);
    heff_drop(v_xs_24570);
    return heff_tag_at_n(v_ru_24x1_24573_24Bug, TAG_Bug, 1, (V[]){v_what_24608});
  }
  default: return heff_nomatch(v_x1_24573);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args) {
  V v_d_24557 = args[0];
  V v_a_24558 = args[1];
  V v_x1_24559 = heff_tr(heff_call(v_a_24558, 1, (V[]){v_d_24557}));
  switch (heff_tag_of(v_x1_24559)) {
  case TAG_Ok: {
    V v_v_24560 = heff_field(v_x1_24559, 0);
    V v_ru_24x1_24559_24Ok = heff_take_reuse_n(v_x1_24559, 1ULL, 1);
    switch (heff_tag_of(v_v_24560)) {
    case TAG_VFun: {
      heff_take_n(v_v_24560, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24559_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24560, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24559_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24560, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24559_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24560, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24559_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24560, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24559_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24560, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24559_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24560, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24559_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24560, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24559_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24570 = heff_field(v_v_24560, 0);
      heff_take_n(v_v_24560, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24559_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam48, 2, 1, (V[]){v_xs_24570})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24560, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24559_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24560, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24559_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24559_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24560);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24612 = heff_field(v_x1_24559, 0);
    V v_ru_24x1_24559_24Bug = heff_take_reuse_n(v_x1_24559, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24559_24Bug, TAG_Bug, 1, (V[]){v_what_24612});
  }
  default: return heff_nomatch(v_x1_24559);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args) {
  V v_d_24555 = args[0];
  V v_u_24556 = args[1];
  heff_drop(v_d_24555);
  heff_drop(v_u_24556);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam47_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args) {
  V v_d_24630 = args[0];
  V v_a_24631 = args[1];
  V v_xs_24629 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24632 = heff_tr(heff_call(v_a_24631, 1, (V[]){v_d_24630}));
  switch (heff_tag_of(v_x1_24632)) {
  case TAG_Ok: {
    V v_v_24633 = heff_field(v_x1_24632, 0);
    V v_ru_24x1_24632_24Ok = heff_take_reuse_n(v_x1_24632, 1ULL, 1);
    switch (heff_tag_of(v_v_24633)) {
    case TAG_VFun: {
      heff_take_n(v_v_24633, 0ULL, 1);
      heff_drop(v_xs_24629);
      heff_drop_cell(v_ru_24x1_24632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24633, 0ULL, 1);
      heff_drop(v_xs_24629);
      heff_drop_cell(v_ru_24x1_24632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24633, 0ULL, 2);
      heff_drop(v_xs_24629);
      heff_drop_cell(v_ru_24x1_24632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24633, 0ULL, 1);
      heff_drop(v_xs_24629);
      heff_drop_cell(v_ru_24x1_24632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24633, 0ULL, 1);
      heff_drop(v_xs_24629);
      heff_drop_cell(v_ru_24x1_24632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24633, 0ULL, 1);
      heff_drop(v_xs_24629);
      heff_drop_cell(v_ru_24x1_24632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24633, 0ULL, 1);
      heff_drop(v_xs_24629);
      heff_drop_cell(v_ru_24x1_24632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24633, 0ULL, 1);
      heff_drop(v_xs_24629);
      heff_drop_cell(v_ru_24x1_24632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24643 = heff_field(v_v_24633, 0);
      V v_ru_24v_24633_24VArr = heff_take_reuse_n(v_v_24633, 1ULL, 1);
      V v_t_24644 = (g_prelude_2e_2b_2b(heff_arrayToList(v_xs_24629), heff_arrayToList(v_xs_24643)));
      V v_t_24645 = heff_tag_at_n(v_ru_24v_24633_24VArr, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24644)});
      return heff_tag_at_n(v_ru_24x1_24632_24Ok, TAG_Ok, 1, (V[]){v_t_24645});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24633, 0ULL, 1);
      heff_drop(v_xs_24629);
      heff_drop_cell(v_ru_24x1_24632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24633, 0ULL, 2);
      heff_drop(v_xs_24629);
      heff_drop_cell(v_ru_24x1_24632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24629);
      heff_drop_cell(v_ru_24x1_24632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24633);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24629);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24629);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24649 = heff_field(v_x1_24632, 0);
    V v_ru_24x1_24632_24Bug = heff_take_reuse_n(v_x1_24632, 1ULL, 1);
    heff_drop(v_xs_24629);
    return heff_tag_at_n(v_ru_24x1_24632_24Bug, TAG_Bug, 1, (V[]){v_what_24649});
  }
  default: return heff_nomatch(v_x1_24632);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args) {
  V v_d_24616 = args[0];
  V v_a_24617 = args[1];
  V v_x1_24618 = heff_tr(heff_call(v_a_24617, 1, (V[]){v_d_24616}));
  switch (heff_tag_of(v_x1_24618)) {
  case TAG_Ok: {
    V v_v_24619 = heff_field(v_x1_24618, 0);
    V v_ru_24x1_24618_24Ok = heff_take_reuse_n(v_x1_24618, 1ULL, 1);
    switch (heff_tag_of(v_v_24619)) {
    case TAG_VFun: {
      heff_take_n(v_v_24619, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24618_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24619, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24618_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24619, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24618_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24619, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24618_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24619, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24618_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24619, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24618_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24619, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24618_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24619, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24618_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24629 = heff_field(v_v_24619, 0);
      heff_take_n(v_v_24619, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24618_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam52, 2, 1, (V[]){v_xs_24629})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24619, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24618_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24619, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24618_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24618_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24619);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24653 = heff_field(v_x1_24618, 0);
    V v_ru_24x1_24618_24Bug = heff_take_reuse_n(v_x1_24618, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24618_24Bug, TAG_Bug, 1, (V[]){v_what_24653});
  }
  default: return heff_nomatch(v_x1_24618);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args) {
  V v_d_24614 = args[0];
  V v_u_24615 = args[1];
  heff_drop(v_d_24614);
  heff_drop(v_u_24615);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam51_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args) {
  V v_d_24656 = args[0];
  V v_a_24657 = args[1];
  V v_x1_24658 = heff_tr(heff_call(v_a_24657, 1, (V[]){v_d_24656}));
  switch (heff_tag_of(v_x1_24658)) {
  case TAG_Ok: {
    V v_v_24659 = heff_field(v_x1_24658, 0);
    V v_ru_24x1_24658_24Ok = heff_take_reuse_n(v_x1_24658, 1ULL, 1);
    switch (heff_tag_of(v_v_24659)) {
    case TAG_VFun: {
      heff_take_n(v_v_24659, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24659, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24659, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24659, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24659, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24659, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24667 = heff_field(v_v_24659, 0);
      V v_ru_24v_24659_24VStr = heff_take_reuse_n(v_v_24659, 1ULL, 1);
      V v_t_24668 = heff_tag_at_n(v_ru_24v_24659_24VStr, TAG_VInt, 1, (V[]){heff_strLength(v_a_24667)});
      return heff_tag_at_n(v_ru_24x1_24658_24Ok, TAG_Ok, 1, (V[]){v_t_24668});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24659, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24659, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24659, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24659, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24658_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24659);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24674 = heff_field(v_x1_24658, 0);
    V v_ru_24x1_24658_24Bug = heff_take_reuse_n(v_x1_24658, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24658_24Bug, TAG_Bug, 1, (V[]){v_what_24674});
  }
  default: return heff_nomatch(v_x1_24658);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args) {
  V v_d_24697 = args[0];
  V v_a_24698 = args[1];
  V v_a_24687 = heff_env(self)[0];
  V v_a_24696 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24699 = heff_tr(heff_call(v_a_24698, 1, (V[]){v_d_24697}));
  switch (heff_tag_of(v_x1_24699)) {
  case TAG_Ok: {
    V v_v_24700 = heff_field(v_x1_24699, 0);
    V v_ru_24x1_24699_24Ok = heff_take_reuse_n(v_x1_24699, 1ULL, 1);
    switch (heff_tag_of(v_v_24700)) {
    case TAG_VFun: {
      heff_take_n(v_v_24700, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop(v_a_24696);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24700, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop(v_a_24696);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24700, 0ULL, 2);
      heff_drop(v_a_24687);
      heff_drop(v_a_24696);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24705 = heff_field(v_v_24700, 0);
      V v_ru_24v_24700_24VInt = heff_take_reuse_n(v_v_24700, 1ULL, 1);
      V v_t_24706 = heff_tag_at_n(v_ru_24v_24700_24VInt, TAG_VStr, 1, (V[]){heff_strSlice(v_a_24687, v_a_24696, v_a_24705)});
      return heff_tag_at_n(v_ru_24x1_24699_24Ok, TAG_Ok, 1, (V[]){v_t_24706});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24700, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop(v_a_24696);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24700, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop(v_a_24696);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24700, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop(v_a_24696);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24700, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop(v_a_24696);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24700, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop(v_a_24696);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24700, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop(v_a_24696);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24700, 0ULL, 2);
      heff_drop(v_a_24687);
      heff_drop(v_a_24696);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24687);
      heff_drop(v_a_24696);
      heff_drop_cell(v_ru_24x1_24699_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24700);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24687);
    heff_drop(v_a_24696);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24687);
    heff_drop(v_a_24696);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24715 = heff_field(v_x1_24699, 0);
    V v_ru_24x1_24699_24Bug = heff_take_reuse_n(v_x1_24699, 1ULL, 1);
    heff_drop(v_a_24687);
    heff_drop(v_a_24696);
    return heff_tag_at_n(v_ru_24x1_24699_24Bug, TAG_Bug, 1, (V[]){v_what_24715});
  }
  default: return heff_nomatch(v_x1_24699);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args) {
  V v_d_24688 = args[0];
  V v_a_24689 = args[1];
  V v_a_24687 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24690 = heff_tr(heff_call(v_a_24689, 1, (V[]){v_d_24688}));
  switch (heff_tag_of(v_x1_24690)) {
  case TAG_Ok: {
    V v_v_24691 = heff_field(v_x1_24690, 0);
    V v_ru_24x1_24690_24Ok = heff_take_reuse_n(v_x1_24690, 1ULL, 1);
    switch (heff_tag_of(v_v_24691)) {
    case TAG_VFun: {
      heff_take_n(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24691, 0ULL, 2);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24696 = heff_field(v_v_24691, 0);
      heff_take_n(v_v_24691, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24690_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam56, 2, 2, (V[]){v_a_24687, v_a_24696})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24691, 0ULL, 1);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24691, 0ULL, 2);
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24687);
      heff_drop_cell(v_ru_24x1_24690_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24691);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24687);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24687);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24724 = heff_field(v_x1_24690, 0);
    V v_ru_24x1_24690_24Bug = heff_take_reuse_n(v_x1_24690, 1ULL, 1);
    heff_drop(v_a_24687);
    return heff_tag_at_n(v_ru_24x1_24690_24Bug, TAG_Bug, 1, (V[]){v_what_24724});
  }
  default: return heff_nomatch(v_x1_24690);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args) {
  V v_d_24676 = args[0];
  V v_a_24677 = args[1];
  V v_x1_24678 = heff_tr(heff_call(v_a_24677, 1, (V[]){v_d_24676}));
  switch (heff_tag_of(v_x1_24678)) {
  case TAG_Ok: {
    V v_v_24679 = heff_field(v_x1_24678, 0);
    V v_ru_24x1_24678_24Ok = heff_take_reuse_n(v_x1_24678, 1ULL, 1);
    switch (heff_tag_of(v_v_24679)) {
    case TAG_VFun: {
      heff_take_n(v_v_24679, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24678_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24679, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24678_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24679, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24678_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24679, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24678_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24679, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24678_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24679, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24678_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24687 = heff_field(v_v_24679, 0);
      heff_take_n(v_v_24679, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24678_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam55, 2, 1, (V[]){v_a_24687})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24679, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24678_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24679, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24678_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24679, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24678_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24679, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24678_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24678_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24679);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24730 = heff_field(v_x1_24678, 0);
    V v_ru_24x1_24678_24Bug = heff_take_reuse_n(v_x1_24678, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24678_24Bug, TAG_Bug, 1, (V[]){v_what_24730});
  }
  default: return heff_nomatch(v_x1_24678);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args) {
  V v_a_24732 = args[0];
  V v_b_24733 = args[1];
  V v_t_24735;
  if (heff_strEq_c(v_a_24732, v_b_24733)) {
    v_t_24735 = ((V)&g_heff_2ecompile_2einterp_2eprim_str64);
  } else {
    v_t_24735 = ((V)&g_heff_2ecompile_2einterp_2eprim_str65);
  }
  V v_t_24736 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24735, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24736});
}
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args) {
  V v_a_24738 = args[0];
  V v_b_24739 = args[1];
  V v_t_24741;
  if (heff_strLt_c(v_a_24738, v_b_24739)) {
    v_t_24741 = ((V)&g_heff_2ecompile_2einterp_2eprim_str67);
  } else {
    v_t_24741 = ((V)&g_heff_2ecompile_2einterp_2eprim_str68);
  }
  V v_t_24742 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24741, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24742});
}
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args) {
  V v_a_24744 = args[0];
  V v_b_24745 = args[1];
  V v_t_24748;
  if (heff_strLt_c_lent(v_a_24744, v_b_24745, 0)) {
    heff_drop(v_a_24744);
    heff_drop(v_b_24745);
    v_t_24748 = MK_INT(-1LL);
  } else {
    if (heff_strEq_c(v_a_24744, v_b_24745)) {
      v_t_24748 = MK_INT(0LL);
    } else {
      v_t_24748 = MK_INT(1LL);
    }
  }
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24748})});
}
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args) {
  V v_d_24750 = args[0];
  V v_a_24751 = args[1];
  V v_x1_24752 = heff_tr(heff_call(v_a_24751, 1, (V[]){v_d_24750}));
  switch (heff_tag_of(v_x1_24752)) {
  case TAG_Ok: {
    V v_v_24753 = heff_field(v_x1_24752, 0);
    V v_ru_24x1_24752_24Ok = heff_take_reuse_n(v_x1_24752, 1ULL, 1);
    switch (heff_tag_of(v_v_24753)) {
    case TAG_VFun: {
      heff_take_n(v_v_24753, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24752_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24753, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24752_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24753, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24752_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24753, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24752_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24753, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24752_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24753, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24752_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24761 = heff_field(v_v_24753, 0);
      V v_ru_24v_24753_24VStr = heff_take_reuse_n(v_v_24753, 1ULL, 1);
      V v_t_24762 = ({ V a_0 = v_a_24761; V a_1 = MK_INT(0LL); V a_2 = heff_strLength_lent(v_a_24761, 0); V r_ = (g_heff_2ecompile_2einterp_2ehashFrom(a_0, a_1, a_2)); heff_drop(v_a_24761); r_; });
      V v_t_24763 = (g_heff_2ecompile_2einterp_2efmix64(v_t_24762));
      V v_t_24764 = heff_tag_at_n(v_ru_24v_24753_24VStr, TAG_VInt, 1, (V[]){heff_intDiv(v_t_24763, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_24752_24Ok, TAG_Ok, 1, (V[]){v_t_24764});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24753, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24752_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24753, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24752_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24753, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24752_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24753, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24752_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24752_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24753);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24770 = heff_field(v_x1_24752, 0);
    V v_ru_24x1_24752_24Bug = heff_take_reuse_n(v_x1_24752, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24752_24Bug, TAG_Bug, 1, (V[]){v_what_24770});
  }
  default: return heff_nomatch(v_x1_24752);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args) {
  V v_d_24772 = args[0];
  V v_a_24773 = args[1];
  V v_x1_24774 = heff_tr(heff_call(v_a_24773, 1, (V[]){v_d_24772}));
  switch (heff_tag_of(v_x1_24774)) {
  case TAG_Ok: {
    V v_v_24775 = heff_field(v_x1_24774, 0);
    V v_ru_24x1_24774_24Ok = heff_take_reuse_n(v_x1_24774, 1ULL, 1);
    switch (heff_tag_of(v_v_24775)) {
    case TAG_VFun: {
      heff_take_n(v_v_24775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24775, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24780 = heff_field(v_v_24775, 0);
      V v_ru_24v_24775_24VInt = heff_take_reuse_n(v_v_24775, 1ULL, 1);
      V v_t_24781 = heff_intAdd(heff_intMod(v_a_24780, heff_dup(g_heff_2ecompile_2einterp_2eword64_get())), heff_dup(g_heff_2ecompile_2einterp_2eword64_get()));
      V v_t_24782 = (g_heff_2ecompile_2einterp_2efmix64(heff_intMod(v_t_24781, heff_dup(g_heff_2ecompile_2einterp_2eword64_get()))));
      V v_t_24783 = heff_tag_at_n(v_ru_24v_24775_24VInt, TAG_VInt, 1, (V[]){heff_intDiv(v_t_24782, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_24774_24Ok, TAG_Ok, 1, (V[]){v_t_24783});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24775, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24775);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24792 = heff_field(v_x1_24774, 0);
    V v_ru_24x1_24774_24Bug = heff_take_reuse_n(v_x1_24774, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24774_24Bug, TAG_Bug, 1, (V[]){v_what_24792});
  }
  default: return heff_nomatch(v_x1_24774);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args) {
  V v_d_24812 = args[0];
  V v_a_24813 = args[1];
  V v_a_24802 = heff_env(self)[0];
  V v_a_24811 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24814 = heff_tr(heff_call(v_a_24813, 1, (V[]){v_d_24812}));
  switch (heff_tag_of(v_x1_24814)) {
  case TAG_Ok: {
    V v_v_24815 = heff_field(v_x1_24814, 0);
    V v_ru_24x1_24814_24Ok = heff_take_reuse_n(v_x1_24814, 1ULL, 1);
    switch (heff_tag_of(v_v_24815)) {
    case TAG_VFun: {
      heff_take_n(v_v_24815, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop(v_a_24811);
      heff_drop_cell(v_ru_24x1_24814_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24815, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop(v_a_24811);
      heff_drop_cell(v_ru_24x1_24814_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24815, 0ULL, 2);
      heff_drop(v_a_24802);
      heff_drop(v_a_24811);
      heff_drop_cell(v_ru_24x1_24814_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24820 = heff_field(v_v_24815, 0);
      heff_take_n(v_v_24815, 1ULL, 1);
      V v_t_24821 = (g_heff_2ecompile_2einterp_2etrieSlotOf(v_a_24802, v_a_24811, v_a_24820));
      return heff_tag_at_n(v_ru_24x1_24814_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24821})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24815, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop(v_a_24811);
      heff_drop_cell(v_ru_24x1_24814_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24815, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop(v_a_24811);
      heff_drop_cell(v_ru_24x1_24814_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24815, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop(v_a_24811);
      heff_drop_cell(v_ru_24x1_24814_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24815, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop(v_a_24811);
      heff_drop_cell(v_ru_24x1_24814_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24815, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop(v_a_24811);
      heff_drop_cell(v_ru_24x1_24814_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24815, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop(v_a_24811);
      heff_drop_cell(v_ru_24x1_24814_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24815, 0ULL, 2);
      heff_drop(v_a_24802);
      heff_drop(v_a_24811);
      heff_drop_cell(v_ru_24x1_24814_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24802);
      heff_drop(v_a_24811);
      heff_drop_cell(v_ru_24x1_24814_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24815);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24802);
    heff_drop(v_a_24811);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24802);
    heff_drop(v_a_24811);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24830 = heff_field(v_x1_24814, 0);
    V v_ru_24x1_24814_24Bug = heff_take_reuse_n(v_x1_24814, 1ULL, 1);
    heff_drop(v_a_24802);
    heff_drop(v_a_24811);
    return heff_tag_at_n(v_ru_24x1_24814_24Bug, TAG_Bug, 1, (V[]){v_what_24830});
  }
  default: return heff_nomatch(v_x1_24814);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args) {
  V v_d_24803 = args[0];
  V v_a_24804 = args[1];
  V v_a_24802 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24805 = heff_tr(heff_call(v_a_24804, 1, (V[]){v_d_24803}));
  switch (heff_tag_of(v_x1_24805)) {
  case TAG_Ok: {
    V v_v_24806 = heff_field(v_x1_24805, 0);
    V v_ru_24x1_24805_24Ok = heff_take_reuse_n(v_x1_24805, 1ULL, 1);
    switch (heff_tag_of(v_v_24806)) {
    case TAG_VFun: {
      heff_take_n(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24806, 0ULL, 2);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24811 = heff_field(v_v_24806, 0);
      heff_take_n(v_v_24806, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24805_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam64, 2, 2, (V[]){v_a_24802, v_a_24811})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24806, 0ULL, 1);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24806, 0ULL, 2);
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24802);
      heff_drop_cell(v_ru_24x1_24805_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24806);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24802);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24802);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24839 = heff_field(v_x1_24805, 0);
    V v_ru_24x1_24805_24Bug = heff_take_reuse_n(v_x1_24805, 1ULL, 1);
    heff_drop(v_a_24802);
    return heff_tag_at_n(v_ru_24x1_24805_24Bug, TAG_Bug, 1, (V[]){v_what_24839});
  }
  default: return heff_nomatch(v_x1_24805);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args) {
  V v_d_24794 = args[0];
  V v_a_24795 = args[1];
  V v_x1_24796 = heff_tr(heff_call(v_a_24795, 1, (V[]){v_d_24794}));
  switch (heff_tag_of(v_x1_24796)) {
  case TAG_Ok: {
    V v_v_24797 = heff_field(v_x1_24796, 0);
    V v_ru_24x1_24796_24Ok = heff_take_reuse_n(v_x1_24796, 1ULL, 1);
    switch (heff_tag_of(v_v_24797)) {
    case TAG_VFun: {
      heff_take_n(v_v_24797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24797, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24802 = heff_field(v_v_24797, 0);
      heff_take_n(v_v_24797, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24796_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam63, 2, 1, (V[]){v_a_24802})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24797, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24797);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24848 = heff_field(v_x1_24796, 0);
    V v_ru_24x1_24796_24Bug = heff_take_reuse_n(v_x1_24796, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24796_24Bug, TAG_Bug, 1, (V[]){v_what_24848});
  }
  default: return heff_nomatch(v_x1_24796);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args) {
  V v_d_24852 = args[0];
  V v_a_24853 = args[1];
  V v_n_24850 = heff_env(self)[0];
  V v_a_24851 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24854 = heff_tr(heff_call(v_a_24853, 1, (V[]){v_d_24852}));
  switch (heff_tag_of(v_x1_24854)) {
  case TAG_Ok: {
    V v_v_24855 = heff_field(v_x1_24854, 0);
    V v_ru_24x1_24854_24Ok = heff_take_reuse_n(v_x1_24854, 1ULL, 1);
    switch (heff_tag_of(v_v_24855)) {
    case TAG_VFun: {
      heff_take_n(v_v_24855, 0ULL, 1);
      heff_drop(v_n_24850);
      heff_drop(v_a_24851);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24855, 0ULL, 1);
      heff_drop(v_n_24850);
      heff_drop(v_a_24851);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24855, 0ULL, 2);
      heff_drop(v_n_24850);
      heff_drop(v_a_24851);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24860 = heff_field(v_v_24855, 0);
      heff_take_n(v_v_24855, 1ULL, 1);
      V v_t_24862;
      if (heff_intLe_c_lent(MK_INT(0LL), v_a_24860, 1)) {
        v_t_24862 = v_a_24860;
      } else {
        heff_drop(v_a_24860);
        v_t_24862 = MK_INT(0LL);
      }
      V v_j_24863 = heff_strFind(v_n_24850, v_a_24851, v_t_24862);
      V v_t_24865;
      if (heff_intLt_c_lent(v_j_24863, MK_INT(0LL), 2)) {
        heff_drop(v_j_24863);
        v_t_24865 = MK_INT(-1LL);
      } else {
        v_t_24865 = v_j_24863;
      }
      return heff_tag_at_n(v_ru_24x1_24854_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24865})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24855, 0ULL, 1);
      heff_drop(v_n_24850);
      heff_drop(v_a_24851);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24855, 0ULL, 1);
      heff_drop(v_n_24850);
      heff_drop(v_a_24851);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24855, 0ULL, 1);
      heff_drop(v_n_24850);
      heff_drop(v_a_24851);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24855, 0ULL, 1);
      heff_drop(v_n_24850);
      heff_drop(v_a_24851);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24855, 0ULL, 1);
      heff_drop(v_n_24850);
      heff_drop(v_a_24851);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24855, 0ULL, 1);
      heff_drop(v_n_24850);
      heff_drop(v_a_24851);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24855, 0ULL, 2);
      heff_drop(v_n_24850);
      heff_drop(v_a_24851);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_n_24850);
      heff_drop(v_a_24851);
      heff_drop_cell(v_ru_24x1_24854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24855);
    }
  }
  case TAG_Abn: {
    heff_drop(v_n_24850);
    heff_drop(v_a_24851);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_n_24850);
    heff_drop(v_a_24851);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24874 = heff_field(v_x1_24854, 0);
    V v_ru_24x1_24854_24Bug = heff_take_reuse_n(v_x1_24854, 1ULL, 1);
    heff_drop(v_n_24850);
    heff_drop(v_a_24851);
    return heff_tag_at_n(v_ru_24x1_24854_24Bug, TAG_Bug, 1, (V[]){v_what_24874});
  }
  default: return heff_nomatch(v_x1_24854);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args) {
  V v_n_24850 = args[0];
  V v_a_24851 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam66, 2, 2, (V[]){v_n_24850, v_a_24851})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args) {
  V v_d_24888 = args[0];
  V v_a_24889 = args[1];
  V v_a_24887 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24890 = heff_tr(heff_call(v_a_24889, 1, (V[]){v_d_24888}));
  switch (heff_tag_of(v_x1_24890)) {
  case TAG_Ok: {
    V v_v_24891 = heff_field(v_x1_24890, 0);
    V v_ru_24x1_24890_24Ok = heff_take_reuse_n(v_x1_24890, 1ULL, 1);
    switch (heff_tag_of(v_v_24891)) {
    case TAG_VFun: {
      heff_take_n(v_v_24891, 0ULL, 1);
      heff_drop(v_a_24887);
      heff_drop_cell(v_ru_24x1_24890_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24891, 0ULL, 1);
      heff_drop(v_a_24887);
      heff_drop_cell(v_ru_24x1_24890_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24891, 0ULL, 2);
      heff_drop(v_a_24887);
      heff_drop_cell(v_ru_24x1_24890_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24896 = heff_field(v_v_24891, 0);
      V v_ru_24v_24891_24VInt = heff_take_reuse_n(v_v_24891, 1ULL, 1);
      V v_t_24897 = heff_tag_at_n(v_ru_24v_24891_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_24887, v_a_24896)});
      return heff_tag_at_n(v_ru_24x1_24890_24Ok, TAG_Ok, 1, (V[]){v_t_24897});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24891, 0ULL, 1);
      heff_drop(v_a_24887);
      heff_drop_cell(v_ru_24x1_24890_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24891, 0ULL, 1);
      heff_drop(v_a_24887);
      heff_drop_cell(v_ru_24x1_24890_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24891, 0ULL, 1);
      heff_drop(v_a_24887);
      heff_drop_cell(v_ru_24x1_24890_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24891, 0ULL, 1);
      heff_drop(v_a_24887);
      heff_drop_cell(v_ru_24x1_24890_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24891, 0ULL, 1);
      heff_drop(v_a_24887);
      heff_drop_cell(v_ru_24x1_24890_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24891, 0ULL, 1);
      heff_drop(v_a_24887);
      heff_drop_cell(v_ru_24x1_24890_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24891, 0ULL, 2);
      heff_drop(v_a_24887);
      heff_drop_cell(v_ru_24x1_24890_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24887);
      heff_drop_cell(v_ru_24x1_24890_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24891);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24887);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24887);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24906 = heff_field(v_x1_24890, 0);
    V v_ru_24x1_24890_24Bug = heff_take_reuse_n(v_x1_24890, 1ULL, 1);
    heff_drop(v_a_24887);
    return heff_tag_at_n(v_ru_24x1_24890_24Bug, TAG_Bug, 1, (V[]){v_what_24906});
  }
  default: return heff_nomatch(v_x1_24890);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args) {
  V v_d_24876 = args[0];
  V v_a_24877 = args[1];
  V v_x1_24878 = heff_tr(heff_call(v_a_24877, 1, (V[]){v_d_24876}));
  switch (heff_tag_of(v_x1_24878)) {
  case TAG_Ok: {
    V v_v_24879 = heff_field(v_x1_24878, 0);
    V v_ru_24x1_24878_24Ok = heff_take_reuse_n(v_x1_24878, 1ULL, 1);
    switch (heff_tag_of(v_v_24879)) {
    case TAG_VFun: {
      heff_take_n(v_v_24879, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24878_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24879, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24878_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24879, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24878_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24879, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24878_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24879, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24878_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24879, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24878_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24887 = heff_field(v_v_24879, 0);
      heff_take_n(v_v_24879, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24878_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam68, 2, 1, (V[]){v_a_24887})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24879, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24878_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24879, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24878_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24879, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24878_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24879, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24878_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24878_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24879);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24912 = heff_field(v_x1_24878, 0);
    V v_ru_24x1_24878_24Bug = heff_take_reuse_n(v_x1_24878, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24878_24Bug, TAG_Bug, 1, (V[]){v_what_24912});
  }
  default: return heff_nomatch(v_x1_24878);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args) {
  V v_d_24914 = args[0];
  V v_a_24915 = args[1];
  V v_x1_24916 = heff_tr(heff_call(v_a_24915, 1, (V[]){v_d_24914}));
  switch (heff_tag_of(v_x1_24916)) {
  case TAG_Ok: {
    V v_v_24917 = heff_field(v_x1_24916, 0);
    V v_ru_24x1_24916_24Ok = heff_take_reuse_n(v_x1_24916, 1ULL, 1);
    switch (heff_tag_of(v_v_24917)) {
    case TAG_VFun: {
      heff_take_n(v_v_24917, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24916_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24917, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24916_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24917, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24916_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24922 = heff_field(v_v_24917, 0);
      heff_take_n(v_v_24917, 1ULL, 1);
      V v_t_24923 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_a_24922)));
      return heff_tag_at_n(v_ru_24x1_24916_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_24923})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24917, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24916_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24917, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24916_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24917, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24916_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24917, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24916_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24917, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24916_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24917, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24916_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24917, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24916_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24916_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24917);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24932 = heff_field(v_x1_24916, 0);
    V v_ru_24x1_24916_24Bug = heff_take_reuse_n(v_x1_24916, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24916_24Bug, TAG_Bug, 1, (V[]){v_what_24932});
  }
  default: return heff_nomatch(v_x1_24916);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args) {
  V v_d_24946 = args[0];
  V v_a_24947 = args[1];
  V v_a_24945 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24948 = heff_tr(heff_call(v_a_24947, 1, (V[]){v_d_24946}));
  switch (heff_tag_of(v_x1_24948)) {
  case TAG_Ok: {
    V v_v_24949 = heff_field(v_x1_24948, 0);
    V v_ru_24x1_24948_24Ok = heff_take_reuse_n(v_x1_24948, 1ULL, 1);
    switch (heff_tag_of(v_v_24949)) {
    case TAG_VFun: {
      heff_take_n(v_v_24949, 0ULL, 1);
      heff_drop(v_a_24945);
      heff_drop_cell(v_ru_24x1_24948_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24949, 0ULL, 1);
      heff_drop(v_a_24945);
      heff_drop_cell(v_ru_24x1_24948_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24949, 0ULL, 2);
      heff_drop(v_a_24945);
      heff_drop_cell(v_ru_24x1_24948_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24954 = heff_field(v_v_24949, 0);
      heff_take_n(v_v_24949, 1ULL, 1);
      V v_t_24955 = heff_runeToInt(heff_strRuneAt(v_a_24945, v_a_24954));
      return heff_tag_at_n(v_ru_24x1_24948_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VRune, 1, (V[]){v_t_24955})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24949, 0ULL, 1);
      heff_drop(v_a_24945);
      heff_drop_cell(v_ru_24x1_24948_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24949, 0ULL, 1);
      heff_drop(v_a_24945);
      heff_drop_cell(v_ru_24x1_24948_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24949, 0ULL, 1);
      heff_drop(v_a_24945);
      heff_drop_cell(v_ru_24x1_24948_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24949, 0ULL, 1);
      heff_drop(v_a_24945);
      heff_drop_cell(v_ru_24x1_24948_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24949, 0ULL, 1);
      heff_drop(v_a_24945);
      heff_drop_cell(v_ru_24x1_24948_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24949, 0ULL, 1);
      heff_drop(v_a_24945);
      heff_drop_cell(v_ru_24x1_24948_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24949, 0ULL, 2);
      heff_drop(v_a_24945);
      heff_drop_cell(v_ru_24x1_24948_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24945);
      heff_drop_cell(v_ru_24x1_24948_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24949);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24945);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24945);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24964 = heff_field(v_x1_24948, 0);
    V v_ru_24x1_24948_24Bug = heff_take_reuse_n(v_x1_24948, 1ULL, 1);
    heff_drop(v_a_24945);
    return heff_tag_at_n(v_ru_24x1_24948_24Bug, TAG_Bug, 1, (V[]){v_what_24964});
  }
  default: return heff_nomatch(v_x1_24948);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args) {
  V v_d_24934 = args[0];
  V v_a_24935 = args[1];
  V v_x1_24936 = heff_tr(heff_call(v_a_24935, 1, (V[]){v_d_24934}));
  switch (heff_tag_of(v_x1_24936)) {
  case TAG_Ok: {
    V v_v_24937 = heff_field(v_x1_24936, 0);
    V v_ru_24x1_24936_24Ok = heff_take_reuse_n(v_x1_24936, 1ULL, 1);
    switch (heff_tag_of(v_v_24937)) {
    case TAG_VFun: {
      heff_take_n(v_v_24937, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24936_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24937, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24936_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24937, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24936_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24937, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24936_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24937, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24936_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24937, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24936_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24945 = heff_field(v_v_24937, 0);
      heff_take_n(v_v_24937, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24936_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam71, 2, 1, (V[]){v_a_24945})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24937, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24936_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24937, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24936_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24937, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24936_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24937, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24936_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24936_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24937);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24970 = heff_field(v_x1_24936, 0);
    V v_ru_24x1_24936_24Bug = heff_take_reuse_n(v_x1_24936, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24936_24Bug, TAG_Bug, 1, (V[]){v_what_24970});
  }
  default: return heff_nomatch(v_x1_24936);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args) {
  V v_d_24984 = args[0];
  V v_a_24985 = args[1];
  V v_a_24983 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24986 = heff_tr(heff_call(v_a_24985, 1, (V[]){v_d_24984}));
  switch (heff_tag_of(v_x1_24986)) {
  case TAG_Ok: {
    V v_v_24987 = heff_field(v_x1_24986, 0);
    V v_ru_24x1_24986_24Ok = heff_take_reuse_n(v_x1_24986, 1ULL, 1);
    switch (heff_tag_of(v_v_24987)) {
    case TAG_VFun: {
      heff_take_n(v_v_24987, 0ULL, 1);
      heff_drop(v_a_24983);
      heff_drop_cell(v_ru_24x1_24986_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24987, 0ULL, 1);
      heff_drop(v_a_24983);
      heff_drop_cell(v_ru_24x1_24986_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24987, 0ULL, 2);
      heff_drop(v_a_24983);
      heff_drop_cell(v_ru_24x1_24986_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24992 = heff_field(v_v_24987, 0);
      V v_ru_24v_24987_24VInt = heff_take_reuse_n(v_v_24987, 1ULL, 1);
      V v_t_24993 = heff_tag_at_n(v_ru_24v_24987_24VInt, TAG_VInt, 1, (V[]){heff_strRuneWidth(v_a_24983, v_a_24992)});
      return heff_tag_at_n(v_ru_24x1_24986_24Ok, TAG_Ok, 1, (V[]){v_t_24993});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24987, 0ULL, 1);
      heff_drop(v_a_24983);
      heff_drop_cell(v_ru_24x1_24986_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24987, 0ULL, 1);
      heff_drop(v_a_24983);
      heff_drop_cell(v_ru_24x1_24986_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24987, 0ULL, 1);
      heff_drop(v_a_24983);
      heff_drop_cell(v_ru_24x1_24986_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24987, 0ULL, 1);
      heff_drop(v_a_24983);
      heff_drop_cell(v_ru_24x1_24986_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24987, 0ULL, 1);
      heff_drop(v_a_24983);
      heff_drop_cell(v_ru_24x1_24986_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24987, 0ULL, 1);
      heff_drop(v_a_24983);
      heff_drop_cell(v_ru_24x1_24986_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24987, 0ULL, 2);
      heff_drop(v_a_24983);
      heff_drop_cell(v_ru_24x1_24986_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24983);
      heff_drop_cell(v_ru_24x1_24986_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24987);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24983);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24983);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241002 = heff_field(v_x1_24986, 0);
    V v_ru_24x1_24986_24Bug = heff_take_reuse_n(v_x1_24986, 1ULL, 1);
    heff_drop(v_a_24983);
    return heff_tag_at_n(v_ru_24x1_24986_24Bug, TAG_Bug, 1, (V[]){v_what_241002});
  }
  default: return heff_nomatch(v_x1_24986);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args) {
  V v_d_24972 = args[0];
  V v_a_24973 = args[1];
  V v_x1_24974 = heff_tr(heff_call(v_a_24973, 1, (V[]){v_d_24972}));
  switch (heff_tag_of(v_x1_24974)) {
  case TAG_Ok: {
    V v_v_24975 = heff_field(v_x1_24974, 0);
    V v_ru_24x1_24974_24Ok = heff_take_reuse_n(v_x1_24974, 1ULL, 1);
    switch (heff_tag_of(v_v_24975)) {
    case TAG_VFun: {
      heff_take_n(v_v_24975, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24974_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24975, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24974_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24975, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24974_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24975, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24974_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24975, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24974_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24975, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24974_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24983 = heff_field(v_v_24975, 0);
      heff_take_n(v_v_24975, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24974_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam73, 2, 1, (V[]){v_a_24983})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24975, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24974_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24975, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24974_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24975, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24974_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24975, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24974_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24974_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24975);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241008 = heff_field(v_x1_24974, 0);
    V v_ru_24x1_24974_24Bug = heff_take_reuse_n(v_x1_24974, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24974_24Bug, TAG_Bug, 1, (V[]){v_what_241008});
  }
  default: return heff_nomatch(v_x1_24974);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args) {
  V v_d_241010 = args[0];
  V v_a_241011 = args[1];
  V v_x1_241012 = heff_tr(heff_call(v_a_241011, 1, (V[]){v_d_241010}));
  switch (heff_tag_of(v_x1_241012)) {
  case TAG_Ok: {
    V v_v_241013 = heff_field(v_x1_241012, 0);
    V v_ru_24x1_241012_24Ok = heff_take_reuse_n(v_x1_241012, 1ULL, 1);
    switch (heff_tag_of(v_v_241013)) {
    case TAG_VFun: {
      heff_take_n(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241013, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241021 = heff_field(v_v_241013, 0);
      V v_ru_24v_241013_24VStr = heff_take_reuse_n(v_v_241013, 1ULL, 1);
      V v_t_241022 = heff_tag_at_n(v_ru_24v_241013_24VStr, TAG_VInt, 1, (V[]){heff_strRuneCount(v_a_241021)});
      return heff_tag_at_n(v_ru_24x1_241012_24Ok, TAG_Ok, 1, (V[]){v_t_241022});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241013, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241013, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241012_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241013);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241028 = heff_field(v_x1_241012, 0);
    V v_ru_24x1_241012_24Bug = heff_take_reuse_n(v_x1_241012, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241012_24Bug, TAG_Bug, 1, (V[]){v_what_241028});
  }
  default: return heff_nomatch(v_x1_241012);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args) {
  V v_d_241030 = args[0];
  V v_a_241031 = args[1];
  V v_x1_241032 = heff_tr(heff_call(v_a_241031, 1, (V[]){v_d_241030}));
  switch (heff_tag_of(v_x1_241032)) {
  case TAG_Ok: {
    V v_v_241033 = heff_field(v_x1_241032, 0);
    V v_ru_24x1_241032_24Ok = heff_take_reuse_n(v_x1_241032, 1ULL, 1);
    switch (heff_tag_of(v_v_241033)) {
    case TAG_VFun: {
      heff_take_n(v_v_241033, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241032_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241033, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241032_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241033, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241032_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241033, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241032_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241033, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241032_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241033, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241032_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241041 = heff_field(v_v_241033, 0);
      heff_take_n(v_v_241033, 1ULL, 1);
      V v_t_241042 = heff_strOfRunes(heff_strRunes(v_a_241041));
      return heff_tag_at_n(v_ru_24x1_241032_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_241042})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241033, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241032_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241033, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241032_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241033, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241032_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241033, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241032_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241032_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241033);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241048 = heff_field(v_x1_241032, 0);
    V v_ru_24x1_241032_24Bug = heff_take_reuse_n(v_x1_241032, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241032_24Bug, TAG_Bug, 1, (V[]){v_what_241048});
  }
  default: return heff_nomatch(v_x1_241032);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args) {
  V v_d_241050 = args[0];
  V v_a_241051 = args[1];
  V v_x1_241052 = heff_tr(heff_call(v_a_241051, 1, (V[]){v_d_241050}));
  switch (heff_tag_of(v_x1_241052)) {
  case TAG_Ok: {
    V v_v_241053 = heff_field(v_x1_241052, 0);
    V v_ru_24x1_241052_24Ok = heff_take_reuse_n(v_x1_241052, 1ULL, 1);
    switch (heff_tag_of(v_v_241053)) {
    case TAG_VFun: {
      heff_take_n(v_v_241053, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241053, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241053, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241053, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241053, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241053, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241061 = heff_field(v_v_241053, 0);
      heff_take_n(v_v_241053, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241052_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_a_241061})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241053, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241053, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241053, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241053, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241053);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241067 = heff_field(v_x1_241052, 0);
    V v_ru_24x1_241052_24Bug = heff_take_reuse_n(v_x1_241052, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241052_24Bug, TAG_Bug, 1, (V[]){v_what_241067});
  }
  default: return heff_nomatch(v_x1_241052);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args) {
  V v_d_241069 = args[0];
  V v_a_241070 = args[1];
  V v_x1_241071 = heff_tr(heff_call(v_a_241070, 1, (V[]){v_d_241069}));
  switch (heff_tag_of(v_x1_241071)) {
  case TAG_Ok: {
    V v_v_241072 = heff_field(v_x1_241071, 0);
    V v_ru_24x1_241071_24Ok = heff_take_reuse_n(v_x1_241071, 1ULL, 1);
    switch (heff_tag_of(v_v_241072)) {
    case TAG_VFun: {
      heff_take_n(v_v_241072, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241071_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241072, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241071_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241072, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241071_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241072, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241071_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241072, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241071_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241072, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241071_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241072, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241071_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241072, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241071_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241072, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241071_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241083 = heff_field(v_v_241072, 0);
      V v_ru_24v_241072_24VBytes = heff_take_reuse_n(v_v_241072, 1ULL, 1);
      V v_t_241084 = heff_tag_at_n(v_ru_24v_241072_24VBytes, TAG_VInt, 1, (V[]){heff_strLength(v_a_241083)});
      return heff_tag_at_n(v_ru_24x1_241071_24Ok, TAG_Ok, 1, (V[]){v_t_241084});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241072, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241071_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241071_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241072);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241087 = heff_field(v_x1_241071, 0);
    V v_ru_24x1_241071_24Bug = heff_take_reuse_n(v_x1_241071, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241071_24Bug, TAG_Bug, 1, (V[]){v_what_241087});
  }
  default: return heff_nomatch(v_x1_241071);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args) {
  V v_d_241104 = args[0];
  V v_a_241105 = args[1];
  V v_a_241103 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241106 = heff_tr(heff_call(v_a_241105, 1, (V[]){v_d_241104}));
  switch (heff_tag_of(v_x1_241106)) {
  case TAG_Ok: {
    V v_v_241107 = heff_field(v_x1_241106, 0);
    V v_ru_24x1_241106_24Ok = heff_take_reuse_n(v_x1_241106, 1ULL, 1);
    switch (heff_tag_of(v_v_241107)) {
    case TAG_VFun: {
      heff_take_n(v_v_241107, 0ULL, 1);
      heff_drop(v_a_241103);
      heff_drop_cell(v_ru_24x1_241106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241107, 0ULL, 1);
      heff_drop(v_a_241103);
      heff_drop_cell(v_ru_24x1_241106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241107, 0ULL, 2);
      heff_drop(v_a_241103);
      heff_drop_cell(v_ru_24x1_241106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241112 = heff_field(v_v_241107, 0);
      V v_ru_24v_241107_24VInt = heff_take_reuse_n(v_v_241107, 1ULL, 1);
      if (heff_intLe_c_lent(MK_INT(0LL), v_a_241112, 1)) {
        if (heff_intLt_c(heff_dup(v_a_241112), heff_strLength_lent(v_a_241103, 0))) {
          V v_t_241115 = heff_tag_at_n(v_ru_24v_241107_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_241103, v_a_241112)});
          return heff_tag_at_n(v_ru_24x1_241106_24Ok, TAG_Ok, 1, (V[]){v_t_241115});
        } else {
          heff_drop(v_a_241103);
          heff_drop_cell(v_ru_24x1_241106_24Ok, 1);
          heff_drop(v_a_241112);
          heff_drop_cell(v_ru_24v_241107_24VInt, 1);
          return NTAG(TAG_Abn);
        }
      } else {
        heff_drop(v_a_241103);
        heff_drop_cell(v_ru_24x1_241106_24Ok, 1);
        heff_drop(v_a_241112);
        heff_drop_cell(v_ru_24v_241107_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241107, 0ULL, 1);
      heff_drop(v_a_241103);
      heff_drop_cell(v_ru_24x1_241106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241107, 0ULL, 1);
      heff_drop(v_a_241103);
      heff_drop_cell(v_ru_24x1_241106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241107, 0ULL, 1);
      heff_drop(v_a_241103);
      heff_drop_cell(v_ru_24x1_241106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241107, 0ULL, 1);
      heff_drop(v_a_241103);
      heff_drop_cell(v_ru_24x1_241106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241107, 0ULL, 1);
      heff_drop(v_a_241103);
      heff_drop_cell(v_ru_24x1_241106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241107, 0ULL, 1);
      heff_drop(v_a_241103);
      heff_drop_cell(v_ru_24x1_241106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241107, 0ULL, 2);
      heff_drop(v_a_241103);
      heff_drop_cell(v_ru_24x1_241106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241103);
      heff_drop_cell(v_ru_24x1_241106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241107);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241103);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241103);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241124 = heff_field(v_x1_241106, 0);
    V v_ru_24x1_241106_24Bug = heff_take_reuse_n(v_x1_241106, 1ULL, 1);
    heff_drop(v_a_241103);
    return heff_tag_at_n(v_ru_24x1_241106_24Bug, TAG_Bug, 1, (V[]){v_what_241124});
  }
  default: return heff_nomatch(v_x1_241106);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args) {
  V v_d_241089 = args[0];
  V v_a_241090 = args[1];
  V v_x1_241091 = heff_tr(heff_call(v_a_241090, 1, (V[]){v_d_241089}));
  switch (heff_tag_of(v_x1_241091)) {
  case TAG_Ok: {
    V v_v_241092 = heff_field(v_x1_241091, 0);
    V v_ru_24x1_241091_24Ok = heff_take_reuse_n(v_x1_241091, 1ULL, 1);
    switch (heff_tag_of(v_v_241092)) {
    case TAG_VFun: {
      heff_take_n(v_v_241092, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241091_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241092, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241091_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241092, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241091_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241092, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241091_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241092, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241091_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241092, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241091_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241092, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241091_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241092, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241091_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241092, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241091_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241103 = heff_field(v_v_241092, 0);
      heff_take_n(v_v_241092, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241091_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam79, 2, 1, (V[]){v_a_241103})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241092, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241091_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241091_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241092);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241127 = heff_field(v_x1_241091, 0);
    V v_ru_24x1_241091_24Bug = heff_take_reuse_n(v_x1_241091, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241091_24Bug, TAG_Bug, 1, (V[]){v_what_241127});
  }
  default: return heff_nomatch(v_x1_241091);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args) {
  V v_d_241153 = args[0];
  V v_a_241154 = args[1];
  V v_a_241143 = heff_env(self)[0];
  V v_a_241152 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241155 = heff_tr(heff_call(v_a_241154, 1, (V[]){v_d_241153}));
  switch (heff_tag_of(v_x1_241155)) {
  case TAG_Ok: {
    V v_v_241156 = heff_field(v_x1_241155, 0);
    V v_ru_24x1_241155_24Ok = heff_take_reuse_n(v_x1_241155, 1ULL, 1);
    switch (heff_tag_of(v_v_241156)) {
    case TAG_VFun: {
      heff_take_n(v_v_241156, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop(v_a_241152);
      heff_drop_cell(v_ru_24x1_241155_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241156, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop(v_a_241152);
      heff_drop_cell(v_ru_24x1_241155_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241156, 0ULL, 2);
      heff_drop(v_a_241143);
      heff_drop(v_a_241152);
      heff_drop_cell(v_ru_24x1_241155_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241161 = heff_field(v_v_241156, 0);
      V v_ru_24v_241156_24VInt = heff_take_reuse_n(v_v_241156, 1ULL, 1);
      V v_t_241162 = heff_tag_at_n(v_ru_24v_241156_24VInt, TAG_VBytes, 1, (V[]){heff_strSlice(v_a_241143, v_a_241152, v_a_241161)});
      return heff_tag_at_n(v_ru_24x1_241155_24Ok, TAG_Ok, 1, (V[]){v_t_241162});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241156, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop(v_a_241152);
      heff_drop_cell(v_ru_24x1_241155_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241156, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop(v_a_241152);
      heff_drop_cell(v_ru_24x1_241155_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241156, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop(v_a_241152);
      heff_drop_cell(v_ru_24x1_241155_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241156, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop(v_a_241152);
      heff_drop_cell(v_ru_24x1_241155_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241156, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop(v_a_241152);
      heff_drop_cell(v_ru_24x1_241155_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241156, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop(v_a_241152);
      heff_drop_cell(v_ru_24x1_241155_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241156, 0ULL, 2);
      heff_drop(v_a_241143);
      heff_drop(v_a_241152);
      heff_drop_cell(v_ru_24x1_241155_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241143);
      heff_drop(v_a_241152);
      heff_drop_cell(v_ru_24x1_241155_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241156);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241143);
    heff_drop(v_a_241152);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241143);
    heff_drop(v_a_241152);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241171 = heff_field(v_x1_241155, 0);
    V v_ru_24x1_241155_24Bug = heff_take_reuse_n(v_x1_241155, 1ULL, 1);
    heff_drop(v_a_241143);
    heff_drop(v_a_241152);
    return heff_tag_at_n(v_ru_24x1_241155_24Bug, TAG_Bug, 1, (V[]){v_what_241171});
  }
  default: return heff_nomatch(v_x1_241155);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args) {
  V v_d_241144 = args[0];
  V v_a_241145 = args[1];
  V v_a_241143 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241146 = heff_tr(heff_call(v_a_241145, 1, (V[]){v_d_241144}));
  switch (heff_tag_of(v_x1_241146)) {
  case TAG_Ok: {
    V v_v_241147 = heff_field(v_x1_241146, 0);
    V v_ru_24x1_241146_24Ok = heff_take_reuse_n(v_x1_241146, 1ULL, 1);
    switch (heff_tag_of(v_v_241147)) {
    case TAG_VFun: {
      heff_take_n(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241147, 0ULL, 2);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241152 = heff_field(v_v_241147, 0);
      heff_take_n(v_v_241147, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241146_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam82, 2, 2, (V[]){v_a_241143, v_a_241152})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241147, 0ULL, 1);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241147, 0ULL, 2);
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241143);
      heff_drop_cell(v_ru_24x1_241146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241147);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241143);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241143);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241180 = heff_field(v_x1_241146, 0);
    V v_ru_24x1_241146_24Bug = heff_take_reuse_n(v_x1_241146, 1ULL, 1);
    heff_drop(v_a_241143);
    return heff_tag_at_n(v_ru_24x1_241146_24Bug, TAG_Bug, 1, (V[]){v_what_241180});
  }
  default: return heff_nomatch(v_x1_241146);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args) {
  V v_d_241129 = args[0];
  V v_a_241130 = args[1];
  V v_x1_241131 = heff_tr(heff_call(v_a_241130, 1, (V[]){v_d_241129}));
  switch (heff_tag_of(v_x1_241131)) {
  case TAG_Ok: {
    V v_v_241132 = heff_field(v_x1_241131, 0);
    V v_ru_24x1_241131_24Ok = heff_take_reuse_n(v_x1_241131, 1ULL, 1);
    switch (heff_tag_of(v_v_241132)) {
    case TAG_VFun: {
      heff_take_n(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241132, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241132, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241143 = heff_field(v_v_241132, 0);
      heff_take_n(v_v_241132, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241131_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam81, 2, 1, (V[]){v_a_241143})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241132, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241131_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241132);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241183 = heff_field(v_x1_241131, 0);
    V v_ru_24x1_241131_24Bug = heff_take_reuse_n(v_x1_241131, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241131_24Bug, TAG_Bug, 1, (V[]){v_what_241183});
  }
  default: return heff_nomatch(v_x1_241131);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args) {
  V v_d_241186 = args[0];
  V v_l_241187 = args[1];
  V v_x1_241188 = heff_tr(heff_call(v_l_241187, 1, (V[]){v_d_241186}));
  switch (heff_tag_of(v_x1_241188)) {
  case TAG_Ok: {
    V v_v_241189 = heff_field(v_x1_241188, 0);
    heff_take_n(v_x1_241188, 1ULL, 1);
    V v_t_241190 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241189, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_241190; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str86); V r_ = (g_heff_2ecompile_2einterp_2ebytesJoined(a_0, a_1)); heff_drop(v_t_241190); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241191 = heff_field(v_x1_241188, 0);
    V v_ru_24x1_241188_24Bug = heff_take_reuse_n(v_x1_241188, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241188_24Bug, TAG_Bug, 1, (V[]){v_what_241191});
  }
  default: return heff_nomatch(v_x1_241188);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args) {
  V v_a_241193 = args[0];
  V v_b_241194 = args[1];
  V v_t_241196;
  if (heff_strEq_c(v_a_241193, v_b_241194)) {
    v_t_241196 = ((V)&g_heff_2ecompile_2einterp_2eprim_str88);
  } else {
    v_t_241196 = ((V)&g_heff_2ecompile_2einterp_2eprim_str89);
  }
  V v_t_241197 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241196, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241197});
}
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args) {
  V v_d_241199 = args[0];
  V v_l_241200 = args[1];
  V v_x1_241201 = heff_tr(heff_call(v_l_241200, 1, (V[]){v_d_241199}));
  switch (heff_tag_of(v_x1_241201)) {
  case TAG_Ok: {
    V v_v_241202 = heff_field(v_x1_241201, 0);
    V v_ru_24x1_241201_24Ok = heff_take_reuse_n(v_x1_241201, 1ULL, 1);
    V v_t_241203 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241202, NTAG(TAG_Nil)));
    V v_t_241204 = ({ V a_0 = v_t_241203; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str91); V r_ = (g_heff_2ecompile_2einterp_2ebyteString(a_0, a_1)); heff_drop(v_t_241203); r_; });
    return heff_tag_at_n(v_ru_24x1_241201_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_t_241204})});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241205 = heff_field(v_x1_241201, 0);
    V v_ru_24x1_241201_24Bug = heff_take_reuse_n(v_x1_241201, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241201_24Bug, TAG_Bug, 1, (V[]){v_what_241205});
  }
  default: return heff_nomatch(v_x1_241201);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args) {
  V v_d_241207 = args[0];
  V v_a_241208 = args[1];
  V v_x1_241209 = heff_tr(heff_call(v_a_241208, 1, (V[]){v_d_241207}));
  switch (heff_tag_of(v_x1_241209)) {
  case TAG_Ok: {
    V v_v_241210 = heff_field(v_x1_241209, 0);
    V v_ru_24x1_241209_24Ok = heff_take_reuse_n(v_x1_241209, 1ULL, 1);
    switch (heff_tag_of(v_v_241210)) {
    case TAG_VFun: {
      heff_take_n(v_v_241210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241210, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241210, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241221 = heff_field(v_v_241210, 0);
      heff_take_n(v_v_241210, 1ULL, 1);
      int64_t v_t_241222 = (heff_unbox_word(heff_strLength_lent(v_a_241221, 0)) - ((int64_t)1ULL));
      V v_t_241223 = ({ V a_0 = v_a_241221; V a_1 = MK_INT(0LL); V a_2 = heff_box_word(v_t_241222); V r_ = (g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(a_0, a_1, a_2)); heff_drop(v_a_241221); r_; });
      return heff_tag_at_n(v_ru_24x1_241209_24Ok, TAG_Ok, 1, (V[]){v_t_241223});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241210, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241210);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241226 = heff_field(v_x1_241209, 0);
    V v_ru_24x1_241209_24Bug = heff_take_reuse_n(v_x1_241209, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241209_24Bug, TAG_Bug, 1, (V[]){v_what_241226});
  }
  default: return heff_nomatch(v_x1_241209);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args) {
  V v_d_241228 = args[0];
  V v_a_241229 = args[1];
  V v_x1_241230 = heff_tr(heff_call(v_a_241229, 1, (V[]){v_d_241228}));
  switch (heff_tag_of(v_x1_241230)) {
  case TAG_Ok: {
    V v_v_241231 = heff_field(v_x1_241230, 0);
    V v_ru_24x1_241230_24Ok = heff_take_reuse_n(v_x1_241230, 1ULL, 1);
    switch (heff_tag_of(v_v_241231)) {
    case TAG_VFun: {
      heff_take_n(v_v_241231, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241230_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241231, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241230_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241231, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241230_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241231, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241230_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241231, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241230_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241231, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241230_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241239 = heff_field(v_v_241231, 0);
      heff_take_n(v_v_241231, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241230_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_a_241239})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241231, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241230_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241231, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241230_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241231, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241230_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241231, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241230_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241230_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241231);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241245 = heff_field(v_x1_241230, 0);
    V v_ru_24x1_241230_24Bug = heff_take_reuse_n(v_x1_241230, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241230_24Bug, TAG_Bug, 1, (V[]){v_what_241245});
  }
  default: return heff_nomatch(v_x1_241230);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args) {
  V v_d_241247 = args[0];
  V v_a_241248 = args[1];
  V v_x1_241249 = heff_tr(heff_call(v_a_241248, 1, (V[]){v_d_241247}));
  switch (heff_tag_of(v_x1_241249)) {
  case TAG_Ok: {
    V v_v_241250 = heff_field(v_x1_241249, 0);
    V v_ru_24x1_241249_24Ok = heff_take_reuse_n(v_x1_241249, 1ULL, 1);
    switch (heff_tag_of(v_v_241250)) {
    case TAG_VFun: {
      heff_take_n(v_v_241250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241250, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241250, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241261 = heff_field(v_v_241250, 0);
      heff_take_n(v_v_241250, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241249_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_a_241261})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241250, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241249_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241250);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241264 = heff_field(v_x1_241249, 0);
    V v_ru_24x1_241249_24Bug = heff_take_reuse_n(v_x1_241249, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241249_24Bug, TAG_Bug, 1, (V[]){v_what_241264});
  }
  default: return heff_nomatch(v_x1_241249);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args) {
  V v_d_241266 = args[0];
  V v_a_241267 = args[1];
  V v_x1_241268 = heff_tr(heff_call(v_a_241267, 1, (V[]){v_d_241266}));
  switch (heff_tag_of(v_x1_241268)) {
  case TAG_Ok: {
    V v_v_241269 = heff_field(v_x1_241268, 0);
    V v_ru_24x1_241268_24Ok = heff_take_reuse_n(v_x1_241268, 1ULL, 1);
    switch (heff_tag_of(v_v_241269)) {
    case TAG_VFun: {
      heff_take_n(v_v_241269, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241268_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241269, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241268_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241269, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241268_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241269, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241268_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241269, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241268_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241269, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241268_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241269, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241268_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241269, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241268_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241269, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241268_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241280 = heff_field(v_v_241269, 0);
      heff_take_n(v_v_241269, 1ULL, 1);
      V v_t_241281 = (g_rune_2evalidFrom(v_a_241280, MK_INT(0LL)));
      V v_t_241282;
      if ((heff_dup(v_t_241281) == NTAG(TAG_True))) {
        heff_drop(v_t_241281);
        v_t_241282 = v_a_241280;
      } else {
        heff_drop(v_t_241281);
        v_t_241282 = heff_strOfRunes(heff_strRunes(v_a_241280));
      }
      return heff_tag_at_n(v_ru_24x1_241268_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_241282})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241269, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241268_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241268_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241269);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241285 = heff_field(v_x1_241268, 0);
    V v_ru_24x1_241268_24Bug = heff_take_reuse_n(v_x1_241268, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241268_24Bug, TAG_Bug, 1, (V[]){v_what_241285});
  }
  default: return heff_nomatch(v_x1_241268);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args) {
  V v_d_241320 = args[0];
  V v_a_241321 = args[1];
  V v_a_241301 = heff_env(self)[0];
  V v_a_241310 = heff_env(self)[1];
  V v_a_241319 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241322 = heff_tr(heff_call(v_a_241321, 1, (V[]){v_d_241320}));
  switch (heff_tag_of(v_x1_241322)) {
  case TAG_Ok: {
    V v_v_241323 = heff_field(v_x1_241322, 0);
    heff_take_n(v_x1_241322, 1ULL, 1);
    switch (heff_tag_of(v_v_241323)) {
    case TAG_VFun: {
      heff_take_n(v_v_241323, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop(v_a_241319);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241323, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop(v_a_241319);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241323, 0ULL, 2);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop(v_a_241319);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241328 = heff_field(v_v_241323, 0);
      heff_take_n(v_v_241323, 1ULL, 1);
      V v_t_241329 = heff_intMul(heff_strLength_lent(v_a_241301, 0), MK_INT(8LL));
      return ({ V a_0 = v_a_241301; V a_1 = v_t_241329; V a_2 = v_a_241310; V a_3 = v_a_241319; V a_4 = v_a_241328; V r_ = (g_heff_2ecompile_2einterp_2eintAtV(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_a_241301); r_; });
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241323, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop(v_a_241319);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241323, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop(v_a_241319);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241323, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop(v_a_241319);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241323, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop(v_a_241319);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241323, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop(v_a_241319);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241323, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop(v_a_241319);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241323, 0ULL, 2);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop(v_a_241319);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop(v_a_241319);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241323);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241301);
    heff_drop(v_a_241310);
    heff_drop(v_a_241319);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241301);
    heff_drop(v_a_241310);
    heff_drop(v_a_241319);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241338 = heff_field(v_x1_241322, 0);
    V v_ru_24x1_241322_24Bug = heff_take_reuse_n(v_x1_241322, 1ULL, 1);
    heff_drop(v_a_241301);
    heff_drop(v_a_241310);
    heff_drop(v_a_241319);
    return heff_tag_at_n(v_ru_24x1_241322_24Bug, TAG_Bug, 1, (V[]){v_what_241338});
  }
  default: return heff_nomatch(v_x1_241322);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args) {
  V v_d_241311 = args[0];
  V v_a_241312 = args[1];
  V v_a_241301 = heff_env(self)[0];
  V v_a_241310 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241313 = heff_tr(heff_call(v_a_241312, 1, (V[]){v_d_241311}));
  switch (heff_tag_of(v_x1_241313)) {
  case TAG_Ok: {
    V v_v_241314 = heff_field(v_x1_241313, 0);
    V v_ru_24x1_241313_24Ok = heff_take_reuse_n(v_x1_241313, 1ULL, 1);
    switch (heff_tag_of(v_v_241314)) {
    case TAG_VFun: {
      heff_take_n(v_v_241314, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop_cell(v_ru_24x1_241313_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241314, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop_cell(v_ru_24x1_241313_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241314, 0ULL, 2);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop_cell(v_ru_24x1_241313_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241319 = heff_field(v_v_241314, 0);
      heff_take_n(v_v_241314, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241313_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam93, 2, 3, (V[]){v_a_241301, v_a_241310, v_a_241319})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241314, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop_cell(v_ru_24x1_241313_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241314, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop_cell(v_ru_24x1_241313_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241314, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop_cell(v_ru_24x1_241313_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241314, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop_cell(v_ru_24x1_241313_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241314, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop_cell(v_ru_24x1_241313_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241314, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop_cell(v_ru_24x1_241313_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241314, 0ULL, 2);
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop_cell(v_ru_24x1_241313_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241301);
      heff_drop(v_a_241310);
      heff_drop_cell(v_ru_24x1_241313_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241314);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241301);
    heff_drop(v_a_241310);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241301);
    heff_drop(v_a_241310);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241347 = heff_field(v_x1_241313, 0);
    V v_ru_24x1_241313_24Bug = heff_take_reuse_n(v_x1_241313, 1ULL, 1);
    heff_drop(v_a_241301);
    heff_drop(v_a_241310);
    return heff_tag_at_n(v_ru_24x1_241313_24Bug, TAG_Bug, 1, (V[]){v_what_241347});
  }
  default: return heff_nomatch(v_x1_241313);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args) {
  V v_d_241302 = args[0];
  V v_a_241303 = args[1];
  V v_a_241301 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241304 = heff_tr(heff_call(v_a_241303, 1, (V[]){v_d_241302}));
  switch (heff_tag_of(v_x1_241304)) {
  case TAG_Ok: {
    V v_v_241305 = heff_field(v_x1_241304, 0);
    V v_ru_24x1_241304_24Ok = heff_take_reuse_n(v_x1_241304, 1ULL, 1);
    switch (heff_tag_of(v_v_241305)) {
    case TAG_VFun: {
      heff_take_n(v_v_241305, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop_cell(v_ru_24x1_241304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241305, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop_cell(v_ru_24x1_241304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241305, 0ULL, 2);
      heff_drop(v_a_241301);
      heff_drop_cell(v_ru_24x1_241304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241310 = heff_field(v_v_241305, 0);
      heff_take_n(v_v_241305, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241304_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam92, 2, 2, (V[]){v_a_241301, v_a_241310})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241305, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop_cell(v_ru_24x1_241304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241305, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop_cell(v_ru_24x1_241304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241305, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop_cell(v_ru_24x1_241304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241305, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop_cell(v_ru_24x1_241304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241305, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop_cell(v_ru_24x1_241304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241305, 0ULL, 1);
      heff_drop(v_a_241301);
      heff_drop_cell(v_ru_24x1_241304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241305, 0ULL, 2);
      heff_drop(v_a_241301);
      heff_drop_cell(v_ru_24x1_241304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241301);
      heff_drop_cell(v_ru_24x1_241304_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241305);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241301);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241301);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241356 = heff_field(v_x1_241304, 0);
    V v_ru_24x1_241304_24Bug = heff_take_reuse_n(v_x1_241304, 1ULL, 1);
    heff_drop(v_a_241301);
    return heff_tag_at_n(v_ru_24x1_241304_24Bug, TAG_Bug, 1, (V[]){v_what_241356});
  }
  default: return heff_nomatch(v_x1_241304);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args) {
  V v_d_241287 = args[0];
  V v_a_241288 = args[1];
  V v_x1_241289 = heff_tr(heff_call(v_a_241288, 1, (V[]){v_d_241287}));
  switch (heff_tag_of(v_x1_241289)) {
  case TAG_Ok: {
    V v_v_241290 = heff_field(v_x1_241289, 0);
    V v_ru_24x1_241289_24Ok = heff_take_reuse_n(v_x1_241289, 1ULL, 1);
    switch (heff_tag_of(v_v_241290)) {
    case TAG_VFun: {
      heff_take_n(v_v_241290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241290, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241290, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241301 = heff_field(v_v_241290, 0);
      heff_take_n(v_v_241290, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241289_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam91, 2, 1, (V[]){v_a_241301})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241290, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241289_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241290);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241359 = heff_field(v_x1_241289, 0);
    V v_ru_24x1_241289_24Bug = heff_take_reuse_n(v_x1_241289, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241289_24Bug, TAG_Bug, 1, (V[]){v_what_241359});
  }
  default: return heff_nomatch(v_x1_241289);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args) {
  V v_d_241379 = args[0];
  V v_a_241380 = args[1];
  V v_a_241369 = heff_env(self)[0];
  V v_a_241378 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241381 = heff_tr(heff_call(v_a_241380, 1, (V[]){v_d_241379}));
  switch (heff_tag_of(v_x1_241381)) {
  case TAG_Ok: {
    V v_v_241382 = heff_field(v_x1_241381, 0);
    heff_take_n(v_x1_241381, 1ULL, 1);
    switch (heff_tag_of(v_v_241382)) {
    case TAG_VFun: {
      heff_take_n(v_v_241382, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop(v_a_241378);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241382, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop(v_a_241378);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241382, 0ULL, 2);
      heff_drop(v_a_241369);
      heff_drop(v_a_241378);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241387 = heff_field(v_v_241382, 0);
      heff_take_n(v_v_241382, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2ebytesOfIntV(v_a_241369, v_a_241378, v_a_241387));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241382, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop(v_a_241378);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241382, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop(v_a_241378);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241382, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop(v_a_241378);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241382, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop(v_a_241378);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241382, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop(v_a_241378);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241382, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop(v_a_241378);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241382, 0ULL, 2);
      heff_drop(v_a_241369);
      heff_drop(v_a_241378);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241369);
      heff_drop(v_a_241378);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241382);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241369);
    heff_drop(v_a_241378);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241369);
    heff_drop(v_a_241378);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241396 = heff_field(v_x1_241381, 0);
    V v_ru_24x1_241381_24Bug = heff_take_reuse_n(v_x1_241381, 1ULL, 1);
    heff_drop(v_a_241369);
    heff_drop(v_a_241378);
    return heff_tag_at_n(v_ru_24x1_241381_24Bug, TAG_Bug, 1, (V[]){v_what_241396});
  }
  default: return heff_nomatch(v_x1_241381);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args) {
  V v_d_241370 = args[0];
  V v_a_241371 = args[1];
  V v_a_241369 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241372 = heff_tr(heff_call(v_a_241371, 1, (V[]){v_d_241370}));
  switch (heff_tag_of(v_x1_241372)) {
  case TAG_Ok: {
    V v_v_241373 = heff_field(v_x1_241372, 0);
    V v_ru_24x1_241372_24Ok = heff_take_reuse_n(v_x1_241372, 1ULL, 1);
    switch (heff_tag_of(v_v_241373)) {
    case TAG_VFun: {
      heff_take_n(v_v_241373, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop_cell(v_ru_24x1_241372_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241373, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop_cell(v_ru_24x1_241372_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241373, 0ULL, 2);
      heff_drop(v_a_241369);
      heff_drop_cell(v_ru_24x1_241372_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241378 = heff_field(v_v_241373, 0);
      heff_take_n(v_v_241373, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241372_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam96, 2, 2, (V[]){v_a_241369, v_a_241378})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241373, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop_cell(v_ru_24x1_241372_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241373, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop_cell(v_ru_24x1_241372_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241373, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop_cell(v_ru_24x1_241372_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241373, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop_cell(v_ru_24x1_241372_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241373, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop_cell(v_ru_24x1_241372_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241373, 0ULL, 1);
      heff_drop(v_a_241369);
      heff_drop_cell(v_ru_24x1_241372_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241373, 0ULL, 2);
      heff_drop(v_a_241369);
      heff_drop_cell(v_ru_24x1_241372_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241369);
      heff_drop_cell(v_ru_24x1_241372_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241373);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241369);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241369);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241405 = heff_field(v_x1_241372, 0);
    V v_ru_24x1_241372_24Bug = heff_take_reuse_n(v_x1_241372, 1ULL, 1);
    heff_drop(v_a_241369);
    return heff_tag_at_n(v_ru_24x1_241372_24Bug, TAG_Bug, 1, (V[]){v_what_241405});
  }
  default: return heff_nomatch(v_x1_241372);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args) {
  V v_d_241361 = args[0];
  V v_a_241362 = args[1];
  V v_x1_241363 = heff_tr(heff_call(v_a_241362, 1, (V[]){v_d_241361}));
  switch (heff_tag_of(v_x1_241363)) {
  case TAG_Ok: {
    V v_v_241364 = heff_field(v_x1_241363, 0);
    V v_ru_24x1_241363_24Ok = heff_take_reuse_n(v_x1_241363, 1ULL, 1);
    switch (heff_tag_of(v_v_241364)) {
    case TAG_VFun: {
      heff_take_n(v_v_241364, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241363_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241364, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241363_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241364, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241363_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241369 = heff_field(v_v_241364, 0);
      heff_take_n(v_v_241364, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241363_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam95, 2, 1, (V[]){v_a_241369})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241364, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241363_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241364, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241363_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241364, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241363_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241364, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241363_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241364, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241363_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241364, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241363_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241364, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241363_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241363_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241364);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241414 = heff_field(v_x1_241363, 0);
    V v_ru_24x1_241363_24Bug = heff_take_reuse_n(v_x1_241363, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241363_24Bug, TAG_Bug, 1, (V[]){v_what_241414});
  }
  default: return heff_nomatch(v_x1_241363);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args) {
  V v_d_241440 = args[0];
  V v_a_241441 = args[1];
  V v_a_241439 = heff_env(self)[0];
  V v_a_241430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241442 = heff_tr(heff_call(v_a_241441, 1, (V[]){v_d_241440}));
  switch (heff_tag_of(v_x1_241442)) {
  case TAG_Ok: {
    V v_v_241443 = heff_field(v_x1_241442, 0);
    V v_ru_24x1_241442_24Ok = heff_take_reuse_n(v_x1_241442, 1ULL, 1);
    switch (heff_tag_of(v_v_241443)) {
    case TAG_VFun: {
      heff_take_n(v_v_241443, 0ULL, 1);
      heff_drop(v_a_241439);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241442_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241443, 0ULL, 1);
      heff_drop(v_a_241439);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241442_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241443, 0ULL, 2);
      heff_drop(v_a_241439);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241442_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241443, 0ULL, 1);
      heff_drop(v_a_241439);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241442_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241443, 0ULL, 1);
      heff_drop(v_a_241439);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241442_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241443, 0ULL, 1);
      heff_drop(v_a_241439);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241442_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241443, 0ULL, 1);
      heff_drop(v_a_241439);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241442_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241443, 0ULL, 1);
      heff_drop(v_a_241439);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241442_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241443, 0ULL, 1);
      heff_drop(v_a_241439);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241442_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241454 = heff_field(v_v_241443, 0);
      heff_take_n(v_v_241443, 1ULL, 1);
      V v_t_241461;
      if (heff_intLe_c_lent(MK_INT(0LL), v_a_241439, 1)) {
        V v_t_241456 = heff_intAdd(heff_dup(v_a_241439), heff_strLength_lent(v_a_241454, 0));
        if (heff_intLe_c(v_t_241456, heff_strLength_lent(v_a_241430, 0))) {
          V v_t_241458 = heff_intAdd(heff_dup(v_a_241439), heff_strLength_lent(v_a_241454, 0));
          V v_t_241460;
          if (heff_strEq_c(heff_strSlice(v_a_241430, v_a_241439, v_t_241458), v_a_241454)) {
            v_t_241460 = ((V)&g_heff_2ecompile_2einterp_2eprim_str99);
          } else {
            v_t_241460 = ((V)&g_heff_2ecompile_2einterp_2eprim_str100);
          }
          v_t_241461 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241460, NTAG(TAG_Nil)});
        } else {
          heff_drop(v_a_241439);
          heff_drop(v_a_241430);
          heff_drop(v_a_241454);
          v_t_241461 = heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str101), NTAG(TAG_Nil)});
        }
      } else {
        heff_drop(v_a_241439);
        heff_drop(v_a_241430);
        heff_drop(v_a_241454);
        v_t_241461 = heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str102), NTAG(TAG_Nil)});
      }
      return heff_tag_at_n(v_ru_24x1_241442_24Ok, TAG_Ok, 1, (V[]){v_t_241461});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241443, 0ULL, 2);
      heff_drop(v_a_241439);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241442_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241439);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241442_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241443);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241439);
    heff_drop(v_a_241430);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241439);
    heff_drop(v_a_241430);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241464 = heff_field(v_x1_241442, 0);
    V v_ru_24x1_241442_24Bug = heff_take_reuse_n(v_x1_241442, 1ULL, 1);
    heff_drop(v_a_241439);
    heff_drop(v_a_241430);
    return heff_tag_at_n(v_ru_24x1_241442_24Bug, TAG_Bug, 1, (V[]){v_what_241464});
  }
  default: return heff_nomatch(v_x1_241442);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args) {
  V v_d_241431 = args[0];
  V v_a_241432 = args[1];
  V v_a_241430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241433 = heff_tr(heff_call(v_a_241432, 1, (V[]){v_d_241431}));
  switch (heff_tag_of(v_x1_241433)) {
  case TAG_Ok: {
    V v_v_241434 = heff_field(v_x1_241433, 0);
    V v_ru_24x1_241433_24Ok = heff_take_reuse_n(v_x1_241433, 1ULL, 1);
    switch (heff_tag_of(v_v_241434)) {
    case TAG_VFun: {
      heff_take_n(v_v_241434, 0ULL, 1);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241433_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241434, 0ULL, 1);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241433_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241434, 0ULL, 2);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241433_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241439 = heff_field(v_v_241434, 0);
      heff_take_n(v_v_241434, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241433_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam99, 2, 2, (V[]){v_a_241439, v_a_241430})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241434, 0ULL, 1);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241433_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241434, 0ULL, 1);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241433_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241434, 0ULL, 1);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241433_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241434, 0ULL, 1);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241433_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241434, 0ULL, 1);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241433_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241434, 0ULL, 1);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241433_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241434, 0ULL, 2);
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241433_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241430);
      heff_drop_cell(v_ru_24x1_241433_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241434);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241430);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241430);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241473 = heff_field(v_x1_241433, 0);
    V v_ru_24x1_241433_24Bug = heff_take_reuse_n(v_x1_241433, 1ULL, 1);
    heff_drop(v_a_241430);
    return heff_tag_at_n(v_ru_24x1_241433_24Bug, TAG_Bug, 1, (V[]){v_what_241473});
  }
  default: return heff_nomatch(v_x1_241433);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args) {
  V v_d_241416 = args[0];
  V v_a_241417 = args[1];
  V v_x1_241418 = heff_tr(heff_call(v_a_241417, 1, (V[]){v_d_241416}));
  switch (heff_tag_of(v_x1_241418)) {
  case TAG_Ok: {
    V v_v_241419 = heff_field(v_x1_241418, 0);
    V v_ru_24x1_241418_24Ok = heff_take_reuse_n(v_x1_241418, 1ULL, 1);
    switch (heff_tag_of(v_v_241419)) {
    case TAG_VFun: {
      heff_take_n(v_v_241419, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241418_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241419, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241418_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241419, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241418_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241419, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241418_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241419, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241418_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241419, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241418_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241419, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241418_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241419, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241418_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241419, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241418_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241430 = heff_field(v_v_241419, 0);
      heff_take_n(v_v_241419, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241418_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam98, 2, 1, (V[]){v_a_241430})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241419, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241418_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241418_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241419);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241476 = heff_field(v_x1_241418, 0);
    V v_ru_24x1_241418_24Bug = heff_take_reuse_n(v_x1_241418, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241418_24Bug, TAG_Bug, 1, (V[]){v_what_241476});
  }
  default: return heff_nomatch(v_x1_241418);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args) {
  V v_d_241499 = args[0];
  V v_a_241500 = args[1];
  V v_s_241480 = heff_env(self)[0];
  V v_m_241479 = heff_env(self)[1];
  V v_a_241489 = heff_env(self)[2];
  V v_a_241498 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_241501 = heff_tr(heff_call(v_a_241500, 1, (V[]){v_d_241499}));
  switch (heff_tag_of(v_x1_241501)) {
  case TAG_Ok: {
    V v_v_241502 = heff_field(v_x1_241501, 0);
    heff_take_n(v_x1_241501, 1ULL, 1);
    switch (heff_tag_of(v_v_241502)) {
    case TAG_VFun: {
      heff_take_n(v_v_241502, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop(v_a_241498);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241502, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop(v_a_241498);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241502, 0ULL, 2);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop(v_a_241498);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241507 = heff_field(v_v_241502, 0);
      heff_take_n(v_v_241502, 1ULL, 1);
      return ({ V a_0 = v_s_241480; V a_1 = v_m_241479; V a_2 = v_a_241489; V a_3 = v_a_241498; V a_4 = v_a_241507; V r_ = (g_heff_2ecompile_2einterp_2eintAtV(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_241480); r_; });
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241502, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop(v_a_241498);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241502, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop(v_a_241498);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241502, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop(v_a_241498);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241502, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop(v_a_241498);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241502, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop(v_a_241498);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241502, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop(v_a_241498);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241502, 0ULL, 2);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop(v_a_241498);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop(v_a_241498);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241502);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241480);
    heff_drop(v_m_241479);
    heff_drop(v_a_241489);
    heff_drop(v_a_241498);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241480);
    heff_drop(v_m_241479);
    heff_drop(v_a_241489);
    heff_drop(v_a_241498);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241516 = heff_field(v_x1_241501, 0);
    V v_ru_24x1_241501_24Bug = heff_take_reuse_n(v_x1_241501, 1ULL, 1);
    heff_drop(v_s_241480);
    heff_drop(v_m_241479);
    heff_drop(v_a_241489);
    heff_drop(v_a_241498);
    return heff_tag_at_n(v_ru_24x1_241501_24Bug, TAG_Bug, 1, (V[]){v_what_241516});
  }
  default: return heff_nomatch(v_x1_241501);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args) {
  V v_d_241490 = args[0];
  V v_a_241491 = args[1];
  V v_s_241480 = heff_env(self)[0];
  V v_m_241479 = heff_env(self)[1];
  V v_a_241489 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241492 = heff_tr(heff_call(v_a_241491, 1, (V[]){v_d_241490}));
  switch (heff_tag_of(v_x1_241492)) {
  case TAG_Ok: {
    V v_v_241493 = heff_field(v_x1_241492, 0);
    V v_ru_24x1_241492_24Ok = heff_take_reuse_n(v_x1_241492, 1ULL, 1);
    switch (heff_tag_of(v_v_241493)) {
    case TAG_VFun: {
      heff_take_n(v_v_241493, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop_cell(v_ru_24x1_241492_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241493, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop_cell(v_ru_24x1_241492_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241493, 0ULL, 2);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop_cell(v_ru_24x1_241492_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241498 = heff_field(v_v_241493, 0);
      heff_take_n(v_v_241493, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241492_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam103, 2, 4, (V[]){v_s_241480, v_m_241479, v_a_241489, v_a_241498})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241493, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop_cell(v_ru_24x1_241492_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241493, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop_cell(v_ru_24x1_241492_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241493, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop_cell(v_ru_24x1_241492_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241493, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop_cell(v_ru_24x1_241492_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241493, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop_cell(v_ru_24x1_241492_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241493, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop_cell(v_ru_24x1_241492_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241493, 0ULL, 2);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop_cell(v_ru_24x1_241492_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop(v_a_241489);
      heff_drop_cell(v_ru_24x1_241492_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241493);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241480);
    heff_drop(v_m_241479);
    heff_drop(v_a_241489);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241480);
    heff_drop(v_m_241479);
    heff_drop(v_a_241489);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241525 = heff_field(v_x1_241492, 0);
    V v_ru_24x1_241492_24Bug = heff_take_reuse_n(v_x1_241492, 1ULL, 1);
    heff_drop(v_s_241480);
    heff_drop(v_m_241479);
    heff_drop(v_a_241489);
    return heff_tag_at_n(v_ru_24x1_241492_24Bug, TAG_Bug, 1, (V[]){v_what_241525});
  }
  default: return heff_nomatch(v_x1_241492);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args) {
  V v_d_241481 = args[0];
  V v_a_241482 = args[1];
  V v_s_241480 = heff_env(self)[0];
  V v_m_241479 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241483 = heff_tr(heff_call(v_a_241482, 1, (V[]){v_d_241481}));
  switch (heff_tag_of(v_x1_241483)) {
  case TAG_Ok: {
    V v_v_241484 = heff_field(v_x1_241483, 0);
    V v_ru_24x1_241483_24Ok = heff_take_reuse_n(v_x1_241483, 1ULL, 1);
    switch (heff_tag_of(v_v_241484)) {
    case TAG_VFun: {
      heff_take_n(v_v_241484, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop_cell(v_ru_24x1_241483_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241484, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop_cell(v_ru_24x1_241483_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241484, 0ULL, 2);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop_cell(v_ru_24x1_241483_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241489 = heff_field(v_v_241484, 0);
      heff_take_n(v_v_241484, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241483_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam102, 2, 3, (V[]){v_s_241480, v_m_241479, v_a_241489})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241484, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop_cell(v_ru_24x1_241483_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241484, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop_cell(v_ru_24x1_241483_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241484, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop_cell(v_ru_24x1_241483_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241484, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop_cell(v_ru_24x1_241483_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241484, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop_cell(v_ru_24x1_241483_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241484, 0ULL, 1);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop_cell(v_ru_24x1_241483_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241484, 0ULL, 2);
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop_cell(v_ru_24x1_241483_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241480);
      heff_drop(v_m_241479);
      heff_drop_cell(v_ru_24x1_241483_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241484);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241480);
    heff_drop(v_m_241479);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241480);
    heff_drop(v_m_241479);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241534 = heff_field(v_x1_241483, 0);
    V v_ru_24x1_241483_24Bug = heff_take_reuse_n(v_x1_241483, 1ULL, 1);
    heff_drop(v_s_241480);
    heff_drop(v_m_241479);
    return heff_tag_at_n(v_ru_24x1_241483_24Bug, TAG_Bug, 1, (V[]){v_what_241534});
  }
  default: return heff_nomatch(v_x1_241483);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args) {
  V v_m_241479 = args[0];
  V v_s_241480 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam101, 2, 2, (V[]){v_s_241480, v_m_241479})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args) {
  V v_d_241554 = args[0];
  V v_a_241555 = args[1];
  V v_a_241544 = heff_env(self)[0];
  V v_a_241553 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241556 = heff_tr(heff_call(v_a_241555, 1, (V[]){v_d_241554}));
  switch (heff_tag_of(v_x1_241556)) {
  case TAG_Ok: {
    V v_v_241557 = heff_field(v_x1_241556, 0);
    heff_take_n(v_x1_241556, 1ULL, 1);
    switch (heff_tag_of(v_v_241557)) {
    case TAG_VFun: {
      heff_take_n(v_v_241557, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop(v_a_241553);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241557, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop(v_a_241553);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241557, 0ULL, 2);
      heff_drop(v_a_241544);
      heff_drop(v_a_241553);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241562 = heff_field(v_v_241557, 0);
      heff_take_n(v_v_241557, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2ebitsOfIntV(v_a_241544, v_a_241553, v_a_241562));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241557, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop(v_a_241553);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241557, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop(v_a_241553);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241557, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop(v_a_241553);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241557, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop(v_a_241553);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241557, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop(v_a_241553);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241557, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop(v_a_241553);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241557, 0ULL, 2);
      heff_drop(v_a_241544);
      heff_drop(v_a_241553);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241544);
      heff_drop(v_a_241553);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241557);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241544);
    heff_drop(v_a_241553);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241544);
    heff_drop(v_a_241553);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241571 = heff_field(v_x1_241556, 0);
    V v_ru_24x1_241556_24Bug = heff_take_reuse_n(v_x1_241556, 1ULL, 1);
    heff_drop(v_a_241544);
    heff_drop(v_a_241553);
    return heff_tag_at_n(v_ru_24x1_241556_24Bug, TAG_Bug, 1, (V[]){v_what_241571});
  }
  default: return heff_nomatch(v_x1_241556);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args) {
  V v_d_241545 = args[0];
  V v_a_241546 = args[1];
  V v_a_241544 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241547 = heff_tr(heff_call(v_a_241546, 1, (V[]){v_d_241545}));
  switch (heff_tag_of(v_x1_241547)) {
  case TAG_Ok: {
    V v_v_241548 = heff_field(v_x1_241547, 0);
    V v_ru_24x1_241547_24Ok = heff_take_reuse_n(v_x1_241547, 1ULL, 1);
    switch (heff_tag_of(v_v_241548)) {
    case TAG_VFun: {
      heff_take_n(v_v_241548, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop_cell(v_ru_24x1_241547_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241548, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop_cell(v_ru_24x1_241547_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241548, 0ULL, 2);
      heff_drop(v_a_241544);
      heff_drop_cell(v_ru_24x1_241547_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241553 = heff_field(v_v_241548, 0);
      heff_take_n(v_v_241548, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241547_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam106, 2, 2, (V[]){v_a_241544, v_a_241553})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241548, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop_cell(v_ru_24x1_241547_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241548, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop_cell(v_ru_24x1_241547_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241548, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop_cell(v_ru_24x1_241547_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241548, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop_cell(v_ru_24x1_241547_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241548, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop_cell(v_ru_24x1_241547_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241548, 0ULL, 1);
      heff_drop(v_a_241544);
      heff_drop_cell(v_ru_24x1_241547_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241548, 0ULL, 2);
      heff_drop(v_a_241544);
      heff_drop_cell(v_ru_24x1_241547_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241544);
      heff_drop_cell(v_ru_24x1_241547_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241548);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241544);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241544);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241580 = heff_field(v_x1_241547, 0);
    V v_ru_24x1_241547_24Bug = heff_take_reuse_n(v_x1_241547, 1ULL, 1);
    heff_drop(v_a_241544);
    return heff_tag_at_n(v_ru_24x1_241547_24Bug, TAG_Bug, 1, (V[]){v_what_241580});
  }
  default: return heff_nomatch(v_x1_241547);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args) {
  V v_d_241536 = args[0];
  V v_a_241537 = args[1];
  V v_x1_241538 = heff_tr(heff_call(v_a_241537, 1, (V[]){v_d_241536}));
  switch (heff_tag_of(v_x1_241538)) {
  case TAG_Ok: {
    V v_v_241539 = heff_field(v_x1_241538, 0);
    V v_ru_24x1_241538_24Ok = heff_take_reuse_n(v_x1_241538, 1ULL, 1);
    switch (heff_tag_of(v_v_241539)) {
    case TAG_VFun: {
      heff_take_n(v_v_241539, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241538_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241539, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241538_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241539, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241538_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241544 = heff_field(v_v_241539, 0);
      heff_take_n(v_v_241539, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241538_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam105, 2, 1, (V[]){v_a_241544})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241539, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241538_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241539, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241538_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241539, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241538_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241539, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241538_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241539, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241538_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241539, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241538_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241539, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241538_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241538_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241539);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241589 = heff_field(v_x1_241538, 0);
    V v_ru_24x1_241538_24Bug = heff_take_reuse_n(v_x1_241538, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241538_24Bug, TAG_Bug, 1, (V[]){v_what_241589});
  }
  default: return heff_nomatch(v_x1_241538);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args) {
  V v_d_241591 = args[0];
  V v_l_241592 = args[1];
  V v_x1_241593 = heff_tr(heff_call(v_l_241592, 1, (V[]){v_d_241591}));
  switch (heff_tag_of(v_x1_241593)) {
  case TAG_Ok: {
    V v_v_241594 = heff_field(v_x1_241593, 0);
    heff_take_n(v_x1_241593, 1ULL, 1);
    V v_t_241595 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241594, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_241595; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2einterp_2eprim_str107); V r_ = (g_heff_2ecompile_2einterp_2ebitsJoined(a_0, a_1, a_2)); heff_drop(v_t_241595); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241596 = heff_field(v_x1_241593, 0);
    V v_ru_24x1_241593_24Bug = heff_take_reuse_n(v_x1_241593, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241593_24Bug, TAG_Bug, 1, (V[]){v_what_241596});
  }
  default: return heff_nomatch(v_x1_241593);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam110(V self, V *args) {
  V v_d_241609 = args[0];
  V v_a_241610 = args[1];
  V v_a_241608 = heff_env(self)[0];
  V v_m_241598 = heff_env(self)[1];
  V v_s_241599 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241611 = heff_tr(heff_call(v_a_241610, 1, (V[]){v_d_241609}));
  switch (heff_tag_of(v_x1_241611)) {
  case TAG_Ok: {
    V v_v_241612 = heff_field(v_x1_241611, 0);
    V v_ru_24x1_241611_24Ok = heff_take_reuse_n(v_x1_241611, 1ULL, 1);
    switch (heff_tag_of(v_v_241612)) {
    case TAG_VFun: {
      heff_take_n(v_v_241612, 0ULL, 1);
      heff_drop(v_a_241608);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241611_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241612, 0ULL, 1);
      heff_drop(v_a_241608);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241611_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241612, 0ULL, 2);
      heff_drop(v_a_241608);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241611_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241617 = heff_field(v_v_241612, 0);
      heff_take_n(v_v_241612, 1ULL, 1);
      if (heff_intLt_c_lent(v_a_241608, MK_INT(0LL), 2)) {
        heff_drop(v_a_241608);
        heff_drop(v_m_241598);
        heff_drop(v_s_241599);
        heff_drop_cell(v_ru_24x1_241611_24Ok, 1);
        heff_drop(v_a_241617);
        return NTAG(TAG_Abn);
      } else {
        if (heff_intLt_c_lent(v_a_241617, MK_INT(0LL), 2)) {
          heff_drop(v_a_241608);
          heff_drop(v_m_241598);
          heff_drop(v_s_241599);
          heff_drop_cell(v_ru_24x1_241611_24Ok, 1);
          heff_drop(v_a_241617);
          return NTAG(TAG_Abn);
        } else {
          if (heff_intLt_c(v_m_241598, heff_intAdd(heff_dup(v_a_241608), heff_dup(v_a_241617)))) {
            heff_drop(v_a_241608);
            heff_drop(v_s_241599);
            heff_drop_cell(v_ru_24x1_241611_24Ok, 1);
            heff_drop(v_a_241617);
            return NTAG(TAG_Abn);
          } else {
            V v_t_241621 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str109); V a_2 = v_s_241599; V a_3 = heff_dup(v_a_241608); V a_4 = heff_intAdd(v_a_241608, heff_dup(v_a_241617)); V r_ = (g_heff_2ecompile_2einterp_2ebitsCopy(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_241599); r_; });
            return heff_tag_at_n(v_ru_24x1_241611_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_a_241617, v_t_241621})});
          }
        }
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241612, 0ULL, 1);
      heff_drop(v_a_241608);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241611_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241612, 0ULL, 1);
      heff_drop(v_a_241608);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241611_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241612, 0ULL, 1);
      heff_drop(v_a_241608);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241611_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241612, 0ULL, 1);
      heff_drop(v_a_241608);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241611_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241612, 0ULL, 1);
      heff_drop(v_a_241608);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241611_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241612, 0ULL, 1);
      heff_drop(v_a_241608);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241611_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241612, 0ULL, 2);
      heff_drop(v_a_241608);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241611_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241608);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241611_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241612);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241608);
    heff_drop(v_m_241598);
    heff_drop(v_s_241599);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241608);
    heff_drop(v_m_241598);
    heff_drop(v_s_241599);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241630 = heff_field(v_x1_241611, 0);
    V v_ru_24x1_241611_24Bug = heff_take_reuse_n(v_x1_241611, 1ULL, 1);
    heff_drop(v_a_241608);
    heff_drop(v_m_241598);
    heff_drop(v_s_241599);
    return heff_tag_at_n(v_ru_24x1_241611_24Bug, TAG_Bug, 1, (V[]){v_what_241630});
  }
  default: return heff_nomatch(v_x1_241611);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args) {
  V v_d_241600 = args[0];
  V v_a_241601 = args[1];
  V v_m_241598 = heff_env(self)[0];
  V v_s_241599 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241602 = heff_tr(heff_call(v_a_241601, 1, (V[]){v_d_241600}));
  switch (heff_tag_of(v_x1_241602)) {
  case TAG_Ok: {
    V v_v_241603 = heff_field(v_x1_241602, 0);
    V v_ru_24x1_241602_24Ok = heff_take_reuse_n(v_x1_241602, 1ULL, 1);
    switch (heff_tag_of(v_v_241603)) {
    case TAG_VFun: {
      heff_take_n(v_v_241603, 0ULL, 1);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241602_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241603, 0ULL, 1);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241602_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241603, 0ULL, 2);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241602_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241608 = heff_field(v_v_241603, 0);
      heff_take_n(v_v_241603, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241602_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam110, 2, 3, (V[]){v_a_241608, v_m_241598, v_s_241599})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241603, 0ULL, 1);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241602_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241603, 0ULL, 1);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241602_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241603, 0ULL, 1);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241602_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241603, 0ULL, 1);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241602_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241603, 0ULL, 1);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241602_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241603, 0ULL, 1);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241602_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241603, 0ULL, 2);
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241602_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_m_241598);
      heff_drop(v_s_241599);
      heff_drop_cell(v_ru_24x1_241602_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241603);
    }
  }
  case TAG_Abn: {
    heff_drop(v_m_241598);
    heff_drop(v_s_241599);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_m_241598);
    heff_drop(v_s_241599);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241639 = heff_field(v_x1_241602, 0);
    V v_ru_24x1_241602_24Bug = heff_take_reuse_n(v_x1_241602, 1ULL, 1);
    heff_drop(v_m_241598);
    heff_drop(v_s_241599);
    return heff_tag_at_n(v_ru_24x1_241602_24Bug, TAG_Bug, 1, (V[]){v_what_241639});
  }
  default: return heff_nomatch(v_x1_241602);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args) {
  V v_m_241598 = args[0];
  V v_s_241599 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam109, 2, 2, (V[]){v_m_241598, v_s_241599})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam111(V self, V *args) {
  V v_d_241641 = args[0];
  V v_a_241642 = args[1];
  V v_x1_241643 = heff_tr(heff_call(v_a_241642, 1, (V[]){v_d_241641}));
  switch (heff_tag_of(v_x1_241643)) {
  case TAG_Ok: {
    V v_v_241644 = heff_field(v_x1_241643, 0);
    V v_ru_24x1_241643_24Ok = heff_take_reuse_n(v_x1_241643, 1ULL, 1);
    switch (heff_tag_of(v_v_241644)) {
    case TAG_VFun: {
      heff_take_n(v_v_241644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241644, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241655 = heff_field(v_v_241644, 0);
      heff_take_n(v_v_241644, 1ULL, 1);
      V v_t_241656 = heff_intMul(heff_strLength_lent(v_a_241655, 0), MK_INT(8LL));
      return heff_tag_at_n(v_ru_24x1_241643_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_t_241656, v_a_241655})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241644, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241644);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241659 = heff_field(v_x1_241643, 0);
    V v_ru_24x1_241643_24Bug = heff_take_reuse_n(v_x1_241643, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241643_24Bug, TAG_Bug, 1, (V[]){v_what_241659});
  }
  default: return heff_nomatch(v_x1_241643);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam112(V self, V *args) {
  V v_n_241661 = args[0];
  V v_s_241662 = args[1];
  if ((heff_unbox_word(heff_intMod(v_n_241661, MK_INT(8LL))) == ((int64_t)0ULL))) {
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_s_241662})});
  } else {
    heff_drop(v_s_241662);
    return NTAG(TAG_Abn);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam114(V self, V *args) {
  V v_m_241667 = args[0];
  V v_t_241668 = args[1];
  V v_n_241665 = heff_env(self)[0];
  V v_s_241666 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_241672;
  if (heff_intEq_c(v_n_241665, v_m_241667)) {
    V v_t_241671;
    if (heff_strEq_c(v_s_241666, v_t_241668)) {
      v_t_241671 = ((V)&g_heff_2ecompile_2einterp_2eprim_str113);
    } else {
      v_t_241671 = ((V)&g_heff_2ecompile_2einterp_2eprim_str114);
    }
    v_t_241672 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241671, NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_241668);
    heff_drop(v_s_241666);
    v_t_241672 = heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str115), NTAG(TAG_Nil)});
  }
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241672});
}
V g_heff_2ecompile_2einterp_2eprim_lam113(V self, V *args) {
  V v_n_241665 = args[0];
  V v_s_241666 = args[1];
  V v_t_241673 = (g_heff_2ecompile_2einterp_2ebits1(heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam114, 2, 2, (V[]){v_n_241665, v_s_241666})));
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241673});
}
V g_heff_2ecompile_2einterp_2eprim_lam116(V self, V *args) {
  V v_d_241684 = args[0];
  V v_a_241685 = args[1];
  V v_a_241683 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241686 = heff_tr(heff_call(v_a_241685, 1, (V[]){v_d_241684}));
  switch (heff_tag_of(v_x1_241686)) {
  case TAG_Ok: {
    V v_v_241687 = heff_field(v_x1_241686, 0);
    V v_ru_24x1_241686_24Ok = heff_take_reuse_n(v_x1_241686, 1ULL, 1);
    switch (heff_tag_of(v_v_241687)) {
    case TAG_VFun: {
      heff_take_n(v_v_241687, 0ULL, 1);
      heff_drop(v_a_241683);
      heff_drop_cell(v_ru_24x1_241686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241687, 0ULL, 1);
      heff_drop(v_a_241683);
      heff_drop_cell(v_ru_24x1_241686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241687, 0ULL, 2);
      heff_drop(v_a_241683);
      heff_drop_cell(v_ru_24x1_241686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241687, 0ULL, 1);
      heff_drop(v_a_241683);
      heff_drop_cell(v_ru_24x1_241686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_241693 = heff_tflat_f64(v_v_241687, 0);
      heff_take_na(v_v_241687, 0ULL, 1);
      if (heff_intEq_c_lent(v_a_241683, MK_INT(64LL), 2)) {
        heff_drop(v_a_241683);
        V v_t_241695 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(11LL), MK_INT(52LL), v_a_241693));
        return heff_tag_at_n(v_ru_24x1_241686_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_241695})});
      } else {
        if (heff_intEq_c(v_a_241683, MK_INT(32LL))) {
          double v_t_241697 = ((double)((float)v_a_241693));
          V v_t_241698 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(8LL), MK_INT(23LL), v_t_241697));
          return heff_tag_at_n(v_ru_24x1_241686_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_241698})});
        } else {
          heff_drop_cell(v_ru_24x1_241686_24Ok, 1);
          return NTAG(TAG_Abn);
        }
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241687, 0ULL, 1);
      heff_drop(v_a_241683);
      heff_drop_cell(v_ru_24x1_241686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241687, 0ULL, 1);
      heff_drop(v_a_241683);
      heff_drop_cell(v_ru_24x1_241686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241687, 0ULL, 1);
      heff_drop(v_a_241683);
      heff_drop_cell(v_ru_24x1_241686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241687, 0ULL, 1);
      heff_drop(v_a_241683);
      heff_drop_cell(v_ru_24x1_241686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241687, 0ULL, 1);
      heff_drop(v_a_241683);
      heff_drop_cell(v_ru_24x1_241686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241687, 0ULL, 2);
      heff_drop(v_a_241683);
      heff_drop_cell(v_ru_24x1_241686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241683);
      heff_drop_cell(v_ru_24x1_241686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_241687);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241683);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241683);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241706 = heff_field(v_x1_241686, 0);
    V v_ru_24x1_241686_24Bug = heff_take_reuse_n(v_x1_241686, 1ULL, 1);
    heff_drop(v_a_241683);
    return heff_tag_at_n(v_ru_24x1_241686_24Bug, TAG_Bug, 1, (V[]){v_what_241706});
  }
  default: return heff_nomatch(v_x1_241686);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam115(V self, V *args) {
  V v_d_241675 = args[0];
  V v_a_241676 = args[1];
  V v_x1_241677 = heff_tr(heff_call(v_a_241676, 1, (V[]){v_d_241675}));
  switch (heff_tag_of(v_x1_241677)) {
  case TAG_Ok: {
    V v_v_241678 = heff_field(v_x1_241677, 0);
    V v_ru_24x1_241677_24Ok = heff_take_reuse_n(v_x1_241677, 1ULL, 1);
    switch (heff_tag_of(v_v_241678)) {
    case TAG_VFun: {
      heff_take_n(v_v_241678, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241677_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241678, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241677_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241678, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241677_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241683 = heff_field(v_v_241678, 0);
      heff_take_n(v_v_241678, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241677_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam116, 2, 1, (V[]){v_a_241683})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241678, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241677_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241678, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241677_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241678, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241677_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241678, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241677_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241678, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241677_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241678, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241677_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241678, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241677_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241677_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241678);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241715 = heff_field(v_x1_241677, 0);
    V v_ru_24x1_241677_24Bug = heff_take_reuse_n(v_x1_241677, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241677_24Bug, TAG_Bug, 1, (V[]){v_what_241715});
  }
  default: return heff_nomatch(v_x1_241677);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam118(V self, V *args) {
  V v_d_241726 = args[0];
  V v_a_241727 = args[1];
  V v_a_241725 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241728 = heff_tr(heff_call(v_a_241727, 1, (V[]){v_d_241726}));
  switch (heff_tag_of(v_x1_241728)) {
  case TAG_Ok: {
    V v_v_241729 = heff_field(v_x1_241728, 0);
    heff_take_n(v_x1_241728, 1ULL, 1);
    switch (heff_tag_of(v_v_241729)) {
    case TAG_VFun: {
      heff_take_n(v_v_241729, 0ULL, 1);
      heff_drop(v_a_241725);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241729, 0ULL, 1);
      heff_drop(v_a_241725);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241729, 0ULL, 2);
      heff_drop(v_a_241725);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241734 = heff_field(v_v_241729, 0);
      heff_take_n(v_v_241729, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2efloatOfBitsV(v_a_241725, v_a_241734));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241729, 0ULL, 1);
      heff_drop(v_a_241725);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241729, 0ULL, 1);
      heff_drop(v_a_241725);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241729, 0ULL, 1);
      heff_drop(v_a_241725);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241729, 0ULL, 1);
      heff_drop(v_a_241725);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241729, 0ULL, 1);
      heff_drop(v_a_241725);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241729, 0ULL, 1);
      heff_drop(v_a_241725);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241729, 0ULL, 2);
      heff_drop(v_a_241725);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241725);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241729);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241725);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241725);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241743 = heff_field(v_x1_241728, 0);
    V v_ru_24x1_241728_24Bug = heff_take_reuse_n(v_x1_241728, 1ULL, 1);
    heff_drop(v_a_241725);
    return heff_tag_at_n(v_ru_24x1_241728_24Bug, TAG_Bug, 1, (V[]){v_what_241743});
  }
  default: return heff_nomatch(v_x1_241728);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam117(V self, V *args) {
  V v_d_241717 = args[0];
  V v_a_241718 = args[1];
  V v_x1_241719 = heff_tr(heff_call(v_a_241718, 1, (V[]){v_d_241717}));
  switch (heff_tag_of(v_x1_241719)) {
  case TAG_Ok: {
    V v_v_241720 = heff_field(v_x1_241719, 0);
    V v_ru_24x1_241719_24Ok = heff_take_reuse_n(v_x1_241719, 1ULL, 1);
    switch (heff_tag_of(v_v_241720)) {
    case TAG_VFun: {
      heff_take_n(v_v_241720, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241719_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241720, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241719_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241720, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241719_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241725 = heff_field(v_v_241720, 0);
      heff_take_n(v_v_241720, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241719_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam118, 2, 1, (V[]){v_a_241725})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241720, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241719_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241720, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241719_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241720, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241719_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241720, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241719_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241720, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241719_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241720, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241719_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241720, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241719_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241719_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241720);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241752 = heff_field(v_x1_241719, 0);
    V v_ru_24x1_241719_24Bug = heff_take_reuse_n(v_x1_241719, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241719_24Bug, TAG_Bug, 1, (V[]){v_what_241752});
  }
  default: return heff_nomatch(v_x1_241719);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam119(V self, V *args) {
  V v_a_241754 = args[0];
  V v_b_241755 = args[1];
  V v_t_241757;
  if (heff_intEq_c(v_a_241754, v_b_241755)) {
    v_t_241757 = ((V)&g_heff_2ecompile_2einterp_2eprim_str119);
  } else {
    v_t_241757 = ((V)&g_heff_2ecompile_2einterp_2eprim_str120);
  }
  V v_t_241758 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241757, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241758});
}
V g_heff_2ecompile_2einterp_2eprim_lam120(V self, V *args) {
  V v_a_241760 = args[0];
  V v_b_241761 = args[1];
  V v_t_241763;
  if (heff_intLt_c(v_a_241760, v_b_241761)) {
    v_t_241763 = ((V)&g_heff_2ecompile_2einterp_2eprim_str122);
  } else {
    v_t_241763 = ((V)&g_heff_2ecompile_2einterp_2eprim_str123);
  }
  V v_t_241764 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241763, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241764});
}
V g_heff_2ecompile_2einterp_2eprim_lam121(V self, V *args) {
  V v_a_241766 = args[0];
  V v_b_241767 = args[1];
  V v_t_241769;
  if (heff_intLe_c(v_a_241766, v_b_241767)) {
    v_t_241769 = ((V)&g_heff_2ecompile_2einterp_2eprim_str125);
  } else {
    v_t_241769 = ((V)&g_heff_2ecompile_2einterp_2eprim_str126);
  }
  V v_t_241770 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241769, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241770});
}
V g_heff_2ecompile_2einterp_2eprim_lam122(V self, V *args) {
  V v_d_241772 = args[0];
  V v_a_241773 = args[1];
  V v_x1_241774 = heff_tr(heff_call(v_a_241773, 1, (V[]){v_d_241772}));
  switch (heff_tag_of(v_x1_241774)) {
  case TAG_Ok: {
    V v_v_241775 = heff_field(v_x1_241774, 0);
    V v_ru_24x1_241774_24Ok = heff_take_reuse_n(v_x1_241774, 1ULL, 1);
    switch (heff_tag_of(v_v_241775)) {
    case TAG_VFun: {
      heff_take_n(v_v_241775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241775, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VRune: {
      V v_a_241784 = heff_field(v_v_241775, 0);
      heff_take_n(v_v_241775, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241774_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_241784})});
    }
    case TAG_VArr: {
      heff_take_n(v_v_241775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241775, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241775, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241774_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    default: return heff_nomatch(v_v_241775);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241789 = heff_field(v_x1_241774, 0);
    V v_ru_24x1_241774_24Bug = heff_take_reuse_n(v_x1_241774, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241774_24Bug, TAG_Bug, 1, (V[]){v_what_241789});
  }
  default: return heff_nomatch(v_x1_241774);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam124(V self, V *args) {
  V v_d_241793 = args[0];
  V v_a_241794 = args[1];
  V f_ = v_a_241794;
  args[0] = v_d_241793;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2einterp_2eprim_lam123(V self, V *args) {
  V v_d_241791 = args[0];
  V v_u_241792 = args[1];
  heff_drop(v_d_241791);
  heff_drop(v_u_241792);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam124_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam125(V self, V *args) {
  V v_d_241796 = args[0];
  V v_a_241797 = args[1];
  V v_x1_241798 = heff_tr(heff_call(v_a_241797, 1, (V[]){v_d_241796}));
  switch (heff_tag_of(v_x1_241798)) {
  case TAG_Ok: {
    V v_v_241799 = heff_field(v_x1_241798, 0);
    V v_ru_24x1_241798_24Ok = heff_take_reuse_n(v_x1_241798, 1ULL, 1);
    switch (heff_tag_of(v_v_241799)) {
    case TAG_VFun: {
      heff_take_n(v_v_241799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241799, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241804 = heff_field(v_v_241799, 0);
      heff_take_n(v_v_241799, 1ULL, 1);
      V v_t_241805 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_241806 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_241807 = heff_intSub(v_a_241804, heff_intSub(MK_INT(0LL), v_t_241806));
      V v_t_241808 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(32LL)));
      V v_t_241809 = heff_intAdd(heff_intSub(MK_INT(0LL), v_t_241805), heff_intMod(v_t_241807, v_t_241808));
      return heff_tag_at_n(v_ru_24x1_241798_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VRune, 1, (V[]){v_t_241809})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241799, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241799);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241818 = heff_field(v_x1_241798, 0);
    V v_ru_24x1_241798_24Bug = heff_take_reuse_n(v_x1_241798, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241798_24Bug, TAG_Bug, 1, (V[]){v_what_241818});
  }
  default: return heff_nomatch(v_x1_241798);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam126(V self, V *args) {
  V v_d_241820 = args[0];
  V v_a_241821 = args[1];
  V v_x1_241822 = heff_tr(heff_call(v_a_241821, 1, (V[]){v_d_241820}));
  switch (heff_tag_of(v_x1_241822)) {
  case TAG_Ok: {
    V v_v_241823 = heff_field(v_x1_241822, 0);
    V v_ru_24x1_241822_24Ok = heff_take_reuse_n(v_x1_241822, 1ULL, 1);
    switch (heff_tag_of(v_v_241823)) {
    case TAG_VFun: {
      heff_take_n(v_v_241823, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241822_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241823, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241822_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241823, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241822_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241823, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241822_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241823, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241822_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241823, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241822_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241831 = heff_field(v_v_241823, 0);
      heff_take_n(v_v_241823, 1ULL, 1);
      V v_t_241832 = (g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(heff_strRunes(v_a_241831)));
      return heff_tag_at_n(v_ru_24x1_241822_24Ok, TAG_Ok, 1, (V[]){v_t_241832});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241823, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241822_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241823, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241822_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241823, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241822_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241823, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241822_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241822_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241823);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241838 = heff_field(v_x1_241822, 0);
    V v_ru_24x1_241822_24Bug = heff_take_reuse_n(v_x1_241822, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241822_24Bug, TAG_Bug, 1, (V[]){v_what_241838});
  }
  default: return heff_nomatch(v_x1_241822);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam127(V self, V *args) {
  V v_d_241840 = args[0];
  V v_l_241841 = args[1];
  V v_x1_241842 = heff_tr(heff_call(v_l_241841, 1, (V[]){v_d_241840}));
  switch (heff_tag_of(v_x1_241842)) {
  case TAG_Ok: {
    V v_v_241843 = heff_field(v_x1_241842, 0);
    V v_ru_24x1_241842_24Ok = heff_take_reuse_n(v_x1_241842, 1ULL, 1);
    V v_t_241844 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241843, NTAG(TAG_Nil)));
    V v_t_241845 = (g_heff_2ecompile_2einterp_2eruneCodes(v_t_241844));
    V v_t_241846 = (g_list_2emap(heff_dup(g_runeFromInt_get()), v_t_241845));
    V v_t_241847 = heff_tag_n(TAG_VStr, 1, (V[]){heff_strOfRunes(v_t_241846)});
    return heff_tag_at_n(v_ru_24x1_241842_24Ok, TAG_Ok, 1, (V[]){v_t_241847});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241848 = heff_field(v_x1_241842, 0);
    V v_ru_24x1_241842_24Bug = heff_take_reuse_n(v_x1_241842, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241842_24Bug, TAG_Bug, 1, (V[]){v_what_241848});
  }
  default: return heff_nomatch(v_x1_241842);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam128(V self, V *args) {
  V v_d_241854 = args[0];
  V v_a_241855 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241854);
  heff_drop(v_a_241855);
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprim_str132), v_p_240)});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str0, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str3, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str6, 2, "{ ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str7, 2, " }");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str9, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str10, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str11, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str15, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str16, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str17, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str20, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str21, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str22, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str23, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str24, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str25, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str26, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str27, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str28, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str29, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str30, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str31, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str32, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str33, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str34, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str35, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str36, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str37, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str38, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str39, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str40, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str41, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str42, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str43, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str44, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str45, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str46, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str47, 1, ")");
Clo g_heff_2ecompile_2einterp_2eshowValGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eshowValGo_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eshowValGo(V v_inArg_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VFun: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_243 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_243, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str0))) {
        V v_t_245 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str1), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str2)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VCons: {
    V v_fs_246 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_t_247 = heff_arrayToList(heff_take_field(v_fs_246, 0));
    V v_t_248 = heff_arrayToList(heff_get_n(v_fs_246, 2, 3));
    V v_t_249 = (g_heff_2eutil_2edict_2ezipKV(v_t_247, v_t_248));
    V v_x2_2410 = (g_list_2emap_24s1427000880x1925304966(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str3), v_t_249));
    V v_t_2413;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_xs_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str5); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str7)));
  }
  case TAG_VTag: {
    V v_x_2414 = heff_field(v_v_241, 0);
    V v_vs_2415 = heff_field(v_v_241, 1);
    V v_ru_24v_241_24VTag = heff_take_reuse_n(v_v_241, 3ULL, 2);
    HeffT2 v_t_2416 = (g_heff_2ecompile_2einterp_2elistValsGo_24cpr(heff_tag_at_n(v_ru_24v_241_24VTag, TAG_VTag, 2, (V[]){heff_dup(v_x_2414), heff_dup(v_vs_2415)}), NTAG(TAG_Nil)));
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        heff_drop(v_x_2414);
        heff_drop(v_vs_2415);
        V v_items_2420 = v_field_2418;
        V v_x2_2421 = (g_list_2emap_24s391931963x434308123(v_items_2420));
        V v_t_2424;
        switch (heff_tag_of(v_x2_2421)) {
        case TAG_Nil: {
          v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2422 = heff_field(v_x2_2421, 0);
          V v_xs_2423 = heff_field(v_x2_2421, 1);
          heff_take_n(v_x2_2421, 3ULL, 2);
          v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str9); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2421);
        }
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str10), heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str11)));
      } else {
        heff_drop(v_field_2418);
        switch (heff_tag_of(v_vs_2415)) {
        case TAG_Nil: {
          return v_x_2414;
        }
        case TAG_Cons: {
          if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
            V v_x2_2427 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str12), v_vs_2415));
            V v_t_2430;
            switch (heff_tag_of(v_x2_2427)) {
            case TAG_Nil: {
              v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str13);
              break;
            }
            case TAG_Cons: {
              V v_x_2428 = heff_field(v_x2_2427, 0);
              V v_xs_2429 = heff_field(v_x2_2427, 1);
              heff_take_n(v_x2_2427, 3ULL, 2);
              v_t_2430 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str14); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2427);
            }
            V v_t_2431 = heff_strAppend(v_x_2414, heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str15)));
            return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str16), v_t_2431);
          } else {
            V v_x2_2432 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str17), v_vs_2415));
            V v_t_2435;
            switch (heff_tag_of(v_x2_2432)) {
            case TAG_Nil: {
              v_t_2435 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str18);
              break;
            }
            case TAG_Cons: {
              V v_x_2433 = heff_field(v_x2_2432, 0);
              V v_xs_2434 = heff_field(v_x2_2432, 1);
              heff_take_n(v_x2_2432, 3ULL, 2);
              v_t_2435 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str19); V a_1 = v_x_2433; V a_2 = v_xs_2434; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2434); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2432);
            }
            return heff_strAppend(v_x_2414, v_t_2435);
          }
        }
        default: return heff_nomatch(v_vs_2415);
        }
      }
    }
  }
  case TAG_VInt: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2437 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2437, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str20))) {
        V v_t_2439 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str21), heff_strAppend(v_t_2439, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str22)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VFloat: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2441 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2441, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str23))) {
        V v_t_2443 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str24), heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str25)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VFloat32: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2445 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2445, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str26))) {
        V v_t_2447 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str27), heff_strAppend(v_t_2447, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str28)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VStr: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2449 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2449, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str29))) {
        V v_t_2451 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str30), heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str31)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VRune: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2453 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2453, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str32))) {
        V v_t_2455 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str33), heff_strAppend(v_t_2455, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str34)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VArr: {
    V v_xs_2456 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_x2_2457 = (g_list_2emap_24s391931963x434308123(heff_arrayToList(v_xs_2456)));
    V v_t_2460;
    switch (heff_tag_of(v_x2_2457)) {
    case TAG_Nil: {
      v_t_2460 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2458 = heff_field(v_x2_2457, 0);
      V v_xs_2459 = heff_field(v_x2_2457, 1);
      heff_take_n(v_x2_2457, 3ULL, 2);
      v_t_2460 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str36); V a_1 = v_x_2458; V a_2 = v_xs_2459; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2459); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2457);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str37), heff_strAppend(v_t_2460, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str38)));
  }
  case TAG_VBytes: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2462 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2462, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str39))) {
        V v_t_2464 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str40), heff_strAppend(v_t_2464, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str41)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VBits: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2467 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2467, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str42))) {
        V v_t_2469 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str43), heff_strAppend(v_t_2469, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str44)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
    }
  }
  case TAG_VErased: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2470 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2470, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str45))) {
        V v_t_2472 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str46), heff_strAppend(v_t_2472, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str47)));
      } else {
        return (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      }
    } else {
      return (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2eshowValGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_lam0, 1, 0};
Clo g_heff_2ecompile_2einterp_2eapplyErased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eapplyErased(V v_n_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_r_241)) {
  case TAG_RSucceeded: {
    V v_r1_242 = heff_dup(heff_field(v_r_241, 0));
    switch (heff_tag_of(v_r1_242)) {
    case TAG_VFun: {
      V v_f_243 = heff_field(v_r1_242, 0);
      V v_ru_24r1_242_24VFun = heff_take_reuse_n(v_r1_242, 1ULL, 1);
      heff_drop_tag(v_r_241, 1);
      if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
        heff_drop(v_n_240);
        return heff_tag_n(TAG_RSucceeded, 1, (V[]){heff_tag_at_n(v_ru_24r1_242_24VFun, TAG_VFun, 1, (V[]){v_f_243})});
      } else {
        heff_drop_cell(v_ru_24r1_242_24VFun, 1);
        V v_x1_246 = heff_tr(heff_call(v_f_243, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo)}));
        V v_t_249;
        switch (heff_tag_of(v_x1_246)) {
        case TAG_Ok: {
          V v_v_247 = heff_field(v_x1_246, 0);
          V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
          v_t_249 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_RSucceeded, 1, (V[]){v_v_247});
          break;
        }
        case TAG_Abn: {
          v_t_249 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          v_t_249 = NTAG(TAG_RDiverged);
          break;
        }
        case TAG_Bug: {
          V v_what_248 = heff_field(v_x1_246, 0);
          V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
          v_t_249 = heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_RBug, 1, (V[]){v_what_248});
          break;
        }
        default: heff_nomatch(v_x1_246);
        }
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_t_249;
        v_n_240 = t_0;
        v_r_241 = t_1;
        goto top;
      }
    }
    case TAG_VCons: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VTag: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VInt: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat: {
      heff_take_na(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat32: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VStr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VRune: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VArr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBytes: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBits: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VErased: {
      heff_drop(v_n_240);
      return v_r_241;
    }
    default: return heff_nomatch(v_r1_242);
    }
  }
  case TAG_RAbandoned: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RDiverged: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RBug: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  default: return heff_nomatch(v_r_241);
  }
}
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eapplyErased(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args) {
  V v_d_245 = args[0];
  heff_drop(v_d_245);
  return heff_tag_n(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
}
Clo g_heff_2ecompile_2einterp_2ereachGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ereachGlobals_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ereachGlobals(V v_gs_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_gs_240, 8);
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_seen_241, v_k_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_k_243);
        V v_x_249 = v_field_247;
        heff_drop(v_x_249);
        V t_0 = v_gs_240;
        V t_1 = v_seen_241;
        V t_2 = v_rest_244;
        v_gs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_2410 = (g_std_2emap_2einsert_24s93785294x875597928(v_seen_241, heff_dup(v_k_243), NTAG(TAG_MkUnit)));
        HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_gs_240, 1), v_k_243));
        V v_t_2428;
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            heff_drop(v_k_243);
            V v_e_2415 = v_field_2413;
            V v_t_2416 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_get_n(v_e_2415, 0, 4)));
            v_t_2428 = (g_heff_2eelab_2erename_2enubFirst(v_t_2416));
          } else {
            heff_drop(v_field_2413);
            HeffT2 v_t_2417 = ({ V a_0 = heff_rfield(v_gs_240, 2); V a_1 = v_k_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_k_243); r_; });
            {
              V v_field_2419 = v_t_2417.f[1];
              int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
              if ((v_tag_2418 == ((int64_t)0ULL))) {
                V v_k2_2421 = v_field_2419;
                HeffT2 v_t_2422 = ({ V a_0 = heff_rfield(v_gs_240, 1); V a_1 = v_k2_2421; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_k2_2421); r_; });
                {
                  V v_field_2424 = v_t_2422.f[1];
                  int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
                  if ((v_tag_2423 == ((int64_t)0ULL))) {
                    V v_entry_2426 = v_field_2424;
                    V v_t_2427 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_get_n(v_entry_2426, 0, 4)));
                    v_t_2428 = (g_heff_2eelab_2erename_2enubFirst(v_t_2427));
                  } else {
                    heff_drop(v_field_2424);
                    v_t_2428 = NTAG(TAG_Nil);
                  }
                }
              } else {
                heff_drop(v_field_2419);
                v_t_2428 = NTAG(TAG_Nil);
              }
            }
          }
        }
        V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2428, v_rest_244));
        V t_0 = v_gs_240;
        V t_1 = v_t_2410;
        V t_2 = v_t_2429;
        v_gs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2einterp_2ereachGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ereachGlobals(a[0], a[1], a[2]);
}