// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_Ok 9325
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_aliases 1464806715
#define LBL_entries 787768015
#define LBL_keys 9783995
#define LBL_syntax 1059664654
#define LBL_values 1123329101
V g_heff_2ecompile_2einterp_2eapplyErased(V, V);
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eapplyErased_clo;
V g_heff_2ecompile_2einterp_2ebits1(V);
V g_heff_2ecompile_2einterp_2ebits1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebits1_clo;
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void);
V g_heff_2ecompile_2einterp_2ebitsCopy(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsCopy_clo;
V g_heff_2ecompile_2einterp_2ebitsJoined(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsJoined_clo;
V g_heff_2ecompile_2einterp_2ebitsOfIntV(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsOfIntV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsOfIntV_clo;
V g_heff_2ecompile_2einterp_2ebyteString(V, V);
V g_heff_2ecompile_2einterp_2ebyteString_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebyteString_clo;
V g_heff_2ecompile_2einterp_2ebytes2(V);
V g_heff_2ecompile_2einterp_2ebytes2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytes2_clo;
V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get(void);
V g_heff_2ecompile_2einterp_2ebytesJoined(V, V);
V g_heff_2ecompile_2einterp_2ebytesJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesJoined_clo;
V g_heff_2ecompile_2einterp_2ebytesOfIntV(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfIntV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfIntV_clo;
V g_heff_2ecompile_2einterp_2ebytesOfNat(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfNat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfNat_clo;
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void);
V g_heff_2ecompile_2einterp_2efixedPrimV(V);
V g_heff_2ecompile_2einterp_2efixedPrimV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedPrimV_clo;
V g_heff_2ecompile_2einterp_2efloat2(V);
V g_heff_2ecompile_2einterp_2efloat2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloat2_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get(void);
V g_heff_2ecompile_2einterp_2efloatOfBitsV(V, V);
V g_heff_2ecompile_2einterp_2efloatOfBitsV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloatOfBitsV_clo;
V g_heff_2ecompile_2einterp_2efloatTake2(V, V, V);
V g_heff_2ecompile_2einterp_2efloatTake2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloatTake2_clo;
V g_heff_2ecompile_2einterp_2efmix64(V);
V g_heff_2ecompile_2einterp_2efmix64_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efmix64_clo;
V g_heff_2ecompile_2einterp_2efromListV(V, V);
V g_heff_2ecompile_2einterp_2efromListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efromListV_clo;
V g_heff_2ecompile_2einterp_2egenGo(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2egenGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2egenGo_clo;
V g_heff_2ecompile_2einterp_2ehashFrom(V, V, V);
V g_heff_2ecompile_2einterp_2ehashFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ehashFrom_clo;
V g_heff_2ecompile_2einterp_2eieeeBits_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeBits(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeBits_clo;
V g_heff_2ecompile_2einterp_2eieeeMagnitude_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeMagnitude(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeMagnitude_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeMagnitude_clo;
double g_heff_2ecompile_2einterp_2eieeeOf_w(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeOf_clo;
V g_heff_2ecompile_2einterp_2eint2(V);
V g_heff_2ecompile_2einterp_2eint2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eint2_clo;
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void);
V g_heff_2ecompile_2einterp_2eintAtV(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintAtV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintAtV_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_clo;
HeffT2 g_heff_2ecompile_2einterp_2elistValsGo_24cpr(V, V);
V g_heff_2ecompile_2einterp_2elittleOut(V, V);
V g_heff_2ecompile_2einterp_2elittleOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elittleOut_clo;
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotARune_get(void);
V g_heff_2ecompile_2einterp_2enotAString_get(void);
V g_heff_2ecompile_2einterp_2enotAnArray_get(void);
V g_heff_2ecompile_2einterp_2enotAnInt_get(void);
V g_heff_2ecompile_2einterp_2enotBytes_get(void);
HeffT2 g_heff_2ecompile_2einterp_2enthV_24cpr(V, V);
V g_heff_2ecompile_2einterp_2eprim(V);
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eprim_clo;
V g_heff_2ecompile_2einterp_2ereachGlobals(V, V, V);
V g_heff_2ecompile_2einterp_2ereachGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ereachGlobals_clo;
V g_heff_2ecompile_2einterp_2erune2(V);
V g_heff_2ecompile_2einterp_2erune2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2erune2_clo;
V g_heff_2ecompile_2einterp_2eruneCodes(V);
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_clo;
V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V, V);
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo;
V g_heff_2ecompile_2einterp_2escalarV(V);
V g_heff_2ecompile_2einterp_2escalarV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2escalarV_clo;
V g_heff_2ecompile_2einterp_2esetAt(V, V, V);
V g_heff_2ecompile_2einterp_2esetAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esetAt_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2einterp_2esliceV(V, V, V);
V g_heff_2ecompile_2einterp_2esliceV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esliceV_clo;
V g_heff_2ecompile_2einterp_2estr2(V);
V g_heff_2ecompile_2einterp_2estr2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2estr2_clo;
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get(void);
V g_heff_2ecompile_2einterp_2etoListV(V);
V g_heff_2ecompile_2einterp_2etoListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(V, V, V);
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(V);
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_clo;
V g_heff_2ecompile_2einterp_2etrieSlotOf(V, V, V);
V g_heff_2ecompile_2einterp_2etrieSlotOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etrieSlotOf_clo;
V g_heff_2ecompile_2einterp_2etwoTo(V);
V g_heff_2ecompile_2einterp_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoTo_clo;
V g_heff_2ecompile_2einterp_2eword64_get(void);
V g_heff_2ecompile_2einterp_2ewordOf(V, V, V);
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ewordOf_clo;
HeffT2 g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(V);
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2erename_2enubFirst(V);
V g_heff_2eelab_2erename_2enubFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2enubFirst_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1427000880x1925304966(V, V);
V g_list_2emap_24s1427000880x1925304966_entry(V self, V *a);
extern Clo g_list_2emap_24s1427000880x1925304966_clo;
V g_list_2emap_24s391931963x434308123(V);
V g_list_2emap_24s391931963x434308123_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_clo;
V g_list_2emap_24s503834852x510769098(V, V);
V g_list_2emap_24s503834852x510769098_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_rune_2evalidFrom(V, V);
V g_rune_2evalidFrom_entry(V self, V *a);
extern Clo g_rune_2evalidFrom_clo;
V g_runeFromInt_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAnInt_str0, 38, "a primitive given what is not an `Int`");

static V g_heff_2ecompile_2einterp_2enotAnInt_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAnInt_st;
static V g_heff_2ecompile_2einterp_2enotAnInt_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAnInt_str0)});
}
V g_heff_2ecompile_2einterp_2enotAnInt_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAnInt_st)) return g_heff_2ecompile_2einterp_2enotAnInt_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAnInt_val, &g_heff_2ecompile_2einterp_2enotAnInt_st, g_heff_2ecompile_2einterp_2enotAnInt_init);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAFloat64_str0, 41, "a primitive given what is not a `Float64`");

static V g_heff_2ecompile_2einterp_2enotAFloat64_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAFloat64_st;
static V g_heff_2ecompile_2einterp_2enotAFloat64_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAFloat64_str0)});
}
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAFloat64_st)) return g_heff_2ecompile_2einterp_2enotAFloat64_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAFloat64_val, &g_heff_2ecompile_2einterp_2enotAFloat64_st, g_heff_2ecompile_2einterp_2enotAFloat64_init);
}
Clo g_heff_2ecompile_2einterp_2efloatTake2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloatTake2_entry, 3, 0};

V g_heff_2ecompile_2einterp_2efloatTake2(V v_f_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_VFun: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VCons: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VTag: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VInt: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VFloat: {
    V v_a_248 = heff_tget_v(v_x2_241, 0);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_VFun: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      V v_b_2414 = heff_tget_v(v_x3_242, 0);
      return heff_tail(v_f_240, 2, (V[]){v_a_248, v_b_2414});
    }
    case TAG_VFloat32: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_VFloat32: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VStr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VRune: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VArr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VBytes: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VBits: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VErased: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2efloatTake2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2einterp_2efloatTake2(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2einterp_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ewordOf_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ewordOf(V v_n_240, V v_f_241, V v_v_242) {
top: ;
  if ((heff_unbox_word(heff_intMod(v_f_241, MK_INT(2LL))) == ((int64_t)1ULL))) {
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_245 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_246 = heff_intAdd(heff_intMod(v_v_242, v_t_244), v_t_245);
    V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    return (g_heff_2ecompile_2einterp_2elittleOut(heff_intMod(v_t_246, v_t_247), v_n_240));
  } else {
    V v_t_248 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_2410 = heff_intAdd(heff_intMod(v_v_242, v_t_248), v_t_249);
    V v_t_2411 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_240));
    return heff_intMod(v_t_2410, v_t_2411);
  }
}
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ewordOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsOfIntV_str0, 0, "");
Clo g_heff_2ecompile_2einterp_2ebitsOfIntV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsOfIntV_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ebitsOfIntV(V v_n_240, V v_f_241, V v_v_242) {
top: ;
  if (heff_intLt_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    heff_drop(v_f_241);
    heff_drop(v_v_242);
    return NTAG(TAG_Abn);
  } else {
    if (heff_intLt_c_lent(MK_INT(64LL), v_n_240, 1)) {
      heff_drop(v_n_240);
      heff_drop(v_f_241);
      heff_drop(v_v_242);
      return NTAG(TAG_Abn);
    } else {
      V v_w_245 = (g_heff_2ecompile_2einterp_2ewordOf(heff_dup(v_n_240), v_f_241, v_v_242));
      int64_t v_t_246 = ((heff_peek_word(v_n_240) + ((int64_t)7ULL)) / ((int64_t)8ULL));
      int64_t v_t_247 = ((heff_peek_word(v_n_240) + ((int64_t)7ULL)) / ((int64_t)8ULL));
      int64_t v_t_248 = ((v_t_247 * ((int64_t)8ULL)) - heff_peek_word(v_n_240));
      V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word(v_t_248)));
      V v_t_2410 = (g_heff_2ecompile_2einterp_2ebytesOfNat(heff_box_word(v_t_246), heff_intMul(v_w_245, v_t_249), ((V)&g_heff_2ecompile_2einterp_2ebitsOfIntV_str0)));
      return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_n_240, v_t_2410})});
    }
  }
}
V g_heff_2ecompile_2einterp_2ebitsOfIntV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitsOfIntV(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2eieeeBits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eieeeBits_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eieeeBits_w(V v_eb_240, V v_fb_241, double v_x_242) {
top: ;
  if ((v_x_242 == v_x_242)) {
    if ((v_x_242 < (0.0))) {
      V v_t_245 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_eb_240) + heff_peek_word(v_fb_241)))));
      V v_t_246 = (g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, ((0.0) - v_x_242)));
      return heff_intAdd(v_t_245, v_t_246);
    } else {
      if ((v_x_242 == (0.0))) {
        if ((((1.0) / v_x_242) < (0.0))) {
          V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_eb_240) + heff_peek_word(v_fb_241)))));
          V v_t_2410 = (g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, ((0.0) - v_x_242)));
          return heff_intAdd(v_t_249, v_t_2410);
        } else {
          HEFF_LAST return g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, v_x_242);
        }
      } else {
        HEFF_LAST return g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, v_x_242);
      }
    }
  } else {
    V v_t_2411 = (g_heff_2ecompile_2einterp_2etwoTo(v_eb_240));
    V v_t_2412 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_fb_241)));
    V v_t_2413 = heff_intMul(heff_intSub(v_t_2411, MK_INT(1LL)), v_t_2412);
    V v_t_2414 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_unbox_word(v_fb_241) - ((int64_t)1ULL)))));
    return heff_intAdd(v_t_2413, v_t_2414);
  }
}
V g_heff_2ecompile_2einterp_2eieeeBits(V v_eb_240, V v_fb_241, V v_box_24x_242) {
  double v_x_242 = heff_unbox_f64(v_box_24x_242);
  return (g_heff_2ecompile_2einterp_2eieeeBits_w(v_eb_240, v_fb_241, v_x_242));
}
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eieeeBits(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2efloatOfBitsV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloatOfBitsV_entry, 2, 0};

V g_heff_2ecompile_2einterp_2efloatOfBitsV(V v_n_240, V v_u_241) {
top: ;
  if (heff_intEq_c_lent(v_n_240, MK_INT(64LL), 2)) {
    heff_drop(v_n_240);
    V v_t_243 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    V v_t_245 = heff_intAdd(heff_intMod(v_u_241, v_t_243), v_t_244);
    V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    double v_t_247 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(11LL), MK_INT(52LL), heff_intMod(v_t_245, v_t_246)));
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_nf(TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_247)})});
  } else {
    if (heff_intEq_c(v_n_240, MK_INT(32LL))) {
      V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      V v_t_2410 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      V v_t_2411 = heff_intAdd(heff_intMod(v_u_241, v_t_249), v_t_2410);
      V v_t_2412 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      double v_t_2413 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(8LL), MK_INT(23LL), heff_intMod(v_t_2411, v_t_2412)));
      return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_nf(TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_2413)})});
    } else {
      heff_drop(v_u_241);
      return NTAG(TAG_Abn);
    }
  }
}
V g_heff_2ecompile_2einterp_2efloatOfBitsV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efloatOfBitsV(a[0], a[1]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eruneCodes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_VFun: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2411 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2411, heff_hole()});
      V v_u_2413 = (g_heff_2ecompile_2einterp_2eruneCodes_24dps(v_rest_242, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eruneCodes(a[0]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_VFun: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2412 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2412, heff_hole()});
      V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2413;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eruneCodes_24dps(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st;
static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st)) return g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val, &g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)(heff_unbox_f32(v_a_2414) / heff_unbox_f32(v_b_2421))))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st;
static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st)) return g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
  return heff_global(&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val, &g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init);
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = (g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(v_a_2412, v_b_2417));
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2418})});
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1, 2, 1, (V[]){v_a_241})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10, 36, "a primitive given what is not `Bits`");
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st;
static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st)) return g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val, &g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init);
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  V v_x1_242 = heff_tr(heff_call(v_a_241, 1, (V[]){v_d_240}));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Ok: {
    V v_v_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Ok = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_v_243)) {
    case TAG_VFun: {
      V v_ru_24v_243_24VFun = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFun, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0)});
    }
    case TAG_VCons: {
      V v_ru_24v_243_24VCons = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VCons, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1)});
    }
    case TAG_VTag: {
      heff_take_n(v_v_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2)});
    }
    case TAG_VInt: {
      V v_ru_24v_243_24VInt = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3)});
    }
    case TAG_VFloat: {
      V v_ru_24v_243_24VFloat = heff_take_reuse_na(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4)});
    }
    case TAG_VFloat32: {
      V v_ru_24v_243_24VFloat32 = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat32, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5)});
    }
    case TAG_VStr: {
      V v_ru_24v_243_24VStr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VStr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6)});
    }
    case TAG_VRune: {
      V v_ru_24v_243_24VRune = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VRune, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7)});
    }
    case TAG_VArr: {
      V v_ru_24v_243_24VArr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VArr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8)});
    }
    case TAG_VBytes: {
      V v_ru_24v_243_24VBytes = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VBytes, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9)});
    }
    case TAG_VBits: {
      V v_n_2415 = heff_field(v_v_243, 0);
      heff_take_n(v_v_243, 1ULL, 2);
      return heff_tag_at_n(v_ru_24x1_242_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_n_2415})});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10)});
    }
    default: return heff_nomatch(v_v_243);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2417 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Bug = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_242_24Bug, TAG_Bug, 1, (V[]){v_what_2417});
  }
  default: return heff_nomatch(v_x1_242);
  }
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str1, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str2, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str3, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str4, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str5, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str6, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str7, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str8, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str9, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str10, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str11, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str12, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str13, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str14, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str15, 9, "onWindows");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str16, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str17, 6, "intAnd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str18, 5, "intOr");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str19, 6, "intXor");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str20, 6, "intShl");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str21, 6, "intShr");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str22, 8, "floatAdd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str23, 8, "floatSub");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str24, 8, "floatMul");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str25, 8, "floatDiv");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str26, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str27, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str28, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str29, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str30, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str31, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str32, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str33, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str34, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str35, 9, "floatShow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str36, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str37, 9, "floatSqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str38, 10, "floatFloor");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str39, 8, "floatSin");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str40, 8, "floatCos");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str41, 8, "floatTan");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str42, 9, "floatAsin");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str43, 9, "floatAcos");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str44, 9, "floatAtan");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str45, 10, "floatAtan2");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str46, 8, "floatExp");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str47, 8, "floatLog");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str48, 8, "floatPow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str49, 11, "arrayLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str50, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str51, 32, "an index in range, of no element");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str52, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str53, 13, "arrayGenerate");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str54, 13, "arrayFromList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str55, 11, "arrayToList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str56, 14, "arrayReplicate");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str57, 10, "arraySlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str58, 11, "arrayAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str59, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str60, 9, "strLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str61, 8, "strSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str62, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str63, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str64, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str65, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str66, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str67, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str68, 10, "strCompare");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str69, 7, "strHash");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str70, 7, "intHash");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str71, 8, "trieSlot");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str72, 7, "strFind");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str73, 9, "strByteAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str74, 11, "strFromByte");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str75, 9, "strRuneAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str76, 12, "strRuneWidth");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str77, 12, "strRuneCount");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str78, 7, "strToJS");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str79, 9, "strFromJS");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str80, 11, "bytesLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str81, 7, "bytesAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str82, 10, "bytesSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str83, 11, "bytesAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str84, 11, "bytesConcat");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str85, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str86, 7, "bytesEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str87, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str88, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str89, 13, "bytesFromList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str90, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str91, 11, "bytesToList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str92, 15, "bytesFromString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str93, 13, "bytesAsString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str94, 13, "bytesToString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str95, 10, "bytesIntAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str96, 10, "bytesOfInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str97, 10, "bytesHasAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str98, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str99, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str100, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str101, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str102, 10, "bitsLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str103, 9, "bitsIntAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str104, 9, "bitsOfInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str105, 10, "bitsConcat");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str106, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str107, 9, "bitsSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str108, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str109, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str110, 9, "bitsBytes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str111, 6, "bitsEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str112, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str113, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str114, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str115, 9, "floatBits");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str116, 11, "floatOfBits");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str117, 6, "runeEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str118, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str119, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str120, 6, "runeLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str121, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str122, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str123, 6, "runeLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str124, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str125, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str126, 9, "runeToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str127, 4, "keep");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str128, 11, "runeFromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str129, 8, "strRunes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str130, 10, "strOfRunes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str131, 13, "no primitive ");
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam0, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam1, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam2, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam3, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam4, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam5, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam6, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam7, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam8, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam9, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam10, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam11, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam12, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam13, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam14, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam15, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam16, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam17, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam18, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam19, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam20, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam21, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam22, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam23, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam24, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam25, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam27, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam26, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam29, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam28, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam32, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam31, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam38, 1, 0};
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam36, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam35, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam40, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam39, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam42, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam41, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam44_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam44, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam43, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam47, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam46, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam51, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam50_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam50, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam53_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam53, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam54_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam54, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam57_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam57, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam58_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam58, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam59_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam59, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam60_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam60, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam61_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam61, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam62_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam62, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam65_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam65, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam67_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam67, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam69_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam69, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam70_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam70, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam72_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam72, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam74_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam74, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam75_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam75, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam76_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam76, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam77_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam77, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam78_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam78, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam80_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam80, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam83_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam83, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam84_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam84, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam85_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam85, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam86_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam86, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam87_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam87, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam88_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam88, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam89_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam89, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam90_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam90, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam94_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam94, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam97_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam97, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam100_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam100, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam104_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam104, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam107_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam107, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam110(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam108_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam108, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam111(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam111_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam111, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam112(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam112_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam112, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam114(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam113(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam113_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam113, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam116(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam115(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam115_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam115, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam118(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam117(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam117_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam117, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam119(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam119, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam120(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam120_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam120, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam121(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam121_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam121, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam122(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam122_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam122, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam124(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam124, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam123(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam123, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam125(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam125_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam125, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam126(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam126_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam126, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam127(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam127_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam127, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam128(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eprim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eprim(V v_p_240) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str0), 2)) {
    heff_drop(v_p_240);
    return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get());
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str1), 2)) {
      heff_drop(v_p_240);
      return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get());
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str2), 2)) {
        heff_drop(v_p_240);
        return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get());
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str3), 2)) {
          heff_drop(v_p_240);
          HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam0_clo));
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str4), 2)) {
            heff_drop(v_p_240);
            HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam1_clo));
          } else {
            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str5), 2)) {
              heff_drop(v_p_240);
              HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam2_clo));
            } else {
              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str8), 2)) {
                heff_drop(v_p_240);
                HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam3_clo));
              } else {
                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str11), 2)) {
                  heff_drop(v_p_240);
                  HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam4_clo));
                } else {
                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str14), 2)) {
                    heff_drop(v_p_240);
                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam5_clo)});
                  } else {
                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str15), 2)) {
                      heff_drop(v_p_240);
                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam6_clo)});
                    } else {
                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str17), 2)) {
                        heff_drop(v_p_240);
                        return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get());
                      } else {
                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str18), 2)) {
                          heff_drop(v_p_240);
                          HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam7_clo));
                        } else {
                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str19), 2)) {
                            heff_drop(v_p_240);
                            HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam8_clo));
                          } else {
                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str20), 2)) {
                              heff_drop(v_p_240);
                              HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam9_clo));
                            } else {
                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str21), 2)) {
                                heff_drop(v_p_240);
                                HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam10_clo));
                              } else {
                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str22), 2)) {
                                  heff_drop(v_p_240);
                                  return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get());
                                } else {
                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str23), 2)) {
                                    heff_drop(v_p_240);
                                    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get());
                                  } else {
                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str24), 2)) {
                                      heff_drop(v_p_240);
                                      return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get());
                                    } else {
                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str25), 2)) {
                                        heff_drop(v_p_240);
                                        return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get());
                                      } else {
                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str26), 2)) {
                                          heff_drop(v_p_240);
                                          HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam11_clo));
                                        } else {
                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str29), 2)) {
                                            heff_drop(v_p_240);
                                            HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam12_clo));
                                          } else {
                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str32), 2)) {
                                              heff_drop(v_p_240);
                                              HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam13_clo));
                                            } else {
                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str35), 2)) {
                                                heff_drop(v_p_240);
                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam14_clo)});
                                              } else {
                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str36), 2)) {
                                                  heff_drop(v_p_240);
                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam15_clo)});
                                                } else {
                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str37), 2)) {
                                                    heff_drop(v_p_240);
                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam16_clo)});
                                                  } else {
                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str38), 2)) {
                                                      heff_drop(v_p_240);
                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam17_clo)});
                                                    } else {
                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str39), 2)) {
                                                        heff_drop(v_p_240);
                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam18_clo)});
                                                      } else {
                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str40), 2)) {
                                                          heff_drop(v_p_240);
                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam19_clo)});
                                                        } else {
                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str41), 2)) {
                                                            heff_drop(v_p_240);
                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam20_clo)});
                                                          } else {
                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str42), 2)) {
                                                              heff_drop(v_p_240);
                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam21_clo)});
                                                            } else {
                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str43), 2)) {
                                                                heff_drop(v_p_240);
                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam22_clo)});
                                                              } else {
                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str44), 2)) {
                                                                  heff_drop(v_p_240);
                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam23_clo)});
                                                                } else {
                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str45), 2)) {
                                                                    heff_drop(v_p_240);
                                                                    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get());
                                                                  } else {
                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str46), 2)) {
                                                                      heff_drop(v_p_240);
                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam24_clo)});
                                                                    } else {
                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str47), 2)) {
                                                                        heff_drop(v_p_240);
                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam25_clo)});
                                                                      } else {
                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str48), 2)) {
                                                                          heff_drop(v_p_240);
                                                                          return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get());
                                                                        } else {
                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str49), 2)) {
                                                                            heff_drop(v_p_240);
                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam26_clo)});
                                                                          } else {
                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str50), 2)) {
                                                                              heff_drop(v_p_240);
                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam28_clo)});
                                                                            } else {
                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str52), 2)) {
                                                                                heff_drop(v_p_240);
                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam31_clo)});
                                                                              } else {
                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str53), 2)) {
                                                                                  heff_drop(v_p_240);
                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam35_clo)});
                                                                                } else {
                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str54), 2)) {
                                                                                    heff_drop(v_p_240);
                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam39_clo)});
                                                                                  } else {
                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str55), 2)) {
                                                                                      heff_drop(v_p_240);
                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam41_clo)});
                                                                                    } else {
                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str56), 2)) {
                                                                                        heff_drop(v_p_240);
                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam43_clo)});
                                                                                      } else {
                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str57), 2)) {
                                                                                          heff_drop(v_p_240);
                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam46_clo)});
                                                                                        } else {
                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str58), 2)) {
                                                                                            heff_drop(v_p_240);
                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam50_clo)});
                                                                                          } else {
                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str59), 2)) {
                                                                                              heff_drop(v_p_240);
                                                                                              return heff_dup(g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get());
                                                                                            } else {
                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str60), 2)) {
                                                                                                heff_drop(v_p_240);
                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam53_clo)});
                                                                                              } else {
                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str61), 2)) {
                                                                                                  heff_drop(v_p_240);
                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam54_clo)});
                                                                                                } else {
                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str62), 2)) {
                                                                                                    heff_drop(v_p_240);
                                                                                                    HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam57_clo));
                                                                                                  } else {
                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str65), 2)) {
                                                                                                      heff_drop(v_p_240);
                                                                                                      HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam58_clo));
                                                                                                    } else {
                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str68), 2)) {
                                                                                                        heff_drop(v_p_240);
                                                                                                        HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam59_clo));
                                                                                                      } else {
                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str69), 2)) {
                                                                                                          heff_drop(v_p_240);
                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam60_clo)});
                                                                                                        } else {
                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str70), 2)) {
                                                                                                            heff_drop(v_p_240);
                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam61_clo)});
                                                                                                          } else {
                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str71), 2)) {
                                                                                                              heff_drop(v_p_240);
                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam62_clo)});
                                                                                                            } else {
                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str72), 2)) {
                                                                                                                heff_drop(v_p_240);
                                                                                                                HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam65_clo));
                                                                                                              } else {
                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str73), 2)) {
                                                                                                                  heff_drop(v_p_240);
                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam67_clo)});
                                                                                                                } else {
                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str74), 2)) {
                                                                                                                    heff_drop(v_p_240);
                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam69_clo)});
                                                                                                                  } else {
                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str75), 2)) {
                                                                                                                      heff_drop(v_p_240);
                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam70_clo)});
                                                                                                                    } else {
                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str76), 2)) {
                                                                                                                        heff_drop(v_p_240);
                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam72_clo)});
                                                                                                                      } else {
                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str77), 2)) {
                                                                                                                          heff_drop(v_p_240);
                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam74_clo)});
                                                                                                                        } else {
                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str78), 2)) {
                                                                                                                            heff_drop(v_p_240);
                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam75_clo)});
                                                                                                                          } else {
                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str79), 2)) {
                                                                                                                              heff_drop(v_p_240);
                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam76_clo)});
                                                                                                                            } else {
                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str80), 2)) {
                                                                                                                                heff_drop(v_p_240);
                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam77_clo)});
                                                                                                                              } else {
                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str81), 2)) {
                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam78_clo)});
                                                                                                                                } else {
                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str82), 2)) {
                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam80_clo)});
                                                                                                                                  } else {
                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str83), 2)) {
                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                      return heff_dup(g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get());
                                                                                                                                    } else {
                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str84), 2)) {
                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam83_clo)});
                                                                                                                                      } else {
                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str86), 2)) {
                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                          HEFF_LAST return g_heff_2ecompile_2einterp_2ebytes2(((V)&g_heff_2ecompile_2einterp_2eprim_lam84_clo));
                                                                                                                                        } else {
                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str89), 2)) {
                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam85_clo)});
                                                                                                                                          } else {
                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str91), 2)) {
                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam86_clo)});
                                                                                                                                            } else {
                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str92), 2)) {
                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam87_clo)});
                                                                                                                                              } else {
                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str93), 2)) {
                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam88_clo)});
                                                                                                                                                } else {
                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str94), 2)) {
                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam89_clo)});
                                                                                                                                                  } else {
                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str95), 2)) {
                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam90_clo)});
                                                                                                                                                    } else {
                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str96), 2)) {
                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam94_clo)});
                                                                                                                                                      } else {
                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str97), 2)) {
                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam97_clo)});
                                                                                                                                                        } else {
                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str102), 2)) {
                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                            return heff_dup(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get());
                                                                                                                                                          } else {
                                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str103), 2)) {
                                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                                              HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam100_clo));
                                                                                                                                                            } else {
                                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str104), 2)) {
                                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam104_clo)});
                                                                                                                                                              } else {
                                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str105), 2)) {
                                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam107_clo)});
                                                                                                                                                                } else {
                                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str107), 2)) {
                                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                                    HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam108_clo));
                                                                                                                                                                  } else {
                                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str109), 2)) {
                                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam111_clo)});
                                                                                                                                                                    } else {
                                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str110), 2)) {
                                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                                        HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam112_clo));
                                                                                                                                                                      } else {
                                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str111), 2)) {
                                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                                          HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam113_clo));
                                                                                                                                                                        } else {
                                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str115), 2)) {
                                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam115_clo)});
                                                                                                                                                                          } else {
                                                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str116), 2)) {
                                                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam117_clo)});
                                                                                                                                                                            } else {
                                                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str117), 2)) {
                                                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                                                HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam119_clo));
                                                                                                                                                                              } else {
                                                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str120), 2)) {
                                                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                                                  HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam120_clo));
                                                                                                                                                                                } else {
                                                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str123), 2)) {
                                                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                                                    HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam121_clo));
                                                                                                                                                                                  } else {
                                                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str126), 2)) {
                                                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam122_clo)});
                                                                                                                                                                                    } else {
                                                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str127), 2)) {
                                                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam123_clo)});
                                                                                                                                                                                      } else {
                                                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str128), 2)) {
                                                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam125_clo)});
                                                                                                                                                                                        } else {
                                                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str129), 2)) {
                                                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam126_clo)});
                                                                                                                                                                                          } else {
                                                                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str130), 2)) {
                                                                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam127_clo)});
                                                                                                                                                                                            } else {
                                                                                                                                                                                              HeffT2 v_t_241847 = (g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(v_p_240));
                                                                                                                                                                                              {
                                                                                                                                                                                                V v_field_241849 = v_t_241847.f[1];
                                                                                                                                                                                                int64_t v_tag_241848 = ((int64_t)v_t_241847.f[0]);
                                                                                                                                                                                                if ((v_tag_241848 == ((int64_t)0ULL))) {
                                                                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                                                                  V v_fp_241851 = v_field_241849;
                                                                                                                                                                                                  HEFF_LAST return g_heff_2ecompile_2einterp_2efixedPrimV(v_fp_241851);
                                                                                                                                                                                                } else {
                                                                                                                                                                                                  heff_drop(v_field_241849);
                                                                                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam128, 2, 1, (V[]){v_p_240})});
                                                                                                                                                                                                }
                                                                                                                                                                                              }
                                                                                                                                                                                            }
                                                                                                                                                                                          }
                                                                                                                                                                                        }
                                                                                                                                                                                      }
                                                                                                                                                                                    }
                                                                                                                                                                                  }
                                                                                                                                                                                }
                                                                                                                                                                              }
                                                                                                                                                                            }
                                                                                                                                                                          }
                                                                                                                                                                        }
                                                                                                                                                                      }
                                                                                                                                                                    }
                                                                                                                                                                  }
                                                                                                                                                                }
                                                                                                                                                              }
                                                                                                                                                            }
                                                                                                                                                          }
                                                                                                                                                        }
                                                                                                                                                      }
                                                                                                                                                    }
                                                                                                                                                  }
                                                                                                                                                }
                                                                                                                                              }
                                                                                                                                            }
                                                                                                                                          }
                                                                                                                                        }
                                                                                                                                      }
                                                                                                                                    }
                                                                                                                                  }
                                                                                                                                }
                                                                                                                              }
                                                                                                                            }
                                                                                                                          }
                                                                                                                        }
                                                                                                                      }
                                                                                                                    }
                                                                                                                  }
                                                                                                                }
                                                                                                              }
                                                                                                            }
                                                                                                          }
                                                                                                        }
                                                                                                      }
                                                                                                    }
                                                                                                  }
                                                                                                }
                                                                                              }
                                                                                            }
                                                                                          }
                                                                                        }
                                                                                      }
                                                                                    }
                                                                                  }
                                                                                }
                                                                              }
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eprim(a[0]);
}
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_b_246 = args[1];
  if (heff_intEq_c_lent(v_b_246, MK_INT(0LL), 2)) {
    heff_drop(v_a_245);
    heff_drop(v_b_246);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){MK_INT(0LL)})});
  } else {
    V v_t_248 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_245, v_b_246)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_248});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args) {
  V v_a_2410 = args[0];
  V v_b_2411 = args[1];
  if (heff_intEq_c_lent(v_b_2411, MK_INT(0LL), 2)) {
    heff_drop(v_b_2411);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_2410})});
  } else {
    V v_t_2413 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMod(v_a_2410, v_b_2411)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2413});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args) {
  V v_a_2415 = args[0];
  V v_b_2416 = args[1];
  V v_t_2418;
  if (heff_intEq_c(v_a_2415, v_b_2416)) {
    v_t_2418 = ((V)&g_heff_2ecompile_2einterp_2eprim_str6);
  } else {
    v_t_2418 = ((V)&g_heff_2ecompile_2einterp_2eprim_str7);
  }
  V v_t_2419 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2419});
}
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args) {
  V v_a_2421 = args[0];
  V v_b_2422 = args[1];
  V v_t_2424;
  if (heff_intLt_c(v_a_2421, v_b_2422)) {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2eprim_str9);
  } else {
    v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2eprim_str10);
  }
  V v_t_2425 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2425});
}
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args) {
  V v_a_2427 = args[0];
  V v_b_2428 = args[1];
  V v_t_2430;
  if (heff_intLe_c(v_a_2427, v_b_2428)) {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2eprim_str12);
  } else {
    v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2eprim_str13);
  }
  V v_t_2431 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2431});
}
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args) {
  V v_d_2433 = args[0];
  V v_a_2434 = args[1];
  V v_x1_2435 = heff_tr(heff_call(v_a_2434, 1, (V[]){v_d_2433}));
  switch (heff_tag_of(v_x1_2435)) {
  case TAG_Ok: {
    V v_v_2436 = heff_field(v_x1_2435, 0);
    V v_ru_24x1_2435_24Ok = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
    switch (heff_tag_of(v_v_2436)) {
    case TAG_VFun: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2436, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_2441 = heff_field(v_v_2436, 0);
      V v_ru_24v_2436_24VInt = heff_take_reuse_n(v_v_2436, 1ULL, 1);
      V v_t_2442 = heff_tag_at_n(v_ru_24v_2436_24VInt, TAG_VStr, 1, (V[]){heff_intShow(v_a_2441)});
      return heff_tag_at_n(v_ru_24x1_2435_24Ok, TAG_Ok, 1, (V[]){v_t_2442});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2436, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2436, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2435_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_2436);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2451 = heff_field(v_x1_2435, 0);
    V v_ru_24x1_2435_24Bug = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2435_24Bug, TAG_Bug, 1, (V[]){v_what_2451});
  }
  default: return heff_nomatch(v_x1_2435);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args) {
  V v_d_2453 = args[0];
  V v_a_2454 = args[1];
  heff_drop(v_d_2453);
  heff_drop(v_a_2454);
  V v_t_2455 = heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str16), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2455});
}
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args) {
  V v_a_2458 = args[0];
  V v_b_2459 = args[1];
  V v_t_2460 = (g_heff_2ecompile_2einterp_2eintBits_24s1937409415x1404595683(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), v_a_2458, v_b_2459));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2460})});
}
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args) {
  V v_a_2462 = args[0];
  V v_b_2463 = args[1];
  V v_t_2464 = (g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(MK_INT(2LL), v_a_2462, v_b_2463));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2464})});
}
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args) {
  V v_a_2466 = args[0];
  V v_b_2467 = args[1];
  if (heff_intLt_c_lent(v_b_2467, MK_INT(0LL), 2)) {
    V v_k_2469 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2467)));
    V v_t_2470 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2466, v_k_2469)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2470});
  } else {
    V v_k_2471 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2467));
    V v_t_2472 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2466, v_k_2471)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2472});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args) {
  V v_a_2474 = args[0];
  V v_b_2475 = args[1];
  if (heff_intLt_c_lent(v_b_2475, MK_INT(0LL), 2)) {
    V v_k_2477 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2475)));
    V v_t_2478 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2474, v_k_2477)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2478});
  } else {
    V v_k_2479 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2475));
    V v_t_2480 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2474, v_k_2479)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2480});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args) {
  V v_box_24a_2486 = args[0];
  V v_box_24b_2487 = args[1];
  double v_a_2486 = heff_unbox_f64(v_box_24a_2486);
  double v_b_2487 = heff_unbox_f64(v_box_24b_2487);
  V v_t_2489;
  if ((v_a_2486 == v_b_2487)) {
    v_t_2489 = ((V)&g_heff_2ecompile_2einterp_2eprim_str27);
  } else {
    v_t_2489 = ((V)&g_heff_2ecompile_2einterp_2eprim_str28);
  }
  V v_t_2490 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2489, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2490});
}
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args) {
  V v_box_24a_2492 = args[0];
  V v_box_24b_2493 = args[1];
  double v_a_2492 = heff_unbox_f64(v_box_24a_2492);
  double v_b_2493 = heff_unbox_f64(v_box_24b_2493);
  V v_t_2495;
  if ((v_a_2492 < v_b_2493)) {
    v_t_2495 = ((V)&g_heff_2ecompile_2einterp_2eprim_str30);
  } else {
    v_t_2495 = ((V)&g_heff_2ecompile_2einterp_2eprim_str31);
  }
  V v_t_2496 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2495, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2496});
}
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args) {
  V v_box_24a_2498 = args[0];
  V v_box_24b_2499 = args[1];
  double v_a_2498 = heff_unbox_f64(v_box_24a_2498);
  double v_b_2499 = heff_unbox_f64(v_box_24b_2499);
  V v_t_24101;
  if ((v_a_2498 <= v_b_2499)) {
    v_t_24101 = ((V)&g_heff_2ecompile_2einterp_2eprim_str33);
  } else {
    v_t_24101 = ((V)&g_heff_2ecompile_2einterp_2eprim_str34);
  }
  V v_t_24102 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24101, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24102});
}
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args) {
  V v_d_24104 = args[0];
  V v_a_24105 = args[1];
  V v_x1_24106 = heff_tr(heff_call(v_a_24105, 1, (V[]){v_d_24104}));
  switch (heff_tag_of(v_x1_24106)) {
  case TAG_Ok: {
    V v_v_24107 = heff_field(v_x1_24106, 0);
    V v_ru_24x1_24106_24Ok = heff_take_reuse_n(v_x1_24106, 1ULL, 1);
    switch (heff_tag_of(v_v_24107)) {
    case TAG_VFun: {
      heff_take_n(v_v_24107, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24107, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24107, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24107, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      V v_a_24113 = heff_tget_v(v_v_24107, 0);
      V v_ru_24v_24107_24VFloat = heff_take_reuse_na(v_v_24107, 0ULL, 1);
      V v_t_24114 = heff_tag_at_n(v_ru_24v_24107_24VFloat, TAG_VStr, 1, (V[]){heff_floatShow(v_a_24113)});
      return heff_tag_at_n(v_ru_24x1_24106_24Ok, TAG_Ok, 1, (V[]){v_t_24114});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24107, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24107, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24107, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24107, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24107, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24107, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24106_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24107);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24122 = heff_field(v_x1_24106, 0);
    V v_ru_24x1_24106_24Bug = heff_take_reuse_n(v_x1_24106, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24106_24Bug, TAG_Bug, 1, (V[]){v_what_24122});
  }
  default: return heff_nomatch(v_x1_24106);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args) {
  V v_d_24124 = args[0];
  V v_a_24125 = args[1];
  V v_x1_24126 = heff_tr(heff_call(v_a_24125, 1, (V[]){v_d_24124}));
  switch (heff_tag_of(v_x1_24126)) {
  case TAG_Ok: {
    V v_v_24127 = heff_field(v_x1_24126, 0);
    V v_ru_24x1_24126_24Ok = heff_take_reuse_n(v_x1_24126, 1ULL, 1);
    switch (heff_tag_of(v_v_24127)) {
    case TAG_VFun: {
      heff_take_n(v_v_24127, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24127, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24127, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24132 = heff_field(v_v_24127, 0);
      V v_ru_24v_24127_24VInt = heff_take_reuse_n(v_v_24127, 1ULL, 1);
      V v_t_24133 = heff_tag_at_nf(v_ru_24v_24127_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(heff_from_int_f64(v_a_24132))});
      return heff_tag_at_n(v_ru_24x1_24126_24Ok, TAG_Ok, 1, (V[]){v_t_24133});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24127, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24127, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24127, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24127, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24127, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24127, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24127, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24126_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24127);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24142 = heff_field(v_x1_24126, 0);
    V v_ru_24x1_24126_24Bug = heff_take_reuse_n(v_x1_24126, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24126_24Bug, TAG_Bug, 1, (V[]){v_what_24142});
  }
  default: return heff_nomatch(v_x1_24126);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args) {
  V v_d_24144 = args[0];
  V v_a_24145 = args[1];
  V v_x1_24146 = heff_tr(heff_call(v_a_24145, 1, (V[]){v_d_24144}));
  switch (heff_tag_of(v_x1_24146)) {
  case TAG_Ok: {
    V v_v_24147 = heff_field(v_x1_24146, 0);
    V v_ru_24x1_24146_24Ok = heff_take_reuse_n(v_x1_24146, 1ULL, 1);
    switch (heff_tag_of(v_v_24147)) {
    case TAG_VFun: {
      heff_take_n(v_v_24147, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24147, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24147, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24147, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24153 = heff_tflat_f64(v_v_24147, 0);
      V v_ru_24v_24147_24VFloat = heff_take_reuse_na(v_v_24147, 0ULL, 1);
      V v_t_24154 = heff_tag_at_nf(v_ru_24v_24147_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(sqrt(v_a_24153))});
      return heff_tag_at_n(v_ru_24x1_24146_24Ok, TAG_Ok, 1, (V[]){v_t_24154});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24147, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24147, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24147, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24147, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24147, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24147, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24146_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24147);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24162 = heff_field(v_x1_24146, 0);
    V v_ru_24x1_24146_24Bug = heff_take_reuse_n(v_x1_24146, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24146_24Bug, TAG_Bug, 1, (V[]){v_what_24162});
  }
  default: return heff_nomatch(v_x1_24146);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args) {
  V v_d_24164 = args[0];
  V v_a_24165 = args[1];
  V v_x1_24166 = heff_tr(heff_call(v_a_24165, 1, (V[]){v_d_24164}));
  switch (heff_tag_of(v_x1_24166)) {
  case TAG_Ok: {
    V v_v_24167 = heff_field(v_x1_24166, 0);
    V v_ru_24x1_24166_24Ok = heff_take_reuse_n(v_x1_24166, 1ULL, 1);
    switch (heff_tag_of(v_v_24167)) {
    case TAG_VFun: {
      heff_take_n(v_v_24167, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24166_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24167, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24166_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24167, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24166_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24167, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24166_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24173 = heff_tflat_f64(v_v_24167, 0);
      V v_ru_24v_24167_24VFloat = heff_take_reuse_na(v_v_24167, 0ULL, 1);
      if (((v_a_24173 - v_a_24173) == (0.0))) {
        V v_t_24175 = heff_tag_at_n(v_ru_24v_24167_24VFloat, TAG_VInt, 1, (V[]){heff_floor_f64(v_a_24173)});
        return heff_tag_at_n(v_ru_24x1_24166_24Ok, TAG_Ok, 1, (V[]){v_t_24175});
      } else {
        heff_drop_cell(v_ru_24v_24167_24VFloat, 1);
        return heff_tag_at_n(v_ru_24x1_24166_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){MK_INT(0LL)})});
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24167, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24166_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24167, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24166_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24167, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24166_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24167, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24166_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24167, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24166_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24167, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24166_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24166_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24167);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24183 = heff_field(v_x1_24166, 0);
    V v_ru_24x1_24166_24Bug = heff_take_reuse_n(v_x1_24166, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24166_24Bug, TAG_Bug, 1, (V[]){v_what_24183});
  }
  default: return heff_nomatch(v_x1_24166);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args) {
  V v_d_24185 = args[0];
  V v_a_24186 = args[1];
  V v_x1_24187 = heff_tr(heff_call(v_a_24186, 1, (V[]){v_d_24185}));
  switch (heff_tag_of(v_x1_24187)) {
  case TAG_Ok: {
    V v_v_24188 = heff_field(v_x1_24187, 0);
    V v_ru_24x1_24187_24Ok = heff_take_reuse_n(v_x1_24187, 1ULL, 1);
    switch (heff_tag_of(v_v_24188)) {
    case TAG_VFun: {
      heff_take_n(v_v_24188, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24187_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24188, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24187_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24188, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24187_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24188, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24187_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24194 = heff_tflat_f64(v_v_24188, 0);
      V v_ru_24v_24188_24VFloat = heff_take_reuse_na(v_v_24188, 0ULL, 1);
      V v_t_24195 = heff_tag_at_nf(v_ru_24v_24188_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(sin(v_a_24194))});
      return heff_tag_at_n(v_ru_24x1_24187_24Ok, TAG_Ok, 1, (V[]){v_t_24195});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24188, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24187_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24188, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24187_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24188, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24187_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24188, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24187_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24188, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24187_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24188, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24187_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24187_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24188);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24203 = heff_field(v_x1_24187, 0);
    V v_ru_24x1_24187_24Bug = heff_take_reuse_n(v_x1_24187, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24187_24Bug, TAG_Bug, 1, (V[]){v_what_24203});
  }
  default: return heff_nomatch(v_x1_24187);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args) {
  V v_d_24205 = args[0];
  V v_a_24206 = args[1];
  V v_x1_24207 = heff_tr(heff_call(v_a_24206, 1, (V[]){v_d_24205}));
  switch (heff_tag_of(v_x1_24207)) {
  case TAG_Ok: {
    V v_v_24208 = heff_field(v_x1_24207, 0);
    V v_ru_24x1_24207_24Ok = heff_take_reuse_n(v_x1_24207, 1ULL, 1);
    switch (heff_tag_of(v_v_24208)) {
    case TAG_VFun: {
      heff_take_n(v_v_24208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24208, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24214 = heff_tflat_f64(v_v_24208, 0);
      V v_ru_24v_24208_24VFloat = heff_take_reuse_na(v_v_24208, 0ULL, 1);
      V v_t_24215 = heff_tag_at_nf(v_ru_24v_24208_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(cos(v_a_24214))});
      return heff_tag_at_n(v_ru_24x1_24207_24Ok, TAG_Ok, 1, (V[]){v_t_24215});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24208, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24208);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24223 = heff_field(v_x1_24207, 0);
    V v_ru_24x1_24207_24Bug = heff_take_reuse_n(v_x1_24207, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24207_24Bug, TAG_Bug, 1, (V[]){v_what_24223});
  }
  default: return heff_nomatch(v_x1_24207);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args) {
  V v_d_24225 = args[0];
  V v_a_24226 = args[1];
  V v_x1_24227 = heff_tr(heff_call(v_a_24226, 1, (V[]){v_d_24225}));
  switch (heff_tag_of(v_x1_24227)) {
  case TAG_Ok: {
    V v_v_24228 = heff_field(v_x1_24227, 0);
    V v_ru_24x1_24227_24Ok = heff_take_reuse_n(v_x1_24227, 1ULL, 1);
    switch (heff_tag_of(v_v_24228)) {
    case TAG_VFun: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24228, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24234 = heff_tflat_f64(v_v_24228, 0);
      V v_ru_24v_24228_24VFloat = heff_take_reuse_na(v_v_24228, 0ULL, 1);
      V v_t_24235 = heff_tag_at_nf(v_ru_24v_24228_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(tan(v_a_24234))});
      return heff_tag_at_n(v_ru_24x1_24227_24Ok, TAG_Ok, 1, (V[]){v_t_24235});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24228, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24228);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24243 = heff_field(v_x1_24227, 0);
    V v_ru_24x1_24227_24Bug = heff_take_reuse_n(v_x1_24227, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24227_24Bug, TAG_Bug, 1, (V[]){v_what_24243});
  }
  default: return heff_nomatch(v_x1_24227);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args) {
  V v_d_24245 = args[0];
  V v_a_24246 = args[1];
  V v_x1_24247 = heff_tr(heff_call(v_a_24246, 1, (V[]){v_d_24245}));
  switch (heff_tag_of(v_x1_24247)) {
  case TAG_Ok: {
    V v_v_24248 = heff_field(v_x1_24247, 0);
    V v_ru_24x1_24247_24Ok = heff_take_reuse_n(v_x1_24247, 1ULL, 1);
    switch (heff_tag_of(v_v_24248)) {
    case TAG_VFun: {
      heff_take_n(v_v_24248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24248, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24254 = heff_tflat_f64(v_v_24248, 0);
      V v_ru_24v_24248_24VFloat = heff_take_reuse_na(v_v_24248, 0ULL, 1);
      V v_t_24255 = heff_tag_at_nf(v_ru_24v_24248_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(asin(v_a_24254))});
      return heff_tag_at_n(v_ru_24x1_24247_24Ok, TAG_Ok, 1, (V[]){v_t_24255});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24248, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24248);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24263 = heff_field(v_x1_24247, 0);
    V v_ru_24x1_24247_24Bug = heff_take_reuse_n(v_x1_24247, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24247_24Bug, TAG_Bug, 1, (V[]){v_what_24263});
  }
  default: return heff_nomatch(v_x1_24247);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args) {
  V v_d_24265 = args[0];
  V v_a_24266 = args[1];
  V v_x1_24267 = heff_tr(heff_call(v_a_24266, 1, (V[]){v_d_24265}));
  switch (heff_tag_of(v_x1_24267)) {
  case TAG_Ok: {
    V v_v_24268 = heff_field(v_x1_24267, 0);
    V v_ru_24x1_24267_24Ok = heff_take_reuse_n(v_x1_24267, 1ULL, 1);
    switch (heff_tag_of(v_v_24268)) {
    case TAG_VFun: {
      heff_take_n(v_v_24268, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24267_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24268, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24267_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24268, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24267_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24268, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24267_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24274 = heff_tflat_f64(v_v_24268, 0);
      V v_ru_24v_24268_24VFloat = heff_take_reuse_na(v_v_24268, 0ULL, 1);
      V v_t_24275 = heff_tag_at_nf(v_ru_24v_24268_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(acos(v_a_24274))});
      return heff_tag_at_n(v_ru_24x1_24267_24Ok, TAG_Ok, 1, (V[]){v_t_24275});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24268, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24267_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24268, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24267_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24268, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24267_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24268, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24267_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24268, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24267_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24268, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24267_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24267_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24268);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24283 = heff_field(v_x1_24267, 0);
    V v_ru_24x1_24267_24Bug = heff_take_reuse_n(v_x1_24267, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24267_24Bug, TAG_Bug, 1, (V[]){v_what_24283});
  }
  default: return heff_nomatch(v_x1_24267);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args) {
  V v_d_24285 = args[0];
  V v_a_24286 = args[1];
  V v_x1_24287 = heff_tr(heff_call(v_a_24286, 1, (V[]){v_d_24285}));
  switch (heff_tag_of(v_x1_24287)) {
  case TAG_Ok: {
    V v_v_24288 = heff_field(v_x1_24287, 0);
    V v_ru_24x1_24287_24Ok = heff_take_reuse_n(v_x1_24287, 1ULL, 1);
    switch (heff_tag_of(v_v_24288)) {
    case TAG_VFun: {
      heff_take_n(v_v_24288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24288, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24294 = heff_tflat_f64(v_v_24288, 0);
      V v_ru_24v_24288_24VFloat = heff_take_reuse_na(v_v_24288, 0ULL, 1);
      V v_t_24295 = heff_tag_at_nf(v_ru_24v_24288_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(atan(v_a_24294))});
      return heff_tag_at_n(v_ru_24x1_24287_24Ok, TAG_Ok, 1, (V[]){v_t_24295});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24288, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24288);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24303 = heff_field(v_x1_24287, 0);
    V v_ru_24x1_24287_24Bug = heff_take_reuse_n(v_x1_24287, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24287_24Bug, TAG_Bug, 1, (V[]){v_what_24303});
  }
  default: return heff_nomatch(v_x1_24287);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args) {
  V v_d_24306 = args[0];
  V v_a_24307 = args[1];
  V v_x1_24308 = heff_tr(heff_call(v_a_24307, 1, (V[]){v_d_24306}));
  switch (heff_tag_of(v_x1_24308)) {
  case TAG_Ok: {
    V v_v_24309 = heff_field(v_x1_24308, 0);
    V v_ru_24x1_24308_24Ok = heff_take_reuse_n(v_x1_24308, 1ULL, 1);
    switch (heff_tag_of(v_v_24309)) {
    case TAG_VFun: {
      heff_take_n(v_v_24309, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24308_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24309, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24308_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24309, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24308_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24309, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24308_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24315 = heff_tflat_f64(v_v_24309, 0);
      V v_ru_24v_24309_24VFloat = heff_take_reuse_na(v_v_24309, 0ULL, 1);
      V v_t_24316 = heff_tag_at_nf(v_ru_24v_24309_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(exp(v_a_24315))});
      return heff_tag_at_n(v_ru_24x1_24308_24Ok, TAG_Ok, 1, (V[]){v_t_24316});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24309, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24308_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24309, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24308_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24309, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24308_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24309, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24308_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24309, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24308_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24309, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24308_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24308_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24309);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24324 = heff_field(v_x1_24308, 0);
    V v_ru_24x1_24308_24Bug = heff_take_reuse_n(v_x1_24308, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24308_24Bug, TAG_Bug, 1, (V[]){v_what_24324});
  }
  default: return heff_nomatch(v_x1_24308);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args) {
  V v_d_24326 = args[0];
  V v_a_24327 = args[1];
  V v_x1_24328 = heff_tr(heff_call(v_a_24327, 1, (V[]){v_d_24326}));
  switch (heff_tag_of(v_x1_24328)) {
  case TAG_Ok: {
    V v_v_24329 = heff_field(v_x1_24328, 0);
    V v_ru_24x1_24328_24Ok = heff_take_reuse_n(v_x1_24328, 1ULL, 1);
    switch (heff_tag_of(v_v_24329)) {
    case TAG_VFun: {
      heff_take_n(v_v_24329, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24329, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24329, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24329, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24335 = heff_tflat_f64(v_v_24329, 0);
      V v_ru_24v_24329_24VFloat = heff_take_reuse_na(v_v_24329, 0ULL, 1);
      V v_t_24336 = heff_tag_at_nf(v_ru_24v_24329_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(log(v_a_24335))});
      return heff_tag_at_n(v_ru_24x1_24328_24Ok, TAG_Ok, 1, (V[]){v_t_24336});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24329, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24329, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24329, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24329, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24329, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24329, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24328_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24329);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24344 = heff_field(v_x1_24328, 0);
    V v_ru_24x1_24328_24Bug = heff_take_reuse_n(v_x1_24328, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24328_24Bug, TAG_Bug, 1, (V[]){v_what_24344});
  }
  default: return heff_nomatch(v_x1_24328);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args) {
  V v_d_24349 = args[0];
  V v_a_24350 = args[1];
  V v_x1_24351 = heff_tr(heff_call(v_a_24350, 1, (V[]){v_d_24349}));
  switch (heff_tag_of(v_x1_24351)) {
  case TAG_Ok: {
    V v_v_24352 = heff_field(v_x1_24351, 0);
    V v_ru_24x1_24351_24Ok = heff_take_reuse_n(v_x1_24351, 1ULL, 1);
    switch (heff_tag_of(v_v_24352)) {
    case TAG_VFun: {
      heff_take_n(v_v_24352, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24351_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24352, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24351_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24352, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24351_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24352, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24351_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24352, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24351_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24352, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24351_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24352, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24351_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24352, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24351_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24362 = heff_field(v_v_24352, 0);
      heff_take_n(v_v_24352, 1ULL, 1);
      V v_t_24363 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_xs_24362); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      return heff_tag_at_n(v_ru_24x1_24351_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24363})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24352, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24351_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24352, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24351_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24351_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24352);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24367 = heff_field(v_x1_24351, 0);
    V v_ru_24x1_24351_24Bug = heff_take_reuse_n(v_x1_24351, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24351_24Bug, TAG_Bug, 1, (V[]){v_what_24367});
  }
  default: return heff_nomatch(v_x1_24351);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args) {
  V v_d_24347 = args[0];
  V v_u_24348 = args[1];
  heff_drop(v_d_24347);
  heff_drop(v_u_24348);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam27_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args) {
  V v_d_24385 = args[0];
  V v_a_24386 = args[1];
  V v_xs_24384 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24387 = heff_tr(heff_call(v_a_24386, 1, (V[]){v_d_24385}));
  switch (heff_tag_of(v_x1_24387)) {
  case TAG_Ok: {
    V v_v_24388 = heff_field(v_x1_24387, 0);
    V v_ru_24x1_24387_24Ok = heff_take_reuse_n(v_x1_24387, 1ULL, 1);
    switch (heff_tag_of(v_v_24388)) {
    case TAG_VFun: {
      heff_take_n(v_v_24388, 0ULL, 1);
      heff_drop(v_xs_24384);
      heff_drop_cell(v_ru_24x1_24387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24388, 0ULL, 1);
      heff_drop(v_xs_24384);
      heff_drop_cell(v_ru_24x1_24387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24388, 0ULL, 2);
      heff_drop(v_xs_24384);
      heff_drop_cell(v_ru_24x1_24387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24393 = heff_field(v_v_24388, 0);
      V v_ru_24v_24388_24VInt = heff_take_reuse_n(v_v_24388, 1ULL, 1);
      if (heff_intLe_c_lent(MK_INT(0LL), v_a_24393, 1)) {
        V v_t_24395 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24384)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        if (heff_intLt_c_lent(v_a_24393, v_t_24395, 2)) {
          HeffT2 v_t_24397 = (g_heff_2ecompile_2einterp_2enthV_24cpr(heff_arrayToList(v_xs_24384), v_a_24393));
          {
            V v_field_24399 = v_t_24397.f[1];
            int64_t v_tag_24398 = ((int64_t)v_t_24397.f[0]);
            if ((v_tag_24398 == ((int64_t)0ULL))) {
              heff_drop_cell(v_ru_24v_24388_24VInt, 1);
              V v_v_24401 = v_field_24399;
              return heff_tag_at_n(v_ru_24x1_24387_24Ok, TAG_Ok, 1, (V[]){v_v_24401});
            } else {
              heff_drop_cell(v_ru_24x1_24387_24Ok, 1);
              heff_drop(v_field_24399);
              return heff_tag_at_n(v_ru_24v_24388_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str51)});
            }
          }
        } else {
          heff_drop(v_xs_24384);
          heff_drop_cell(v_ru_24x1_24387_24Ok, 1);
          heff_drop(v_a_24393);
          heff_drop_cell(v_ru_24v_24388_24VInt, 1);
          return NTAG(TAG_Abn);
        }
      } else {
        heff_drop(v_xs_24384);
        heff_drop_cell(v_ru_24x1_24387_24Ok, 1);
        heff_drop(v_a_24393);
        heff_drop_cell(v_ru_24v_24388_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24388, 0ULL, 1);
      heff_drop(v_xs_24384);
      heff_drop_cell(v_ru_24x1_24387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24388, 0ULL, 1);
      heff_drop(v_xs_24384);
      heff_drop_cell(v_ru_24x1_24387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24388, 0ULL, 1);
      heff_drop(v_xs_24384);
      heff_drop_cell(v_ru_24x1_24387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24388, 0ULL, 1);
      heff_drop(v_xs_24384);
      heff_drop_cell(v_ru_24x1_24387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24388, 0ULL, 1);
      heff_drop(v_xs_24384);
      heff_drop_cell(v_ru_24x1_24387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24388, 0ULL, 1);
      heff_drop(v_xs_24384);
      heff_drop_cell(v_ru_24x1_24387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24388, 0ULL, 2);
      heff_drop(v_xs_24384);
      heff_drop_cell(v_ru_24x1_24387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24384);
      heff_drop_cell(v_ru_24x1_24387_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24388);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24384);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24384);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24410 = heff_field(v_x1_24387, 0);
    V v_ru_24x1_24387_24Bug = heff_take_reuse_n(v_x1_24387, 1ULL, 1);
    heff_drop(v_xs_24384);
    return heff_tag_at_n(v_ru_24x1_24387_24Bug, TAG_Bug, 1, (V[]){v_what_24410});
  }
  default: return heff_nomatch(v_x1_24387);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args) {
  V v_d_24371 = args[0];
  V v_a_24372 = args[1];
  V v_x1_24373 = heff_tr(heff_call(v_a_24372, 1, (V[]){v_d_24371}));
  switch (heff_tag_of(v_x1_24373)) {
  case TAG_Ok: {
    V v_v_24374 = heff_field(v_x1_24373, 0);
    V v_ru_24x1_24373_24Ok = heff_take_reuse_n(v_x1_24373, 1ULL, 1);
    switch (heff_tag_of(v_v_24374)) {
    case TAG_VFun: {
      heff_take_n(v_v_24374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24374, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24384 = heff_field(v_v_24374, 0);
      heff_take_n(v_v_24374, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24373_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam30, 2, 1, (V[]){v_xs_24384})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24374, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24374);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24414 = heff_field(v_x1_24373, 0);
    V v_ru_24x1_24373_24Bug = heff_take_reuse_n(v_x1_24373, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24373_24Bug, TAG_Bug, 1, (V[]){v_what_24414});
  }
  default: return heff_nomatch(v_x1_24373);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args) {
  V v_d_24369 = args[0];
  V v_u_24370 = args[1];
  heff_drop(v_d_24369);
  heff_drop(v_u_24370);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam29_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args) {
  V v_d_24441 = args[0];
  V v_x_24442 = args[1];
  V v_a_24440 = heff_env(self)[0];
  V v_xs_24431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24443 = heff_tr(heff_call(v_x_24442, 1, (V[]){v_d_24441}));
  switch (heff_tag_of(v_x1_24443)) {
  case TAG_Ok: {
    V v_v_24444 = heff_field(v_x1_24443, 0);
    V v_ru_24x1_24443_24Ok = heff_take_reuse_n(v_x1_24443, 1ULL, 1);
    if (heff_intLe_c_lent(MK_INT(0LL), v_a_24440, 1)) {
      V v_t_24446 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24431)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (heff_intLt_c_lent(v_a_24440, v_t_24446, 2)) {
        V v_t_24448 = (g_heff_2ecompile_2einterp_2esetAt(heff_arrayToList(v_xs_24431), v_a_24440, v_v_24444));
        V v_t_24449 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24448)});
        return heff_tag_at_n(v_ru_24x1_24443_24Ok, TAG_Ok, 1, (V[]){v_t_24449});
      } else {
        heff_drop(v_a_24440);
        heff_drop(v_v_24444);
        return heff_tag_at_n(v_ru_24x1_24443_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VArr, 1, (V[]){v_xs_24431})});
      }
    } else {
      heff_drop(v_a_24440);
      heff_drop(v_v_24444);
      return heff_tag_at_n(v_ru_24x1_24443_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VArr, 1, (V[]){v_xs_24431})});
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24440);
    heff_drop(v_xs_24431);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24440);
    heff_drop(v_xs_24431);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24450 = heff_field(v_x1_24443, 0);
    V v_ru_24x1_24443_24Bug = heff_take_reuse_n(v_x1_24443, 1ULL, 1);
    heff_drop(v_a_24440);
    heff_drop(v_xs_24431);
    return heff_tag_at_n(v_ru_24x1_24443_24Bug, TAG_Bug, 1, (V[]){v_what_24450});
  }
  default: return heff_nomatch(v_x1_24443);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args) {
  V v_d_24432 = args[0];
  V v_a_24433 = args[1];
  V v_xs_24431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24434 = heff_tr(heff_call(v_a_24433, 1, (V[]){v_d_24432}));
  switch (heff_tag_of(v_x1_24434)) {
  case TAG_Ok: {
    V v_v_24435 = heff_field(v_x1_24434, 0);
    V v_ru_24x1_24434_24Ok = heff_take_reuse_n(v_x1_24434, 1ULL, 1);
    switch (heff_tag_of(v_v_24435)) {
    case TAG_VFun: {
      heff_take_n(v_v_24435, 0ULL, 1);
      heff_drop(v_xs_24431);
      heff_drop_cell(v_ru_24x1_24434_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24435, 0ULL, 1);
      heff_drop(v_xs_24431);
      heff_drop_cell(v_ru_24x1_24434_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24435, 0ULL, 2);
      heff_drop(v_xs_24431);
      heff_drop_cell(v_ru_24x1_24434_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24440 = heff_field(v_v_24435, 0);
      heff_take_n(v_v_24435, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24434_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam34, 2, 2, (V[]){v_a_24440, v_xs_24431})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24435, 0ULL, 1);
      heff_drop(v_xs_24431);
      heff_drop_cell(v_ru_24x1_24434_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24435, 0ULL, 1);
      heff_drop(v_xs_24431);
      heff_drop_cell(v_ru_24x1_24434_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24435, 0ULL, 1);
      heff_drop(v_xs_24431);
      heff_drop_cell(v_ru_24x1_24434_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24435, 0ULL, 1);
      heff_drop(v_xs_24431);
      heff_drop_cell(v_ru_24x1_24434_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24435, 0ULL, 1);
      heff_drop(v_xs_24431);
      heff_drop_cell(v_ru_24x1_24434_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24435, 0ULL, 1);
      heff_drop(v_xs_24431);
      heff_drop_cell(v_ru_24x1_24434_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24435, 0ULL, 2);
      heff_drop(v_xs_24431);
      heff_drop_cell(v_ru_24x1_24434_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24431);
      heff_drop_cell(v_ru_24x1_24434_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24435);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24431);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24431);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24459 = heff_field(v_x1_24434, 0);
    V v_ru_24x1_24434_24Bug = heff_take_reuse_n(v_x1_24434, 1ULL, 1);
    heff_drop(v_xs_24431);
    return heff_tag_at_n(v_ru_24x1_24434_24Bug, TAG_Bug, 1, (V[]){v_what_24459});
  }
  default: return heff_nomatch(v_x1_24434);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args) {
  V v_d_24418 = args[0];
  V v_a_24419 = args[1];
  V v_x1_24420 = heff_tr(heff_call(v_a_24419, 1, (V[]){v_d_24418}));
  switch (heff_tag_of(v_x1_24420)) {
  case TAG_Ok: {
    V v_v_24421 = heff_field(v_x1_24420, 0);
    V v_ru_24x1_24420_24Ok = heff_take_reuse_n(v_x1_24420, 1ULL, 1);
    switch (heff_tag_of(v_v_24421)) {
    case TAG_VFun: {
      heff_take_n(v_v_24421, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24420_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24421, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24420_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24421, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24420_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24421, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24420_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24421, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24420_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24421, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24420_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24421, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24420_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24421, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24420_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24431 = heff_field(v_v_24421, 0);
      heff_take_n(v_v_24421, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24420_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam33, 2, 1, (V[]){v_xs_24431})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24421, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24420_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24421, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24420_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24420_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24421);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24463 = heff_field(v_x1_24420, 0);
    V v_ru_24x1_24420_24Bug = heff_take_reuse_n(v_x1_24420, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24420_24Bug, TAG_Bug, 1, (V[]){v_what_24463});
  }
  default: return heff_nomatch(v_x1_24420);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args) {
  V v_d_24416 = args[0];
  V v_u_24417 = args[1];
  heff_drop(v_d_24416);
  heff_drop(v_u_24417);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam32_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args) {
  V v_vs_24480 = args[0];
  V v_t_24481 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_vs_24480)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24481});
}
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args) {
  V v_d_24476 = args[0];
  V v_f_24477 = args[1];
  V v_a_24475 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24478 = heff_tr(heff_call(v_f_24477, 1, (V[]){heff_dup(v_d_24476)}));
  switch (heff_tag_of(v_x1_24478)) {
  case TAG_Ok: {
    V v_v_24479 = heff_field(v_x1_24478, 0);
    heff_take_n(v_x1_24478, 1ULL, 1);
    return (g_heff_2ecompile_2einterp_2egenGo(v_d_24476, MK_INT(0LL), v_a_24475, v_v_24479, ((V)&g_heff_2ecompile_2einterp_2eprim_lam38_clo)));
  }
  case TAG_Abn: {
    heff_drop(v_d_24476);
    heff_drop(v_a_24475);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_24476);
    heff_drop(v_a_24475);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24482 = heff_field(v_x1_24478, 0);
    V v_ru_24x1_24478_24Bug = heff_take_reuse_n(v_x1_24478, 1ULL, 1);
    heff_drop(v_d_24476);
    heff_drop(v_a_24475);
    return heff_tag_at_n(v_ru_24x1_24478_24Bug, TAG_Bug, 1, (V[]){v_what_24482});
  }
  default: return heff_nomatch(v_x1_24478);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args) {
  V v_d_24467 = args[0];
  V v_a_24468 = args[1];
  V v_x1_24469 = heff_tr(heff_call(v_a_24468, 1, (V[]){v_d_24467}));
  switch (heff_tag_of(v_x1_24469)) {
  case TAG_Ok: {
    V v_v_24470 = heff_field(v_x1_24469, 0);
    V v_ru_24x1_24469_24Ok = heff_take_reuse_n(v_x1_24469, 1ULL, 1);
    switch (heff_tag_of(v_v_24470)) {
    case TAG_VFun: {
      heff_take_n(v_v_24470, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24469_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24470, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24469_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24470, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24469_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24475 = heff_field(v_v_24470, 0);
      heff_take_n(v_v_24470, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24469_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam37, 2, 1, (V[]){v_a_24475})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24470, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24469_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24470, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24469_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24470, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24469_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24470, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24469_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24470, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24469_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24470, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24469_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24470, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24469_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24469_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24470);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24491 = heff_field(v_x1_24469, 0);
    V v_ru_24x1_24469_24Bug = heff_take_reuse_n(v_x1_24469, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24469_24Bug, TAG_Bug, 1, (V[]){v_what_24491});
  }
  default: return heff_nomatch(v_x1_24469);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args) {
  V v_d_24465 = args[0];
  V v_u_24466 = args[1];
  heff_drop(v_d_24465);
  heff_drop(v_u_24466);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam36_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args) {
  V v_d_24495 = args[0];
  V v_l_24496 = args[1];
  V v_x1_24497 = heff_tr(heff_call(v_l_24496, 1, (V[]){v_d_24495}));
  switch (heff_tag_of(v_x1_24497)) {
  case TAG_Ok: {
    V v_v_24498 = heff_field(v_x1_24497, 0);
    V v_ru_24x1_24497_24Ok = heff_take_reuse_n(v_x1_24497, 1ULL, 1);
    V v_t_24499 = (g_heff_2ecompile_2einterp_2efromListV(v_v_24498, NTAG(TAG_Nil)));
    V v_t_24500 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24499)});
    return heff_tag_at_n(v_ru_24x1_24497_24Ok, TAG_Ok, 1, (V[]){v_t_24500});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24501 = heff_field(v_x1_24497, 0);
    V v_ru_24x1_24497_24Bug = heff_take_reuse_n(v_x1_24497, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24497_24Bug, TAG_Bug, 1, (V[]){v_what_24501});
  }
  default: return heff_nomatch(v_x1_24497);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args) {
  V v_d_24493 = args[0];
  V v_u_24494 = args[1];
  heff_drop(v_d_24493);
  heff_drop(v_u_24494);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam40_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args) {
  V v_d_24505 = args[0];
  V v_a_24506 = args[1];
  V v_x1_24507 = heff_tr(heff_call(v_a_24506, 1, (V[]){v_d_24505}));
  switch (heff_tag_of(v_x1_24507)) {
  case TAG_Ok: {
    V v_v_24508 = heff_field(v_x1_24507, 0);
    V v_ru_24x1_24507_24Ok = heff_take_reuse_n(v_x1_24507, 1ULL, 1);
    switch (heff_tag_of(v_v_24508)) {
    case TAG_VFun: {
      heff_take_n(v_v_24508, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24507_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24508, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24507_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24508, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24507_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24508, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24507_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24508, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24507_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24508, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24507_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24508, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24507_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24508, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24507_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24518 = heff_field(v_v_24508, 0);
      heff_take_n(v_v_24508, 1ULL, 1);
      V v_t_24519 = (g_heff_2ecompile_2einterp_2etoListV(heff_arrayToList(v_xs_24518)));
      return heff_tag_at_n(v_ru_24x1_24507_24Ok, TAG_Ok, 1, (V[]){v_t_24519});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24508, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24507_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24508, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24507_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24507_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24508);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24523 = heff_field(v_x1_24507, 0);
    V v_ru_24x1_24507_24Bug = heff_take_reuse_n(v_x1_24507, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24507_24Bug, TAG_Bug, 1, (V[]){v_what_24523});
  }
  default: return heff_nomatch(v_x1_24507);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args) {
  V v_d_24503 = args[0];
  V v_u_24504 = args[1];
  heff_drop(v_d_24503);
  heff_drop(v_u_24504);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam42_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args) {
  V v_d_24536 = args[0];
  V v_x_24537 = args[1];
  V v_a_24535 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24538 = heff_tr(heff_call(v_x_24537, 1, (V[]){v_d_24536}));
  switch (heff_tag_of(v_x1_24538)) {
  case TAG_Ok: {
    V v_v_24539 = heff_field(v_x1_24538, 0);
    V v_ru_24x1_24538_24Ok = heff_take_reuse_n(v_x1_24538, 1ULL, 1);
    V v_t_24540 = (g_list_2ereplicate(v_a_24535, v_v_24539));
    V v_t_24541 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24540)});
    return heff_tag_at_n(v_ru_24x1_24538_24Ok, TAG_Ok, 1, (V[]){v_t_24541});
  }
  case TAG_Abn: {
    heff_drop(v_a_24535);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24535);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24542 = heff_field(v_x1_24538, 0);
    V v_ru_24x1_24538_24Bug = heff_take_reuse_n(v_x1_24538, 1ULL, 1);
    heff_drop(v_a_24535);
    return heff_tag_at_n(v_ru_24x1_24538_24Bug, TAG_Bug, 1, (V[]){v_what_24542});
  }
  default: return heff_nomatch(v_x1_24538);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args) {
  V v_d_24527 = args[0];
  V v_a_24528 = args[1];
  V v_x1_24529 = heff_tr(heff_call(v_a_24528, 1, (V[]){v_d_24527}));
  switch (heff_tag_of(v_x1_24529)) {
  case TAG_Ok: {
    V v_v_24530 = heff_field(v_x1_24529, 0);
    V v_ru_24x1_24529_24Ok = heff_take_reuse_n(v_x1_24529, 1ULL, 1);
    switch (heff_tag_of(v_v_24530)) {
    case TAG_VFun: {
      heff_take_n(v_v_24530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24530, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24535 = heff_field(v_v_24530, 0);
      heff_take_n(v_v_24530, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24529_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam45, 2, 1, (V[]){v_a_24535})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24530, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24530, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24529_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24530);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24551 = heff_field(v_x1_24529, 0);
    V v_ru_24x1_24529_24Bug = heff_take_reuse_n(v_x1_24529, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24529_24Bug, TAG_Bug, 1, (V[]){v_what_24551});
  }
  default: return heff_nomatch(v_x1_24529);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args) {
  V v_d_24525 = args[0];
  V v_u_24526 = args[1];
  heff_drop(v_d_24525);
  heff_drop(v_u_24526);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam44_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args) {
  V v_d_24578 = args[0];
  V v_a_24579 = args[1];
  V v_xs_24568 = heff_env(self)[0];
  V v_a_24577 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24580 = heff_tr(heff_call(v_a_24579, 1, (V[]){v_d_24578}));
  switch (heff_tag_of(v_x1_24580)) {
  case TAG_Ok: {
    V v_v_24581 = heff_field(v_x1_24580, 0);
    V v_ru_24x1_24580_24Ok = heff_take_reuse_n(v_x1_24580, 1ULL, 1);
    switch (heff_tag_of(v_v_24581)) {
    case TAG_VFun: {
      heff_take_n(v_v_24581, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop(v_a_24577);
      heff_drop_cell(v_ru_24x1_24580_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24581, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop(v_a_24577);
      heff_drop_cell(v_ru_24x1_24580_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24581, 0ULL, 2);
      heff_drop(v_xs_24568);
      heff_drop(v_a_24577);
      heff_drop_cell(v_ru_24x1_24580_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24586 = heff_field(v_v_24581, 0);
      V v_ru_24v_24581_24VInt = heff_take_reuse_n(v_v_24581, 1ULL, 1);
      V v_t_24587 = ({ V b_0 = heff_arrayToList(v_xs_24568); V a_1 = v_a_24577; V a_2 = v_a_24586; V r_ = (g_heff_2ecompile_2einterp_2esliceV(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V v_t_24588 = heff_tag_at_n(v_ru_24v_24581_24VInt, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24587)});
      return heff_tag_at_n(v_ru_24x1_24580_24Ok, TAG_Ok, 1, (V[]){v_t_24588});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24581, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop(v_a_24577);
      heff_drop_cell(v_ru_24x1_24580_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24581, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop(v_a_24577);
      heff_drop_cell(v_ru_24x1_24580_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24581, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop(v_a_24577);
      heff_drop_cell(v_ru_24x1_24580_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24581, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop(v_a_24577);
      heff_drop_cell(v_ru_24x1_24580_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24581, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop(v_a_24577);
      heff_drop_cell(v_ru_24x1_24580_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24581, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop(v_a_24577);
      heff_drop_cell(v_ru_24x1_24580_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24581, 0ULL, 2);
      heff_drop(v_xs_24568);
      heff_drop(v_a_24577);
      heff_drop_cell(v_ru_24x1_24580_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24568);
      heff_drop(v_a_24577);
      heff_drop_cell(v_ru_24x1_24580_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24581);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24568);
    heff_drop(v_a_24577);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24568);
    heff_drop(v_a_24577);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24597 = heff_field(v_x1_24580, 0);
    V v_ru_24x1_24580_24Bug = heff_take_reuse_n(v_x1_24580, 1ULL, 1);
    heff_drop(v_xs_24568);
    heff_drop(v_a_24577);
    return heff_tag_at_n(v_ru_24x1_24580_24Bug, TAG_Bug, 1, (V[]){v_what_24597});
  }
  default: return heff_nomatch(v_x1_24580);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args) {
  V v_d_24569 = args[0];
  V v_a_24570 = args[1];
  V v_xs_24568 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24571 = heff_tr(heff_call(v_a_24570, 1, (V[]){v_d_24569}));
  switch (heff_tag_of(v_x1_24571)) {
  case TAG_Ok: {
    V v_v_24572 = heff_field(v_x1_24571, 0);
    V v_ru_24x1_24571_24Ok = heff_take_reuse_n(v_x1_24571, 1ULL, 1);
    switch (heff_tag_of(v_v_24572)) {
    case TAG_VFun: {
      heff_take_n(v_v_24572, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop_cell(v_ru_24x1_24571_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24572, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop_cell(v_ru_24x1_24571_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24572, 0ULL, 2);
      heff_drop(v_xs_24568);
      heff_drop_cell(v_ru_24x1_24571_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24577 = heff_field(v_v_24572, 0);
      heff_take_n(v_v_24572, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24571_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam49, 2, 2, (V[]){v_xs_24568, v_a_24577})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24572, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop_cell(v_ru_24x1_24571_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24572, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop_cell(v_ru_24x1_24571_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24572, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop_cell(v_ru_24x1_24571_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24572, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop_cell(v_ru_24x1_24571_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24572, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop_cell(v_ru_24x1_24571_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24572, 0ULL, 1);
      heff_drop(v_xs_24568);
      heff_drop_cell(v_ru_24x1_24571_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24572, 0ULL, 2);
      heff_drop(v_xs_24568);
      heff_drop_cell(v_ru_24x1_24571_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24568);
      heff_drop_cell(v_ru_24x1_24571_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24572);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24568);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24568);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24606 = heff_field(v_x1_24571, 0);
    V v_ru_24x1_24571_24Bug = heff_take_reuse_n(v_x1_24571, 1ULL, 1);
    heff_drop(v_xs_24568);
    return heff_tag_at_n(v_ru_24x1_24571_24Bug, TAG_Bug, 1, (V[]){v_what_24606});
  }
  default: return heff_nomatch(v_x1_24571);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args) {
  V v_d_24555 = args[0];
  V v_a_24556 = args[1];
  V v_x1_24557 = heff_tr(heff_call(v_a_24556, 1, (V[]){v_d_24555}));
  switch (heff_tag_of(v_x1_24557)) {
  case TAG_Ok: {
    V v_v_24558 = heff_field(v_x1_24557, 0);
    V v_ru_24x1_24557_24Ok = heff_take_reuse_n(v_x1_24557, 1ULL, 1);
    switch (heff_tag_of(v_v_24558)) {
    case TAG_VFun: {
      heff_take_n(v_v_24558, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24557_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24558, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24557_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24558, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24557_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24558, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24557_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24558, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24557_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24558, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24557_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24558, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24557_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24558, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24557_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24568 = heff_field(v_v_24558, 0);
      heff_take_n(v_v_24558, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24557_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam48, 2, 1, (V[]){v_xs_24568})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24558, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24557_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24558, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24557_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24557_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24558);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24610 = heff_field(v_x1_24557, 0);
    V v_ru_24x1_24557_24Bug = heff_take_reuse_n(v_x1_24557, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24557_24Bug, TAG_Bug, 1, (V[]){v_what_24610});
  }
  default: return heff_nomatch(v_x1_24557);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args) {
  V v_d_24553 = args[0];
  V v_u_24554 = args[1];
  heff_drop(v_d_24553);
  heff_drop(v_u_24554);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam47_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args) {
  V v_d_24628 = args[0];
  V v_a_24629 = args[1];
  V v_xs_24627 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24630 = heff_tr(heff_call(v_a_24629, 1, (V[]){v_d_24628}));
  switch (heff_tag_of(v_x1_24630)) {
  case TAG_Ok: {
    V v_v_24631 = heff_field(v_x1_24630, 0);
    V v_ru_24x1_24630_24Ok = heff_take_reuse_n(v_x1_24630, 1ULL, 1);
    switch (heff_tag_of(v_v_24631)) {
    case TAG_VFun: {
      heff_take_n(v_v_24631, 0ULL, 1);
      heff_drop(v_xs_24627);
      heff_drop_cell(v_ru_24x1_24630_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24631, 0ULL, 1);
      heff_drop(v_xs_24627);
      heff_drop_cell(v_ru_24x1_24630_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24631, 0ULL, 2);
      heff_drop(v_xs_24627);
      heff_drop_cell(v_ru_24x1_24630_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24631, 0ULL, 1);
      heff_drop(v_xs_24627);
      heff_drop_cell(v_ru_24x1_24630_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24631, 0ULL, 1);
      heff_drop(v_xs_24627);
      heff_drop_cell(v_ru_24x1_24630_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24631, 0ULL, 1);
      heff_drop(v_xs_24627);
      heff_drop_cell(v_ru_24x1_24630_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24631, 0ULL, 1);
      heff_drop(v_xs_24627);
      heff_drop_cell(v_ru_24x1_24630_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24631, 0ULL, 1);
      heff_drop(v_xs_24627);
      heff_drop_cell(v_ru_24x1_24630_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24641 = heff_field(v_v_24631, 0);
      V v_ru_24v_24631_24VArr = heff_take_reuse_n(v_v_24631, 1ULL, 1);
      V v_t_24642 = (g_prelude_2e_2b_2b(heff_arrayToList(v_xs_24627), heff_arrayToList(v_xs_24641)));
      V v_t_24643 = heff_tag_at_n(v_ru_24v_24631_24VArr, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24642)});
      return heff_tag_at_n(v_ru_24x1_24630_24Ok, TAG_Ok, 1, (V[]){v_t_24643});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24631, 0ULL, 1);
      heff_drop(v_xs_24627);
      heff_drop_cell(v_ru_24x1_24630_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24631, 0ULL, 2);
      heff_drop(v_xs_24627);
      heff_drop_cell(v_ru_24x1_24630_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24627);
      heff_drop_cell(v_ru_24x1_24630_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24631);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24627);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24627);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24647 = heff_field(v_x1_24630, 0);
    V v_ru_24x1_24630_24Bug = heff_take_reuse_n(v_x1_24630, 1ULL, 1);
    heff_drop(v_xs_24627);
    return heff_tag_at_n(v_ru_24x1_24630_24Bug, TAG_Bug, 1, (V[]){v_what_24647});
  }
  default: return heff_nomatch(v_x1_24630);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args) {
  V v_d_24614 = args[0];
  V v_a_24615 = args[1];
  V v_x1_24616 = heff_tr(heff_call(v_a_24615, 1, (V[]){v_d_24614}));
  switch (heff_tag_of(v_x1_24616)) {
  case TAG_Ok: {
    V v_v_24617 = heff_field(v_x1_24616, 0);
    V v_ru_24x1_24616_24Ok = heff_take_reuse_n(v_x1_24616, 1ULL, 1);
    switch (heff_tag_of(v_v_24617)) {
    case TAG_VFun: {
      heff_take_n(v_v_24617, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24616_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24617, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24616_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24617, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24616_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24617, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24616_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24617, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24616_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24617, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24616_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24617, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24616_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24617, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24616_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24627 = heff_field(v_v_24617, 0);
      heff_take_n(v_v_24617, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24616_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam52, 2, 1, (V[]){v_xs_24627})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24617, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24616_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24617, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24616_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24616_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24617);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24651 = heff_field(v_x1_24616, 0);
    V v_ru_24x1_24616_24Bug = heff_take_reuse_n(v_x1_24616, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24616_24Bug, TAG_Bug, 1, (V[]){v_what_24651});
  }
  default: return heff_nomatch(v_x1_24616);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args) {
  V v_d_24612 = args[0];
  V v_u_24613 = args[1];
  heff_drop(v_d_24612);
  heff_drop(v_u_24613);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam51_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args) {
  V v_d_24654 = args[0];
  V v_a_24655 = args[1];
  V v_x1_24656 = heff_tr(heff_call(v_a_24655, 1, (V[]){v_d_24654}));
  switch (heff_tag_of(v_x1_24656)) {
  case TAG_Ok: {
    V v_v_24657 = heff_field(v_x1_24656, 0);
    V v_ru_24x1_24656_24Ok = heff_take_reuse_n(v_x1_24656, 1ULL, 1);
    switch (heff_tag_of(v_v_24657)) {
    case TAG_VFun: {
      heff_take_n(v_v_24657, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24656_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24657, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24656_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24657, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24656_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24657, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24656_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24657, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24656_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24657, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24656_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24665 = heff_field(v_v_24657, 0);
      V v_ru_24v_24657_24VStr = heff_take_reuse_n(v_v_24657, 1ULL, 1);
      V v_t_24666 = heff_tag_at_n(v_ru_24v_24657_24VStr, TAG_VInt, 1, (V[]){heff_strLength(v_a_24665)});
      return heff_tag_at_n(v_ru_24x1_24656_24Ok, TAG_Ok, 1, (V[]){v_t_24666});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24657, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24656_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24657, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24656_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24657, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24656_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24657, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24656_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24656_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24657);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24672 = heff_field(v_x1_24656, 0);
    V v_ru_24x1_24656_24Bug = heff_take_reuse_n(v_x1_24656, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24656_24Bug, TAG_Bug, 1, (V[]){v_what_24672});
  }
  default: return heff_nomatch(v_x1_24656);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args) {
  V v_d_24695 = args[0];
  V v_a_24696 = args[1];
  V v_a_24685 = heff_env(self)[0];
  V v_a_24694 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24697 = heff_tr(heff_call(v_a_24696, 1, (V[]){v_d_24695}));
  switch (heff_tag_of(v_x1_24697)) {
  case TAG_Ok: {
    V v_v_24698 = heff_field(v_x1_24697, 0);
    V v_ru_24x1_24697_24Ok = heff_take_reuse_n(v_x1_24697, 1ULL, 1);
    switch (heff_tag_of(v_v_24698)) {
    case TAG_VFun: {
      heff_take_n(v_v_24698, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop(v_a_24694);
      heff_drop_cell(v_ru_24x1_24697_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24698, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop(v_a_24694);
      heff_drop_cell(v_ru_24x1_24697_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24698, 0ULL, 2);
      heff_drop(v_a_24685);
      heff_drop(v_a_24694);
      heff_drop_cell(v_ru_24x1_24697_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24703 = heff_field(v_v_24698, 0);
      V v_ru_24v_24698_24VInt = heff_take_reuse_n(v_v_24698, 1ULL, 1);
      V v_t_24704 = heff_tag_at_n(v_ru_24v_24698_24VInt, TAG_VStr, 1, (V[]){heff_strSlice(v_a_24685, v_a_24694, v_a_24703)});
      return heff_tag_at_n(v_ru_24x1_24697_24Ok, TAG_Ok, 1, (V[]){v_t_24704});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24698, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop(v_a_24694);
      heff_drop_cell(v_ru_24x1_24697_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24698, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop(v_a_24694);
      heff_drop_cell(v_ru_24x1_24697_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24698, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop(v_a_24694);
      heff_drop_cell(v_ru_24x1_24697_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24698, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop(v_a_24694);
      heff_drop_cell(v_ru_24x1_24697_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24698, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop(v_a_24694);
      heff_drop_cell(v_ru_24x1_24697_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24698, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop(v_a_24694);
      heff_drop_cell(v_ru_24x1_24697_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24698, 0ULL, 2);
      heff_drop(v_a_24685);
      heff_drop(v_a_24694);
      heff_drop_cell(v_ru_24x1_24697_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24685);
      heff_drop(v_a_24694);
      heff_drop_cell(v_ru_24x1_24697_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24698);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24685);
    heff_drop(v_a_24694);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24685);
    heff_drop(v_a_24694);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24713 = heff_field(v_x1_24697, 0);
    V v_ru_24x1_24697_24Bug = heff_take_reuse_n(v_x1_24697, 1ULL, 1);
    heff_drop(v_a_24685);
    heff_drop(v_a_24694);
    return heff_tag_at_n(v_ru_24x1_24697_24Bug, TAG_Bug, 1, (V[]){v_what_24713});
  }
  default: return heff_nomatch(v_x1_24697);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args) {
  V v_d_24686 = args[0];
  V v_a_24687 = args[1];
  V v_a_24685 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24688 = heff_tr(heff_call(v_a_24687, 1, (V[]){v_d_24686}));
  switch (heff_tag_of(v_x1_24688)) {
  case TAG_Ok: {
    V v_v_24689 = heff_field(v_x1_24688, 0);
    V v_ru_24x1_24688_24Ok = heff_take_reuse_n(v_x1_24688, 1ULL, 1);
    switch (heff_tag_of(v_v_24689)) {
    case TAG_VFun: {
      heff_take_n(v_v_24689, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop_cell(v_ru_24x1_24688_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24689, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop_cell(v_ru_24x1_24688_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24689, 0ULL, 2);
      heff_drop(v_a_24685);
      heff_drop_cell(v_ru_24x1_24688_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24694 = heff_field(v_v_24689, 0);
      heff_take_n(v_v_24689, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24688_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam56, 2, 2, (V[]){v_a_24685, v_a_24694})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24689, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop_cell(v_ru_24x1_24688_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24689, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop_cell(v_ru_24x1_24688_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24689, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop_cell(v_ru_24x1_24688_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24689, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop_cell(v_ru_24x1_24688_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24689, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop_cell(v_ru_24x1_24688_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24689, 0ULL, 1);
      heff_drop(v_a_24685);
      heff_drop_cell(v_ru_24x1_24688_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24689, 0ULL, 2);
      heff_drop(v_a_24685);
      heff_drop_cell(v_ru_24x1_24688_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24685);
      heff_drop_cell(v_ru_24x1_24688_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24689);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24685);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24685);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24722 = heff_field(v_x1_24688, 0);
    V v_ru_24x1_24688_24Bug = heff_take_reuse_n(v_x1_24688, 1ULL, 1);
    heff_drop(v_a_24685);
    return heff_tag_at_n(v_ru_24x1_24688_24Bug, TAG_Bug, 1, (V[]){v_what_24722});
  }
  default: return heff_nomatch(v_x1_24688);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args) {
  V v_d_24674 = args[0];
  V v_a_24675 = args[1];
  V v_x1_24676 = heff_tr(heff_call(v_a_24675, 1, (V[]){v_d_24674}));
  switch (heff_tag_of(v_x1_24676)) {
  case TAG_Ok: {
    V v_v_24677 = heff_field(v_x1_24676, 0);
    V v_ru_24x1_24676_24Ok = heff_take_reuse_n(v_x1_24676, 1ULL, 1);
    switch (heff_tag_of(v_v_24677)) {
    case TAG_VFun: {
      heff_take_n(v_v_24677, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24677, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24677, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24677, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24677, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24677, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24685 = heff_field(v_v_24677, 0);
      heff_take_n(v_v_24677, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24676_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam55, 2, 1, (V[]){v_a_24685})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24677, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24677, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24677, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24677, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24677);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24728 = heff_field(v_x1_24676, 0);
    V v_ru_24x1_24676_24Bug = heff_take_reuse_n(v_x1_24676, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24676_24Bug, TAG_Bug, 1, (V[]){v_what_24728});
  }
  default: return heff_nomatch(v_x1_24676);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args) {
  V v_a_24730 = args[0];
  V v_b_24731 = args[1];
  V v_t_24733;
  if (heff_strEq_c(v_a_24730, v_b_24731)) {
    v_t_24733 = ((V)&g_heff_2ecompile_2einterp_2eprim_str63);
  } else {
    v_t_24733 = ((V)&g_heff_2ecompile_2einterp_2eprim_str64);
  }
  V v_t_24734 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24733, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24734});
}
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args) {
  V v_a_24736 = args[0];
  V v_b_24737 = args[1];
  V v_t_24739;
  if (heff_strLt_c(v_a_24736, v_b_24737)) {
    v_t_24739 = ((V)&g_heff_2ecompile_2einterp_2eprim_str66);
  } else {
    v_t_24739 = ((V)&g_heff_2ecompile_2einterp_2eprim_str67);
  }
  V v_t_24740 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24739, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24740});
}
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args) {
  V v_a_24742 = args[0];
  V v_b_24743 = args[1];
  V v_t_24746;
  if (heff_strLt_c_lent(v_a_24742, v_b_24743, 0)) {
    heff_drop(v_a_24742);
    heff_drop(v_b_24743);
    v_t_24746 = MK_INT(-1LL);
  } else {
    if (heff_strEq_c(v_a_24742, v_b_24743)) {
      v_t_24746 = MK_INT(0LL);
    } else {
      v_t_24746 = MK_INT(1LL);
    }
  }
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24746})});
}
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args) {
  V v_d_24748 = args[0];
  V v_a_24749 = args[1];
  V v_x1_24750 = heff_tr(heff_call(v_a_24749, 1, (V[]){v_d_24748}));
  switch (heff_tag_of(v_x1_24750)) {
  case TAG_Ok: {
    V v_v_24751 = heff_field(v_x1_24750, 0);
    V v_ru_24x1_24750_24Ok = heff_take_reuse_n(v_x1_24750, 1ULL, 1);
    switch (heff_tag_of(v_v_24751)) {
    case TAG_VFun: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24751, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24759 = heff_field(v_v_24751, 0);
      V v_ru_24v_24751_24VStr = heff_take_reuse_n(v_v_24751, 1ULL, 1);
      V v_t_24760 = ({ V a_0 = v_a_24759; V a_1 = MK_INT(0LL); V a_2 = heff_strLength_lent(v_a_24759, 0); V r_ = (g_heff_2ecompile_2einterp_2ehashFrom(a_0, a_1, a_2)); heff_drop(v_a_24759); r_; });
      V v_t_24761 = (g_heff_2ecompile_2einterp_2efmix64(v_t_24760));
      V v_t_24762 = heff_tag_at_n(v_ru_24v_24751_24VStr, TAG_VInt, 1, (V[]){heff_intDiv(v_t_24761, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_24750_24Ok, TAG_Ok, 1, (V[]){v_t_24762});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24751, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24751);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24768 = heff_field(v_x1_24750, 0);
    V v_ru_24x1_24750_24Bug = heff_take_reuse_n(v_x1_24750, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24750_24Bug, TAG_Bug, 1, (V[]){v_what_24768});
  }
  default: return heff_nomatch(v_x1_24750);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args) {
  V v_d_24770 = args[0];
  V v_a_24771 = args[1];
  V v_x1_24772 = heff_tr(heff_call(v_a_24771, 1, (V[]){v_d_24770}));
  switch (heff_tag_of(v_x1_24772)) {
  case TAG_Ok: {
    V v_v_24773 = heff_field(v_x1_24772, 0);
    V v_ru_24x1_24772_24Ok = heff_take_reuse_n(v_x1_24772, 1ULL, 1);
    switch (heff_tag_of(v_v_24773)) {
    case TAG_VFun: {
      heff_take_n(v_v_24773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24773, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24778 = heff_field(v_v_24773, 0);
      V v_ru_24v_24773_24VInt = heff_take_reuse_n(v_v_24773, 1ULL, 1);
      V v_t_24779 = heff_intAdd(heff_intMod(v_a_24778, heff_dup(g_heff_2ecompile_2einterp_2eword64_get())), heff_dup(g_heff_2ecompile_2einterp_2eword64_get()));
      V v_t_24780 = (g_heff_2ecompile_2einterp_2efmix64(heff_intMod(v_t_24779, heff_dup(g_heff_2ecompile_2einterp_2eword64_get()))));
      V v_t_24781 = heff_tag_at_n(v_ru_24v_24773_24VInt, TAG_VInt, 1, (V[]){heff_intDiv(v_t_24780, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_24772_24Ok, TAG_Ok, 1, (V[]){v_t_24781});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24773, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24773);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24790 = heff_field(v_x1_24772, 0);
    V v_ru_24x1_24772_24Bug = heff_take_reuse_n(v_x1_24772, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24772_24Bug, TAG_Bug, 1, (V[]){v_what_24790});
  }
  default: return heff_nomatch(v_x1_24772);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args) {
  V v_d_24810 = args[0];
  V v_a_24811 = args[1];
  V v_a_24800 = heff_env(self)[0];
  V v_a_24809 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24812 = heff_tr(heff_call(v_a_24811, 1, (V[]){v_d_24810}));
  switch (heff_tag_of(v_x1_24812)) {
  case TAG_Ok: {
    V v_v_24813 = heff_field(v_x1_24812, 0);
    V v_ru_24x1_24812_24Ok = heff_take_reuse_n(v_x1_24812, 1ULL, 1);
    switch (heff_tag_of(v_v_24813)) {
    case TAG_VFun: {
      heff_take_n(v_v_24813, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop(v_a_24809);
      heff_drop_cell(v_ru_24x1_24812_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24813, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop(v_a_24809);
      heff_drop_cell(v_ru_24x1_24812_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24813, 0ULL, 2);
      heff_drop(v_a_24800);
      heff_drop(v_a_24809);
      heff_drop_cell(v_ru_24x1_24812_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24818 = heff_field(v_v_24813, 0);
      heff_take_n(v_v_24813, 1ULL, 1);
      V v_t_24819 = (g_heff_2ecompile_2einterp_2etrieSlotOf(v_a_24800, v_a_24809, v_a_24818));
      return heff_tag_at_n(v_ru_24x1_24812_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24819})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24813, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop(v_a_24809);
      heff_drop_cell(v_ru_24x1_24812_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24813, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop(v_a_24809);
      heff_drop_cell(v_ru_24x1_24812_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24813, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop(v_a_24809);
      heff_drop_cell(v_ru_24x1_24812_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24813, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop(v_a_24809);
      heff_drop_cell(v_ru_24x1_24812_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24813, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop(v_a_24809);
      heff_drop_cell(v_ru_24x1_24812_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24813, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop(v_a_24809);
      heff_drop_cell(v_ru_24x1_24812_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24813, 0ULL, 2);
      heff_drop(v_a_24800);
      heff_drop(v_a_24809);
      heff_drop_cell(v_ru_24x1_24812_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24800);
      heff_drop(v_a_24809);
      heff_drop_cell(v_ru_24x1_24812_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24813);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24800);
    heff_drop(v_a_24809);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24800);
    heff_drop(v_a_24809);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24828 = heff_field(v_x1_24812, 0);
    V v_ru_24x1_24812_24Bug = heff_take_reuse_n(v_x1_24812, 1ULL, 1);
    heff_drop(v_a_24800);
    heff_drop(v_a_24809);
    return heff_tag_at_n(v_ru_24x1_24812_24Bug, TAG_Bug, 1, (V[]){v_what_24828});
  }
  default: return heff_nomatch(v_x1_24812);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args) {
  V v_d_24801 = args[0];
  V v_a_24802 = args[1];
  V v_a_24800 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24803 = heff_tr(heff_call(v_a_24802, 1, (V[]){v_d_24801}));
  switch (heff_tag_of(v_x1_24803)) {
  case TAG_Ok: {
    V v_v_24804 = heff_field(v_x1_24803, 0);
    V v_ru_24x1_24803_24Ok = heff_take_reuse_n(v_x1_24803, 1ULL, 1);
    switch (heff_tag_of(v_v_24804)) {
    case TAG_VFun: {
      heff_take_n(v_v_24804, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop_cell(v_ru_24x1_24803_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24804, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop_cell(v_ru_24x1_24803_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24804, 0ULL, 2);
      heff_drop(v_a_24800);
      heff_drop_cell(v_ru_24x1_24803_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24809 = heff_field(v_v_24804, 0);
      heff_take_n(v_v_24804, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24803_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam64, 2, 2, (V[]){v_a_24800, v_a_24809})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24804, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop_cell(v_ru_24x1_24803_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24804, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop_cell(v_ru_24x1_24803_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24804, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop_cell(v_ru_24x1_24803_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24804, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop_cell(v_ru_24x1_24803_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24804, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop_cell(v_ru_24x1_24803_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24804, 0ULL, 1);
      heff_drop(v_a_24800);
      heff_drop_cell(v_ru_24x1_24803_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24804, 0ULL, 2);
      heff_drop(v_a_24800);
      heff_drop_cell(v_ru_24x1_24803_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24800);
      heff_drop_cell(v_ru_24x1_24803_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24804);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24800);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24800);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24837 = heff_field(v_x1_24803, 0);
    V v_ru_24x1_24803_24Bug = heff_take_reuse_n(v_x1_24803, 1ULL, 1);
    heff_drop(v_a_24800);
    return heff_tag_at_n(v_ru_24x1_24803_24Bug, TAG_Bug, 1, (V[]){v_what_24837});
  }
  default: return heff_nomatch(v_x1_24803);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args) {
  V v_d_24792 = args[0];
  V v_a_24793 = args[1];
  V v_x1_24794 = heff_tr(heff_call(v_a_24793, 1, (V[]){v_d_24792}));
  switch (heff_tag_of(v_x1_24794)) {
  case TAG_Ok: {
    V v_v_24795 = heff_field(v_x1_24794, 0);
    V v_ru_24x1_24794_24Ok = heff_take_reuse_n(v_x1_24794, 1ULL, 1);
    switch (heff_tag_of(v_v_24795)) {
    case TAG_VFun: {
      heff_take_n(v_v_24795, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24794_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24795, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24794_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24795, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24794_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24800 = heff_field(v_v_24795, 0);
      heff_take_n(v_v_24795, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24794_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam63, 2, 1, (V[]){v_a_24800})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24795, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24794_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24795, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24794_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24795, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24794_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24795, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24794_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24795, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24794_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24795, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24794_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24795, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24794_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24794_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24795);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24846 = heff_field(v_x1_24794, 0);
    V v_ru_24x1_24794_24Bug = heff_take_reuse_n(v_x1_24794, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24794_24Bug, TAG_Bug, 1, (V[]){v_what_24846});
  }
  default: return heff_nomatch(v_x1_24794);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args) {
  V v_d_24850 = args[0];
  V v_a_24851 = args[1];
  V v_n_24848 = heff_env(self)[0];
  V v_a_24849 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24852 = heff_tr(heff_call(v_a_24851, 1, (V[]){v_d_24850}));
  switch (heff_tag_of(v_x1_24852)) {
  case TAG_Ok: {
    V v_v_24853 = heff_field(v_x1_24852, 0);
    V v_ru_24x1_24852_24Ok = heff_take_reuse_n(v_x1_24852, 1ULL, 1);
    switch (heff_tag_of(v_v_24853)) {
    case TAG_VFun: {
      heff_take_n(v_v_24853, 0ULL, 1);
      heff_drop(v_n_24848);
      heff_drop(v_a_24849);
      heff_drop_cell(v_ru_24x1_24852_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24853, 0ULL, 1);
      heff_drop(v_n_24848);
      heff_drop(v_a_24849);
      heff_drop_cell(v_ru_24x1_24852_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24853, 0ULL, 2);
      heff_drop(v_n_24848);
      heff_drop(v_a_24849);
      heff_drop_cell(v_ru_24x1_24852_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24858 = heff_field(v_v_24853, 0);
      heff_take_n(v_v_24853, 1ULL, 1);
      V v_t_24860;
      if (heff_intLe_c_lent(MK_INT(0LL), v_a_24858, 1)) {
        v_t_24860 = v_a_24858;
      } else {
        heff_drop(v_a_24858);
        v_t_24860 = MK_INT(0LL);
      }
      V v_j_24861 = heff_strFind(v_n_24848, v_a_24849, v_t_24860);
      V v_t_24863;
      if (heff_intLt_c_lent(v_j_24861, MK_INT(0LL), 2)) {
        heff_drop(v_j_24861);
        v_t_24863 = MK_INT(-1LL);
      } else {
        v_t_24863 = v_j_24861;
      }
      return heff_tag_at_n(v_ru_24x1_24852_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24863})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24853, 0ULL, 1);
      heff_drop(v_n_24848);
      heff_drop(v_a_24849);
      heff_drop_cell(v_ru_24x1_24852_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24853, 0ULL, 1);
      heff_drop(v_n_24848);
      heff_drop(v_a_24849);
      heff_drop_cell(v_ru_24x1_24852_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24853, 0ULL, 1);
      heff_drop(v_n_24848);
      heff_drop(v_a_24849);
      heff_drop_cell(v_ru_24x1_24852_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24853, 0ULL, 1);
      heff_drop(v_n_24848);
      heff_drop(v_a_24849);
      heff_drop_cell(v_ru_24x1_24852_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24853, 0ULL, 1);
      heff_drop(v_n_24848);
      heff_drop(v_a_24849);
      heff_drop_cell(v_ru_24x1_24852_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24853, 0ULL, 1);
      heff_drop(v_n_24848);
      heff_drop(v_a_24849);
      heff_drop_cell(v_ru_24x1_24852_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24853, 0ULL, 2);
      heff_drop(v_n_24848);
      heff_drop(v_a_24849);
      heff_drop_cell(v_ru_24x1_24852_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_n_24848);
      heff_drop(v_a_24849);
      heff_drop_cell(v_ru_24x1_24852_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24853);
    }
  }
  case TAG_Abn: {
    heff_drop(v_n_24848);
    heff_drop(v_a_24849);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_n_24848);
    heff_drop(v_a_24849);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24872 = heff_field(v_x1_24852, 0);
    V v_ru_24x1_24852_24Bug = heff_take_reuse_n(v_x1_24852, 1ULL, 1);
    heff_drop(v_n_24848);
    heff_drop(v_a_24849);
    return heff_tag_at_n(v_ru_24x1_24852_24Bug, TAG_Bug, 1, (V[]){v_what_24872});
  }
  default: return heff_nomatch(v_x1_24852);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args) {
  V v_n_24848 = args[0];
  V v_a_24849 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam66, 2, 2, (V[]){v_n_24848, v_a_24849})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args) {
  V v_d_24886 = args[0];
  V v_a_24887 = args[1];
  V v_a_24885 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24888 = heff_tr(heff_call(v_a_24887, 1, (V[]){v_d_24886}));
  switch (heff_tag_of(v_x1_24888)) {
  case TAG_Ok: {
    V v_v_24889 = heff_field(v_x1_24888, 0);
    V v_ru_24x1_24888_24Ok = heff_take_reuse_n(v_x1_24888, 1ULL, 1);
    switch (heff_tag_of(v_v_24889)) {
    case TAG_VFun: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop(v_a_24885);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop(v_a_24885);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24889, 0ULL, 2);
      heff_drop(v_a_24885);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24894 = heff_field(v_v_24889, 0);
      V v_ru_24v_24889_24VInt = heff_take_reuse_n(v_v_24889, 1ULL, 1);
      V v_t_24895 = heff_tag_at_n(v_ru_24v_24889_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_24885, v_a_24894)});
      return heff_tag_at_n(v_ru_24x1_24888_24Ok, TAG_Ok, 1, (V[]){v_t_24895});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24889, 0ULL, 1);
      heff_drop(v_a_24885);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop(v_a_24885);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop(v_a_24885);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop(v_a_24885);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop(v_a_24885);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop(v_a_24885);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24889, 0ULL, 2);
      heff_drop(v_a_24885);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24885);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24889);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24885);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24885);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24904 = heff_field(v_x1_24888, 0);
    V v_ru_24x1_24888_24Bug = heff_take_reuse_n(v_x1_24888, 1ULL, 1);
    heff_drop(v_a_24885);
    return heff_tag_at_n(v_ru_24x1_24888_24Bug, TAG_Bug, 1, (V[]){v_what_24904});
  }
  default: return heff_nomatch(v_x1_24888);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args) {
  V v_d_24874 = args[0];
  V v_a_24875 = args[1];
  V v_x1_24876 = heff_tr(heff_call(v_a_24875, 1, (V[]){v_d_24874}));
  switch (heff_tag_of(v_x1_24876)) {
  case TAG_Ok: {
    V v_v_24877 = heff_field(v_x1_24876, 0);
    V v_ru_24x1_24876_24Ok = heff_take_reuse_n(v_x1_24876, 1ULL, 1);
    switch (heff_tag_of(v_v_24877)) {
    case TAG_VFun: {
      heff_take_n(v_v_24877, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24876_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24877, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24876_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24877, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24876_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24877, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24876_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24877, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24876_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24877, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24876_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24885 = heff_field(v_v_24877, 0);
      heff_take_n(v_v_24877, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24876_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam68, 2, 1, (V[]){v_a_24885})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24877, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24876_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24877, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24876_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24877, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24876_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24877, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24876_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24876_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24877);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24910 = heff_field(v_x1_24876, 0);
    V v_ru_24x1_24876_24Bug = heff_take_reuse_n(v_x1_24876, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24876_24Bug, TAG_Bug, 1, (V[]){v_what_24910});
  }
  default: return heff_nomatch(v_x1_24876);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args) {
  V v_d_24912 = args[0];
  V v_a_24913 = args[1];
  V v_x1_24914 = heff_tr(heff_call(v_a_24913, 1, (V[]){v_d_24912}));
  switch (heff_tag_of(v_x1_24914)) {
  case TAG_Ok: {
    V v_v_24915 = heff_field(v_x1_24914, 0);
    V v_ru_24x1_24914_24Ok = heff_take_reuse_n(v_x1_24914, 1ULL, 1);
    switch (heff_tag_of(v_v_24915)) {
    case TAG_VFun: {
      heff_take_n(v_v_24915, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24914_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24915, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24914_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24915, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24914_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24920 = heff_field(v_v_24915, 0);
      heff_take_n(v_v_24915, 1ULL, 1);
      V v_t_24921 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_a_24920)));
      return heff_tag_at_n(v_ru_24x1_24914_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_24921})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24915, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24914_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24915, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24914_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24915, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24914_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24915, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24914_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24915, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24914_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24915, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24914_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24915, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24914_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24914_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24915);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24930 = heff_field(v_x1_24914, 0);
    V v_ru_24x1_24914_24Bug = heff_take_reuse_n(v_x1_24914, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24914_24Bug, TAG_Bug, 1, (V[]){v_what_24930});
  }
  default: return heff_nomatch(v_x1_24914);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args) {
  V v_d_24944 = args[0];
  V v_a_24945 = args[1];
  V v_a_24943 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24946 = heff_tr(heff_call(v_a_24945, 1, (V[]){v_d_24944}));
  switch (heff_tag_of(v_x1_24946)) {
  case TAG_Ok: {
    V v_v_24947 = heff_field(v_x1_24946, 0);
    V v_ru_24x1_24946_24Ok = heff_take_reuse_n(v_x1_24946, 1ULL, 1);
    switch (heff_tag_of(v_v_24947)) {
    case TAG_VFun: {
      heff_take_n(v_v_24947, 0ULL, 1);
      heff_drop(v_a_24943);
      heff_drop_cell(v_ru_24x1_24946_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24947, 0ULL, 1);
      heff_drop(v_a_24943);
      heff_drop_cell(v_ru_24x1_24946_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24947, 0ULL, 2);
      heff_drop(v_a_24943);
      heff_drop_cell(v_ru_24x1_24946_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24952 = heff_field(v_v_24947, 0);
      heff_take_n(v_v_24947, 1ULL, 1);
      V v_t_24953 = heff_runeToInt(heff_strRuneAt(v_a_24943, v_a_24952));
      return heff_tag_at_n(v_ru_24x1_24946_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VRune, 1, (V[]){v_t_24953})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24947, 0ULL, 1);
      heff_drop(v_a_24943);
      heff_drop_cell(v_ru_24x1_24946_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24947, 0ULL, 1);
      heff_drop(v_a_24943);
      heff_drop_cell(v_ru_24x1_24946_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24947, 0ULL, 1);
      heff_drop(v_a_24943);
      heff_drop_cell(v_ru_24x1_24946_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24947, 0ULL, 1);
      heff_drop(v_a_24943);
      heff_drop_cell(v_ru_24x1_24946_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24947, 0ULL, 1);
      heff_drop(v_a_24943);
      heff_drop_cell(v_ru_24x1_24946_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24947, 0ULL, 1);
      heff_drop(v_a_24943);
      heff_drop_cell(v_ru_24x1_24946_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24947, 0ULL, 2);
      heff_drop(v_a_24943);
      heff_drop_cell(v_ru_24x1_24946_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24943);
      heff_drop_cell(v_ru_24x1_24946_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24947);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24943);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24943);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24962 = heff_field(v_x1_24946, 0);
    V v_ru_24x1_24946_24Bug = heff_take_reuse_n(v_x1_24946, 1ULL, 1);
    heff_drop(v_a_24943);
    return heff_tag_at_n(v_ru_24x1_24946_24Bug, TAG_Bug, 1, (V[]){v_what_24962});
  }
  default: return heff_nomatch(v_x1_24946);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args) {
  V v_d_24932 = args[0];
  V v_a_24933 = args[1];
  V v_x1_24934 = heff_tr(heff_call(v_a_24933, 1, (V[]){v_d_24932}));
  switch (heff_tag_of(v_x1_24934)) {
  case TAG_Ok: {
    V v_v_24935 = heff_field(v_x1_24934, 0);
    V v_ru_24x1_24934_24Ok = heff_take_reuse_n(v_x1_24934, 1ULL, 1);
    switch (heff_tag_of(v_v_24935)) {
    case TAG_VFun: {
      heff_take_n(v_v_24935, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24934_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24935, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24934_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24935, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24934_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24935, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24934_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24935, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24934_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24935, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24934_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24943 = heff_field(v_v_24935, 0);
      heff_take_n(v_v_24935, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24934_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam71, 2, 1, (V[]){v_a_24943})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24935, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24934_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24935, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24934_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24935, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24934_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24935, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24934_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24934_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24935);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24968 = heff_field(v_x1_24934, 0);
    V v_ru_24x1_24934_24Bug = heff_take_reuse_n(v_x1_24934, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24934_24Bug, TAG_Bug, 1, (V[]){v_what_24968});
  }
  default: return heff_nomatch(v_x1_24934);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args) {
  V v_d_24982 = args[0];
  V v_a_24983 = args[1];
  V v_a_24981 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24984 = heff_tr(heff_call(v_a_24983, 1, (V[]){v_d_24982}));
  switch (heff_tag_of(v_x1_24984)) {
  case TAG_Ok: {
    V v_v_24985 = heff_field(v_x1_24984, 0);
    V v_ru_24x1_24984_24Ok = heff_take_reuse_n(v_x1_24984, 1ULL, 1);
    switch (heff_tag_of(v_v_24985)) {
    case TAG_VFun: {
      heff_take_n(v_v_24985, 0ULL, 1);
      heff_drop(v_a_24981);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24985, 0ULL, 1);
      heff_drop(v_a_24981);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24985, 0ULL, 2);
      heff_drop(v_a_24981);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24990 = heff_field(v_v_24985, 0);
      V v_ru_24v_24985_24VInt = heff_take_reuse_n(v_v_24985, 1ULL, 1);
      V v_t_24991 = heff_tag_at_n(v_ru_24v_24985_24VInt, TAG_VInt, 1, (V[]){heff_strRuneWidth(v_a_24981, v_a_24990)});
      return heff_tag_at_n(v_ru_24x1_24984_24Ok, TAG_Ok, 1, (V[]){v_t_24991});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24985, 0ULL, 1);
      heff_drop(v_a_24981);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24985, 0ULL, 1);
      heff_drop(v_a_24981);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24985, 0ULL, 1);
      heff_drop(v_a_24981);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24985, 0ULL, 1);
      heff_drop(v_a_24981);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24985, 0ULL, 1);
      heff_drop(v_a_24981);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24985, 0ULL, 1);
      heff_drop(v_a_24981);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24985, 0ULL, 2);
      heff_drop(v_a_24981);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24981);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24985);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24981);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24981);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241000 = heff_field(v_x1_24984, 0);
    V v_ru_24x1_24984_24Bug = heff_take_reuse_n(v_x1_24984, 1ULL, 1);
    heff_drop(v_a_24981);
    return heff_tag_at_n(v_ru_24x1_24984_24Bug, TAG_Bug, 1, (V[]){v_what_241000});
  }
  default: return heff_nomatch(v_x1_24984);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args) {
  V v_d_24970 = args[0];
  V v_a_24971 = args[1];
  V v_x1_24972 = heff_tr(heff_call(v_a_24971, 1, (V[]){v_d_24970}));
  switch (heff_tag_of(v_x1_24972)) {
  case TAG_Ok: {
    V v_v_24973 = heff_field(v_x1_24972, 0);
    V v_ru_24x1_24972_24Ok = heff_take_reuse_n(v_x1_24972, 1ULL, 1);
    switch (heff_tag_of(v_v_24973)) {
    case TAG_VFun: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24973, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24981 = heff_field(v_v_24973, 0);
      heff_take_n(v_v_24973, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24972_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam73, 2, 1, (V[]){v_a_24981})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24973, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24973, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24972_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24973);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241006 = heff_field(v_x1_24972, 0);
    V v_ru_24x1_24972_24Bug = heff_take_reuse_n(v_x1_24972, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24972_24Bug, TAG_Bug, 1, (V[]){v_what_241006});
  }
  default: return heff_nomatch(v_x1_24972);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args) {
  V v_d_241008 = args[0];
  V v_a_241009 = args[1];
  V v_x1_241010 = heff_tr(heff_call(v_a_241009, 1, (V[]){v_d_241008}));
  switch (heff_tag_of(v_x1_241010)) {
  case TAG_Ok: {
    V v_v_241011 = heff_field(v_x1_241010, 0);
    V v_ru_24x1_241010_24Ok = heff_take_reuse_n(v_x1_241010, 1ULL, 1);
    switch (heff_tag_of(v_v_241011)) {
    case TAG_VFun: {
      heff_take_n(v_v_241011, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241011, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241011, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241011, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241011, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241011, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241019 = heff_field(v_v_241011, 0);
      V v_ru_24v_241011_24VStr = heff_take_reuse_n(v_v_241011, 1ULL, 1);
      V v_t_241020 = heff_tag_at_n(v_ru_24v_241011_24VStr, TAG_VInt, 1, (V[]){heff_strRuneCount(v_a_241019)});
      return heff_tag_at_n(v_ru_24x1_241010_24Ok, TAG_Ok, 1, (V[]){v_t_241020});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241011, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241011, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241011, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241011, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241011);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241026 = heff_field(v_x1_241010, 0);
    V v_ru_24x1_241010_24Bug = heff_take_reuse_n(v_x1_241010, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241010_24Bug, TAG_Bug, 1, (V[]){v_what_241026});
  }
  default: return heff_nomatch(v_x1_241010);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args) {
  V v_d_241028 = args[0];
  V v_a_241029 = args[1];
  V v_x1_241030 = heff_tr(heff_call(v_a_241029, 1, (V[]){v_d_241028}));
  switch (heff_tag_of(v_x1_241030)) {
  case TAG_Ok: {
    V v_v_241031 = heff_field(v_x1_241030, 0);
    V v_ru_24x1_241030_24Ok = heff_take_reuse_n(v_x1_241030, 1ULL, 1);
    switch (heff_tag_of(v_v_241031)) {
    case TAG_VFun: {
      heff_take_n(v_v_241031, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241031, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241031, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241031, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241031, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241031, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241039 = heff_field(v_v_241031, 0);
      heff_take_n(v_v_241031, 1ULL, 1);
      V v_t_241040 = heff_strOfRunes(heff_strRunes(v_a_241039));
      return heff_tag_at_n(v_ru_24x1_241030_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_241040})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241031, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241031, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241031, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241031, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241030_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241031);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241046 = heff_field(v_x1_241030, 0);
    V v_ru_24x1_241030_24Bug = heff_take_reuse_n(v_x1_241030, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241030_24Bug, TAG_Bug, 1, (V[]){v_what_241046});
  }
  default: return heff_nomatch(v_x1_241030);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args) {
  V v_d_241048 = args[0];
  V v_a_241049 = args[1];
  V v_x1_241050 = heff_tr(heff_call(v_a_241049, 1, (V[]){v_d_241048}));
  switch (heff_tag_of(v_x1_241050)) {
  case TAG_Ok: {
    V v_v_241051 = heff_field(v_x1_241050, 0);
    V v_ru_24x1_241050_24Ok = heff_take_reuse_n(v_x1_241050, 1ULL, 1);
    switch (heff_tag_of(v_v_241051)) {
    case TAG_VFun: {
      heff_take_n(v_v_241051, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241050_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241051, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241050_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241051, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241050_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241051, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241050_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241051, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241050_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241051, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241050_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241059 = heff_field(v_v_241051, 0);
      heff_take_n(v_v_241051, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241050_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_a_241059})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241051, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241050_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241051, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241050_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241051, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241050_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241051, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241050_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241050_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241051);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241065 = heff_field(v_x1_241050, 0);
    V v_ru_24x1_241050_24Bug = heff_take_reuse_n(v_x1_241050, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241050_24Bug, TAG_Bug, 1, (V[]){v_what_241065});
  }
  default: return heff_nomatch(v_x1_241050);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args) {
  V v_d_241067 = args[0];
  V v_a_241068 = args[1];
  V v_x1_241069 = heff_tr(heff_call(v_a_241068, 1, (V[]){v_d_241067}));
  switch (heff_tag_of(v_x1_241069)) {
  case TAG_Ok: {
    V v_v_241070 = heff_field(v_x1_241069, 0);
    V v_ru_24x1_241069_24Ok = heff_take_reuse_n(v_x1_241069, 1ULL, 1);
    switch (heff_tag_of(v_v_241070)) {
    case TAG_VFun: {
      heff_take_n(v_v_241070, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241070, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241070, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241070, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241070, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241070, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241070, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241070, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241070, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241081 = heff_field(v_v_241070, 0);
      V v_ru_24v_241070_24VBytes = heff_take_reuse_n(v_v_241070, 1ULL, 1);
      V v_t_241082 = heff_tag_at_n(v_ru_24v_241070_24VBytes, TAG_VInt, 1, (V[]){heff_strLength(v_a_241081)});
      return heff_tag_at_n(v_ru_24x1_241069_24Ok, TAG_Ok, 1, (V[]){v_t_241082});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241070, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241070);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241085 = heff_field(v_x1_241069, 0);
    V v_ru_24x1_241069_24Bug = heff_take_reuse_n(v_x1_241069, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241069_24Bug, TAG_Bug, 1, (V[]){v_what_241085});
  }
  default: return heff_nomatch(v_x1_241069);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args) {
  V v_d_241102 = args[0];
  V v_a_241103 = args[1];
  V v_a_241101 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241104 = heff_tr(heff_call(v_a_241103, 1, (V[]){v_d_241102}));
  switch (heff_tag_of(v_x1_241104)) {
  case TAG_Ok: {
    V v_v_241105 = heff_field(v_x1_241104, 0);
    V v_ru_24x1_241104_24Ok = heff_take_reuse_n(v_x1_241104, 1ULL, 1);
    switch (heff_tag_of(v_v_241105)) {
    case TAG_VFun: {
      heff_take_n(v_v_241105, 0ULL, 1);
      heff_drop(v_a_241101);
      heff_drop_cell(v_ru_24x1_241104_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241105, 0ULL, 1);
      heff_drop(v_a_241101);
      heff_drop_cell(v_ru_24x1_241104_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241105, 0ULL, 2);
      heff_drop(v_a_241101);
      heff_drop_cell(v_ru_24x1_241104_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241110 = heff_field(v_v_241105, 0);
      V v_ru_24v_241105_24VInt = heff_take_reuse_n(v_v_241105, 1ULL, 1);
      if (heff_intLe_c_lent(MK_INT(0LL), v_a_241110, 1)) {
        if (heff_intLt_c(heff_dup(v_a_241110), heff_strLength_lent(v_a_241101, 0))) {
          V v_t_241113 = heff_tag_at_n(v_ru_24v_241105_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_241101, v_a_241110)});
          return heff_tag_at_n(v_ru_24x1_241104_24Ok, TAG_Ok, 1, (V[]){v_t_241113});
        } else {
          heff_drop(v_a_241101);
          heff_drop_cell(v_ru_24x1_241104_24Ok, 1);
          heff_drop(v_a_241110);
          heff_drop_cell(v_ru_24v_241105_24VInt, 1);
          return NTAG(TAG_Abn);
        }
      } else {
        heff_drop(v_a_241101);
        heff_drop_cell(v_ru_24x1_241104_24Ok, 1);
        heff_drop(v_a_241110);
        heff_drop_cell(v_ru_24v_241105_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241105, 0ULL, 1);
      heff_drop(v_a_241101);
      heff_drop_cell(v_ru_24x1_241104_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241105, 0ULL, 1);
      heff_drop(v_a_241101);
      heff_drop_cell(v_ru_24x1_241104_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241105, 0ULL, 1);
      heff_drop(v_a_241101);
      heff_drop_cell(v_ru_24x1_241104_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241105, 0ULL, 1);
      heff_drop(v_a_241101);
      heff_drop_cell(v_ru_24x1_241104_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241105, 0ULL, 1);
      heff_drop(v_a_241101);
      heff_drop_cell(v_ru_24x1_241104_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241105, 0ULL, 1);
      heff_drop(v_a_241101);
      heff_drop_cell(v_ru_24x1_241104_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241105, 0ULL, 2);
      heff_drop(v_a_241101);
      heff_drop_cell(v_ru_24x1_241104_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241101);
      heff_drop_cell(v_ru_24x1_241104_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241105);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241101);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241101);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241122 = heff_field(v_x1_241104, 0);
    V v_ru_24x1_241104_24Bug = heff_take_reuse_n(v_x1_241104, 1ULL, 1);
    heff_drop(v_a_241101);
    return heff_tag_at_n(v_ru_24x1_241104_24Bug, TAG_Bug, 1, (V[]){v_what_241122});
  }
  default: return heff_nomatch(v_x1_241104);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args) {
  V v_d_241087 = args[0];
  V v_a_241088 = args[1];
  V v_x1_241089 = heff_tr(heff_call(v_a_241088, 1, (V[]){v_d_241087}));
  switch (heff_tag_of(v_x1_241089)) {
  case TAG_Ok: {
    V v_v_241090 = heff_field(v_x1_241089, 0);
    V v_ru_24x1_241089_24Ok = heff_take_reuse_n(v_x1_241089, 1ULL, 1);
    switch (heff_tag_of(v_v_241090)) {
    case TAG_VFun: {
      heff_take_n(v_v_241090, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241090, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241090, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241090, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241090, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241090, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241090, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241090, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241090, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241101 = heff_field(v_v_241090, 0);
      heff_take_n(v_v_241090, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241089_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam79, 2, 1, (V[]){v_a_241101})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241090, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241090);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241125 = heff_field(v_x1_241089, 0);
    V v_ru_24x1_241089_24Bug = heff_take_reuse_n(v_x1_241089, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241089_24Bug, TAG_Bug, 1, (V[]){v_what_241125});
  }
  default: return heff_nomatch(v_x1_241089);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args) {
  V v_d_241151 = args[0];
  V v_a_241152 = args[1];
  V v_a_241141 = heff_env(self)[0];
  V v_a_241150 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241153 = heff_tr(heff_call(v_a_241152, 1, (V[]){v_d_241151}));
  switch (heff_tag_of(v_x1_241153)) {
  case TAG_Ok: {
    V v_v_241154 = heff_field(v_x1_241153, 0);
    V v_ru_24x1_241153_24Ok = heff_take_reuse_n(v_x1_241153, 1ULL, 1);
    switch (heff_tag_of(v_v_241154)) {
    case TAG_VFun: {
      heff_take_n(v_v_241154, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop(v_a_241150);
      heff_drop_cell(v_ru_24x1_241153_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241154, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop(v_a_241150);
      heff_drop_cell(v_ru_24x1_241153_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241154, 0ULL, 2);
      heff_drop(v_a_241141);
      heff_drop(v_a_241150);
      heff_drop_cell(v_ru_24x1_241153_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241159 = heff_field(v_v_241154, 0);
      V v_ru_24v_241154_24VInt = heff_take_reuse_n(v_v_241154, 1ULL, 1);
      V v_t_241160 = heff_tag_at_n(v_ru_24v_241154_24VInt, TAG_VBytes, 1, (V[]){heff_strSlice(v_a_241141, v_a_241150, v_a_241159)});
      return heff_tag_at_n(v_ru_24x1_241153_24Ok, TAG_Ok, 1, (V[]){v_t_241160});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241154, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop(v_a_241150);
      heff_drop_cell(v_ru_24x1_241153_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241154, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop(v_a_241150);
      heff_drop_cell(v_ru_24x1_241153_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241154, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop(v_a_241150);
      heff_drop_cell(v_ru_24x1_241153_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241154, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop(v_a_241150);
      heff_drop_cell(v_ru_24x1_241153_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241154, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop(v_a_241150);
      heff_drop_cell(v_ru_24x1_241153_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241154, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop(v_a_241150);
      heff_drop_cell(v_ru_24x1_241153_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241154, 0ULL, 2);
      heff_drop(v_a_241141);
      heff_drop(v_a_241150);
      heff_drop_cell(v_ru_24x1_241153_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241141);
      heff_drop(v_a_241150);
      heff_drop_cell(v_ru_24x1_241153_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241154);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241141);
    heff_drop(v_a_241150);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241141);
    heff_drop(v_a_241150);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241169 = heff_field(v_x1_241153, 0);
    V v_ru_24x1_241153_24Bug = heff_take_reuse_n(v_x1_241153, 1ULL, 1);
    heff_drop(v_a_241141);
    heff_drop(v_a_241150);
    return heff_tag_at_n(v_ru_24x1_241153_24Bug, TAG_Bug, 1, (V[]){v_what_241169});
  }
  default: return heff_nomatch(v_x1_241153);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args) {
  V v_d_241142 = args[0];
  V v_a_241143 = args[1];
  V v_a_241141 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241144 = heff_tr(heff_call(v_a_241143, 1, (V[]){v_d_241142}));
  switch (heff_tag_of(v_x1_241144)) {
  case TAG_Ok: {
    V v_v_241145 = heff_field(v_x1_241144, 0);
    V v_ru_24x1_241144_24Ok = heff_take_reuse_n(v_x1_241144, 1ULL, 1);
    switch (heff_tag_of(v_v_241145)) {
    case TAG_VFun: {
      heff_take_n(v_v_241145, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop_cell(v_ru_24x1_241144_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241145, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop_cell(v_ru_24x1_241144_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241145, 0ULL, 2);
      heff_drop(v_a_241141);
      heff_drop_cell(v_ru_24x1_241144_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241150 = heff_field(v_v_241145, 0);
      heff_take_n(v_v_241145, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241144_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam82, 2, 2, (V[]){v_a_241141, v_a_241150})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241145, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop_cell(v_ru_24x1_241144_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241145, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop_cell(v_ru_24x1_241144_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241145, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop_cell(v_ru_24x1_241144_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241145, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop_cell(v_ru_24x1_241144_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241145, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop_cell(v_ru_24x1_241144_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241145, 0ULL, 1);
      heff_drop(v_a_241141);
      heff_drop_cell(v_ru_24x1_241144_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241145, 0ULL, 2);
      heff_drop(v_a_241141);
      heff_drop_cell(v_ru_24x1_241144_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241141);
      heff_drop_cell(v_ru_24x1_241144_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241145);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241141);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241141);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241178 = heff_field(v_x1_241144, 0);
    V v_ru_24x1_241144_24Bug = heff_take_reuse_n(v_x1_241144, 1ULL, 1);
    heff_drop(v_a_241141);
    return heff_tag_at_n(v_ru_24x1_241144_24Bug, TAG_Bug, 1, (V[]){v_what_241178});
  }
  default: return heff_nomatch(v_x1_241144);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args) {
  V v_d_241127 = args[0];
  V v_a_241128 = args[1];
  V v_x1_241129 = heff_tr(heff_call(v_a_241128, 1, (V[]){v_d_241127}));
  switch (heff_tag_of(v_x1_241129)) {
  case TAG_Ok: {
    V v_v_241130 = heff_field(v_x1_241129, 0);
    V v_ru_24x1_241129_24Ok = heff_take_reuse_n(v_x1_241129, 1ULL, 1);
    switch (heff_tag_of(v_v_241130)) {
    case TAG_VFun: {
      heff_take_n(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241130, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241141 = heff_field(v_v_241130, 0);
      heff_take_n(v_v_241130, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241129_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam81, 2, 1, (V[]){v_a_241141})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241130, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241130);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241181 = heff_field(v_x1_241129, 0);
    V v_ru_24x1_241129_24Bug = heff_take_reuse_n(v_x1_241129, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241129_24Bug, TAG_Bug, 1, (V[]){v_what_241181});
  }
  default: return heff_nomatch(v_x1_241129);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args) {
  V v_d_241184 = args[0];
  V v_l_241185 = args[1];
  V v_x1_241186 = heff_tr(heff_call(v_l_241185, 1, (V[]){v_d_241184}));
  switch (heff_tag_of(v_x1_241186)) {
  case TAG_Ok: {
    V v_v_241187 = heff_field(v_x1_241186, 0);
    heff_take_n(v_x1_241186, 1ULL, 1);
    V v_t_241188 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241187, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_241188; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str85); V r_ = (g_heff_2ecompile_2einterp_2ebytesJoined(a_0, a_1)); heff_drop(v_t_241188); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241189 = heff_field(v_x1_241186, 0);
    V v_ru_24x1_241186_24Bug = heff_take_reuse_n(v_x1_241186, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241186_24Bug, TAG_Bug, 1, (V[]){v_what_241189});
  }
  default: return heff_nomatch(v_x1_241186);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args) {
  V v_a_241191 = args[0];
  V v_b_241192 = args[1];
  V v_t_241194;
  if (heff_strEq_c(v_a_241191, v_b_241192)) {
    v_t_241194 = ((V)&g_heff_2ecompile_2einterp_2eprim_str87);
  } else {
    v_t_241194 = ((V)&g_heff_2ecompile_2einterp_2eprim_str88);
  }
  V v_t_241195 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241194, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241195});
}
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args) {
  V v_d_241197 = args[0];
  V v_l_241198 = args[1];
  V v_x1_241199 = heff_tr(heff_call(v_l_241198, 1, (V[]){v_d_241197}));
  switch (heff_tag_of(v_x1_241199)) {
  case TAG_Ok: {
    V v_v_241200 = heff_field(v_x1_241199, 0);
    V v_ru_24x1_241199_24Ok = heff_take_reuse_n(v_x1_241199, 1ULL, 1);
    V v_t_241201 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241200, NTAG(TAG_Nil)));
    V v_t_241202 = ({ V a_0 = v_t_241201; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str90); V r_ = (g_heff_2ecompile_2einterp_2ebyteString(a_0, a_1)); heff_drop(v_t_241201); r_; });
    return heff_tag_at_n(v_ru_24x1_241199_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_t_241202})});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241203 = heff_field(v_x1_241199, 0);
    V v_ru_24x1_241199_24Bug = heff_take_reuse_n(v_x1_241199, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241199_24Bug, TAG_Bug, 1, (V[]){v_what_241203});
  }
  default: return heff_nomatch(v_x1_241199);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args) {
  V v_d_241205 = args[0];
  V v_a_241206 = args[1];
  V v_x1_241207 = heff_tr(heff_call(v_a_241206, 1, (V[]){v_d_241205}));
  switch (heff_tag_of(v_x1_241207)) {
  case TAG_Ok: {
    V v_v_241208 = heff_field(v_x1_241207, 0);
    V v_ru_24x1_241207_24Ok = heff_take_reuse_n(v_x1_241207, 1ULL, 1);
    switch (heff_tag_of(v_v_241208)) {
    case TAG_VFun: {
      heff_take_n(v_v_241208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241208, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241208, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241219 = heff_field(v_v_241208, 0);
      heff_take_n(v_v_241208, 1ULL, 1);
      int64_t v_t_241220 = (heff_unbox_word(heff_strLength_lent(v_a_241219, 0)) - ((int64_t)1ULL));
      V v_t_241221 = ({ V a_0 = v_a_241219; V a_1 = MK_INT(0LL); V a_2 = heff_box_word(v_t_241220); V r_ = (g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(a_0, a_1, a_2)); heff_drop(v_a_241219); r_; });
      return heff_tag_at_n(v_ru_24x1_241207_24Ok, TAG_Ok, 1, (V[]){v_t_241221});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241208, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241207_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241208);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241224 = heff_field(v_x1_241207, 0);
    V v_ru_24x1_241207_24Bug = heff_take_reuse_n(v_x1_241207, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241207_24Bug, TAG_Bug, 1, (V[]){v_what_241224});
  }
  default: return heff_nomatch(v_x1_241207);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args) {
  V v_d_241226 = args[0];
  V v_a_241227 = args[1];
  V v_x1_241228 = heff_tr(heff_call(v_a_241227, 1, (V[]){v_d_241226}));
  switch (heff_tag_of(v_x1_241228)) {
  case TAG_Ok: {
    V v_v_241229 = heff_field(v_x1_241228, 0);
    V v_ru_24x1_241228_24Ok = heff_take_reuse_n(v_x1_241228, 1ULL, 1);
    switch (heff_tag_of(v_v_241229)) {
    case TAG_VFun: {
      heff_take_n(v_v_241229, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241228_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241229, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241228_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241229, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241228_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241229, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241228_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241229, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241228_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241229, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241228_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241237 = heff_field(v_v_241229, 0);
      heff_take_n(v_v_241229, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241228_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_a_241237})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241229, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241228_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241229, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241228_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241229, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241228_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241229, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241228_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241228_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241229);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241243 = heff_field(v_x1_241228, 0);
    V v_ru_24x1_241228_24Bug = heff_take_reuse_n(v_x1_241228, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241228_24Bug, TAG_Bug, 1, (V[]){v_what_241243});
  }
  default: return heff_nomatch(v_x1_241228);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args) {
  V v_d_241245 = args[0];
  V v_a_241246 = args[1];
  V v_x1_241247 = heff_tr(heff_call(v_a_241246, 1, (V[]){v_d_241245}));
  switch (heff_tag_of(v_x1_241247)) {
  case TAG_Ok: {
    V v_v_241248 = heff_field(v_x1_241247, 0);
    V v_ru_24x1_241247_24Ok = heff_take_reuse_n(v_x1_241247, 1ULL, 1);
    switch (heff_tag_of(v_v_241248)) {
    case TAG_VFun: {
      heff_take_n(v_v_241248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241248, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241248, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241259 = heff_field(v_v_241248, 0);
      heff_take_n(v_v_241248, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241247_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_a_241259})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241248, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241247_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241248);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241262 = heff_field(v_x1_241247, 0);
    V v_ru_24x1_241247_24Bug = heff_take_reuse_n(v_x1_241247, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241247_24Bug, TAG_Bug, 1, (V[]){v_what_241262});
  }
  default: return heff_nomatch(v_x1_241247);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args) {
  V v_d_241264 = args[0];
  V v_a_241265 = args[1];
  V v_x1_241266 = heff_tr(heff_call(v_a_241265, 1, (V[]){v_d_241264}));
  switch (heff_tag_of(v_x1_241266)) {
  case TAG_Ok: {
    V v_v_241267 = heff_field(v_x1_241266, 0);
    V v_ru_24x1_241266_24Ok = heff_take_reuse_n(v_x1_241266, 1ULL, 1);
    switch (heff_tag_of(v_v_241267)) {
    case TAG_VFun: {
      heff_take_n(v_v_241267, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241266_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241267, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241266_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241267, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241266_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241267, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241266_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241267, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241266_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241267, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241266_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241267, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241266_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241267, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241266_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241267, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241266_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241278 = heff_field(v_v_241267, 0);
      heff_take_n(v_v_241267, 1ULL, 1);
      V v_t_241279 = (g_rune_2evalidFrom(v_a_241278, MK_INT(0LL)));
      V v_t_241280;
      if ((heff_dup(v_t_241279) == NTAG(TAG_True))) {
        heff_drop(v_t_241279);
        v_t_241280 = v_a_241278;
      } else {
        heff_drop(v_t_241279);
        v_t_241280 = heff_strOfRunes(heff_strRunes(v_a_241278));
      }
      return heff_tag_at_n(v_ru_24x1_241266_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_241280})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241267, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241266_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241266_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241267);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241283 = heff_field(v_x1_241266, 0);
    V v_ru_24x1_241266_24Bug = heff_take_reuse_n(v_x1_241266, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241266_24Bug, TAG_Bug, 1, (V[]){v_what_241283});
  }
  default: return heff_nomatch(v_x1_241266);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args) {
  V v_d_241318 = args[0];
  V v_a_241319 = args[1];
  V v_a_241299 = heff_env(self)[0];
  V v_a_241308 = heff_env(self)[1];
  V v_a_241317 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241320 = heff_tr(heff_call(v_a_241319, 1, (V[]){v_d_241318}));
  switch (heff_tag_of(v_x1_241320)) {
  case TAG_Ok: {
    V v_v_241321 = heff_field(v_x1_241320, 0);
    heff_take_n(v_x1_241320, 1ULL, 1);
    switch (heff_tag_of(v_v_241321)) {
    case TAG_VFun: {
      heff_take_n(v_v_241321, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop(v_a_241317);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241321, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop(v_a_241317);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241321, 0ULL, 2);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop(v_a_241317);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241326 = heff_field(v_v_241321, 0);
      heff_take_n(v_v_241321, 1ULL, 1);
      V v_t_241327 = heff_intMul(heff_strLength_lent(v_a_241299, 0), MK_INT(8LL));
      return ({ V a_0 = v_a_241299; V a_1 = v_t_241327; V a_2 = v_a_241308; V a_3 = v_a_241317; V a_4 = v_a_241326; V r_ = (g_heff_2ecompile_2einterp_2eintAtV(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_a_241299); r_; });
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241321, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop(v_a_241317);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241321, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop(v_a_241317);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241321, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop(v_a_241317);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241321, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop(v_a_241317);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241321, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop(v_a_241317);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241321, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop(v_a_241317);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241321, 0ULL, 2);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop(v_a_241317);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop(v_a_241317);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241321);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241299);
    heff_drop(v_a_241308);
    heff_drop(v_a_241317);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241299);
    heff_drop(v_a_241308);
    heff_drop(v_a_241317);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241336 = heff_field(v_x1_241320, 0);
    V v_ru_24x1_241320_24Bug = heff_take_reuse_n(v_x1_241320, 1ULL, 1);
    heff_drop(v_a_241299);
    heff_drop(v_a_241308);
    heff_drop(v_a_241317);
    return heff_tag_at_n(v_ru_24x1_241320_24Bug, TAG_Bug, 1, (V[]){v_what_241336});
  }
  default: return heff_nomatch(v_x1_241320);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args) {
  V v_d_241309 = args[0];
  V v_a_241310 = args[1];
  V v_a_241299 = heff_env(self)[0];
  V v_a_241308 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241311 = heff_tr(heff_call(v_a_241310, 1, (V[]){v_d_241309}));
  switch (heff_tag_of(v_x1_241311)) {
  case TAG_Ok: {
    V v_v_241312 = heff_field(v_x1_241311, 0);
    V v_ru_24x1_241311_24Ok = heff_take_reuse_n(v_x1_241311, 1ULL, 1);
    switch (heff_tag_of(v_v_241312)) {
    case TAG_VFun: {
      heff_take_n(v_v_241312, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop_cell(v_ru_24x1_241311_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241312, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop_cell(v_ru_24x1_241311_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241312, 0ULL, 2);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop_cell(v_ru_24x1_241311_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241317 = heff_field(v_v_241312, 0);
      heff_take_n(v_v_241312, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241311_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam93, 2, 3, (V[]){v_a_241299, v_a_241308, v_a_241317})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241312, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop_cell(v_ru_24x1_241311_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241312, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop_cell(v_ru_24x1_241311_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241312, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop_cell(v_ru_24x1_241311_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241312, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop_cell(v_ru_24x1_241311_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241312, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop_cell(v_ru_24x1_241311_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241312, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop_cell(v_ru_24x1_241311_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241312, 0ULL, 2);
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop_cell(v_ru_24x1_241311_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241299);
      heff_drop(v_a_241308);
      heff_drop_cell(v_ru_24x1_241311_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241312);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241299);
    heff_drop(v_a_241308);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241299);
    heff_drop(v_a_241308);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241345 = heff_field(v_x1_241311, 0);
    V v_ru_24x1_241311_24Bug = heff_take_reuse_n(v_x1_241311, 1ULL, 1);
    heff_drop(v_a_241299);
    heff_drop(v_a_241308);
    return heff_tag_at_n(v_ru_24x1_241311_24Bug, TAG_Bug, 1, (V[]){v_what_241345});
  }
  default: return heff_nomatch(v_x1_241311);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args) {
  V v_d_241300 = args[0];
  V v_a_241301 = args[1];
  V v_a_241299 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241302 = heff_tr(heff_call(v_a_241301, 1, (V[]){v_d_241300}));
  switch (heff_tag_of(v_x1_241302)) {
  case TAG_Ok: {
    V v_v_241303 = heff_field(v_x1_241302, 0);
    V v_ru_24x1_241302_24Ok = heff_take_reuse_n(v_x1_241302, 1ULL, 1);
    switch (heff_tag_of(v_v_241303)) {
    case TAG_VFun: {
      heff_take_n(v_v_241303, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop_cell(v_ru_24x1_241302_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241303, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop_cell(v_ru_24x1_241302_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241303, 0ULL, 2);
      heff_drop(v_a_241299);
      heff_drop_cell(v_ru_24x1_241302_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241308 = heff_field(v_v_241303, 0);
      heff_take_n(v_v_241303, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241302_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam92, 2, 2, (V[]){v_a_241299, v_a_241308})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241303, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop_cell(v_ru_24x1_241302_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241303, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop_cell(v_ru_24x1_241302_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241303, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop_cell(v_ru_24x1_241302_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241303, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop_cell(v_ru_24x1_241302_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241303, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop_cell(v_ru_24x1_241302_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241303, 0ULL, 1);
      heff_drop(v_a_241299);
      heff_drop_cell(v_ru_24x1_241302_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241303, 0ULL, 2);
      heff_drop(v_a_241299);
      heff_drop_cell(v_ru_24x1_241302_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241299);
      heff_drop_cell(v_ru_24x1_241302_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241303);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241299);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241299);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241354 = heff_field(v_x1_241302, 0);
    V v_ru_24x1_241302_24Bug = heff_take_reuse_n(v_x1_241302, 1ULL, 1);
    heff_drop(v_a_241299);
    return heff_tag_at_n(v_ru_24x1_241302_24Bug, TAG_Bug, 1, (V[]){v_what_241354});
  }
  default: return heff_nomatch(v_x1_241302);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args) {
  V v_d_241285 = args[0];
  V v_a_241286 = args[1];
  V v_x1_241287 = heff_tr(heff_call(v_a_241286, 1, (V[]){v_d_241285}));
  switch (heff_tag_of(v_x1_241287)) {
  case TAG_Ok: {
    V v_v_241288 = heff_field(v_x1_241287, 0);
    V v_ru_24x1_241287_24Ok = heff_take_reuse_n(v_x1_241287, 1ULL, 1);
    switch (heff_tag_of(v_v_241288)) {
    case TAG_VFun: {
      heff_take_n(v_v_241288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241288, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241288, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241299 = heff_field(v_v_241288, 0);
      heff_take_n(v_v_241288, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241287_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam91, 2, 1, (V[]){v_a_241299})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241288, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241287_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241288);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241357 = heff_field(v_x1_241287, 0);
    V v_ru_24x1_241287_24Bug = heff_take_reuse_n(v_x1_241287, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241287_24Bug, TAG_Bug, 1, (V[]){v_what_241357});
  }
  default: return heff_nomatch(v_x1_241287);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args) {
  V v_d_241377 = args[0];
  V v_a_241378 = args[1];
  V v_a_241367 = heff_env(self)[0];
  V v_a_241376 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241379 = heff_tr(heff_call(v_a_241378, 1, (V[]){v_d_241377}));
  switch (heff_tag_of(v_x1_241379)) {
  case TAG_Ok: {
    V v_v_241380 = heff_field(v_x1_241379, 0);
    heff_take_n(v_x1_241379, 1ULL, 1);
    switch (heff_tag_of(v_v_241380)) {
    case TAG_VFun: {
      heff_take_n(v_v_241380, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop(v_a_241376);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241380, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop(v_a_241376);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241380, 0ULL, 2);
      heff_drop(v_a_241367);
      heff_drop(v_a_241376);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241385 = heff_field(v_v_241380, 0);
      heff_take_n(v_v_241380, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2ebytesOfIntV(v_a_241367, v_a_241376, v_a_241385));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241380, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop(v_a_241376);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241380, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop(v_a_241376);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241380, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop(v_a_241376);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241380, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop(v_a_241376);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241380, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop(v_a_241376);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241380, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop(v_a_241376);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241380, 0ULL, 2);
      heff_drop(v_a_241367);
      heff_drop(v_a_241376);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241367);
      heff_drop(v_a_241376);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241380);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241367);
    heff_drop(v_a_241376);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241367);
    heff_drop(v_a_241376);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241394 = heff_field(v_x1_241379, 0);
    V v_ru_24x1_241379_24Bug = heff_take_reuse_n(v_x1_241379, 1ULL, 1);
    heff_drop(v_a_241367);
    heff_drop(v_a_241376);
    return heff_tag_at_n(v_ru_24x1_241379_24Bug, TAG_Bug, 1, (V[]){v_what_241394});
  }
  default: return heff_nomatch(v_x1_241379);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args) {
  V v_d_241368 = args[0];
  V v_a_241369 = args[1];
  V v_a_241367 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241370 = heff_tr(heff_call(v_a_241369, 1, (V[]){v_d_241368}));
  switch (heff_tag_of(v_x1_241370)) {
  case TAG_Ok: {
    V v_v_241371 = heff_field(v_x1_241370, 0);
    V v_ru_24x1_241370_24Ok = heff_take_reuse_n(v_x1_241370, 1ULL, 1);
    switch (heff_tag_of(v_v_241371)) {
    case TAG_VFun: {
      heff_take_n(v_v_241371, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop_cell(v_ru_24x1_241370_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241371, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop_cell(v_ru_24x1_241370_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241371, 0ULL, 2);
      heff_drop(v_a_241367);
      heff_drop_cell(v_ru_24x1_241370_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241376 = heff_field(v_v_241371, 0);
      heff_take_n(v_v_241371, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241370_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam96, 2, 2, (V[]){v_a_241367, v_a_241376})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241371, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop_cell(v_ru_24x1_241370_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241371, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop_cell(v_ru_24x1_241370_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241371, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop_cell(v_ru_24x1_241370_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241371, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop_cell(v_ru_24x1_241370_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241371, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop_cell(v_ru_24x1_241370_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241371, 0ULL, 1);
      heff_drop(v_a_241367);
      heff_drop_cell(v_ru_24x1_241370_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241371, 0ULL, 2);
      heff_drop(v_a_241367);
      heff_drop_cell(v_ru_24x1_241370_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241367);
      heff_drop_cell(v_ru_24x1_241370_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241371);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241367);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241367);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241403 = heff_field(v_x1_241370, 0);
    V v_ru_24x1_241370_24Bug = heff_take_reuse_n(v_x1_241370, 1ULL, 1);
    heff_drop(v_a_241367);
    return heff_tag_at_n(v_ru_24x1_241370_24Bug, TAG_Bug, 1, (V[]){v_what_241403});
  }
  default: return heff_nomatch(v_x1_241370);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args) {
  V v_d_241359 = args[0];
  V v_a_241360 = args[1];
  V v_x1_241361 = heff_tr(heff_call(v_a_241360, 1, (V[]){v_d_241359}));
  switch (heff_tag_of(v_x1_241361)) {
  case TAG_Ok: {
    V v_v_241362 = heff_field(v_x1_241361, 0);
    V v_ru_24x1_241361_24Ok = heff_take_reuse_n(v_x1_241361, 1ULL, 1);
    switch (heff_tag_of(v_v_241362)) {
    case TAG_VFun: {
      heff_take_n(v_v_241362, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241361_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241362, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241361_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241362, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241361_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241367 = heff_field(v_v_241362, 0);
      heff_take_n(v_v_241362, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241361_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam95, 2, 1, (V[]){v_a_241367})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241362, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241361_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241362, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241361_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241362, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241361_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241362, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241361_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241362, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241361_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241362, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241361_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241362, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241361_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241361_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241362);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241412 = heff_field(v_x1_241361, 0);
    V v_ru_24x1_241361_24Bug = heff_take_reuse_n(v_x1_241361, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241361_24Bug, TAG_Bug, 1, (V[]){v_what_241412});
  }
  default: return heff_nomatch(v_x1_241361);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args) {
  V v_d_241438 = args[0];
  V v_a_241439 = args[1];
  V v_a_241437 = heff_env(self)[0];
  V v_a_241428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241440 = heff_tr(heff_call(v_a_241439, 1, (V[]){v_d_241438}));
  switch (heff_tag_of(v_x1_241440)) {
  case TAG_Ok: {
    V v_v_241441 = heff_field(v_x1_241440, 0);
    V v_ru_24x1_241440_24Ok = heff_take_reuse_n(v_x1_241440, 1ULL, 1);
    switch (heff_tag_of(v_v_241441)) {
    case TAG_VFun: {
      heff_take_n(v_v_241441, 0ULL, 1);
      heff_drop(v_a_241437);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241440_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241441, 0ULL, 1);
      heff_drop(v_a_241437);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241440_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241441, 0ULL, 2);
      heff_drop(v_a_241437);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241440_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241441, 0ULL, 1);
      heff_drop(v_a_241437);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241440_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241441, 0ULL, 1);
      heff_drop(v_a_241437);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241440_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241441, 0ULL, 1);
      heff_drop(v_a_241437);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241440_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241441, 0ULL, 1);
      heff_drop(v_a_241437);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241440_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241441, 0ULL, 1);
      heff_drop(v_a_241437);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241440_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241441, 0ULL, 1);
      heff_drop(v_a_241437);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241440_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241452 = heff_field(v_v_241441, 0);
      heff_take_n(v_v_241441, 1ULL, 1);
      V v_t_241459;
      if (heff_intLe_c_lent(MK_INT(0LL), v_a_241437, 1)) {
        V v_t_241454 = heff_intAdd(heff_dup(v_a_241437), heff_strLength_lent(v_a_241452, 0));
        if (heff_intLe_c(v_t_241454, heff_strLength_lent(v_a_241428, 0))) {
          V v_t_241456 = heff_intAdd(heff_dup(v_a_241437), heff_strLength_lent(v_a_241452, 0));
          V v_t_241458;
          if (heff_strEq_c(heff_strSlice(v_a_241428, v_a_241437, v_t_241456), v_a_241452)) {
            v_t_241458 = ((V)&g_heff_2ecompile_2einterp_2eprim_str98);
          } else {
            v_t_241458 = ((V)&g_heff_2ecompile_2einterp_2eprim_str99);
          }
          v_t_241459 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241458, NTAG(TAG_Nil)});
        } else {
          heff_drop(v_a_241437);
          heff_drop(v_a_241428);
          heff_drop(v_a_241452);
          v_t_241459 = heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str100), NTAG(TAG_Nil)});
        }
      } else {
        heff_drop(v_a_241437);
        heff_drop(v_a_241428);
        heff_drop(v_a_241452);
        v_t_241459 = heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str101), NTAG(TAG_Nil)});
      }
      return heff_tag_at_n(v_ru_24x1_241440_24Ok, TAG_Ok, 1, (V[]){v_t_241459});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241441, 0ULL, 2);
      heff_drop(v_a_241437);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241440_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241437);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241440_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241441);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241437);
    heff_drop(v_a_241428);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241437);
    heff_drop(v_a_241428);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241462 = heff_field(v_x1_241440, 0);
    V v_ru_24x1_241440_24Bug = heff_take_reuse_n(v_x1_241440, 1ULL, 1);
    heff_drop(v_a_241437);
    heff_drop(v_a_241428);
    return heff_tag_at_n(v_ru_24x1_241440_24Bug, TAG_Bug, 1, (V[]){v_what_241462});
  }
  default: return heff_nomatch(v_x1_241440);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args) {
  V v_d_241429 = args[0];
  V v_a_241430 = args[1];
  V v_a_241428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241431 = heff_tr(heff_call(v_a_241430, 1, (V[]){v_d_241429}));
  switch (heff_tag_of(v_x1_241431)) {
  case TAG_Ok: {
    V v_v_241432 = heff_field(v_x1_241431, 0);
    V v_ru_24x1_241431_24Ok = heff_take_reuse_n(v_x1_241431, 1ULL, 1);
    switch (heff_tag_of(v_v_241432)) {
    case TAG_VFun: {
      heff_take_n(v_v_241432, 0ULL, 1);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241431_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241432, 0ULL, 1);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241431_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241432, 0ULL, 2);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241431_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241437 = heff_field(v_v_241432, 0);
      heff_take_n(v_v_241432, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241431_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam99, 2, 2, (V[]){v_a_241437, v_a_241428})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241432, 0ULL, 1);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241431_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241432, 0ULL, 1);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241431_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241432, 0ULL, 1);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241431_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241432, 0ULL, 1);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241431_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241432, 0ULL, 1);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241431_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241432, 0ULL, 1);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241431_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241432, 0ULL, 2);
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241431_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241428);
      heff_drop_cell(v_ru_24x1_241431_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241432);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241428);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241428);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241471 = heff_field(v_x1_241431, 0);
    V v_ru_24x1_241431_24Bug = heff_take_reuse_n(v_x1_241431, 1ULL, 1);
    heff_drop(v_a_241428);
    return heff_tag_at_n(v_ru_24x1_241431_24Bug, TAG_Bug, 1, (V[]){v_what_241471});
  }
  default: return heff_nomatch(v_x1_241431);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args) {
  V v_d_241414 = args[0];
  V v_a_241415 = args[1];
  V v_x1_241416 = heff_tr(heff_call(v_a_241415, 1, (V[]){v_d_241414}));
  switch (heff_tag_of(v_x1_241416)) {
  case TAG_Ok: {
    V v_v_241417 = heff_field(v_x1_241416, 0);
    V v_ru_24x1_241416_24Ok = heff_take_reuse_n(v_x1_241416, 1ULL, 1);
    switch (heff_tag_of(v_v_241417)) {
    case TAG_VFun: {
      heff_take_n(v_v_241417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241417, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241417, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241428 = heff_field(v_v_241417, 0);
      heff_take_n(v_v_241417, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241416_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam98, 2, 1, (V[]){v_a_241428})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241417, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241416_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241417);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241474 = heff_field(v_x1_241416, 0);
    V v_ru_24x1_241416_24Bug = heff_take_reuse_n(v_x1_241416, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241416_24Bug, TAG_Bug, 1, (V[]){v_what_241474});
  }
  default: return heff_nomatch(v_x1_241416);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args) {
  V v_d_241497 = args[0];
  V v_a_241498 = args[1];
  V v_s_241478 = heff_env(self)[0];
  V v_m_241477 = heff_env(self)[1];
  V v_a_241487 = heff_env(self)[2];
  V v_a_241496 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_241499 = heff_tr(heff_call(v_a_241498, 1, (V[]){v_d_241497}));
  switch (heff_tag_of(v_x1_241499)) {
  case TAG_Ok: {
    V v_v_241500 = heff_field(v_x1_241499, 0);
    heff_take_n(v_x1_241499, 1ULL, 1);
    switch (heff_tag_of(v_v_241500)) {
    case TAG_VFun: {
      heff_take_n(v_v_241500, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop(v_a_241496);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241500, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop(v_a_241496);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241500, 0ULL, 2);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop(v_a_241496);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241505 = heff_field(v_v_241500, 0);
      heff_take_n(v_v_241500, 1ULL, 1);
      return ({ V a_0 = v_s_241478; V a_1 = v_m_241477; V a_2 = v_a_241487; V a_3 = v_a_241496; V a_4 = v_a_241505; V r_ = (g_heff_2ecompile_2einterp_2eintAtV(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_241478); r_; });
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241500, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop(v_a_241496);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241500, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop(v_a_241496);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241500, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop(v_a_241496);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241500, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop(v_a_241496);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241500, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop(v_a_241496);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241500, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop(v_a_241496);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241500, 0ULL, 2);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop(v_a_241496);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop(v_a_241496);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241500);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241478);
    heff_drop(v_m_241477);
    heff_drop(v_a_241487);
    heff_drop(v_a_241496);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241478);
    heff_drop(v_m_241477);
    heff_drop(v_a_241487);
    heff_drop(v_a_241496);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241514 = heff_field(v_x1_241499, 0);
    V v_ru_24x1_241499_24Bug = heff_take_reuse_n(v_x1_241499, 1ULL, 1);
    heff_drop(v_s_241478);
    heff_drop(v_m_241477);
    heff_drop(v_a_241487);
    heff_drop(v_a_241496);
    return heff_tag_at_n(v_ru_24x1_241499_24Bug, TAG_Bug, 1, (V[]){v_what_241514});
  }
  default: return heff_nomatch(v_x1_241499);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args) {
  V v_d_241488 = args[0];
  V v_a_241489 = args[1];
  V v_s_241478 = heff_env(self)[0];
  V v_m_241477 = heff_env(self)[1];
  V v_a_241487 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241490 = heff_tr(heff_call(v_a_241489, 1, (V[]){v_d_241488}));
  switch (heff_tag_of(v_x1_241490)) {
  case TAG_Ok: {
    V v_v_241491 = heff_field(v_x1_241490, 0);
    V v_ru_24x1_241490_24Ok = heff_take_reuse_n(v_x1_241490, 1ULL, 1);
    switch (heff_tag_of(v_v_241491)) {
    case TAG_VFun: {
      heff_take_n(v_v_241491, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop_cell(v_ru_24x1_241490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241491, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop_cell(v_ru_24x1_241490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241491, 0ULL, 2);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop_cell(v_ru_24x1_241490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241496 = heff_field(v_v_241491, 0);
      heff_take_n(v_v_241491, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241490_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam103, 2, 4, (V[]){v_s_241478, v_m_241477, v_a_241487, v_a_241496})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241491, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop_cell(v_ru_24x1_241490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241491, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop_cell(v_ru_24x1_241490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241491, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop_cell(v_ru_24x1_241490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241491, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop_cell(v_ru_24x1_241490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241491, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop_cell(v_ru_24x1_241490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241491, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop_cell(v_ru_24x1_241490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241491, 0ULL, 2);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop_cell(v_ru_24x1_241490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop(v_a_241487);
      heff_drop_cell(v_ru_24x1_241490_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241491);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241478);
    heff_drop(v_m_241477);
    heff_drop(v_a_241487);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241478);
    heff_drop(v_m_241477);
    heff_drop(v_a_241487);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241523 = heff_field(v_x1_241490, 0);
    V v_ru_24x1_241490_24Bug = heff_take_reuse_n(v_x1_241490, 1ULL, 1);
    heff_drop(v_s_241478);
    heff_drop(v_m_241477);
    heff_drop(v_a_241487);
    return heff_tag_at_n(v_ru_24x1_241490_24Bug, TAG_Bug, 1, (V[]){v_what_241523});
  }
  default: return heff_nomatch(v_x1_241490);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args) {
  V v_d_241479 = args[0];
  V v_a_241480 = args[1];
  V v_s_241478 = heff_env(self)[0];
  V v_m_241477 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241481 = heff_tr(heff_call(v_a_241480, 1, (V[]){v_d_241479}));
  switch (heff_tag_of(v_x1_241481)) {
  case TAG_Ok: {
    V v_v_241482 = heff_field(v_x1_241481, 0);
    V v_ru_24x1_241481_24Ok = heff_take_reuse_n(v_x1_241481, 1ULL, 1);
    switch (heff_tag_of(v_v_241482)) {
    case TAG_VFun: {
      heff_take_n(v_v_241482, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop_cell(v_ru_24x1_241481_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241482, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop_cell(v_ru_24x1_241481_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241482, 0ULL, 2);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop_cell(v_ru_24x1_241481_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241487 = heff_field(v_v_241482, 0);
      heff_take_n(v_v_241482, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241481_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam102, 2, 3, (V[]){v_s_241478, v_m_241477, v_a_241487})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241482, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop_cell(v_ru_24x1_241481_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241482, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop_cell(v_ru_24x1_241481_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241482, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop_cell(v_ru_24x1_241481_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241482, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop_cell(v_ru_24x1_241481_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241482, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop_cell(v_ru_24x1_241481_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241482, 0ULL, 1);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop_cell(v_ru_24x1_241481_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241482, 0ULL, 2);
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop_cell(v_ru_24x1_241481_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241478);
      heff_drop(v_m_241477);
      heff_drop_cell(v_ru_24x1_241481_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241482);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241478);
    heff_drop(v_m_241477);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241478);
    heff_drop(v_m_241477);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241532 = heff_field(v_x1_241481, 0);
    V v_ru_24x1_241481_24Bug = heff_take_reuse_n(v_x1_241481, 1ULL, 1);
    heff_drop(v_s_241478);
    heff_drop(v_m_241477);
    return heff_tag_at_n(v_ru_24x1_241481_24Bug, TAG_Bug, 1, (V[]){v_what_241532});
  }
  default: return heff_nomatch(v_x1_241481);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args) {
  V v_m_241477 = args[0];
  V v_s_241478 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam101, 2, 2, (V[]){v_s_241478, v_m_241477})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args) {
  V v_d_241552 = args[0];
  V v_a_241553 = args[1];
  V v_a_241542 = heff_env(self)[0];
  V v_a_241551 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241554 = heff_tr(heff_call(v_a_241553, 1, (V[]){v_d_241552}));
  switch (heff_tag_of(v_x1_241554)) {
  case TAG_Ok: {
    V v_v_241555 = heff_field(v_x1_241554, 0);
    heff_take_n(v_x1_241554, 1ULL, 1);
    switch (heff_tag_of(v_v_241555)) {
    case TAG_VFun: {
      heff_take_n(v_v_241555, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop(v_a_241551);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241555, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop(v_a_241551);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241555, 0ULL, 2);
      heff_drop(v_a_241542);
      heff_drop(v_a_241551);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241560 = heff_field(v_v_241555, 0);
      heff_take_n(v_v_241555, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2ebitsOfIntV(v_a_241542, v_a_241551, v_a_241560));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241555, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop(v_a_241551);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241555, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop(v_a_241551);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241555, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop(v_a_241551);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241555, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop(v_a_241551);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241555, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop(v_a_241551);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241555, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop(v_a_241551);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241555, 0ULL, 2);
      heff_drop(v_a_241542);
      heff_drop(v_a_241551);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241542);
      heff_drop(v_a_241551);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241555);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241542);
    heff_drop(v_a_241551);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241542);
    heff_drop(v_a_241551);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241569 = heff_field(v_x1_241554, 0);
    V v_ru_24x1_241554_24Bug = heff_take_reuse_n(v_x1_241554, 1ULL, 1);
    heff_drop(v_a_241542);
    heff_drop(v_a_241551);
    return heff_tag_at_n(v_ru_24x1_241554_24Bug, TAG_Bug, 1, (V[]){v_what_241569});
  }
  default: return heff_nomatch(v_x1_241554);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args) {
  V v_d_241543 = args[0];
  V v_a_241544 = args[1];
  V v_a_241542 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241545 = heff_tr(heff_call(v_a_241544, 1, (V[]){v_d_241543}));
  switch (heff_tag_of(v_x1_241545)) {
  case TAG_Ok: {
    V v_v_241546 = heff_field(v_x1_241545, 0);
    V v_ru_24x1_241545_24Ok = heff_take_reuse_n(v_x1_241545, 1ULL, 1);
    switch (heff_tag_of(v_v_241546)) {
    case TAG_VFun: {
      heff_take_n(v_v_241546, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop_cell(v_ru_24x1_241545_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241546, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop_cell(v_ru_24x1_241545_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241546, 0ULL, 2);
      heff_drop(v_a_241542);
      heff_drop_cell(v_ru_24x1_241545_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241551 = heff_field(v_v_241546, 0);
      heff_take_n(v_v_241546, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241545_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam106, 2, 2, (V[]){v_a_241542, v_a_241551})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241546, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop_cell(v_ru_24x1_241545_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241546, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop_cell(v_ru_24x1_241545_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241546, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop_cell(v_ru_24x1_241545_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241546, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop_cell(v_ru_24x1_241545_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241546, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop_cell(v_ru_24x1_241545_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241546, 0ULL, 1);
      heff_drop(v_a_241542);
      heff_drop_cell(v_ru_24x1_241545_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241546, 0ULL, 2);
      heff_drop(v_a_241542);
      heff_drop_cell(v_ru_24x1_241545_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241542);
      heff_drop_cell(v_ru_24x1_241545_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241546);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241542);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241542);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241578 = heff_field(v_x1_241545, 0);
    V v_ru_24x1_241545_24Bug = heff_take_reuse_n(v_x1_241545, 1ULL, 1);
    heff_drop(v_a_241542);
    return heff_tag_at_n(v_ru_24x1_241545_24Bug, TAG_Bug, 1, (V[]){v_what_241578});
  }
  default: return heff_nomatch(v_x1_241545);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args) {
  V v_d_241534 = args[0];
  V v_a_241535 = args[1];
  V v_x1_241536 = heff_tr(heff_call(v_a_241535, 1, (V[]){v_d_241534}));
  switch (heff_tag_of(v_x1_241536)) {
  case TAG_Ok: {
    V v_v_241537 = heff_field(v_x1_241536, 0);
    V v_ru_24x1_241536_24Ok = heff_take_reuse_n(v_x1_241536, 1ULL, 1);
    switch (heff_tag_of(v_v_241537)) {
    case TAG_VFun: {
      heff_take_n(v_v_241537, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241536_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241537, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241536_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241537, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241536_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241542 = heff_field(v_v_241537, 0);
      heff_take_n(v_v_241537, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241536_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam105, 2, 1, (V[]){v_a_241542})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241537, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241536_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241537, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241536_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241537, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241536_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241537, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241536_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241537, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241536_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241537, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241536_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241537, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241536_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241536_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241537);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241587 = heff_field(v_x1_241536, 0);
    V v_ru_24x1_241536_24Bug = heff_take_reuse_n(v_x1_241536, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241536_24Bug, TAG_Bug, 1, (V[]){v_what_241587});
  }
  default: return heff_nomatch(v_x1_241536);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args) {
  V v_d_241589 = args[0];
  V v_l_241590 = args[1];
  V v_x1_241591 = heff_tr(heff_call(v_l_241590, 1, (V[]){v_d_241589}));
  switch (heff_tag_of(v_x1_241591)) {
  case TAG_Ok: {
    V v_v_241592 = heff_field(v_x1_241591, 0);
    heff_take_n(v_x1_241591, 1ULL, 1);
    V v_t_241593 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241592, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_241593; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2einterp_2eprim_str106); V r_ = (g_heff_2ecompile_2einterp_2ebitsJoined(a_0, a_1, a_2)); heff_drop(v_t_241593); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241594 = heff_field(v_x1_241591, 0);
    V v_ru_24x1_241591_24Bug = heff_take_reuse_n(v_x1_241591, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241591_24Bug, TAG_Bug, 1, (V[]){v_what_241594});
  }
  default: return heff_nomatch(v_x1_241591);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam110(V self, V *args) {
  V v_d_241607 = args[0];
  V v_a_241608 = args[1];
  V v_a_241606 = heff_env(self)[0];
  V v_m_241596 = heff_env(self)[1];
  V v_s_241597 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241609 = heff_tr(heff_call(v_a_241608, 1, (V[]){v_d_241607}));
  switch (heff_tag_of(v_x1_241609)) {
  case TAG_Ok: {
    V v_v_241610 = heff_field(v_x1_241609, 0);
    V v_ru_24x1_241609_24Ok = heff_take_reuse_n(v_x1_241609, 1ULL, 1);
    switch (heff_tag_of(v_v_241610)) {
    case TAG_VFun: {
      heff_take_n(v_v_241610, 0ULL, 1);
      heff_drop(v_a_241606);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241610, 0ULL, 1);
      heff_drop(v_a_241606);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241610, 0ULL, 2);
      heff_drop(v_a_241606);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241615 = heff_field(v_v_241610, 0);
      heff_take_n(v_v_241610, 1ULL, 1);
      if (heff_intLt_c_lent(v_a_241606, MK_INT(0LL), 2)) {
        heff_drop(v_a_241606);
        heff_drop(v_m_241596);
        heff_drop(v_s_241597);
        heff_drop_cell(v_ru_24x1_241609_24Ok, 1);
        heff_drop(v_a_241615);
        return NTAG(TAG_Abn);
      } else {
        if (heff_intLt_c_lent(v_a_241615, MK_INT(0LL), 2)) {
          heff_drop(v_a_241606);
          heff_drop(v_m_241596);
          heff_drop(v_s_241597);
          heff_drop_cell(v_ru_24x1_241609_24Ok, 1);
          heff_drop(v_a_241615);
          return NTAG(TAG_Abn);
        } else {
          if (heff_intLt_c(v_m_241596, heff_intAdd(heff_dup(v_a_241606), heff_dup(v_a_241615)))) {
            heff_drop(v_a_241606);
            heff_drop(v_s_241597);
            heff_drop_cell(v_ru_24x1_241609_24Ok, 1);
            heff_drop(v_a_241615);
            return NTAG(TAG_Abn);
          } else {
            V v_t_241619 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str108); V a_2 = v_s_241597; V a_3 = heff_dup(v_a_241606); V a_4 = heff_intAdd(v_a_241606, heff_dup(v_a_241615)); V r_ = (g_heff_2ecompile_2einterp_2ebitsCopy(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_241597); r_; });
            return heff_tag_at_n(v_ru_24x1_241609_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_a_241615, v_t_241619})});
          }
        }
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241610, 0ULL, 1);
      heff_drop(v_a_241606);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241610, 0ULL, 1);
      heff_drop(v_a_241606);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241610, 0ULL, 1);
      heff_drop(v_a_241606);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241610, 0ULL, 1);
      heff_drop(v_a_241606);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241610, 0ULL, 1);
      heff_drop(v_a_241606);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241610, 0ULL, 1);
      heff_drop(v_a_241606);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241610, 0ULL, 2);
      heff_drop(v_a_241606);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241606);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241610);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241606);
    heff_drop(v_m_241596);
    heff_drop(v_s_241597);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241606);
    heff_drop(v_m_241596);
    heff_drop(v_s_241597);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241628 = heff_field(v_x1_241609, 0);
    V v_ru_24x1_241609_24Bug = heff_take_reuse_n(v_x1_241609, 1ULL, 1);
    heff_drop(v_a_241606);
    heff_drop(v_m_241596);
    heff_drop(v_s_241597);
    return heff_tag_at_n(v_ru_24x1_241609_24Bug, TAG_Bug, 1, (V[]){v_what_241628});
  }
  default: return heff_nomatch(v_x1_241609);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args) {
  V v_d_241598 = args[0];
  V v_a_241599 = args[1];
  V v_m_241596 = heff_env(self)[0];
  V v_s_241597 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241600 = heff_tr(heff_call(v_a_241599, 1, (V[]){v_d_241598}));
  switch (heff_tag_of(v_x1_241600)) {
  case TAG_Ok: {
    V v_v_241601 = heff_field(v_x1_241600, 0);
    V v_ru_24x1_241600_24Ok = heff_take_reuse_n(v_x1_241600, 1ULL, 1);
    switch (heff_tag_of(v_v_241601)) {
    case TAG_VFun: {
      heff_take_n(v_v_241601, 0ULL, 1);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241600_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241601, 0ULL, 1);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241600_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241601, 0ULL, 2);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241600_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241606 = heff_field(v_v_241601, 0);
      heff_take_n(v_v_241601, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241600_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam110, 2, 3, (V[]){v_a_241606, v_m_241596, v_s_241597})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241601, 0ULL, 1);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241600_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241601, 0ULL, 1);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241600_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241601, 0ULL, 1);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241600_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241601, 0ULL, 1);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241600_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241601, 0ULL, 1);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241600_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241601, 0ULL, 1);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241600_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241601, 0ULL, 2);
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241600_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_m_241596);
      heff_drop(v_s_241597);
      heff_drop_cell(v_ru_24x1_241600_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241601);
    }
  }
  case TAG_Abn: {
    heff_drop(v_m_241596);
    heff_drop(v_s_241597);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_m_241596);
    heff_drop(v_s_241597);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241637 = heff_field(v_x1_241600, 0);
    V v_ru_24x1_241600_24Bug = heff_take_reuse_n(v_x1_241600, 1ULL, 1);
    heff_drop(v_m_241596);
    heff_drop(v_s_241597);
    return heff_tag_at_n(v_ru_24x1_241600_24Bug, TAG_Bug, 1, (V[]){v_what_241637});
  }
  default: return heff_nomatch(v_x1_241600);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args) {
  V v_m_241596 = args[0];
  V v_s_241597 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam109, 2, 2, (V[]){v_m_241596, v_s_241597})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam111(V self, V *args) {
  V v_d_241639 = args[0];
  V v_a_241640 = args[1];
  V v_x1_241641 = heff_tr(heff_call(v_a_241640, 1, (V[]){v_d_241639}));
  switch (heff_tag_of(v_x1_241641)) {
  case TAG_Ok: {
    V v_v_241642 = heff_field(v_x1_241641, 0);
    V v_ru_24x1_241641_24Ok = heff_take_reuse_n(v_x1_241641, 1ULL, 1);
    switch (heff_tag_of(v_v_241642)) {
    case TAG_VFun: {
      heff_take_n(v_v_241642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241642, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241642, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241653 = heff_field(v_v_241642, 0);
      heff_take_n(v_v_241642, 1ULL, 1);
      V v_t_241654 = heff_intMul(heff_strLength_lent(v_a_241653, 0), MK_INT(8LL));
      return heff_tag_at_n(v_ru_24x1_241641_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_t_241654, v_a_241653})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241642, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241641_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241642);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241657 = heff_field(v_x1_241641, 0);
    V v_ru_24x1_241641_24Bug = heff_take_reuse_n(v_x1_241641, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241641_24Bug, TAG_Bug, 1, (V[]){v_what_241657});
  }
  default: return heff_nomatch(v_x1_241641);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam112(V self, V *args) {
  V v_n_241659 = args[0];
  V v_s_241660 = args[1];
  if ((heff_unbox_word(heff_intMod(v_n_241659, MK_INT(8LL))) == ((int64_t)0ULL))) {
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_s_241660})});
  } else {
    heff_drop(v_s_241660);
    return NTAG(TAG_Abn);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam114(V self, V *args) {
  V v_m_241665 = args[0];
  V v_t_241666 = args[1];
  V v_n_241663 = heff_env(self)[0];
  V v_s_241664 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_241670;
  if (heff_intEq_c(v_n_241663, v_m_241665)) {
    V v_t_241669;
    if (heff_strEq_c(v_s_241664, v_t_241666)) {
      v_t_241669 = ((V)&g_heff_2ecompile_2einterp_2eprim_str112);
    } else {
      v_t_241669 = ((V)&g_heff_2ecompile_2einterp_2eprim_str113);
    }
    v_t_241670 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241669, NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_241666);
    heff_drop(v_s_241664);
    v_t_241670 = heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str114), NTAG(TAG_Nil)});
  }
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241670});
}
V g_heff_2ecompile_2einterp_2eprim_lam113(V self, V *args) {
  V v_n_241663 = args[0];
  V v_s_241664 = args[1];
  V v_t_241671 = (g_heff_2ecompile_2einterp_2ebits1(heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam114, 2, 2, (V[]){v_n_241663, v_s_241664})));
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241671});
}
V g_heff_2ecompile_2einterp_2eprim_lam116(V self, V *args) {
  V v_d_241682 = args[0];
  V v_a_241683 = args[1];
  V v_a_241681 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241684 = heff_tr(heff_call(v_a_241683, 1, (V[]){v_d_241682}));
  switch (heff_tag_of(v_x1_241684)) {
  case TAG_Ok: {
    V v_v_241685 = heff_field(v_x1_241684, 0);
    V v_ru_24x1_241684_24Ok = heff_take_reuse_n(v_x1_241684, 1ULL, 1);
    switch (heff_tag_of(v_v_241685)) {
    case TAG_VFun: {
      heff_take_n(v_v_241685, 0ULL, 1);
      heff_drop(v_a_241681);
      heff_drop_cell(v_ru_24x1_241684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241685, 0ULL, 1);
      heff_drop(v_a_241681);
      heff_drop_cell(v_ru_24x1_241684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241685, 0ULL, 2);
      heff_drop(v_a_241681);
      heff_drop_cell(v_ru_24x1_241684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241685, 0ULL, 1);
      heff_drop(v_a_241681);
      heff_drop_cell(v_ru_24x1_241684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_241691 = heff_tflat_f64(v_v_241685, 0);
      heff_take_na(v_v_241685, 0ULL, 1);
      if (heff_intEq_c_lent(v_a_241681, MK_INT(64LL), 2)) {
        heff_drop(v_a_241681);
        V v_t_241693 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(11LL), MK_INT(52LL), v_a_241691));
        return heff_tag_at_n(v_ru_24x1_241684_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_241693})});
      } else {
        if (heff_intEq_c(v_a_241681, MK_INT(32LL))) {
          double v_t_241695 = ((double)((float)v_a_241691));
          V v_t_241696 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(8LL), MK_INT(23LL), v_t_241695));
          return heff_tag_at_n(v_ru_24x1_241684_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_241696})});
        } else {
          heff_drop_cell(v_ru_24x1_241684_24Ok, 1);
          return NTAG(TAG_Abn);
        }
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241685, 0ULL, 1);
      heff_drop(v_a_241681);
      heff_drop_cell(v_ru_24x1_241684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241685, 0ULL, 1);
      heff_drop(v_a_241681);
      heff_drop_cell(v_ru_24x1_241684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241685, 0ULL, 1);
      heff_drop(v_a_241681);
      heff_drop_cell(v_ru_24x1_241684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241685, 0ULL, 1);
      heff_drop(v_a_241681);
      heff_drop_cell(v_ru_24x1_241684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241685, 0ULL, 1);
      heff_drop(v_a_241681);
      heff_drop_cell(v_ru_24x1_241684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241685, 0ULL, 2);
      heff_drop(v_a_241681);
      heff_drop_cell(v_ru_24x1_241684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241681);
      heff_drop_cell(v_ru_24x1_241684_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_241685);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241681);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241681);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241704 = heff_field(v_x1_241684, 0);
    V v_ru_24x1_241684_24Bug = heff_take_reuse_n(v_x1_241684, 1ULL, 1);
    heff_drop(v_a_241681);
    return heff_tag_at_n(v_ru_24x1_241684_24Bug, TAG_Bug, 1, (V[]){v_what_241704});
  }
  default: return heff_nomatch(v_x1_241684);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam115(V self, V *args) {
  V v_d_241673 = args[0];
  V v_a_241674 = args[1];
  V v_x1_241675 = heff_tr(heff_call(v_a_241674, 1, (V[]){v_d_241673}));
  switch (heff_tag_of(v_x1_241675)) {
  case TAG_Ok: {
    V v_v_241676 = heff_field(v_x1_241675, 0);
    V v_ru_24x1_241675_24Ok = heff_take_reuse_n(v_x1_241675, 1ULL, 1);
    switch (heff_tag_of(v_v_241676)) {
    case TAG_VFun: {
      heff_take_n(v_v_241676, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241675_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241676, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241675_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241676, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241675_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241681 = heff_field(v_v_241676, 0);
      heff_take_n(v_v_241676, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241675_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam116, 2, 1, (V[]){v_a_241681})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241676, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241675_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241676, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241675_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241676, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241675_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241676, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241675_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241676, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241675_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241676, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241675_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241676, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241675_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241675_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241676);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241713 = heff_field(v_x1_241675, 0);
    V v_ru_24x1_241675_24Bug = heff_take_reuse_n(v_x1_241675, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241675_24Bug, TAG_Bug, 1, (V[]){v_what_241713});
  }
  default: return heff_nomatch(v_x1_241675);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam118(V self, V *args) {
  V v_d_241724 = args[0];
  V v_a_241725 = args[1];
  V v_a_241723 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241726 = heff_tr(heff_call(v_a_241725, 1, (V[]){v_d_241724}));
  switch (heff_tag_of(v_x1_241726)) {
  case TAG_Ok: {
    V v_v_241727 = heff_field(v_x1_241726, 0);
    heff_take_n(v_x1_241726, 1ULL, 1);
    switch (heff_tag_of(v_v_241727)) {
    case TAG_VFun: {
      heff_take_n(v_v_241727, 0ULL, 1);
      heff_drop(v_a_241723);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241727, 0ULL, 1);
      heff_drop(v_a_241723);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241727, 0ULL, 2);
      heff_drop(v_a_241723);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241732 = heff_field(v_v_241727, 0);
      heff_take_n(v_v_241727, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2efloatOfBitsV(v_a_241723, v_a_241732));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241727, 0ULL, 1);
      heff_drop(v_a_241723);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241727, 0ULL, 1);
      heff_drop(v_a_241723);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241727, 0ULL, 1);
      heff_drop(v_a_241723);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241727, 0ULL, 1);
      heff_drop(v_a_241723);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241727, 0ULL, 1);
      heff_drop(v_a_241723);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241727, 0ULL, 1);
      heff_drop(v_a_241723);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241727, 0ULL, 2);
      heff_drop(v_a_241723);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241723);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241727);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241723);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241723);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241741 = heff_field(v_x1_241726, 0);
    V v_ru_24x1_241726_24Bug = heff_take_reuse_n(v_x1_241726, 1ULL, 1);
    heff_drop(v_a_241723);
    return heff_tag_at_n(v_ru_24x1_241726_24Bug, TAG_Bug, 1, (V[]){v_what_241741});
  }
  default: return heff_nomatch(v_x1_241726);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam117(V self, V *args) {
  V v_d_241715 = args[0];
  V v_a_241716 = args[1];
  V v_x1_241717 = heff_tr(heff_call(v_a_241716, 1, (V[]){v_d_241715}));
  switch (heff_tag_of(v_x1_241717)) {
  case TAG_Ok: {
    V v_v_241718 = heff_field(v_x1_241717, 0);
    V v_ru_24x1_241717_24Ok = heff_take_reuse_n(v_x1_241717, 1ULL, 1);
    switch (heff_tag_of(v_v_241718)) {
    case TAG_VFun: {
      heff_take_n(v_v_241718, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241717_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241718, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241717_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241718, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241717_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241723 = heff_field(v_v_241718, 0);
      heff_take_n(v_v_241718, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241717_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam118, 2, 1, (V[]){v_a_241723})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241718, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241717_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241718, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241717_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241718, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241717_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241718, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241717_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241718, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241717_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241718, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241717_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241718, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241717_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241717_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241718);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241750 = heff_field(v_x1_241717, 0);
    V v_ru_24x1_241717_24Bug = heff_take_reuse_n(v_x1_241717, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241717_24Bug, TAG_Bug, 1, (V[]){v_what_241750});
  }
  default: return heff_nomatch(v_x1_241717);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam119(V self, V *args) {
  V v_a_241752 = args[0];
  V v_b_241753 = args[1];
  V v_t_241755;
  if (heff_intEq_c(v_a_241752, v_b_241753)) {
    v_t_241755 = ((V)&g_heff_2ecompile_2einterp_2eprim_str118);
  } else {
    v_t_241755 = ((V)&g_heff_2ecompile_2einterp_2eprim_str119);
  }
  V v_t_241756 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241755, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241756});
}
V g_heff_2ecompile_2einterp_2eprim_lam120(V self, V *args) {
  V v_a_241758 = args[0];
  V v_b_241759 = args[1];
  V v_t_241761;
  if (heff_intLt_c(v_a_241758, v_b_241759)) {
    v_t_241761 = ((V)&g_heff_2ecompile_2einterp_2eprim_str121);
  } else {
    v_t_241761 = ((V)&g_heff_2ecompile_2einterp_2eprim_str122);
  }
  V v_t_241762 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241761, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241762});
}
V g_heff_2ecompile_2einterp_2eprim_lam121(V self, V *args) {
  V v_a_241764 = args[0];
  V v_b_241765 = args[1];
  V v_t_241767;
  if (heff_intLe_c(v_a_241764, v_b_241765)) {
    v_t_241767 = ((V)&g_heff_2ecompile_2einterp_2eprim_str124);
  } else {
    v_t_241767 = ((V)&g_heff_2ecompile_2einterp_2eprim_str125);
  }
  V v_t_241768 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241767, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241768});
}
V g_heff_2ecompile_2einterp_2eprim_lam122(V self, V *args) {
  V v_d_241770 = args[0];
  V v_a_241771 = args[1];
  V v_x1_241772 = heff_tr(heff_call(v_a_241771, 1, (V[]){v_d_241770}));
  switch (heff_tag_of(v_x1_241772)) {
  case TAG_Ok: {
    V v_v_241773 = heff_field(v_x1_241772, 0);
    V v_ru_24x1_241772_24Ok = heff_take_reuse_n(v_x1_241772, 1ULL, 1);
    switch (heff_tag_of(v_v_241773)) {
    case TAG_VFun: {
      heff_take_n(v_v_241773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241773, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VRune: {
      V v_a_241782 = heff_field(v_v_241773, 0);
      heff_take_n(v_v_241773, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241772_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_241782})});
    }
    case TAG_VArr: {
      heff_take_n(v_v_241773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241773, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241773, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241772_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    default: return heff_nomatch(v_v_241773);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241787 = heff_field(v_x1_241772, 0);
    V v_ru_24x1_241772_24Bug = heff_take_reuse_n(v_x1_241772, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241772_24Bug, TAG_Bug, 1, (V[]){v_what_241787});
  }
  default: return heff_nomatch(v_x1_241772);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam124(V self, V *args) {
  V v_d_241791 = args[0];
  V v_a_241792 = args[1];
  V f_ = v_a_241792;
  args[0] = v_d_241791;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2einterp_2eprim_lam123(V self, V *args) {
  V v_d_241789 = args[0];
  V v_u_241790 = args[1];
  heff_drop(v_d_241789);
  heff_drop(v_u_241790);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam124_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam125(V self, V *args) {
  V v_d_241794 = args[0];
  V v_a_241795 = args[1];
  V v_x1_241796 = heff_tr(heff_call(v_a_241795, 1, (V[]){v_d_241794}));
  switch (heff_tag_of(v_x1_241796)) {
  case TAG_Ok: {
    V v_v_241797 = heff_field(v_x1_241796, 0);
    V v_ru_24x1_241796_24Ok = heff_take_reuse_n(v_x1_241796, 1ULL, 1);
    switch (heff_tag_of(v_v_241797)) {
    case TAG_VFun: {
      heff_take_n(v_v_241797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241797, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241802 = heff_field(v_v_241797, 0);
      heff_take_n(v_v_241797, 1ULL, 1);
      V v_t_241803 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_241804 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_241805 = heff_intSub(v_a_241802, heff_intSub(MK_INT(0LL), v_t_241804));
      V v_t_241806 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(32LL)));
      V v_t_241807 = heff_intAdd(heff_intSub(MK_INT(0LL), v_t_241803), heff_intMod(v_t_241805, v_t_241806));
      return heff_tag_at_n(v_ru_24x1_241796_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VRune, 1, (V[]){v_t_241807})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241797, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241797, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241796_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241797);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241816 = heff_field(v_x1_241796, 0);
    V v_ru_24x1_241796_24Bug = heff_take_reuse_n(v_x1_241796, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241796_24Bug, TAG_Bug, 1, (V[]){v_what_241816});
  }
  default: return heff_nomatch(v_x1_241796);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam126(V self, V *args) {
  V v_d_241818 = args[0];
  V v_a_241819 = args[1];
  V v_x1_241820 = heff_tr(heff_call(v_a_241819, 1, (V[]){v_d_241818}));
  switch (heff_tag_of(v_x1_241820)) {
  case TAG_Ok: {
    V v_v_241821 = heff_field(v_x1_241820, 0);
    V v_ru_24x1_241820_24Ok = heff_take_reuse_n(v_x1_241820, 1ULL, 1);
    switch (heff_tag_of(v_v_241821)) {
    case TAG_VFun: {
      heff_take_n(v_v_241821, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241820_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241821, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241820_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241821, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241820_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241821, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241820_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241821, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241820_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241821, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241820_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241829 = heff_field(v_v_241821, 0);
      heff_take_n(v_v_241821, 1ULL, 1);
      V v_t_241830 = (g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(heff_strRunes(v_a_241829)));
      return heff_tag_at_n(v_ru_24x1_241820_24Ok, TAG_Ok, 1, (V[]){v_t_241830});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241821, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241820_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241821, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241820_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241821, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241820_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241821, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241820_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241820_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241821);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241836 = heff_field(v_x1_241820, 0);
    V v_ru_24x1_241820_24Bug = heff_take_reuse_n(v_x1_241820, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241820_24Bug, TAG_Bug, 1, (V[]){v_what_241836});
  }
  default: return heff_nomatch(v_x1_241820);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam127(V self, V *args) {
  V v_d_241838 = args[0];
  V v_l_241839 = args[1];
  V v_x1_241840 = heff_tr(heff_call(v_l_241839, 1, (V[]){v_d_241838}));
  switch (heff_tag_of(v_x1_241840)) {
  case TAG_Ok: {
    V v_v_241841 = heff_field(v_x1_241840, 0);
    V v_ru_24x1_241840_24Ok = heff_take_reuse_n(v_x1_241840, 1ULL, 1);
    V v_t_241842 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241841, NTAG(TAG_Nil)));
    V v_t_241843 = (g_heff_2ecompile_2einterp_2eruneCodes(v_t_241842));
    V v_t_241844 = (g_list_2emap(heff_dup(g_runeFromInt_get()), v_t_241843));
    V v_t_241845 = heff_tag_n(TAG_VStr, 1, (V[]){heff_strOfRunes(v_t_241844)});
    return heff_tag_at_n(v_ru_24x1_241840_24Ok, TAG_Ok, 1, (V[]){v_t_241845});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241846 = heff_field(v_x1_241840, 0);
    V v_ru_24x1_241840_24Bug = heff_take_reuse_n(v_x1_241840, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241840_24Bug, TAG_Bug, 1, (V[]){v_what_241846});
  }
  default: return heff_nomatch(v_x1_241840);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam128(V self, V *args) {
  V v_d_241852 = args[0];
  V v_a_241853 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241852);
  heff_drop(v_a_241853);
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprim_str131), v_p_240)});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str0, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str3, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str6, 2, "{ ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str7, 2, " }");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str9, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str10, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str11, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str15, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str16, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str17, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str20, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str21, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str22, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str23, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str24, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str25, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str26, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str27, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str28, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str29, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str30, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str31, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str32, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str33, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str34, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str35, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str36, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str37, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str38, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str39, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str40, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str41, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str42, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str43, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str44, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str45, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str46, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str47, 1, ")");
Clo g_heff_2ecompile_2einterp_2eshowValGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eshowValGo_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eshowValGo(V v_inArg_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VFun: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_243 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_243, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str0))) {
        V v_t_245 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str1), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str2)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VCons: {
    V v_fs_246 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_t_247 = heff_arrayToList(heff_take_field(v_fs_246, 0));
    V v_t_248 = heff_arrayToList(heff_get_n(v_fs_246, 2, 3));
    V v_t_249 = (g_heff_2eutil_2edict_2ezipKV(v_t_247, v_t_248));
    V v_x2_2410 = (g_list_2emap_24s1427000880x1925304966(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str3), v_t_249));
    V v_t_2413;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_xs_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str5); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str7)));
  }
  case TAG_VTag: {
    V v_x_2414 = heff_field(v_v_241, 0);
    V v_vs_2415 = heff_field(v_v_241, 1);
    V v_ru_24v_241_24VTag = heff_take_reuse_n(v_v_241, 3ULL, 2);
    HeffT2 v_t_2416 = (g_heff_2ecompile_2einterp_2elistValsGo_24cpr(heff_tag_at_n(v_ru_24v_241_24VTag, TAG_VTag, 2, (V[]){heff_dup(v_x_2414), heff_dup(v_vs_2415)}), NTAG(TAG_Nil)));
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        heff_drop(v_x_2414);
        heff_drop(v_vs_2415);
        V v_items_2420 = v_field_2418;
        V v_x2_2421 = (g_list_2emap_24s391931963x434308123(v_items_2420));
        V v_t_2424;
        switch (heff_tag_of(v_x2_2421)) {
        case TAG_Nil: {
          v_t_2424 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2422 = heff_field(v_x2_2421, 0);
          V v_xs_2423 = heff_field(v_x2_2421, 1);
          heff_take_n(v_x2_2421, 3ULL, 2);
          v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str9); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2421);
        }
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str10), heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str11)));
      } else {
        heff_drop(v_field_2418);
        switch (heff_tag_of(v_vs_2415)) {
        case TAG_Nil: {
          return v_x_2414;
        }
        case TAG_Cons: {
          if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
            V v_x2_2427 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str12), v_vs_2415));
            V v_t_2430;
            switch (heff_tag_of(v_x2_2427)) {
            case TAG_Nil: {
              v_t_2430 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str13);
              break;
            }
            case TAG_Cons: {
              V v_x_2428 = heff_field(v_x2_2427, 0);
              V v_xs_2429 = heff_field(v_x2_2427, 1);
              heff_take_n(v_x2_2427, 3ULL, 2);
              v_t_2430 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str14); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2427);
            }
            V v_t_2431 = heff_strAppend(v_x_2414, heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str15)));
            return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str16), v_t_2431);
          } else {
            V v_x2_2432 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str17), v_vs_2415));
            V v_t_2435;
            switch (heff_tag_of(v_x2_2432)) {
            case TAG_Nil: {
              v_t_2435 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str18);
              break;
            }
            case TAG_Cons: {
              V v_x_2433 = heff_field(v_x2_2432, 0);
              V v_xs_2434 = heff_field(v_x2_2432, 1);
              heff_take_n(v_x2_2432, 3ULL, 2);
              v_t_2435 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str19); V a_1 = v_x_2433; V a_2 = v_xs_2434; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2434); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2432);
            }
            return heff_strAppend(v_x_2414, v_t_2435);
          }
        }
        default: return heff_nomatch(v_vs_2415);
        }
      }
    }
  }
  case TAG_VInt: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2437 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2437, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str20))) {
        V v_t_2439 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str21), heff_strAppend(v_t_2439, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str22)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VFloat: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2441 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2441, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str23))) {
        V v_t_2443 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str24), heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str25)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VFloat32: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2445 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2445, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str26))) {
        V v_t_2447 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str27), heff_strAppend(v_t_2447, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str28)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VStr: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2449 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2449, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str29))) {
        V v_t_2451 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str30), heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str31)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VRune: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2453 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2453, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str32))) {
        V v_t_2455 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str33), heff_strAppend(v_t_2455, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str34)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VArr: {
    V v_xs_2456 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_x2_2457 = (g_list_2emap_24s391931963x434308123(heff_arrayToList(v_xs_2456)));
    V v_t_2460;
    switch (heff_tag_of(v_x2_2457)) {
    case TAG_Nil: {
      v_t_2460 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2458 = heff_field(v_x2_2457, 0);
      V v_xs_2459 = heff_field(v_x2_2457, 1);
      heff_take_n(v_x2_2457, 3ULL, 2);
      v_t_2460 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str36); V a_1 = v_x_2458; V a_2 = v_xs_2459; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2459); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2457);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str37), heff_strAppend(v_t_2460, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str38)));
  }
  case TAG_VBytes: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2462 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2462, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str39))) {
        V v_t_2464 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str40), heff_strAppend(v_t_2464, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str41)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VBits: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2467 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2467, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str42))) {
        V v_t_2469 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str43), heff_strAppend(v_t_2469, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str44)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
    }
  }
  case TAG_VErased: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2470 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2470, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str45))) {
        V v_t_2472 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str46), heff_strAppend(v_t_2472, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str47)));
      } else {
        return (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      }
    } else {
      return (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2eshowValGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_lam0, 1, 0};
Clo g_heff_2ecompile_2einterp_2eapplyErased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eapplyErased(V v_n_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_r_241)) {
  case TAG_RSucceeded: {
    V v_r1_242 = heff_dup(heff_field(v_r_241, 0));
    switch (heff_tag_of(v_r1_242)) {
    case TAG_VFun: {
      V v_f_243 = heff_field(v_r1_242, 0);
      V v_ru_24r1_242_24VFun = heff_take_reuse_n(v_r1_242, 1ULL, 1);
      heff_drop_tag(v_r_241, 1);
      if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
        heff_drop(v_n_240);
        return heff_tag_n(TAG_RSucceeded, 1, (V[]){heff_tag_at_n(v_ru_24r1_242_24VFun, TAG_VFun, 1, (V[]){v_f_243})});
      } else {
        heff_drop_cell(v_ru_24r1_242_24VFun, 1);
        V v_x1_246 = heff_tr(heff_call(v_f_243, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo)}));
        V v_t_249;
        switch (heff_tag_of(v_x1_246)) {
        case TAG_Ok: {
          V v_v_247 = heff_field(v_x1_246, 0);
          V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
          v_t_249 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_RSucceeded, 1, (V[]){v_v_247});
          break;
        }
        case TAG_Abn: {
          v_t_249 = NTAG(TAG_RAbandoned);
          break;
        }
        case TAG_Div: {
          v_t_249 = NTAG(TAG_RDiverged);
          break;
        }
        case TAG_Bug: {
          V v_what_248 = heff_field(v_x1_246, 0);
          V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
          v_t_249 = heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_RBug, 1, (V[]){v_what_248});
          break;
        }
        default: heff_nomatch(v_x1_246);
        }
        V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
        V t_1 = v_t_249;
        v_n_240 = t_0;
        v_r_241 = t_1;
        goto top;
      }
    }
    case TAG_VCons: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VTag: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VInt: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat: {
      heff_take_na(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat32: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VStr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VRune: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VArr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBytes: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBits: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VErased: {
      heff_drop(v_n_240);
      return v_r_241;
    }
    default: return heff_nomatch(v_r1_242);
    }
  }
  case TAG_RAbandoned: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RDiverged: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RBug: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  default: return heff_nomatch(v_r_241);
  }
}
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eapplyErased(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args) {
  V v_d_245 = args[0];
  heff_drop(v_d_245);
  return heff_tag_n(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
}
Clo g_heff_2ecompile_2einterp_2ereachGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ereachGlobals_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ereachGlobals(V v_gs_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_gs_240, 8);
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_seen_241, v_k_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_k_243);
        V v_x_249 = v_field_247;
        heff_drop(v_x_249);
        V t_0 = v_gs_240;
        V t_1 = v_seen_241;
        V t_2 = v_rest_244;
        v_gs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_2410 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_seen_241, heff_dup(v_k_243), NTAG(TAG_MkUnit)));
        HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_gs_240, 1), v_k_243));
        V v_t_2428;
        {
          V v_field_2413 = v_t_2411.f[1];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            heff_drop(v_k_243);
            V v_e_2415 = v_field_2413;
            V v_t_2416 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_get_n(v_e_2415, 0, 4)));
            v_t_2428 = (g_heff_2eelab_2erename_2enubFirst(v_t_2416));
          } else {
            heff_drop(v_field_2413);
            HeffT2 v_t_2417 = ({ V a_0 = heff_rfield(v_gs_240, 2); V a_1 = v_k_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_k_243); r_; });
            {
              V v_field_2419 = v_t_2417.f[1];
              int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
              if ((v_tag_2418 == ((int64_t)0ULL))) {
                V v_k2_2421 = v_field_2419;
                HeffT2 v_t_2422 = ({ V a_0 = heff_rfield(v_gs_240, 1); V a_1 = v_k2_2421; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_k2_2421); r_; });
                {
                  V v_field_2424 = v_t_2422.f[1];
                  int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
                  if ((v_tag_2423 == ((int64_t)0ULL))) {
                    V v_entry_2426 = v_field_2424;
                    V v_t_2427 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_get_n(v_entry_2426, 0, 4)));
                    v_t_2428 = (g_heff_2eelab_2erename_2enubFirst(v_t_2427));
                  } else {
                    heff_drop(v_field_2424);
                    v_t_2428 = NTAG(TAG_Nil);
                  }
                }
              } else {
                heff_drop(v_field_2419);
                v_t_2428 = NTAG(TAG_Nil);
              }
            }
          }
        }
        V v_t_2429 = (g_prelude_2e_2b_2b(v_t_2428, v_rest_244));
        V t_0 = v_gs_240;
        V t_1 = v_t_2410;
        V t_2 = v_t_2429;
        v_gs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2einterp_2ereachGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ereachGlobals(a[0], a[1], a[2]);
}