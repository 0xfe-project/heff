// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_ArrayAppend 23933
#define TAG_ArrayFromList 11455
#define TAG_ArrayGenerate 2390
#define TAG_ArrayIndex 31774
#define TAG_ArrayInsertAt 1609
#define TAG_ArrayLength 32493
#define TAG_ArrayPush 18071
#define TAG_ArrayRemoveAt 38526
#define TAG_ArrayReplicate 47039
#define TAG_ArrayReserve 45606
#define TAG_ArraySet 62162
#define TAG_ArraySlice 38486
#define TAG_ArrayToList 20274
#define TAG_BitsBytes 6377
#define TAG_BitsConcat 14523
#define TAG_BitsEq 8995
#define TAG_BitsIntAt 48290
#define TAG_BitsLength 37027
#define TAG_BitsOfBytes 24218
#define TAG_BitsOfInt 3554
#define TAG_BitsSlice 40746
#define TAG_Bug 14592
#define TAG_BytesAppend 445
#define TAG_BytesAsString 10306
#define TAG_BytesAt 9508
#define TAG_BytesConcat 52027
#define TAG_BytesEq 9629
#define TAG_BytesFromList 45957
#define TAG_BytesFromString 47012
#define TAG_BytesHasAt 63051
#define TAG_BytesIntAt 64296
#define TAG_BytesLength 9005
#define TAG_BytesOfInt 19560
#define TAG_BytesSlice 56752
#define TAG_BytesToList 62312
#define TAG_BytesToString 37927
#define TAG_Div 16157
#define TAG_FloatAcos 708
#define TAG_FloatAdd 6390
#define TAG_FloatAsin 15893
#define TAG_FloatAtan 16606
#define TAG_FloatAtan2 55855
#define TAG_FloatBits 36420
#define TAG_FloatCos 8668
#define TAG_FloatDiv 9446
#define TAG_FloatEq 13032
#define TAG_FloatExp 10866
#define TAG_FloatFloor 58439
#define TAG_FloatFromInt 61384
#define TAG_FloatLe 13237
#define TAG_FloatLog 17305
#define TAG_FloatLt 13252
#define TAG_FloatMul 18457
#define TAG_FloatOfBits 49155
#define TAG_FloatOfDecimal 61587
#define TAG_FloatPow 21165
#define TAG_FloatShow 17547
#define TAG_FloatSin 23853
#define TAG_FloatSqrt 26286
#define TAG_FloatSub 24213
#define TAG_FloatTan 24566
#define TAG_IntAdd 18227
#define TAG_IntAnd 18537
#define TAG_IntDiv 21283
#define TAG_IntEq 36665
#define TAG_IntHash 50175
#define TAG_IntLe 36870
#define TAG_IntLt 36885
#define TAG_IntMod 30100
#define TAG_IntMul 30294
#define TAG_IntOr 36976
#define TAG_IntShl 35657
#define TAG_IntShow 56864
#define TAG_IntShr 35663
#define TAG_IntSub 36050
#define TAG_IntXor 40685
#define TAG_Keep 49586
#define TAG_OfFixed 17267
#define TAG_Ok 9325
#define TAG_OnWindows 60758
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_RuneEq 61407
#define TAG_RuneFromInt 49375
#define TAG_RuneLe 61612
#define TAG_RuneLt 61627
#define TAG_RuneToInt 27192
#define TAG_StrAppend 34515
#define TAG_StrByteAt 5424
#define TAG_StrCompare 35677
#define TAG_StrEq 12955
#define TAG_StrEqRange 52111
#define TAG_StrFind 15860
#define TAG_StrFromByte 3813
#define TAG_StrFromJS 60564
#define TAG_StrHash 2387
#define TAG_StrHashRange 56513
#define TAG_StrLength 43075
#define TAG_StrLt 13175
#define TAG_StrOfRunes 54236
#define TAG_StrRuneAt 38304
#define TAG_StrRuneCount 54745
#define TAG_StrRuneWidth 48503
#define TAG_StrRunes 5519
#define TAG_StrSlice 780
#define TAG_StrToJS 44411
#define TAG_TrieSlot 53599
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_aliases 1464806715
#define LBL_entries 787768015
#define LBL_fixed 298804110
#define LBL_keys 9783995
#define LBL_op 10312
#define LBL_syntax 1059664654
#define LBL_values 1123329101
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
V g_heff_2ecompile_2einterp_2eapplyErased(V, V);
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eapplyErased_clo;
V g_heff_2ecompile_2einterp_2ebits1(V);
V g_heff_2ecompile_2einterp_2ebits1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebits1_clo;
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void);
V g_heff_2ecompile_2einterp_2ebitsCopy(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsCopy_clo;
V g_heff_2ecompile_2einterp_2ebitsJoined(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsJoined_clo;
V g_heff_2ecompile_2einterp_2ebitsRead(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsRead_clo;
V g_heff_2ecompile_2einterp_2ebitsSet(V);
V g_heff_2ecompile_2einterp_2ebitsSet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsSet_clo;
V g_heff_2ecompile_2einterp_2ebyteString(V, V);
V g_heff_2ecompile_2einterp_2ebyteString_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebyteString_clo;
V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get(void);
V g_heff_2ecompile_2einterp_2ebytesJoined(V, V);
V g_heff_2ecompile_2einterp_2ebytesJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesJoined_clo;
V g_heff_2ecompile_2einterp_2ebytesOfNat(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfNat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfNat_clo;
double g_heff_2ecompile_2einterp_2edecimalTextV_w(V, V);
V g_heff_2ecompile_2einterp_2edecimalTextV(V, V);
V g_heff_2ecompile_2einterp_2edecimalTextV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2edecimalTextV_clo;
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void);
V g_heff_2ecompile_2einterp_2efixedPrimV(V);
V g_heff_2ecompile_2einterp_2efixedPrimV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedPrimV_clo;
V g_heff_2ecompile_2einterp_2efloat2(V);
V g_heff_2ecompile_2einterp_2efloat2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloat2_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get(void);
V g_heff_2ecompile_2einterp_2efmix64(V);
V g_heff_2ecompile_2einterp_2efmix64_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efmix64_clo;
V g_heff_2ecompile_2einterp_2efromListV(V, V);
V g_heff_2ecompile_2einterp_2efromListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efromListV_clo;
V g_heff_2ecompile_2einterp_2egenGo(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2egenGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2egenGo_clo;
V g_heff_2ecompile_2einterp_2ehashFrom(V, V, V);
V g_heff_2ecompile_2einterp_2ehashFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ehashFrom_clo;
V g_heff_2ecompile_2einterp_2eieeeBits_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeBits(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeBits_clo;
V g_heff_2ecompile_2einterp_2eieeeMagnitude_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeMagnitude(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeMagnitude_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeMagnitude_clo;
double g_heff_2ecompile_2einterp_2eieeeOf_w(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeOf_clo;
V g_heff_2ecompile_2einterp_2eint2(V);
V g_heff_2ecompile_2einterp_2eint2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eint2_clo;
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void);
V g_heff_2ecompile_2einterp_2eintAtV(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintAtV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintAtV_clo;
V g_heff_2ecompile_2einterp_2eintAtV_24tok1(V, V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintAtV_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintAtV_24tok1_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_clo;
V g_heff_2ecompile_2einterp_2elistValsGo(V, V);
V g_heff_2ecompile_2einterp_2elistValsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elistValsGo_clo;
V g_heff_2ecompile_2einterp_2elittleInGo(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2elittleInGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elittleInGo_clo;
V g_heff_2ecompile_2einterp_2elittleOutGo(V, V, V, V);
V g_heff_2ecompile_2einterp_2elittleOutGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elittleOutGo_clo;
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotARune_get(void);
V g_heff_2ecompile_2einterp_2enotAString_get(void);
V g_heff_2ecompile_2einterp_2enotAnArray_get(void);
V g_heff_2ecompile_2einterp_2enotAnInt_get(void);
V g_heff_2ecompile_2einterp_2enotBytes_get(void);
HeffT2 g_heff_2ecompile_2einterp_2enthV_24cpr(V, V);
V g_heff_2ecompile_2einterp_2eprim(V);
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eprim_clo;
V g_heff_2ecompile_2einterp_2ereachGlobals(V, V, V);
V g_heff_2ecompile_2einterp_2ereachGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ereachGlobals_clo;
V g_heff_2ecompile_2einterp_2erune2(V);
V g_heff_2ecompile_2einterp_2erune2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2erune2_clo;
V g_heff_2ecompile_2einterp_2eruneCodes(V);
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_clo;
V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V, V);
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo;
V g_heff_2ecompile_2einterp_2escalarV(V);
V g_heff_2ecompile_2einterp_2escalarV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2escalarV_clo;
V g_heff_2ecompile_2einterp_2esetAt(V, V, V);
V g_heff_2ecompile_2einterp_2esetAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esetAt_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2einterp_2esliceV(V, V, V);
V g_heff_2ecompile_2einterp_2esliceV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esliceV_clo;
V g_heff_2ecompile_2einterp_2estr2(V);
V g_heff_2ecompile_2einterp_2estr2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2estr2_clo;
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get(void);
V g_heff_2ecompile_2einterp_2etoListV(V);
V g_heff_2ecompile_2einterp_2etoListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(V, V, V);
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(V);
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_clo;
V g_heff_2ecompile_2einterp_2etwoTo(V);
V g_heff_2ecompile_2einterp_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoTo_clo;
V g_heff_2ecompile_2einterp_2eword64_get(void);
V g_heff_2ecompile_2einterp_2ewordOf(V, V, V);
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ewordOf_clo;
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2erename_2enubFirst(V);
V g_heff_2eelab_2erename_2enubFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2enubFirst_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s24324293x740715900(V, V);
V g_list_2emap_24s24324293x740715900_entry(V self, V *a);
extern Clo g_list_2emap_24s24324293x740715900_clo;
V g_list_2emap_24s391931963x434308123(V);
V g_list_2emap_24s391931963x434308123_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_clo;
V g_list_2emap_24s503834852x510769098(V, V);
V g_list_2emap_24s503834852x510769098_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_rune_2evalidString_2evalidFrom_240(V, V);
V g_rune_2evalidString_2evalidFrom_240_entry(V self, V *a);
extern Clo g_rune_2evalidString_2evalidFrom_240_clo;
V g_runeFromInt_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAnInt_str0, 38, "a primitive given what is not an `Int`");

static V g_heff_2ecompile_2einterp_2enotAnInt_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAnInt_st;
static V g_heff_2ecompile_2einterp_2enotAnInt_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAnInt_str0)});
}
V g_heff_2ecompile_2einterp_2enotAnInt_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAnInt_st)) return g_heff_2ecompile_2einterp_2enotAnInt_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAnInt_val, &g_heff_2ecompile_2einterp_2enotAnInt_st, g_heff_2ecompile_2einterp_2enotAnInt_init);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAFloat64_str0, 41, "a primitive given what is not a `Float64`");

static V g_heff_2ecompile_2einterp_2enotAFloat64_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAFloat64_st;
static V g_heff_2ecompile_2einterp_2enotAFloat64_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAFloat64_str0)});
}
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAFloat64_st)) return g_heff_2ecompile_2einterp_2enotAFloat64_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAFloat64_val, &g_heff_2ecompile_2einterp_2enotAFloat64_st, g_heff_2ecompile_2einterp_2enotAFloat64_init);
}
Clo g_heff_2ecompile_2einterp_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ewordOf_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ewordOf(V v_n_240, V v_f_241, V v_v_242) {
top: ;
  if ((heff_unbox_word(heff_intMod(v_f_241, MK_INT(2LL))) == ((int64_t)1ULL))) {
    V v_t_243 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_245 = heff_intAdd(heff_intMod(v_v_242, v_t_243), v_t_244);
    V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_u_247 = heff_intMod(v_t_245, v_t_246);
    V v_n_248 = v_n_240;
    V v_t_249 = (g_heff_2ecompile_2einterp_2elittleOutGo(heff_dup(v_u_247), heff_box_word((heff_peek_word(v_n_248) / ((int64_t)8ULL))), MK_INT(0LL), MK_INT(0LL)));
    V v_t_2410 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_n_248) % ((int64_t)8ULL)))));
    int64_t v_t_2411 = (((int64_t)8ULL) * (heff_peek_word(v_n_248) / ((int64_t)8ULL)));
    V v_t_2412 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word(v_t_2411)));
    V v_t_2413 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_unbox_word(v_n_248) % ((int64_t)8ULL)))));
    V v_t_2414 = heff_intMod(heff_intDiv(v_u_247, v_t_2412), v_t_2413);
    return heff_intAdd(heff_intMul(v_t_249, v_t_2410), v_t_2414);
  } else {
    V v_t_2415 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_2416 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_2417 = heff_intAdd(heff_intMod(v_v_242, v_t_2415), v_t_2416);
    V v_t_2418 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_240));
    return heff_intMod(v_t_2417, v_t_2418);
  }
}
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ewordOf(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2eieeeBits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eieeeBits_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eieeeBits_w(V v_eb_240, V v_fb_241, double v_x_242) {
top: ;
  if (!(v_x_242 == v_x_242)) {
    V v_t_243 = (g_heff_2ecompile_2einterp_2etwoTo(v_eb_240));
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_fb_241)));
    V v_t_245 = heff_intMul(heff_intSub(v_t_243, MK_INT(1LL)), v_t_244);
    V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_unbox_word(v_fb_241) - ((int64_t)1ULL)))));
    return heff_intAdd(v_t_245, v_t_246);
  } else {
    if (((v_x_242 < (0.0)) || ((v_x_242 == (0.0)) && (((1.0) / v_x_242) < (0.0))))) {
      V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_eb_240) + heff_peek_word(v_fb_241)))));
      V v_t_248 = (g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, ((0.0) - v_x_242)));
      return heff_intAdd(v_t_247, v_t_248);
    } else {
      HEFF_LAST return g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, v_x_242);
    }
  }
}
V g_heff_2ecompile_2einterp_2eieeeBits(V v_eb_240, V v_fb_241, V v_box_24x_242) {
  double v_x_242 = heff_unbox_f64(v_box_24x_242);
  return (g_heff_2ecompile_2einterp_2eieeeBits_w(v_eb_240, v_fb_241, v_x_242));
}
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eieeeBits(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eruneCodes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_VFun: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2411 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2411, heff_hole()});
      V v_u_2413 = (g_heff_2ecompile_2einterp_2eruneCodes_24dps(v_rest_242, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eruneCodes(a[0]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_VFun: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2412 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2412, heff_hole()});
      V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2413;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eruneCodes_24dps(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st;
static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st)) return g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val, &g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)(heff_unbox_f32(v_a_2414) / heff_unbox_f32(v_b_2421))))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st;
static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st)) return g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
  return heff_global(&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val, &g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init);
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = (g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(v_a_2412, v_b_2417));
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VInt, 1, (V[]){v_t_2418})});
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1, 2, 1, (V[]){v_a_241})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10, 36, "a primitive given what is not `Bits`");
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st;
static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st)) return g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val, &g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init);
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  V v_x1_242 = heff_tr(heff_call(v_a_241, 1, (V[]){v_d_240}));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Ok: {
    V v_v_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Ok = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_v_243)) {
    case TAG_VFun: {
      V v_ru_24v_243_24VFun = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFun, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0)});
    }
    case TAG_VCons: {
      V v_ru_24v_243_24VCons = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VCons, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1)});
    }
    case TAG_VTag: {
      heff_take_n(v_v_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2)});
    }
    case TAG_VInt: {
      V v_ru_24v_243_24VInt = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3)});
    }
    case TAG_VFloat: {
      V v_ru_24v_243_24VFloat = heff_take_reuse_na(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4)});
    }
    case TAG_VFloat32: {
      V v_ru_24v_243_24VFloat32 = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat32, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5)});
    }
    case TAG_VStr: {
      V v_ru_24v_243_24VStr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VStr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6)});
    }
    case TAG_VRune: {
      V v_ru_24v_243_24VRune = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VRune, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7)});
    }
    case TAG_VArr: {
      V v_ru_24v_243_24VArr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VArr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8)});
    }
    case TAG_VBytes: {
      V v_ru_24v_243_24VBytes = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VBytes, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9)});
    }
    case TAG_VBits: {
      V v_n_2415 = heff_field(v_v_243, 0);
      heff_take_n(v_v_243, 1ULL, 2);
      return heff_tag_at_n(v_ru_24x1_242_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_n_2415})});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10)});
    }
    default: return heff_nomatch(v_v_243);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2417 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Bug = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_242_24Bug, TAG_Bug, 1, (V[]){v_what_2417});
  }
  default: return heff_nomatch(v_x1_242);
  }
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str3, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str4, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str5, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str6, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str7, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str8, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str9, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str10, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str11, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str12, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str13, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str14, 32, "an index in range, of no element");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str15, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str16, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str17, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str18, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str19, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str20, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str21, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str22, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str23, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str24, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str26, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str27, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str28, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str29, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str30, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str31, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str32, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str33, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str34, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str35, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str36, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str37, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str38, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str39, 13, "no primitive ");
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam0, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam1, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam2, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam3, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam4, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam5, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam6, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam7, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam8, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam9, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam10, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam11, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam12, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam13, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam14, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam15, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam16, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam17, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam18, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam19, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam20, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam21, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam22, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam23, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam24, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam25, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam27, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam26, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam29, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam28, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam32, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam31, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam38, 1, 0};
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam36, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam35, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam40, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam39, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam42, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam41, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam44_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam44, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam43, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam47, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam46, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam51, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam50_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam50, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam54_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam54, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam53_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam53, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam58_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam58, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam57_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam57, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam61_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam61, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam60_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam60, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam64_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam64, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam63_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam63, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam66_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam66, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam67_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam67, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam70_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam70, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam71_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam71, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam72_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam72, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam73_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam73, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam75_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam75, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam76_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam76, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam77_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam77, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam78_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam78, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam79_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam79, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam81_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam81, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam80_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam80, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam82_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam82, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam84_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam84, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam85_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam85, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam87_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam87, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam89_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam89, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam90_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam90, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam91_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam91, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam92_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam92, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam93_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam93, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam94_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam94, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam95_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam95, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam97_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam97, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam100_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam100, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam101_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam101, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam104_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam104, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam105_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam105, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam106_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam106, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam107_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam107, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam108_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam108, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam112(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam111(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam110(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam109_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam109, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam115(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam114(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam113(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam113_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam113, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam118(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam117(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam116(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam116_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam116, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam122(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam121(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam120(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam119(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam119, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam125(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam124(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam123(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam123, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam126(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam126_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam126, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam129(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam128(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam127(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam127_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam127, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam130(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam130, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam131(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam131_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam131, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam133(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam132(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam132, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam135(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam134(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam134_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam134, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam137(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam136(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam136_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam136, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam141(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam140(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam139(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam138(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam138_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam138, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam142(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam142_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam142, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam145(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam144(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam143(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam143_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam143, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam148(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam147(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam146(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam146_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam146, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam149(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam149_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam149, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam152(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam151(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam150(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam150_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam150, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam153(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eprim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eprim(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_IntAdd: {
    return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get());
  }
  case TAG_IntSub: {
    return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get());
  }
  case TAG_IntMul: {
    return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get());
  }
  case TAG_IntDiv: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam0_clo));
  }
  case TAG_IntMod: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam1_clo));
  }
  case TAG_IntEq: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam2_clo));
  }
  case TAG_IntLt: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam3_clo));
  }
  case TAG_IntLe: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam4_clo));
  }
  case TAG_IntShow: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam5_clo)});
  }
  case TAG_IntAnd: {
    return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get());
  }
  case TAG_IntOr: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam6_clo));
  }
  case TAG_IntXor: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam7_clo));
  }
  case TAG_IntShl: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam8_clo));
  }
  case TAG_IntShr: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam9_clo));
  }
  case TAG_FloatAdd: {
    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get());
  }
  case TAG_FloatSub: {
    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get());
  }
  case TAG_FloatMul: {
    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get());
  }
  case TAG_FloatDiv: {
    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get());
  }
  case TAG_FloatEq: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam10_clo));
  }
  case TAG_FloatLt: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam11_clo));
  }
  case TAG_FloatLe: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam12_clo));
  }
  case TAG_FloatShow: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam13_clo)});
  }
  case TAG_FloatFromInt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam14_clo)});
  }
  case TAG_FloatSqrt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam15_clo)});
  }
  case TAG_OnWindows: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam16_clo)});
  }
  case TAG_FloatFloor: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam17_clo)});
  }
  case TAG_FloatSin: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam18_clo)});
  }
  case TAG_FloatCos: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam19_clo)});
  }
  case TAG_FloatTan: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam20_clo)});
  }
  case TAG_FloatAsin: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam21_clo)});
  }
  case TAG_FloatAcos: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam22_clo)});
  }
  case TAG_FloatAtan: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam23_clo)});
  }
  case TAG_FloatAtan2: {
    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get());
  }
  case TAG_FloatExp: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam24_clo)});
  }
  case TAG_FloatLog: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam25_clo)});
  }
  case TAG_FloatPow: {
    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get());
  }
  case TAG_ArrayLength: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam26_clo)});
  }
  case TAG_ArrayIndex: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam28_clo)});
  }
  case TAG_ArraySet: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam31_clo)});
  }
  case TAG_ArrayGenerate: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam35_clo)});
  }
  case TAG_ArrayFromList: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam39_clo)});
  }
  case TAG_ArrayToList: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam41_clo)});
  }
  case TAG_ArrayReplicate: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam43_clo)});
  }
  case TAG_ArraySlice: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam46_clo)});
  }
  case TAG_ArrayAppend: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam50_clo)});
  }
  case TAG_ArrayInsertAt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam53_clo)});
  }
  case TAG_ArrayRemoveAt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam57_clo)});
  }
  case TAG_ArrayPush: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam60_clo)});
  }
  case TAG_ArrayReserve: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam63_clo)});
  }
  case TAG_StrAppend: {
    return heff_dup(g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get());
  }
  case TAG_StrLength: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam66_clo)});
  }
  case TAG_StrSlice: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam67_clo)});
  }
  case TAG_StrEq: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam70_clo));
  }
  case TAG_StrLt: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam71_clo));
  }
  case TAG_StrCompare: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam72_clo));
  }
  case TAG_StrFind: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam73_clo));
  }
  case TAG_RuneEq: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam75_clo));
  }
  case TAG_RuneLt: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam76_clo));
  }
  case TAG_RuneLe: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam77_clo));
  }
  case TAG_RuneToInt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam78_clo)});
  }
  case TAG_RuneFromInt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam79_clo)});
  }
  case TAG_Keep: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam80_clo)});
  }
  case TAG_StrByteAt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam82_clo)});
  }
  case TAG_StrFromByte: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam84_clo)});
  }
  case TAG_StrRuneAt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam85_clo)});
  }
  case TAG_StrRuneWidth: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam87_clo)});
  }
  case TAG_StrRuneCount: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam89_clo)});
  }
  case TAG_StrRunes: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam90_clo)});
  }
  case TAG_StrOfRunes: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam91_clo)});
  }
  case TAG_StrToJS: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam92_clo)});
  }
  case TAG_StrFromJS: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam93_clo)});
  }
  case TAG_BytesLength: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam94_clo)});
  }
  case TAG_BytesAt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam95_clo)});
  }
  case TAG_BytesSlice: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam97_clo)});
  }
  case TAG_BytesAppend: {
    return heff_dup(g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get());
  }
  case TAG_BytesConcat: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam100_clo)});
  }
  case TAG_BytesEq: {
    V v_f_241248 = ((V)&g_heff_2ecompile_2einterp_2eprim_lam101_clo);
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam102, 2, 1, (V[]){v_f_241248})});
  }
  case TAG_BytesFromList: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam104_clo)});
  }
  case TAG_BytesToList: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam105_clo)});
  }
  case TAG_BytesFromString: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam106_clo)});
  }
  case TAG_BytesAsString: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam107_clo)});
  }
  case TAG_BytesToString: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam108_clo)});
  }
  case TAG_BytesIntAt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam109_clo)});
  }
  case TAG_BytesOfInt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam113_clo)});
  }
  case TAG_BytesHasAt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam116_clo)});
  }
  case TAG_BitsLength: {
    return heff_dup(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get());
  }
  case TAG_BitsIntAt: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam119_clo));
  }
  case TAG_BitsOfInt: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam123_clo)});
  }
  case TAG_BitsConcat: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam126_clo)});
  }
  case TAG_BitsSlice: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam127_clo));
  }
  case TAG_BitsOfBytes: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam130_clo)});
  }
  case TAG_BitsBytes: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam131_clo));
  }
  case TAG_BitsEq: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam132_clo));
  }
  case TAG_FloatBits: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam134_clo)});
  }
  case TAG_FloatOfBits: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam136_clo)});
  }
  case TAG_FloatOfDecimal: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam138_clo)});
  }
  case TAG_StrHash: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam142_clo)});
  }
  case TAG_StrHashRange: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam143_clo)});
  }
  case TAG_StrEqRange: {
    HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam146_clo));
  }
  case TAG_IntHash: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam149_clo)});
  }
  case TAG_TrieSlot: {
    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam150_clo)});
  }
  case TAG_OfFixed: {
    V v_w_242127 = heff_field(v_p_240, 0);
    V v_op_242128 = heff_field(v_p_240, 1);
    HEFF_LAST return g_heff_2ecompile_2einterp_2efixedPrimV(heff_rec_n(2, shape_fixed__op, (V[]){heff_dup(v_w_242127), heff_dup(v_op_242128)}));
  }
  default: {
    return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam153, 2, 1, (V[]){heff_dup(v_p_240)})});
  }
  }
}
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2eprim(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_b_242 = args[1];
  if (heff_intEq_c_lent(v_b_242, MK_INT(0LL), 2)) {
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){MK_INT(0LL)})});
  } else {
    V v_t_243 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_241, v_b_242)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_243});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args) {
  V v_a_244 = args[0];
  V v_b_245 = args[1];
  if (heff_intEq_c_lent(v_b_245, MK_INT(0LL), 2)) {
    heff_drop(v_b_245);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_244})});
  } else {
    V v_t_246 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMod(v_a_244, v_b_245)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_246});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args) {
  V v_a_247 = args[0];
  V v_b_248 = args[1];
  V v_t_249;
  if (heff_intEq_c(v_a_247, v_b_248)) {
    v_t_249 = ((V)&g_heff_2ecompile_2einterp_2eprim_str0);
  } else {
    v_t_249 = ((V)&g_heff_2ecompile_2einterp_2eprim_str1);
  }
  V v_t_2410 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2410});
}
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args) {
  V v_a_2411 = args[0];
  V v_b_2412 = args[1];
  V v_t_2413;
  if (heff_intLt_c(v_a_2411, v_b_2412)) {
    v_t_2413 = ((V)&g_heff_2ecompile_2einterp_2eprim_str2);
  } else {
    v_t_2413 = ((V)&g_heff_2ecompile_2einterp_2eprim_str3);
  }
  V v_t_2414 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2414});
}
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args) {
  V v_a_2415 = args[0];
  V v_b_2416 = args[1];
  V v_t_2417;
  if (heff_intLe_c(v_a_2415, v_b_2416)) {
    v_t_2417 = ((V)&g_heff_2ecompile_2einterp_2eprim_str4);
  } else {
    v_t_2417 = ((V)&g_heff_2ecompile_2einterp_2eprim_str5);
  }
  V v_t_2418 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2418});
}
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args) {
  V v_d_2419 = args[0];
  V v_a_2420 = args[1];
  V v_x1_2421 = heff_tr(heff_call(v_a_2420, 1, (V[]){v_d_2419}));
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_Ok: {
    V v_v_2422 = heff_field(v_x1_2421, 0);
    V v_ru_24x1_2421_24Ok = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
    switch (heff_tag_of(v_v_2422)) {
    case TAG_VFun: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2422, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_2427 = heff_field(v_v_2422, 0);
      V v_ru_24v_2422_24VInt = heff_take_reuse_n(v_v_2422, 1ULL, 1);
      V v_t_2428 = heff_tag_at_n(v_ru_24v_2422_24VInt, TAG_VStr, 1, (V[]){heff_intShow(v_a_2427)});
      return heff_tag_at_n(v_ru_24x1_2421_24Ok, TAG_Ok, 1, (V[]){v_t_2428});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2422, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_2422);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2437 = heff_field(v_x1_2421, 0);
    V v_ru_24x1_2421_24Bug = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2421_24Bug, TAG_Bug, 1, (V[]){v_what_2437});
  }
  default: return heff_nomatch(v_x1_2421);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args) {
  V v_a_2438 = args[0];
  V v_b_2439 = args[1];
  V v_t_2440 = (g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), v_a_2438, v_b_2439));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2440})});
}
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args) {
  V v_a_2441 = args[0];
  V v_b_2442 = args[1];
  V v_t_2443 = (g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(MK_INT(2LL), v_a_2441, v_b_2442));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2443})});
}
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args) {
  V v_a_2444 = args[0];
  V v_b_2445 = args[1];
  if (heff_intLt_c_lent(v_b_2445, MK_INT(0LL), 2)) {
    V v_k_2446 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2445)));
    V v_t_2447 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2444, v_k_2446)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2447});
  } else {
    V v_k_2448 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2445));
    V v_t_2449 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2444, v_k_2448)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2449});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args) {
  V v_a_2450 = args[0];
  V v_b_2451 = args[1];
  if (heff_intLt_c_lent(v_b_2451, MK_INT(0LL), 2)) {
    V v_k_2452 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2451)));
    V v_t_2453 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2450, v_k_2452)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2453});
  } else {
    V v_k_2454 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2451));
    V v_t_2455 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2450, v_k_2454)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2455});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args) {
  V v_box_24a_2456 = args[0];
  V v_box_24b_2457 = args[1];
  double v_a_2456 = heff_unbox_f64(v_box_24a_2456);
  double v_b_2457 = heff_unbox_f64(v_box_24b_2457);
  V v_t_2458;
  if ((v_a_2456 == v_b_2457)) {
    v_t_2458 = ((V)&g_heff_2ecompile_2einterp_2eprim_str6);
  } else {
    v_t_2458 = ((V)&g_heff_2ecompile_2einterp_2eprim_str7);
  }
  V v_t_2459 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2459});
}
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args) {
  V v_box_24a_2460 = args[0];
  V v_box_24b_2461 = args[1];
  double v_a_2460 = heff_unbox_f64(v_box_24a_2460);
  double v_b_2461 = heff_unbox_f64(v_box_24b_2461);
  V v_t_2462;
  if ((v_a_2460 < v_b_2461)) {
    v_t_2462 = ((V)&g_heff_2ecompile_2einterp_2eprim_str8);
  } else {
    v_t_2462 = ((V)&g_heff_2ecompile_2einterp_2eprim_str9);
  }
  V v_t_2463 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2463});
}
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args) {
  V v_box_24a_2464 = args[0];
  V v_box_24b_2465 = args[1];
  double v_a_2464 = heff_unbox_f64(v_box_24a_2464);
  double v_b_2465 = heff_unbox_f64(v_box_24b_2465);
  V v_t_2466;
  if ((v_a_2464 <= v_b_2465)) {
    v_t_2466 = ((V)&g_heff_2ecompile_2einterp_2eprim_str10);
  } else {
    v_t_2466 = ((V)&g_heff_2ecompile_2einterp_2eprim_str11);
  }
  V v_t_2467 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2467});
}
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args) {
  V v_d_2468 = args[0];
  V v_a_2469 = args[1];
  V v_x1_2470 = heff_tr(heff_call(v_a_2469, 1, (V[]){v_d_2468}));
  switch (heff_tag_of(v_x1_2470)) {
  case TAG_Ok: {
    V v_v_2471 = heff_field(v_x1_2470, 0);
    V v_ru_24x1_2470_24Ok = heff_take_reuse_n(v_x1_2470, 1ULL, 1);
    switch (heff_tag_of(v_v_2471)) {
    case TAG_VFun: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2471, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      V v_a_2477 = heff_tget_v(v_v_2471, 0);
      V v_ru_24v_2471_24VFloat = heff_take_reuse_na(v_v_2471, 0ULL, 1);
      V v_t_2478 = heff_tag_at_n(v_ru_24v_2471_24VFloat, TAG_VStr, 1, (V[]){heff_floatShow(v_a_2477)});
      return heff_tag_at_n(v_ru_24x1_2470_24Ok, TAG_Ok, 1, (V[]){v_t_2478});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2471, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_2471);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2486 = heff_field(v_x1_2470, 0);
    V v_ru_24x1_2470_24Bug = heff_take_reuse_n(v_x1_2470, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2470_24Bug, TAG_Bug, 1, (V[]){v_what_2486});
  }
  default: return heff_nomatch(v_x1_2470);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args) {
  V v_d_2487 = args[0];
  V v_a_2488 = args[1];
  V v_x1_2489 = heff_tr(heff_call(v_a_2488, 1, (V[]){v_d_2487}));
  switch (heff_tag_of(v_x1_2489)) {
  case TAG_Ok: {
    V v_v_2490 = heff_field(v_x1_2489, 0);
    V v_ru_24x1_2489_24Ok = heff_take_reuse_n(v_x1_2489, 1ULL, 1);
    switch (heff_tag_of(v_v_2490)) {
    case TAG_VFun: {
      heff_take_n(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2490, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_2495 = heff_field(v_v_2490, 0);
      V v_ru_24v_2490_24VInt = heff_take_reuse_n(v_v_2490, 1ULL, 1);
      V v_t_2496 = heff_tag_at_nf(v_ru_24v_2490_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(heff_from_int_f64(v_a_2495))});
      return heff_tag_at_n(v_ru_24x1_2489_24Ok, TAG_Ok, 1, (V[]){v_t_2496});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2490, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2490, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2489_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_2490);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24105 = heff_field(v_x1_2489, 0);
    V v_ru_24x1_2489_24Bug = heff_take_reuse_n(v_x1_2489, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2489_24Bug, TAG_Bug, 1, (V[]){v_what_24105});
  }
  default: return heff_nomatch(v_x1_2489);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args) {
  V v_d_24106 = args[0];
  V v_a_24107 = args[1];
  V v_x1_24108 = heff_tr(heff_call(v_a_24107, 1, (V[]){v_d_24106}));
  switch (heff_tag_of(v_x1_24108)) {
  case TAG_Ok: {
    V v_v_24109 = heff_field(v_x1_24108, 0);
    V v_ru_24x1_24108_24Ok = heff_take_reuse_n(v_x1_24108, 1ULL, 1);
    switch (heff_tag_of(v_v_24109)) {
    case TAG_VFun: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24109, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24115 = heff_tflat_f64(v_v_24109, 0);
      V v_ru_24v_24109_24VFloat = heff_take_reuse_na(v_v_24109, 0ULL, 1);
      V v_t_24116 = heff_tag_at_nf(v_ru_24v_24109_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(sqrt(v_a_24115))});
      return heff_tag_at_n(v_ru_24x1_24108_24Ok, TAG_Ok, 1, (V[]){v_t_24116});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24109, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24109, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24108_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24109);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24124 = heff_field(v_x1_24108, 0);
    V v_ru_24x1_24108_24Bug = heff_take_reuse_n(v_x1_24108, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24108_24Bug, TAG_Bug, 1, (V[]){v_what_24124});
  }
  default: return heff_nomatch(v_x1_24108);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args) {
  V v_d_24125 = args[0];
  V v_a_24126 = args[1];
  heff_drop(v_d_24125);
  heff_drop(v_a_24126);
  V v_t_24127 = heff_onWindows(NTAG(TAG_MkUnit));
  V v_t_24128;
  if ((heff_dup(v_t_24127) == NTAG(TAG_True))) {
    heff_drop(v_t_24127);
    v_t_24128 = ((V)&g_heff_2ecompile_2einterp_2eprim_str12);
  } else {
    heff_drop(v_t_24127);
    v_t_24128 = ((V)&g_heff_2ecompile_2einterp_2eprim_str13);
  }
  V v_t_24129 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24128, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24129});
}
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args) {
  V v_d_24130 = args[0];
  V v_a_24131 = args[1];
  V v_x1_24132 = heff_tr(heff_call(v_a_24131, 1, (V[]){v_d_24130}));
  switch (heff_tag_of(v_x1_24132)) {
  case TAG_Ok: {
    V v_v_24133 = heff_field(v_x1_24132, 0);
    V v_ru_24x1_24132_24Ok = heff_take_reuse_n(v_x1_24132, 1ULL, 1);
    switch (heff_tag_of(v_v_24133)) {
    case TAG_VFun: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24133, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24139 = heff_tflat_f64(v_v_24133, 0);
      V v_ru_24v_24133_24VFloat = heff_take_reuse_na(v_v_24133, 0ULL, 1);
      if (((v_a_24139 - v_a_24139) == (0.0))) {
        V v_t_24140 = heff_tag_at_n(v_ru_24v_24133_24VFloat, TAG_VInt, 1, (V[]){heff_floor_f64(v_a_24139)});
        return heff_tag_at_n(v_ru_24x1_24132_24Ok, TAG_Ok, 1, (V[]){v_t_24140});
      } else {
        return heff_tag_at_n(v_ru_24x1_24132_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24133_24VFloat, TAG_VInt, 1, (V[]){MK_INT(0LL)})});
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24133, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24133);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24148 = heff_field(v_x1_24132, 0);
    V v_ru_24x1_24132_24Bug = heff_take_reuse_n(v_x1_24132, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24132_24Bug, TAG_Bug, 1, (V[]){v_what_24148});
  }
  default: return heff_nomatch(v_x1_24132);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args) {
  V v_d_24149 = args[0];
  V v_a_24150 = args[1];
  V v_x1_24151 = heff_tr(heff_call(v_a_24150, 1, (V[]){v_d_24149}));
  switch (heff_tag_of(v_x1_24151)) {
  case TAG_Ok: {
    V v_v_24152 = heff_field(v_x1_24151, 0);
    V v_ru_24x1_24151_24Ok = heff_take_reuse_n(v_x1_24151, 1ULL, 1);
    switch (heff_tag_of(v_v_24152)) {
    case TAG_VFun: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24152, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24158 = heff_tflat_f64(v_v_24152, 0);
      V v_ru_24v_24152_24VFloat = heff_take_reuse_na(v_v_24152, 0ULL, 1);
      V v_t_24159 = heff_tag_at_nf(v_ru_24v_24152_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(sin(v_a_24158))});
      return heff_tag_at_n(v_ru_24x1_24151_24Ok, TAG_Ok, 1, (V[]){v_t_24159});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24152, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24152);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24167 = heff_field(v_x1_24151, 0);
    V v_ru_24x1_24151_24Bug = heff_take_reuse_n(v_x1_24151, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24151_24Bug, TAG_Bug, 1, (V[]){v_what_24167});
  }
  default: return heff_nomatch(v_x1_24151);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args) {
  V v_d_24168 = args[0];
  V v_a_24169 = args[1];
  V v_x1_24170 = heff_tr(heff_call(v_a_24169, 1, (V[]){v_d_24168}));
  switch (heff_tag_of(v_x1_24170)) {
  case TAG_Ok: {
    V v_v_24171 = heff_field(v_x1_24170, 0);
    V v_ru_24x1_24170_24Ok = heff_take_reuse_n(v_x1_24170, 1ULL, 1);
    switch (heff_tag_of(v_v_24171)) {
    case TAG_VFun: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24171, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24177 = heff_tflat_f64(v_v_24171, 0);
      V v_ru_24v_24171_24VFloat = heff_take_reuse_na(v_v_24171, 0ULL, 1);
      V v_t_24178 = heff_tag_at_nf(v_ru_24v_24171_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(cos(v_a_24177))});
      return heff_tag_at_n(v_ru_24x1_24170_24Ok, TAG_Ok, 1, (V[]){v_t_24178});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24171, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24171);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24186 = heff_field(v_x1_24170, 0);
    V v_ru_24x1_24170_24Bug = heff_take_reuse_n(v_x1_24170, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24170_24Bug, TAG_Bug, 1, (V[]){v_what_24186});
  }
  default: return heff_nomatch(v_x1_24170);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args) {
  V v_d_24187 = args[0];
  V v_a_24188 = args[1];
  V v_x1_24189 = heff_tr(heff_call(v_a_24188, 1, (V[]){v_d_24187}));
  switch (heff_tag_of(v_x1_24189)) {
  case TAG_Ok: {
    V v_v_24190 = heff_field(v_x1_24189, 0);
    V v_ru_24x1_24189_24Ok = heff_take_reuse_n(v_x1_24189, 1ULL, 1);
    switch (heff_tag_of(v_v_24190)) {
    case TAG_VFun: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24190, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24196 = heff_tflat_f64(v_v_24190, 0);
      V v_ru_24v_24190_24VFloat = heff_take_reuse_na(v_v_24190, 0ULL, 1);
      V v_t_24197 = heff_tag_at_nf(v_ru_24v_24190_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(tan(v_a_24196))});
      return heff_tag_at_n(v_ru_24x1_24189_24Ok, TAG_Ok, 1, (V[]){v_t_24197});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24190, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24190);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24205 = heff_field(v_x1_24189, 0);
    V v_ru_24x1_24189_24Bug = heff_take_reuse_n(v_x1_24189, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24189_24Bug, TAG_Bug, 1, (V[]){v_what_24205});
  }
  default: return heff_nomatch(v_x1_24189);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args) {
  V v_d_24206 = args[0];
  V v_a_24207 = args[1];
  V v_x1_24208 = heff_tr(heff_call(v_a_24207, 1, (V[]){v_d_24206}));
  switch (heff_tag_of(v_x1_24208)) {
  case TAG_Ok: {
    V v_v_24209 = heff_field(v_x1_24208, 0);
    V v_ru_24x1_24208_24Ok = heff_take_reuse_n(v_x1_24208, 1ULL, 1);
    switch (heff_tag_of(v_v_24209)) {
    case TAG_VFun: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24209, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24215 = heff_tflat_f64(v_v_24209, 0);
      V v_ru_24v_24209_24VFloat = heff_take_reuse_na(v_v_24209, 0ULL, 1);
      V v_t_24216 = heff_tag_at_nf(v_ru_24v_24209_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(asin(v_a_24215))});
      return heff_tag_at_n(v_ru_24x1_24208_24Ok, TAG_Ok, 1, (V[]){v_t_24216});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24209, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24209);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24224 = heff_field(v_x1_24208, 0);
    V v_ru_24x1_24208_24Bug = heff_take_reuse_n(v_x1_24208, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24208_24Bug, TAG_Bug, 1, (V[]){v_what_24224});
  }
  default: return heff_nomatch(v_x1_24208);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args) {
  V v_d_24225 = args[0];
  V v_a_24226 = args[1];
  V v_x1_24227 = heff_tr(heff_call(v_a_24226, 1, (V[]){v_d_24225}));
  switch (heff_tag_of(v_x1_24227)) {
  case TAG_Ok: {
    V v_v_24228 = heff_field(v_x1_24227, 0);
    V v_ru_24x1_24227_24Ok = heff_take_reuse_n(v_x1_24227, 1ULL, 1);
    switch (heff_tag_of(v_v_24228)) {
    case TAG_VFun: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24228, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24234 = heff_tflat_f64(v_v_24228, 0);
      V v_ru_24v_24228_24VFloat = heff_take_reuse_na(v_v_24228, 0ULL, 1);
      V v_t_24235 = heff_tag_at_nf(v_ru_24v_24228_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(acos(v_a_24234))});
      return heff_tag_at_n(v_ru_24x1_24227_24Ok, TAG_Ok, 1, (V[]){v_t_24235});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24228, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24228);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24243 = heff_field(v_x1_24227, 0);
    V v_ru_24x1_24227_24Bug = heff_take_reuse_n(v_x1_24227, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24227_24Bug, TAG_Bug, 1, (V[]){v_what_24243});
  }
  default: return heff_nomatch(v_x1_24227);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args) {
  V v_d_24244 = args[0];
  V v_a_24245 = args[1];
  V v_x1_24246 = heff_tr(heff_call(v_a_24245, 1, (V[]){v_d_24244}));
  switch (heff_tag_of(v_x1_24246)) {
  case TAG_Ok: {
    V v_v_24247 = heff_field(v_x1_24246, 0);
    V v_ru_24x1_24246_24Ok = heff_take_reuse_n(v_x1_24246, 1ULL, 1);
    switch (heff_tag_of(v_v_24247)) {
    case TAG_VFun: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24247, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24253 = heff_tflat_f64(v_v_24247, 0);
      V v_ru_24v_24247_24VFloat = heff_take_reuse_na(v_v_24247, 0ULL, 1);
      V v_t_24254 = heff_tag_at_nf(v_ru_24v_24247_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(atan(v_a_24253))});
      return heff_tag_at_n(v_ru_24x1_24246_24Ok, TAG_Ok, 1, (V[]){v_t_24254});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24247, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24247);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24262 = heff_field(v_x1_24246, 0);
    V v_ru_24x1_24246_24Bug = heff_take_reuse_n(v_x1_24246, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24246_24Bug, TAG_Bug, 1, (V[]){v_what_24262});
  }
  default: return heff_nomatch(v_x1_24246);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args) {
  V v_d_24263 = args[0];
  V v_a_24264 = args[1];
  V v_x1_24265 = heff_tr(heff_call(v_a_24264, 1, (V[]){v_d_24263}));
  switch (heff_tag_of(v_x1_24265)) {
  case TAG_Ok: {
    V v_v_24266 = heff_field(v_x1_24265, 0);
    V v_ru_24x1_24265_24Ok = heff_take_reuse_n(v_x1_24265, 1ULL, 1);
    switch (heff_tag_of(v_v_24266)) {
    case TAG_VFun: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24266, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24272 = heff_tflat_f64(v_v_24266, 0);
      V v_ru_24v_24266_24VFloat = heff_take_reuse_na(v_v_24266, 0ULL, 1);
      V v_t_24273 = heff_tag_at_nf(v_ru_24v_24266_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(exp(v_a_24272))});
      return heff_tag_at_n(v_ru_24x1_24265_24Ok, TAG_Ok, 1, (V[]){v_t_24273});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24266, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24266);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24281 = heff_field(v_x1_24265, 0);
    V v_ru_24x1_24265_24Bug = heff_take_reuse_n(v_x1_24265, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24265_24Bug, TAG_Bug, 1, (V[]){v_what_24281});
  }
  default: return heff_nomatch(v_x1_24265);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args) {
  V v_d_24282 = args[0];
  V v_a_24283 = args[1];
  V v_x1_24284 = heff_tr(heff_call(v_a_24283, 1, (V[]){v_d_24282}));
  switch (heff_tag_of(v_x1_24284)) {
  case TAG_Ok: {
    V v_v_24285 = heff_field(v_x1_24284, 0);
    V v_ru_24x1_24284_24Ok = heff_take_reuse_n(v_x1_24284, 1ULL, 1);
    switch (heff_tag_of(v_v_24285)) {
    case TAG_VFun: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24285, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24291 = heff_tflat_f64(v_v_24285, 0);
      V v_ru_24v_24285_24VFloat = heff_take_reuse_na(v_v_24285, 0ULL, 1);
      V v_t_24292 = heff_tag_at_nf(v_ru_24v_24285_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(log(v_a_24291))});
      return heff_tag_at_n(v_ru_24x1_24284_24Ok, TAG_Ok, 1, (V[]){v_t_24292});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24285, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24285);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24300 = heff_field(v_x1_24284, 0);
    V v_ru_24x1_24284_24Bug = heff_take_reuse_n(v_x1_24284, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24284_24Bug, TAG_Bug, 1, (V[]){v_what_24300});
  }
  default: return heff_nomatch(v_x1_24284);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args) {
  V v_d_24303 = args[0];
  V v_a_24304 = args[1];
  V v_x1_24305 = heff_tr(heff_call(v_a_24304, 1, (V[]){v_d_24303}));
  switch (heff_tag_of(v_x1_24305)) {
  case TAG_Ok: {
    V v_v_24306 = heff_field(v_x1_24305, 0);
    V v_ru_24x1_24305_24Ok = heff_take_reuse_n(v_x1_24305, 1ULL, 1);
    switch (heff_tag_of(v_v_24306)) {
    case TAG_VFun: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24306, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24316 = heff_field(v_v_24306, 0);
      V v_ru_24v_24306_24VArr = heff_take_reuse_n(v_v_24306, 1ULL, 1);
      V v_t_24317 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_xs_24316); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      return heff_tag_at_n(v_ru_24x1_24305_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24306_24VArr, TAG_VInt, 1, (V[]){v_t_24317})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24306, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24306);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24321 = heff_field(v_x1_24305, 0);
    V v_ru_24x1_24305_24Bug = heff_take_reuse_n(v_x1_24305, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24305_24Bug, TAG_Bug, 1, (V[]){v_what_24321});
  }
  default: return heff_nomatch(v_x1_24305);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args) {
  V v_d_24301 = args[0];
  V v_u_24302 = args[1];
  heff_drop(v_d_24301);
  heff_drop(v_u_24302);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam27_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args) {
  V v_d_24338 = args[0];
  V v_a_24339 = args[1];
  V v_xs_24337 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24340 = heff_tr(heff_call(v_a_24339, 1, (V[]){v_d_24338}));
  switch (heff_tag_of(v_x1_24340)) {
  case TAG_Ok: {
    V v_v_24341 = heff_field(v_x1_24340, 0);
    V v_ru_24x1_24340_24Ok = heff_take_reuse_n(v_x1_24340, 1ULL, 1);
    switch (heff_tag_of(v_v_24341)) {
    case TAG_VFun: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24341, 0ULL, 2);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24346 = heff_field(v_v_24341, 0);
      V v_ru_24v_24341_24VInt = heff_take_reuse_n(v_v_24341, 1ULL, 1);
      if ((heff_intLe_c_lent(MK_INT(0LL), v_a_24346, 1) && ({ V v_t_242132 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24337)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; }); int c_ = heff_intLt_c_lent(v_a_24346, v_t_242132, 0); heff_drop(v_t_242132); c_; }))) {
        HeffT2 v_t_24347 = ({ V b_0 = heff_arrayToList(v_xs_24337); V a_1 = v_a_24346; HeffT2 r_ = (g_heff_2ecompile_2einterp_2enthV_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        {
          V v_field_24349 = v_t_24347.f[1];
          int64_t v_tag_24348 = ((int64_t)v_t_24347.f[0]);
          if ((v_tag_24348 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24v_24341_24VInt, 1);
            V v_v_24350 = v_field_24349;
            return heff_tag_at_n(v_ru_24x1_24340_24Ok, TAG_Ok, 1, (V[]){v_v_24350});
          } else {
            heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
            heff_drop(v_field_24349);
            return heff_tag_at_n(v_ru_24v_24341_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str14)});
          }
        }
      } else {
        heff_drop(v_xs_24337);
        heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
        heff_drop(v_a_24346);
        heff_drop_cell(v_ru_24v_24341_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24341, 0ULL, 2);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24341);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24337);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24337);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24359 = heff_field(v_x1_24340, 0);
    V v_ru_24x1_24340_24Bug = heff_take_reuse_n(v_x1_24340, 1ULL, 1);
    heff_drop(v_xs_24337);
    return heff_tag_at_n(v_ru_24x1_24340_24Bug, TAG_Bug, 1, (V[]){v_what_24359});
  }
  default: return heff_nomatch(v_x1_24340);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args) {
  V v_d_24324 = args[0];
  V v_a_24325 = args[1];
  V v_x1_24326 = heff_tr(heff_call(v_a_24325, 1, (V[]){v_d_24324}));
  switch (heff_tag_of(v_x1_24326)) {
  case TAG_Ok: {
    V v_v_24327 = heff_field(v_x1_24326, 0);
    V v_ru_24x1_24326_24Ok = heff_take_reuse_n(v_x1_24326, 1ULL, 1);
    switch (heff_tag_of(v_v_24327)) {
    case TAG_VFun: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24327, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24337 = heff_field(v_v_24327, 0);
      V v_ru_24v_24327_24VArr = heff_take_reuse_n(v_v_24327, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24326_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24327_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam30, 2, 1, (V[]){v_xs_24337})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24327, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24327);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24363 = heff_field(v_x1_24326, 0);
    V v_ru_24x1_24326_24Bug = heff_take_reuse_n(v_x1_24326, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24326_24Bug, TAG_Bug, 1, (V[]){v_what_24363});
  }
  default: return heff_nomatch(v_x1_24326);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args) {
  V v_d_24322 = args[0];
  V v_u_24323 = args[1];
  heff_drop(v_d_24322);
  heff_drop(v_u_24323);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam29_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args) {
  V v_d_24389 = args[0];
  V v_x_24390 = args[1];
  V v_a_24388 = heff_env(self)[0];
  V v_xs_24379 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24391 = heff_tr(heff_call(v_x_24390, 1, (V[]){v_d_24389}));
  switch (heff_tag_of(v_x1_24391)) {
  case TAG_Ok: {
    V v_v_24392 = heff_field(v_x1_24391, 0);
    V v_ru_24x1_24391_24Ok = heff_take_reuse_n(v_x1_24391, 1ULL, 1);
    if ((heff_intLe_c_lent(MK_INT(0LL), v_a_24388, 1) && ({ V v_t_242133 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24379)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; }); int c_ = heff_intLt_c_lent(v_a_24388, v_t_242133, 0); heff_drop(v_t_242133); c_; }))) {
      V v_t_24393 = (g_heff_2ecompile_2einterp_2esetAt(heff_arrayToList(v_xs_24379), v_a_24388, v_v_24392));
      V v_t_24394 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24393)});
      return heff_tag_at_n(v_ru_24x1_24391_24Ok, TAG_Ok, 1, (V[]){v_t_24394});
    } else {
      heff_drop(v_a_24388);
      heff_drop(v_v_24392);
      return heff_tag_at_n(v_ru_24x1_24391_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VArr, 1, (V[]){v_xs_24379})});
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24388);
    heff_drop(v_xs_24379);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24388);
    heff_drop(v_xs_24379);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24395 = heff_field(v_x1_24391, 0);
    V v_ru_24x1_24391_24Bug = heff_take_reuse_n(v_x1_24391, 1ULL, 1);
    heff_drop(v_a_24388);
    heff_drop(v_xs_24379);
    return heff_tag_at_n(v_ru_24x1_24391_24Bug, TAG_Bug, 1, (V[]){v_what_24395});
  }
  default: return heff_nomatch(v_x1_24391);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args) {
  V v_d_24380 = args[0];
  V v_a_24381 = args[1];
  V v_xs_24379 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24382 = heff_tr(heff_call(v_a_24381, 1, (V[]){v_d_24380}));
  switch (heff_tag_of(v_x1_24382)) {
  case TAG_Ok: {
    V v_v_24383 = heff_field(v_x1_24382, 0);
    V v_ru_24x1_24382_24Ok = heff_take_reuse_n(v_x1_24382, 1ULL, 1);
    switch (heff_tag_of(v_v_24383)) {
    case TAG_VFun: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24383, 0ULL, 2);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24388 = heff_field(v_v_24383, 0);
      V v_ru_24v_24383_24VInt = heff_take_reuse_n(v_v_24383, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24382_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24383_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam34, 2, 2, (V[]){v_a_24388, v_xs_24379})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24383, 0ULL, 2);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24383);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24379);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24379);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24404 = heff_field(v_x1_24382, 0);
    V v_ru_24x1_24382_24Bug = heff_take_reuse_n(v_x1_24382, 1ULL, 1);
    heff_drop(v_xs_24379);
    return heff_tag_at_n(v_ru_24x1_24382_24Bug, TAG_Bug, 1, (V[]){v_what_24404});
  }
  default: return heff_nomatch(v_x1_24382);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args) {
  V v_d_24366 = args[0];
  V v_a_24367 = args[1];
  V v_x1_24368 = heff_tr(heff_call(v_a_24367, 1, (V[]){v_d_24366}));
  switch (heff_tag_of(v_x1_24368)) {
  case TAG_Ok: {
    V v_v_24369 = heff_field(v_x1_24368, 0);
    V v_ru_24x1_24368_24Ok = heff_take_reuse_n(v_x1_24368, 1ULL, 1);
    switch (heff_tag_of(v_v_24369)) {
    case TAG_VFun: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24369, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24379 = heff_field(v_v_24369, 0);
      V v_ru_24v_24369_24VArr = heff_take_reuse_n(v_v_24369, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24368_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24369_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam33, 2, 1, (V[]){v_xs_24379})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24369, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24369);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24408 = heff_field(v_x1_24368, 0);
    V v_ru_24x1_24368_24Bug = heff_take_reuse_n(v_x1_24368, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24368_24Bug, TAG_Bug, 1, (V[]){v_what_24408});
  }
  default: return heff_nomatch(v_x1_24368);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args) {
  V v_d_24364 = args[0];
  V v_u_24365 = args[1];
  heff_drop(v_d_24364);
  heff_drop(v_u_24365);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam32_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args) {
  V v_vs_24424 = args[0];
  V v_t_24425 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_vs_24424)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24425});
}
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args) {
  V v_d_24420 = args[0];
  V v_f_24421 = args[1];
  V v_a_24419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24422 = heff_tr(heff_call(v_f_24421, 1, (V[]){heff_dup(v_d_24420)}));
  switch (heff_tag_of(v_x1_24422)) {
  case TAG_Ok: {
    V v_v_24423 = heff_field(v_x1_24422, 0);
    heff_take_n(v_x1_24422, 1ULL, 1);
    return (g_heff_2ecompile_2einterp_2egenGo(v_d_24420, MK_INT(0LL), v_a_24419, v_v_24423, ((V)&g_heff_2ecompile_2einterp_2eprim_lam38_clo)));
  }
  case TAG_Abn: {
    heff_drop(v_d_24420);
    heff_drop(v_a_24419);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_24420);
    heff_drop(v_a_24419);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24426 = heff_field(v_x1_24422, 0);
    V v_ru_24x1_24422_24Bug = heff_take_reuse_n(v_x1_24422, 1ULL, 1);
    heff_drop(v_d_24420);
    heff_drop(v_a_24419);
    return heff_tag_at_n(v_ru_24x1_24422_24Bug, TAG_Bug, 1, (V[]){v_what_24426});
  }
  default: return heff_nomatch(v_x1_24422);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args) {
  V v_d_24411 = args[0];
  V v_a_24412 = args[1];
  V v_x1_24413 = heff_tr(heff_call(v_a_24412, 1, (V[]){v_d_24411}));
  switch (heff_tag_of(v_x1_24413)) {
  case TAG_Ok: {
    V v_v_24414 = heff_field(v_x1_24413, 0);
    V v_ru_24x1_24413_24Ok = heff_take_reuse_n(v_x1_24413, 1ULL, 1);
    switch (heff_tag_of(v_v_24414)) {
    case TAG_VFun: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24414, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24419 = heff_field(v_v_24414, 0);
      V v_ru_24v_24414_24VInt = heff_take_reuse_n(v_v_24414, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24413_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24414_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam37, 2, 1, (V[]){v_a_24419})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24414, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24414);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24435 = heff_field(v_x1_24413, 0);
    V v_ru_24x1_24413_24Bug = heff_take_reuse_n(v_x1_24413, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24413_24Bug, TAG_Bug, 1, (V[]){v_what_24435});
  }
  default: return heff_nomatch(v_x1_24413);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args) {
  V v_d_24409 = args[0];
  V v_u_24410 = args[1];
  heff_drop(v_d_24409);
  heff_drop(v_u_24410);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam36_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args) {
  V v_d_24438 = args[0];
  V v_l_24439 = args[1];
  V v_x1_24440 = heff_tr(heff_call(v_l_24439, 1, (V[]){v_d_24438}));
  switch (heff_tag_of(v_x1_24440)) {
  case TAG_Ok: {
    V v_v_24441 = heff_field(v_x1_24440, 0);
    V v_ru_24x1_24440_24Ok = heff_take_reuse_n(v_x1_24440, 1ULL, 1);
    V v_t_24442 = (g_heff_2ecompile_2einterp_2efromListV(v_v_24441, NTAG(TAG_Nil)));
    V v_t_24443 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24442)});
    return heff_tag_at_n(v_ru_24x1_24440_24Ok, TAG_Ok, 1, (V[]){v_t_24443});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24444 = heff_field(v_x1_24440, 0);
    V v_ru_24x1_24440_24Bug = heff_take_reuse_n(v_x1_24440, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24440_24Bug, TAG_Bug, 1, (V[]){v_what_24444});
  }
  default: return heff_nomatch(v_x1_24440);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args) {
  V v_d_24436 = args[0];
  V v_u_24437 = args[1];
  heff_drop(v_d_24436);
  heff_drop(v_u_24437);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam40_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args) {
  V v_d_24447 = args[0];
  V v_a_24448 = args[1];
  V v_x1_24449 = heff_tr(heff_call(v_a_24448, 1, (V[]){v_d_24447}));
  switch (heff_tag_of(v_x1_24449)) {
  case TAG_Ok: {
    V v_v_24450 = heff_field(v_x1_24449, 0);
    V v_ru_24x1_24449_24Ok = heff_take_reuse_n(v_x1_24449, 1ULL, 1);
    switch (heff_tag_of(v_v_24450)) {
    case TAG_VFun: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24450, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24460 = heff_field(v_v_24450, 0);
      heff_take_n(v_v_24450, 1ULL, 1);
      V v_t_24461 = (g_heff_2ecompile_2einterp_2etoListV(heff_arrayToList(v_xs_24460)));
      return heff_tag_at_n(v_ru_24x1_24449_24Ok, TAG_Ok, 1, (V[]){v_t_24461});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24450, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24450);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24465 = heff_field(v_x1_24449, 0);
    V v_ru_24x1_24449_24Bug = heff_take_reuse_n(v_x1_24449, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24449_24Bug, TAG_Bug, 1, (V[]){v_what_24465});
  }
  default: return heff_nomatch(v_x1_24449);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args) {
  V v_d_24445 = args[0];
  V v_u_24446 = args[1];
  heff_drop(v_d_24445);
  heff_drop(v_u_24446);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam42_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args) {
  V v_d_24477 = args[0];
  V v_x_24478 = args[1];
  V v_a_24476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24479 = heff_tr(heff_call(v_x_24478, 1, (V[]){v_d_24477}));
  switch (heff_tag_of(v_x1_24479)) {
  case TAG_Ok: {
    V v_v_24480 = heff_field(v_x1_24479, 0);
    V v_ru_24x1_24479_24Ok = heff_take_reuse_n(v_x1_24479, 1ULL, 1);
    V v_t_24481 = (g_list_2ereplicate(v_a_24476, v_v_24480));
    V v_t_24482 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24481)});
    return heff_tag_at_n(v_ru_24x1_24479_24Ok, TAG_Ok, 1, (V[]){v_t_24482});
  }
  case TAG_Abn: {
    heff_drop(v_a_24476);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24476);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24483 = heff_field(v_x1_24479, 0);
    V v_ru_24x1_24479_24Bug = heff_take_reuse_n(v_x1_24479, 1ULL, 1);
    heff_drop(v_a_24476);
    return heff_tag_at_n(v_ru_24x1_24479_24Bug, TAG_Bug, 1, (V[]){v_what_24483});
  }
  default: return heff_nomatch(v_x1_24479);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args) {
  V v_d_24468 = args[0];
  V v_a_24469 = args[1];
  V v_x1_24470 = heff_tr(heff_call(v_a_24469, 1, (V[]){v_d_24468}));
  switch (heff_tag_of(v_x1_24470)) {
  case TAG_Ok: {
    V v_v_24471 = heff_field(v_x1_24470, 0);
    V v_ru_24x1_24470_24Ok = heff_take_reuse_n(v_x1_24470, 1ULL, 1);
    switch (heff_tag_of(v_v_24471)) {
    case TAG_VFun: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24471, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24476 = heff_field(v_v_24471, 0);
      V v_ru_24v_24471_24VInt = heff_take_reuse_n(v_v_24471, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24470_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24471_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam45, 2, 1, (V[]){v_a_24476})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24471, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24471);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24492 = heff_field(v_x1_24470, 0);
    V v_ru_24x1_24470_24Bug = heff_take_reuse_n(v_x1_24470, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24470_24Bug, TAG_Bug, 1, (V[]){v_what_24492});
  }
  default: return heff_nomatch(v_x1_24470);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args) {
  V v_d_24466 = args[0];
  V v_u_24467 = args[1];
  heff_drop(v_d_24466);
  heff_drop(v_u_24467);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam44_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args) {
  V v_d_24518 = args[0];
  V v_a_24519 = args[1];
  V v_xs_24508 = heff_env(self)[0];
  V v_a_24517 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24520 = heff_tr(heff_call(v_a_24519, 1, (V[]){v_d_24518}));
  switch (heff_tag_of(v_x1_24520)) {
  case TAG_Ok: {
    V v_v_24521 = heff_field(v_x1_24520, 0);
    V v_ru_24x1_24520_24Ok = heff_take_reuse_n(v_x1_24520, 1ULL, 1);
    switch (heff_tag_of(v_v_24521)) {
    case TAG_VFun: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24521, 0ULL, 2);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24526 = heff_field(v_v_24521, 0);
      V v_ru_24v_24521_24VInt = heff_take_reuse_n(v_v_24521, 1ULL, 1);
      V v_t_24527 = ({ V b_0 = heff_arrayToList(v_xs_24508); V a_1 = v_a_24517; V a_2 = v_a_24526; V r_ = (g_heff_2ecompile_2einterp_2esliceV(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V v_t_24528 = heff_tag_at_n(v_ru_24v_24521_24VInt, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24527)});
      return heff_tag_at_n(v_ru_24x1_24520_24Ok, TAG_Ok, 1, (V[]){v_t_24528});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24521, 0ULL, 2);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24521);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24508);
    heff_drop(v_a_24517);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24508);
    heff_drop(v_a_24517);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24537 = heff_field(v_x1_24520, 0);
    V v_ru_24x1_24520_24Bug = heff_take_reuse_n(v_x1_24520, 1ULL, 1);
    heff_drop(v_xs_24508);
    heff_drop(v_a_24517);
    return heff_tag_at_n(v_ru_24x1_24520_24Bug, TAG_Bug, 1, (V[]){v_what_24537});
  }
  default: return heff_nomatch(v_x1_24520);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args) {
  V v_d_24509 = args[0];
  V v_a_24510 = args[1];
  V v_xs_24508 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24511 = heff_tr(heff_call(v_a_24510, 1, (V[]){v_d_24509}));
  switch (heff_tag_of(v_x1_24511)) {
  case TAG_Ok: {
    V v_v_24512 = heff_field(v_x1_24511, 0);
    V v_ru_24x1_24511_24Ok = heff_take_reuse_n(v_x1_24511, 1ULL, 1);
    switch (heff_tag_of(v_v_24512)) {
    case TAG_VFun: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24512, 0ULL, 2);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24517 = heff_field(v_v_24512, 0);
      V v_ru_24v_24512_24VInt = heff_take_reuse_n(v_v_24512, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24511_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24512_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam49, 2, 2, (V[]){v_xs_24508, v_a_24517})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24512, 0ULL, 2);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24512);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24508);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24508);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24546 = heff_field(v_x1_24511, 0);
    V v_ru_24x1_24511_24Bug = heff_take_reuse_n(v_x1_24511, 1ULL, 1);
    heff_drop(v_xs_24508);
    return heff_tag_at_n(v_ru_24x1_24511_24Bug, TAG_Bug, 1, (V[]){v_what_24546});
  }
  default: return heff_nomatch(v_x1_24511);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args) {
  V v_d_24495 = args[0];
  V v_a_24496 = args[1];
  V v_x1_24497 = heff_tr(heff_call(v_a_24496, 1, (V[]){v_d_24495}));
  switch (heff_tag_of(v_x1_24497)) {
  case TAG_Ok: {
    V v_v_24498 = heff_field(v_x1_24497, 0);
    V v_ru_24x1_24497_24Ok = heff_take_reuse_n(v_x1_24497, 1ULL, 1);
    switch (heff_tag_of(v_v_24498)) {
    case TAG_VFun: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24498, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24508 = heff_field(v_v_24498, 0);
      V v_ru_24v_24498_24VArr = heff_take_reuse_n(v_v_24498, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24497_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24498_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam48, 2, 1, (V[]){v_xs_24508})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24498, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24498);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24550 = heff_field(v_x1_24497, 0);
    V v_ru_24x1_24497_24Bug = heff_take_reuse_n(v_x1_24497, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24497_24Bug, TAG_Bug, 1, (V[]){v_what_24550});
  }
  default: return heff_nomatch(v_x1_24497);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args) {
  V v_d_24493 = args[0];
  V v_u_24494 = args[1];
  heff_drop(v_d_24493);
  heff_drop(v_u_24494);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam47_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args) {
  V v_d_24567 = args[0];
  V v_a_24568 = args[1];
  V v_xs_24566 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24569 = heff_tr(heff_call(v_a_24568, 1, (V[]){v_d_24567}));
  switch (heff_tag_of(v_x1_24569)) {
  case TAG_Ok: {
    V v_v_24570 = heff_field(v_x1_24569, 0);
    V v_ru_24x1_24569_24Ok = heff_take_reuse_n(v_x1_24569, 1ULL, 1);
    switch (heff_tag_of(v_v_24570)) {
    case TAG_VFun: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24570, 0ULL, 2);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24580 = heff_field(v_v_24570, 0);
      V v_ru_24v_24570_24VArr = heff_take_reuse_n(v_v_24570, 1ULL, 1);
      V v_t_24581 = (g_prelude_2e_2b_2b(heff_arrayToList(v_xs_24566), heff_arrayToList(v_xs_24580)));
      V v_t_24582 = heff_tag_at_n(v_ru_24v_24570_24VArr, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24581)});
      return heff_tag_at_n(v_ru_24x1_24569_24Ok, TAG_Ok, 1, (V[]){v_t_24582});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24570, 0ULL, 2);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24570);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24566);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24566);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24586 = heff_field(v_x1_24569, 0);
    V v_ru_24x1_24569_24Bug = heff_take_reuse_n(v_x1_24569, 1ULL, 1);
    heff_drop(v_xs_24566);
    return heff_tag_at_n(v_ru_24x1_24569_24Bug, TAG_Bug, 1, (V[]){v_what_24586});
  }
  default: return heff_nomatch(v_x1_24569);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args) {
  V v_d_24553 = args[0];
  V v_a_24554 = args[1];
  V v_x1_24555 = heff_tr(heff_call(v_a_24554, 1, (V[]){v_d_24553}));
  switch (heff_tag_of(v_x1_24555)) {
  case TAG_Ok: {
    V v_v_24556 = heff_field(v_x1_24555, 0);
    V v_ru_24x1_24555_24Ok = heff_take_reuse_n(v_x1_24555, 1ULL, 1);
    switch (heff_tag_of(v_v_24556)) {
    case TAG_VFun: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24556, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24566 = heff_field(v_v_24556, 0);
      V v_ru_24v_24556_24VArr = heff_take_reuse_n(v_v_24556, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24555_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24556_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam52, 2, 1, (V[]){v_xs_24566})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24556, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24556);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24590 = heff_field(v_x1_24555, 0);
    V v_ru_24x1_24555_24Bug = heff_take_reuse_n(v_x1_24555, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24555_24Bug, TAG_Bug, 1, (V[]){v_what_24590});
  }
  default: return heff_nomatch(v_x1_24555);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args) {
  V v_d_24551 = args[0];
  V v_u_24552 = args[1];
  heff_drop(v_d_24551);
  heff_drop(v_u_24552);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam51_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args) {
  V v_d_24616 = args[0];
  V v_x_24617 = args[1];
  V v_xs_24606 = heff_env(self)[0];
  V v_a_24615 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24618 = heff_tr(heff_call(v_x_24617, 1, (V[]){v_d_24616}));
  switch (heff_tag_of(v_x1_24618)) {
  case TAG_Ok: {
    V v_v_24619 = heff_field(v_x1_24618, 0);
    V v_ru_24x1_24618_24Ok = heff_take_reuse_n(v_x1_24618, 1ULL, 1);
    V v_xs_24620 = heff_arrayToList(v_xs_24606);
    V v_t_24621 = (g_list_2etake(heff_dup(v_a_24615), heff_dup(v_xs_24620)));
    V v_t_24622 = ({ V a_0 = v_a_24615; V a_1 = v_xs_24620; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_xs_24620); r_; });
    V v_t_24623 = (g_prelude_2e_2b_2b(v_t_24621, heff_tag_n(TAG_Cons, 2, (V[]){v_v_24619, v_t_24622})));
    V v_t_24624 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24623)});
    return heff_tag_at_n(v_ru_24x1_24618_24Ok, TAG_Ok, 1, (V[]){v_t_24624});
  }
  case TAG_Abn: {
    heff_drop(v_xs_24606);
    heff_drop(v_a_24615);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24606);
    heff_drop(v_a_24615);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24625 = heff_field(v_x1_24618, 0);
    V v_ru_24x1_24618_24Bug = heff_take_reuse_n(v_x1_24618, 1ULL, 1);
    heff_drop(v_xs_24606);
    heff_drop(v_a_24615);
    return heff_tag_at_n(v_ru_24x1_24618_24Bug, TAG_Bug, 1, (V[]){v_what_24625});
  }
  default: return heff_nomatch(v_x1_24618);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args) {
  V v_d_24607 = args[0];
  V v_a_24608 = args[1];
  V v_xs_24606 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24609 = heff_tr(heff_call(v_a_24608, 1, (V[]){v_d_24607}));
  switch (heff_tag_of(v_x1_24609)) {
  case TAG_Ok: {
    V v_v_24610 = heff_field(v_x1_24609, 0);
    V v_ru_24x1_24609_24Ok = heff_take_reuse_n(v_x1_24609, 1ULL, 1);
    switch (heff_tag_of(v_v_24610)) {
    case TAG_VFun: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24610, 0ULL, 2);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24615 = heff_field(v_v_24610, 0);
      V v_ru_24v_24610_24VInt = heff_take_reuse_n(v_v_24610, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24609_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24610_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam56, 2, 2, (V[]){v_xs_24606, v_a_24615})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24610, 0ULL, 2);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24610);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24606);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24606);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24634 = heff_field(v_x1_24609, 0);
    V v_ru_24x1_24609_24Bug = heff_take_reuse_n(v_x1_24609, 1ULL, 1);
    heff_drop(v_xs_24606);
    return heff_tag_at_n(v_ru_24x1_24609_24Bug, TAG_Bug, 1, (V[]){v_what_24634});
  }
  default: return heff_nomatch(v_x1_24609);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args) {
  V v_d_24593 = args[0];
  V v_a_24594 = args[1];
  V v_x1_24595 = heff_tr(heff_call(v_a_24594, 1, (V[]){v_d_24593}));
  switch (heff_tag_of(v_x1_24595)) {
  case TAG_Ok: {
    V v_v_24596 = heff_field(v_x1_24595, 0);
    V v_ru_24x1_24595_24Ok = heff_take_reuse_n(v_x1_24595, 1ULL, 1);
    switch (heff_tag_of(v_v_24596)) {
    case TAG_VFun: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24596, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24606 = heff_field(v_v_24596, 0);
      V v_ru_24v_24596_24VArr = heff_take_reuse_n(v_v_24596, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24595_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24596_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam55, 2, 1, (V[]){v_xs_24606})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24596, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24596);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24638 = heff_field(v_x1_24595, 0);
    V v_ru_24x1_24595_24Bug = heff_take_reuse_n(v_x1_24595, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24595_24Bug, TAG_Bug, 1, (V[]){v_what_24638});
  }
  default: return heff_nomatch(v_x1_24595);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args) {
  V v_d_24591 = args[0];
  V v_u_24592 = args[1];
  heff_drop(v_d_24591);
  heff_drop(v_u_24592);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam54_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args) {
  V v_d_24655 = args[0];
  V v_a_24656 = args[1];
  V v_xs_24654 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24657 = heff_tr(heff_call(v_a_24656, 1, (V[]){v_d_24655}));
  switch (heff_tag_of(v_x1_24657)) {
  case TAG_Ok: {
    V v_v_24658 = heff_field(v_x1_24657, 0);
    V v_ru_24x1_24657_24Ok = heff_take_reuse_n(v_x1_24657, 1ULL, 1);
    switch (heff_tag_of(v_v_24658)) {
    case TAG_VFun: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24658, 0ULL, 2);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24663 = heff_field(v_v_24658, 0);
      V v_ru_24v_24658_24VInt = heff_take_reuse_n(v_v_24658, 1ULL, 1);
      V v_xs_24664 = heff_arrayToList(v_xs_24654);
      V v_t_24667;
      if ((heff_intLe_c_lent(MK_INT(0LL), v_a_24663, 1) && ({ V v_t_242134 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_24664)); int c_ = heff_intLt_c_lent(v_a_24663, v_t_242134, 0); heff_drop(v_t_242134); c_; }))) {
        V v_t_24665 = (g_list_2etake(heff_dup(v_a_24663), heff_dup(v_xs_24664)));
        V v_t_24666 = ({ V a_0 = heff_intAdd(v_a_24663, MK_INT(1LL)); V a_1 = v_xs_24664; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_xs_24664); r_; });
        v_t_24667 = (g_prelude_2e_2b_2b(v_t_24665, v_t_24666));
      } else {
        heff_drop(v_a_24663);
        v_t_24667 = v_xs_24664;
      }
      V v_t_24668 = heff_tag_at_n(v_ru_24v_24658_24VInt, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24667)});
      return heff_tag_at_n(v_ru_24x1_24657_24Ok, TAG_Ok, 1, (V[]){v_t_24668});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24658, 0ULL, 2);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24658);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24654);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24654);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24677 = heff_field(v_x1_24657, 0);
    V v_ru_24x1_24657_24Bug = heff_take_reuse_n(v_x1_24657, 1ULL, 1);
    heff_drop(v_xs_24654);
    return heff_tag_at_n(v_ru_24x1_24657_24Bug, TAG_Bug, 1, (V[]){v_what_24677});
  }
  default: return heff_nomatch(v_x1_24657);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args) {
  V v_d_24641 = args[0];
  V v_a_24642 = args[1];
  V v_x1_24643 = heff_tr(heff_call(v_a_24642, 1, (V[]){v_d_24641}));
  switch (heff_tag_of(v_x1_24643)) {
  case TAG_Ok: {
    V v_v_24644 = heff_field(v_x1_24643, 0);
    V v_ru_24x1_24643_24Ok = heff_take_reuse_n(v_x1_24643, 1ULL, 1);
    switch (heff_tag_of(v_v_24644)) {
    case TAG_VFun: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24644, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24654 = heff_field(v_v_24644, 0);
      V v_ru_24v_24644_24VArr = heff_take_reuse_n(v_v_24644, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24643_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24644_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam59, 2, 1, (V[]){v_xs_24654})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24644, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24644);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24681 = heff_field(v_x1_24643, 0);
    V v_ru_24x1_24643_24Bug = heff_take_reuse_n(v_x1_24643, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24643_24Bug, TAG_Bug, 1, (V[]){v_what_24681});
  }
  default: return heff_nomatch(v_x1_24643);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args) {
  V v_d_24639 = args[0];
  V v_u_24640 = args[1];
  heff_drop(v_d_24639);
  heff_drop(v_u_24640);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam58_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args) {
  V v_d_24698 = args[0];
  V v_x_24699 = args[1];
  V v_xs_24697 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24700 = heff_tr(heff_call(v_x_24699, 1, (V[]){v_d_24698}));
  switch (heff_tag_of(v_x1_24700)) {
  case TAG_Ok: {
    V v_v_24701 = heff_field(v_x1_24700, 0);
    V v_ru_24x1_24700_24Ok = heff_take_reuse_n(v_x1_24700, 1ULL, 1);
    V v_t_24702 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_24701, NTAG(TAG_Nil)});
    V v_t_24703 = (g_prelude_2e_2b_2b(heff_arrayToList(v_xs_24697), v_t_24702));
    V v_t_24704 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24703)});
    return heff_tag_at_n(v_ru_24x1_24700_24Ok, TAG_Ok, 1, (V[]){v_t_24704});
  }
  case TAG_Abn: {
    heff_drop(v_xs_24697);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24697);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24705 = heff_field(v_x1_24700, 0);
    V v_ru_24x1_24700_24Bug = heff_take_reuse_n(v_x1_24700, 1ULL, 1);
    heff_drop(v_xs_24697);
    return heff_tag_at_n(v_ru_24x1_24700_24Bug, TAG_Bug, 1, (V[]){v_what_24705});
  }
  default: return heff_nomatch(v_x1_24700);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args) {
  V v_d_24684 = args[0];
  V v_a_24685 = args[1];
  V v_x1_24686 = heff_tr(heff_call(v_a_24685, 1, (V[]){v_d_24684}));
  switch (heff_tag_of(v_x1_24686)) {
  case TAG_Ok: {
    V v_v_24687 = heff_field(v_x1_24686, 0);
    V v_ru_24x1_24686_24Ok = heff_take_reuse_n(v_x1_24686, 1ULL, 1);
    switch (heff_tag_of(v_v_24687)) {
    case TAG_VFun: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24687, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24697 = heff_field(v_v_24687, 0);
      V v_ru_24v_24687_24VArr = heff_take_reuse_n(v_v_24687, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24686_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24687_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam62, 2, 1, (V[]){v_xs_24697})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24687, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24687);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24709 = heff_field(v_x1_24686, 0);
    V v_ru_24x1_24686_24Bug = heff_take_reuse_n(v_x1_24686, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24686_24Bug, TAG_Bug, 1, (V[]){v_what_24709});
  }
  default: return heff_nomatch(v_x1_24686);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args) {
  V v_d_24682 = args[0];
  V v_u_24683 = args[1];
  heff_drop(v_d_24682);
  heff_drop(v_u_24683);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam61_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args) {
  V v_d_24726 = args[0];
  V v_a_24727 = args[1];
  V v_xs_24725 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24728 = heff_tr(heff_call(v_a_24727, 1, (V[]){v_d_24726}));
  switch (heff_tag_of(v_x1_24728)) {
  case TAG_Ok: {
    V v_v_24729 = heff_field(v_x1_24728, 0);
    V v_ru_24x1_24728_24Ok = heff_take_reuse_n(v_x1_24728, 1ULL, 1);
    switch (heff_tag_of(v_v_24729)) {
    case TAG_VFun: {
      heff_take_n(v_v_24729, 0ULL, 1);
      heff_drop(v_xs_24725);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24729, 0ULL, 1);
      heff_drop(v_xs_24725);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24729, 0ULL, 2);
      heff_drop(v_xs_24725);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_ru_24v_24729_24VInt = heff_take_reuse_n(v_v_24729, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24728_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24729_24VInt, TAG_VArr, 1, (V[]){v_xs_24725})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24729, 0ULL, 1);
      heff_drop(v_xs_24725);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24729, 0ULL, 1);
      heff_drop(v_xs_24725);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24729, 0ULL, 1);
      heff_drop(v_xs_24725);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24729, 0ULL, 1);
      heff_drop(v_xs_24725);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24729, 0ULL, 1);
      heff_drop(v_xs_24725);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24729, 0ULL, 1);
      heff_drop(v_xs_24725);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24729, 0ULL, 2);
      heff_drop(v_xs_24725);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24725);
      heff_drop_cell(v_ru_24x1_24728_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24729);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24725);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24725);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24743 = heff_field(v_x1_24728, 0);
    V v_ru_24x1_24728_24Bug = heff_take_reuse_n(v_x1_24728, 1ULL, 1);
    heff_drop(v_xs_24725);
    return heff_tag_at_n(v_ru_24x1_24728_24Bug, TAG_Bug, 1, (V[]){v_what_24743});
  }
  default: return heff_nomatch(v_x1_24728);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args) {
  V v_d_24712 = args[0];
  V v_a_24713 = args[1];
  V v_x1_24714 = heff_tr(heff_call(v_a_24713, 1, (V[]){v_d_24712}));
  switch (heff_tag_of(v_x1_24714)) {
  case TAG_Ok: {
    V v_v_24715 = heff_field(v_x1_24714, 0);
    V v_ru_24x1_24714_24Ok = heff_take_reuse_n(v_x1_24714, 1ULL, 1);
    switch (heff_tag_of(v_v_24715)) {
    case TAG_VFun: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24715, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24725 = heff_field(v_v_24715, 0);
      V v_ru_24v_24715_24VArr = heff_take_reuse_n(v_v_24715, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24714_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24715_24VArr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam65, 2, 1, (V[]){v_xs_24725})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24715, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24715);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24747 = heff_field(v_x1_24714, 0);
    V v_ru_24x1_24714_24Bug = heff_take_reuse_n(v_x1_24714, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24714_24Bug, TAG_Bug, 1, (V[]){v_what_24747});
  }
  default: return heff_nomatch(v_x1_24714);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args) {
  V v_d_24710 = args[0];
  V v_u_24711 = args[1];
  heff_drop(v_d_24710);
  heff_drop(v_u_24711);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam64_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args) {
  V v_d_24748 = args[0];
  V v_a_24749 = args[1];
  V v_x1_24750 = heff_tr(heff_call(v_a_24749, 1, (V[]){v_d_24748}));
  switch (heff_tag_of(v_x1_24750)) {
  case TAG_Ok: {
    V v_v_24751 = heff_field(v_x1_24750, 0);
    V v_ru_24x1_24750_24Ok = heff_take_reuse_n(v_x1_24750, 1ULL, 1);
    switch (heff_tag_of(v_v_24751)) {
    case TAG_VFun: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24751, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24759 = heff_field(v_v_24751, 0);
      V v_ru_24v_24751_24VStr = heff_take_reuse_n(v_v_24751, 1ULL, 1);
      V v_t_24760 = heff_tag_at_n(v_ru_24v_24751_24VStr, TAG_VInt, 1, (V[]){heff_strLength(v_a_24759)});
      return heff_tag_at_n(v_ru_24x1_24750_24Ok, TAG_Ok, 1, (V[]){v_t_24760});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24751, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24751, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24751);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24766 = heff_field(v_x1_24750, 0);
    V v_ru_24x1_24750_24Bug = heff_take_reuse_n(v_x1_24750, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24750_24Bug, TAG_Bug, 1, (V[]){v_what_24766});
  }
  default: return heff_nomatch(v_x1_24750);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args) {
  V v_d_24788 = args[0];
  V v_a_24789 = args[1];
  V v_a_24778 = heff_env(self)[0];
  V v_a_24787 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24790 = heff_tr(heff_call(v_a_24789, 1, (V[]){v_d_24788}));
  switch (heff_tag_of(v_x1_24790)) {
  case TAG_Ok: {
    V v_v_24791 = heff_field(v_x1_24790, 0);
    V v_ru_24x1_24790_24Ok = heff_take_reuse_n(v_x1_24790, 1ULL, 1);
    switch (heff_tag_of(v_v_24791)) {
    case TAG_VFun: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop(v_a_24787);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop(v_a_24787);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24791, 0ULL, 2);
      heff_drop(v_a_24778);
      heff_drop(v_a_24787);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24796 = heff_field(v_v_24791, 0);
      V v_ru_24v_24791_24VInt = heff_take_reuse_n(v_v_24791, 1ULL, 1);
      V v_t_24797 = heff_tag_at_n(v_ru_24v_24791_24VInt, TAG_VStr, 1, (V[]){heff_strSlice(v_a_24778, v_a_24787, v_a_24796)});
      return heff_tag_at_n(v_ru_24x1_24790_24Ok, TAG_Ok, 1, (V[]){v_t_24797});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24791, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop(v_a_24787);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop(v_a_24787);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop(v_a_24787);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop(v_a_24787);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop(v_a_24787);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24791, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop(v_a_24787);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24791, 0ULL, 2);
      heff_drop(v_a_24778);
      heff_drop(v_a_24787);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24778);
      heff_drop(v_a_24787);
      heff_drop_cell(v_ru_24x1_24790_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24791);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24778);
    heff_drop(v_a_24787);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24778);
    heff_drop(v_a_24787);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24806 = heff_field(v_x1_24790, 0);
    V v_ru_24x1_24790_24Bug = heff_take_reuse_n(v_x1_24790, 1ULL, 1);
    heff_drop(v_a_24778);
    heff_drop(v_a_24787);
    return heff_tag_at_n(v_ru_24x1_24790_24Bug, TAG_Bug, 1, (V[]){v_what_24806});
  }
  default: return heff_nomatch(v_x1_24790);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args) {
  V v_d_24779 = args[0];
  V v_a_24780 = args[1];
  V v_a_24778 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24781 = heff_tr(heff_call(v_a_24780, 1, (V[]){v_d_24779}));
  switch (heff_tag_of(v_x1_24781)) {
  case TAG_Ok: {
    V v_v_24782 = heff_field(v_x1_24781, 0);
    V v_ru_24x1_24781_24Ok = heff_take_reuse_n(v_x1_24781, 1ULL, 1);
    switch (heff_tag_of(v_v_24782)) {
    case TAG_VFun: {
      heff_take_n(v_v_24782, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24782, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24782, 0ULL, 2);
      heff_drop(v_a_24778);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24787 = heff_field(v_v_24782, 0);
      V v_ru_24v_24782_24VInt = heff_take_reuse_n(v_v_24782, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24781_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24782_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam69, 2, 2, (V[]){v_a_24778, v_a_24787})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24782, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24782, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24782, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24782, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24782, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24782, 0ULL, 1);
      heff_drop(v_a_24778);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24782, 0ULL, 2);
      heff_drop(v_a_24778);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24778);
      heff_drop_cell(v_ru_24x1_24781_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24782);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24778);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24778);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24815 = heff_field(v_x1_24781, 0);
    V v_ru_24x1_24781_24Bug = heff_take_reuse_n(v_x1_24781, 1ULL, 1);
    heff_drop(v_a_24778);
    return heff_tag_at_n(v_ru_24x1_24781_24Bug, TAG_Bug, 1, (V[]){v_what_24815});
  }
  default: return heff_nomatch(v_x1_24781);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args) {
  V v_d_24767 = args[0];
  V v_a_24768 = args[1];
  V v_x1_24769 = heff_tr(heff_call(v_a_24768, 1, (V[]){v_d_24767}));
  switch (heff_tag_of(v_x1_24769)) {
  case TAG_Ok: {
    V v_v_24770 = heff_field(v_x1_24769, 0);
    V v_ru_24x1_24769_24Ok = heff_take_reuse_n(v_x1_24769, 1ULL, 1);
    switch (heff_tag_of(v_v_24770)) {
    case TAG_VFun: {
      heff_take_n(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24770, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24778 = heff_field(v_v_24770, 0);
      V v_ru_24v_24770_24VStr = heff_take_reuse_n(v_v_24770, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24769_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24770_24VStr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam68, 2, 1, (V[]){v_a_24778})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24770, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24770, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24769_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24770);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24821 = heff_field(v_x1_24769, 0);
    V v_ru_24x1_24769_24Bug = heff_take_reuse_n(v_x1_24769, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24769_24Bug, TAG_Bug, 1, (V[]){v_what_24821});
  }
  default: return heff_nomatch(v_x1_24769);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args) {
  V v_a_24822 = args[0];
  V v_b_24823 = args[1];
  V v_t_24824;
  if (heff_strEq_c(v_a_24822, v_b_24823)) {
    v_t_24824 = ((V)&g_heff_2ecompile_2einterp_2eprim_str15);
  } else {
    v_t_24824 = ((V)&g_heff_2ecompile_2einterp_2eprim_str16);
  }
  V v_t_24825 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24824, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24825});
}
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args) {
  V v_a_24826 = args[0];
  V v_b_24827 = args[1];
  V v_t_24828;
  if (heff_strLt_c(v_a_24826, v_b_24827)) {
    v_t_24828 = ((V)&g_heff_2ecompile_2einterp_2eprim_str17);
  } else {
    v_t_24828 = ((V)&g_heff_2ecompile_2einterp_2eprim_str18);
  }
  V v_t_24829 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24828, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24829});
}
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args) {
  V v_a_24830 = args[0];
  V v_b_24831 = args[1];
  V v_t_24832;
  if (heff_strLt_c_lent(v_a_24830, v_b_24831, 0)) {
    heff_drop(v_a_24830);
    heff_drop(v_b_24831);
    v_t_24832 = MK_INT(-1LL);
  } else {
    if (heff_strEq_c(v_a_24830, v_b_24831)) {
      v_t_24832 = MK_INT(0LL);
    } else {
      v_t_24832 = MK_INT(1LL);
    }
  }
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24832})});
}
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args) {
  V v_d_24835 = args[0];
  V v_a_24836 = args[1];
  V v_n_24833 = heff_env(self)[0];
  V v_a_24834 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24837 = heff_tr(heff_call(v_a_24836, 1, (V[]){v_d_24835}));
  switch (heff_tag_of(v_x1_24837)) {
  case TAG_Ok: {
    V v_v_24838 = heff_field(v_x1_24837, 0);
    V v_ru_24x1_24837_24Ok = heff_take_reuse_n(v_x1_24837, 1ULL, 1);
    switch (heff_tag_of(v_v_24838)) {
    case TAG_VFun: {
      heff_take_n(v_v_24838, 0ULL, 1);
      heff_drop(v_n_24833);
      heff_drop(v_a_24834);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24838, 0ULL, 1);
      heff_drop(v_n_24833);
      heff_drop(v_a_24834);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24838, 0ULL, 2);
      heff_drop(v_n_24833);
      heff_drop(v_a_24834);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24843 = heff_field(v_v_24838, 0);
      V v_ru_24v_24838_24VInt = heff_take_reuse_n(v_v_24838, 1ULL, 1);
      V v_t_24844;
      if (heff_intLe_c_lent(MK_INT(0LL), v_a_24843, 1)) {
        v_t_24844 = v_a_24843;
      } else {
        heff_drop(v_a_24843);
        v_t_24844 = MK_INT(0LL);
      }
      V v_j_24845 = heff_strFind(v_n_24833, v_a_24834, v_t_24844);
      V v_t_24846;
      if (heff_intLt_c_lent(v_j_24845, MK_INT(0LL), 2)) {
        heff_drop(v_j_24845);
        v_t_24846 = MK_INT(-1LL);
      } else {
        v_t_24846 = v_j_24845;
      }
      return heff_tag_at_n(v_ru_24x1_24837_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24838_24VInt, TAG_VInt, 1, (V[]){v_t_24846})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24838, 0ULL, 1);
      heff_drop(v_n_24833);
      heff_drop(v_a_24834);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24838, 0ULL, 1);
      heff_drop(v_n_24833);
      heff_drop(v_a_24834);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24838, 0ULL, 1);
      heff_drop(v_n_24833);
      heff_drop(v_a_24834);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24838, 0ULL, 1);
      heff_drop(v_n_24833);
      heff_drop(v_a_24834);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24838, 0ULL, 1);
      heff_drop(v_n_24833);
      heff_drop(v_a_24834);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24838, 0ULL, 1);
      heff_drop(v_n_24833);
      heff_drop(v_a_24834);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24838, 0ULL, 2);
      heff_drop(v_n_24833);
      heff_drop(v_a_24834);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_n_24833);
      heff_drop(v_a_24834);
      heff_drop_cell(v_ru_24x1_24837_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24838);
    }
  }
  case TAG_Abn: {
    heff_drop(v_n_24833);
    heff_drop(v_a_24834);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_n_24833);
    heff_drop(v_a_24834);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24855 = heff_field(v_x1_24837, 0);
    V v_ru_24x1_24837_24Bug = heff_take_reuse_n(v_x1_24837, 1ULL, 1);
    heff_drop(v_n_24833);
    heff_drop(v_a_24834);
    return heff_tag_at_n(v_ru_24x1_24837_24Bug, TAG_Bug, 1, (V[]){v_what_24855});
  }
  default: return heff_nomatch(v_x1_24837);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args) {
  V v_n_24833 = args[0];
  V v_a_24834 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam74, 2, 2, (V[]){v_n_24833, v_a_24834})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args) {
  V v_a_24856 = args[0];
  V v_b_24857 = args[1];
  V v_t_24858;
  if (heff_intEq_c(v_a_24856, v_b_24857)) {
    v_t_24858 = ((V)&g_heff_2ecompile_2einterp_2eprim_str19);
  } else {
    v_t_24858 = ((V)&g_heff_2ecompile_2einterp_2eprim_str20);
  }
  V v_t_24859 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24858, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24859});
}
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args) {
  V v_a_24860 = args[0];
  V v_b_24861 = args[1];
  V v_t_24862;
  if (heff_intLt_c(v_a_24860, v_b_24861)) {
    v_t_24862 = ((V)&g_heff_2ecompile_2einterp_2eprim_str21);
  } else {
    v_t_24862 = ((V)&g_heff_2ecompile_2einterp_2eprim_str22);
  }
  V v_t_24863 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24862, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24863});
}
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args) {
  V v_a_24864 = args[0];
  V v_b_24865 = args[1];
  V v_t_24866;
  if (heff_intLe_c(v_a_24864, v_b_24865)) {
    v_t_24866 = ((V)&g_heff_2ecompile_2einterp_2eprim_str23);
  } else {
    v_t_24866 = ((V)&g_heff_2ecompile_2einterp_2eprim_str24);
  }
  V v_t_24867 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24866, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24867});
}
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args) {
  V v_d_24868 = args[0];
  V v_a_24869 = args[1];
  V v_x1_24870 = heff_tr(heff_call(v_a_24869, 1, (V[]){v_d_24868}));
  switch (heff_tag_of(v_x1_24870)) {
  case TAG_Ok: {
    V v_v_24871 = heff_field(v_x1_24870, 0);
    V v_ru_24x1_24870_24Ok = heff_take_reuse_n(v_x1_24870, 1ULL, 1);
    switch (heff_tag_of(v_v_24871)) {
    case TAG_VFun: {
      heff_take_n(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24871, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VRune: {
      V v_a_24880 = heff_field(v_v_24871, 0);
      V v_ru_24v_24871_24VRune = heff_take_reuse_n(v_v_24871, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24870_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24871_24VRune, TAG_VInt, 1, (V[]){v_a_24880})});
    }
    case TAG_VArr: {
      heff_take_n(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24871, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24871, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24870_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    default: return heff_nomatch(v_v_24871);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24885 = heff_field(v_x1_24870, 0);
    V v_ru_24x1_24870_24Bug = heff_take_reuse_n(v_x1_24870, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24870_24Bug, TAG_Bug, 1, (V[]){v_what_24885});
  }
  default: return heff_nomatch(v_x1_24870);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args) {
  V v_d_24886 = args[0];
  V v_a_24887 = args[1];
  V v_x1_24888 = heff_tr(heff_call(v_a_24887, 1, (V[]){v_d_24886}));
  switch (heff_tag_of(v_x1_24888)) {
  case TAG_Ok: {
    V v_v_24889 = heff_field(v_x1_24888, 0);
    V v_ru_24x1_24888_24Ok = heff_take_reuse_n(v_x1_24888, 1ULL, 1);
    switch (heff_tag_of(v_v_24889)) {
    case TAG_VFun: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24889, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24894 = heff_field(v_v_24889, 0);
      V v_ru_24v_24889_24VInt = heff_take_reuse_n(v_v_24889, 1ULL, 1);
      V v_t_24895 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_24896 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_24897 = heff_intSub(v_a_24894, heff_intSub(MK_INT(0LL), v_t_24896));
      V v_t_24898 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(32LL)));
      V v_t_24899 = heff_intAdd(heff_intSub(MK_INT(0LL), v_t_24895), heff_intMod(v_t_24897, v_t_24898));
      return heff_tag_at_n(v_ru_24x1_24888_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24889_24VInt, TAG_VRune, 1, (V[]){v_t_24899})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24889, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24889, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24888_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24889);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24908 = heff_field(v_x1_24888, 0);
    V v_ru_24x1_24888_24Bug = heff_take_reuse_n(v_x1_24888, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24888_24Bug, TAG_Bug, 1, (V[]){v_what_24908});
  }
  default: return heff_nomatch(v_x1_24888);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args) {
  V v_d_24911 = args[0];
  V v_a_24912 = args[1];
  V f_ = v_a_24912;
  args[0] = v_d_24911;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args) {
  V v_d_24909 = args[0];
  V v_u_24910 = args[1];
  heff_drop(v_d_24909);
  heff_drop(v_u_24910);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam81_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args) {
  V v_d_24925 = args[0];
  V v_a_24926 = args[1];
  V v_a_24924 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24927 = heff_tr(heff_call(v_a_24926, 1, (V[]){v_d_24925}));
  switch (heff_tag_of(v_x1_24927)) {
  case TAG_Ok: {
    V v_v_24928 = heff_field(v_x1_24927, 0);
    V v_ru_24x1_24927_24Ok = heff_take_reuse_n(v_x1_24927, 1ULL, 1);
    switch (heff_tag_of(v_v_24928)) {
    case TAG_VFun: {
      heff_take_n(v_v_24928, 0ULL, 1);
      heff_drop(v_a_24924);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24928, 0ULL, 1);
      heff_drop(v_a_24924);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24928, 0ULL, 2);
      heff_drop(v_a_24924);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24933 = heff_field(v_v_24928, 0);
      V v_ru_24v_24928_24VInt = heff_take_reuse_n(v_v_24928, 1ULL, 1);
      V v_t_24934 = heff_tag_at_n(v_ru_24v_24928_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_24924, v_a_24933)});
      return heff_tag_at_n(v_ru_24x1_24927_24Ok, TAG_Ok, 1, (V[]){v_t_24934});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24928, 0ULL, 1);
      heff_drop(v_a_24924);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24928, 0ULL, 1);
      heff_drop(v_a_24924);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24928, 0ULL, 1);
      heff_drop(v_a_24924);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24928, 0ULL, 1);
      heff_drop(v_a_24924);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24928, 0ULL, 1);
      heff_drop(v_a_24924);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24928, 0ULL, 1);
      heff_drop(v_a_24924);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24928, 0ULL, 2);
      heff_drop(v_a_24924);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24924);
      heff_drop_cell(v_ru_24x1_24927_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24928);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24924);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24924);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24943 = heff_field(v_x1_24927, 0);
    V v_ru_24x1_24927_24Bug = heff_take_reuse_n(v_x1_24927, 1ULL, 1);
    heff_drop(v_a_24924);
    return heff_tag_at_n(v_ru_24x1_24927_24Bug, TAG_Bug, 1, (V[]){v_what_24943});
  }
  default: return heff_nomatch(v_x1_24927);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args) {
  V v_d_24913 = args[0];
  V v_a_24914 = args[1];
  V v_x1_24915 = heff_tr(heff_call(v_a_24914, 1, (V[]){v_d_24913}));
  switch (heff_tag_of(v_x1_24915)) {
  case TAG_Ok: {
    V v_v_24916 = heff_field(v_x1_24915, 0);
    V v_ru_24x1_24915_24Ok = heff_take_reuse_n(v_x1_24915, 1ULL, 1);
    switch (heff_tag_of(v_v_24916)) {
    case TAG_VFun: {
      heff_take_n(v_v_24916, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24916, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24916, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24916, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24916, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24916, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24924 = heff_field(v_v_24916, 0);
      V v_ru_24v_24916_24VStr = heff_take_reuse_n(v_v_24916, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24915_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24916_24VStr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam83, 2, 1, (V[]){v_a_24924})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24916, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24916, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24916, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24916, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24916);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24949 = heff_field(v_x1_24915, 0);
    V v_ru_24x1_24915_24Bug = heff_take_reuse_n(v_x1_24915, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24915_24Bug, TAG_Bug, 1, (V[]){v_what_24949});
  }
  default: return heff_nomatch(v_x1_24915);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args) {
  V v_d_24950 = args[0];
  V v_a_24951 = args[1];
  V v_x1_24952 = heff_tr(heff_call(v_a_24951, 1, (V[]){v_d_24950}));
  switch (heff_tag_of(v_x1_24952)) {
  case TAG_Ok: {
    V v_v_24953 = heff_field(v_x1_24952, 0);
    V v_ru_24x1_24952_24Ok = heff_take_reuse_n(v_x1_24952, 1ULL, 1);
    switch (heff_tag_of(v_v_24953)) {
    case TAG_VFun: {
      heff_take_n(v_v_24953, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24952_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24953, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24952_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24953, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24952_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24958 = heff_field(v_v_24953, 0);
      V v_ru_24v_24953_24VInt = heff_take_reuse_n(v_v_24953, 1ULL, 1);
      V v_t_24959 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_a_24958)));
      return heff_tag_at_n(v_ru_24x1_24952_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24953_24VInt, TAG_VStr, 1, (V[]){v_t_24959})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24953, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24952_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24953, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24952_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24953, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24952_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24953, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24952_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24953, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24952_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24953, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24952_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24953, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24952_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24952_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24953);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24968 = heff_field(v_x1_24952, 0);
    V v_ru_24x1_24952_24Bug = heff_take_reuse_n(v_x1_24952, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24952_24Bug, TAG_Bug, 1, (V[]){v_what_24968});
  }
  default: return heff_nomatch(v_x1_24952);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args) {
  V v_d_24981 = args[0];
  V v_a_24982 = args[1];
  V v_a_24980 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24983 = heff_tr(heff_call(v_a_24982, 1, (V[]){v_d_24981}));
  switch (heff_tag_of(v_x1_24983)) {
  case TAG_Ok: {
    V v_v_24984 = heff_field(v_x1_24983, 0);
    V v_ru_24x1_24983_24Ok = heff_take_reuse_n(v_x1_24983, 1ULL, 1);
    switch (heff_tag_of(v_v_24984)) {
    case TAG_VFun: {
      heff_take_n(v_v_24984, 0ULL, 1);
      heff_drop(v_a_24980);
      heff_drop_cell(v_ru_24x1_24983_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24984, 0ULL, 1);
      heff_drop(v_a_24980);
      heff_drop_cell(v_ru_24x1_24983_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24984, 0ULL, 2);
      heff_drop(v_a_24980);
      heff_drop_cell(v_ru_24x1_24983_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24989 = heff_field(v_v_24984, 0);
      V v_ru_24v_24984_24VInt = heff_take_reuse_n(v_v_24984, 1ULL, 1);
      V v_t_24990 = heff_runeToInt(heff_strRuneAt(v_a_24980, v_a_24989));
      return heff_tag_at_n(v_ru_24x1_24983_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24984_24VInt, TAG_VRune, 1, (V[]){v_t_24990})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24984, 0ULL, 1);
      heff_drop(v_a_24980);
      heff_drop_cell(v_ru_24x1_24983_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24984, 0ULL, 1);
      heff_drop(v_a_24980);
      heff_drop_cell(v_ru_24x1_24983_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24984, 0ULL, 1);
      heff_drop(v_a_24980);
      heff_drop_cell(v_ru_24x1_24983_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24984, 0ULL, 1);
      heff_drop(v_a_24980);
      heff_drop_cell(v_ru_24x1_24983_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24984, 0ULL, 1);
      heff_drop(v_a_24980);
      heff_drop_cell(v_ru_24x1_24983_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24984, 0ULL, 1);
      heff_drop(v_a_24980);
      heff_drop_cell(v_ru_24x1_24983_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24984, 0ULL, 2);
      heff_drop(v_a_24980);
      heff_drop_cell(v_ru_24x1_24983_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24980);
      heff_drop_cell(v_ru_24x1_24983_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24984);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24980);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24980);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24999 = heff_field(v_x1_24983, 0);
    V v_ru_24x1_24983_24Bug = heff_take_reuse_n(v_x1_24983, 1ULL, 1);
    heff_drop(v_a_24980);
    return heff_tag_at_n(v_ru_24x1_24983_24Bug, TAG_Bug, 1, (V[]){v_what_24999});
  }
  default: return heff_nomatch(v_x1_24983);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args) {
  V v_d_24969 = args[0];
  V v_a_24970 = args[1];
  V v_x1_24971 = heff_tr(heff_call(v_a_24970, 1, (V[]){v_d_24969}));
  switch (heff_tag_of(v_x1_24971)) {
  case TAG_Ok: {
    V v_v_24972 = heff_field(v_x1_24971, 0);
    V v_ru_24x1_24971_24Ok = heff_take_reuse_n(v_x1_24971, 1ULL, 1);
    switch (heff_tag_of(v_v_24972)) {
    case TAG_VFun: {
      heff_take_n(v_v_24972, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24971_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24972, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24971_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24972, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24971_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24972, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24971_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24972, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24971_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24972, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24971_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24980 = heff_field(v_v_24972, 0);
      V v_ru_24v_24972_24VStr = heff_take_reuse_n(v_v_24972, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24971_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_24972_24VStr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam86, 2, 1, (V[]){v_a_24980})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24972, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24971_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24972, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24971_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24972, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24971_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24972, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24971_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24971_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24972);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241005 = heff_field(v_x1_24971, 0);
    V v_ru_24x1_24971_24Bug = heff_take_reuse_n(v_x1_24971, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24971_24Bug, TAG_Bug, 1, (V[]){v_what_241005});
  }
  default: return heff_nomatch(v_x1_24971);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args) {
  V v_d_241018 = args[0];
  V v_a_241019 = args[1];
  V v_a_241017 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241020 = heff_tr(heff_call(v_a_241019, 1, (V[]){v_d_241018}));
  switch (heff_tag_of(v_x1_241020)) {
  case TAG_Ok: {
    V v_v_241021 = heff_field(v_x1_241020, 0);
    V v_ru_24x1_241020_24Ok = heff_take_reuse_n(v_x1_241020, 1ULL, 1);
    switch (heff_tag_of(v_v_241021)) {
    case TAG_VFun: {
      heff_take_n(v_v_241021, 0ULL, 1);
      heff_drop(v_a_241017);
      heff_drop_cell(v_ru_24x1_241020_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241021, 0ULL, 1);
      heff_drop(v_a_241017);
      heff_drop_cell(v_ru_24x1_241020_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241021, 0ULL, 2);
      heff_drop(v_a_241017);
      heff_drop_cell(v_ru_24x1_241020_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241026 = heff_field(v_v_241021, 0);
      V v_ru_24v_241021_24VInt = heff_take_reuse_n(v_v_241021, 1ULL, 1);
      V v_t_241027 = heff_tag_at_n(v_ru_24v_241021_24VInt, TAG_VInt, 1, (V[]){heff_strRuneWidth(v_a_241017, v_a_241026)});
      return heff_tag_at_n(v_ru_24x1_241020_24Ok, TAG_Ok, 1, (V[]){v_t_241027});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241021, 0ULL, 1);
      heff_drop(v_a_241017);
      heff_drop_cell(v_ru_24x1_241020_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241021, 0ULL, 1);
      heff_drop(v_a_241017);
      heff_drop_cell(v_ru_24x1_241020_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241021, 0ULL, 1);
      heff_drop(v_a_241017);
      heff_drop_cell(v_ru_24x1_241020_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241021, 0ULL, 1);
      heff_drop(v_a_241017);
      heff_drop_cell(v_ru_24x1_241020_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241021, 0ULL, 1);
      heff_drop(v_a_241017);
      heff_drop_cell(v_ru_24x1_241020_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241021, 0ULL, 1);
      heff_drop(v_a_241017);
      heff_drop_cell(v_ru_24x1_241020_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241021, 0ULL, 2);
      heff_drop(v_a_241017);
      heff_drop_cell(v_ru_24x1_241020_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241017);
      heff_drop_cell(v_ru_24x1_241020_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241021);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241017);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241017);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241036 = heff_field(v_x1_241020, 0);
    V v_ru_24x1_241020_24Bug = heff_take_reuse_n(v_x1_241020, 1ULL, 1);
    heff_drop(v_a_241017);
    return heff_tag_at_n(v_ru_24x1_241020_24Bug, TAG_Bug, 1, (V[]){v_what_241036});
  }
  default: return heff_nomatch(v_x1_241020);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args) {
  V v_d_241006 = args[0];
  V v_a_241007 = args[1];
  V v_x1_241008 = heff_tr(heff_call(v_a_241007, 1, (V[]){v_d_241006}));
  switch (heff_tag_of(v_x1_241008)) {
  case TAG_Ok: {
    V v_v_241009 = heff_field(v_x1_241008, 0);
    V v_ru_24x1_241008_24Ok = heff_take_reuse_n(v_x1_241008, 1ULL, 1);
    switch (heff_tag_of(v_v_241009)) {
    case TAG_VFun: {
      heff_take_n(v_v_241009, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241008_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241009, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241008_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241009, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241008_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241009, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241008_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241009, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241008_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241009, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241008_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241017 = heff_field(v_v_241009, 0);
      V v_ru_24v_241009_24VStr = heff_take_reuse_n(v_v_241009, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241008_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241009_24VStr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam88, 2, 1, (V[]){v_a_241017})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241009, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241008_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241009, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241008_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241009, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241008_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241009, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241008_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241008_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241009);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241042 = heff_field(v_x1_241008, 0);
    V v_ru_24x1_241008_24Bug = heff_take_reuse_n(v_x1_241008, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241008_24Bug, TAG_Bug, 1, (V[]){v_what_241042});
  }
  default: return heff_nomatch(v_x1_241008);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args) {
  V v_d_241043 = args[0];
  V v_a_241044 = args[1];
  V v_x1_241045 = heff_tr(heff_call(v_a_241044, 1, (V[]){v_d_241043}));
  switch (heff_tag_of(v_x1_241045)) {
  case TAG_Ok: {
    V v_v_241046 = heff_field(v_x1_241045, 0);
    V v_ru_24x1_241045_24Ok = heff_take_reuse_n(v_x1_241045, 1ULL, 1);
    switch (heff_tag_of(v_v_241046)) {
    case TAG_VFun: {
      heff_take_n(v_v_241046, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241045_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241046, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241045_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241046, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241045_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241046, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241045_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241046, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241045_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241046, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241045_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241054 = heff_field(v_v_241046, 0);
      V v_ru_24v_241046_24VStr = heff_take_reuse_n(v_v_241046, 1ULL, 1);
      V v_t_241055 = heff_tag_at_n(v_ru_24v_241046_24VStr, TAG_VInt, 1, (V[]){heff_strRuneCount(v_a_241054)});
      return heff_tag_at_n(v_ru_24x1_241045_24Ok, TAG_Ok, 1, (V[]){v_t_241055});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241046, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241045_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241046, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241045_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241046, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241045_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241046, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241045_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241045_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241046);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241061 = heff_field(v_x1_241045, 0);
    V v_ru_24x1_241045_24Bug = heff_take_reuse_n(v_x1_241045, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241045_24Bug, TAG_Bug, 1, (V[]){v_what_241061});
  }
  default: return heff_nomatch(v_x1_241045);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args) {
  V v_d_241062 = args[0];
  V v_a_241063 = args[1];
  V v_x1_241064 = heff_tr(heff_call(v_a_241063, 1, (V[]){v_d_241062}));
  switch (heff_tag_of(v_x1_241064)) {
  case TAG_Ok: {
    V v_v_241065 = heff_field(v_x1_241064, 0);
    V v_ru_24x1_241064_24Ok = heff_take_reuse_n(v_x1_241064, 1ULL, 1);
    switch (heff_tag_of(v_v_241065)) {
    case TAG_VFun: {
      heff_take_n(v_v_241065, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241064_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241065, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241064_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241065, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241064_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241065, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241064_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241065, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241064_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241065, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241064_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241073 = heff_field(v_v_241065, 0);
      heff_take_n(v_v_241065, 1ULL, 1);
      V v_t_241074 = (g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(heff_strRunes(v_a_241073)));
      return heff_tag_at_n(v_ru_24x1_241064_24Ok, TAG_Ok, 1, (V[]){v_t_241074});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241065, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241064_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241065, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241064_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241065, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241064_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241065, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241064_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241064_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241065);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241080 = heff_field(v_x1_241064, 0);
    V v_ru_24x1_241064_24Bug = heff_take_reuse_n(v_x1_241064, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241064_24Bug, TAG_Bug, 1, (V[]){v_what_241080});
  }
  default: return heff_nomatch(v_x1_241064);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args) {
  V v_d_241081 = args[0];
  V v_l_241082 = args[1];
  V v_x1_241083 = heff_tr(heff_call(v_l_241082, 1, (V[]){v_d_241081}));
  switch (heff_tag_of(v_x1_241083)) {
  case TAG_Ok: {
    V v_v_241084 = heff_field(v_x1_241083, 0);
    V v_ru_24x1_241083_24Ok = heff_take_reuse_n(v_x1_241083, 1ULL, 1);
    V v_t_241085 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241084, NTAG(TAG_Nil)));
    V v_t_241086 = (g_heff_2ecompile_2einterp_2eruneCodes(v_t_241085));
    V v_t_241087 = (g_list_2emap(heff_dup(g_runeFromInt_get()), v_t_241086));
    V v_t_241088 = heff_tag_n(TAG_VStr, 1, (V[]){heff_strOfRunes(v_t_241087)});
    return heff_tag_at_n(v_ru_24x1_241083_24Ok, TAG_Ok, 1, (V[]){v_t_241088});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241089 = heff_field(v_x1_241083, 0);
    V v_ru_24x1_241083_24Bug = heff_take_reuse_n(v_x1_241083, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241083_24Bug, TAG_Bug, 1, (V[]){v_what_241089});
  }
  default: return heff_nomatch(v_x1_241083);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args) {
  V v_d_241090 = args[0];
  V v_a_241091 = args[1];
  V v_x1_241092 = heff_tr(heff_call(v_a_241091, 1, (V[]){v_d_241090}));
  switch (heff_tag_of(v_x1_241092)) {
  case TAG_Ok: {
    V v_v_241093 = heff_field(v_x1_241092, 0);
    V v_ru_24x1_241092_24Ok = heff_take_reuse_n(v_x1_241092, 1ULL, 1);
    switch (heff_tag_of(v_v_241093)) {
    case TAG_VFun: {
      heff_take_n(v_v_241093, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241092_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241093, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241092_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241093, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241092_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241093, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241092_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241093, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241092_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241093, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241092_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241101 = heff_field(v_v_241093, 0);
      V v_ru_24v_241093_24VStr = heff_take_reuse_n(v_v_241093, 1ULL, 1);
      V v_t_241102 = heff_strOfRunes(heff_strRunes(v_a_241101));
      return heff_tag_at_n(v_ru_24x1_241092_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241093_24VStr, TAG_VStr, 1, (V[]){v_t_241102})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241093, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241092_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241093, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241092_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241093, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241092_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241093, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241092_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241092_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241093);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241108 = heff_field(v_x1_241092, 0);
    V v_ru_24x1_241092_24Bug = heff_take_reuse_n(v_x1_241092, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241092_24Bug, TAG_Bug, 1, (V[]){v_what_241108});
  }
  default: return heff_nomatch(v_x1_241092);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args) {
  V v_d_241109 = args[0];
  V v_a_241110 = args[1];
  V v_x1_241111 = heff_tr(heff_call(v_a_241110, 1, (V[]){v_d_241109}));
  switch (heff_tag_of(v_x1_241111)) {
  case TAG_Ok: {
    V v_v_241112 = heff_field(v_x1_241111, 0);
    V v_ru_24x1_241111_24Ok = heff_take_reuse_n(v_x1_241111, 1ULL, 1);
    switch (heff_tag_of(v_v_241112)) {
    case TAG_VFun: {
      heff_take_n(v_v_241112, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241111_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241112, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241111_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241112, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241111_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241112, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241111_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241112, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241111_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241112, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241111_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241120 = heff_field(v_v_241112, 0);
      V v_ru_24v_241112_24VStr = heff_take_reuse_n(v_v_241112, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241111_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241112_24VStr, TAG_VStr, 1, (V[]){v_a_241120})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241112, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241111_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241112, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241111_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241112, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241111_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241112, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241111_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241111_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241112);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241126 = heff_field(v_x1_241111, 0);
    V v_ru_24x1_241111_24Bug = heff_take_reuse_n(v_x1_241111, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241111_24Bug, TAG_Bug, 1, (V[]){v_what_241126});
  }
  default: return heff_nomatch(v_x1_241111);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args) {
  V v_d_241127 = args[0];
  V v_a_241128 = args[1];
  V v_x1_241129 = heff_tr(heff_call(v_a_241128, 1, (V[]){v_d_241127}));
  switch (heff_tag_of(v_x1_241129)) {
  case TAG_Ok: {
    V v_v_241130 = heff_field(v_x1_241129, 0);
    V v_ru_24x1_241129_24Ok = heff_take_reuse_n(v_x1_241129, 1ULL, 1);
    switch (heff_tag_of(v_v_241130)) {
    case TAG_VFun: {
      heff_take_n(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241130, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241130, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241141 = heff_field(v_v_241130, 0);
      V v_ru_24v_241130_24VBytes = heff_take_reuse_n(v_v_241130, 1ULL, 1);
      V v_t_241142 = heff_tag_at_n(v_ru_24v_241130_24VBytes, TAG_VInt, 1, (V[]){heff_strLength(v_a_241141)});
      return heff_tag_at_n(v_ru_24x1_241129_24Ok, TAG_Ok, 1, (V[]){v_t_241142});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241130, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241129_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241130);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241145 = heff_field(v_x1_241129, 0);
    V v_ru_24x1_241129_24Bug = heff_take_reuse_n(v_x1_241129, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241129_24Bug, TAG_Bug, 1, (V[]){v_what_241145});
  }
  default: return heff_nomatch(v_x1_241129);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args) {
  V v_d_241161 = args[0];
  V v_a_241162 = args[1];
  V v_a_241160 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241163 = heff_tr(heff_call(v_a_241162, 1, (V[]){v_d_241161}));
  switch (heff_tag_of(v_x1_241163)) {
  case TAG_Ok: {
    V v_v_241164 = heff_field(v_x1_241163, 0);
    V v_ru_24x1_241163_24Ok = heff_take_reuse_n(v_x1_241163, 1ULL, 1);
    switch (heff_tag_of(v_v_241164)) {
    case TAG_VFun: {
      heff_take_n(v_v_241164, 0ULL, 1);
      heff_drop(v_a_241160);
      heff_drop_cell(v_ru_24x1_241163_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241164, 0ULL, 1);
      heff_drop(v_a_241160);
      heff_drop_cell(v_ru_24x1_241163_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241164, 0ULL, 2);
      heff_drop(v_a_241160);
      heff_drop_cell(v_ru_24x1_241163_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241169 = heff_field(v_v_241164, 0);
      V v_ru_24v_241164_24VInt = heff_take_reuse_n(v_v_241164, 1ULL, 1);
      if ((heff_intLe_c_lent(MK_INT(0LL), v_a_241169, 1) && heff_intLt_c(heff_dup(v_a_241169), heff_strLength_lent(v_a_241160, 0)))) {
        V v_t_241170 = heff_tag_at_n(v_ru_24v_241164_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_241160, v_a_241169)});
        return heff_tag_at_n(v_ru_24x1_241163_24Ok, TAG_Ok, 1, (V[]){v_t_241170});
      } else {
        heff_drop(v_a_241160);
        heff_drop_cell(v_ru_24x1_241163_24Ok, 1);
        heff_drop(v_a_241169);
        heff_drop_cell(v_ru_24v_241164_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241164, 0ULL, 1);
      heff_drop(v_a_241160);
      heff_drop_cell(v_ru_24x1_241163_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241164, 0ULL, 1);
      heff_drop(v_a_241160);
      heff_drop_cell(v_ru_24x1_241163_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241164, 0ULL, 1);
      heff_drop(v_a_241160);
      heff_drop_cell(v_ru_24x1_241163_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241164, 0ULL, 1);
      heff_drop(v_a_241160);
      heff_drop_cell(v_ru_24x1_241163_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241164, 0ULL, 1);
      heff_drop(v_a_241160);
      heff_drop_cell(v_ru_24x1_241163_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241164, 0ULL, 1);
      heff_drop(v_a_241160);
      heff_drop_cell(v_ru_24x1_241163_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241164, 0ULL, 2);
      heff_drop(v_a_241160);
      heff_drop_cell(v_ru_24x1_241163_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241160);
      heff_drop_cell(v_ru_24x1_241163_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241164);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241160);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241160);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241179 = heff_field(v_x1_241163, 0);
    V v_ru_24x1_241163_24Bug = heff_take_reuse_n(v_x1_241163, 1ULL, 1);
    heff_drop(v_a_241160);
    return heff_tag_at_n(v_ru_24x1_241163_24Bug, TAG_Bug, 1, (V[]){v_what_241179});
  }
  default: return heff_nomatch(v_x1_241163);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args) {
  V v_d_241146 = args[0];
  V v_a_241147 = args[1];
  V v_x1_241148 = heff_tr(heff_call(v_a_241147, 1, (V[]){v_d_241146}));
  switch (heff_tag_of(v_x1_241148)) {
  case TAG_Ok: {
    V v_v_241149 = heff_field(v_x1_241148, 0);
    V v_ru_24x1_241148_24Ok = heff_take_reuse_n(v_x1_241148, 1ULL, 1);
    switch (heff_tag_of(v_v_241149)) {
    case TAG_VFun: {
      heff_take_n(v_v_241149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241149, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241149, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241160 = heff_field(v_v_241149, 0);
      V v_ru_24v_241149_24VBytes = heff_take_reuse_n(v_v_241149, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241148_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241149_24VBytes, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam96, 2, 1, (V[]){v_a_241160})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241149, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241148_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241149);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241182 = heff_field(v_x1_241148, 0);
    V v_ru_24x1_241148_24Bug = heff_take_reuse_n(v_x1_241148, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241148_24Bug, TAG_Bug, 1, (V[]){v_what_241182});
  }
  default: return heff_nomatch(v_x1_241148);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args) {
  V v_d_241207 = args[0];
  V v_a_241208 = args[1];
  V v_a_241197 = heff_env(self)[0];
  V v_a_241206 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241209 = heff_tr(heff_call(v_a_241208, 1, (V[]){v_d_241207}));
  switch (heff_tag_of(v_x1_241209)) {
  case TAG_Ok: {
    V v_v_241210 = heff_field(v_x1_241209, 0);
    V v_ru_24x1_241209_24Ok = heff_take_reuse_n(v_x1_241209, 1ULL, 1);
    switch (heff_tag_of(v_v_241210)) {
    case TAG_VFun: {
      heff_take_n(v_v_241210, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop(v_a_241206);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241210, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop(v_a_241206);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241210, 0ULL, 2);
      heff_drop(v_a_241197);
      heff_drop(v_a_241206);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241215 = heff_field(v_v_241210, 0);
      V v_ru_24v_241210_24VInt = heff_take_reuse_n(v_v_241210, 1ULL, 1);
      V v_t_241216 = heff_tag_at_n(v_ru_24v_241210_24VInt, TAG_VBytes, 1, (V[]){heff_strSlice(v_a_241197, v_a_241206, v_a_241215)});
      return heff_tag_at_n(v_ru_24x1_241209_24Ok, TAG_Ok, 1, (V[]){v_t_241216});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241210, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop(v_a_241206);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241210, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop(v_a_241206);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241210, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop(v_a_241206);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241210, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop(v_a_241206);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241210, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop(v_a_241206);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241210, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop(v_a_241206);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241210, 0ULL, 2);
      heff_drop(v_a_241197);
      heff_drop(v_a_241206);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241197);
      heff_drop(v_a_241206);
      heff_drop_cell(v_ru_24x1_241209_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241210);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241197);
    heff_drop(v_a_241206);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241197);
    heff_drop(v_a_241206);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241225 = heff_field(v_x1_241209, 0);
    V v_ru_24x1_241209_24Bug = heff_take_reuse_n(v_x1_241209, 1ULL, 1);
    heff_drop(v_a_241197);
    heff_drop(v_a_241206);
    return heff_tag_at_n(v_ru_24x1_241209_24Bug, TAG_Bug, 1, (V[]){v_what_241225});
  }
  default: return heff_nomatch(v_x1_241209);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args) {
  V v_d_241198 = args[0];
  V v_a_241199 = args[1];
  V v_a_241197 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241200 = heff_tr(heff_call(v_a_241199, 1, (V[]){v_d_241198}));
  switch (heff_tag_of(v_x1_241200)) {
  case TAG_Ok: {
    V v_v_241201 = heff_field(v_x1_241200, 0);
    V v_ru_24x1_241200_24Ok = heff_take_reuse_n(v_x1_241200, 1ULL, 1);
    switch (heff_tag_of(v_v_241201)) {
    case TAG_VFun: {
      heff_take_n(v_v_241201, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241201, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241201, 0ULL, 2);
      heff_drop(v_a_241197);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241206 = heff_field(v_v_241201, 0);
      V v_ru_24v_241201_24VInt = heff_take_reuse_n(v_v_241201, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241200_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241201_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam99, 2, 2, (V[]){v_a_241197, v_a_241206})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241201, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241201, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241201, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241201, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241201, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241201, 0ULL, 1);
      heff_drop(v_a_241197);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241201, 0ULL, 2);
      heff_drop(v_a_241197);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241197);
      heff_drop_cell(v_ru_24x1_241200_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241201);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241197);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241197);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241234 = heff_field(v_x1_241200, 0);
    V v_ru_24x1_241200_24Bug = heff_take_reuse_n(v_x1_241200, 1ULL, 1);
    heff_drop(v_a_241197);
    return heff_tag_at_n(v_ru_24x1_241200_24Bug, TAG_Bug, 1, (V[]){v_what_241234});
  }
  default: return heff_nomatch(v_x1_241200);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args) {
  V v_d_241183 = args[0];
  V v_a_241184 = args[1];
  V v_x1_241185 = heff_tr(heff_call(v_a_241184, 1, (V[]){v_d_241183}));
  switch (heff_tag_of(v_x1_241185)) {
  case TAG_Ok: {
    V v_v_241186 = heff_field(v_x1_241185, 0);
    V v_ru_24x1_241185_24Ok = heff_take_reuse_n(v_x1_241185, 1ULL, 1);
    switch (heff_tag_of(v_v_241186)) {
    case TAG_VFun: {
      heff_take_n(v_v_241186, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241185_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241186, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241185_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241186, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241185_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241186, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241185_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241186, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241185_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241186, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241185_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241186, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241185_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241186, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241185_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241186, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241185_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241197 = heff_field(v_v_241186, 0);
      V v_ru_24v_241186_24VBytes = heff_take_reuse_n(v_v_241186, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241185_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241186_24VBytes, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam98, 2, 1, (V[]){v_a_241197})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241186, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241185_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241185_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241186);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241237 = heff_field(v_x1_241185, 0);
    V v_ru_24x1_241185_24Bug = heff_take_reuse_n(v_x1_241185, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241185_24Bug, TAG_Bug, 1, (V[]){v_what_241237});
  }
  default: return heff_nomatch(v_x1_241185);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args) {
  V v_d_241238 = args[0];
  V v_l_241239 = args[1];
  V v_x1_241240 = heff_tr(heff_call(v_l_241239, 1, (V[]){v_d_241238}));
  switch (heff_tag_of(v_x1_241240)) {
  case TAG_Ok: {
    V v_v_241241 = heff_field(v_x1_241240, 0);
    heff_take_n(v_x1_241240, 1ULL, 1);
    V v_t_241242 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241241, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_241242; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str25); V r_ = (g_heff_2ecompile_2einterp_2ebytesJoined(a_0, a_1)); heff_drop(v_t_241242); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241243 = heff_field(v_x1_241240, 0);
    V v_ru_24x1_241240_24Bug = heff_take_reuse_n(v_x1_241240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241240_24Bug, TAG_Bug, 1, (V[]){v_what_241243});
  }
  default: return heff_nomatch(v_x1_241240);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args) {
  V v_a_241244 = args[0];
  V v_b_241245 = args[1];
  V v_t_241246;
  if (heff_strEq_c(v_a_241244, v_b_241245)) {
    v_t_241246 = ((V)&g_heff_2ecompile_2einterp_2eprim_str26);
  } else {
    v_t_241246 = ((V)&g_heff_2ecompile_2einterp_2eprim_str27);
  }
  V v_t_241247 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241246, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241247});
}
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args) {
  V v_d_241251 = args[0];
  V v_b_241252 = args[1];
  V v_a_241250 = heff_env(self)[0];
  V v_f_241248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241253 = heff_tr(heff_call(v_a_241250, 1, (V[]){heff_dup(v_d_241251)}));
  switch (heff_tag_of(v_x1_241253)) {
  case TAG_Ok: {
    V v_v_241254 = heff_field(v_x1_241253, 0);
    V v_ru_24x1_241253_24Ok = heff_take_reuse_n(v_x1_241253, 1ULL, 1);
    V v_x1_241255 = heff_tr(heff_call(v_b_241252, 1, (V[]){v_d_241251}));
    switch (heff_tag_of(v_x1_241255)) {
    case TAG_Ok: {
      V v_v_241256 = heff_field(v_x1_241255, 0);
      heff_take_n(v_x1_241255, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_241253_24Ok, 1);
      V v_f_241257 = v_f_241248;
      V v_x2_241258 = v_v_241254;
      V v_x3_241259 = v_v_241256;
      switch (heff_tag_of(v_x2_241258)) {
      case TAG_VFun: {
        heff_take_n(v_x2_241258, 0ULL, 1);
        heff_drop(v_f_241257);
        heff_drop(v_x3_241259);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VCons: {
        heff_take_n(v_x2_241258, 0ULL, 1);
        heff_drop(v_f_241257);
        heff_drop(v_x3_241259);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VTag: {
        heff_take_n(v_x2_241258, 0ULL, 2);
        heff_drop(v_f_241257);
        heff_drop(v_x3_241259);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VInt: {
        heff_take_n(v_x2_241258, 0ULL, 1);
        heff_drop(v_f_241257);
        heff_drop(v_x3_241259);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_x2_241258, 0ULL, 1);
        heff_drop(v_f_241257);
        heff_drop(v_x3_241259);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_x2_241258, 0ULL, 1);
        heff_drop(v_f_241257);
        heff_drop(v_x3_241259);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VStr: {
        heff_take_n(v_x2_241258, 0ULL, 1);
        heff_drop(v_f_241257);
        heff_drop(v_x3_241259);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VRune: {
        heff_take_n(v_x2_241258, 0ULL, 1);
        heff_drop(v_f_241257);
        heff_drop(v_x3_241259);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VArr: {
        heff_take_n(v_x2_241258, 0ULL, 1);
        heff_drop(v_f_241257);
        heff_drop(v_x3_241259);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VBytes: {
        V v_a_241270 = heff_field(v_x2_241258, 0);
        heff_take_n(v_x2_241258, 1ULL, 1);
        switch (heff_tag_of(v_x3_241259)) {
        case TAG_VFun: {
          heff_take_n(v_x3_241259, 0ULL, 1);
          heff_drop(v_f_241257);
          heff_drop(v_a_241270);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VCons: {
          heff_take_n(v_x3_241259, 0ULL, 1);
          heff_drop(v_f_241257);
          heff_drop(v_a_241270);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VTag: {
          heff_take_n(v_x3_241259, 0ULL, 2);
          heff_drop(v_f_241257);
          heff_drop(v_a_241270);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VInt: {
          heff_take_n(v_x3_241259, 0ULL, 1);
          heff_drop(v_f_241257);
          heff_drop(v_a_241270);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_x3_241259, 0ULL, 1);
          heff_drop(v_f_241257);
          heff_drop(v_a_241270);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_x3_241259, 0ULL, 1);
          heff_drop(v_f_241257);
          heff_drop(v_a_241270);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VStr: {
          heff_take_n(v_x3_241259, 0ULL, 1);
          heff_drop(v_f_241257);
          heff_drop(v_a_241270);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VRune: {
          heff_take_n(v_x3_241259, 0ULL, 1);
          heff_drop(v_f_241257);
          heff_drop(v_a_241270);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VArr: {
          heff_take_n(v_x3_241259, 0ULL, 1);
          heff_drop(v_f_241257);
          heff_drop(v_a_241270);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VBytes: {
          V v_b_241281 = heff_field(v_x3_241259, 0);
          heff_take_n(v_x3_241259, 1ULL, 1);
          V f_ = v_f_241257;
          args[0] = v_a_241270;
          args[1] = v_b_241281;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        case TAG_VBits: {
          heff_take_n(v_x3_241259, 0ULL, 2);
          heff_drop(v_f_241257);
          heff_drop(v_a_241270);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VErased: {
          heff_drop(v_f_241257);
          heff_drop(v_a_241270);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        default: return heff_nomatch(v_x3_241259);
        }
      }
      case TAG_VBits: {
        heff_take_n(v_x2_241258, 0ULL, 2);
        heff_drop(v_f_241257);
        heff_drop(v_x3_241259);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VErased: {
        heff_drop(v_f_241257);
        heff_drop(v_x3_241259);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      default: return heff_nomatch(v_x2_241258);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_241254);
      heff_drop_cell(v_ru_24x1_241253_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_241254);
      heff_drop_cell(v_ru_24x1_241253_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_241286 = heff_field(v_x1_241255, 0);
      heff_take_n(v_x1_241255, 1ULL, 1);
      heff_drop(v_v_241254);
      return heff_tag_at_n(v_ru_24x1_241253_24Ok, TAG_Bug, 1, (V[]){v_what_241286});
    }
    default: return heff_nomatch(v_x1_241255);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_241251);
    heff_drop(v_b_241252);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_241251);
    heff_drop(v_b_241252);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241287 = heff_field(v_x1_241253, 0);
    V v_ru_24x1_241253_24Bug = heff_take_reuse_n(v_x1_241253, 1ULL, 1);
    heff_drop(v_d_241251);
    heff_drop(v_b_241252);
    return heff_tag_at_n(v_ru_24x1_241253_24Bug, TAG_Bug, 1, (V[]){v_what_241287});
  }
  default: return heff_nomatch(v_x1_241253);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args) {
  V v_d_241249 = args[0];
  V v_a_241250 = args[1];
  V v_f_241248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241249);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam103, 2, 2, (V[]){v_a_241250, v_f_241248})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args) {
  V v_d_241288 = args[0];
  V v_l_241289 = args[1];
  V v_x1_241290 = heff_tr(heff_call(v_l_241289, 1, (V[]){v_d_241288}));
  switch (heff_tag_of(v_x1_241290)) {
  case TAG_Ok: {
    V v_v_241291 = heff_field(v_x1_241290, 0);
    V v_ru_24x1_241290_24Ok = heff_take_reuse_n(v_x1_241290, 1ULL, 1);
    V v_t_241292 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241291, NTAG(TAG_Nil)));
    V v_t_241293 = ({ V a_0 = v_t_241292; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str28); V r_ = (g_heff_2ecompile_2einterp_2ebyteString(a_0, a_1)); heff_drop(v_t_241292); r_; });
    return heff_tag_at_n(v_ru_24x1_241290_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_t_241293})});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241294 = heff_field(v_x1_241290, 0);
    V v_ru_24x1_241290_24Bug = heff_take_reuse_n(v_x1_241290, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241290_24Bug, TAG_Bug, 1, (V[]){v_what_241294});
  }
  default: return heff_nomatch(v_x1_241290);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args) {
  V v_d_241295 = args[0];
  V v_a_241296 = args[1];
  V v_x1_241297 = heff_tr(heff_call(v_a_241296, 1, (V[]){v_d_241295}));
  switch (heff_tag_of(v_x1_241297)) {
  case TAG_Ok: {
    V v_v_241298 = heff_field(v_x1_241297, 0);
    V v_ru_24x1_241297_24Ok = heff_take_reuse_n(v_x1_241297, 1ULL, 1);
    switch (heff_tag_of(v_v_241298)) {
    case TAG_VFun: {
      heff_take_n(v_v_241298, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241297_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241298, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241297_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241298, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241297_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241298, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241297_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241298, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241297_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241298, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241297_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241298, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241297_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241298, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241297_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241298, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241297_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241309 = heff_field(v_v_241298, 0);
      heff_take_n(v_v_241298, 1ULL, 1);
      int64_t v_t_241310 = (heff_unbox_word(heff_strLength_lent(v_a_241309, 0)) - ((int64_t)1ULL));
      V v_t_241311 = ({ V a_0 = v_a_241309; V a_1 = MK_INT(0LL); V a_2 = heff_box_word(v_t_241310); V r_ = (g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(a_0, a_1, a_2)); heff_drop(v_a_241309); r_; });
      return heff_tag_at_n(v_ru_24x1_241297_24Ok, TAG_Ok, 1, (V[]){v_t_241311});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241298, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241297_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241297_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241298);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241314 = heff_field(v_x1_241297, 0);
    V v_ru_24x1_241297_24Bug = heff_take_reuse_n(v_x1_241297, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241297_24Bug, TAG_Bug, 1, (V[]){v_what_241314});
  }
  default: return heff_nomatch(v_x1_241297);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args) {
  V v_d_241315 = args[0];
  V v_a_241316 = args[1];
  V v_x1_241317 = heff_tr(heff_call(v_a_241316, 1, (V[]){v_d_241315}));
  switch (heff_tag_of(v_x1_241317)) {
  case TAG_Ok: {
    V v_v_241318 = heff_field(v_x1_241317, 0);
    V v_ru_24x1_241317_24Ok = heff_take_reuse_n(v_x1_241317, 1ULL, 1);
    switch (heff_tag_of(v_v_241318)) {
    case TAG_VFun: {
      heff_take_n(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241318, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241326 = heff_field(v_v_241318, 0);
      V v_ru_24v_241318_24VStr = heff_take_reuse_n(v_v_241318, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241317_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241318_24VStr, TAG_VBytes, 1, (V[]){v_a_241326})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241318, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241318, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241317_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241318);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241332 = heff_field(v_x1_241317, 0);
    V v_ru_24x1_241317_24Bug = heff_take_reuse_n(v_x1_241317, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241317_24Bug, TAG_Bug, 1, (V[]){v_what_241332});
  }
  default: return heff_nomatch(v_x1_241317);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args) {
  V v_d_241333 = args[0];
  V v_a_241334 = args[1];
  V v_x1_241335 = heff_tr(heff_call(v_a_241334, 1, (V[]){v_d_241333}));
  switch (heff_tag_of(v_x1_241335)) {
  case TAG_Ok: {
    V v_v_241336 = heff_field(v_x1_241335, 0);
    V v_ru_24x1_241335_24Ok = heff_take_reuse_n(v_x1_241335, 1ULL, 1);
    switch (heff_tag_of(v_v_241336)) {
    case TAG_VFun: {
      heff_take_n(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241336, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241336, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241347 = heff_field(v_v_241336, 0);
      V v_ru_24v_241336_24VBytes = heff_take_reuse_n(v_v_241336, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241335_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241336_24VBytes, TAG_VStr, 1, (V[]){v_a_241347})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241336, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241335_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241336);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241350 = heff_field(v_x1_241335, 0);
    V v_ru_24x1_241335_24Bug = heff_take_reuse_n(v_x1_241335, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241335_24Bug, TAG_Bug, 1, (V[]){v_what_241350});
  }
  default: return heff_nomatch(v_x1_241335);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args) {
  V v_d_241351 = args[0];
  V v_a_241352 = args[1];
  V v_x1_241353 = heff_tr(heff_call(v_a_241352, 1, (V[]){v_d_241351}));
  switch (heff_tag_of(v_x1_241353)) {
  case TAG_Ok: {
    V v_v_241354 = heff_field(v_x1_241353, 0);
    V v_ru_24x1_241353_24Ok = heff_take_reuse_n(v_x1_241353, 1ULL, 1);
    switch (heff_tag_of(v_v_241354)) {
    case TAG_VFun: {
      heff_take_n(v_v_241354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241354, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241354, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241365 = heff_field(v_v_241354, 0);
      V v_ru_24v_241354_24VBytes = heff_take_reuse_n(v_v_241354, 1ULL, 1);
      V v_t_241366 = (g_rune_2evalidString_2evalidFrom_240(v_a_241365, MK_INT(0LL)));
      V v_t_241367;
      if ((heff_dup(v_t_241366) == NTAG(TAG_True))) {
        heff_drop(v_t_241366);
        v_t_241367 = v_a_241365;
      } else {
        heff_drop(v_t_241366);
        v_t_241367 = heff_strOfRunes(heff_strRunes(v_a_241365));
      }
      return heff_tag_at_n(v_ru_24x1_241353_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241354_24VBytes, TAG_VStr, 1, (V[]){v_t_241367})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241354, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241353_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241354);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241370 = heff_field(v_x1_241353, 0);
    V v_ru_24x1_241353_24Bug = heff_take_reuse_n(v_x1_241353, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241353_24Bug, TAG_Bug, 1, (V[]){v_what_241370});
  }
  default: return heff_nomatch(v_x1_241353);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam112(V self, V *args) {
  V v_d_241404 = args[0];
  V v_a_241405 = args[1];
  V v_a_241385 = heff_env(self)[0];
  V v_a_241394 = heff_env(self)[1];
  V v_a_241403 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241406 = heff_tr(heff_call(v_a_241405, 1, (V[]){v_d_241404}));
  switch (heff_tag_of(v_x1_241406)) {
  case TAG_Ok: {
    V v_v_241407 = heff_field(v_x1_241406, 0);
    V v_ru_24x1_241406_24Ok = heff_take_reuse_n(v_x1_241406, 1ULL, 1);
    switch (heff_tag_of(v_v_241407)) {
    case TAG_VFun: {
      heff_take_n(v_v_241407, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop(v_a_241403);
      heff_drop_cell(v_ru_24x1_241406_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241407, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop(v_a_241403);
      heff_drop_cell(v_ru_24x1_241406_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241407, 0ULL, 2);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop(v_a_241403);
      heff_drop_cell(v_ru_24x1_241406_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241412 = heff_field(v_v_241407, 0);
      heff_take_n(v_v_241407, 1ULL, 1);
      int64_t v_t_241413 = (heff_unbox_word(heff_strLength_lent(v_a_241385, 0)) * ((int64_t)8ULL));
      return ({ V a_0 = v_ru_24x1_241406_24Ok; V a_1 = v_a_241385; V a_2 = heff_box_word(v_t_241413); V a_3 = v_a_241394; V a_4 = v_a_241403; V a_5 = v_a_241412; V r_ = (g_heff_2ecompile_2einterp_2eintAtV_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_a_241385); r_; });
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241407, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop(v_a_241403);
      heff_drop_cell(v_ru_24x1_241406_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241407, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop(v_a_241403);
      heff_drop_cell(v_ru_24x1_241406_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241407, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop(v_a_241403);
      heff_drop_cell(v_ru_24x1_241406_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241407, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop(v_a_241403);
      heff_drop_cell(v_ru_24x1_241406_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241407, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop(v_a_241403);
      heff_drop_cell(v_ru_24x1_241406_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241407, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop(v_a_241403);
      heff_drop_cell(v_ru_24x1_241406_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241407, 0ULL, 2);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop(v_a_241403);
      heff_drop_cell(v_ru_24x1_241406_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop(v_a_241403);
      heff_drop_cell(v_ru_24x1_241406_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241407);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241385);
    heff_drop(v_a_241394);
    heff_drop(v_a_241403);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241385);
    heff_drop(v_a_241394);
    heff_drop(v_a_241403);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241422 = heff_field(v_x1_241406, 0);
    V v_ru_24x1_241406_24Bug = heff_take_reuse_n(v_x1_241406, 1ULL, 1);
    heff_drop(v_a_241385);
    heff_drop(v_a_241394);
    heff_drop(v_a_241403);
    return heff_tag_at_n(v_ru_24x1_241406_24Bug, TAG_Bug, 1, (V[]){v_what_241422});
  }
  default: return heff_nomatch(v_x1_241406);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam111(V self, V *args) {
  V v_d_241395 = args[0];
  V v_a_241396 = args[1];
  V v_a_241385 = heff_env(self)[0];
  V v_a_241394 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241397 = heff_tr(heff_call(v_a_241396, 1, (V[]){v_d_241395}));
  switch (heff_tag_of(v_x1_241397)) {
  case TAG_Ok: {
    V v_v_241398 = heff_field(v_x1_241397, 0);
    V v_ru_24x1_241397_24Ok = heff_take_reuse_n(v_x1_241397, 1ULL, 1);
    switch (heff_tag_of(v_v_241398)) {
    case TAG_VFun: {
      heff_take_n(v_v_241398, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop_cell(v_ru_24x1_241397_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241398, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop_cell(v_ru_24x1_241397_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241398, 0ULL, 2);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop_cell(v_ru_24x1_241397_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241403 = heff_field(v_v_241398, 0);
      V v_ru_24v_241398_24VInt = heff_take_reuse_n(v_v_241398, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241397_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241398_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam112, 2, 3, (V[]){v_a_241385, v_a_241394, v_a_241403})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241398, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop_cell(v_ru_24x1_241397_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241398, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop_cell(v_ru_24x1_241397_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241398, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop_cell(v_ru_24x1_241397_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241398, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop_cell(v_ru_24x1_241397_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241398, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop_cell(v_ru_24x1_241397_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241398, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop_cell(v_ru_24x1_241397_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241398, 0ULL, 2);
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop_cell(v_ru_24x1_241397_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241385);
      heff_drop(v_a_241394);
      heff_drop_cell(v_ru_24x1_241397_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241398);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241385);
    heff_drop(v_a_241394);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241385);
    heff_drop(v_a_241394);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241431 = heff_field(v_x1_241397, 0);
    V v_ru_24x1_241397_24Bug = heff_take_reuse_n(v_x1_241397, 1ULL, 1);
    heff_drop(v_a_241385);
    heff_drop(v_a_241394);
    return heff_tag_at_n(v_ru_24x1_241397_24Bug, TAG_Bug, 1, (V[]){v_what_241431});
  }
  default: return heff_nomatch(v_x1_241397);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam110(V self, V *args) {
  V v_d_241386 = args[0];
  V v_a_241387 = args[1];
  V v_a_241385 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241388 = heff_tr(heff_call(v_a_241387, 1, (V[]){v_d_241386}));
  switch (heff_tag_of(v_x1_241388)) {
  case TAG_Ok: {
    V v_v_241389 = heff_field(v_x1_241388, 0);
    V v_ru_24x1_241388_24Ok = heff_take_reuse_n(v_x1_241388, 1ULL, 1);
    switch (heff_tag_of(v_v_241389)) {
    case TAG_VFun: {
      heff_take_n(v_v_241389, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop_cell(v_ru_24x1_241388_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241389, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop_cell(v_ru_24x1_241388_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241389, 0ULL, 2);
      heff_drop(v_a_241385);
      heff_drop_cell(v_ru_24x1_241388_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241394 = heff_field(v_v_241389, 0);
      V v_ru_24v_241389_24VInt = heff_take_reuse_n(v_v_241389, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241388_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241389_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam111, 2, 2, (V[]){v_a_241385, v_a_241394})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241389, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop_cell(v_ru_24x1_241388_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241389, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop_cell(v_ru_24x1_241388_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241389, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop_cell(v_ru_24x1_241388_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241389, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop_cell(v_ru_24x1_241388_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241389, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop_cell(v_ru_24x1_241388_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241389, 0ULL, 1);
      heff_drop(v_a_241385);
      heff_drop_cell(v_ru_24x1_241388_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241389, 0ULL, 2);
      heff_drop(v_a_241385);
      heff_drop_cell(v_ru_24x1_241388_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241385);
      heff_drop_cell(v_ru_24x1_241388_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241389);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241385);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241385);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241440 = heff_field(v_x1_241388, 0);
    V v_ru_24x1_241388_24Bug = heff_take_reuse_n(v_x1_241388, 1ULL, 1);
    heff_drop(v_a_241385);
    return heff_tag_at_n(v_ru_24x1_241388_24Bug, TAG_Bug, 1, (V[]){v_what_241440});
  }
  default: return heff_nomatch(v_x1_241388);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args) {
  V v_d_241371 = args[0];
  V v_a_241372 = args[1];
  V v_x1_241373 = heff_tr(heff_call(v_a_241372, 1, (V[]){v_d_241371}));
  switch (heff_tag_of(v_x1_241373)) {
  case TAG_Ok: {
    V v_v_241374 = heff_field(v_x1_241373, 0);
    V v_ru_24x1_241373_24Ok = heff_take_reuse_n(v_x1_241373, 1ULL, 1);
    switch (heff_tag_of(v_v_241374)) {
    case TAG_VFun: {
      heff_take_n(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241374, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241374, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241385 = heff_field(v_v_241374, 0);
      V v_ru_24v_241374_24VBytes = heff_take_reuse_n(v_v_241374, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241373_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241374_24VBytes, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam110, 2, 1, (V[]){v_a_241385})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241374, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241373_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241374);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241443 = heff_field(v_x1_241373, 0);
    V v_ru_24x1_241373_24Bug = heff_take_reuse_n(v_x1_241373, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241373_24Bug, TAG_Bug, 1, (V[]){v_what_241443});
  }
  default: return heff_nomatch(v_x1_241373);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam115(V self, V *args) {
  V v_d_241462 = args[0];
  V v_a_241463 = args[1];
  V v_a_241452 = heff_env(self)[0];
  V v_a_241461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241464 = heff_tr(heff_call(v_a_241463, 1, (V[]){v_d_241462}));
  switch (heff_tag_of(v_x1_241464)) {
  case TAG_Ok: {
    V v_v_241465 = heff_field(v_x1_241464, 0);
    V v_ru_24x1_241464_24Ok = heff_take_reuse_n(v_x1_241464, 1ULL, 1);
    switch (heff_tag_of(v_v_241465)) {
    case TAG_VFun: {
      heff_take_n(v_v_241465, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241465, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241465, 0ULL, 2);
      heff_drop(v_a_241452);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241470 = heff_field(v_v_241465, 0);
      V v_ru_24v_241465_24VInt = heff_take_reuse_n(v_v_241465, 1ULL, 1);
      V v_n_241471 = v_a_241452;
      V v_f_241472 = v_a_241461;
      V v_v_241473 = v_a_241470;
      if ((heff_intLt_c_lent(v_n_241471, MK_INT(0LL), 2) || (heff_intLt_c_lent(MK_INT(64LL), v_n_241471, 1) || !((heff_peek_word(v_n_241471) % ((int64_t)8ULL)) == ((int64_t)0ULL))))) {
        heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
        heff_drop_cell(v_ru_24v_241465_24VInt, 1);
        heff_drop(v_n_241471);
        heff_drop(v_f_241472);
        heff_drop(v_v_241473);
        return NTAG(TAG_Abn);
      } else {
        V v_w_241474 = (g_heff_2ecompile_2einterp_2ewordOf(heff_dup(v_n_241471), v_f_241472, v_v_241473));
        int64_t v_t_241475 = ((heff_peek_word(v_n_241471) + ((int64_t)7ULL)) / ((int64_t)8ULL));
        int64_t v_t_241476 = ((heff_peek_word(v_n_241471) + ((int64_t)7ULL)) / ((int64_t)8ULL));
        int64_t v_t_241477 = ((v_t_241476 * ((int64_t)8ULL)) - heff_unbox_word(v_n_241471));
        V v_t_241478 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word(v_t_241477)));
        V v_t_241479 = (g_heff_2ecompile_2einterp_2ebytesOfNat(heff_box_word(v_t_241475), heff_intMul(v_w_241474, v_t_241478), ((V)&g_heff_2ecompile_2einterp_2eprim_str29)));
        return heff_tag_at_n(v_ru_24x1_241464_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241465_24VInt, TAG_VBytes, 1, (V[]){v_t_241479})});
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241465, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241465, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241465, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241465, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241465, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241465, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241465, 0ULL, 2);
      heff_drop(v_a_241452);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241452);
      heff_drop(v_a_241461);
      heff_drop_cell(v_ru_24x1_241464_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241465);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241452);
    heff_drop(v_a_241461);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241452);
    heff_drop(v_a_241461);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241488 = heff_field(v_x1_241464, 0);
    V v_ru_24x1_241464_24Bug = heff_take_reuse_n(v_x1_241464, 1ULL, 1);
    heff_drop(v_a_241452);
    heff_drop(v_a_241461);
    return heff_tag_at_n(v_ru_24x1_241464_24Bug, TAG_Bug, 1, (V[]){v_what_241488});
  }
  default: return heff_nomatch(v_x1_241464);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam114(V self, V *args) {
  V v_d_241453 = args[0];
  V v_a_241454 = args[1];
  V v_a_241452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241455 = heff_tr(heff_call(v_a_241454, 1, (V[]){v_d_241453}));
  switch (heff_tag_of(v_x1_241455)) {
  case TAG_Ok: {
    V v_v_241456 = heff_field(v_x1_241455, 0);
    V v_ru_24x1_241455_24Ok = heff_take_reuse_n(v_x1_241455, 1ULL, 1);
    switch (heff_tag_of(v_v_241456)) {
    case TAG_VFun: {
      heff_take_n(v_v_241456, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241456, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241456, 0ULL, 2);
      heff_drop(v_a_241452);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241461 = heff_field(v_v_241456, 0);
      V v_ru_24v_241456_24VInt = heff_take_reuse_n(v_v_241456, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241455_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241456_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam115, 2, 2, (V[]){v_a_241452, v_a_241461})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241456, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241456, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241456, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241456, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241456, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241456, 0ULL, 1);
      heff_drop(v_a_241452);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241456, 0ULL, 2);
      heff_drop(v_a_241452);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241452);
      heff_drop_cell(v_ru_24x1_241455_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241456);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241452);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241452);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241497 = heff_field(v_x1_241455, 0);
    V v_ru_24x1_241455_24Bug = heff_take_reuse_n(v_x1_241455, 1ULL, 1);
    heff_drop(v_a_241452);
    return heff_tag_at_n(v_ru_24x1_241455_24Bug, TAG_Bug, 1, (V[]){v_what_241497});
  }
  default: return heff_nomatch(v_x1_241455);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam113(V self, V *args) {
  V v_d_241444 = args[0];
  V v_a_241445 = args[1];
  V v_x1_241446 = heff_tr(heff_call(v_a_241445, 1, (V[]){v_d_241444}));
  switch (heff_tag_of(v_x1_241446)) {
  case TAG_Ok: {
    V v_v_241447 = heff_field(v_x1_241446, 0);
    V v_ru_24x1_241446_24Ok = heff_take_reuse_n(v_x1_241446, 1ULL, 1);
    switch (heff_tag_of(v_v_241447)) {
    case TAG_VFun: {
      heff_take_n(v_v_241447, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241446_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241447, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241446_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241447, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241446_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241452 = heff_field(v_v_241447, 0);
      V v_ru_24v_241447_24VInt = heff_take_reuse_n(v_v_241447, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241446_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241447_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam114, 2, 1, (V[]){v_a_241452})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241447, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241446_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241447, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241446_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241447, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241446_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241447, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241446_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241447, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241446_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241447, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241446_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241447, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241446_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241446_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241447);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241506 = heff_field(v_x1_241446, 0);
    V v_ru_24x1_241446_24Bug = heff_take_reuse_n(v_x1_241446, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241446_24Bug, TAG_Bug, 1, (V[]){v_what_241506});
  }
  default: return heff_nomatch(v_x1_241446);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam118(V self, V *args) {
  V v_d_241531 = args[0];
  V v_a_241532 = args[1];
  V v_a_241530 = heff_env(self)[0];
  V v_a_241521 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241533 = heff_tr(heff_call(v_a_241532, 1, (V[]){v_d_241531}));
  switch (heff_tag_of(v_x1_241533)) {
  case TAG_Ok: {
    V v_v_241534 = heff_field(v_x1_241533, 0);
    V v_ru_24x1_241533_24Ok = heff_take_reuse_n(v_x1_241533, 1ULL, 1);
    switch (heff_tag_of(v_v_241534)) {
    case TAG_VFun: {
      heff_take_n(v_v_241534, 0ULL, 1);
      heff_drop(v_a_241530);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241533_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241534, 0ULL, 1);
      heff_drop(v_a_241530);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241533_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241534, 0ULL, 2);
      heff_drop(v_a_241530);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241533_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241534, 0ULL, 1);
      heff_drop(v_a_241530);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241533_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241534, 0ULL, 1);
      heff_drop(v_a_241530);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241533_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241534, 0ULL, 1);
      heff_drop(v_a_241530);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241533_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241534, 0ULL, 1);
      heff_drop(v_a_241530);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241533_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241534, 0ULL, 1);
      heff_drop(v_a_241530);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241533_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241534, 0ULL, 1);
      heff_drop(v_a_241530);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241533_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241545 = heff_field(v_v_241534, 0);
      heff_take_n(v_v_241534, 1ULL, 1);
      V v_t_241547;
      if ((heff_intLe_c_lent(MK_INT(0LL), v_a_241530, 1) && (heff_intLe_c(heff_intAdd(heff_dup(v_a_241530), heff_strLength_lent(v_a_241545, 0)), heff_strLength_lent(v_a_241521, 0)) && ({ V v_t_241546 = heff_intAdd(heff_dup(v_a_241530), heff_strLength_lent(v_a_241545, 0)); int c_ = ({ V v_t_242135 = heff_strSlice_lent(v_a_241521, v_a_241530, v_t_241546, 0); int c_ = heff_strEq_c_lent(v_t_242135, v_a_241545, 0); heff_drop(v_t_242135); c_; }); heff_drop(v_t_241546); c_; })))) {
        heff_drop(v_a_241530);
        heff_drop(v_a_241521);
        heff_drop(v_a_241545);
        v_t_241547 = ((V)&g_heff_2ecompile_2einterp_2eprim_str30);
      } else {
        heff_drop(v_a_241530);
        heff_drop(v_a_241521);
        heff_drop(v_a_241545);
        v_t_241547 = ((V)&g_heff_2ecompile_2einterp_2eprim_str31);
      }
      V v_t_241548 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241547, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_241533_24Ok, TAG_Ok, 1, (V[]){v_t_241548});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241534, 0ULL, 2);
      heff_drop(v_a_241530);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241533_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241530);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241533_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241534);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241530);
    heff_drop(v_a_241521);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241530);
    heff_drop(v_a_241521);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241551 = heff_field(v_x1_241533, 0);
    V v_ru_24x1_241533_24Bug = heff_take_reuse_n(v_x1_241533, 1ULL, 1);
    heff_drop(v_a_241530);
    heff_drop(v_a_241521);
    return heff_tag_at_n(v_ru_24x1_241533_24Bug, TAG_Bug, 1, (V[]){v_what_241551});
  }
  default: return heff_nomatch(v_x1_241533);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam117(V self, V *args) {
  V v_d_241522 = args[0];
  V v_a_241523 = args[1];
  V v_a_241521 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241524 = heff_tr(heff_call(v_a_241523, 1, (V[]){v_d_241522}));
  switch (heff_tag_of(v_x1_241524)) {
  case TAG_Ok: {
    V v_v_241525 = heff_field(v_x1_241524, 0);
    V v_ru_24x1_241524_24Ok = heff_take_reuse_n(v_x1_241524, 1ULL, 1);
    switch (heff_tag_of(v_v_241525)) {
    case TAG_VFun: {
      heff_take_n(v_v_241525, 0ULL, 1);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241524_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241525, 0ULL, 1);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241524_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241525, 0ULL, 2);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241524_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241530 = heff_field(v_v_241525, 0);
      V v_ru_24v_241525_24VInt = heff_take_reuse_n(v_v_241525, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241524_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241525_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam118, 2, 2, (V[]){v_a_241530, v_a_241521})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241525, 0ULL, 1);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241524_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241525, 0ULL, 1);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241524_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241525, 0ULL, 1);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241524_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241525, 0ULL, 1);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241524_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241525, 0ULL, 1);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241524_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241525, 0ULL, 1);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241524_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241525, 0ULL, 2);
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241524_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241521);
      heff_drop_cell(v_ru_24x1_241524_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241525);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241521);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241521);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241560 = heff_field(v_x1_241524, 0);
    V v_ru_24x1_241524_24Bug = heff_take_reuse_n(v_x1_241524, 1ULL, 1);
    heff_drop(v_a_241521);
    return heff_tag_at_n(v_ru_24x1_241524_24Bug, TAG_Bug, 1, (V[]){v_what_241560});
  }
  default: return heff_nomatch(v_x1_241524);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam116(V self, V *args) {
  V v_d_241507 = args[0];
  V v_a_241508 = args[1];
  V v_x1_241509 = heff_tr(heff_call(v_a_241508, 1, (V[]){v_d_241507}));
  switch (heff_tag_of(v_x1_241509)) {
  case TAG_Ok: {
    V v_v_241510 = heff_field(v_x1_241509, 0);
    V v_ru_24x1_241509_24Ok = heff_take_reuse_n(v_x1_241509, 1ULL, 1);
    switch (heff_tag_of(v_v_241510)) {
    case TAG_VFun: {
      heff_take_n(v_v_241510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241510, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241510, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241521 = heff_field(v_v_241510, 0);
      V v_ru_24v_241510_24VBytes = heff_take_reuse_n(v_v_241510, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241509_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241510_24VBytes, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam117, 2, 1, (V[]){v_a_241521})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241510, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241509_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241510);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241563 = heff_field(v_x1_241509, 0);
    V v_ru_24x1_241509_24Bug = heff_take_reuse_n(v_x1_241509, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241509_24Bug, TAG_Bug, 1, (V[]){v_what_241563});
  }
  default: return heff_nomatch(v_x1_241509);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam122(V self, V *args) {
  V v_d_241584 = args[0];
  V v_a_241585 = args[1];
  V v_s_241565 = heff_env(self)[0];
  V v_m_241564 = heff_env(self)[1];
  V v_a_241574 = heff_env(self)[2];
  V v_a_241583 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_241586 = heff_tr(heff_call(v_a_241585, 1, (V[]){v_d_241584}));
  switch (heff_tag_of(v_x1_241586)) {
  case TAG_Ok: {
    V v_v_241587 = heff_field(v_x1_241586, 0);
    V v_ru_24x1_241586_24Ok = heff_take_reuse_n(v_x1_241586, 1ULL, 1);
    switch (heff_tag_of(v_v_241587)) {
    case TAG_VFun: {
      heff_take_n(v_v_241587, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop(v_a_241583);
      heff_drop_cell(v_ru_24x1_241586_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241587, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop(v_a_241583);
      heff_drop_cell(v_ru_24x1_241586_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241587, 0ULL, 2);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop(v_a_241583);
      heff_drop_cell(v_ru_24x1_241586_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241592 = heff_field(v_v_241587, 0);
      heff_take_n(v_v_241587, 1ULL, 1);
      return ({ V a_0 = v_ru_24x1_241586_24Ok; V a_1 = v_s_241565; V a_2 = v_m_241564; V a_3 = v_a_241574; V a_4 = v_a_241583; V a_5 = v_a_241592; V r_ = (g_heff_2ecompile_2einterp_2eintAtV_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_s_241565); r_; });
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241587, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop(v_a_241583);
      heff_drop_cell(v_ru_24x1_241586_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241587, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop(v_a_241583);
      heff_drop_cell(v_ru_24x1_241586_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241587, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop(v_a_241583);
      heff_drop_cell(v_ru_24x1_241586_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241587, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop(v_a_241583);
      heff_drop_cell(v_ru_24x1_241586_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241587, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop(v_a_241583);
      heff_drop_cell(v_ru_24x1_241586_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241587, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop(v_a_241583);
      heff_drop_cell(v_ru_24x1_241586_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241587, 0ULL, 2);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop(v_a_241583);
      heff_drop_cell(v_ru_24x1_241586_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop(v_a_241583);
      heff_drop_cell(v_ru_24x1_241586_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241587);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241565);
    heff_drop(v_m_241564);
    heff_drop(v_a_241574);
    heff_drop(v_a_241583);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241565);
    heff_drop(v_m_241564);
    heff_drop(v_a_241574);
    heff_drop(v_a_241583);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241601 = heff_field(v_x1_241586, 0);
    V v_ru_24x1_241586_24Bug = heff_take_reuse_n(v_x1_241586, 1ULL, 1);
    heff_drop(v_s_241565);
    heff_drop(v_m_241564);
    heff_drop(v_a_241574);
    heff_drop(v_a_241583);
    return heff_tag_at_n(v_ru_24x1_241586_24Bug, TAG_Bug, 1, (V[]){v_what_241601});
  }
  default: return heff_nomatch(v_x1_241586);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam121(V self, V *args) {
  V v_d_241575 = args[0];
  V v_a_241576 = args[1];
  V v_s_241565 = heff_env(self)[0];
  V v_m_241564 = heff_env(self)[1];
  V v_a_241574 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241577 = heff_tr(heff_call(v_a_241576, 1, (V[]){v_d_241575}));
  switch (heff_tag_of(v_x1_241577)) {
  case TAG_Ok: {
    V v_v_241578 = heff_field(v_x1_241577, 0);
    V v_ru_24x1_241577_24Ok = heff_take_reuse_n(v_x1_241577, 1ULL, 1);
    switch (heff_tag_of(v_v_241578)) {
    case TAG_VFun: {
      heff_take_n(v_v_241578, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop_cell(v_ru_24x1_241577_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241578, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop_cell(v_ru_24x1_241577_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241578, 0ULL, 2);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop_cell(v_ru_24x1_241577_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241583 = heff_field(v_v_241578, 0);
      V v_ru_24v_241578_24VInt = heff_take_reuse_n(v_v_241578, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241577_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241578_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam122, 2, 4, (V[]){v_s_241565, v_m_241564, v_a_241574, v_a_241583})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241578, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop_cell(v_ru_24x1_241577_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241578, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop_cell(v_ru_24x1_241577_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241578, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop_cell(v_ru_24x1_241577_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241578, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop_cell(v_ru_24x1_241577_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241578, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop_cell(v_ru_24x1_241577_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241578, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop_cell(v_ru_24x1_241577_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241578, 0ULL, 2);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop_cell(v_ru_24x1_241577_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop(v_a_241574);
      heff_drop_cell(v_ru_24x1_241577_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241578);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241565);
    heff_drop(v_m_241564);
    heff_drop(v_a_241574);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241565);
    heff_drop(v_m_241564);
    heff_drop(v_a_241574);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241610 = heff_field(v_x1_241577, 0);
    V v_ru_24x1_241577_24Bug = heff_take_reuse_n(v_x1_241577, 1ULL, 1);
    heff_drop(v_s_241565);
    heff_drop(v_m_241564);
    heff_drop(v_a_241574);
    return heff_tag_at_n(v_ru_24x1_241577_24Bug, TAG_Bug, 1, (V[]){v_what_241610});
  }
  default: return heff_nomatch(v_x1_241577);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam120(V self, V *args) {
  V v_d_241566 = args[0];
  V v_a_241567 = args[1];
  V v_s_241565 = heff_env(self)[0];
  V v_m_241564 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241568 = heff_tr(heff_call(v_a_241567, 1, (V[]){v_d_241566}));
  switch (heff_tag_of(v_x1_241568)) {
  case TAG_Ok: {
    V v_v_241569 = heff_field(v_x1_241568, 0);
    V v_ru_24x1_241568_24Ok = heff_take_reuse_n(v_x1_241568, 1ULL, 1);
    switch (heff_tag_of(v_v_241569)) {
    case TAG_VFun: {
      heff_take_n(v_v_241569, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop_cell(v_ru_24x1_241568_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241569, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop_cell(v_ru_24x1_241568_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241569, 0ULL, 2);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop_cell(v_ru_24x1_241568_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241574 = heff_field(v_v_241569, 0);
      V v_ru_24v_241569_24VInt = heff_take_reuse_n(v_v_241569, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241568_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241569_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam121, 2, 3, (V[]){v_s_241565, v_m_241564, v_a_241574})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241569, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop_cell(v_ru_24x1_241568_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241569, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop_cell(v_ru_24x1_241568_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241569, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop_cell(v_ru_24x1_241568_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241569, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop_cell(v_ru_24x1_241568_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241569, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop_cell(v_ru_24x1_241568_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241569, 0ULL, 1);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop_cell(v_ru_24x1_241568_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241569, 0ULL, 2);
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop_cell(v_ru_24x1_241568_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241565);
      heff_drop(v_m_241564);
      heff_drop_cell(v_ru_24x1_241568_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241569);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241565);
    heff_drop(v_m_241564);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241565);
    heff_drop(v_m_241564);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241619 = heff_field(v_x1_241568, 0);
    V v_ru_24x1_241568_24Bug = heff_take_reuse_n(v_x1_241568, 1ULL, 1);
    heff_drop(v_s_241565);
    heff_drop(v_m_241564);
    return heff_tag_at_n(v_ru_24x1_241568_24Bug, TAG_Bug, 1, (V[]){v_what_241619});
  }
  default: return heff_nomatch(v_x1_241568);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam119(V self, V *args) {
  V v_m_241564 = args[0];
  V v_s_241565 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam120, 2, 2, (V[]){v_s_241565, v_m_241564})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam125(V self, V *args) {
  V v_d_241638 = args[0];
  V v_a_241639 = args[1];
  V v_a_241628 = heff_env(self)[0];
  V v_a_241637 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241640 = heff_tr(heff_call(v_a_241639, 1, (V[]){v_d_241638}));
  switch (heff_tag_of(v_x1_241640)) {
  case TAG_Ok: {
    V v_v_241641 = heff_field(v_x1_241640, 0);
    V v_ru_24x1_241640_24Ok = heff_take_reuse_n(v_x1_241640, 1ULL, 1);
    switch (heff_tag_of(v_v_241641)) {
    case TAG_VFun: {
      heff_take_n(v_v_241641, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop(v_a_241637);
      heff_drop_cell(v_ru_24x1_241640_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241641, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop(v_a_241637);
      heff_drop_cell(v_ru_24x1_241640_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241641, 0ULL, 2);
      heff_drop(v_a_241628);
      heff_drop(v_a_241637);
      heff_drop_cell(v_ru_24x1_241640_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241646 = heff_field(v_v_241641, 0);
      heff_take_n(v_v_241641, 1ULL, 1);
      V v_n_241647 = v_a_241628;
      V v_f_241648 = v_a_241637;
      V v_v_241649 = v_a_241646;
      if ((heff_intLt_c_lent(v_n_241647, MK_INT(0LL), 2) || heff_intLt_c_lent(MK_INT(64LL), v_n_241647, 1))) {
        heff_drop_cell(v_ru_24x1_241640_24Ok, 1);
        heff_drop(v_n_241647);
        heff_drop(v_f_241648);
        heff_drop(v_v_241649);
        return NTAG(TAG_Abn);
      } else {
        V v_w_241650 = (g_heff_2ecompile_2einterp_2ewordOf(heff_dup(v_n_241647), v_f_241648, v_v_241649));
        int64_t v_t_241651 = ((heff_peek_word(v_n_241647) + ((int64_t)7ULL)) / ((int64_t)8ULL));
        int64_t v_t_241652 = ((heff_peek_word(v_n_241647) + ((int64_t)7ULL)) / ((int64_t)8ULL));
        int64_t v_t_241653 = ((v_t_241652 * ((int64_t)8ULL)) - heff_peek_word(v_n_241647));
        V v_t_241654 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word(v_t_241653)));
        V v_t_241655 = (g_heff_2ecompile_2einterp_2ebytesOfNat(heff_box_word(v_t_241651), heff_intMul(v_w_241650, v_t_241654), ((V)&g_heff_2ecompile_2einterp_2eprim_str32)));
        return heff_tag_at_n(v_ru_24x1_241640_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_n_241647, v_t_241655})});
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241641, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop(v_a_241637);
      heff_drop_cell(v_ru_24x1_241640_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241641, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop(v_a_241637);
      heff_drop_cell(v_ru_24x1_241640_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241641, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop(v_a_241637);
      heff_drop_cell(v_ru_24x1_241640_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241641, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop(v_a_241637);
      heff_drop_cell(v_ru_24x1_241640_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241641, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop(v_a_241637);
      heff_drop_cell(v_ru_24x1_241640_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241641, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop(v_a_241637);
      heff_drop_cell(v_ru_24x1_241640_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241641, 0ULL, 2);
      heff_drop(v_a_241628);
      heff_drop(v_a_241637);
      heff_drop_cell(v_ru_24x1_241640_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241628);
      heff_drop(v_a_241637);
      heff_drop_cell(v_ru_24x1_241640_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241641);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241628);
    heff_drop(v_a_241637);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241628);
    heff_drop(v_a_241637);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241664 = heff_field(v_x1_241640, 0);
    V v_ru_24x1_241640_24Bug = heff_take_reuse_n(v_x1_241640, 1ULL, 1);
    heff_drop(v_a_241628);
    heff_drop(v_a_241637);
    return heff_tag_at_n(v_ru_24x1_241640_24Bug, TAG_Bug, 1, (V[]){v_what_241664});
  }
  default: return heff_nomatch(v_x1_241640);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam124(V self, V *args) {
  V v_d_241629 = args[0];
  V v_a_241630 = args[1];
  V v_a_241628 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241631 = heff_tr(heff_call(v_a_241630, 1, (V[]){v_d_241629}));
  switch (heff_tag_of(v_x1_241631)) {
  case TAG_Ok: {
    V v_v_241632 = heff_field(v_x1_241631, 0);
    V v_ru_24x1_241631_24Ok = heff_take_reuse_n(v_x1_241631, 1ULL, 1);
    switch (heff_tag_of(v_v_241632)) {
    case TAG_VFun: {
      heff_take_n(v_v_241632, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop_cell(v_ru_24x1_241631_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241632, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop_cell(v_ru_24x1_241631_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241632, 0ULL, 2);
      heff_drop(v_a_241628);
      heff_drop_cell(v_ru_24x1_241631_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241637 = heff_field(v_v_241632, 0);
      V v_ru_24v_241632_24VInt = heff_take_reuse_n(v_v_241632, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241631_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241632_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam125, 2, 2, (V[]){v_a_241628, v_a_241637})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241632, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop_cell(v_ru_24x1_241631_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241632, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop_cell(v_ru_24x1_241631_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241632, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop_cell(v_ru_24x1_241631_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241632, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop_cell(v_ru_24x1_241631_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241632, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop_cell(v_ru_24x1_241631_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241632, 0ULL, 1);
      heff_drop(v_a_241628);
      heff_drop_cell(v_ru_24x1_241631_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241632, 0ULL, 2);
      heff_drop(v_a_241628);
      heff_drop_cell(v_ru_24x1_241631_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241628);
      heff_drop_cell(v_ru_24x1_241631_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241632);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241628);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241628);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241673 = heff_field(v_x1_241631, 0);
    V v_ru_24x1_241631_24Bug = heff_take_reuse_n(v_x1_241631, 1ULL, 1);
    heff_drop(v_a_241628);
    return heff_tag_at_n(v_ru_24x1_241631_24Bug, TAG_Bug, 1, (V[]){v_what_241673});
  }
  default: return heff_nomatch(v_x1_241631);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam123(V self, V *args) {
  V v_d_241620 = args[0];
  V v_a_241621 = args[1];
  V v_x1_241622 = heff_tr(heff_call(v_a_241621, 1, (V[]){v_d_241620}));
  switch (heff_tag_of(v_x1_241622)) {
  case TAG_Ok: {
    V v_v_241623 = heff_field(v_x1_241622, 0);
    V v_ru_24x1_241622_24Ok = heff_take_reuse_n(v_x1_241622, 1ULL, 1);
    switch (heff_tag_of(v_v_241623)) {
    case TAG_VFun: {
      heff_take_n(v_v_241623, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241622_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241623, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241622_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241623, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241622_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241628 = heff_field(v_v_241623, 0);
      V v_ru_24v_241623_24VInt = heff_take_reuse_n(v_v_241623, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241622_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241623_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam124, 2, 1, (V[]){v_a_241628})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241623, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241622_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241623, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241622_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241623, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241622_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241623, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241622_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241623, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241622_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241623, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241622_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241623, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241622_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241622_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241623);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241682 = heff_field(v_x1_241622, 0);
    V v_ru_24x1_241622_24Bug = heff_take_reuse_n(v_x1_241622, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241622_24Bug, TAG_Bug, 1, (V[]){v_what_241682});
  }
  default: return heff_nomatch(v_x1_241622);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam126(V self, V *args) {
  V v_d_241683 = args[0];
  V v_l_241684 = args[1];
  V v_x1_241685 = heff_tr(heff_call(v_l_241684, 1, (V[]){v_d_241683}));
  switch (heff_tag_of(v_x1_241685)) {
  case TAG_Ok: {
    V v_v_241686 = heff_field(v_x1_241685, 0);
    heff_take_n(v_x1_241685, 1ULL, 1);
    V v_t_241687 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241686, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_241687; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2einterp_2eprim_str33); V r_ = (g_heff_2ecompile_2einterp_2ebitsJoined(a_0, a_1, a_2)); heff_drop(v_t_241687); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241688 = heff_field(v_x1_241685, 0);
    V v_ru_24x1_241685_24Bug = heff_take_reuse_n(v_x1_241685, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241685_24Bug, TAG_Bug, 1, (V[]){v_what_241688});
  }
  default: return heff_nomatch(v_x1_241685);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam129(V self, V *args) {
  V v_d_241700 = args[0];
  V v_a_241701 = args[1];
  V v_a_241699 = heff_env(self)[0];
  V v_m_241689 = heff_env(self)[1];
  V v_s_241690 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241702 = heff_tr(heff_call(v_a_241701, 1, (V[]){v_d_241700}));
  switch (heff_tag_of(v_x1_241702)) {
  case TAG_Ok: {
    V v_v_241703 = heff_field(v_x1_241702, 0);
    V v_ru_24x1_241702_24Ok = heff_take_reuse_n(v_x1_241702, 1ULL, 1);
    switch (heff_tag_of(v_v_241703)) {
    case TAG_VFun: {
      heff_take_n(v_v_241703, 0ULL, 1);
      heff_drop(v_a_241699);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241702_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241703, 0ULL, 1);
      heff_drop(v_a_241699);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241702_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241703, 0ULL, 2);
      heff_drop(v_a_241699);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241702_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241708 = heff_field(v_v_241703, 0);
      heff_take_n(v_v_241703, 1ULL, 1);
      if ((heff_intLt_c_lent(v_a_241699, MK_INT(0LL), 2) || (heff_intLt_c_lent(v_a_241708, MK_INT(0LL), 2) || heff_intLt_c(heff_dup(v_m_241689), heff_intAdd(heff_dup(v_a_241699), heff_dup(v_a_241708)))))) {
        heff_drop(v_a_241699);
        heff_drop(v_m_241689);
        heff_drop(v_s_241690);
        heff_drop_cell(v_ru_24x1_241702_24Ok, 1);
        heff_drop(v_a_241708);
        return NTAG(TAG_Abn);
      } else {
        heff_drop(v_m_241689);
        V v_t_241709 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str34); V a_2 = v_s_241690; V a_3 = heff_dup(v_a_241699); V a_4 = heff_intAdd(v_a_241699, heff_dup(v_a_241708)); V r_ = (g_heff_2ecompile_2einterp_2ebitsCopy(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_241690); r_; });
        return heff_tag_at_n(v_ru_24x1_241702_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_a_241708, v_t_241709})});
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241703, 0ULL, 1);
      heff_drop(v_a_241699);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241702_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241703, 0ULL, 1);
      heff_drop(v_a_241699);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241702_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241703, 0ULL, 1);
      heff_drop(v_a_241699);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241702_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241703, 0ULL, 1);
      heff_drop(v_a_241699);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241702_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241703, 0ULL, 1);
      heff_drop(v_a_241699);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241702_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241703, 0ULL, 1);
      heff_drop(v_a_241699);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241702_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241703, 0ULL, 2);
      heff_drop(v_a_241699);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241702_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241699);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241702_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241703);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241699);
    heff_drop(v_m_241689);
    heff_drop(v_s_241690);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241699);
    heff_drop(v_m_241689);
    heff_drop(v_s_241690);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241718 = heff_field(v_x1_241702, 0);
    V v_ru_24x1_241702_24Bug = heff_take_reuse_n(v_x1_241702, 1ULL, 1);
    heff_drop(v_a_241699);
    heff_drop(v_m_241689);
    heff_drop(v_s_241690);
    return heff_tag_at_n(v_ru_24x1_241702_24Bug, TAG_Bug, 1, (V[]){v_what_241718});
  }
  default: return heff_nomatch(v_x1_241702);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam128(V self, V *args) {
  V v_d_241691 = args[0];
  V v_a_241692 = args[1];
  V v_m_241689 = heff_env(self)[0];
  V v_s_241690 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241693 = heff_tr(heff_call(v_a_241692, 1, (V[]){v_d_241691}));
  switch (heff_tag_of(v_x1_241693)) {
  case TAG_Ok: {
    V v_v_241694 = heff_field(v_x1_241693, 0);
    V v_ru_24x1_241693_24Ok = heff_take_reuse_n(v_x1_241693, 1ULL, 1);
    switch (heff_tag_of(v_v_241694)) {
    case TAG_VFun: {
      heff_take_n(v_v_241694, 0ULL, 1);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241694, 0ULL, 1);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241694, 0ULL, 2);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241699 = heff_field(v_v_241694, 0);
      V v_ru_24v_241694_24VInt = heff_take_reuse_n(v_v_241694, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241693_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241694_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam129, 2, 3, (V[]){v_a_241699, v_m_241689, v_s_241690})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241694, 0ULL, 1);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241694, 0ULL, 1);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241694, 0ULL, 1);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241694, 0ULL, 1);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241694, 0ULL, 1);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241694, 0ULL, 1);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241694, 0ULL, 2);
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_m_241689);
      heff_drop(v_s_241690);
      heff_drop_cell(v_ru_24x1_241693_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241694);
    }
  }
  case TAG_Abn: {
    heff_drop(v_m_241689);
    heff_drop(v_s_241690);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_m_241689);
    heff_drop(v_s_241690);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241727 = heff_field(v_x1_241693, 0);
    V v_ru_24x1_241693_24Bug = heff_take_reuse_n(v_x1_241693, 1ULL, 1);
    heff_drop(v_m_241689);
    heff_drop(v_s_241690);
    return heff_tag_at_n(v_ru_24x1_241693_24Bug, TAG_Bug, 1, (V[]){v_what_241727});
  }
  default: return heff_nomatch(v_x1_241693);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam127(V self, V *args) {
  V v_m_241689 = args[0];
  V v_s_241690 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam128, 2, 2, (V[]){v_m_241689, v_s_241690})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam130(V self, V *args) {
  V v_d_241728 = args[0];
  V v_a_241729 = args[1];
  V v_x1_241730 = heff_tr(heff_call(v_a_241729, 1, (V[]){v_d_241728}));
  switch (heff_tag_of(v_x1_241730)) {
  case TAG_Ok: {
    V v_v_241731 = heff_field(v_x1_241730, 0);
    V v_ru_24x1_241730_24Ok = heff_take_reuse_n(v_x1_241730, 1ULL, 1);
    switch (heff_tag_of(v_v_241731)) {
    case TAG_VFun: {
      heff_take_n(v_v_241731, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241730_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241731, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241730_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241731, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241730_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241731, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241730_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241731, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241730_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241731, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241730_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241731, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241730_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241731, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241730_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241731, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241730_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241742 = heff_field(v_v_241731, 0);
      heff_take_n(v_v_241731, 1ULL, 1);
      int64_t v_t_241743 = (heff_unbox_word(heff_strLength_lent(v_a_241742, 0)) * ((int64_t)8ULL));
      return heff_tag_at_n(v_ru_24x1_241730_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){heff_box_word(v_t_241743), v_a_241742})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241731, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241730_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241730_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241731);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241746 = heff_field(v_x1_241730, 0);
    V v_ru_24x1_241730_24Bug = heff_take_reuse_n(v_x1_241730, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241730_24Bug, TAG_Bug, 1, (V[]){v_what_241746});
  }
  default: return heff_nomatch(v_x1_241730);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam131(V self, V *args) {
  V v_n_241747 = args[0];
  V v_s_241748 = args[1];
  if ((heff_unbox_word(heff_intMod(v_n_241747, MK_INT(8LL))) == ((int64_t)0ULL))) {
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_s_241748})});
  } else {
    heff_drop(v_s_241748);
    return NTAG(TAG_Abn);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam133(V self, V *args) {
  V v_m_241751 = args[0];
  V v_t_241752 = args[1];
  V v_n_241749 = heff_env(self)[0];
  V v_s_241750 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_241753;
  if ((heff_intEq_c_lent(v_n_241749, v_m_241751, 0) && heff_strEq_c_lent(v_s_241750, v_t_241752, 0))) {
    heff_drop(v_m_241751);
    heff_drop(v_t_241752);
    heff_drop(v_n_241749);
    heff_drop(v_s_241750);
    v_t_241753 = ((V)&g_heff_2ecompile_2einterp_2eprim_str35);
  } else {
    heff_drop(v_m_241751);
    heff_drop(v_t_241752);
    heff_drop(v_n_241749);
    heff_drop(v_s_241750);
    v_t_241753 = ((V)&g_heff_2ecompile_2einterp_2eprim_str36);
  }
  V v_t_241754 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241753, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241754});
}
V g_heff_2ecompile_2einterp_2eprim_lam132(V self, V *args) {
  V v_n_241749 = args[0];
  V v_s_241750 = args[1];
  V v_t_241755 = (g_heff_2ecompile_2einterp_2ebits1(heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam133, 2, 2, (V[]){v_n_241749, v_s_241750})));
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241755});
}
V g_heff_2ecompile_2einterp_2eprim_lam135(V self, V *args) {
  V v_d_241765 = args[0];
  V v_a_241766 = args[1];
  V v_a_241764 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241767 = heff_tr(heff_call(v_a_241766, 1, (V[]){v_d_241765}));
  switch (heff_tag_of(v_x1_241767)) {
  case TAG_Ok: {
    V v_v_241768 = heff_field(v_x1_241767, 0);
    V v_ru_24x1_241767_24Ok = heff_take_reuse_n(v_x1_241767, 1ULL, 1);
    switch (heff_tag_of(v_v_241768)) {
    case TAG_VFun: {
      heff_take_n(v_v_241768, 0ULL, 1);
      heff_drop(v_a_241764);
      heff_drop_cell(v_ru_24x1_241767_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241768, 0ULL, 1);
      heff_drop(v_a_241764);
      heff_drop_cell(v_ru_24x1_241767_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241768, 0ULL, 2);
      heff_drop(v_a_241764);
      heff_drop_cell(v_ru_24x1_241767_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241768, 0ULL, 1);
      heff_drop(v_a_241764);
      heff_drop_cell(v_ru_24x1_241767_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_241774 = heff_tflat_f64(v_v_241768, 0);
      V v_ru_24v_241768_24VFloat = heff_take_reuse_na(v_v_241768, 0ULL, 1);
      if (heff_intEq_c_lent(v_a_241764, MK_INT(64LL), 2)) {
        heff_drop(v_a_241764);
        V v_t_241775 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(11LL), MK_INT(52LL), v_a_241774));
        return heff_tag_at_n(v_ru_24x1_241767_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241768_24VFloat, TAG_VInt, 1, (V[]){v_t_241775})});
      } else {
        if (heff_intEq_c(v_a_241764, MK_INT(32LL))) {
          double v_t_241776 = ((double)((float)v_a_241774));
          V v_t_241777 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(8LL), MK_INT(23LL), v_t_241776));
          return heff_tag_at_n(v_ru_24x1_241767_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241768_24VFloat, TAG_VInt, 1, (V[]){v_t_241777})});
        } else {
          heff_drop_cell(v_ru_24x1_241767_24Ok, 1);
          heff_drop_cell(v_ru_24v_241768_24VFloat, 1);
          return NTAG(TAG_Abn);
        }
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241768, 0ULL, 1);
      heff_drop(v_a_241764);
      heff_drop_cell(v_ru_24x1_241767_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241768, 0ULL, 1);
      heff_drop(v_a_241764);
      heff_drop_cell(v_ru_24x1_241767_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241768, 0ULL, 1);
      heff_drop(v_a_241764);
      heff_drop_cell(v_ru_24x1_241767_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241768, 0ULL, 1);
      heff_drop(v_a_241764);
      heff_drop_cell(v_ru_24x1_241767_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241768, 0ULL, 1);
      heff_drop(v_a_241764);
      heff_drop_cell(v_ru_24x1_241767_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241768, 0ULL, 2);
      heff_drop(v_a_241764);
      heff_drop_cell(v_ru_24x1_241767_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241764);
      heff_drop_cell(v_ru_24x1_241767_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_241768);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241764);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241764);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241785 = heff_field(v_x1_241767, 0);
    V v_ru_24x1_241767_24Bug = heff_take_reuse_n(v_x1_241767, 1ULL, 1);
    heff_drop(v_a_241764);
    return heff_tag_at_n(v_ru_24x1_241767_24Bug, TAG_Bug, 1, (V[]){v_what_241785});
  }
  default: return heff_nomatch(v_x1_241767);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam134(V self, V *args) {
  V v_d_241756 = args[0];
  V v_a_241757 = args[1];
  V v_x1_241758 = heff_tr(heff_call(v_a_241757, 1, (V[]){v_d_241756}));
  switch (heff_tag_of(v_x1_241758)) {
  case TAG_Ok: {
    V v_v_241759 = heff_field(v_x1_241758, 0);
    V v_ru_24x1_241758_24Ok = heff_take_reuse_n(v_x1_241758, 1ULL, 1);
    switch (heff_tag_of(v_v_241759)) {
    case TAG_VFun: {
      heff_take_n(v_v_241759, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241758_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241759, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241758_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241759, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241758_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241764 = heff_field(v_v_241759, 0);
      V v_ru_24v_241759_24VInt = heff_take_reuse_n(v_v_241759, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241758_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241759_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam135, 2, 1, (V[]){v_a_241764})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241759, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241758_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241759, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241758_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241759, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241758_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241759, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241758_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241759, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241758_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241759, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241758_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241759, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241758_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241758_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241759);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241794 = heff_field(v_x1_241758, 0);
    V v_ru_24x1_241758_24Bug = heff_take_reuse_n(v_x1_241758, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241758_24Bug, TAG_Bug, 1, (V[]){v_what_241794});
  }
  default: return heff_nomatch(v_x1_241758);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam137(V self, V *args) {
  V v_d_241804 = args[0];
  V v_a_241805 = args[1];
  V v_a_241803 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241806 = heff_tr(heff_call(v_a_241805, 1, (V[]){v_d_241804}));
  switch (heff_tag_of(v_x1_241806)) {
  case TAG_Ok: {
    V v_v_241807 = heff_field(v_x1_241806, 0);
    V v_ru_24x1_241806_24Ok = heff_take_reuse_n(v_x1_241806, 1ULL, 1);
    switch (heff_tag_of(v_v_241807)) {
    case TAG_VFun: {
      heff_take_n(v_v_241807, 0ULL, 1);
      heff_drop(v_a_241803);
      heff_drop_cell(v_ru_24x1_241806_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241807, 0ULL, 1);
      heff_drop(v_a_241803);
      heff_drop_cell(v_ru_24x1_241806_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241807, 0ULL, 2);
      heff_drop(v_a_241803);
      heff_drop_cell(v_ru_24x1_241806_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241812 = heff_field(v_v_241807, 0);
      V v_ru_24v_241807_24VInt = heff_take_reuse_n(v_v_241807, 1ULL, 1);
      V v_n_241813 = v_a_241803;
      V v_u_241814 = v_a_241812;
      if (heff_intEq_c_lent(v_n_241813, MK_INT(64LL), 2)) {
        heff_drop(v_n_241813);
        V v_t_241815 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
        V v_t_241816 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
        V v_t_241817 = heff_intAdd(heff_intMod(v_u_241814, v_t_241815), v_t_241816);
        V v_t_241818 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
        double v_t_241819 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(11LL), MK_INT(52LL), heff_intMod(v_t_241817, v_t_241818)));
        return heff_tag_at_n(v_ru_24x1_241806_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_nf(v_ru_24v_241807_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_241819)})});
      } else {
        if (heff_intEq_c(v_n_241813, MK_INT(32LL))) {
          V v_t_241820 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
          V v_t_241821 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
          V v_t_241822 = heff_intAdd(heff_intMod(v_u_241814, v_t_241820), v_t_241821);
          V v_t_241823 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
          double v_t_241824 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(8LL), MK_INT(23LL), heff_intMod(v_t_241822, v_t_241823)));
          return heff_tag_at_n(v_ru_24x1_241806_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_nf(v_ru_24v_241807_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_241824)})});
        } else {
          heff_drop_cell(v_ru_24x1_241806_24Ok, 1);
          heff_drop_cell(v_ru_24v_241807_24VInt, 1);
          heff_drop(v_u_241814);
          return NTAG(TAG_Abn);
        }
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241807, 0ULL, 1);
      heff_drop(v_a_241803);
      heff_drop_cell(v_ru_24x1_241806_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241807, 0ULL, 1);
      heff_drop(v_a_241803);
      heff_drop_cell(v_ru_24x1_241806_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241807, 0ULL, 1);
      heff_drop(v_a_241803);
      heff_drop_cell(v_ru_24x1_241806_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241807, 0ULL, 1);
      heff_drop(v_a_241803);
      heff_drop_cell(v_ru_24x1_241806_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241807, 0ULL, 1);
      heff_drop(v_a_241803);
      heff_drop_cell(v_ru_24x1_241806_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241807, 0ULL, 1);
      heff_drop(v_a_241803);
      heff_drop_cell(v_ru_24x1_241806_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241807, 0ULL, 2);
      heff_drop(v_a_241803);
      heff_drop_cell(v_ru_24x1_241806_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241803);
      heff_drop_cell(v_ru_24x1_241806_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241807);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241803);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241803);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241833 = heff_field(v_x1_241806, 0);
    V v_ru_24x1_241806_24Bug = heff_take_reuse_n(v_x1_241806, 1ULL, 1);
    heff_drop(v_a_241803);
    return heff_tag_at_n(v_ru_24x1_241806_24Bug, TAG_Bug, 1, (V[]){v_what_241833});
  }
  default: return heff_nomatch(v_x1_241806);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam136(V self, V *args) {
  V v_d_241795 = args[0];
  V v_a_241796 = args[1];
  V v_x1_241797 = heff_tr(heff_call(v_a_241796, 1, (V[]){v_d_241795}));
  switch (heff_tag_of(v_x1_241797)) {
  case TAG_Ok: {
    V v_v_241798 = heff_field(v_x1_241797, 0);
    V v_ru_24x1_241797_24Ok = heff_take_reuse_n(v_x1_241797, 1ULL, 1);
    switch (heff_tag_of(v_v_241798)) {
    case TAG_VFun: {
      heff_take_n(v_v_241798, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241797_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241798, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241797_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241798, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241797_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241803 = heff_field(v_v_241798, 0);
      V v_ru_24v_241798_24VInt = heff_take_reuse_n(v_v_241798, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241797_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241798_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam137, 2, 1, (V[]){v_a_241803})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241798, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241797_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241798, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241797_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241798, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241797_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241798, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241797_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241798, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241797_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241798, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241797_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241798, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241797_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241797_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241798);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241842 = heff_field(v_x1_241797, 0);
    V v_ru_24x1_241797_24Bug = heff_take_reuse_n(v_x1_241797, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241797_24Bug, TAG_Bug, 1, (V[]){v_what_241842});
  }
  default: return heff_nomatch(v_x1_241797);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam141(V self, V *args) {
  V v_d_241873 = args[0];
  V v_a_241874 = args[1];
  V v_a_241863 = heff_env(self)[0];
  V v_a_241872 = heff_env(self)[1];
  V v_a_241851 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241875 = heff_tr(heff_call(v_a_241874, 1, (V[]){v_d_241873}));
  switch (heff_tag_of(v_x1_241875)) {
  case TAG_Ok: {
    V v_v_241876 = heff_field(v_x1_241875, 0);
    V v_ru_24x1_241875_24Ok = heff_take_reuse_n(v_x1_241875, 1ULL, 1);
    switch (heff_tag_of(v_v_241876)) {
    case TAG_VFun: {
      heff_take_n(v_v_241876, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241872);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241875_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241876, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241872);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241875_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241876, 0ULL, 2);
      heff_drop(v_a_241863);
      heff_drop(v_a_241872);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241875_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241881 = heff_field(v_v_241876, 0);
      V v_ru_24v_241876_24VInt = heff_take_reuse_n(v_v_241876, 1ULL, 1);
      V v_t_241882 = heff_strSlice(v_a_241863, v_a_241872, v_a_241881);
      if (heff_intEq_c_lent(v_a_241851, MK_INT(64LL), 2)) {
        heff_drop(v_a_241851);
        double v_t_241883 = ({ V a_0 = MK_INT(64LL); V a_1 = v_t_241882; double r_ = (g_heff_2ecompile_2einterp_2edecimalTextV_w(a_0, a_1)); heff_drop(v_t_241882); r_; });
        return heff_tag_at_n(v_ru_24x1_241875_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_nf(v_ru_24v_241876_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_241883)})});
      } else {
        if (heff_intEq_c(v_a_241851, MK_INT(32LL))) {
          double v_t_241884 = ({ V a_0 = MK_INT(32LL); V a_1 = v_t_241882; double r_ = (g_heff_2ecompile_2einterp_2edecimalTextV_w(a_0, a_1)); heff_drop(v_t_241882); r_; });
          return heff_tag_at_n(v_ru_24x1_241875_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_nf(v_ru_24v_241876_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_241884)})});
        } else {
          heff_drop_cell(v_ru_24x1_241875_24Ok, 1);
          heff_drop_cell(v_ru_24v_241876_24VInt, 1);
          heff_drop(v_t_241882);
          return NTAG(TAG_Abn);
        }
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241876, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241872);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241875_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241876, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241872);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241875_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241876, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241872);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241875_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241876, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241872);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241875_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241876, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241872);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241875_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241876, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241872);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241875_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241876, 0ULL, 2);
      heff_drop(v_a_241863);
      heff_drop(v_a_241872);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241875_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241863);
      heff_drop(v_a_241872);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241875_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241876);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241863);
    heff_drop(v_a_241872);
    heff_drop(v_a_241851);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241863);
    heff_drop(v_a_241872);
    heff_drop(v_a_241851);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241893 = heff_field(v_x1_241875, 0);
    V v_ru_24x1_241875_24Bug = heff_take_reuse_n(v_x1_241875, 1ULL, 1);
    heff_drop(v_a_241863);
    heff_drop(v_a_241872);
    heff_drop(v_a_241851);
    return heff_tag_at_n(v_ru_24x1_241875_24Bug, TAG_Bug, 1, (V[]){v_what_241893});
  }
  default: return heff_nomatch(v_x1_241875);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam140(V self, V *args) {
  V v_d_241864 = args[0];
  V v_a_241865 = args[1];
  V v_a_241863 = heff_env(self)[0];
  V v_a_241851 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241866 = heff_tr(heff_call(v_a_241865, 1, (V[]){v_d_241864}));
  switch (heff_tag_of(v_x1_241866)) {
  case TAG_Ok: {
    V v_v_241867 = heff_field(v_x1_241866, 0);
    V v_ru_24x1_241866_24Ok = heff_take_reuse_n(v_x1_241866, 1ULL, 1);
    switch (heff_tag_of(v_v_241867)) {
    case TAG_VFun: {
      heff_take_n(v_v_241867, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241866_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241867, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241866_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241867, 0ULL, 2);
      heff_drop(v_a_241863);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241866_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241872 = heff_field(v_v_241867, 0);
      V v_ru_24v_241867_24VInt = heff_take_reuse_n(v_v_241867, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241866_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241867_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam141, 2, 3, (V[]){v_a_241863, v_a_241872, v_a_241851})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241867, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241866_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241867, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241866_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241867, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241866_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241867, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241866_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241867, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241866_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241867, 0ULL, 1);
      heff_drop(v_a_241863);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241866_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241867, 0ULL, 2);
      heff_drop(v_a_241863);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241866_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241863);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241866_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241867);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241863);
    heff_drop(v_a_241851);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241863);
    heff_drop(v_a_241851);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241902 = heff_field(v_x1_241866, 0);
    V v_ru_24x1_241866_24Bug = heff_take_reuse_n(v_x1_241866, 1ULL, 1);
    heff_drop(v_a_241863);
    heff_drop(v_a_241851);
    return heff_tag_at_n(v_ru_24x1_241866_24Bug, TAG_Bug, 1, (V[]){v_what_241902});
  }
  default: return heff_nomatch(v_x1_241866);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam139(V self, V *args) {
  V v_d_241852 = args[0];
  V v_a_241853 = args[1];
  V v_a_241851 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241854 = heff_tr(heff_call(v_a_241853, 1, (V[]){v_d_241852}));
  switch (heff_tag_of(v_x1_241854)) {
  case TAG_Ok: {
    V v_v_241855 = heff_field(v_x1_241854, 0);
    V v_ru_24x1_241854_24Ok = heff_take_reuse_n(v_x1_241854, 1ULL, 1);
    switch (heff_tag_of(v_v_241855)) {
    case TAG_VFun: {
      heff_take_n(v_v_241855, 0ULL, 1);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241855, 0ULL, 1);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241855, 0ULL, 2);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241855, 0ULL, 1);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241855, 0ULL, 1);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241855, 0ULL, 1);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241863 = heff_field(v_v_241855, 0);
      V v_ru_24v_241855_24VStr = heff_take_reuse_n(v_v_241855, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241854_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241855_24VStr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam140, 2, 2, (V[]){v_a_241863, v_a_241851})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241855, 0ULL, 1);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241855, 0ULL, 1);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241855, 0ULL, 1);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241855, 0ULL, 2);
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241851);
      heff_drop_cell(v_ru_24x1_241854_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241855);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241851);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241851);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241908 = heff_field(v_x1_241854, 0);
    V v_ru_24x1_241854_24Bug = heff_take_reuse_n(v_x1_241854, 1ULL, 1);
    heff_drop(v_a_241851);
    return heff_tag_at_n(v_ru_24x1_241854_24Bug, TAG_Bug, 1, (V[]){v_what_241908});
  }
  default: return heff_nomatch(v_x1_241854);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam138(V self, V *args) {
  V v_d_241843 = args[0];
  V v_a_241844 = args[1];
  V v_x1_241845 = heff_tr(heff_call(v_a_241844, 1, (V[]){v_d_241843}));
  switch (heff_tag_of(v_x1_241845)) {
  case TAG_Ok: {
    V v_v_241846 = heff_field(v_x1_241845, 0);
    V v_ru_24x1_241845_24Ok = heff_take_reuse_n(v_x1_241845, 1ULL, 1);
    switch (heff_tag_of(v_v_241846)) {
    case TAG_VFun: {
      heff_take_n(v_v_241846, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241846, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241846, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241851 = heff_field(v_v_241846, 0);
      V v_ru_24v_241846_24VInt = heff_take_reuse_n(v_v_241846, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241845_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241846_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam139, 2, 1, (V[]){v_a_241851})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241846, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241846, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241846, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241846, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241846, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241846, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241846, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241845_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241846);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241917 = heff_field(v_x1_241845, 0);
    V v_ru_24x1_241845_24Bug = heff_take_reuse_n(v_x1_241845, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241845_24Bug, TAG_Bug, 1, (V[]){v_what_241917});
  }
  default: return heff_nomatch(v_x1_241845);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam142(V self, V *args) {
  V v_d_241918 = args[0];
  V v_a_241919 = args[1];
  V v_x1_241920 = heff_tr(heff_call(v_a_241919, 1, (V[]){v_d_241918}));
  switch (heff_tag_of(v_x1_241920)) {
  case TAG_Ok: {
    V v_v_241921 = heff_field(v_x1_241920, 0);
    V v_ru_24x1_241920_24Ok = heff_take_reuse_n(v_x1_241920, 1ULL, 1);
    switch (heff_tag_of(v_v_241921)) {
    case TAG_VFun: {
      heff_take_n(v_v_241921, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241920_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241921, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241920_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241921, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241920_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241921, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241920_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241921, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241920_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241921, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241920_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241929 = heff_field(v_v_241921, 0);
      V v_ru_24v_241921_24VStr = heff_take_reuse_n(v_v_241921, 1ULL, 1);
      V v_t_241930 = ({ V a_0 = v_a_241929; V a_1 = MK_INT(0LL); V a_2 = heff_strLength_lent(v_a_241929, 0); V r_ = (g_heff_2ecompile_2einterp_2ehashFrom(a_0, a_1, a_2)); heff_drop(v_a_241929); r_; });
      V v_t_241931 = (g_heff_2ecompile_2einterp_2efmix64(v_t_241930));
      V v_t_241932 = heff_tag_at_n(v_ru_24v_241921_24VStr, TAG_VInt, 1, (V[]){heff_intDiv(v_t_241931, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_241920_24Ok, TAG_Ok, 1, (V[]){v_t_241932});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241921, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241920_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241921, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241920_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241921, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241920_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241921, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241920_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241920_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241921);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241938 = heff_field(v_x1_241920, 0);
    V v_ru_24x1_241920_24Bug = heff_take_reuse_n(v_x1_241920, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241920_24Bug, TAG_Bug, 1, (V[]){v_what_241938});
  }
  default: return heff_nomatch(v_x1_241920);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam145(V self, V *args) {
  V v_d_241960 = args[0];
  V v_a_241961 = args[1];
  V v_a_241950 = heff_env(self)[0];
  V v_a_241959 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241962 = heff_tr(heff_call(v_a_241961, 1, (V[]){v_d_241960}));
  switch (heff_tag_of(v_x1_241962)) {
  case TAG_Ok: {
    V v_v_241963 = heff_field(v_x1_241962, 0);
    V v_ru_24x1_241962_24Ok = heff_take_reuse_n(v_x1_241962, 1ULL, 1);
    switch (heff_tag_of(v_v_241963)) {
    case TAG_VFun: {
      heff_take_n(v_v_241963, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop(v_a_241959);
      heff_drop_cell(v_ru_24x1_241962_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241963, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop(v_a_241959);
      heff_drop_cell(v_ru_24x1_241962_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241963, 0ULL, 2);
      heff_drop(v_a_241950);
      heff_drop(v_a_241959);
      heff_drop_cell(v_ru_24x1_241962_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241968 = heff_field(v_v_241963, 0);
      V v_ru_24v_241963_24VInt = heff_take_reuse_n(v_v_241963, 1ULL, 1);
      V v_s_241969 = heff_strSlice(v_a_241950, v_a_241959, v_a_241968);
      V v_t_241970 = ({ V a_0 = v_s_241969; V a_1 = MK_INT(0LL); V a_2 = heff_strLength_lent(v_s_241969, 0); V r_ = (g_heff_2ecompile_2einterp_2ehashFrom(a_0, a_1, a_2)); heff_drop(v_s_241969); r_; });
      V v_t_241971 = (g_heff_2ecompile_2einterp_2efmix64(v_t_241970));
      V v_t_241972 = heff_tag_at_n(v_ru_24v_241963_24VInt, TAG_VInt, 1, (V[]){heff_intDiv(v_t_241971, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_241962_24Ok, TAG_Ok, 1, (V[]){v_t_241972});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241963, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop(v_a_241959);
      heff_drop_cell(v_ru_24x1_241962_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241963, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop(v_a_241959);
      heff_drop_cell(v_ru_24x1_241962_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241963, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop(v_a_241959);
      heff_drop_cell(v_ru_24x1_241962_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241963, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop(v_a_241959);
      heff_drop_cell(v_ru_24x1_241962_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241963, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop(v_a_241959);
      heff_drop_cell(v_ru_24x1_241962_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241963, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop(v_a_241959);
      heff_drop_cell(v_ru_24x1_241962_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241963, 0ULL, 2);
      heff_drop(v_a_241950);
      heff_drop(v_a_241959);
      heff_drop_cell(v_ru_24x1_241962_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241950);
      heff_drop(v_a_241959);
      heff_drop_cell(v_ru_24x1_241962_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241963);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241950);
    heff_drop(v_a_241959);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241950);
    heff_drop(v_a_241959);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241981 = heff_field(v_x1_241962, 0);
    V v_ru_24x1_241962_24Bug = heff_take_reuse_n(v_x1_241962, 1ULL, 1);
    heff_drop(v_a_241950);
    heff_drop(v_a_241959);
    return heff_tag_at_n(v_ru_24x1_241962_24Bug, TAG_Bug, 1, (V[]){v_what_241981});
  }
  default: return heff_nomatch(v_x1_241962);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam144(V self, V *args) {
  V v_d_241951 = args[0];
  V v_a_241952 = args[1];
  V v_a_241950 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241953 = heff_tr(heff_call(v_a_241952, 1, (V[]){v_d_241951}));
  switch (heff_tag_of(v_x1_241953)) {
  case TAG_Ok: {
    V v_v_241954 = heff_field(v_x1_241953, 0);
    V v_ru_24x1_241953_24Ok = heff_take_reuse_n(v_x1_241953, 1ULL, 1);
    switch (heff_tag_of(v_v_241954)) {
    case TAG_VFun: {
      heff_take_n(v_v_241954, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop_cell(v_ru_24x1_241953_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241954, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop_cell(v_ru_24x1_241953_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241954, 0ULL, 2);
      heff_drop(v_a_241950);
      heff_drop_cell(v_ru_24x1_241953_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241959 = heff_field(v_v_241954, 0);
      V v_ru_24v_241954_24VInt = heff_take_reuse_n(v_v_241954, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241953_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241954_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam145, 2, 2, (V[]){v_a_241950, v_a_241959})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241954, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop_cell(v_ru_24x1_241953_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241954, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop_cell(v_ru_24x1_241953_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241954, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop_cell(v_ru_24x1_241953_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241954, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop_cell(v_ru_24x1_241953_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241954, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop_cell(v_ru_24x1_241953_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241954, 0ULL, 1);
      heff_drop(v_a_241950);
      heff_drop_cell(v_ru_24x1_241953_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241954, 0ULL, 2);
      heff_drop(v_a_241950);
      heff_drop_cell(v_ru_24x1_241953_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241950);
      heff_drop_cell(v_ru_24x1_241953_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241954);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241950);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241950);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241990 = heff_field(v_x1_241953, 0);
    V v_ru_24x1_241953_24Bug = heff_take_reuse_n(v_x1_241953, 1ULL, 1);
    heff_drop(v_a_241950);
    return heff_tag_at_n(v_ru_24x1_241953_24Bug, TAG_Bug, 1, (V[]){v_what_241990});
  }
  default: return heff_nomatch(v_x1_241953);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam143(V self, V *args) {
  V v_d_241939 = args[0];
  V v_a_241940 = args[1];
  V v_x1_241941 = heff_tr(heff_call(v_a_241940, 1, (V[]){v_d_241939}));
  switch (heff_tag_of(v_x1_241941)) {
  case TAG_Ok: {
    V v_v_241942 = heff_field(v_x1_241941, 0);
    V v_ru_24x1_241941_24Ok = heff_take_reuse_n(v_x1_241941, 1ULL, 1);
    switch (heff_tag_of(v_v_241942)) {
    case TAG_VFun: {
      heff_take_n(v_v_241942, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241941_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241942, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241941_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241942, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241941_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241942, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241941_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241942, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241941_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241942, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241941_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241950 = heff_field(v_v_241942, 0);
      V v_ru_24v_241942_24VStr = heff_take_reuse_n(v_v_241942, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241941_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_241942_24VStr, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam144, 2, 1, (V[]){v_a_241950})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241942, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241941_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241942, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241941_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241942, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241941_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241942, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241941_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241941_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241942);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241996 = heff_field(v_x1_241941, 0);
    V v_ru_24x1_241941_24Bug = heff_take_reuse_n(v_x1_241941, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241941_24Bug, TAG_Bug, 1, (V[]){v_what_241996});
  }
  default: return heff_nomatch(v_x1_241941);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam148(V self, V *args) {
  V v_d_242008 = args[0];
  V v_a_242009 = args[1];
  V v_t_241997 = heff_env(self)[0];
  V v_a_241998 = heff_env(self)[1];
  V v_a_242007 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_242010 = heff_tr(heff_call(v_a_242009, 1, (V[]){v_d_242008}));
  switch (heff_tag_of(v_x1_242010)) {
  case TAG_Ok: {
    V v_v_242011 = heff_field(v_x1_242010, 0);
    V v_ru_24x1_242010_24Ok = heff_take_reuse_n(v_x1_242010, 1ULL, 1);
    switch (heff_tag_of(v_v_242011)) {
    case TAG_VFun: {
      heff_take_n(v_v_242011, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop(v_a_242007);
      heff_drop_cell(v_ru_24x1_242010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_242011, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop(v_a_242007);
      heff_drop_cell(v_ru_24x1_242010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_242011, 0ULL, 2);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop(v_a_242007);
      heff_drop_cell(v_ru_24x1_242010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_242016 = heff_field(v_v_242011, 0);
      heff_take_n(v_v_242011, 1ULL, 1);
      V v_t_242017;
      if (heff_strEq_c(v_t_241997, heff_strSlice(v_a_241998, v_a_242007, v_a_242016))) {
        v_t_242017 = ((V)&g_heff_2ecompile_2einterp_2eprim_str37);
      } else {
        v_t_242017 = ((V)&g_heff_2ecompile_2einterp_2eprim_str38);
      }
      V v_t_242018 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_242017, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_242010_24Ok, TAG_Ok, 1, (V[]){v_t_242018});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_242011, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop(v_a_242007);
      heff_drop_cell(v_ru_24x1_242010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_242011, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop(v_a_242007);
      heff_drop_cell(v_ru_24x1_242010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_242011, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop(v_a_242007);
      heff_drop_cell(v_ru_24x1_242010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_242011, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop(v_a_242007);
      heff_drop_cell(v_ru_24x1_242010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_242011, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop(v_a_242007);
      heff_drop_cell(v_ru_24x1_242010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_242011, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop(v_a_242007);
      heff_drop_cell(v_ru_24x1_242010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_242011, 0ULL, 2);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop(v_a_242007);
      heff_drop_cell(v_ru_24x1_242010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop(v_a_242007);
      heff_drop_cell(v_ru_24x1_242010_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_242011);
    }
  }
  case TAG_Abn: {
    heff_drop(v_t_241997);
    heff_drop(v_a_241998);
    heff_drop(v_a_242007);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_t_241997);
    heff_drop(v_a_241998);
    heff_drop(v_a_242007);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_242027 = heff_field(v_x1_242010, 0);
    V v_ru_24x1_242010_24Bug = heff_take_reuse_n(v_x1_242010, 1ULL, 1);
    heff_drop(v_t_241997);
    heff_drop(v_a_241998);
    heff_drop(v_a_242007);
    return heff_tag_at_n(v_ru_24x1_242010_24Bug, TAG_Bug, 1, (V[]){v_what_242027});
  }
  default: return heff_nomatch(v_x1_242010);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam147(V self, V *args) {
  V v_d_241999 = args[0];
  V v_a_242000 = args[1];
  V v_t_241997 = heff_env(self)[0];
  V v_a_241998 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_242001 = heff_tr(heff_call(v_a_242000, 1, (V[]){v_d_241999}));
  switch (heff_tag_of(v_x1_242001)) {
  case TAG_Ok: {
    V v_v_242002 = heff_field(v_x1_242001, 0);
    V v_ru_24x1_242001_24Ok = heff_take_reuse_n(v_x1_242001, 1ULL, 1);
    switch (heff_tag_of(v_v_242002)) {
    case TAG_VFun: {
      heff_take_n(v_v_242002, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop_cell(v_ru_24x1_242001_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_242002, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop_cell(v_ru_24x1_242001_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_242002, 0ULL, 2);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop_cell(v_ru_24x1_242001_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_242007 = heff_field(v_v_242002, 0);
      V v_ru_24v_242002_24VInt = heff_take_reuse_n(v_v_242002, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_242001_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_242002_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam148, 2, 3, (V[]){v_t_241997, v_a_241998, v_a_242007})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_242002, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop_cell(v_ru_24x1_242001_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_242002, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop_cell(v_ru_24x1_242001_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_242002, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop_cell(v_ru_24x1_242001_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_242002, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop_cell(v_ru_24x1_242001_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_242002, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop_cell(v_ru_24x1_242001_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_242002, 0ULL, 1);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop_cell(v_ru_24x1_242001_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_242002, 0ULL, 2);
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop_cell(v_ru_24x1_242001_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_t_241997);
      heff_drop(v_a_241998);
      heff_drop_cell(v_ru_24x1_242001_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_242002);
    }
  }
  case TAG_Abn: {
    heff_drop(v_t_241997);
    heff_drop(v_a_241998);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_t_241997);
    heff_drop(v_a_241998);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_242036 = heff_field(v_x1_242001, 0);
    V v_ru_24x1_242001_24Bug = heff_take_reuse_n(v_x1_242001, 1ULL, 1);
    heff_drop(v_t_241997);
    heff_drop(v_a_241998);
    return heff_tag_at_n(v_ru_24x1_242001_24Bug, TAG_Bug, 1, (V[]){v_what_242036});
  }
  default: return heff_nomatch(v_x1_242001);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam146(V self, V *args) {
  V v_t_241997 = args[0];
  V v_a_241998 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam147, 2, 2, (V[]){v_t_241997, v_a_241998})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam149(V self, V *args) {
  V v_d_242037 = args[0];
  V v_a_242038 = args[1];
  V v_x1_242039 = heff_tr(heff_call(v_a_242038, 1, (V[]){v_d_242037}));
  switch (heff_tag_of(v_x1_242039)) {
  case TAG_Ok: {
    V v_v_242040 = heff_field(v_x1_242039, 0);
    V v_ru_24x1_242039_24Ok = heff_take_reuse_n(v_x1_242039, 1ULL, 1);
    switch (heff_tag_of(v_v_242040)) {
    case TAG_VFun: {
      heff_take_n(v_v_242040, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242039_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_242040, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242039_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_242040, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242039_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_242045 = heff_field(v_v_242040, 0);
      V v_ru_24v_242040_24VInt = heff_take_reuse_n(v_v_242040, 1ULL, 1);
      V v_t_242046 = heff_intAdd(heff_intMod(v_a_242045, heff_dup(g_heff_2ecompile_2einterp_2eword64_get())), heff_dup(g_heff_2ecompile_2einterp_2eword64_get()));
      V v_t_242047 = (g_heff_2ecompile_2einterp_2efmix64(heff_intMod(v_t_242046, heff_dup(g_heff_2ecompile_2einterp_2eword64_get()))));
      V v_t_242048 = heff_tag_at_n(v_ru_24v_242040_24VInt, TAG_VInt, 1, (V[]){heff_intDiv(v_t_242047, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_242039_24Ok, TAG_Ok, 1, (V[]){v_t_242048});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_242040, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242039_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_242040, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242039_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_242040, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242039_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_242040, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242039_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_242040, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242039_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_242040, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242039_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_242040, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242039_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_242039_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_242040);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_242057 = heff_field(v_x1_242039, 0);
    V v_ru_24x1_242039_24Bug = heff_take_reuse_n(v_x1_242039, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_242039_24Bug, TAG_Bug, 1, (V[]){v_what_242057});
  }
  default: return heff_nomatch(v_x1_242039);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam152(V self, V *args) {
  V v_d_242076 = args[0];
  V v_a_242077 = args[1];
  V v_a_242066 = heff_env(self)[0];
  V v_a_242075 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_242078 = heff_tr(heff_call(v_a_242077, 1, (V[]){v_d_242076}));
  switch (heff_tag_of(v_x1_242078)) {
  case TAG_Ok: {
    V v_v_242079 = heff_field(v_x1_242078, 0);
    V v_ru_24x1_242078_24Ok = heff_take_reuse_n(v_x1_242078, 1ULL, 1);
    switch (heff_tag_of(v_v_242079)) {
    case TAG_VFun: {
      heff_take_n(v_v_242079, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop(v_a_242075);
      heff_drop_cell(v_ru_24x1_242078_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_242079, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop(v_a_242075);
      heff_drop_cell(v_ru_24x1_242078_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_242079, 0ULL, 2);
      heff_drop(v_a_242066);
      heff_drop(v_a_242075);
      heff_drop_cell(v_ru_24x1_242078_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_242084 = heff_field(v_v_242079, 0);
      V v_ru_24v_242079_24VInt = heff_take_reuse_n(v_v_242079, 1ULL, 1);
      V v_bm_242085 = v_a_242066;
      V v_h_242086 = v_a_242075;
      V v_s_242087 = v_a_242084;
      V v_t_242088 = (g_heff_2eelab_2efixed_2etwoTo(heff_dup(v_s_242087)));
      V v_t_242089 = heff_intMod(heff_intDiv(heff_dup(v_h_242086), v_t_242088), MK_INT(32LL));
      V v_t_242090 = (g_heff_2eelab_2efixed_2etwoTo(v_t_242089));
      V v_t_242091 = heff_intMod(heff_intDiv(heff_dup(v_bm_242085), v_t_242090), MK_INT(2LL));
      V v_t_242099;
      if ((heff_unbox_word(v_t_242091) == ((int64_t)1ULL))) {
        V v_t_242092 = (g_heff_2eelab_2efixed_2etwoTo(v_s_242087));
        V v_t_242093 = heff_intMod(heff_intDiv(v_h_242086, v_t_242092), MK_INT(32LL));
        V v_t_242094 = (g_heff_2eelab_2efixed_2etwoTo(v_t_242093));
        v_t_242099 = (g_heff_2ecompile_2einterp_2ebitsSet(heff_intMod(v_bm_242085, v_t_242094)));
      } else {
        V v_t_242095 = (g_heff_2eelab_2efixed_2etwoTo(v_s_242087));
        V v_t_242096 = heff_intMod(heff_intDiv(v_h_242086, v_t_242095), MK_INT(32LL));
        V v_t_242097 = (g_heff_2eelab_2efixed_2etwoTo(v_t_242096));
        V v_t_242098 = (g_heff_2ecompile_2einterp_2ebitsSet(heff_intMod(v_bm_242085, v_t_242097)));
        v_t_242099 = heff_intSub(MK_INT(-1LL), v_t_242098);
      }
      return heff_tag_at_n(v_ru_24x1_242078_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_242079_24VInt, TAG_VInt, 1, (V[]){v_t_242099})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_242079, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop(v_a_242075);
      heff_drop_cell(v_ru_24x1_242078_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_242079, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop(v_a_242075);
      heff_drop_cell(v_ru_24x1_242078_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_242079, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop(v_a_242075);
      heff_drop_cell(v_ru_24x1_242078_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_242079, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop(v_a_242075);
      heff_drop_cell(v_ru_24x1_242078_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_242079, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop(v_a_242075);
      heff_drop_cell(v_ru_24x1_242078_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_242079, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop(v_a_242075);
      heff_drop_cell(v_ru_24x1_242078_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_242079, 0ULL, 2);
      heff_drop(v_a_242066);
      heff_drop(v_a_242075);
      heff_drop_cell(v_ru_24x1_242078_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_242066);
      heff_drop(v_a_242075);
      heff_drop_cell(v_ru_24x1_242078_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_242079);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_242066);
    heff_drop(v_a_242075);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_242066);
    heff_drop(v_a_242075);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_242108 = heff_field(v_x1_242078, 0);
    V v_ru_24x1_242078_24Bug = heff_take_reuse_n(v_x1_242078, 1ULL, 1);
    heff_drop(v_a_242066);
    heff_drop(v_a_242075);
    return heff_tag_at_n(v_ru_24x1_242078_24Bug, TAG_Bug, 1, (V[]){v_what_242108});
  }
  default: return heff_nomatch(v_x1_242078);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam151(V self, V *args) {
  V v_d_242067 = args[0];
  V v_a_242068 = args[1];
  V v_a_242066 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_242069 = heff_tr(heff_call(v_a_242068, 1, (V[]){v_d_242067}));
  switch (heff_tag_of(v_x1_242069)) {
  case TAG_Ok: {
    V v_v_242070 = heff_field(v_x1_242069, 0);
    V v_ru_24x1_242069_24Ok = heff_take_reuse_n(v_x1_242069, 1ULL, 1);
    switch (heff_tag_of(v_v_242070)) {
    case TAG_VFun: {
      heff_take_n(v_v_242070, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop_cell(v_ru_24x1_242069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_242070, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop_cell(v_ru_24x1_242069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_242070, 0ULL, 2);
      heff_drop(v_a_242066);
      heff_drop_cell(v_ru_24x1_242069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_242075 = heff_field(v_v_242070, 0);
      V v_ru_24v_242070_24VInt = heff_take_reuse_n(v_v_242070, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_242069_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_242070_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam152, 2, 2, (V[]){v_a_242066, v_a_242075})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_242070, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop_cell(v_ru_24x1_242069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_242070, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop_cell(v_ru_24x1_242069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_242070, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop_cell(v_ru_24x1_242069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_242070, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop_cell(v_ru_24x1_242069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_242070, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop_cell(v_ru_24x1_242069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_242070, 0ULL, 1);
      heff_drop(v_a_242066);
      heff_drop_cell(v_ru_24x1_242069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_242070, 0ULL, 2);
      heff_drop(v_a_242066);
      heff_drop_cell(v_ru_24x1_242069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_242066);
      heff_drop_cell(v_ru_24x1_242069_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_242070);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_242066);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_242066);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_242117 = heff_field(v_x1_242069, 0);
    V v_ru_24x1_242069_24Bug = heff_take_reuse_n(v_x1_242069, 1ULL, 1);
    heff_drop(v_a_242066);
    return heff_tag_at_n(v_ru_24x1_242069_24Bug, TAG_Bug, 1, (V[]){v_what_242117});
  }
  default: return heff_nomatch(v_x1_242069);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam150(V self, V *args) {
  V v_d_242058 = args[0];
  V v_a_242059 = args[1];
  V v_x1_242060 = heff_tr(heff_call(v_a_242059, 1, (V[]){v_d_242058}));
  switch (heff_tag_of(v_x1_242060)) {
  case TAG_Ok: {
    V v_v_242061 = heff_field(v_x1_242060, 0);
    V v_ru_24x1_242060_24Ok = heff_take_reuse_n(v_x1_242060, 1ULL, 1);
    switch (heff_tag_of(v_v_242061)) {
    case TAG_VFun: {
      heff_take_n(v_v_242061, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242060_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_242061, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242060_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_242061, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242060_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_242066 = heff_field(v_v_242061, 0);
      V v_ru_24v_242061_24VInt = heff_take_reuse_n(v_v_242061, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_242060_24Ok, TAG_Ok, 1, (V[]){heff_tag_at_n(v_ru_24v_242061_24VInt, TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam151, 2, 1, (V[]){v_a_242066})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_242061, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242060_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_242061, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242060_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_242061, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242060_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_242061, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242060_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_242061, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242060_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_242061, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242060_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_242061, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242060_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_242060_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_242061);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_242126 = heff_field(v_x1_242060, 0);
    V v_ru_24x1_242060_24Bug = heff_take_reuse_n(v_x1_242060, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_242060_24Bug, TAG_Bug, 1, (V[]){v_what_242126});
  }
  default: return heff_nomatch(v_x1_242060);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam153(V self, V *args) {
  V v_d_242129 = args[0];
  V v_a_242130 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_242129);
  heff_drop(v_a_242130);
  V v_t_242131 = ({ V a_0 = v_p_240; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_240); r_; });
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprim_str39), v_t_242131)});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str0, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str2, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str3, 2, "{ ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str4, 2, " }");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str5, 3, "Nil");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str6, 4, "Cons");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str7, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str10, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str16, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str17, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str18, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str20, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str21, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str22, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str23, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str24, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str25, 1, ")");
Clo g_heff_2ecompile_2einterp_2eshowValGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eshowValGo_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eshowValGo(V v_inArg_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VCons: {
    V v_fs_242 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_keys_243 = heff_take_field(v_fs_242, 0);
    V v_values_244 = heff_get_n(v_fs_242, 2, 3);
    V v_t_245 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_243), heff_arrayToList(v_values_244)));
    V v_x2_246 = (g_list_2emap_24s24324293x740715900(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str0), v_t_245));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str3), v_t_249), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str4));
  }
  case TAG_VTag: {
    V v_x_2410 = heff_field(v_v_241, 0);
    V v_vs_2411 = heff_field(v_v_241, 1);
    V v_ru_24v_241_24VTag = heff_take_reuse_n(v_v_241, 3ULL, 2);
    V v_t_2421;
    if (heff_strEq_c_lent(v_x_2410, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str5), 2)) {
      heff_drop_cell(v_ru_24v_241_24VTag, 2);
      switch (heff_tag_of(v_vs_2411)) {
      case TAG_Nil: {
        v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        v_t_2421 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_vs_2411);
      }
    } else {
      if (heff_strEq_c_lent(v_x_2410, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str6), 2)) {
        switch (heff_tag_of(v_vs_2411)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24v_241_24VTag, 2);
          v_t_2421 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_x_2414 = heff_dup(heff_field(v_vs_2411, 0));
          V v_x122_2415 = heff_dup(heff_field(v_vs_2411, 1));
          switch (heff_tag_of(v_x122_2415)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24v_241_24VTag, 2);
            heff_drop(v_x_2414);
            v_t_2421 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Cons: {
            V v_rest_2416 = heff_field(v_x122_2415, 0);
            V v_x1222_2417 = heff_field(v_x122_2415, 1);
            heff_take_n(v_x122_2415, 3ULL, 2);
            switch (heff_tag_of(v_x1222_2417)) {
            case TAG_Nil: {
              V v_t_2418 = heff_tag_at_n(v_ru_24v_241_24VTag, TAG_Cons, 2, (V[]){v_x_2414, NTAG(TAG_Nil)});
              v_t_2421 = (g_heff_2ecompile_2einterp_2elistValsGo(v_rest_2416, v_t_2418));
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_x1222_2417, 0ULL, 2);
              heff_drop_cell(v_ru_24v_241_24VTag, 2);
              heff_drop(v_x_2414);
              heff_drop(v_rest_2416);
              v_t_2421 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_x1222_2417);
            }
            break;
          }
          default: heff_nomatch(v_x122_2415);
          }
          break;
        }
        default: heff_nomatch(v_vs_2411);
        }
      } else {
        heff_drop_cell(v_ru_24v_241_24VTag, 2);
        v_t_2421 = NTAG(TAG_Nothing);
      }
    }
    switch (heff_tag_of(v_t_2421)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_vs_2411)) {
      case TAG_Nil: {
        return v_x_2410;
      }
      case TAG_Cons: {
        if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
          V v_x2_2424 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str7), v_vs_2411));
          V v_t_2427;
          switch (heff_tag_of(v_x2_2424)) {
          case TAG_Nil: {
            v_t_2427 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str8);
            break;
          }
          case TAG_Cons: {
            V v_x_2425 = heff_field(v_x2_2424, 0);
            V v_xs_2426 = heff_field(v_x2_2424, 1);
            heff_take_n(v_x2_2424, 3ULL, 2);
            v_t_2427 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str9); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2424);
          }
          V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str10), v_x_2410), v_t_2427);
          return heff_strAppend(v_t_2428, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str11));
        } else {
          V v_x2_2429 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str12), v_vs_2411));
          V v_t_2432;
          switch (heff_tag_of(v_x2_2429)) {
          case TAG_Nil: {
            v_t_2432 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str13);
            break;
          }
          case TAG_Cons: {
            V v_x_2430 = heff_field(v_x2_2429, 0);
            V v_xs_2431 = heff_field(v_x2_2429, 1);
            heff_take_n(v_x2_2429, 3ULL, 2);
            v_t_2432 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str14); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2429);
          }
          return heff_strAppend(v_x_2410, v_t_2432);
        }
      }
      default: return heff_nomatch(v_vs_2411);
      }
    }
    case TAG_Just: {
      V v_items_2433 = heff_field(v_t_2421, 0);
      heff_take_n(v_t_2421, 1ULL, 1);
      heff_drop(v_x_2410);
      heff_drop(v_vs_2411);
      V v_x2_2434 = (g_list_2emap_24s391931963x434308123(v_items_2433));
      V v_t_2437;
      switch (heff_tag_of(v_x2_2434)) {
      case TAG_Nil: {
        v_t_2437 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str15);
        break;
      }
      case TAG_Cons: {
        V v_x_2435 = heff_field(v_x2_2434, 0);
        V v_xs_2436 = heff_field(v_x2_2434, 1);
        heff_take_n(v_x2_2434, 3ULL, 2);
        v_t_2437 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str16); V a_1 = v_x_2435; V a_2 = v_xs_2436; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2436); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2434);
      }
      return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str17), v_t_2437), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str18));
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  case TAG_VArr: {
    V v_xs_2438 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_x2_2439 = (g_list_2emap_24s391931963x434308123(heff_arrayToList(v_xs_2438)));
    V v_t_2442;
    switch (heff_tag_of(v_x2_2439)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_x2_2439, 0);
      V v_xs_2441 = heff_field(v_x2_2439, 1);
      heff_take_n(v_x2_2439, 3ULL, 2);
      v_t_2442 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str20); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2439);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str21), v_t_2442), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str22));
  }
  default: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2443 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2443, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str23))) {
        V v_t_2444 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop(v_v_241); r_; });
        return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str24), v_t_2444), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str25));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop(v_v_241); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop(v_v_241); r_; });
    }
  }
  }
}
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2eshowValGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_lam0, 1, 0};
Clo g_heff_2ecompile_2einterp_2eapplyErased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eapplyErased(V v_n_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_r_241)) {
  case TAG_RSucceeded: {
    V v_r1_242 = heff_dup(heff_field(v_r_241, 0));
    switch (heff_tag_of(v_r1_242)) {
    case TAG_VFun: {
      V v_f_243 = heff_field(v_r1_242, 0);
      V v_ru_24r1_242_24VFun = heff_take_reuse_n(v_r1_242, 1ULL, 1);
      switch (heff_tag_of(v_r_241)) {
      case TAG_RSucceeded: {
        V v_ru_24r_241_24RSucceeded = heff_take_reuse_n(v_r_241, 0ULL, 1);
        if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
          heff_drop(v_n_240);
          return heff_tag_at_n(v_ru_24r_241_24RSucceeded, TAG_RSucceeded, 1, (V[]){heff_tag_at_n(v_ru_24r1_242_24VFun, TAG_VFun, 1, (V[]){v_f_243})});
        } else {
          heff_drop_cell(v_ru_24r1_242_24VFun, 1);
          V v_x1_246 = heff_tr(heff_call(v_f_243, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo)}));
          V v_t_249;
          switch (heff_tag_of(v_x1_246)) {
          case TAG_Ok: {
            V v_v_247 = heff_field(v_x1_246, 0);
            heff_take_n(v_x1_246, 1ULL, 1);
            v_t_249 = heff_tag_at_n(v_ru_24r_241_24RSucceeded, TAG_RSucceeded, 1, (V[]){v_v_247});
            break;
          }
          case TAG_Abn: {
            heff_drop_cell(v_ru_24r_241_24RSucceeded, 1);
            v_t_249 = NTAG(TAG_RAbandoned);
            break;
          }
          case TAG_Div: {
            heff_drop_cell(v_ru_24r_241_24RSucceeded, 1);
            v_t_249 = NTAG(TAG_RDiverged);
            break;
          }
          case TAG_Bug: {
            V v_what_248 = heff_field(v_x1_246, 0);
            V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
            heff_drop_cell(v_ru_24r_241_24RSucceeded, 1);
            v_t_249 = heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_RBug, 1, (V[]){v_what_248});
            break;
          }
          default: heff_nomatch(v_x1_246);
          }
          V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
          V t_1 = v_t_249;
          v_n_240 = t_0;
          v_r_241 = t_1;
          goto top;
        }
      }
      default: return heff_nomatch(v_r_241);
      }
    }
    case TAG_VCons: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VTag: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VInt: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat: {
      heff_take_na(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat32: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VStr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VRune: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VArr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBytes: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBits: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VErased: {
      heff_drop(v_n_240);
      return v_r_241;
    }
    default: return heff_nomatch(v_r1_242);
    }
  }
  case TAG_RAbandoned: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RDiverged: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RBug: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  default: return heff_nomatch(v_r_241);
  }
}
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eapplyErased(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args) {
  V v_d_245 = args[0];
  heff_drop(v_d_245);
  return heff_tag_n(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
}
Clo g_heff_2ecompile_2einterp_2ereachGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ereachGlobals_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ereachGlobals(V v_gs_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_gs_240, 8);
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_seen_241, v_k_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_k_243);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        V t_0 = v_gs_240;
        V t_1 = v_seen_241;
        V t_2 = v_rest_244;
        v_gs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_seen_241, heff_dup(v_k_243), NTAG(TAG_MkUnit)));
        HeffT2 v_t_2410 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_gs_240, 1), v_k_243));
        V v_t_2424;
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            heff_drop(v_k_243);
            V v_e_2413 = v_field_2412;
            V v_t_2414 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_get_n(v_e_2413, 0, 4)));
            v_t_2424 = (g_heff_2eelab_2erename_2enubFirst(v_t_2414));
          } else {
            heff_drop(v_field_2412);
            HeffT2 v_t_2415 = ({ V a_0 = heff_rfield(v_gs_240, 2); V a_1 = v_k_243; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_k_243); r_; });
            {
              V v_field_2417 = v_t_2415.f[1];
              int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
              if ((v_tag_2416 == ((int64_t)0ULL))) {
                V v_k2_2418 = v_field_2417;
                HeffT2 v_t_2419 = ({ V a_0 = heff_rfield(v_gs_240, 1); V a_1 = v_k2_2418; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_k2_2418); r_; });
                {
                  V v_field_2421 = v_t_2419.f[1];
                  int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                  if ((v_tag_2420 == ((int64_t)0ULL))) {
                    V v_entry_2422 = v_field_2421;
                    V v_t_2423 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_get_n(v_entry_2422, 0, 4)));
                    v_t_2424 = (g_heff_2eelab_2erename_2enubFirst(v_t_2423));
                  } else {
                    heff_drop(v_field_2421);
                    v_t_2424 = NTAG(TAG_Nil);
                  }
                }
              } else {
                heff_drop(v_field_2417);
                v_t_2424 = NTAG(TAG_Nil);
              }
            }
          }
        }
        V v_t_2425 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_242_24Cons, v_t_2424, v_rest_244));
        V t_0 = v_gs_240;
        V t_1 = v_t_249;
        V t_2 = v_t_2425;
        v_gs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2einterp_2ereachGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ereachGlobals(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2eintAtV_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eintAtV_24tok1_entry, 6, 0};

V g_heff_2ecompile_2einterp_2eintAtV_24tok1(V v_tok_240, V v_s_241, V v_limit_242, V v_o_243, V v_n_244, V v_f_245) {
top: ;
  if ((heff_intLt_c_lent(v_o_243, MK_INT(0LL), 2) || (heff_intLt_c_lent(v_n_244, MK_INT(0LL), 2) || (heff_intLt_c_lent(MK_INT(64LL), v_n_244, 1) || heff_intLt_c(heff_dup(v_limit_242), heff_intAdd(heff_dup(v_o_243), heff_dup(v_n_244))))))) {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_limit_242);
    heff_drop(v_o_243);
    heff_drop(v_n_244);
    heff_drop(v_f_245);
    return NTAG(TAG_Abn);
  } else {
    heff_drop(v_limit_242);
    if ((heff_unbox_word(heff_intMod(heff_dup(v_f_245), MK_INT(2LL))) == ((int64_t)1ULL))) {
      V v_w_246 = (g_heff_2ecompile_2einterp_2ebitsRead(v_s_241, v_o_243, heff_dup(v_n_244), MK_INT(0LL)));
      V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intMod(heff_dup(v_n_244), MK_INT(8LL))));
      V v_t_248 = heff_intMul(MK_INT(8LL), heff_intDiv(heff_dup(v_n_244), MK_INT(8LL)));
      V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(v_t_248));
      V v_t_2410 = heff_intMul(heff_intMod(heff_dup(v_w_246), v_t_247), v_t_249);
      V v_u_2411 = (g_heff_2ecompile_2einterp_2elittleInGo(v_w_246, heff_dup(v_n_244), heff_intDiv(heff_dup(v_n_244), MK_INT(8LL)), MK_INT(0LL), v_t_2410));
      V v_t_2412 = heff_intMod(heff_intDiv(v_f_245, MK_INT(2LL)), MK_INT(2LL));
      V v_t_2415;
      if ((heff_unbox_word(v_t_2412) == ((int64_t)1ULL))) {
        if (heff_intLt_c_lent(MK_INT(0LL), v_n_244, 1)) {
          V v_y_2413 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intSub(heff_dup(v_n_244), MK_INT(1LL))));
          if (heff_intLe_c_lent(v_y_2413, v_u_2411, 1)) {
            V v_t_2414 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_244));
            v_t_2415 = heff_intSub(v_u_2411, v_t_2414);
          } else {
            heff_drop(v_n_244);
            v_t_2415 = v_u_2411;
          }
        } else {
          heff_drop(v_n_244);
          v_t_2415 = v_u_2411;
        }
      } else {
        heff_drop(v_n_244);
        v_t_2415 = v_u_2411;
      }
      return heff_tag_at_n(v_tok_240, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2415})});
    } else {
      V v_u_2416 = (g_heff_2ecompile_2einterp_2ebitsRead(v_s_241, v_o_243, heff_dup(v_n_244), MK_INT(0LL)));
      V v_t_2417 = heff_intMod(heff_intDiv(v_f_245, MK_INT(2LL)), MK_INT(2LL));
      V v_t_2420;
      if ((heff_unbox_word(v_t_2417) == ((int64_t)1ULL))) {
        if (heff_intLt_c_lent(MK_INT(0LL), v_n_244, 1)) {
          V v_y_2418 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intSub(heff_dup(v_n_244), MK_INT(1LL))));
          if (heff_intLe_c_lent(v_y_2418, v_u_2416, 1)) {
            V v_t_2419 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_244));
            v_t_2420 = heff_intSub(v_u_2416, v_t_2419);
          } else {
            heff_drop(v_n_244);
            v_t_2420 = v_u_2416;
          }
        } else {
          heff_drop(v_n_244);
          v_t_2420 = v_u_2416;
        }
      } else {
        heff_drop(v_n_244);
        v_t_2420 = v_u_2416;
      }
      return heff_tag_at_n(v_tok_240, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2420})});
    }
  }
}
V g_heff_2ecompile_2einterp_2eintAtV_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2einterp_2eintAtV_24tok1(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}