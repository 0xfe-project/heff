// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_Ok 9325
#define TAG_RAbandoned 16367
#define TAG_RBug 28397
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_aliases 1464806715
#define LBL_entries 787768015
#define LBL_keys 9783995
#define LBL_syntax 1059664654
#define LBL_values 1123329101
V g_heff_2ecompile_2einterp_2eapplyErased(V, V);
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eapplyErased_clo;
V g_heff_2ecompile_2einterp_2ebits1(V);
V g_heff_2ecompile_2einterp_2ebits1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebits1_clo;
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void);
V g_heff_2ecompile_2einterp_2ebitsCopy(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsCopy_clo;
V g_heff_2ecompile_2einterp_2ebitsJoined(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsJoined_clo;
V g_heff_2ecompile_2einterp_2ebitsOfIntV(V, V, V);
V g_heff_2ecompile_2einterp_2ebitsOfIntV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsOfIntV_clo;
V g_heff_2ecompile_2einterp_2ebitsOfIntV_24tok1(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsOfIntV_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsOfIntV_24tok1_clo;
V g_heff_2ecompile_2einterp_2ebitsRead(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitsRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitsRead_clo;
V g_heff_2ecompile_2einterp_2ebyteString(V, V);
V g_heff_2ecompile_2einterp_2ebyteString_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebyteString_clo;
V g_heff_2ecompile_2einterp_2ebytes2(V);
V g_heff_2ecompile_2einterp_2ebytes2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytes2_clo;
V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get(void);
V g_heff_2ecompile_2einterp_2ebytesJoined(V, V);
V g_heff_2ecompile_2einterp_2ebytesJoined_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesJoined_clo;
V g_heff_2ecompile_2einterp_2ebytesOfIntV(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfIntV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfIntV_clo;
V g_heff_2ecompile_2einterp_2ebytesOfIntV_24tok1(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfIntV_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfIntV_24tok1_clo;
V g_heff_2ecompile_2einterp_2ebytesOfNat(V, V, V);
V g_heff_2ecompile_2einterp_2ebytesOfNat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebytesOfNat_clo;
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void);
V g_heff_2ecompile_2einterp_2efixedPrimV(V);
V g_heff_2ecompile_2einterp_2efixedPrimV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedPrimV_clo;
V g_heff_2ecompile_2einterp_2efloat2(V);
V g_heff_2ecompile_2einterp_2efloat2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloat2_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get(void);
V g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get(void);
V g_heff_2ecompile_2einterp_2efloatOfBitsV(V, V);
V g_heff_2ecompile_2einterp_2efloatOfBitsV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloatOfBitsV_clo;
V g_heff_2ecompile_2einterp_2efloatOfBitsV_24tok1(V, V, V);
V g_heff_2ecompile_2einterp_2efloatOfBitsV_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloatOfBitsV_24tok1_clo;
V g_heff_2ecompile_2einterp_2efloatTake2(V, V, V);
V g_heff_2ecompile_2einterp_2efloatTake2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efloatTake2_clo;
V g_heff_2ecompile_2einterp_2efmix64(V);
V g_heff_2ecompile_2einterp_2efmix64_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efmix64_clo;
V g_heff_2ecompile_2einterp_2efromListV(V, V);
V g_heff_2ecompile_2einterp_2efromListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efromListV_clo;
V g_heff_2ecompile_2einterp_2egenGo(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2egenGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2egenGo_clo;
V g_heff_2ecompile_2einterp_2ehashFrom(V, V, V);
V g_heff_2ecompile_2einterp_2ehashFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ehashFrom_clo;
V g_heff_2ecompile_2einterp_2eieeeBits_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeBits(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeBits_clo;
V g_heff_2ecompile_2einterp_2eieeeMagnitude_w(V, V, double);
V g_heff_2ecompile_2einterp_2eieeeMagnitude(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeMagnitude_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeMagnitude_clo;
double g_heff_2ecompile_2einterp_2eieeeOf_w(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf(V, V, V);
V g_heff_2ecompile_2einterp_2eieeeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeOf_clo;
V g_heff_2ecompile_2einterp_2eint2(V);
V g_heff_2ecompile_2einterp_2eint2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eint2_clo;
V g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get(void);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void);
V g_heff_2ecompile_2einterp_2eintAtV(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintAtV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintAtV_clo;
V g_heff_2ecompile_2einterp_2eintAtV_24tok1(V, V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintAtV_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintAtV_24tok1_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_clo;
HeffT2 g_heff_2ecompile_2einterp_2elistValsGo_24cpr(V, V);
V g_heff_2ecompile_2einterp_2elittleInGo(V, V, V, V, V);
V g_heff_2ecompile_2einterp_2elittleInGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elittleInGo_clo;
V g_heff_2ecompile_2einterp_2elittleOut(V, V);
V g_heff_2ecompile_2einterp_2elittleOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2elittleOut_clo;
V g_heff_2ecompile_2einterp_2enotAFloat32_get(void);
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotARune_get(void);
V g_heff_2ecompile_2einterp_2enotAString_get(void);
V g_heff_2ecompile_2einterp_2enotAnArray_get(void);
V g_heff_2ecompile_2einterp_2enotAnInt_get(void);
V g_heff_2ecompile_2einterp_2enotBytes_get(void);
HeffT2 g_heff_2ecompile_2einterp_2enthV_24cpr(V, V);
V g_heff_2ecompile_2einterp_2eprim(V);
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eprim_clo;
V g_heff_2ecompile_2einterp_2ereachGlobals(V, V, V);
V g_heff_2ecompile_2einterp_2ereachGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ereachGlobals_clo;
V g_heff_2ecompile_2einterp_2erune2(V);
V g_heff_2ecompile_2einterp_2erune2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2erune2_clo;
V g_heff_2ecompile_2einterp_2eruneCodes(V);
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_clo;
V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V, V);
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo;
V g_heff_2ecompile_2einterp_2escalarV(V);
V g_heff_2ecompile_2einterp_2escalarV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2escalarV_clo;
V g_heff_2ecompile_2einterp_2esetAt(V, V, V);
V g_heff_2ecompile_2einterp_2esetAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esetAt_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2einterp_2esliceV(V, V, V);
V g_heff_2ecompile_2einterp_2esliceV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esliceV_clo;
V g_heff_2ecompile_2einterp_2estr2(V);
V g_heff_2ecompile_2einterp_2estr2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2estr2_clo;
V g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get(void);
V g_heff_2ecompile_2einterp_2etoListV(V);
V g_heff_2ecompile_2einterp_2etoListV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(V, V, V);
V g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227_clo;
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(V);
V g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317_clo;
V g_heff_2ecompile_2einterp_2etrieSlotOf(V, V, V);
V g_heff_2ecompile_2einterp_2etrieSlotOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etrieSlotOf_clo;
V g_heff_2ecompile_2einterp_2etwoTo(V);
V g_heff_2ecompile_2einterp_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoTo_clo;
V g_heff_2ecompile_2einterp_2eword64_get(void);
V g_heff_2ecompile_2einterp_2ewordOf(V, V, V);
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ewordOf_clo;
HeffT2 g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(V);
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2erename_2enubFirst(V);
V g_heff_2eelab_2erename_2enubFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2enubFirst_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1427000880x1925304966(V, V);
V g_list_2emap_24s1427000880x1925304966_entry(V self, V *a);
extern Clo g_list_2emap_24s1427000880x1925304966_clo;
V g_list_2emap_24s391931963x434308123(V);
V g_list_2emap_24s391931963x434308123_entry(V self, V *a);
extern Clo g_list_2emap_24s391931963x434308123_clo;
V g_list_2emap_24s503834852x510769098(V, V);
V g_list_2emap_24s503834852x510769098_entry(V self, V *a);
extern Clo g_list_2emap_24s503834852x510769098_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_rune_2evalidFrom(V, V);
V g_rune_2evalidFrom_entry(V self, V *a);
extern Clo g_rune_2evalidFrom_clo;
V g_runeFromInt_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAnInt_str0, 38, "a primitive given what is not an `Int`");

static V g_heff_2ecompile_2einterp_2enotAnInt_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAnInt_st;
static V g_heff_2ecompile_2einterp_2enotAnInt_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAnInt_str0)});
}
V g_heff_2ecompile_2einterp_2enotAnInt_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAnInt_st)) return g_heff_2ecompile_2einterp_2enotAnInt_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAnInt_val, &g_heff_2ecompile_2einterp_2enotAnInt_st, g_heff_2ecompile_2einterp_2enotAnInt_init);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAFloat64_str0, 41, "a primitive given what is not a `Float64`");

static V g_heff_2ecompile_2einterp_2enotAFloat64_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAFloat64_st;
static V g_heff_2ecompile_2einterp_2enotAFloat64_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAFloat64_str0)});
}
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAFloat64_st)) return g_heff_2ecompile_2einterp_2enotAFloat64_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAFloat64_val, &g_heff_2ecompile_2einterp_2enotAFloat64_st, g_heff_2ecompile_2einterp_2enotAFloat64_init);
}
Clo g_heff_2ecompile_2einterp_2efloatTake2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloatTake2_entry, 3, 0};

V g_heff_2ecompile_2einterp_2efloatTake2(V v_f_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_VFun: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VCons: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VTag: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VInt: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VFloat: {
    V v_a_248 = heff_tget_v(v_x2_241, 0);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_VFun: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      V v_b_2414 = heff_tget_v(v_x3_242, 0);
      return heff_tail(v_f_240, 2, (V[]){v_a_248, v_b_2414});
    }
    case TAG_VFloat32: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop(v_f_240);
      heff_drop(v_a_248);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_VFloat32: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VStr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VRune: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VArr: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VBytes: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VBits: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  case TAG_VErased: {
    heff_drop(v_f_240);
    return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2einterp_2efloatTake2_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2einterp_2efloatTake2(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2einterp_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ewordOf_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ewordOf(V v_n_240, V v_f_241, V v_v_242) {
top: ;
  if ((heff_unbox_word(heff_intMod(v_f_241, MK_INT(2LL))) == ((int64_t)1ULL))) {
    V v_t_243 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_245 = heff_intAdd(heff_intMod(v_v_242, v_t_243), v_t_244);
    V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    return (g_heff_2ecompile_2einterp_2elittleOut(heff_intMod(v_t_245, v_t_246), v_n_240));
  } else {
    V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_248 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_n_240)));
    V v_t_249 = heff_intAdd(heff_intMod(v_v_242, v_t_247), v_t_248);
    V v_t_2410 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_240));
    return heff_intMod(v_t_249, v_t_2410);
  }
}
V g_heff_2ecompile_2einterp_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ewordOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsOfIntV_str0, 0, "");
Clo g_heff_2ecompile_2einterp_2ebitsOfIntV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsOfIntV_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ebitsOfIntV(V v_n_240, V v_f_241, V v_v_242) {
top: ;
  if ((heff_intLt_c_lent(v_n_240, MK_INT(0LL), 2) || heff_intLt_c_lent(MK_INT(64LL), v_n_240, 1))) {
    heff_drop(v_n_240);
    heff_drop(v_f_241);
    heff_drop(v_v_242);
    return NTAG(TAG_Abn);
  } else {
    V v_w_243 = (g_heff_2ecompile_2einterp_2ewordOf(heff_dup(v_n_240), v_f_241, v_v_242));
    int64_t v_t_244 = ((heff_peek_word(v_n_240) + ((int64_t)7ULL)) / ((int64_t)8ULL));
    int64_t v_t_245 = ((heff_peek_word(v_n_240) + ((int64_t)7ULL)) / ((int64_t)8ULL));
    int64_t v_t_246 = ((v_t_245 * ((int64_t)8ULL)) - heff_peek_word(v_n_240));
    V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word(v_t_246)));
    V v_t_248 = (g_heff_2ecompile_2einterp_2ebytesOfNat(heff_box_word(v_t_244), heff_intMul(v_w_243, v_t_247), ((V)&g_heff_2ecompile_2einterp_2ebitsOfIntV_str0)));
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_n_240, v_t_248})});
  }
}
V g_heff_2ecompile_2einterp_2ebitsOfIntV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitsOfIntV(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2eieeeBits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eieeeBits_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eieeeBits_w(V v_eb_240, V v_fb_241, double v_x_242) {
top: ;
  if (!(v_x_242 == v_x_242)) {
    V v_t_243 = (g_heff_2ecompile_2einterp_2etwoTo(v_eb_240));
    V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_fb_241)));
    V v_t_245 = heff_intMul(heff_intSub(v_t_243, MK_INT(1LL)), v_t_244);
    V v_t_246 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_unbox_word(v_fb_241) - ((int64_t)1ULL)))));
    return heff_intAdd(v_t_245, v_t_246);
  } else {
    if (((v_x_242 < (0.0)) || ((v_x_242 == (0.0)) && (((1.0) / v_x_242) < (0.0))))) {
      V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((heff_peek_word(v_eb_240) + heff_peek_word(v_fb_241)))));
      V v_t_248 = (g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, ((0.0) - v_x_242)));
      return heff_intAdd(v_t_247, v_t_248);
    } else {
      HEFF_LAST return g_heff_2ecompile_2einterp_2eieeeMagnitude_w(v_eb_240, v_fb_241, v_x_242);
    }
  }
}
V g_heff_2ecompile_2einterp_2eieeeBits(V v_eb_240, V v_fb_241, V v_box_24x_242) {
  double v_x_242 = heff_unbox_f64(v_box_24x_242);
  return (g_heff_2ecompile_2einterp_2eieeeBits_w(v_eb_240, v_fb_241, v_x_242));
}
V g_heff_2ecompile_2einterp_2eieeeBits_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eieeeBits(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2einterp_2efloatOfBitsV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloatOfBitsV_entry, 2, 0};

V g_heff_2ecompile_2einterp_2efloatOfBitsV(V v_n_240, V v_u_241) {
top: ;
  if (heff_intEq_c_lent(v_n_240, MK_INT(64LL), 2)) {
    heff_drop(v_n_240);
    V v_t_242 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    V v_t_243 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    V v_t_244 = heff_intAdd(heff_intMod(v_u_241, v_t_242), v_t_243);
    V v_t_245 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(64LL)));
    double v_t_246 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(11LL), MK_INT(52LL), heff_intMod(v_t_244, v_t_245)));
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_nf(TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_246)})});
  } else {
    if (heff_intEq_c(v_n_240, MK_INT(32LL))) {
      V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      V v_t_248 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      V v_t_249 = heff_intAdd(heff_intMod(v_u_241, v_t_247), v_t_248);
      V v_t_2410 = (g_heff_2ecompile_2einterp_2etwoTo(MK_INT(32LL)));
      double v_t_2411 = (g_heff_2ecompile_2einterp_2eieeeOf_w(MK_INT(8LL), MK_INT(23LL), heff_intMod(v_t_249, v_t_2410)));
      return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_nf(TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_t_2411)})});
    } else {
      heff_drop(v_u_241);
      return NTAG(TAG_Abn);
    }
  }
}
V g_heff_2ecompile_2einterp_2efloatOfBitsV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efloatOfBitsV(a[0], a[1]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eruneCodes(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_VFun: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2411 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2411, heff_hole()});
      V v_u_2413 = (g_heff_2ecompile_2einterp_2eruneCodes_24dps(v_rest_242, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eruneCodes(a[0]);
}
Clo g_heff_2ecompile_2einterp_2eruneCodes_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eruneCodes_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_VFun: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VCons: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VTag: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat: {
      heff_take_na(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VStr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VRune: {
      V v_c_2412 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_2412, heff_hole()});
      V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2413;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VArr: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBytes: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VBits: {
      heff_take_n(v_x11_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2eruneCodes_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eruneCodes_24dps(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st;
static V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st)) return g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_val, &g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_st, g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_init);
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VFloat32: {
        V v_a_2414 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VFloat32: {
          V v_b_2421 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2422 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)(heff_unbox_f32(v_a_2414) / heff_unbox_f32(v_b_2421))))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2422});
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2414);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat32_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ef32V2_24s877455641x267884881_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st;
static V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st)) return g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val;
  return heff_global(&g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_val, &g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_st, g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_init);
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      heff_take_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VInt: {
        V v_a_2412 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VInt: {
          V v_b_2417 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2418 = (g_heff_2ecompile_2einterp_2eintBits_24s1000347599x1204568315(v_a_2412, v_b_2417));
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2418})});
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop(v_a_2412);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_lam1, 2, 1, (V[]){v_a_241})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9, 36, "a primitive given what is not `Bits`");
HEFF_LIT(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10, 36, "a primitive given what is not `Bits`");
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st;
static V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st)) return g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_val, &g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_st, g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_init);
}
V g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  V v_x1_242 = heff_tr(heff_call(v_a_241, 1, (V[]){v_d_240}));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Ok: {
    V v_v_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Ok = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    switch (heff_tag_of(v_v_243)) {
    case TAG_VFun: {
      V v_ru_24v_243_24VFun = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFun, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str0)});
    }
    case TAG_VCons: {
      V v_ru_24v_243_24VCons = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VCons, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str1)});
    }
    case TAG_VTag: {
      heff_take_n(v_v_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str2)});
    }
    case TAG_VInt: {
      V v_ru_24v_243_24VInt = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str3)});
    }
    case TAG_VFloat: {
      V v_ru_24v_243_24VFloat = heff_take_reuse_na(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str4)});
    }
    case TAG_VFloat32: {
      V v_ru_24v_243_24VFloat32 = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VFloat32, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str5)});
    }
    case TAG_VStr: {
      V v_ru_24v_243_24VStr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VStr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str6)});
    }
    case TAG_VRune: {
      V v_ru_24v_243_24VRune = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VRune, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str7)});
    }
    case TAG_VArr: {
      V v_ru_24v_243_24VArr = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VArr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str8)});
    }
    case TAG_VBytes: {
      V v_ru_24v_243_24VBytes = heff_take_reuse_n(v_v_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_at_n(v_ru_24v_243_24VBytes, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str9)});
    }
    case TAG_VBits: {
      V v_n_2415 = heff_field(v_v_243, 0);
      heff_take_n(v_v_243, 1ULL, 2);
      return heff_tag_at_n(v_ru_24x1_242_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_n_2415})});
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_242_24Ok, 1);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_str10)});
    }
    default: return heff_nomatch(v_v_243);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2417 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Bug = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_242_24Bug, TAG_Bug, 1, (V[]){v_what_2417});
  }
  default: return heff_nomatch(v_x1_242);
  }
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str1, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str2, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str3, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str4, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str5, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str6, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str7, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str8, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str9, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str10, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str11, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str12, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str13, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str14, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str15, 9, "onWindows");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str16, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str17, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str18, 6, "intAnd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str19, 5, "intOr");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str20, 6, "intXor");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str21, 6, "intShl");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str22, 6, "intShr");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str23, 8, "floatAdd");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str24, 8, "floatSub");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str25, 8, "floatMul");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str26, 8, "floatDiv");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str27, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str28, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str29, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str30, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str31, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str32, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str33, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str34, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str35, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str36, 9, "floatShow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str37, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str38, 9, "floatSqrt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str39, 10, "floatFloor");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str40, 8, "floatSin");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str41, 8, "floatCos");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str42, 8, "floatTan");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str43, 9, "floatAsin");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str44, 9, "floatAcos");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str45, 9, "floatAtan");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str46, 10, "floatAtan2");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str47, 8, "floatExp");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str48, 8, "floatLog");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str49, 8, "floatPow");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str50, 11, "arrayLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str51, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str52, 32, "an index in range, of no element");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str53, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str54, 13, "arrayGenerate");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str55, 13, "arrayFromList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str56, 11, "arrayToList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str57, 14, "arrayReplicate");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str58, 10, "arraySlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str59, 11, "arrayAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str60, 13, "arrayInsertAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str61, 13, "arrayRemoveAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str62, 9, "arrayPush");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str63, 8, "arrayPop");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str64, 7, "Nothing");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str65, 6, "MkPair");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str66, 4, "Just");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str67, 12, "arrayReserve");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str68, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str69, 9, "strLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str70, 8, "strSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str71, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str72, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str73, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str74, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str75, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str76, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str77, 10, "strCompare");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str78, 7, "strHash");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str79, 7, "intHash");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str80, 8, "trieSlot");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str81, 7, "strFind");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str82, 9, "strByteAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str83, 11, "strFromByte");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str84, 9, "strRuneAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str85, 12, "strRuneWidth");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str86, 12, "strRuneCount");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str87, 7, "strToJS");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str88, 9, "strFromJS");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str89, 11, "bytesLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str90, 7, "bytesAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str91, 10, "bytesSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str92, 11, "bytesAppend");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str93, 11, "bytesConcat");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str94, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str95, 7, "bytesEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str96, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str97, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str98, 13, "bytesFromList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str99, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str100, 11, "bytesToList");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str101, 15, "bytesFromString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str102, 13, "bytesAsString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str103, 13, "bytesToString");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str104, 10, "bytesIntAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str105, 10, "bytesOfInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str106, 10, "bytesHasAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str107, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str108, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str109, 10, "bitsLength");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str110, 9, "bitsIntAt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str111, 9, "bitsOfInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str112, 10, "bitsConcat");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str113, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str114, 9, "bitsSlice");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str115, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str116, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str117, 9, "bitsBytes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str118, 6, "bitsEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str119, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str120, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str121, 9, "floatBits");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str122, 11, "floatOfBits");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str123, 6, "runeEq");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str124, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str125, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str126, 6, "runeLt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str127, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str128, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str129, 6, "runeLe");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str130, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str131, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str132, 9, "runeToInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str133, 4, "keep");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str134, 11, "runeFromInt");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str135, 8, "strRunes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str136, 10, "strOfRunes");
HEFF_LIT(g_heff_2ecompile_2einterp_2eprim_str137, 13, "no primitive ");
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam0, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam1, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam2, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam3, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam4, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam5, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam6, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam7, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam8, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam9, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam10, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam11, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam12, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam13, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam14, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam15, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam16, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam17, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam18, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam19, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam20, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam21, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam22, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam23, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam24, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam25, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam27, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam26, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam29, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam28, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam32, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam31, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam38, 1, 0};
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam36, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam35, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam40, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam39, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam42, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam41, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam44_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam44, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam43, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam47, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam46, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam51, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam50_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam50, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam54_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam54, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam53_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam53, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam58_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam58, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam57_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam57, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam61_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam61, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam60_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam60, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam64_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam64, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam63_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam63, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam66_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam66, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam65_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam65, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam68_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam68, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam69_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam69, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam72_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam72, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam73_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam73, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam74_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam74, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam75_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam75, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam76_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam76, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam77_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam77, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam80_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam80, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam82_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam82, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam84_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam84, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam85_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam85, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam87_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam87, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam89_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam89, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam90_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam90, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam91_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam91, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam92_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam92, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam93_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam93, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam95_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam95, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam98_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam98, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam99_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam99, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam100_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam100, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam101_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam101, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam102_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam102, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam103_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam103, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam104_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam104, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam105_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam105, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam111(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam110(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam109_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam109, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam114(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam113(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam112(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam112_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam112, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam118(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam117(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam116(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam115(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam115_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam115, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam121(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam120(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam119(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam119, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam122(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam122_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam122, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam125(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam124(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam123(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam123, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam126(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam126_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam126, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam127(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam127_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam127, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam129(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam128(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam128_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam128, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam131(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam130(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam130, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam133(V self, V *args);
V g_heff_2ecompile_2einterp_2eprim_lam132(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam132_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam132, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam134(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam134_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam134, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam135(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam135_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam135, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam136(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam136_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam136, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam137(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam137_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam137, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam139(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam139_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam139, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam138(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam138_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam138, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam140(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam140_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam140, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam141(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam141_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam141, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam142(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eprim_lam142_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_lam142, 2, 0};
V g_heff_2ecompile_2einterp_2eprim_lam143(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eprim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eprim_entry, 1, 0};

V g_heff_2ecompile_2einterp_2eprim(V v_p_240) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str0), 2)) {
    heff_drop(v_p_240);
    return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2022969016x1043695010_get());
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str1), 2)) {
      heff_drop(v_p_240);
      return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s2060240473x471699585_get());
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str2), 2)) {
        heff_drop(v_p_240);
        return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s1480614469x1951099139_get());
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str3), 2)) {
          heff_drop(v_p_240);
          HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam0_clo));
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str4), 2)) {
            heff_drop(v_p_240);
            HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam1_clo));
          } else {
            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str5), 2)) {
              heff_drop(v_p_240);
              HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam2_clo));
            } else {
              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str8), 2)) {
                heff_drop(v_p_240);
                HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam3_clo));
              } else {
                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str11), 2)) {
                  heff_drop(v_p_240);
                  HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam4_clo));
                } else {
                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str14), 2)) {
                    heff_drop(v_p_240);
                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam5_clo)});
                  } else {
                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str15), 2)) {
                      heff_drop(v_p_240);
                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam6_clo)});
                    } else {
                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str18), 2)) {
                        heff_drop(v_p_240);
                        return heff_dup(g_heff_2ecompile_2einterp_2eint2_24s464964774x982550490_get());
                      } else {
                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str19), 2)) {
                          heff_drop(v_p_240);
                          HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam7_clo));
                        } else {
                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str20), 2)) {
                            heff_drop(v_p_240);
                            HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam8_clo));
                          } else {
                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str21), 2)) {
                              heff_drop(v_p_240);
                              HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam9_clo));
                            } else {
                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str22), 2)) {
                                heff_drop(v_p_240);
                                HEFF_LAST return g_heff_2ecompile_2einterp_2eint2(((V)&g_heff_2ecompile_2einterp_2eprim_lam10_clo));
                              } else {
                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str23), 2)) {
                                  heff_drop(v_p_240);
                                  return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get());
                                } else {
                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str24), 2)) {
                                    heff_drop(v_p_240);
                                    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s834031176x1239401368_get());
                                  } else {
                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str25), 2)) {
                                      heff_drop(v_p_240);
                                      return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s254405172x571317293_get());
                                    } else {
                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str26), 2)) {
                                        heff_drop(v_p_240);
                                        return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1183788651x1440441955_get());
                                      } else {
                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str27), 2)) {
                                          heff_drop(v_p_240);
                                          HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam11_clo));
                                        } else {
                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str30), 2)) {
                                            heff_drop(v_p_240);
                                            HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam12_clo));
                                          } else {
                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str33), 2)) {
                                              heff_drop(v_p_240);
                                              HEFF_LAST return g_heff_2ecompile_2einterp_2efloat2(((V)&g_heff_2ecompile_2einterp_2eprim_lam13_clo));
                                            } else {
                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str36), 2)) {
                                                heff_drop(v_p_240);
                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam14_clo)});
                                              } else {
                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str37), 2)) {
                                                  heff_drop(v_p_240);
                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam15_clo)});
                                                } else {
                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str38), 2)) {
                                                    heff_drop(v_p_240);
                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam16_clo)});
                                                  } else {
                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str39), 2)) {
                                                      heff_drop(v_p_240);
                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam17_clo)});
                                                    } else {
                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str40), 2)) {
                                                        heff_drop(v_p_240);
                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam18_clo)});
                                                      } else {
                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str41), 2)) {
                                                          heff_drop(v_p_240);
                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam19_clo)});
                                                        } else {
                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str42), 2)) {
                                                            heff_drop(v_p_240);
                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam20_clo)});
                                                          } else {
                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str43), 2)) {
                                                              heff_drop(v_p_240);
                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam21_clo)});
                                                            } else {
                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str44), 2)) {
                                                                heff_drop(v_p_240);
                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam22_clo)});
                                                              } else {
                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str45), 2)) {
                                                                  heff_drop(v_p_240);
                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam23_clo)});
                                                                } else {
                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str46), 2)) {
                                                                    heff_drop(v_p_240);
                                                                    return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1518805128x384666823_get());
                                                                  } else {
                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str47), 2)) {
                                                                      heff_drop(v_p_240);
                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam24_clo)});
                                                                    } else {
                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str48), 2)) {
                                                                        heff_drop(v_p_240);
                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam25_clo)});
                                                                      } else {
                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str49), 2)) {
                                                                          heff_drop(v_p_240);
                                                                          return heff_dup(g_heff_2ecompile_2einterp_2efloat2_24s1593626074x1560539711_get());
                                                                        } else {
                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str50), 2)) {
                                                                            heff_drop(v_p_240);
                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam26_clo)});
                                                                          } else {
                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str51), 2)) {
                                                                              heff_drop(v_p_240);
                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam28_clo)});
                                                                            } else {
                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str53), 2)) {
                                                                                heff_drop(v_p_240);
                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam31_clo)});
                                                                              } else {
                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str54), 2)) {
                                                                                  heff_drop(v_p_240);
                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam35_clo)});
                                                                                } else {
                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str55), 2)) {
                                                                                    heff_drop(v_p_240);
                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam39_clo)});
                                                                                  } else {
                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str56), 2)) {
                                                                                      heff_drop(v_p_240);
                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam41_clo)});
                                                                                    } else {
                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str57), 2)) {
                                                                                        heff_drop(v_p_240);
                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam43_clo)});
                                                                                      } else {
                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str58), 2)) {
                                                                                          heff_drop(v_p_240);
                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam46_clo)});
                                                                                        } else {
                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str59), 2)) {
                                                                                            heff_drop(v_p_240);
                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam50_clo)});
                                                                                          } else {
                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str60), 2)) {
                                                                                              heff_drop(v_p_240);
                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam53_clo)});
                                                                                            } else {
                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str61), 2)) {
                                                                                                heff_drop(v_p_240);
                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam57_clo)});
                                                                                              } else {
                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str62), 2)) {
                                                                                                  heff_drop(v_p_240);
                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam60_clo)});
                                                                                                } else {
                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str63), 2)) {
                                                                                                    heff_drop(v_p_240);
                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam63_clo)});
                                                                                                  } else {
                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str67), 2)) {
                                                                                                      heff_drop(v_p_240);
                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam65_clo)});
                                                                                                    } else {
                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str68), 2)) {
                                                                                                        heff_drop(v_p_240);
                                                                                                        return heff_dup(g_heff_2ecompile_2einterp_2estr2_24s484594154x574200959_get());
                                                                                                      } else {
                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str69), 2)) {
                                                                                                          heff_drop(v_p_240);
                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam68_clo)});
                                                                                                        } else {
                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str70), 2)) {
                                                                                                            heff_drop(v_p_240);
                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam69_clo)});
                                                                                                          } else {
                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str71), 2)) {
                                                                                                              heff_drop(v_p_240);
                                                                                                              HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam72_clo));
                                                                                                            } else {
                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str74), 2)) {
                                                                                                                heff_drop(v_p_240);
                                                                                                                HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam73_clo));
                                                                                                              } else {
                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str77), 2)) {
                                                                                                                  heff_drop(v_p_240);
                                                                                                                  HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam74_clo));
                                                                                                                } else {
                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str78), 2)) {
                                                                                                                    heff_drop(v_p_240);
                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam75_clo)});
                                                                                                                  } else {
                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str79), 2)) {
                                                                                                                      heff_drop(v_p_240);
                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam76_clo)});
                                                                                                                    } else {
                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str80), 2)) {
                                                                                                                        heff_drop(v_p_240);
                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam77_clo)});
                                                                                                                      } else {
                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str81), 2)) {
                                                                                                                          heff_drop(v_p_240);
                                                                                                                          HEFF_LAST return g_heff_2ecompile_2einterp_2estr2(((V)&g_heff_2ecompile_2einterp_2eprim_lam80_clo));
                                                                                                                        } else {
                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str82), 2)) {
                                                                                                                            heff_drop(v_p_240);
                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam82_clo)});
                                                                                                                          } else {
                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str83), 2)) {
                                                                                                                              heff_drop(v_p_240);
                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam84_clo)});
                                                                                                                            } else {
                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str84), 2)) {
                                                                                                                                heff_drop(v_p_240);
                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam85_clo)});
                                                                                                                              } else {
                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str85), 2)) {
                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam87_clo)});
                                                                                                                                } else {
                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str86), 2)) {
                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam89_clo)});
                                                                                                                                  } else {
                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str87), 2)) {
                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam90_clo)});
                                                                                                                                    } else {
                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str88), 2)) {
                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam91_clo)});
                                                                                                                                      } else {
                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str89), 2)) {
                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam92_clo)});
                                                                                                                                        } else {
                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str90), 2)) {
                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam93_clo)});
                                                                                                                                          } else {
                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str91), 2)) {
                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam95_clo)});
                                                                                                                                            } else {
                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str92), 2)) {
                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                return heff_dup(g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get());
                                                                                                                                              } else {
                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str93), 2)) {
                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam98_clo)});
                                                                                                                                                } else {
                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str95), 2)) {
                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                    HEFF_LAST return g_heff_2ecompile_2einterp_2ebytes2(((V)&g_heff_2ecompile_2einterp_2eprim_lam99_clo));
                                                                                                                                                  } else {
                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str98), 2)) {
                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam100_clo)});
                                                                                                                                                    } else {
                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str100), 2)) {
                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam101_clo)});
                                                                                                                                                      } else {
                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str101), 2)) {
                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam102_clo)});
                                                                                                                                                        } else {
                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str102), 2)) {
                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam103_clo)});
                                                                                                                                                          } else {
                                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str103), 2)) {
                                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                                              return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam104_clo)});
                                                                                                                                                            } else {
                                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str104), 2)) {
                                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam105_clo)});
                                                                                                                                                              } else {
                                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str105), 2)) {
                                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam109_clo)});
                                                                                                                                                                } else {
                                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str106), 2)) {
                                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam112_clo)});
                                                                                                                                                                  } else {
                                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str109), 2)) {
                                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                                      return heff_dup(g_heff_2ecompile_2einterp_2ebits1_24s116958137x982445632_get());
                                                                                                                                                                    } else {
                                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str110), 2)) {
                                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                                        HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam115_clo));
                                                                                                                                                                      } else {
                                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str111), 2)) {
                                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                                          return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam119_clo)});
                                                                                                                                                                        } else {
                                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str112), 2)) {
                                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam122_clo)});
                                                                                                                                                                          } else {
                                                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str114), 2)) {
                                                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                                                              HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam123_clo));
                                                                                                                                                                            } else {
                                                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str116), 2)) {
                                                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam126_clo)});
                                                                                                                                                                              } else {
                                                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str117), 2)) {
                                                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                                                  HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam127_clo));
                                                                                                                                                                                } else {
                                                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str118), 2)) {
                                                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                                                    HEFF_LAST return g_heff_2ecompile_2einterp_2ebits1(((V)&g_heff_2ecompile_2einterp_2eprim_lam128_clo));
                                                                                                                                                                                  } else {
                                                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str121), 2)) {
                                                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam130_clo)});
                                                                                                                                                                                    } else {
                                                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str122), 2)) {
                                                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam132_clo)});
                                                                                                                                                                                      } else {
                                                                                                                                                                                        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str123), 2)) {
                                                                                                                                                                                          heff_drop(v_p_240);
                                                                                                                                                                                          HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam134_clo));
                                                                                                                                                                                        } else {
                                                                                                                                                                                          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str126), 2)) {
                                                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                                                            HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam135_clo));
                                                                                                                                                                                          } else {
                                                                                                                                                                                            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str129), 2)) {
                                                                                                                                                                                              heff_drop(v_p_240);
                                                                                                                                                                                              HEFF_LAST return g_heff_2ecompile_2einterp_2erune2(((V)&g_heff_2ecompile_2einterp_2eprim_lam136_clo));
                                                                                                                                                                                            } else {
                                                                                                                                                                                              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str132), 2)) {
                                                                                                                                                                                                heff_drop(v_p_240);
                                                                                                                                                                                                return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam137_clo)});
                                                                                                                                                                                              } else {
                                                                                                                                                                                                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str133), 2)) {
                                                                                                                                                                                                  heff_drop(v_p_240);
                                                                                                                                                                                                  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam138_clo)});
                                                                                                                                                                                                } else {
                                                                                                                                                                                                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str134), 2)) {
                                                                                                                                                                                                    heff_drop(v_p_240);
                                                                                                                                                                                                    return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam140_clo)});
                                                                                                                                                                                                  } else {
                                                                                                                                                                                                    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str135), 2)) {
                                                                                                                                                                                                      heff_drop(v_p_240);
                                                                                                                                                                                                      return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam141_clo)});
                                                                                                                                                                                                    } else {
                                                                                                                                                                                                      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2einterp_2eprim_str136), 2)) {
                                                                                                                                                                                                        heff_drop(v_p_240);
                                                                                                                                                                                                        return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam142_clo)});
                                                                                                                                                                                                      } else {
                                                                                                                                                                                                        HeffT2 v_t_241899 = (g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(v_p_240));
                                                                                                                                                                                                        {
                                                                                                                                                                                                          V v_field_241901 = v_t_241899.f[1];
                                                                                                                                                                                                          int64_t v_tag_241900 = ((int64_t)v_t_241899.f[0]);
                                                                                                                                                                                                          if ((v_tag_241900 == ((int64_t)0ULL))) {
                                                                                                                                                                                                            heff_drop(v_p_240);
                                                                                                                                                                                                            V v_fp_241902 = v_field_241901;
                                                                                                                                                                                                            HEFF_LAST return g_heff_2ecompile_2einterp_2efixedPrimV(v_fp_241902);
                                                                                                                                                                                                          } else {
                                                                                                                                                                                                            heff_drop(v_field_241901);
                                                                                                                                                                                                            return heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam143, 2, 1, (V[]){v_p_240})});
                                                                                                                                                                                                          }
                                                                                                                                                                                                        }
                                                                                                                                                                                                      }
                                                                                                                                                                                                    }
                                                                                                                                                                                                  }
                                                                                                                                                                                                }
                                                                                                                                                                                              }
                                                                                                                                                                                            }
                                                                                                                                                                                          }
                                                                                                                                                                                        }
                                                                                                                                                                                      }
                                                                                                                                                                                    }
                                                                                                                                                                                  }
                                                                                                                                                                                }
                                                                                                                                                                              }
                                                                                                                                                                            }
                                                                                                                                                                          }
                                                                                                                                                                        }
                                                                                                                                                                      }
                                                                                                                                                                    }
                                                                                                                                                                  }
                                                                                                                                                                }
                                                                                                                                                              }
                                                                                                                                                            }
                                                                                                                                                          }
                                                                                                                                                        }
                                                                                                                                                      }
                                                                                                                                                    }
                                                                                                                                                  }
                                                                                                                                                }
                                                                                                                                              }
                                                                                                                                            }
                                                                                                                                          }
                                                                                                                                        }
                                                                                                                                      }
                                                                                                                                    }
                                                                                                                                  }
                                                                                                                                }
                                                                                                                              }
                                                                                                                            }
                                                                                                                          }
                                                                                                                        }
                                                                                                                      }
                                                                                                                    }
                                                                                                                  }
                                                                                                                }
                                                                                                              }
                                                                                                            }
                                                                                                          }
                                                                                                        }
                                                                                                      }
                                                                                                    }
                                                                                                  }
                                                                                                }
                                                                                              }
                                                                                            }
                                                                                          }
                                                                                        }
                                                                                      }
                                                                                    }
                                                                                  }
                                                                                }
                                                                              }
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eprim(a[0]);
}
V g_heff_2ecompile_2einterp_2eprim_lam0(V self, V *args) {
  V v_a_241 = args[0];
  V v_b_242 = args[1];
  if (heff_intEq_c_lent(v_b_242, MK_INT(0LL), 2)) {
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){MK_INT(0LL)})});
  } else {
    V v_t_243 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_241, v_b_242)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_243});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam1(V self, V *args) {
  V v_a_244 = args[0];
  V v_b_245 = args[1];
  if (heff_intEq_c_lent(v_b_245, MK_INT(0LL), 2)) {
    heff_drop(v_b_245);
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_244})});
  } else {
    V v_t_246 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMod(v_a_244, v_b_245)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_246});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam2(V self, V *args) {
  V v_a_247 = args[0];
  V v_b_248 = args[1];
  V v_t_249;
  if (heff_intEq_c(v_a_247, v_b_248)) {
    v_t_249 = ((V)&g_heff_2ecompile_2einterp_2eprim_str6);
  } else {
    v_t_249 = ((V)&g_heff_2ecompile_2einterp_2eprim_str7);
  }
  V v_t_2410 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2410});
}
V g_heff_2ecompile_2einterp_2eprim_lam3(V self, V *args) {
  V v_a_2411 = args[0];
  V v_b_2412 = args[1];
  V v_t_2413;
  if (heff_intLt_c(v_a_2411, v_b_2412)) {
    v_t_2413 = ((V)&g_heff_2ecompile_2einterp_2eprim_str9);
  } else {
    v_t_2413 = ((V)&g_heff_2ecompile_2einterp_2eprim_str10);
  }
  V v_t_2414 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2414});
}
V g_heff_2ecompile_2einterp_2eprim_lam4(V self, V *args) {
  V v_a_2415 = args[0];
  V v_b_2416 = args[1];
  V v_t_2417;
  if (heff_intLe_c(v_a_2415, v_b_2416)) {
    v_t_2417 = ((V)&g_heff_2ecompile_2einterp_2eprim_str12);
  } else {
    v_t_2417 = ((V)&g_heff_2ecompile_2einterp_2eprim_str13);
  }
  V v_t_2418 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2418});
}
V g_heff_2ecompile_2einterp_2eprim_lam5(V self, V *args) {
  V v_d_2419 = args[0];
  V v_a_2420 = args[1];
  V v_x1_2421 = heff_tr(heff_call(v_a_2420, 1, (V[]){v_d_2419}));
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_Ok: {
    V v_v_2422 = heff_field(v_x1_2421, 0);
    V v_ru_24x1_2421_24Ok = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
    switch (heff_tag_of(v_v_2422)) {
    case TAG_VFun: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2422, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_2427 = heff_field(v_v_2422, 0);
      V v_ru_24v_2422_24VInt = heff_take_reuse_n(v_v_2422, 1ULL, 1);
      V v_t_2428 = heff_tag_at_n(v_ru_24v_2422_24VInt, TAG_VStr, 1, (V[]){heff_intShow(v_a_2427)});
      return heff_tag_at_n(v_ru_24x1_2421_24Ok, TAG_Ok, 1, (V[]){v_t_2428});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2422, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_2422);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2437 = heff_field(v_x1_2421, 0);
    V v_ru_24x1_2421_24Bug = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2421_24Bug, TAG_Bug, 1, (V[]){v_what_2437});
  }
  default: return heff_nomatch(v_x1_2421);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam6(V self, V *args) {
  V v_d_2438 = args[0];
  V v_a_2439 = args[1];
  heff_drop(v_d_2438);
  heff_drop(v_a_2439);
  V v_t_2440 = heff_onWindows(NTAG(TAG_MkUnit));
  V v_t_2441;
  if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
    heff_drop(v_t_2440);
    v_t_2441 = ((V)&g_heff_2ecompile_2einterp_2eprim_str16);
  } else {
    heff_drop(v_t_2440);
    v_t_2441 = ((V)&g_heff_2ecompile_2einterp_2eprim_str17);
  }
  V v_t_2442 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2442});
}
V g_heff_2ecompile_2einterp_2eprim_lam7(V self, V *args) {
  V v_a_2443 = args[0];
  V v_b_2444 = args[1];
  V v_t_2445 = (g_heff_2ecompile_2einterp_2eintBits_24s2130672883x1613217130(MK_INT(0LL), MK_INT(1LL), MK_INT(0LL), v_a_2443, v_b_2444));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2445})});
}
V g_heff_2ecompile_2einterp_2eprim_lam8(V self, V *args) {
  V v_a_2446 = args[0];
  V v_b_2447 = args[1];
  V v_t_2448 = (g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(MK_INT(2LL), v_a_2446, v_b_2447));
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2448})});
}
V g_heff_2ecompile_2einterp_2eprim_lam9(V self, V *args) {
  V v_a_2449 = args[0];
  V v_b_2450 = args[1];
  if (heff_intLt_c_lent(v_b_2450, MK_INT(0LL), 2)) {
    V v_k_2451 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2450)));
    V v_t_2452 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2449, v_k_2451)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2452});
  } else {
    V v_k_2453 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2450));
    V v_t_2454 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2449, v_k_2453)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2454});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam10(V self, V *args) {
  V v_a_2455 = args[0];
  V v_b_2456 = args[1];
  if (heff_intLt_c_lent(v_b_2456, MK_INT(0LL), 2)) {
    V v_k_2457 = (g_heff_2eelab_2efixed_2etwoTo(heff_intSub(MK_INT(0LL), v_b_2456)));
    V v_t_2458 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intMul(v_a_2455, v_k_2457)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2458});
  } else {
    V v_k_2459 = (g_heff_2eelab_2efixed_2etwoTo(v_b_2456));
    V v_t_2460 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_2455, v_k_2459)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2460});
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam11(V self, V *args) {
  V v_box_24a_2461 = args[0];
  V v_box_24b_2462 = args[1];
  double v_a_2461 = heff_unbox_f64(v_box_24a_2461);
  double v_b_2462 = heff_unbox_f64(v_box_24b_2462);
  V v_t_2463;
  if ((v_a_2461 == v_b_2462)) {
    v_t_2463 = ((V)&g_heff_2ecompile_2einterp_2eprim_str28);
  } else {
    v_t_2463 = ((V)&g_heff_2ecompile_2einterp_2eprim_str29);
  }
  V v_t_2464 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2463, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2464});
}
V g_heff_2ecompile_2einterp_2eprim_lam12(V self, V *args) {
  V v_box_24a_2465 = args[0];
  V v_box_24b_2466 = args[1];
  double v_a_2465 = heff_unbox_f64(v_box_24a_2465);
  double v_b_2466 = heff_unbox_f64(v_box_24b_2466);
  V v_t_2467;
  if ((v_a_2465 < v_b_2466)) {
    v_t_2467 = ((V)&g_heff_2ecompile_2einterp_2eprim_str31);
  } else {
    v_t_2467 = ((V)&g_heff_2ecompile_2einterp_2eprim_str32);
  }
  V v_t_2468 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2468});
}
V g_heff_2ecompile_2einterp_2eprim_lam13(V self, V *args) {
  V v_box_24a_2469 = args[0];
  V v_box_24b_2470 = args[1];
  double v_a_2469 = heff_unbox_f64(v_box_24a_2469);
  double v_b_2470 = heff_unbox_f64(v_box_24b_2470);
  V v_t_2471;
  if ((v_a_2469 <= v_b_2470)) {
    v_t_2471 = ((V)&g_heff_2ecompile_2einterp_2eprim_str34);
  } else {
    v_t_2471 = ((V)&g_heff_2ecompile_2einterp_2eprim_str35);
  }
  V v_t_2472 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2471, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2472});
}
V g_heff_2ecompile_2einterp_2eprim_lam14(V self, V *args) {
  V v_d_2473 = args[0];
  V v_a_2474 = args[1];
  V v_x1_2475 = heff_tr(heff_call(v_a_2474, 1, (V[]){v_d_2473}));
  switch (heff_tag_of(v_x1_2475)) {
  case TAG_Ok: {
    V v_v_2476 = heff_field(v_x1_2475, 0);
    V v_ru_24x1_2475_24Ok = heff_take_reuse_n(v_x1_2475, 1ULL, 1);
    switch (heff_tag_of(v_v_2476)) {
    case TAG_VFun: {
      heff_take_n(v_v_2476, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2476, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2476, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_2476, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      V v_a_2482 = heff_tget_v(v_v_2476, 0);
      V v_ru_24v_2476_24VFloat = heff_take_reuse_na(v_v_2476, 0ULL, 1);
      V v_t_2483 = heff_tag_at_n(v_ru_24v_2476_24VFloat, TAG_VStr, 1, (V[]){heff_floatShow(v_a_2482)});
      return heff_tag_at_n(v_ru_24x1_2475_24Ok, TAG_Ok, 1, (V[]){v_t_2483});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2476, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2476, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2476, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2476, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2476, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2476, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2475_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_2476);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2491 = heff_field(v_x1_2475, 0);
    V v_ru_24x1_2475_24Bug = heff_take_reuse_n(v_x1_2475, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2475_24Bug, TAG_Bug, 1, (V[]){v_what_2491});
  }
  default: return heff_nomatch(v_x1_2475);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam15(V self, V *args) {
  V v_d_2492 = args[0];
  V v_a_2493 = args[1];
  V v_x1_2494 = heff_tr(heff_call(v_a_2493, 1, (V[]){v_d_2492}));
  switch (heff_tag_of(v_x1_2494)) {
  case TAG_Ok: {
    V v_v_2495 = heff_field(v_x1_2494, 0);
    V v_ru_24x1_2494_24Ok = heff_take_reuse_n(v_x1_2494, 1ULL, 1);
    switch (heff_tag_of(v_v_2495)) {
    case TAG_VFun: {
      heff_take_n(v_v_2495, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_2495, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_2495, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24100 = heff_field(v_v_2495, 0);
      V v_ru_24v_2495_24VInt = heff_take_reuse_n(v_v_2495, 1ULL, 1);
      V v_t_24101 = heff_tag_at_nf(v_ru_24v_2495_24VInt, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(heff_from_int_f64(v_a_24100))});
      return heff_tag_at_n(v_ru_24x1_2494_24Ok, TAG_Ok, 1, (V[]){v_t_24101});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_2495, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_2495, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_2495, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_2495, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_2495, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_2495, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_2495, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_2494_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_2495);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24110 = heff_field(v_x1_2494, 0);
    V v_ru_24x1_2494_24Bug = heff_take_reuse_n(v_x1_2494, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_2494_24Bug, TAG_Bug, 1, (V[]){v_what_24110});
  }
  default: return heff_nomatch(v_x1_2494);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam16(V self, V *args) {
  V v_d_24111 = args[0];
  V v_a_24112 = args[1];
  V v_x1_24113 = heff_tr(heff_call(v_a_24112, 1, (V[]){v_d_24111}));
  switch (heff_tag_of(v_x1_24113)) {
  case TAG_Ok: {
    V v_v_24114 = heff_field(v_x1_24113, 0);
    V v_ru_24x1_24113_24Ok = heff_take_reuse_n(v_x1_24113, 1ULL, 1);
    switch (heff_tag_of(v_v_24114)) {
    case TAG_VFun: {
      heff_take_n(v_v_24114, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24114, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24114, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24114, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24120 = heff_tflat_f64(v_v_24114, 0);
      V v_ru_24v_24114_24VFloat = heff_take_reuse_na(v_v_24114, 0ULL, 1);
      V v_t_24121 = heff_tag_at_nf(v_ru_24v_24114_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(sqrt(v_a_24120))});
      return heff_tag_at_n(v_ru_24x1_24113_24Ok, TAG_Ok, 1, (V[]){v_t_24121});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24114, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24114, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24114, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24114, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24114, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24114, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24113_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24114);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24129 = heff_field(v_x1_24113, 0);
    V v_ru_24x1_24113_24Bug = heff_take_reuse_n(v_x1_24113, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24113_24Bug, TAG_Bug, 1, (V[]){v_what_24129});
  }
  default: return heff_nomatch(v_x1_24113);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam17(V self, V *args) {
  V v_d_24130 = args[0];
  V v_a_24131 = args[1];
  V v_x1_24132 = heff_tr(heff_call(v_a_24131, 1, (V[]){v_d_24130}));
  switch (heff_tag_of(v_x1_24132)) {
  case TAG_Ok: {
    V v_v_24133 = heff_field(v_x1_24132, 0);
    V v_ru_24x1_24132_24Ok = heff_take_reuse_n(v_x1_24132, 1ULL, 1);
    switch (heff_tag_of(v_v_24133)) {
    case TAG_VFun: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24133, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24139 = heff_tflat_f64(v_v_24133, 0);
      V v_ru_24v_24133_24VFloat = heff_take_reuse_na(v_v_24133, 0ULL, 1);
      if (((v_a_24139 - v_a_24139) == (0.0))) {
        V v_t_24140 = heff_tag_at_n(v_ru_24v_24133_24VFloat, TAG_VInt, 1, (V[]){heff_floor_f64(v_a_24139)});
        return heff_tag_at_n(v_ru_24x1_24132_24Ok, TAG_Ok, 1, (V[]){v_t_24140});
      } else {
        heff_drop_cell(v_ru_24v_24133_24VFloat, 1);
        return heff_tag_at_n(v_ru_24x1_24132_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){MK_INT(0LL)})});
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24133, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24133, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24132_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24133);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24148 = heff_field(v_x1_24132, 0);
    V v_ru_24x1_24132_24Bug = heff_take_reuse_n(v_x1_24132, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24132_24Bug, TAG_Bug, 1, (V[]){v_what_24148});
  }
  default: return heff_nomatch(v_x1_24132);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam18(V self, V *args) {
  V v_d_24149 = args[0];
  V v_a_24150 = args[1];
  V v_x1_24151 = heff_tr(heff_call(v_a_24150, 1, (V[]){v_d_24149}));
  switch (heff_tag_of(v_x1_24151)) {
  case TAG_Ok: {
    V v_v_24152 = heff_field(v_x1_24151, 0);
    V v_ru_24x1_24151_24Ok = heff_take_reuse_n(v_x1_24151, 1ULL, 1);
    switch (heff_tag_of(v_v_24152)) {
    case TAG_VFun: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24152, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24158 = heff_tflat_f64(v_v_24152, 0);
      V v_ru_24v_24152_24VFloat = heff_take_reuse_na(v_v_24152, 0ULL, 1);
      V v_t_24159 = heff_tag_at_nf(v_ru_24v_24152_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(sin(v_a_24158))});
      return heff_tag_at_n(v_ru_24x1_24151_24Ok, TAG_Ok, 1, (V[]){v_t_24159});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24152, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24152, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24151_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24152);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24167 = heff_field(v_x1_24151, 0);
    V v_ru_24x1_24151_24Bug = heff_take_reuse_n(v_x1_24151, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24151_24Bug, TAG_Bug, 1, (V[]){v_what_24167});
  }
  default: return heff_nomatch(v_x1_24151);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam19(V self, V *args) {
  V v_d_24168 = args[0];
  V v_a_24169 = args[1];
  V v_x1_24170 = heff_tr(heff_call(v_a_24169, 1, (V[]){v_d_24168}));
  switch (heff_tag_of(v_x1_24170)) {
  case TAG_Ok: {
    V v_v_24171 = heff_field(v_x1_24170, 0);
    V v_ru_24x1_24170_24Ok = heff_take_reuse_n(v_x1_24170, 1ULL, 1);
    switch (heff_tag_of(v_v_24171)) {
    case TAG_VFun: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24171, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24177 = heff_tflat_f64(v_v_24171, 0);
      V v_ru_24v_24171_24VFloat = heff_take_reuse_na(v_v_24171, 0ULL, 1);
      V v_t_24178 = heff_tag_at_nf(v_ru_24v_24171_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(cos(v_a_24177))});
      return heff_tag_at_n(v_ru_24x1_24170_24Ok, TAG_Ok, 1, (V[]){v_t_24178});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24171, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24171);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24186 = heff_field(v_x1_24170, 0);
    V v_ru_24x1_24170_24Bug = heff_take_reuse_n(v_x1_24170, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24170_24Bug, TAG_Bug, 1, (V[]){v_what_24186});
  }
  default: return heff_nomatch(v_x1_24170);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam20(V self, V *args) {
  V v_d_24187 = args[0];
  V v_a_24188 = args[1];
  V v_x1_24189 = heff_tr(heff_call(v_a_24188, 1, (V[]){v_d_24187}));
  switch (heff_tag_of(v_x1_24189)) {
  case TAG_Ok: {
    V v_v_24190 = heff_field(v_x1_24189, 0);
    V v_ru_24x1_24189_24Ok = heff_take_reuse_n(v_x1_24189, 1ULL, 1);
    switch (heff_tag_of(v_v_24190)) {
    case TAG_VFun: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24190, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24196 = heff_tflat_f64(v_v_24190, 0);
      V v_ru_24v_24190_24VFloat = heff_take_reuse_na(v_v_24190, 0ULL, 1);
      V v_t_24197 = heff_tag_at_nf(v_ru_24v_24190_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(tan(v_a_24196))});
      return heff_tag_at_n(v_ru_24x1_24189_24Ok, TAG_Ok, 1, (V[]){v_t_24197});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24190, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24190);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24205 = heff_field(v_x1_24189, 0);
    V v_ru_24x1_24189_24Bug = heff_take_reuse_n(v_x1_24189, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24189_24Bug, TAG_Bug, 1, (V[]){v_what_24205});
  }
  default: return heff_nomatch(v_x1_24189);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam21(V self, V *args) {
  V v_d_24206 = args[0];
  V v_a_24207 = args[1];
  V v_x1_24208 = heff_tr(heff_call(v_a_24207, 1, (V[]){v_d_24206}));
  switch (heff_tag_of(v_x1_24208)) {
  case TAG_Ok: {
    V v_v_24209 = heff_field(v_x1_24208, 0);
    V v_ru_24x1_24208_24Ok = heff_take_reuse_n(v_x1_24208, 1ULL, 1);
    switch (heff_tag_of(v_v_24209)) {
    case TAG_VFun: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24209, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24215 = heff_tflat_f64(v_v_24209, 0);
      V v_ru_24v_24209_24VFloat = heff_take_reuse_na(v_v_24209, 0ULL, 1);
      V v_t_24216 = heff_tag_at_nf(v_ru_24v_24209_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(asin(v_a_24215))});
      return heff_tag_at_n(v_ru_24x1_24208_24Ok, TAG_Ok, 1, (V[]){v_t_24216});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24209, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24209, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24208_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24209);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24224 = heff_field(v_x1_24208, 0);
    V v_ru_24x1_24208_24Bug = heff_take_reuse_n(v_x1_24208, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24208_24Bug, TAG_Bug, 1, (V[]){v_what_24224});
  }
  default: return heff_nomatch(v_x1_24208);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam22(V self, V *args) {
  V v_d_24225 = args[0];
  V v_a_24226 = args[1];
  V v_x1_24227 = heff_tr(heff_call(v_a_24226, 1, (V[]){v_d_24225}));
  switch (heff_tag_of(v_x1_24227)) {
  case TAG_Ok: {
    V v_v_24228 = heff_field(v_x1_24227, 0);
    V v_ru_24x1_24227_24Ok = heff_take_reuse_n(v_x1_24227, 1ULL, 1);
    switch (heff_tag_of(v_v_24228)) {
    case TAG_VFun: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24228, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24234 = heff_tflat_f64(v_v_24228, 0);
      V v_ru_24v_24228_24VFloat = heff_take_reuse_na(v_v_24228, 0ULL, 1);
      V v_t_24235 = heff_tag_at_nf(v_ru_24v_24228_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(acos(v_a_24234))});
      return heff_tag_at_n(v_ru_24x1_24227_24Ok, TAG_Ok, 1, (V[]){v_t_24235});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24228, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24228, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24227_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24228);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24243 = heff_field(v_x1_24227, 0);
    V v_ru_24x1_24227_24Bug = heff_take_reuse_n(v_x1_24227, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24227_24Bug, TAG_Bug, 1, (V[]){v_what_24243});
  }
  default: return heff_nomatch(v_x1_24227);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam23(V self, V *args) {
  V v_d_24244 = args[0];
  V v_a_24245 = args[1];
  V v_x1_24246 = heff_tr(heff_call(v_a_24245, 1, (V[]){v_d_24244}));
  switch (heff_tag_of(v_x1_24246)) {
  case TAG_Ok: {
    V v_v_24247 = heff_field(v_x1_24246, 0);
    V v_ru_24x1_24246_24Ok = heff_take_reuse_n(v_x1_24246, 1ULL, 1);
    switch (heff_tag_of(v_v_24247)) {
    case TAG_VFun: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24247, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24253 = heff_tflat_f64(v_v_24247, 0);
      V v_ru_24v_24247_24VFloat = heff_take_reuse_na(v_v_24247, 0ULL, 1);
      V v_t_24254 = heff_tag_at_nf(v_ru_24v_24247_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(atan(v_a_24253))});
      return heff_tag_at_n(v_ru_24x1_24246_24Ok, TAG_Ok, 1, (V[]){v_t_24254});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24247, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24247, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24246_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24247);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24262 = heff_field(v_x1_24246, 0);
    V v_ru_24x1_24246_24Bug = heff_take_reuse_n(v_x1_24246, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24246_24Bug, TAG_Bug, 1, (V[]){v_what_24262});
  }
  default: return heff_nomatch(v_x1_24246);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam24(V self, V *args) {
  V v_d_24263 = args[0];
  V v_a_24264 = args[1];
  V v_x1_24265 = heff_tr(heff_call(v_a_24264, 1, (V[]){v_d_24263}));
  switch (heff_tag_of(v_x1_24265)) {
  case TAG_Ok: {
    V v_v_24266 = heff_field(v_x1_24265, 0);
    V v_ru_24x1_24265_24Ok = heff_take_reuse_n(v_x1_24265, 1ULL, 1);
    switch (heff_tag_of(v_v_24266)) {
    case TAG_VFun: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24266, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24272 = heff_tflat_f64(v_v_24266, 0);
      V v_ru_24v_24266_24VFloat = heff_take_reuse_na(v_v_24266, 0ULL, 1);
      V v_t_24273 = heff_tag_at_nf(v_ru_24v_24266_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(exp(v_a_24272))});
      return heff_tag_at_n(v_ru_24x1_24265_24Ok, TAG_Ok, 1, (V[]){v_t_24273});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24266, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24266, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24265_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24266);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24281 = heff_field(v_x1_24265, 0);
    V v_ru_24x1_24265_24Bug = heff_take_reuse_n(v_x1_24265, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24265_24Bug, TAG_Bug, 1, (V[]){v_what_24281});
  }
  default: return heff_nomatch(v_x1_24265);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam25(V self, V *args) {
  V v_d_24282 = args[0];
  V v_a_24283 = args[1];
  V v_x1_24284 = heff_tr(heff_call(v_a_24283, 1, (V[]){v_d_24282}));
  switch (heff_tag_of(v_x1_24284)) {
  case TAG_Ok: {
    V v_v_24285 = heff_field(v_x1_24284, 0);
    V v_ru_24x1_24284_24Ok = heff_take_reuse_n(v_x1_24284, 1ULL, 1);
    switch (heff_tag_of(v_v_24285)) {
    case TAG_VFun: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24285, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_24291 = heff_tflat_f64(v_v_24285, 0);
      V v_ru_24v_24285_24VFloat = heff_take_reuse_na(v_v_24285, 0ULL, 1);
      V v_t_24292 = heff_tag_at_nf(v_ru_24v_24285_24VFloat, TAG_VFloat, 1, 1u, (V[]){heff_word_f64(log(v_a_24291))});
      return heff_tag_at_n(v_ru_24x1_24284_24Ok, TAG_Ok, 1, (V[]){v_t_24292});
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24285, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24285, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24284_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_24285);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24300 = heff_field(v_x1_24284, 0);
    V v_ru_24x1_24284_24Bug = heff_take_reuse_n(v_x1_24284, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24284_24Bug, TAG_Bug, 1, (V[]){v_what_24300});
  }
  default: return heff_nomatch(v_x1_24284);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam27(V self, V *args) {
  V v_d_24303 = args[0];
  V v_a_24304 = args[1];
  V v_x1_24305 = heff_tr(heff_call(v_a_24304, 1, (V[]){v_d_24303}));
  switch (heff_tag_of(v_x1_24305)) {
  case TAG_Ok: {
    V v_v_24306 = heff_field(v_x1_24305, 0);
    V v_ru_24x1_24305_24Ok = heff_take_reuse_n(v_x1_24305, 1ULL, 1);
    switch (heff_tag_of(v_v_24306)) {
    case TAG_VFun: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24306, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24316 = heff_field(v_v_24306, 0);
      heff_take_n(v_v_24306, 1ULL, 1);
      V v_t_24317 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_xs_24316); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      return heff_tag_at_n(v_ru_24x1_24305_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24317})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24306, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24306, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24305_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24306);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24321 = heff_field(v_x1_24305, 0);
    V v_ru_24x1_24305_24Bug = heff_take_reuse_n(v_x1_24305, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24305_24Bug, TAG_Bug, 1, (V[]){v_what_24321});
  }
  default: return heff_nomatch(v_x1_24305);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam26(V self, V *args) {
  V v_d_24301 = args[0];
  V v_u_24302 = args[1];
  heff_drop(v_d_24301);
  heff_drop(v_u_24302);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam27_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam30(V self, V *args) {
  V v_d_24338 = args[0];
  V v_a_24339 = args[1];
  V v_xs_24337 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24340 = heff_tr(heff_call(v_a_24339, 1, (V[]){v_d_24338}));
  switch (heff_tag_of(v_x1_24340)) {
  case TAG_Ok: {
    V v_v_24341 = heff_field(v_x1_24340, 0);
    V v_ru_24x1_24340_24Ok = heff_take_reuse_n(v_x1_24340, 1ULL, 1);
    switch (heff_tag_of(v_v_24341)) {
    case TAG_VFun: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24341, 0ULL, 2);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24346 = heff_field(v_v_24341, 0);
      V v_ru_24v_24341_24VInt = heff_take_reuse_n(v_v_24341, 1ULL, 1);
      if ((heff_intLe_c_lent(MK_INT(0LL), v_a_24346, 1) && ({ V v_t_241905 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24337)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; }); int c_ = heff_intLt_c_lent(v_a_24346, v_t_241905, 0); heff_drop(v_t_241905); c_; }))) {
        HeffT2 v_t_24347 = (g_heff_2ecompile_2einterp_2enthV_24cpr(heff_arrayToList(v_xs_24337), v_a_24346));
        {
          V v_field_24349 = v_t_24347.f[1];
          int64_t v_tag_24348 = ((int64_t)v_t_24347.f[0]);
          if ((v_tag_24348 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24v_24341_24VInt, 1);
            V v_v_24350 = v_field_24349;
            return heff_tag_at_n(v_ru_24x1_24340_24Ok, TAG_Ok, 1, (V[]){v_v_24350});
          } else {
            heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
            heff_drop(v_field_24349);
            return heff_tag_at_n(v_ru_24v_24341_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str52)});
          }
        }
      } else {
        heff_drop(v_xs_24337);
        heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
        heff_drop(v_a_24346);
        heff_drop_cell(v_ru_24v_24341_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24341, 0ULL, 1);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24341, 0ULL, 2);
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24337);
      heff_drop_cell(v_ru_24x1_24340_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24341);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24337);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24337);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24359 = heff_field(v_x1_24340, 0);
    V v_ru_24x1_24340_24Bug = heff_take_reuse_n(v_x1_24340, 1ULL, 1);
    heff_drop(v_xs_24337);
    return heff_tag_at_n(v_ru_24x1_24340_24Bug, TAG_Bug, 1, (V[]){v_what_24359});
  }
  default: return heff_nomatch(v_x1_24340);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam29(V self, V *args) {
  V v_d_24324 = args[0];
  V v_a_24325 = args[1];
  V v_x1_24326 = heff_tr(heff_call(v_a_24325, 1, (V[]){v_d_24324}));
  switch (heff_tag_of(v_x1_24326)) {
  case TAG_Ok: {
    V v_v_24327 = heff_field(v_x1_24326, 0);
    V v_ru_24x1_24326_24Ok = heff_take_reuse_n(v_x1_24326, 1ULL, 1);
    switch (heff_tag_of(v_v_24327)) {
    case TAG_VFun: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24327, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24337 = heff_field(v_v_24327, 0);
      heff_take_n(v_v_24327, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24326_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam30, 2, 1, (V[]){v_xs_24337})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24327, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24327, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24326_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24327);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24363 = heff_field(v_x1_24326, 0);
    V v_ru_24x1_24326_24Bug = heff_take_reuse_n(v_x1_24326, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24326_24Bug, TAG_Bug, 1, (V[]){v_what_24363});
  }
  default: return heff_nomatch(v_x1_24326);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam28(V self, V *args) {
  V v_d_24322 = args[0];
  V v_u_24323 = args[1];
  heff_drop(v_d_24322);
  heff_drop(v_u_24323);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam29_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam34(V self, V *args) {
  V v_d_24389 = args[0];
  V v_x_24390 = args[1];
  V v_a_24388 = heff_env(self)[0];
  V v_xs_24379 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24391 = heff_tr(heff_call(v_x_24390, 1, (V[]){v_d_24389}));
  switch (heff_tag_of(v_x1_24391)) {
  case TAG_Ok: {
    V v_v_24392 = heff_field(v_x1_24391, 0);
    V v_ru_24x1_24391_24Ok = heff_take_reuse_n(v_x1_24391, 1ULL, 1);
    if ((heff_intLe_c_lent(MK_INT(0LL), v_a_24388, 1) && ({ V v_t_241906 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_24379)); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; }); int c_ = heff_intLt_c_lent(v_a_24388, v_t_241906, 0); heff_drop(v_t_241906); c_; }))) {
      V v_t_24393 = (g_heff_2ecompile_2einterp_2esetAt(heff_arrayToList(v_xs_24379), v_a_24388, v_v_24392));
      V v_t_24394 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24393)});
      return heff_tag_at_n(v_ru_24x1_24391_24Ok, TAG_Ok, 1, (V[]){v_t_24394});
    } else {
      heff_drop(v_a_24388);
      heff_drop(v_v_24392);
      return heff_tag_at_n(v_ru_24x1_24391_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VArr, 1, (V[]){v_xs_24379})});
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24388);
    heff_drop(v_xs_24379);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24388);
    heff_drop(v_xs_24379);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24395 = heff_field(v_x1_24391, 0);
    V v_ru_24x1_24391_24Bug = heff_take_reuse_n(v_x1_24391, 1ULL, 1);
    heff_drop(v_a_24388);
    heff_drop(v_xs_24379);
    return heff_tag_at_n(v_ru_24x1_24391_24Bug, TAG_Bug, 1, (V[]){v_what_24395});
  }
  default: return heff_nomatch(v_x1_24391);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam33(V self, V *args) {
  V v_d_24380 = args[0];
  V v_a_24381 = args[1];
  V v_xs_24379 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24382 = heff_tr(heff_call(v_a_24381, 1, (V[]){v_d_24380}));
  switch (heff_tag_of(v_x1_24382)) {
  case TAG_Ok: {
    V v_v_24383 = heff_field(v_x1_24382, 0);
    V v_ru_24x1_24382_24Ok = heff_take_reuse_n(v_x1_24382, 1ULL, 1);
    switch (heff_tag_of(v_v_24383)) {
    case TAG_VFun: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24383, 0ULL, 2);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24388 = heff_field(v_v_24383, 0);
      heff_take_n(v_v_24383, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24382_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam34, 2, 2, (V[]){v_a_24388, v_xs_24379})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24383, 0ULL, 1);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24383, 0ULL, 2);
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24379);
      heff_drop_cell(v_ru_24x1_24382_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24383);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24379);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24379);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24404 = heff_field(v_x1_24382, 0);
    V v_ru_24x1_24382_24Bug = heff_take_reuse_n(v_x1_24382, 1ULL, 1);
    heff_drop(v_xs_24379);
    return heff_tag_at_n(v_ru_24x1_24382_24Bug, TAG_Bug, 1, (V[]){v_what_24404});
  }
  default: return heff_nomatch(v_x1_24382);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam32(V self, V *args) {
  V v_d_24366 = args[0];
  V v_a_24367 = args[1];
  V v_x1_24368 = heff_tr(heff_call(v_a_24367, 1, (V[]){v_d_24366}));
  switch (heff_tag_of(v_x1_24368)) {
  case TAG_Ok: {
    V v_v_24369 = heff_field(v_x1_24368, 0);
    V v_ru_24x1_24368_24Ok = heff_take_reuse_n(v_x1_24368, 1ULL, 1);
    switch (heff_tag_of(v_v_24369)) {
    case TAG_VFun: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24369, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24379 = heff_field(v_v_24369, 0);
      heff_take_n(v_v_24369, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24368_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam33, 2, 1, (V[]){v_xs_24379})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24369, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24369, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24368_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24369);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24408 = heff_field(v_x1_24368, 0);
    V v_ru_24x1_24368_24Bug = heff_take_reuse_n(v_x1_24368, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24368_24Bug, TAG_Bug, 1, (V[]){v_what_24408});
  }
  default: return heff_nomatch(v_x1_24368);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam31(V self, V *args) {
  V v_d_24364 = args[0];
  V v_u_24365 = args[1];
  heff_drop(v_d_24364);
  heff_drop(v_u_24365);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam32_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam38(V self, V *args) {
  V v_vs_24424 = args[0];
  V v_t_24425 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_vs_24424)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24425});
}
V g_heff_2ecompile_2einterp_2eprim_lam37(V self, V *args) {
  V v_d_24420 = args[0];
  V v_f_24421 = args[1];
  V v_a_24419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24422 = heff_tr(heff_call(v_f_24421, 1, (V[]){heff_dup(v_d_24420)}));
  switch (heff_tag_of(v_x1_24422)) {
  case TAG_Ok: {
    V v_v_24423 = heff_field(v_x1_24422, 0);
    heff_take_n(v_x1_24422, 1ULL, 1);
    return (g_heff_2ecompile_2einterp_2egenGo(v_d_24420, MK_INT(0LL), v_a_24419, v_v_24423, ((V)&g_heff_2ecompile_2einterp_2eprim_lam38_clo)));
  }
  case TAG_Abn: {
    heff_drop(v_d_24420);
    heff_drop(v_a_24419);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_24420);
    heff_drop(v_a_24419);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24426 = heff_field(v_x1_24422, 0);
    V v_ru_24x1_24422_24Bug = heff_take_reuse_n(v_x1_24422, 1ULL, 1);
    heff_drop(v_d_24420);
    heff_drop(v_a_24419);
    return heff_tag_at_n(v_ru_24x1_24422_24Bug, TAG_Bug, 1, (V[]){v_what_24426});
  }
  default: return heff_nomatch(v_x1_24422);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam36(V self, V *args) {
  V v_d_24411 = args[0];
  V v_a_24412 = args[1];
  V v_x1_24413 = heff_tr(heff_call(v_a_24412, 1, (V[]){v_d_24411}));
  switch (heff_tag_of(v_x1_24413)) {
  case TAG_Ok: {
    V v_v_24414 = heff_field(v_x1_24413, 0);
    V v_ru_24x1_24413_24Ok = heff_take_reuse_n(v_x1_24413, 1ULL, 1);
    switch (heff_tag_of(v_v_24414)) {
    case TAG_VFun: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24414, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24419 = heff_field(v_v_24414, 0);
      heff_take_n(v_v_24414, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24413_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam37, 2, 1, (V[]){v_a_24419})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24414, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24414, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24413_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24414);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24435 = heff_field(v_x1_24413, 0);
    V v_ru_24x1_24413_24Bug = heff_take_reuse_n(v_x1_24413, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24413_24Bug, TAG_Bug, 1, (V[]){v_what_24435});
  }
  default: return heff_nomatch(v_x1_24413);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam35(V self, V *args) {
  V v_d_24409 = args[0];
  V v_u_24410 = args[1];
  heff_drop(v_d_24409);
  heff_drop(v_u_24410);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam36_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam40(V self, V *args) {
  V v_d_24438 = args[0];
  V v_l_24439 = args[1];
  V v_x1_24440 = heff_tr(heff_call(v_l_24439, 1, (V[]){v_d_24438}));
  switch (heff_tag_of(v_x1_24440)) {
  case TAG_Ok: {
    V v_v_24441 = heff_field(v_x1_24440, 0);
    V v_ru_24x1_24440_24Ok = heff_take_reuse_n(v_x1_24440, 1ULL, 1);
    V v_t_24442 = (g_heff_2ecompile_2einterp_2efromListV(v_v_24441, NTAG(TAG_Nil)));
    V v_t_24443 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24442)});
    return heff_tag_at_n(v_ru_24x1_24440_24Ok, TAG_Ok, 1, (V[]){v_t_24443});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24444 = heff_field(v_x1_24440, 0);
    V v_ru_24x1_24440_24Bug = heff_take_reuse_n(v_x1_24440, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24440_24Bug, TAG_Bug, 1, (V[]){v_what_24444});
  }
  default: return heff_nomatch(v_x1_24440);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam39(V self, V *args) {
  V v_d_24436 = args[0];
  V v_u_24437 = args[1];
  heff_drop(v_d_24436);
  heff_drop(v_u_24437);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam40_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam42(V self, V *args) {
  V v_d_24447 = args[0];
  V v_a_24448 = args[1];
  V v_x1_24449 = heff_tr(heff_call(v_a_24448, 1, (V[]){v_d_24447}));
  switch (heff_tag_of(v_x1_24449)) {
  case TAG_Ok: {
    V v_v_24450 = heff_field(v_x1_24449, 0);
    V v_ru_24x1_24449_24Ok = heff_take_reuse_n(v_x1_24449, 1ULL, 1);
    switch (heff_tag_of(v_v_24450)) {
    case TAG_VFun: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24450, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24460 = heff_field(v_v_24450, 0);
      heff_take_n(v_v_24450, 1ULL, 1);
      V v_t_24461 = (g_heff_2ecompile_2einterp_2etoListV(heff_arrayToList(v_xs_24460)));
      return heff_tag_at_n(v_ru_24x1_24449_24Ok, TAG_Ok, 1, (V[]){v_t_24461});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24450, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24450, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24449_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24450);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24465 = heff_field(v_x1_24449, 0);
    V v_ru_24x1_24449_24Bug = heff_take_reuse_n(v_x1_24449, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24449_24Bug, TAG_Bug, 1, (V[]){v_what_24465});
  }
  default: return heff_nomatch(v_x1_24449);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam41(V self, V *args) {
  V v_d_24445 = args[0];
  V v_u_24446 = args[1];
  heff_drop(v_d_24445);
  heff_drop(v_u_24446);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam42_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam45(V self, V *args) {
  V v_d_24477 = args[0];
  V v_x_24478 = args[1];
  V v_a_24476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24479 = heff_tr(heff_call(v_x_24478, 1, (V[]){v_d_24477}));
  switch (heff_tag_of(v_x1_24479)) {
  case TAG_Ok: {
    V v_v_24480 = heff_field(v_x1_24479, 0);
    V v_ru_24x1_24479_24Ok = heff_take_reuse_n(v_x1_24479, 1ULL, 1);
    V v_t_24481 = (g_list_2ereplicate(v_a_24476, v_v_24480));
    V v_t_24482 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24481)});
    return heff_tag_at_n(v_ru_24x1_24479_24Ok, TAG_Ok, 1, (V[]){v_t_24482});
  }
  case TAG_Abn: {
    heff_drop(v_a_24476);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24476);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24483 = heff_field(v_x1_24479, 0);
    V v_ru_24x1_24479_24Bug = heff_take_reuse_n(v_x1_24479, 1ULL, 1);
    heff_drop(v_a_24476);
    return heff_tag_at_n(v_ru_24x1_24479_24Bug, TAG_Bug, 1, (V[]){v_what_24483});
  }
  default: return heff_nomatch(v_x1_24479);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam44(V self, V *args) {
  V v_d_24468 = args[0];
  V v_a_24469 = args[1];
  V v_x1_24470 = heff_tr(heff_call(v_a_24469, 1, (V[]){v_d_24468}));
  switch (heff_tag_of(v_x1_24470)) {
  case TAG_Ok: {
    V v_v_24471 = heff_field(v_x1_24470, 0);
    V v_ru_24x1_24470_24Ok = heff_take_reuse_n(v_x1_24470, 1ULL, 1);
    switch (heff_tag_of(v_v_24471)) {
    case TAG_VFun: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24471, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24476 = heff_field(v_v_24471, 0);
      heff_take_n(v_v_24471, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24470_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam45, 2, 1, (V[]){v_a_24476})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24471, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24471, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24470_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24471);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24492 = heff_field(v_x1_24470, 0);
    V v_ru_24x1_24470_24Bug = heff_take_reuse_n(v_x1_24470, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24470_24Bug, TAG_Bug, 1, (V[]){v_what_24492});
  }
  default: return heff_nomatch(v_x1_24470);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam43(V self, V *args) {
  V v_d_24466 = args[0];
  V v_u_24467 = args[1];
  heff_drop(v_d_24466);
  heff_drop(v_u_24467);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam44_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam49(V self, V *args) {
  V v_d_24518 = args[0];
  V v_a_24519 = args[1];
  V v_xs_24508 = heff_env(self)[0];
  V v_a_24517 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24520 = heff_tr(heff_call(v_a_24519, 1, (V[]){v_d_24518}));
  switch (heff_tag_of(v_x1_24520)) {
  case TAG_Ok: {
    V v_v_24521 = heff_field(v_x1_24520, 0);
    V v_ru_24x1_24520_24Ok = heff_take_reuse_n(v_x1_24520, 1ULL, 1);
    switch (heff_tag_of(v_v_24521)) {
    case TAG_VFun: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24521, 0ULL, 2);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24526 = heff_field(v_v_24521, 0);
      V v_ru_24v_24521_24VInt = heff_take_reuse_n(v_v_24521, 1ULL, 1);
      V v_t_24527 = ({ V b_0 = heff_arrayToList(v_xs_24508); V a_1 = v_a_24517; V a_2 = v_a_24526; V r_ = (g_heff_2ecompile_2einterp_2esliceV(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V v_t_24528 = heff_tag_at_n(v_ru_24v_24521_24VInt, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24527)});
      return heff_tag_at_n(v_ru_24x1_24520_24Ok, TAG_Ok, 1, (V[]){v_t_24528});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24521, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24521, 0ULL, 2);
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24508);
      heff_drop(v_a_24517);
      heff_drop_cell(v_ru_24x1_24520_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24521);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24508);
    heff_drop(v_a_24517);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24508);
    heff_drop(v_a_24517);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24537 = heff_field(v_x1_24520, 0);
    V v_ru_24x1_24520_24Bug = heff_take_reuse_n(v_x1_24520, 1ULL, 1);
    heff_drop(v_xs_24508);
    heff_drop(v_a_24517);
    return heff_tag_at_n(v_ru_24x1_24520_24Bug, TAG_Bug, 1, (V[]){v_what_24537});
  }
  default: return heff_nomatch(v_x1_24520);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam48(V self, V *args) {
  V v_d_24509 = args[0];
  V v_a_24510 = args[1];
  V v_xs_24508 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24511 = heff_tr(heff_call(v_a_24510, 1, (V[]){v_d_24509}));
  switch (heff_tag_of(v_x1_24511)) {
  case TAG_Ok: {
    V v_v_24512 = heff_field(v_x1_24511, 0);
    V v_ru_24x1_24511_24Ok = heff_take_reuse_n(v_x1_24511, 1ULL, 1);
    switch (heff_tag_of(v_v_24512)) {
    case TAG_VFun: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24512, 0ULL, 2);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24517 = heff_field(v_v_24512, 0);
      heff_take_n(v_v_24512, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24511_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam49, 2, 2, (V[]){v_xs_24508, v_a_24517})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24512, 0ULL, 1);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24512, 0ULL, 2);
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24508);
      heff_drop_cell(v_ru_24x1_24511_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24512);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24508);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24508);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24546 = heff_field(v_x1_24511, 0);
    V v_ru_24x1_24511_24Bug = heff_take_reuse_n(v_x1_24511, 1ULL, 1);
    heff_drop(v_xs_24508);
    return heff_tag_at_n(v_ru_24x1_24511_24Bug, TAG_Bug, 1, (V[]){v_what_24546});
  }
  default: return heff_nomatch(v_x1_24511);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam47(V self, V *args) {
  V v_d_24495 = args[0];
  V v_a_24496 = args[1];
  V v_x1_24497 = heff_tr(heff_call(v_a_24496, 1, (V[]){v_d_24495}));
  switch (heff_tag_of(v_x1_24497)) {
  case TAG_Ok: {
    V v_v_24498 = heff_field(v_x1_24497, 0);
    V v_ru_24x1_24497_24Ok = heff_take_reuse_n(v_x1_24497, 1ULL, 1);
    switch (heff_tag_of(v_v_24498)) {
    case TAG_VFun: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24498, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24508 = heff_field(v_v_24498, 0);
      heff_take_n(v_v_24498, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24497_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam48, 2, 1, (V[]){v_xs_24508})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24498, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24498, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24497_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24498);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24550 = heff_field(v_x1_24497, 0);
    V v_ru_24x1_24497_24Bug = heff_take_reuse_n(v_x1_24497, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24497_24Bug, TAG_Bug, 1, (V[]){v_what_24550});
  }
  default: return heff_nomatch(v_x1_24497);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam46(V self, V *args) {
  V v_d_24493 = args[0];
  V v_u_24494 = args[1];
  heff_drop(v_d_24493);
  heff_drop(v_u_24494);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam47_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam52(V self, V *args) {
  V v_d_24567 = args[0];
  V v_a_24568 = args[1];
  V v_xs_24566 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24569 = heff_tr(heff_call(v_a_24568, 1, (V[]){v_d_24567}));
  switch (heff_tag_of(v_x1_24569)) {
  case TAG_Ok: {
    V v_v_24570 = heff_field(v_x1_24569, 0);
    V v_ru_24x1_24569_24Ok = heff_take_reuse_n(v_x1_24569, 1ULL, 1);
    switch (heff_tag_of(v_v_24570)) {
    case TAG_VFun: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24570, 0ULL, 2);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24580 = heff_field(v_v_24570, 0);
      V v_ru_24v_24570_24VArr = heff_take_reuse_n(v_v_24570, 1ULL, 1);
      V v_t_24581 = (g_prelude_2e_2b_2b(heff_arrayToList(v_xs_24566), heff_arrayToList(v_xs_24580)));
      V v_t_24582 = heff_tag_at_n(v_ru_24v_24570_24VArr, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24581)});
      return heff_tag_at_n(v_ru_24x1_24569_24Ok, TAG_Ok, 1, (V[]){v_t_24582});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24570, 0ULL, 1);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24570, 0ULL, 2);
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24566);
      heff_drop_cell(v_ru_24x1_24569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24570);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24566);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24566);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24586 = heff_field(v_x1_24569, 0);
    V v_ru_24x1_24569_24Bug = heff_take_reuse_n(v_x1_24569, 1ULL, 1);
    heff_drop(v_xs_24566);
    return heff_tag_at_n(v_ru_24x1_24569_24Bug, TAG_Bug, 1, (V[]){v_what_24586});
  }
  default: return heff_nomatch(v_x1_24569);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam51(V self, V *args) {
  V v_d_24553 = args[0];
  V v_a_24554 = args[1];
  V v_x1_24555 = heff_tr(heff_call(v_a_24554, 1, (V[]){v_d_24553}));
  switch (heff_tag_of(v_x1_24555)) {
  case TAG_Ok: {
    V v_v_24556 = heff_field(v_x1_24555, 0);
    V v_ru_24x1_24555_24Ok = heff_take_reuse_n(v_x1_24555, 1ULL, 1);
    switch (heff_tag_of(v_v_24556)) {
    case TAG_VFun: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24556, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24566 = heff_field(v_v_24556, 0);
      heff_take_n(v_v_24556, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24555_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam52, 2, 1, (V[]){v_xs_24566})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24556, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24556, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24555_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24556);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24590 = heff_field(v_x1_24555, 0);
    V v_ru_24x1_24555_24Bug = heff_take_reuse_n(v_x1_24555, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24555_24Bug, TAG_Bug, 1, (V[]){v_what_24590});
  }
  default: return heff_nomatch(v_x1_24555);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam50(V self, V *args) {
  V v_d_24551 = args[0];
  V v_u_24552 = args[1];
  heff_drop(v_d_24551);
  heff_drop(v_u_24552);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam51_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam56(V self, V *args) {
  V v_d_24616 = args[0];
  V v_x_24617 = args[1];
  V v_xs_24606 = heff_env(self)[0];
  V v_a_24615 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24618 = heff_tr(heff_call(v_x_24617, 1, (V[]){v_d_24616}));
  switch (heff_tag_of(v_x1_24618)) {
  case TAG_Ok: {
    V v_v_24619 = heff_field(v_x1_24618, 0);
    V v_ru_24x1_24618_24Ok = heff_take_reuse_n(v_x1_24618, 1ULL, 1);
    V v_xs_24620 = heff_arrayToList(v_xs_24606);
    V v_t_24621 = (g_list_2etake(heff_dup(v_a_24615), heff_dup(v_xs_24620)));
    V v_t_24622 = ({ V a_0 = v_a_24615; V a_1 = v_xs_24620; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_xs_24620); r_; });
    V v_t_24623 = (g_prelude_2e_2b_2b(v_t_24621, heff_tag_n(TAG_Cons, 2, (V[]){v_v_24619, v_t_24622})));
    V v_t_24624 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24623)});
    return heff_tag_at_n(v_ru_24x1_24618_24Ok, TAG_Ok, 1, (V[]){v_t_24624});
  }
  case TAG_Abn: {
    heff_drop(v_xs_24606);
    heff_drop(v_a_24615);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24606);
    heff_drop(v_a_24615);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24625 = heff_field(v_x1_24618, 0);
    V v_ru_24x1_24618_24Bug = heff_take_reuse_n(v_x1_24618, 1ULL, 1);
    heff_drop(v_xs_24606);
    heff_drop(v_a_24615);
    return heff_tag_at_n(v_ru_24x1_24618_24Bug, TAG_Bug, 1, (V[]){v_what_24625});
  }
  default: return heff_nomatch(v_x1_24618);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam55(V self, V *args) {
  V v_d_24607 = args[0];
  V v_a_24608 = args[1];
  V v_xs_24606 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24609 = heff_tr(heff_call(v_a_24608, 1, (V[]){v_d_24607}));
  switch (heff_tag_of(v_x1_24609)) {
  case TAG_Ok: {
    V v_v_24610 = heff_field(v_x1_24609, 0);
    V v_ru_24x1_24609_24Ok = heff_take_reuse_n(v_x1_24609, 1ULL, 1);
    switch (heff_tag_of(v_v_24610)) {
    case TAG_VFun: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24610, 0ULL, 2);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24615 = heff_field(v_v_24610, 0);
      heff_take_n(v_v_24610, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24609_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam56, 2, 2, (V[]){v_xs_24606, v_a_24615})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24610, 0ULL, 1);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24610, 0ULL, 2);
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24606);
      heff_drop_cell(v_ru_24x1_24609_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24610);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24606);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24606);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24634 = heff_field(v_x1_24609, 0);
    V v_ru_24x1_24609_24Bug = heff_take_reuse_n(v_x1_24609, 1ULL, 1);
    heff_drop(v_xs_24606);
    return heff_tag_at_n(v_ru_24x1_24609_24Bug, TAG_Bug, 1, (V[]){v_what_24634});
  }
  default: return heff_nomatch(v_x1_24609);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam54(V self, V *args) {
  V v_d_24593 = args[0];
  V v_a_24594 = args[1];
  V v_x1_24595 = heff_tr(heff_call(v_a_24594, 1, (V[]){v_d_24593}));
  switch (heff_tag_of(v_x1_24595)) {
  case TAG_Ok: {
    V v_v_24596 = heff_field(v_x1_24595, 0);
    V v_ru_24x1_24595_24Ok = heff_take_reuse_n(v_x1_24595, 1ULL, 1);
    switch (heff_tag_of(v_v_24596)) {
    case TAG_VFun: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24596, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24606 = heff_field(v_v_24596, 0);
      heff_take_n(v_v_24596, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24595_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam55, 2, 1, (V[]){v_xs_24606})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24596, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24596, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24595_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24596);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24638 = heff_field(v_x1_24595, 0);
    V v_ru_24x1_24595_24Bug = heff_take_reuse_n(v_x1_24595, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24595_24Bug, TAG_Bug, 1, (V[]){v_what_24638});
  }
  default: return heff_nomatch(v_x1_24595);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam53(V self, V *args) {
  V v_d_24591 = args[0];
  V v_u_24592 = args[1];
  heff_drop(v_d_24591);
  heff_drop(v_u_24592);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam54_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam59(V self, V *args) {
  V v_d_24655 = args[0];
  V v_a_24656 = args[1];
  V v_xs_24654 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24657 = heff_tr(heff_call(v_a_24656, 1, (V[]){v_d_24655}));
  switch (heff_tag_of(v_x1_24657)) {
  case TAG_Ok: {
    V v_v_24658 = heff_field(v_x1_24657, 0);
    V v_ru_24x1_24657_24Ok = heff_take_reuse_n(v_x1_24657, 1ULL, 1);
    switch (heff_tag_of(v_v_24658)) {
    case TAG_VFun: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24658, 0ULL, 2);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24663 = heff_field(v_v_24658, 0);
      V v_ru_24v_24658_24VInt = heff_take_reuse_n(v_v_24658, 1ULL, 1);
      V v_xs_24664 = heff_arrayToList(v_xs_24654);
      V v_t_24667;
      if ((heff_intLe_c_lent(MK_INT(0LL), v_a_24663, 1) && ({ V v_t_241907 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_24664)); int c_ = heff_intLt_c_lent(v_a_24663, v_t_241907, 0); heff_drop(v_t_241907); c_; }))) {
        V v_t_24665 = (g_list_2etake(heff_dup(v_a_24663), heff_dup(v_xs_24664)));
        V v_t_24666 = ({ V a_0 = heff_intAdd(v_a_24663, MK_INT(1LL)); V a_1 = v_xs_24664; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_xs_24664); r_; });
        v_t_24667 = (g_prelude_2e_2b_2b(v_t_24665, v_t_24666));
      } else {
        heff_drop(v_a_24663);
        v_t_24667 = v_xs_24664;
      }
      V v_t_24668 = heff_tag_at_n(v_ru_24v_24658_24VInt, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24667)});
      return heff_tag_at_n(v_ru_24x1_24657_24Ok, TAG_Ok, 1, (V[]){v_t_24668});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24658, 0ULL, 1);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24658, 0ULL, 2);
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24654);
      heff_drop_cell(v_ru_24x1_24657_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24658);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24654);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24654);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24677 = heff_field(v_x1_24657, 0);
    V v_ru_24x1_24657_24Bug = heff_take_reuse_n(v_x1_24657, 1ULL, 1);
    heff_drop(v_xs_24654);
    return heff_tag_at_n(v_ru_24x1_24657_24Bug, TAG_Bug, 1, (V[]){v_what_24677});
  }
  default: return heff_nomatch(v_x1_24657);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam58(V self, V *args) {
  V v_d_24641 = args[0];
  V v_a_24642 = args[1];
  V v_x1_24643 = heff_tr(heff_call(v_a_24642, 1, (V[]){v_d_24641}));
  switch (heff_tag_of(v_x1_24643)) {
  case TAG_Ok: {
    V v_v_24644 = heff_field(v_x1_24643, 0);
    V v_ru_24x1_24643_24Ok = heff_take_reuse_n(v_x1_24643, 1ULL, 1);
    switch (heff_tag_of(v_v_24644)) {
    case TAG_VFun: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24644, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24654 = heff_field(v_v_24644, 0);
      heff_take_n(v_v_24644, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24643_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam59, 2, 1, (V[]){v_xs_24654})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24644, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24644, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24643_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24644);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24681 = heff_field(v_x1_24643, 0);
    V v_ru_24x1_24643_24Bug = heff_take_reuse_n(v_x1_24643, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24643_24Bug, TAG_Bug, 1, (V[]){v_what_24681});
  }
  default: return heff_nomatch(v_x1_24643);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam57(V self, V *args) {
  V v_d_24639 = args[0];
  V v_u_24640 = args[1];
  heff_drop(v_d_24639);
  heff_drop(v_u_24640);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam58_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam62(V self, V *args) {
  V v_d_24698 = args[0];
  V v_x_24699 = args[1];
  V v_xs_24697 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24700 = heff_tr(heff_call(v_x_24699, 1, (V[]){v_d_24698}));
  switch (heff_tag_of(v_x1_24700)) {
  case TAG_Ok: {
    V v_v_24701 = heff_field(v_x1_24700, 0);
    V v_ru_24x1_24700_24Ok = heff_take_reuse_n(v_x1_24700, 1ULL, 1);
    V v_t_24702 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_24701, NTAG(TAG_Nil)});
    V v_t_24703 = (g_prelude_2e_2b_2b(heff_arrayToList(v_xs_24697), v_t_24702));
    V v_t_24704 = heff_tag_n(TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24703)});
    return heff_tag_at_n(v_ru_24x1_24700_24Ok, TAG_Ok, 1, (V[]){v_t_24704});
  }
  case TAG_Abn: {
    heff_drop(v_xs_24697);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24697);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24705 = heff_field(v_x1_24700, 0);
    V v_ru_24x1_24700_24Bug = heff_take_reuse_n(v_x1_24700, 1ULL, 1);
    heff_drop(v_xs_24697);
    return heff_tag_at_n(v_ru_24x1_24700_24Bug, TAG_Bug, 1, (V[]){v_what_24705});
  }
  default: return heff_nomatch(v_x1_24700);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam61(V self, V *args) {
  V v_d_24684 = args[0];
  V v_a_24685 = args[1];
  V v_x1_24686 = heff_tr(heff_call(v_a_24685, 1, (V[]){v_d_24684}));
  switch (heff_tag_of(v_x1_24686)) {
  case TAG_Ok: {
    V v_v_24687 = heff_field(v_x1_24686, 0);
    V v_ru_24x1_24686_24Ok = heff_take_reuse_n(v_x1_24686, 1ULL, 1);
    switch (heff_tag_of(v_v_24687)) {
    case TAG_VFun: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24687, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24697 = heff_field(v_v_24687, 0);
      heff_take_n(v_v_24687, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24686_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam62, 2, 1, (V[]){v_xs_24697})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24687, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24687, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24686_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24687);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24709 = heff_field(v_x1_24686, 0);
    V v_ru_24x1_24686_24Bug = heff_take_reuse_n(v_x1_24686, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24686_24Bug, TAG_Bug, 1, (V[]){v_what_24709});
  }
  default: return heff_nomatch(v_x1_24686);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam60(V self, V *args) {
  V v_d_24682 = args[0];
  V v_u_24683 = args[1];
  heff_drop(v_d_24682);
  heff_drop(v_u_24683);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam61_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam64(V self, V *args) {
  V v_d_24712 = args[0];
  V v_a_24713 = args[1];
  V v_x1_24714 = heff_tr(heff_call(v_a_24713, 1, (V[]){v_d_24712}));
  switch (heff_tag_of(v_x1_24714)) {
  case TAG_Ok: {
    V v_v_24715 = heff_field(v_x1_24714, 0);
    V v_ru_24x1_24714_24Ok = heff_take_reuse_n(v_x1_24714, 1ULL, 1);
    switch (heff_tag_of(v_v_24715)) {
    case TAG_VFun: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24715, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24725 = heff_field(v_v_24715, 0);
      V v_ru_24v_24715_24VArr = heff_take_reuse_n(v_v_24715, 1ULL, 1);
      V v_x1_24726 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_arrayToList(v_xs_24725)));
      V v_t_24734;
      switch (heff_tag_of(v_x1_24726)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24v_24715_24VArr, 1);
        v_t_24734 = heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str64), NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        V v_x_24727 = heff_field(v_x1_24726, 0);
        V v_rest_24728 = heff_field(v_x1_24726, 1);
        V v_ru_24x1_24726_24Cons = heff_take_reuse_n(v_x1_24726, 3ULL, 2);
        V v_t_24729 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_24728));
        V v_t_24730 = heff_tag_at_n(v_ru_24v_24715_24VArr, TAG_VArr, 1, (V[]){heff_arrayFromList(v_t_24729)});
        V v_t_24731 = heff_tag_at_n(v_ru_24x1_24726_24Cons, TAG_Cons, 2, (V[]){v_x_24727, NTAG(TAG_Nil)});
        V v_t_24732 = heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str65), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24730, v_t_24731})});
        V v_t_24733 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24732, NTAG(TAG_Nil)});
        v_t_24734 = heff_tag_n(TAG_VTag, 2, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_str66), v_t_24733});
        break;
      }
      default: heff_nomatch(v_x1_24726);
      }
      return heff_tag_at_n(v_ru_24x1_24714_24Ok, TAG_Ok, 1, (V[]){v_t_24734});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24715, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24715, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24714_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24715);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24738 = heff_field(v_x1_24714, 0);
    V v_ru_24x1_24714_24Bug = heff_take_reuse_n(v_x1_24714, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24714_24Bug, TAG_Bug, 1, (V[]){v_what_24738});
  }
  default: return heff_nomatch(v_x1_24714);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam63(V self, V *args) {
  V v_d_24710 = args[0];
  V v_u_24711 = args[1];
  heff_drop(v_d_24710);
  heff_drop(v_u_24711);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam64_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam67(V self, V *args) {
  V v_d_24755 = args[0];
  V v_a_24756 = args[1];
  V v_xs_24754 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24757 = heff_tr(heff_call(v_a_24756, 1, (V[]){v_d_24755}));
  switch (heff_tag_of(v_x1_24757)) {
  case TAG_Ok: {
    V v_v_24758 = heff_field(v_x1_24757, 0);
    V v_ru_24x1_24757_24Ok = heff_take_reuse_n(v_x1_24757, 1ULL, 1);
    switch (heff_tag_of(v_v_24758)) {
    case TAG_VFun: {
      heff_take_n(v_v_24758, 0ULL, 1);
      heff_drop(v_xs_24754);
      heff_drop_cell(v_ru_24x1_24757_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24758, 0ULL, 1);
      heff_drop(v_xs_24754);
      heff_drop_cell(v_ru_24x1_24757_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24758, 0ULL, 2);
      heff_drop(v_xs_24754);
      heff_drop_cell(v_ru_24x1_24757_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24758, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24757_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VArr, 1, (V[]){v_xs_24754})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24758, 0ULL, 1);
      heff_drop(v_xs_24754);
      heff_drop_cell(v_ru_24x1_24757_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24758, 0ULL, 1);
      heff_drop(v_xs_24754);
      heff_drop_cell(v_ru_24x1_24757_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24758, 0ULL, 1);
      heff_drop(v_xs_24754);
      heff_drop_cell(v_ru_24x1_24757_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24758, 0ULL, 1);
      heff_drop(v_xs_24754);
      heff_drop_cell(v_ru_24x1_24757_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24758, 0ULL, 1);
      heff_drop(v_xs_24754);
      heff_drop_cell(v_ru_24x1_24757_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24758, 0ULL, 1);
      heff_drop(v_xs_24754);
      heff_drop_cell(v_ru_24x1_24757_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24758, 0ULL, 2);
      heff_drop(v_xs_24754);
      heff_drop_cell(v_ru_24x1_24757_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_xs_24754);
      heff_drop_cell(v_ru_24x1_24757_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24758);
    }
  }
  case TAG_Abn: {
    heff_drop(v_xs_24754);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_xs_24754);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24772 = heff_field(v_x1_24757, 0);
    V v_ru_24x1_24757_24Bug = heff_take_reuse_n(v_x1_24757, 1ULL, 1);
    heff_drop(v_xs_24754);
    return heff_tag_at_n(v_ru_24x1_24757_24Bug, TAG_Bug, 1, (V[]){v_what_24772});
  }
  default: return heff_nomatch(v_x1_24757);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam66(V self, V *args) {
  V v_d_24741 = args[0];
  V v_a_24742 = args[1];
  V v_x1_24743 = heff_tr(heff_call(v_a_24742, 1, (V[]){v_d_24741}));
  switch (heff_tag_of(v_x1_24743)) {
  case TAG_Ok: {
    V v_v_24744 = heff_field(v_x1_24743, 0);
    V v_ru_24x1_24743_24Ok = heff_take_reuse_n(v_x1_24743, 1ULL, 1);
    switch (heff_tag_of(v_v_24744)) {
    case TAG_VFun: {
      heff_take_n(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24744, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VArr: {
      V v_xs_24754 = heff_field(v_v_24744, 0);
      heff_take_n(v_v_24744, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24743_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam67, 2, 1, (V[]){v_xs_24754})})});
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24744, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24744, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24743_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnArray_get());
    }
    default: return heff_nomatch(v_v_24744);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24776 = heff_field(v_x1_24743, 0);
    V v_ru_24x1_24743_24Bug = heff_take_reuse_n(v_x1_24743, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24743_24Bug, TAG_Bug, 1, (V[]){v_what_24776});
  }
  default: return heff_nomatch(v_x1_24743);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam65(V self, V *args) {
  V v_d_24739 = args[0];
  V v_u_24740 = args[1];
  heff_drop(v_d_24739);
  heff_drop(v_u_24740);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam66_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam68(V self, V *args) {
  V v_d_24777 = args[0];
  V v_a_24778 = args[1];
  V v_x1_24779 = heff_tr(heff_call(v_a_24778, 1, (V[]){v_d_24777}));
  switch (heff_tag_of(v_x1_24779)) {
  case TAG_Ok: {
    V v_v_24780 = heff_field(v_x1_24779, 0);
    V v_ru_24x1_24779_24Ok = heff_take_reuse_n(v_x1_24779, 1ULL, 1);
    switch (heff_tag_of(v_v_24780)) {
    case TAG_VFun: {
      heff_take_n(v_v_24780, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24779_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24780, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24779_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24780, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24779_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24780, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24779_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24780, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24779_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24780, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24779_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24788 = heff_field(v_v_24780, 0);
      V v_ru_24v_24780_24VStr = heff_take_reuse_n(v_v_24780, 1ULL, 1);
      V v_t_24789 = heff_tag_at_n(v_ru_24v_24780_24VStr, TAG_VInt, 1, (V[]){heff_strLength(v_a_24788)});
      return heff_tag_at_n(v_ru_24x1_24779_24Ok, TAG_Ok, 1, (V[]){v_t_24789});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24780, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24779_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24780, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24779_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24780, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24779_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24780, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24779_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24779_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24780);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24795 = heff_field(v_x1_24779, 0);
    V v_ru_24x1_24779_24Bug = heff_take_reuse_n(v_x1_24779, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24779_24Bug, TAG_Bug, 1, (V[]){v_what_24795});
  }
  default: return heff_nomatch(v_x1_24779);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam71(V self, V *args) {
  V v_d_24817 = args[0];
  V v_a_24818 = args[1];
  V v_a_24807 = heff_env(self)[0];
  V v_a_24816 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24819 = heff_tr(heff_call(v_a_24818, 1, (V[]){v_d_24817}));
  switch (heff_tag_of(v_x1_24819)) {
  case TAG_Ok: {
    V v_v_24820 = heff_field(v_x1_24819, 0);
    V v_ru_24x1_24819_24Ok = heff_take_reuse_n(v_x1_24819, 1ULL, 1);
    switch (heff_tag_of(v_v_24820)) {
    case TAG_VFun: {
      heff_take_n(v_v_24820, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop(v_a_24816);
      heff_drop_cell(v_ru_24x1_24819_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24820, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop(v_a_24816);
      heff_drop_cell(v_ru_24x1_24819_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24820, 0ULL, 2);
      heff_drop(v_a_24807);
      heff_drop(v_a_24816);
      heff_drop_cell(v_ru_24x1_24819_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24825 = heff_field(v_v_24820, 0);
      V v_ru_24v_24820_24VInt = heff_take_reuse_n(v_v_24820, 1ULL, 1);
      V v_t_24826 = heff_tag_at_n(v_ru_24v_24820_24VInt, TAG_VStr, 1, (V[]){heff_strSlice(v_a_24807, v_a_24816, v_a_24825)});
      return heff_tag_at_n(v_ru_24x1_24819_24Ok, TAG_Ok, 1, (V[]){v_t_24826});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24820, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop(v_a_24816);
      heff_drop_cell(v_ru_24x1_24819_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24820, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop(v_a_24816);
      heff_drop_cell(v_ru_24x1_24819_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24820, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop(v_a_24816);
      heff_drop_cell(v_ru_24x1_24819_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24820, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop(v_a_24816);
      heff_drop_cell(v_ru_24x1_24819_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24820, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop(v_a_24816);
      heff_drop_cell(v_ru_24x1_24819_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24820, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop(v_a_24816);
      heff_drop_cell(v_ru_24x1_24819_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24820, 0ULL, 2);
      heff_drop(v_a_24807);
      heff_drop(v_a_24816);
      heff_drop_cell(v_ru_24x1_24819_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24807);
      heff_drop(v_a_24816);
      heff_drop_cell(v_ru_24x1_24819_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24820);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24807);
    heff_drop(v_a_24816);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24807);
    heff_drop(v_a_24816);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24835 = heff_field(v_x1_24819, 0);
    V v_ru_24x1_24819_24Bug = heff_take_reuse_n(v_x1_24819, 1ULL, 1);
    heff_drop(v_a_24807);
    heff_drop(v_a_24816);
    return heff_tag_at_n(v_ru_24x1_24819_24Bug, TAG_Bug, 1, (V[]){v_what_24835});
  }
  default: return heff_nomatch(v_x1_24819);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam70(V self, V *args) {
  V v_d_24808 = args[0];
  V v_a_24809 = args[1];
  V v_a_24807 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24810 = heff_tr(heff_call(v_a_24809, 1, (V[]){v_d_24808}));
  switch (heff_tag_of(v_x1_24810)) {
  case TAG_Ok: {
    V v_v_24811 = heff_field(v_x1_24810, 0);
    V v_ru_24x1_24810_24Ok = heff_take_reuse_n(v_x1_24810, 1ULL, 1);
    switch (heff_tag_of(v_v_24811)) {
    case TAG_VFun: {
      heff_take_n(v_v_24811, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop_cell(v_ru_24x1_24810_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24811, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop_cell(v_ru_24x1_24810_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24811, 0ULL, 2);
      heff_drop(v_a_24807);
      heff_drop_cell(v_ru_24x1_24810_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24816 = heff_field(v_v_24811, 0);
      heff_take_n(v_v_24811, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24810_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam71, 2, 2, (V[]){v_a_24807, v_a_24816})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24811, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop_cell(v_ru_24x1_24810_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24811, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop_cell(v_ru_24x1_24810_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24811, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop_cell(v_ru_24x1_24810_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24811, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop_cell(v_ru_24x1_24810_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24811, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop_cell(v_ru_24x1_24810_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24811, 0ULL, 1);
      heff_drop(v_a_24807);
      heff_drop_cell(v_ru_24x1_24810_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24811, 0ULL, 2);
      heff_drop(v_a_24807);
      heff_drop_cell(v_ru_24x1_24810_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24807);
      heff_drop_cell(v_ru_24x1_24810_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24811);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24807);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24807);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24844 = heff_field(v_x1_24810, 0);
    V v_ru_24x1_24810_24Bug = heff_take_reuse_n(v_x1_24810, 1ULL, 1);
    heff_drop(v_a_24807);
    return heff_tag_at_n(v_ru_24x1_24810_24Bug, TAG_Bug, 1, (V[]){v_what_24844});
  }
  default: return heff_nomatch(v_x1_24810);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam69(V self, V *args) {
  V v_d_24796 = args[0];
  V v_a_24797 = args[1];
  V v_x1_24798 = heff_tr(heff_call(v_a_24797, 1, (V[]){v_d_24796}));
  switch (heff_tag_of(v_x1_24798)) {
  case TAG_Ok: {
    V v_v_24799 = heff_field(v_x1_24798, 0);
    V v_ru_24x1_24798_24Ok = heff_take_reuse_n(v_x1_24798, 1ULL, 1);
    switch (heff_tag_of(v_v_24799)) {
    case TAG_VFun: {
      heff_take_n(v_v_24799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24799, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24807 = heff_field(v_v_24799, 0);
      heff_take_n(v_v_24799, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24798_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam70, 2, 1, (V[]){v_a_24807})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24799, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24799, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24798_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24799);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24850 = heff_field(v_x1_24798, 0);
    V v_ru_24x1_24798_24Bug = heff_take_reuse_n(v_x1_24798, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24798_24Bug, TAG_Bug, 1, (V[]){v_what_24850});
  }
  default: return heff_nomatch(v_x1_24798);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam72(V self, V *args) {
  V v_a_24851 = args[0];
  V v_b_24852 = args[1];
  V v_t_24853;
  if (heff_strEq_c(v_a_24851, v_b_24852)) {
    v_t_24853 = ((V)&g_heff_2ecompile_2einterp_2eprim_str72);
  } else {
    v_t_24853 = ((V)&g_heff_2ecompile_2einterp_2eprim_str73);
  }
  V v_t_24854 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24853, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24854});
}
V g_heff_2ecompile_2einterp_2eprim_lam73(V self, V *args) {
  V v_a_24855 = args[0];
  V v_b_24856 = args[1];
  V v_t_24857;
  if (heff_strLt_c(v_a_24855, v_b_24856)) {
    v_t_24857 = ((V)&g_heff_2ecompile_2einterp_2eprim_str75);
  } else {
    v_t_24857 = ((V)&g_heff_2ecompile_2einterp_2eprim_str76);
  }
  V v_t_24858 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_24857, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24858});
}
V g_heff_2ecompile_2einterp_2eprim_lam74(V self, V *args) {
  V v_a_24859 = args[0];
  V v_b_24860 = args[1];
  V v_t_24861;
  if (heff_strLt_c_lent(v_a_24859, v_b_24860, 0)) {
    heff_drop(v_a_24859);
    heff_drop(v_b_24860);
    v_t_24861 = MK_INT(-1LL);
  } else {
    if (heff_strEq_c(v_a_24859, v_b_24860)) {
      v_t_24861 = MK_INT(0LL);
    } else {
      v_t_24861 = MK_INT(1LL);
    }
  }
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24861})});
}
V g_heff_2ecompile_2einterp_2eprim_lam75(V self, V *args) {
  V v_d_24862 = args[0];
  V v_a_24863 = args[1];
  V v_x1_24864 = heff_tr(heff_call(v_a_24863, 1, (V[]){v_d_24862}));
  switch (heff_tag_of(v_x1_24864)) {
  case TAG_Ok: {
    V v_v_24865 = heff_field(v_x1_24864, 0);
    V v_ru_24x1_24864_24Ok = heff_take_reuse_n(v_x1_24864, 1ULL, 1);
    switch (heff_tag_of(v_v_24865)) {
    case TAG_VFun: {
      heff_take_n(v_v_24865, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24864_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24865, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24864_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24865, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24864_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24865, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24864_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24865, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24864_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24865, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24864_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24873 = heff_field(v_v_24865, 0);
      V v_ru_24v_24865_24VStr = heff_take_reuse_n(v_v_24865, 1ULL, 1);
      V v_t_24874 = ({ V a_0 = v_a_24873; V a_1 = MK_INT(0LL); V a_2 = heff_strLength_lent(v_a_24873, 0); V r_ = (g_heff_2ecompile_2einterp_2ehashFrom(a_0, a_1, a_2)); heff_drop(v_a_24873); r_; });
      V v_t_24875 = (g_heff_2ecompile_2einterp_2efmix64(v_t_24874));
      V v_t_24876 = heff_tag_at_n(v_ru_24v_24865_24VStr, TAG_VInt, 1, (V[]){heff_intDiv(v_t_24875, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_24864_24Ok, TAG_Ok, 1, (V[]){v_t_24876});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24865, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24864_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24865, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24864_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24865, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24864_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24865, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24864_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24864_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24865);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24882 = heff_field(v_x1_24864, 0);
    V v_ru_24x1_24864_24Bug = heff_take_reuse_n(v_x1_24864, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24864_24Bug, TAG_Bug, 1, (V[]){v_what_24882});
  }
  default: return heff_nomatch(v_x1_24864);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam76(V self, V *args) {
  V v_d_24883 = args[0];
  V v_a_24884 = args[1];
  V v_x1_24885 = heff_tr(heff_call(v_a_24884, 1, (V[]){v_d_24883}));
  switch (heff_tag_of(v_x1_24885)) {
  case TAG_Ok: {
    V v_v_24886 = heff_field(v_x1_24885, 0);
    V v_ru_24x1_24885_24Ok = heff_take_reuse_n(v_x1_24885, 1ULL, 1);
    switch (heff_tag_of(v_v_24886)) {
    case TAG_VFun: {
      heff_take_n(v_v_24886, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24885_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24886, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24885_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24886, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24885_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24891 = heff_field(v_v_24886, 0);
      V v_ru_24v_24886_24VInt = heff_take_reuse_n(v_v_24886, 1ULL, 1);
      V v_t_24892 = heff_intAdd(heff_intMod(v_a_24891, heff_dup(g_heff_2ecompile_2einterp_2eword64_get())), heff_dup(g_heff_2ecompile_2einterp_2eword64_get()));
      V v_t_24893 = (g_heff_2ecompile_2einterp_2efmix64(heff_intMod(v_t_24892, heff_dup(g_heff_2ecompile_2einterp_2eword64_get()))));
      V v_t_24894 = heff_tag_at_n(v_ru_24v_24886_24VInt, TAG_VInt, 1, (V[]){heff_intDiv(v_t_24893, MK_INT(4LL))});
      return heff_tag_at_n(v_ru_24x1_24885_24Ok, TAG_Ok, 1, (V[]){v_t_24894});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24886, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24885_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24886, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24885_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24886, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24885_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24886, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24885_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24886, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24885_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24886, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24885_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24886, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24885_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24885_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24886);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24903 = heff_field(v_x1_24885, 0);
    V v_ru_24x1_24885_24Bug = heff_take_reuse_n(v_x1_24885, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24885_24Bug, TAG_Bug, 1, (V[]){v_what_24903});
  }
  default: return heff_nomatch(v_x1_24885);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam79(V self, V *args) {
  V v_d_24922 = args[0];
  V v_a_24923 = args[1];
  V v_a_24912 = heff_env(self)[0];
  V v_a_24921 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24924 = heff_tr(heff_call(v_a_24923, 1, (V[]){v_d_24922}));
  switch (heff_tag_of(v_x1_24924)) {
  case TAG_Ok: {
    V v_v_24925 = heff_field(v_x1_24924, 0);
    V v_ru_24x1_24924_24Ok = heff_take_reuse_n(v_x1_24924, 1ULL, 1);
    switch (heff_tag_of(v_v_24925)) {
    case TAG_VFun: {
      heff_take_n(v_v_24925, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop(v_a_24921);
      heff_drop_cell(v_ru_24x1_24924_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24925, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop(v_a_24921);
      heff_drop_cell(v_ru_24x1_24924_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24925, 0ULL, 2);
      heff_drop(v_a_24912);
      heff_drop(v_a_24921);
      heff_drop_cell(v_ru_24x1_24924_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24930 = heff_field(v_v_24925, 0);
      heff_take_n(v_v_24925, 1ULL, 1);
      V v_t_24931 = (g_heff_2ecompile_2einterp_2etrieSlotOf(v_a_24912, v_a_24921, v_a_24930));
      return heff_tag_at_n(v_ru_24x1_24924_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24931})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24925, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop(v_a_24921);
      heff_drop_cell(v_ru_24x1_24924_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24925, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop(v_a_24921);
      heff_drop_cell(v_ru_24x1_24924_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24925, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop(v_a_24921);
      heff_drop_cell(v_ru_24x1_24924_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24925, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop(v_a_24921);
      heff_drop_cell(v_ru_24x1_24924_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24925, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop(v_a_24921);
      heff_drop_cell(v_ru_24x1_24924_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24925, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop(v_a_24921);
      heff_drop_cell(v_ru_24x1_24924_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24925, 0ULL, 2);
      heff_drop(v_a_24912);
      heff_drop(v_a_24921);
      heff_drop_cell(v_ru_24x1_24924_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24912);
      heff_drop(v_a_24921);
      heff_drop_cell(v_ru_24x1_24924_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24925);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24912);
    heff_drop(v_a_24921);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24912);
    heff_drop(v_a_24921);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24940 = heff_field(v_x1_24924, 0);
    V v_ru_24x1_24924_24Bug = heff_take_reuse_n(v_x1_24924, 1ULL, 1);
    heff_drop(v_a_24912);
    heff_drop(v_a_24921);
    return heff_tag_at_n(v_ru_24x1_24924_24Bug, TAG_Bug, 1, (V[]){v_what_24940});
  }
  default: return heff_nomatch(v_x1_24924);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam78(V self, V *args) {
  V v_d_24913 = args[0];
  V v_a_24914 = args[1];
  V v_a_24912 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24915 = heff_tr(heff_call(v_a_24914, 1, (V[]){v_d_24913}));
  switch (heff_tag_of(v_x1_24915)) {
  case TAG_Ok: {
    V v_v_24916 = heff_field(v_x1_24915, 0);
    V v_ru_24x1_24915_24Ok = heff_take_reuse_n(v_x1_24915, 1ULL, 1);
    switch (heff_tag_of(v_v_24916)) {
    case TAG_VFun: {
      heff_take_n(v_v_24916, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24916, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24916, 0ULL, 2);
      heff_drop(v_a_24912);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24921 = heff_field(v_v_24916, 0);
      heff_take_n(v_v_24916, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24915_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam79, 2, 2, (V[]){v_a_24912, v_a_24921})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24916, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24916, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24916, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24916, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24916, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24916, 0ULL, 1);
      heff_drop(v_a_24912);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24916, 0ULL, 2);
      heff_drop(v_a_24912);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24912);
      heff_drop_cell(v_ru_24x1_24915_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24916);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24912);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24912);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24949 = heff_field(v_x1_24915, 0);
    V v_ru_24x1_24915_24Bug = heff_take_reuse_n(v_x1_24915, 1ULL, 1);
    heff_drop(v_a_24912);
    return heff_tag_at_n(v_ru_24x1_24915_24Bug, TAG_Bug, 1, (V[]){v_what_24949});
  }
  default: return heff_nomatch(v_x1_24915);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam77(V self, V *args) {
  V v_d_24904 = args[0];
  V v_a_24905 = args[1];
  V v_x1_24906 = heff_tr(heff_call(v_a_24905, 1, (V[]){v_d_24904}));
  switch (heff_tag_of(v_x1_24906)) {
  case TAG_Ok: {
    V v_v_24907 = heff_field(v_x1_24906, 0);
    V v_ru_24x1_24906_24Ok = heff_take_reuse_n(v_x1_24906, 1ULL, 1);
    switch (heff_tag_of(v_v_24907)) {
    case TAG_VFun: {
      heff_take_n(v_v_24907, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24906_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24907, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24906_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24907, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24906_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24912 = heff_field(v_v_24907, 0);
      heff_take_n(v_v_24907, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24906_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam78, 2, 1, (V[]){v_a_24912})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24907, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24906_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24907, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24906_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24907, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24906_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24907, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24906_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24907, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24906_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24907, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24906_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24907, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24906_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24906_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24907);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24958 = heff_field(v_x1_24906, 0);
    V v_ru_24x1_24906_24Bug = heff_take_reuse_n(v_x1_24906, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24906_24Bug, TAG_Bug, 1, (V[]){v_what_24958});
  }
  default: return heff_nomatch(v_x1_24906);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam81(V self, V *args) {
  V v_d_24961 = args[0];
  V v_a_24962 = args[1];
  V v_n_24959 = heff_env(self)[0];
  V v_a_24960 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24963 = heff_tr(heff_call(v_a_24962, 1, (V[]){v_d_24961}));
  switch (heff_tag_of(v_x1_24963)) {
  case TAG_Ok: {
    V v_v_24964 = heff_field(v_x1_24963, 0);
    V v_ru_24x1_24963_24Ok = heff_take_reuse_n(v_x1_24963, 1ULL, 1);
    switch (heff_tag_of(v_v_24964)) {
    case TAG_VFun: {
      heff_take_n(v_v_24964, 0ULL, 1);
      heff_drop(v_n_24959);
      heff_drop(v_a_24960);
      heff_drop_cell(v_ru_24x1_24963_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24964, 0ULL, 1);
      heff_drop(v_n_24959);
      heff_drop(v_a_24960);
      heff_drop_cell(v_ru_24x1_24963_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24964, 0ULL, 2);
      heff_drop(v_n_24959);
      heff_drop(v_a_24960);
      heff_drop_cell(v_ru_24x1_24963_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_24969 = heff_field(v_v_24964, 0);
      heff_take_n(v_v_24964, 1ULL, 1);
      V v_t_24970;
      if (heff_intLe_c_lent(MK_INT(0LL), v_a_24969, 1)) {
        v_t_24970 = v_a_24969;
      } else {
        heff_drop(v_a_24969);
        v_t_24970 = MK_INT(0LL);
      }
      V v_j_24971 = heff_strFind(v_n_24959, v_a_24960, v_t_24970);
      V v_t_24972;
      if (heff_intLt_c_lent(v_j_24971, MK_INT(0LL), 2)) {
        heff_drop(v_j_24971);
        v_t_24972 = MK_INT(-1LL);
      } else {
        v_t_24972 = v_j_24971;
      }
      return heff_tag_at_n(v_ru_24x1_24963_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_24972})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24964, 0ULL, 1);
      heff_drop(v_n_24959);
      heff_drop(v_a_24960);
      heff_drop_cell(v_ru_24x1_24963_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24964, 0ULL, 1);
      heff_drop(v_n_24959);
      heff_drop(v_a_24960);
      heff_drop_cell(v_ru_24x1_24963_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24964, 0ULL, 1);
      heff_drop(v_n_24959);
      heff_drop(v_a_24960);
      heff_drop_cell(v_ru_24x1_24963_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24964, 0ULL, 1);
      heff_drop(v_n_24959);
      heff_drop(v_a_24960);
      heff_drop_cell(v_ru_24x1_24963_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24964, 0ULL, 1);
      heff_drop(v_n_24959);
      heff_drop(v_a_24960);
      heff_drop_cell(v_ru_24x1_24963_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24964, 0ULL, 1);
      heff_drop(v_n_24959);
      heff_drop(v_a_24960);
      heff_drop_cell(v_ru_24x1_24963_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24964, 0ULL, 2);
      heff_drop(v_n_24959);
      heff_drop(v_a_24960);
      heff_drop_cell(v_ru_24x1_24963_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_n_24959);
      heff_drop(v_a_24960);
      heff_drop_cell(v_ru_24x1_24963_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24964);
    }
  }
  case TAG_Abn: {
    heff_drop(v_n_24959);
    heff_drop(v_a_24960);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_n_24959);
    heff_drop(v_a_24960);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_24981 = heff_field(v_x1_24963, 0);
    V v_ru_24x1_24963_24Bug = heff_take_reuse_n(v_x1_24963, 1ULL, 1);
    heff_drop(v_n_24959);
    heff_drop(v_a_24960);
    return heff_tag_at_n(v_ru_24x1_24963_24Bug, TAG_Bug, 1, (V[]){v_what_24981});
  }
  default: return heff_nomatch(v_x1_24963);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam80(V self, V *args) {
  V v_n_24959 = args[0];
  V v_a_24960 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam81, 2, 2, (V[]){v_n_24959, v_a_24960})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam83(V self, V *args) {
  V v_d_24994 = args[0];
  V v_a_24995 = args[1];
  V v_a_24993 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24996 = heff_tr(heff_call(v_a_24995, 1, (V[]){v_d_24994}));
  switch (heff_tag_of(v_x1_24996)) {
  case TAG_Ok: {
    V v_v_24997 = heff_field(v_x1_24996, 0);
    V v_ru_24x1_24996_24Ok = heff_take_reuse_n(v_x1_24996, 1ULL, 1);
    switch (heff_tag_of(v_v_24997)) {
    case TAG_VFun: {
      heff_take_n(v_v_24997, 0ULL, 1);
      heff_drop(v_a_24993);
      heff_drop_cell(v_ru_24x1_24996_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24997, 0ULL, 1);
      heff_drop(v_a_24993);
      heff_drop_cell(v_ru_24x1_24996_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24997, 0ULL, 2);
      heff_drop(v_a_24993);
      heff_drop_cell(v_ru_24x1_24996_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241002 = heff_field(v_v_24997, 0);
      V v_ru_24v_24997_24VInt = heff_take_reuse_n(v_v_24997, 1ULL, 1);
      V v_t_241003 = heff_tag_at_n(v_ru_24v_24997_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_24993, v_a_241002)});
      return heff_tag_at_n(v_ru_24x1_24996_24Ok, TAG_Ok, 1, (V[]){v_t_241003});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24997, 0ULL, 1);
      heff_drop(v_a_24993);
      heff_drop_cell(v_ru_24x1_24996_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24997, 0ULL, 1);
      heff_drop(v_a_24993);
      heff_drop_cell(v_ru_24x1_24996_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_24997, 0ULL, 1);
      heff_drop(v_a_24993);
      heff_drop_cell(v_ru_24x1_24996_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_24997, 0ULL, 1);
      heff_drop(v_a_24993);
      heff_drop_cell(v_ru_24x1_24996_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24997, 0ULL, 1);
      heff_drop(v_a_24993);
      heff_drop_cell(v_ru_24x1_24996_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24997, 0ULL, 1);
      heff_drop(v_a_24993);
      heff_drop_cell(v_ru_24x1_24996_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24997, 0ULL, 2);
      heff_drop(v_a_24993);
      heff_drop_cell(v_ru_24x1_24996_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_24993);
      heff_drop_cell(v_ru_24x1_24996_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_24997);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_24993);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_24993);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241012 = heff_field(v_x1_24996, 0);
    V v_ru_24x1_24996_24Bug = heff_take_reuse_n(v_x1_24996, 1ULL, 1);
    heff_drop(v_a_24993);
    return heff_tag_at_n(v_ru_24x1_24996_24Bug, TAG_Bug, 1, (V[]){v_what_241012});
  }
  default: return heff_nomatch(v_x1_24996);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam82(V self, V *args) {
  V v_d_24982 = args[0];
  V v_a_24983 = args[1];
  V v_x1_24984 = heff_tr(heff_call(v_a_24983, 1, (V[]){v_d_24982}));
  switch (heff_tag_of(v_x1_24984)) {
  case TAG_Ok: {
    V v_v_24985 = heff_field(v_x1_24984, 0);
    V v_ru_24x1_24984_24Ok = heff_take_reuse_n(v_x1_24984, 1ULL, 1);
    switch (heff_tag_of(v_v_24985)) {
    case TAG_VFun: {
      heff_take_n(v_v_24985, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_24985, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_24985, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_24985, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_24985, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_24985, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_24993 = heff_field(v_v_24985, 0);
      heff_take_n(v_v_24985, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24984_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam83, 2, 1, (V[]){v_a_24993})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_24985, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_24985, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_24985, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_24985, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_24984_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_24985);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241018 = heff_field(v_x1_24984, 0);
    V v_ru_24x1_24984_24Bug = heff_take_reuse_n(v_x1_24984, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_24984_24Bug, TAG_Bug, 1, (V[]){v_what_241018});
  }
  default: return heff_nomatch(v_x1_24984);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam84(V self, V *args) {
  V v_d_241019 = args[0];
  V v_a_241020 = args[1];
  V v_x1_241021 = heff_tr(heff_call(v_a_241020, 1, (V[]){v_d_241019}));
  switch (heff_tag_of(v_x1_241021)) {
  case TAG_Ok: {
    V v_v_241022 = heff_field(v_x1_241021, 0);
    V v_ru_24x1_241021_24Ok = heff_take_reuse_n(v_x1_241021, 1ULL, 1);
    switch (heff_tag_of(v_v_241022)) {
    case TAG_VFun: {
      heff_take_n(v_v_241022, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241022, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241022, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241027 = heff_field(v_v_241022, 0);
      heff_take_n(v_v_241022, 1ULL, 1);
      V v_t_241028 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_a_241027)));
      return heff_tag_at_n(v_ru_24x1_241021_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_241028})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241022, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241022, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241022, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241022, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241022, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241022, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241022, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241021_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241022);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241037 = heff_field(v_x1_241021, 0);
    V v_ru_24x1_241021_24Bug = heff_take_reuse_n(v_x1_241021, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241021_24Bug, TAG_Bug, 1, (V[]){v_what_241037});
  }
  default: return heff_nomatch(v_x1_241021);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam86(V self, V *args) {
  V v_d_241050 = args[0];
  V v_a_241051 = args[1];
  V v_a_241049 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241052 = heff_tr(heff_call(v_a_241051, 1, (V[]){v_d_241050}));
  switch (heff_tag_of(v_x1_241052)) {
  case TAG_Ok: {
    V v_v_241053 = heff_field(v_x1_241052, 0);
    V v_ru_24x1_241052_24Ok = heff_take_reuse_n(v_x1_241052, 1ULL, 1);
    switch (heff_tag_of(v_v_241053)) {
    case TAG_VFun: {
      heff_take_n(v_v_241053, 0ULL, 1);
      heff_drop(v_a_241049);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241053, 0ULL, 1);
      heff_drop(v_a_241049);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241053, 0ULL, 2);
      heff_drop(v_a_241049);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241058 = heff_field(v_v_241053, 0);
      heff_take_n(v_v_241053, 1ULL, 1);
      V v_t_241059 = heff_runeToInt(heff_strRuneAt(v_a_241049, v_a_241058));
      return heff_tag_at_n(v_ru_24x1_241052_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VRune, 1, (V[]){v_t_241059})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241053, 0ULL, 1);
      heff_drop(v_a_241049);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241053, 0ULL, 1);
      heff_drop(v_a_241049);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241053, 0ULL, 1);
      heff_drop(v_a_241049);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241053, 0ULL, 1);
      heff_drop(v_a_241049);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241053, 0ULL, 1);
      heff_drop(v_a_241049);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241053, 0ULL, 1);
      heff_drop(v_a_241049);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241053, 0ULL, 2);
      heff_drop(v_a_241049);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241049);
      heff_drop_cell(v_ru_24x1_241052_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241053);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241049);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241049);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241068 = heff_field(v_x1_241052, 0);
    V v_ru_24x1_241052_24Bug = heff_take_reuse_n(v_x1_241052, 1ULL, 1);
    heff_drop(v_a_241049);
    return heff_tag_at_n(v_ru_24x1_241052_24Bug, TAG_Bug, 1, (V[]){v_what_241068});
  }
  default: return heff_nomatch(v_x1_241052);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam85(V self, V *args) {
  V v_d_241038 = args[0];
  V v_a_241039 = args[1];
  V v_x1_241040 = heff_tr(heff_call(v_a_241039, 1, (V[]){v_d_241038}));
  switch (heff_tag_of(v_x1_241040)) {
  case TAG_Ok: {
    V v_v_241041 = heff_field(v_x1_241040, 0);
    V v_ru_24x1_241040_24Ok = heff_take_reuse_n(v_x1_241040, 1ULL, 1);
    switch (heff_tag_of(v_v_241041)) {
    case TAG_VFun: {
      heff_take_n(v_v_241041, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241041, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241041, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241041, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241041, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241041, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241049 = heff_field(v_v_241041, 0);
      heff_take_n(v_v_241041, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241040_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam86, 2, 1, (V[]){v_a_241049})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241041, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241041, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241041, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241041, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241040_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241041);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241074 = heff_field(v_x1_241040, 0);
    V v_ru_24x1_241040_24Bug = heff_take_reuse_n(v_x1_241040, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241040_24Bug, TAG_Bug, 1, (V[]){v_what_241074});
  }
  default: return heff_nomatch(v_x1_241040);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam88(V self, V *args) {
  V v_d_241087 = args[0];
  V v_a_241088 = args[1];
  V v_a_241086 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241089 = heff_tr(heff_call(v_a_241088, 1, (V[]){v_d_241087}));
  switch (heff_tag_of(v_x1_241089)) {
  case TAG_Ok: {
    V v_v_241090 = heff_field(v_x1_241089, 0);
    V v_ru_24x1_241089_24Ok = heff_take_reuse_n(v_x1_241089, 1ULL, 1);
    switch (heff_tag_of(v_v_241090)) {
    case TAG_VFun: {
      heff_take_n(v_v_241090, 0ULL, 1);
      heff_drop(v_a_241086);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241090, 0ULL, 1);
      heff_drop(v_a_241086);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241090, 0ULL, 2);
      heff_drop(v_a_241086);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241095 = heff_field(v_v_241090, 0);
      V v_ru_24v_241090_24VInt = heff_take_reuse_n(v_v_241090, 1ULL, 1);
      V v_t_241096 = heff_tag_at_n(v_ru_24v_241090_24VInt, TAG_VInt, 1, (V[]){heff_strRuneWidth(v_a_241086, v_a_241095)});
      return heff_tag_at_n(v_ru_24x1_241089_24Ok, TAG_Ok, 1, (V[]){v_t_241096});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241090, 0ULL, 1);
      heff_drop(v_a_241086);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241090, 0ULL, 1);
      heff_drop(v_a_241086);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241090, 0ULL, 1);
      heff_drop(v_a_241086);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241090, 0ULL, 1);
      heff_drop(v_a_241086);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241090, 0ULL, 1);
      heff_drop(v_a_241086);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241090, 0ULL, 1);
      heff_drop(v_a_241086);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241090, 0ULL, 2);
      heff_drop(v_a_241086);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241086);
      heff_drop_cell(v_ru_24x1_241089_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241090);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241086);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241086);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241105 = heff_field(v_x1_241089, 0);
    V v_ru_24x1_241089_24Bug = heff_take_reuse_n(v_x1_241089, 1ULL, 1);
    heff_drop(v_a_241086);
    return heff_tag_at_n(v_ru_24x1_241089_24Bug, TAG_Bug, 1, (V[]){v_what_241105});
  }
  default: return heff_nomatch(v_x1_241089);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam87(V self, V *args) {
  V v_d_241075 = args[0];
  V v_a_241076 = args[1];
  V v_x1_241077 = heff_tr(heff_call(v_a_241076, 1, (V[]){v_d_241075}));
  switch (heff_tag_of(v_x1_241077)) {
  case TAG_Ok: {
    V v_v_241078 = heff_field(v_x1_241077, 0);
    V v_ru_24x1_241077_24Ok = heff_take_reuse_n(v_x1_241077, 1ULL, 1);
    switch (heff_tag_of(v_v_241078)) {
    case TAG_VFun: {
      heff_take_n(v_v_241078, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241077_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241078, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241077_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241078, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241077_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241078, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241077_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241078, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241077_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241078, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241077_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241086 = heff_field(v_v_241078, 0);
      heff_take_n(v_v_241078, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241077_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam88, 2, 1, (V[]){v_a_241086})})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241078, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241077_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241078, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241077_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241078, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241077_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241078, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241077_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241077_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241078);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241111 = heff_field(v_x1_241077, 0);
    V v_ru_24x1_241077_24Bug = heff_take_reuse_n(v_x1_241077, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241077_24Bug, TAG_Bug, 1, (V[]){v_what_241111});
  }
  default: return heff_nomatch(v_x1_241077);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam89(V self, V *args) {
  V v_d_241112 = args[0];
  V v_a_241113 = args[1];
  V v_x1_241114 = heff_tr(heff_call(v_a_241113, 1, (V[]){v_d_241112}));
  switch (heff_tag_of(v_x1_241114)) {
  case TAG_Ok: {
    V v_v_241115 = heff_field(v_x1_241114, 0);
    V v_ru_24x1_241114_24Ok = heff_take_reuse_n(v_x1_241114, 1ULL, 1);
    switch (heff_tag_of(v_v_241115)) {
    case TAG_VFun: {
      heff_take_n(v_v_241115, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241114_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241115, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241114_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241115, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241114_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241115, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241114_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241115, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241114_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241115, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241114_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241123 = heff_field(v_v_241115, 0);
      V v_ru_24v_241115_24VStr = heff_take_reuse_n(v_v_241115, 1ULL, 1);
      V v_t_241124 = heff_tag_at_n(v_ru_24v_241115_24VStr, TAG_VInt, 1, (V[]){heff_strRuneCount(v_a_241123)});
      return heff_tag_at_n(v_ru_24x1_241114_24Ok, TAG_Ok, 1, (V[]){v_t_241124});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241115, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241114_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241115, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241114_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241115, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241114_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241115, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241114_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241114_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241115);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241130 = heff_field(v_x1_241114, 0);
    V v_ru_24x1_241114_24Bug = heff_take_reuse_n(v_x1_241114, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241114_24Bug, TAG_Bug, 1, (V[]){v_what_241130});
  }
  default: return heff_nomatch(v_x1_241114);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam90(V self, V *args) {
  V v_d_241131 = args[0];
  V v_a_241132 = args[1];
  V v_x1_241133 = heff_tr(heff_call(v_a_241132, 1, (V[]){v_d_241131}));
  switch (heff_tag_of(v_x1_241133)) {
  case TAG_Ok: {
    V v_v_241134 = heff_field(v_x1_241133, 0);
    V v_ru_24x1_241133_24Ok = heff_take_reuse_n(v_x1_241133, 1ULL, 1);
    switch (heff_tag_of(v_v_241134)) {
    case TAG_VFun: {
      heff_take_n(v_v_241134, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241133_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241134, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241133_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241134, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241133_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241134, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241133_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241134, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241133_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241134, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241133_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241142 = heff_field(v_v_241134, 0);
      heff_take_n(v_v_241134, 1ULL, 1);
      V v_t_241143 = heff_strOfRunes(heff_strRunes(v_a_241142));
      return heff_tag_at_n(v_ru_24x1_241133_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_241143})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241134, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241133_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241134, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241133_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241134, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241133_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241134, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241133_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241133_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241134);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241149 = heff_field(v_x1_241133, 0);
    V v_ru_24x1_241133_24Bug = heff_take_reuse_n(v_x1_241133, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241133_24Bug, TAG_Bug, 1, (V[]){v_what_241149});
  }
  default: return heff_nomatch(v_x1_241133);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam91(V self, V *args) {
  V v_d_241150 = args[0];
  V v_a_241151 = args[1];
  V v_x1_241152 = heff_tr(heff_call(v_a_241151, 1, (V[]){v_d_241150}));
  switch (heff_tag_of(v_x1_241152)) {
  case TAG_Ok: {
    V v_v_241153 = heff_field(v_x1_241152, 0);
    V v_ru_24x1_241152_24Ok = heff_take_reuse_n(v_x1_241152, 1ULL, 1);
    switch (heff_tag_of(v_v_241153)) {
    case TAG_VFun: {
      heff_take_n(v_v_241153, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241152_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241153, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241152_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241153, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241152_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241153, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241152_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241153, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241152_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241153, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241152_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241161 = heff_field(v_v_241153, 0);
      heff_take_n(v_v_241153, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241152_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_a_241161})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241153, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241152_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241153, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241152_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241153, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241152_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241153, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241152_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241152_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241153);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241167 = heff_field(v_x1_241152, 0);
    V v_ru_24x1_241152_24Bug = heff_take_reuse_n(v_x1_241152, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241152_24Bug, TAG_Bug, 1, (V[]){v_what_241167});
  }
  default: return heff_nomatch(v_x1_241152);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam92(V self, V *args) {
  V v_d_241168 = args[0];
  V v_a_241169 = args[1];
  V v_x1_241170 = heff_tr(heff_call(v_a_241169, 1, (V[]){v_d_241168}));
  switch (heff_tag_of(v_x1_241170)) {
  case TAG_Ok: {
    V v_v_241171 = heff_field(v_x1_241170, 0);
    V v_ru_24x1_241170_24Ok = heff_take_reuse_n(v_x1_241170, 1ULL, 1);
    switch (heff_tag_of(v_v_241171)) {
    case TAG_VFun: {
      heff_take_n(v_v_241171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241171, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241171, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241182 = heff_field(v_v_241171, 0);
      V v_ru_24v_241171_24VBytes = heff_take_reuse_n(v_v_241171, 1ULL, 1);
      V v_t_241183 = heff_tag_at_n(v_ru_24v_241171_24VBytes, TAG_VInt, 1, (V[]){heff_strLength(v_a_241182)});
      return heff_tag_at_n(v_ru_24x1_241170_24Ok, TAG_Ok, 1, (V[]){v_t_241183});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241171, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241170_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241171);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241186 = heff_field(v_x1_241170, 0);
    V v_ru_24x1_241170_24Bug = heff_take_reuse_n(v_x1_241170, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241170_24Bug, TAG_Bug, 1, (V[]){v_what_241186});
  }
  default: return heff_nomatch(v_x1_241170);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam94(V self, V *args) {
  V v_d_241202 = args[0];
  V v_a_241203 = args[1];
  V v_a_241201 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241204 = heff_tr(heff_call(v_a_241203, 1, (V[]){v_d_241202}));
  switch (heff_tag_of(v_x1_241204)) {
  case TAG_Ok: {
    V v_v_241205 = heff_field(v_x1_241204, 0);
    V v_ru_24x1_241204_24Ok = heff_take_reuse_n(v_x1_241204, 1ULL, 1);
    switch (heff_tag_of(v_v_241205)) {
    case TAG_VFun: {
      heff_take_n(v_v_241205, 0ULL, 1);
      heff_drop(v_a_241201);
      heff_drop_cell(v_ru_24x1_241204_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241205, 0ULL, 1);
      heff_drop(v_a_241201);
      heff_drop_cell(v_ru_24x1_241204_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241205, 0ULL, 2);
      heff_drop(v_a_241201);
      heff_drop_cell(v_ru_24x1_241204_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241210 = heff_field(v_v_241205, 0);
      V v_ru_24v_241205_24VInt = heff_take_reuse_n(v_v_241205, 1ULL, 1);
      if ((heff_intLe_c_lent(MK_INT(0LL), v_a_241210, 1) && heff_intLt_c(heff_dup(v_a_241210), heff_strLength_lent(v_a_241201, 0)))) {
        V v_t_241211 = heff_tag_at_n(v_ru_24v_241205_24VInt, TAG_VInt, 1, (V[]){heff_strByteAt(v_a_241201, v_a_241210)});
        return heff_tag_at_n(v_ru_24x1_241204_24Ok, TAG_Ok, 1, (V[]){v_t_241211});
      } else {
        heff_drop(v_a_241201);
        heff_drop_cell(v_ru_24x1_241204_24Ok, 1);
        heff_drop(v_a_241210);
        heff_drop_cell(v_ru_24v_241205_24VInt, 1);
        return NTAG(TAG_Abn);
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241205, 0ULL, 1);
      heff_drop(v_a_241201);
      heff_drop_cell(v_ru_24x1_241204_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241205, 0ULL, 1);
      heff_drop(v_a_241201);
      heff_drop_cell(v_ru_24x1_241204_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241205, 0ULL, 1);
      heff_drop(v_a_241201);
      heff_drop_cell(v_ru_24x1_241204_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241205, 0ULL, 1);
      heff_drop(v_a_241201);
      heff_drop_cell(v_ru_24x1_241204_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241205, 0ULL, 1);
      heff_drop(v_a_241201);
      heff_drop_cell(v_ru_24x1_241204_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241205, 0ULL, 1);
      heff_drop(v_a_241201);
      heff_drop_cell(v_ru_24x1_241204_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241205, 0ULL, 2);
      heff_drop(v_a_241201);
      heff_drop_cell(v_ru_24x1_241204_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241201);
      heff_drop_cell(v_ru_24x1_241204_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241205);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241201);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241201);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241220 = heff_field(v_x1_241204, 0);
    V v_ru_24x1_241204_24Bug = heff_take_reuse_n(v_x1_241204, 1ULL, 1);
    heff_drop(v_a_241201);
    return heff_tag_at_n(v_ru_24x1_241204_24Bug, TAG_Bug, 1, (V[]){v_what_241220});
  }
  default: return heff_nomatch(v_x1_241204);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam93(V self, V *args) {
  V v_d_241187 = args[0];
  V v_a_241188 = args[1];
  V v_x1_241189 = heff_tr(heff_call(v_a_241188, 1, (V[]){v_d_241187}));
  switch (heff_tag_of(v_x1_241189)) {
  case TAG_Ok: {
    V v_v_241190 = heff_field(v_x1_241189, 0);
    V v_ru_24x1_241189_24Ok = heff_take_reuse_n(v_x1_241189, 1ULL, 1);
    switch (heff_tag_of(v_v_241190)) {
    case TAG_VFun: {
      heff_take_n(v_v_241190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241190, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241190, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241201 = heff_field(v_v_241190, 0);
      heff_take_n(v_v_241190, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241189_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam94, 2, 1, (V[]){v_a_241201})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241190, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241189_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241190);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241223 = heff_field(v_x1_241189, 0);
    V v_ru_24x1_241189_24Bug = heff_take_reuse_n(v_x1_241189, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241189_24Bug, TAG_Bug, 1, (V[]){v_what_241223});
  }
  default: return heff_nomatch(v_x1_241189);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam97(V self, V *args) {
  V v_d_241248 = args[0];
  V v_a_241249 = args[1];
  V v_a_241238 = heff_env(self)[0];
  V v_a_241247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241250 = heff_tr(heff_call(v_a_241249, 1, (V[]){v_d_241248}));
  switch (heff_tag_of(v_x1_241250)) {
  case TAG_Ok: {
    V v_v_241251 = heff_field(v_x1_241250, 0);
    V v_ru_24x1_241250_24Ok = heff_take_reuse_n(v_x1_241250, 1ULL, 1);
    switch (heff_tag_of(v_v_241251)) {
    case TAG_VFun: {
      heff_take_n(v_v_241251, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop(v_a_241247);
      heff_drop_cell(v_ru_24x1_241250_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241251, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop(v_a_241247);
      heff_drop_cell(v_ru_24x1_241250_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241251, 0ULL, 2);
      heff_drop(v_a_241238);
      heff_drop(v_a_241247);
      heff_drop_cell(v_ru_24x1_241250_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241256 = heff_field(v_v_241251, 0);
      V v_ru_24v_241251_24VInt = heff_take_reuse_n(v_v_241251, 1ULL, 1);
      V v_t_241257 = heff_tag_at_n(v_ru_24v_241251_24VInt, TAG_VBytes, 1, (V[]){heff_strSlice(v_a_241238, v_a_241247, v_a_241256)});
      return heff_tag_at_n(v_ru_24x1_241250_24Ok, TAG_Ok, 1, (V[]){v_t_241257});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241251, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop(v_a_241247);
      heff_drop_cell(v_ru_24x1_241250_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241251, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop(v_a_241247);
      heff_drop_cell(v_ru_24x1_241250_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241251, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop(v_a_241247);
      heff_drop_cell(v_ru_24x1_241250_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241251, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop(v_a_241247);
      heff_drop_cell(v_ru_24x1_241250_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241251, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop(v_a_241247);
      heff_drop_cell(v_ru_24x1_241250_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241251, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop(v_a_241247);
      heff_drop_cell(v_ru_24x1_241250_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241251, 0ULL, 2);
      heff_drop(v_a_241238);
      heff_drop(v_a_241247);
      heff_drop_cell(v_ru_24x1_241250_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241238);
      heff_drop(v_a_241247);
      heff_drop_cell(v_ru_24x1_241250_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241251);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241238);
    heff_drop(v_a_241247);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241238);
    heff_drop(v_a_241247);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241266 = heff_field(v_x1_241250, 0);
    V v_ru_24x1_241250_24Bug = heff_take_reuse_n(v_x1_241250, 1ULL, 1);
    heff_drop(v_a_241238);
    heff_drop(v_a_241247);
    return heff_tag_at_n(v_ru_24x1_241250_24Bug, TAG_Bug, 1, (V[]){v_what_241266});
  }
  default: return heff_nomatch(v_x1_241250);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam96(V self, V *args) {
  V v_d_241239 = args[0];
  V v_a_241240 = args[1];
  V v_a_241238 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241241 = heff_tr(heff_call(v_a_241240, 1, (V[]){v_d_241239}));
  switch (heff_tag_of(v_x1_241241)) {
  case TAG_Ok: {
    V v_v_241242 = heff_field(v_x1_241241, 0);
    V v_ru_24x1_241241_24Ok = heff_take_reuse_n(v_x1_241241, 1ULL, 1);
    switch (heff_tag_of(v_v_241242)) {
    case TAG_VFun: {
      heff_take_n(v_v_241242, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop_cell(v_ru_24x1_241241_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241242, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop_cell(v_ru_24x1_241241_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241242, 0ULL, 2);
      heff_drop(v_a_241238);
      heff_drop_cell(v_ru_24x1_241241_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241247 = heff_field(v_v_241242, 0);
      heff_take_n(v_v_241242, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241241_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam97, 2, 2, (V[]){v_a_241238, v_a_241247})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241242, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop_cell(v_ru_24x1_241241_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241242, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop_cell(v_ru_24x1_241241_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241242, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop_cell(v_ru_24x1_241241_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241242, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop_cell(v_ru_24x1_241241_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241242, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop_cell(v_ru_24x1_241241_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241242, 0ULL, 1);
      heff_drop(v_a_241238);
      heff_drop_cell(v_ru_24x1_241241_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241242, 0ULL, 2);
      heff_drop(v_a_241238);
      heff_drop_cell(v_ru_24x1_241241_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241238);
      heff_drop_cell(v_ru_24x1_241241_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241242);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241238);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241238);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241275 = heff_field(v_x1_241241, 0);
    V v_ru_24x1_241241_24Bug = heff_take_reuse_n(v_x1_241241, 1ULL, 1);
    heff_drop(v_a_241238);
    return heff_tag_at_n(v_ru_24x1_241241_24Bug, TAG_Bug, 1, (V[]){v_what_241275});
  }
  default: return heff_nomatch(v_x1_241241);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam95(V self, V *args) {
  V v_d_241224 = args[0];
  V v_a_241225 = args[1];
  V v_x1_241226 = heff_tr(heff_call(v_a_241225, 1, (V[]){v_d_241224}));
  switch (heff_tag_of(v_x1_241226)) {
  case TAG_Ok: {
    V v_v_241227 = heff_field(v_x1_241226, 0);
    V v_ru_24x1_241226_24Ok = heff_take_reuse_n(v_x1_241226, 1ULL, 1);
    switch (heff_tag_of(v_v_241227)) {
    case TAG_VFun: {
      heff_take_n(v_v_241227, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241226_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241227, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241226_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241227, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241226_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241227, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241226_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241227, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241226_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241227, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241226_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241227, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241226_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241227, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241226_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241227, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241226_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241238 = heff_field(v_v_241227, 0);
      heff_take_n(v_v_241227, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241226_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam96, 2, 1, (V[]){v_a_241238})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241227, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241226_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241226_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241227);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241278 = heff_field(v_x1_241226, 0);
    V v_ru_24x1_241226_24Bug = heff_take_reuse_n(v_x1_241226, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241226_24Bug, TAG_Bug, 1, (V[]){v_what_241278});
  }
  default: return heff_nomatch(v_x1_241226);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam98(V self, V *args) {
  V v_d_241279 = args[0];
  V v_l_241280 = args[1];
  V v_x1_241281 = heff_tr(heff_call(v_l_241280, 1, (V[]){v_d_241279}));
  switch (heff_tag_of(v_x1_241281)) {
  case TAG_Ok: {
    V v_v_241282 = heff_field(v_x1_241281, 0);
    heff_take_n(v_x1_241281, 1ULL, 1);
    V v_t_241283 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241282, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_241283; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str94); V r_ = (g_heff_2ecompile_2einterp_2ebytesJoined(a_0, a_1)); heff_drop(v_t_241283); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241284 = heff_field(v_x1_241281, 0);
    V v_ru_24x1_241281_24Bug = heff_take_reuse_n(v_x1_241281, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241281_24Bug, TAG_Bug, 1, (V[]){v_what_241284});
  }
  default: return heff_nomatch(v_x1_241281);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam99(V self, V *args) {
  V v_a_241285 = args[0];
  V v_b_241286 = args[1];
  V v_t_241287;
  if (heff_strEq_c(v_a_241285, v_b_241286)) {
    v_t_241287 = ((V)&g_heff_2ecompile_2einterp_2eprim_str96);
  } else {
    v_t_241287 = ((V)&g_heff_2ecompile_2einterp_2eprim_str97);
  }
  V v_t_241288 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241287, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241288});
}
V g_heff_2ecompile_2einterp_2eprim_lam100(V self, V *args) {
  V v_d_241289 = args[0];
  V v_l_241290 = args[1];
  V v_x1_241291 = heff_tr(heff_call(v_l_241290, 1, (V[]){v_d_241289}));
  switch (heff_tag_of(v_x1_241291)) {
  case TAG_Ok: {
    V v_v_241292 = heff_field(v_x1_241291, 0);
    V v_ru_24x1_241291_24Ok = heff_take_reuse_n(v_x1_241291, 1ULL, 1);
    V v_t_241293 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241292, NTAG(TAG_Nil)));
    V v_t_241294 = ({ V a_0 = v_t_241293; V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str99); V r_ = (g_heff_2ecompile_2einterp_2ebyteString(a_0, a_1)); heff_drop(v_t_241293); r_; });
    return heff_tag_at_n(v_ru_24x1_241291_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_t_241294})});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241295 = heff_field(v_x1_241291, 0);
    V v_ru_24x1_241291_24Bug = heff_take_reuse_n(v_x1_241291, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241291_24Bug, TAG_Bug, 1, (V[]){v_what_241295});
  }
  default: return heff_nomatch(v_x1_241291);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam101(V self, V *args) {
  V v_d_241296 = args[0];
  V v_a_241297 = args[1];
  V v_x1_241298 = heff_tr(heff_call(v_a_241297, 1, (V[]){v_d_241296}));
  switch (heff_tag_of(v_x1_241298)) {
  case TAG_Ok: {
    V v_v_241299 = heff_field(v_x1_241298, 0);
    V v_ru_24x1_241298_24Ok = heff_take_reuse_n(v_x1_241298, 1ULL, 1);
    switch (heff_tag_of(v_v_241299)) {
    case TAG_VFun: {
      heff_take_n(v_v_241299, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241299, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241299, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241299, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241299, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241299, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241299, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241299, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241299, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241310 = heff_field(v_v_241299, 0);
      heff_take_n(v_v_241299, 1ULL, 1);
      int64_t v_t_241311 = (heff_unbox_word(heff_strLength_lent(v_a_241310, 0)) - ((int64_t)1ULL));
      V v_t_241312 = ({ V a_0 = v_a_241310; V a_1 = MK_INT(0LL); V a_2 = heff_box_word(v_t_241311); V r_ = (g_heff_2ecompile_2einterp_2etoListV_24f1499118663x2031947227(a_0, a_1, a_2)); heff_drop(v_a_241310); r_; });
      return heff_tag_at_n(v_ru_24x1_241298_24Ok, TAG_Ok, 1, (V[]){v_t_241312});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241299, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241298_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241299);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241315 = heff_field(v_x1_241298, 0);
    V v_ru_24x1_241298_24Bug = heff_take_reuse_n(v_x1_241298, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241298_24Bug, TAG_Bug, 1, (V[]){v_what_241315});
  }
  default: return heff_nomatch(v_x1_241298);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam102(V self, V *args) {
  V v_d_241316 = args[0];
  V v_a_241317 = args[1];
  V v_x1_241318 = heff_tr(heff_call(v_a_241317, 1, (V[]){v_d_241316}));
  switch (heff_tag_of(v_x1_241318)) {
  case TAG_Ok: {
    V v_v_241319 = heff_field(v_x1_241318, 0);
    V v_ru_24x1_241318_24Ok = heff_take_reuse_n(v_x1_241318, 1ULL, 1);
    switch (heff_tag_of(v_v_241319)) {
    case TAG_VFun: {
      heff_take_n(v_v_241319, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241318_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241319, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241318_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241319, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241318_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241319, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241318_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241319, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241318_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241319, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241318_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241327 = heff_field(v_v_241319, 0);
      heff_take_n(v_v_241319, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241318_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_a_241327})});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241319, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241318_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241319, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241318_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241319, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241318_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241319, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241318_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241318_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241319);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241333 = heff_field(v_x1_241318, 0);
    V v_ru_24x1_241318_24Bug = heff_take_reuse_n(v_x1_241318, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241318_24Bug, TAG_Bug, 1, (V[]){v_what_241333});
  }
  default: return heff_nomatch(v_x1_241318);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam103(V self, V *args) {
  V v_d_241334 = args[0];
  V v_a_241335 = args[1];
  V v_x1_241336 = heff_tr(heff_call(v_a_241335, 1, (V[]){v_d_241334}));
  switch (heff_tag_of(v_x1_241336)) {
  case TAG_Ok: {
    V v_v_241337 = heff_field(v_x1_241336, 0);
    V v_ru_24x1_241336_24Ok = heff_take_reuse_n(v_x1_241336, 1ULL, 1);
    switch (heff_tag_of(v_v_241337)) {
    case TAG_VFun: {
      heff_take_n(v_v_241337, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241336_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241337, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241336_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241337, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241336_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241337, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241336_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241337, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241336_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241337, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241336_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241337, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241336_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241337, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241336_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241337, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241336_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241348 = heff_field(v_v_241337, 0);
      heff_take_n(v_v_241337, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241336_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_a_241348})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241337, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241336_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241336_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241337);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241351 = heff_field(v_x1_241336, 0);
    V v_ru_24x1_241336_24Bug = heff_take_reuse_n(v_x1_241336, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241336_24Bug, TAG_Bug, 1, (V[]){v_what_241351});
  }
  default: return heff_nomatch(v_x1_241336);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam104(V self, V *args) {
  V v_d_241352 = args[0];
  V v_a_241353 = args[1];
  V v_x1_241354 = heff_tr(heff_call(v_a_241353, 1, (V[]){v_d_241352}));
  switch (heff_tag_of(v_x1_241354)) {
  case TAG_Ok: {
    V v_v_241355 = heff_field(v_x1_241354, 0);
    V v_ru_24x1_241354_24Ok = heff_take_reuse_n(v_x1_241354, 1ULL, 1);
    switch (heff_tag_of(v_v_241355)) {
    case TAG_VFun: {
      heff_take_n(v_v_241355, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241354_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241355, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241354_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241355, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241354_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241355, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241354_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241355, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241354_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241355, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241354_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241355, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241354_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241355, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241354_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241355, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241354_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241366 = heff_field(v_v_241355, 0);
      heff_take_n(v_v_241355, 1ULL, 1);
      V v_t_241367 = (g_rune_2evalidFrom(v_a_241366, MK_INT(0LL)));
      V v_t_241368;
      if ((heff_dup(v_t_241367) == NTAG(TAG_True))) {
        heff_drop(v_t_241367);
        v_t_241368 = v_a_241366;
      } else {
        heff_drop(v_t_241367);
        v_t_241368 = heff_strOfRunes(heff_strRunes(v_a_241366));
      }
      return heff_tag_at_n(v_ru_24x1_241354_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_t_241368})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241355, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241354_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241354_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241355);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241371 = heff_field(v_x1_241354, 0);
    V v_ru_24x1_241354_24Bug = heff_take_reuse_n(v_x1_241354, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241354_24Bug, TAG_Bug, 1, (V[]){v_what_241371});
  }
  default: return heff_nomatch(v_x1_241354);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam108(V self, V *args) {
  V v_d_241405 = args[0];
  V v_a_241406 = args[1];
  V v_a_241386 = heff_env(self)[0];
  V v_a_241395 = heff_env(self)[1];
  V v_a_241404 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241407 = heff_tr(heff_call(v_a_241406, 1, (V[]){v_d_241405}));
  switch (heff_tag_of(v_x1_241407)) {
  case TAG_Ok: {
    V v_v_241408 = heff_field(v_x1_241407, 0);
    V v_ru_24x1_241407_24Ok = heff_take_reuse_n(v_x1_241407, 1ULL, 1);
    switch (heff_tag_of(v_v_241408)) {
    case TAG_VFun: {
      heff_take_n(v_v_241408, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop(v_a_241404);
      heff_drop_cell(v_ru_24x1_241407_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241408, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop(v_a_241404);
      heff_drop_cell(v_ru_24x1_241407_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241408, 0ULL, 2);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop(v_a_241404);
      heff_drop_cell(v_ru_24x1_241407_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241413 = heff_field(v_v_241408, 0);
      heff_take_n(v_v_241408, 1ULL, 1);
      V v_t_241414 = heff_intMul(heff_strLength_lent(v_a_241386, 0), MK_INT(8LL));
      return ({ V a_0 = v_ru_24x1_241407_24Ok; V a_1 = v_a_241386; V a_2 = v_t_241414; V a_3 = v_a_241395; V a_4 = v_a_241404; V a_5 = v_a_241413; V r_ = (g_heff_2ecompile_2einterp_2eintAtV_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_a_241386); r_; });
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241408, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop(v_a_241404);
      heff_drop_cell(v_ru_24x1_241407_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241408, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop(v_a_241404);
      heff_drop_cell(v_ru_24x1_241407_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241408, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop(v_a_241404);
      heff_drop_cell(v_ru_24x1_241407_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241408, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop(v_a_241404);
      heff_drop_cell(v_ru_24x1_241407_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241408, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop(v_a_241404);
      heff_drop_cell(v_ru_24x1_241407_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241408, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop(v_a_241404);
      heff_drop_cell(v_ru_24x1_241407_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241408, 0ULL, 2);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop(v_a_241404);
      heff_drop_cell(v_ru_24x1_241407_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop(v_a_241404);
      heff_drop_cell(v_ru_24x1_241407_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241408);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241386);
    heff_drop(v_a_241395);
    heff_drop(v_a_241404);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241386);
    heff_drop(v_a_241395);
    heff_drop(v_a_241404);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241423 = heff_field(v_x1_241407, 0);
    V v_ru_24x1_241407_24Bug = heff_take_reuse_n(v_x1_241407, 1ULL, 1);
    heff_drop(v_a_241386);
    heff_drop(v_a_241395);
    heff_drop(v_a_241404);
    return heff_tag_at_n(v_ru_24x1_241407_24Bug, TAG_Bug, 1, (V[]){v_what_241423});
  }
  default: return heff_nomatch(v_x1_241407);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam107(V self, V *args) {
  V v_d_241396 = args[0];
  V v_a_241397 = args[1];
  V v_a_241386 = heff_env(self)[0];
  V v_a_241395 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241398 = heff_tr(heff_call(v_a_241397, 1, (V[]){v_d_241396}));
  switch (heff_tag_of(v_x1_241398)) {
  case TAG_Ok: {
    V v_v_241399 = heff_field(v_x1_241398, 0);
    V v_ru_24x1_241398_24Ok = heff_take_reuse_n(v_x1_241398, 1ULL, 1);
    switch (heff_tag_of(v_v_241399)) {
    case TAG_VFun: {
      heff_take_n(v_v_241399, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop_cell(v_ru_24x1_241398_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241399, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop_cell(v_ru_24x1_241398_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241399, 0ULL, 2);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop_cell(v_ru_24x1_241398_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241404 = heff_field(v_v_241399, 0);
      heff_take_n(v_v_241399, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241398_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam108, 2, 3, (V[]){v_a_241386, v_a_241395, v_a_241404})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241399, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop_cell(v_ru_24x1_241398_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241399, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop_cell(v_ru_24x1_241398_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241399, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop_cell(v_ru_24x1_241398_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241399, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop_cell(v_ru_24x1_241398_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241399, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop_cell(v_ru_24x1_241398_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241399, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop_cell(v_ru_24x1_241398_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241399, 0ULL, 2);
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop_cell(v_ru_24x1_241398_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241386);
      heff_drop(v_a_241395);
      heff_drop_cell(v_ru_24x1_241398_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241399);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241386);
    heff_drop(v_a_241395);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241386);
    heff_drop(v_a_241395);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241432 = heff_field(v_x1_241398, 0);
    V v_ru_24x1_241398_24Bug = heff_take_reuse_n(v_x1_241398, 1ULL, 1);
    heff_drop(v_a_241386);
    heff_drop(v_a_241395);
    return heff_tag_at_n(v_ru_24x1_241398_24Bug, TAG_Bug, 1, (V[]){v_what_241432});
  }
  default: return heff_nomatch(v_x1_241398);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam106(V self, V *args) {
  V v_d_241387 = args[0];
  V v_a_241388 = args[1];
  V v_a_241386 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241389 = heff_tr(heff_call(v_a_241388, 1, (V[]){v_d_241387}));
  switch (heff_tag_of(v_x1_241389)) {
  case TAG_Ok: {
    V v_v_241390 = heff_field(v_x1_241389, 0);
    V v_ru_24x1_241389_24Ok = heff_take_reuse_n(v_x1_241389, 1ULL, 1);
    switch (heff_tag_of(v_v_241390)) {
    case TAG_VFun: {
      heff_take_n(v_v_241390, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop_cell(v_ru_24x1_241389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241390, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop_cell(v_ru_24x1_241389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241390, 0ULL, 2);
      heff_drop(v_a_241386);
      heff_drop_cell(v_ru_24x1_241389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241395 = heff_field(v_v_241390, 0);
      heff_take_n(v_v_241390, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241389_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam107, 2, 2, (V[]){v_a_241386, v_a_241395})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241390, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop_cell(v_ru_24x1_241389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241390, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop_cell(v_ru_24x1_241389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241390, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop_cell(v_ru_24x1_241389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241390, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop_cell(v_ru_24x1_241389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241390, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop_cell(v_ru_24x1_241389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241390, 0ULL, 1);
      heff_drop(v_a_241386);
      heff_drop_cell(v_ru_24x1_241389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241390, 0ULL, 2);
      heff_drop(v_a_241386);
      heff_drop_cell(v_ru_24x1_241389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241386);
      heff_drop_cell(v_ru_24x1_241389_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241390);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241386);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241386);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241441 = heff_field(v_x1_241389, 0);
    V v_ru_24x1_241389_24Bug = heff_take_reuse_n(v_x1_241389, 1ULL, 1);
    heff_drop(v_a_241386);
    return heff_tag_at_n(v_ru_24x1_241389_24Bug, TAG_Bug, 1, (V[]){v_what_241441});
  }
  default: return heff_nomatch(v_x1_241389);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam105(V self, V *args) {
  V v_d_241372 = args[0];
  V v_a_241373 = args[1];
  V v_x1_241374 = heff_tr(heff_call(v_a_241373, 1, (V[]){v_d_241372}));
  switch (heff_tag_of(v_x1_241374)) {
  case TAG_Ok: {
    V v_v_241375 = heff_field(v_x1_241374, 0);
    V v_ru_24x1_241374_24Ok = heff_take_reuse_n(v_x1_241374, 1ULL, 1);
    switch (heff_tag_of(v_v_241375)) {
    case TAG_VFun: {
      heff_take_n(v_v_241375, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241374_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241375, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241374_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241375, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241374_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241375, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241374_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241375, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241374_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241375, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241374_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241375, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241374_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241375, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241374_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241375, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241374_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241386 = heff_field(v_v_241375, 0);
      heff_take_n(v_v_241375, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241374_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam106, 2, 1, (V[]){v_a_241386})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241375, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241374_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241374_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241375);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241444 = heff_field(v_x1_241374, 0);
    V v_ru_24x1_241374_24Bug = heff_take_reuse_n(v_x1_241374, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241374_24Bug, TAG_Bug, 1, (V[]){v_what_241444});
  }
  default: return heff_nomatch(v_x1_241374);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam111(V self, V *args) {
  V v_d_241463 = args[0];
  V v_a_241464 = args[1];
  V v_a_241453 = heff_env(self)[0];
  V v_a_241462 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241465 = heff_tr(heff_call(v_a_241464, 1, (V[]){v_d_241463}));
  switch (heff_tag_of(v_x1_241465)) {
  case TAG_Ok: {
    V v_v_241466 = heff_field(v_x1_241465, 0);
    V v_ru_24x1_241465_24Ok = heff_take_reuse_n(v_x1_241465, 1ULL, 1);
    switch (heff_tag_of(v_v_241466)) {
    case TAG_VFun: {
      heff_take_n(v_v_241466, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop(v_a_241462);
      heff_drop_cell(v_ru_24x1_241465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241466, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop(v_a_241462);
      heff_drop_cell(v_ru_24x1_241465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241466, 0ULL, 2);
      heff_drop(v_a_241453);
      heff_drop(v_a_241462);
      heff_drop_cell(v_ru_24x1_241465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241471 = heff_field(v_v_241466, 0);
      heff_take_n(v_v_241466, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2ebytesOfIntV_24tok1(v_ru_24x1_241465_24Ok, v_a_241453, v_a_241462, v_a_241471));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241466, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop(v_a_241462);
      heff_drop_cell(v_ru_24x1_241465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241466, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop(v_a_241462);
      heff_drop_cell(v_ru_24x1_241465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241466, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop(v_a_241462);
      heff_drop_cell(v_ru_24x1_241465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241466, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop(v_a_241462);
      heff_drop_cell(v_ru_24x1_241465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241466, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop(v_a_241462);
      heff_drop_cell(v_ru_24x1_241465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241466, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop(v_a_241462);
      heff_drop_cell(v_ru_24x1_241465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241466, 0ULL, 2);
      heff_drop(v_a_241453);
      heff_drop(v_a_241462);
      heff_drop_cell(v_ru_24x1_241465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241453);
      heff_drop(v_a_241462);
      heff_drop_cell(v_ru_24x1_241465_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241466);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241453);
    heff_drop(v_a_241462);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241453);
    heff_drop(v_a_241462);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241480 = heff_field(v_x1_241465, 0);
    V v_ru_24x1_241465_24Bug = heff_take_reuse_n(v_x1_241465, 1ULL, 1);
    heff_drop(v_a_241453);
    heff_drop(v_a_241462);
    return heff_tag_at_n(v_ru_24x1_241465_24Bug, TAG_Bug, 1, (V[]){v_what_241480});
  }
  default: return heff_nomatch(v_x1_241465);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam110(V self, V *args) {
  V v_d_241454 = args[0];
  V v_a_241455 = args[1];
  V v_a_241453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241456 = heff_tr(heff_call(v_a_241455, 1, (V[]){v_d_241454}));
  switch (heff_tag_of(v_x1_241456)) {
  case TAG_Ok: {
    V v_v_241457 = heff_field(v_x1_241456, 0);
    V v_ru_24x1_241456_24Ok = heff_take_reuse_n(v_x1_241456, 1ULL, 1);
    switch (heff_tag_of(v_v_241457)) {
    case TAG_VFun: {
      heff_take_n(v_v_241457, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop_cell(v_ru_24x1_241456_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241457, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop_cell(v_ru_24x1_241456_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241457, 0ULL, 2);
      heff_drop(v_a_241453);
      heff_drop_cell(v_ru_24x1_241456_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241462 = heff_field(v_v_241457, 0);
      heff_take_n(v_v_241457, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241456_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam111, 2, 2, (V[]){v_a_241453, v_a_241462})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241457, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop_cell(v_ru_24x1_241456_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241457, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop_cell(v_ru_24x1_241456_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241457, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop_cell(v_ru_24x1_241456_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241457, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop_cell(v_ru_24x1_241456_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241457, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop_cell(v_ru_24x1_241456_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241457, 0ULL, 1);
      heff_drop(v_a_241453);
      heff_drop_cell(v_ru_24x1_241456_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241457, 0ULL, 2);
      heff_drop(v_a_241453);
      heff_drop_cell(v_ru_24x1_241456_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241453);
      heff_drop_cell(v_ru_24x1_241456_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241457);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241453);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241453);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241489 = heff_field(v_x1_241456, 0);
    V v_ru_24x1_241456_24Bug = heff_take_reuse_n(v_x1_241456, 1ULL, 1);
    heff_drop(v_a_241453);
    return heff_tag_at_n(v_ru_24x1_241456_24Bug, TAG_Bug, 1, (V[]){v_what_241489});
  }
  default: return heff_nomatch(v_x1_241456);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam109(V self, V *args) {
  V v_d_241445 = args[0];
  V v_a_241446 = args[1];
  V v_x1_241447 = heff_tr(heff_call(v_a_241446, 1, (V[]){v_d_241445}));
  switch (heff_tag_of(v_x1_241447)) {
  case TAG_Ok: {
    V v_v_241448 = heff_field(v_x1_241447, 0);
    V v_ru_24x1_241447_24Ok = heff_take_reuse_n(v_x1_241447, 1ULL, 1);
    switch (heff_tag_of(v_v_241448)) {
    case TAG_VFun: {
      heff_take_n(v_v_241448, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241447_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241448, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241447_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241448, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241447_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241453 = heff_field(v_v_241448, 0);
      heff_take_n(v_v_241448, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241447_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam110, 2, 1, (V[]){v_a_241453})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241448, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241447_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241448, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241447_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241448, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241447_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241448, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241447_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241448, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241447_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241448, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241447_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241448, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241447_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241447_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241448);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241498 = heff_field(v_x1_241447, 0);
    V v_ru_24x1_241447_24Bug = heff_take_reuse_n(v_x1_241447, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241447_24Bug, TAG_Bug, 1, (V[]){v_what_241498});
  }
  default: return heff_nomatch(v_x1_241447);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam114(V self, V *args) {
  V v_d_241523 = args[0];
  V v_a_241524 = args[1];
  V v_a_241522 = heff_env(self)[0];
  V v_a_241513 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241525 = heff_tr(heff_call(v_a_241524, 1, (V[]){v_d_241523}));
  switch (heff_tag_of(v_x1_241525)) {
  case TAG_Ok: {
    V v_v_241526 = heff_field(v_x1_241525, 0);
    V v_ru_24x1_241525_24Ok = heff_take_reuse_n(v_x1_241525, 1ULL, 1);
    switch (heff_tag_of(v_v_241526)) {
    case TAG_VFun: {
      heff_take_n(v_v_241526, 0ULL, 1);
      heff_drop(v_a_241522);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241526, 0ULL, 1);
      heff_drop(v_a_241522);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241526, 0ULL, 2);
      heff_drop(v_a_241522);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241526, 0ULL, 1);
      heff_drop(v_a_241522);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241526, 0ULL, 1);
      heff_drop(v_a_241522);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241526, 0ULL, 1);
      heff_drop(v_a_241522);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241526, 0ULL, 1);
      heff_drop(v_a_241522);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241526, 0ULL, 1);
      heff_drop(v_a_241522);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241526, 0ULL, 1);
      heff_drop(v_a_241522);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241537 = heff_field(v_v_241526, 0);
      heff_take_n(v_v_241526, 1ULL, 1);
      V v_t_241539;
      if ((heff_intLe_c_lent(MK_INT(0LL), v_a_241522, 1) && (heff_intLe_c(heff_intAdd(heff_dup(v_a_241522), heff_strLength_lent(v_a_241537, 0)), heff_strLength_lent(v_a_241513, 0)) && ({ V v_t_241538 = heff_intAdd(heff_dup(v_a_241522), heff_strLength_lent(v_a_241537, 0)); int c_ = ({ V v_t_241908 = heff_strSlice_lent(v_a_241513, v_a_241522, v_t_241538, 0); int c_ = heff_strEq_c_lent(v_t_241908, v_a_241537, 0); heff_drop(v_t_241908); c_; }); heff_drop(v_t_241538); c_; })))) {
        heff_drop(v_a_241522);
        heff_drop(v_a_241513);
        heff_drop(v_a_241537);
        v_t_241539 = ((V)&g_heff_2ecompile_2einterp_2eprim_str107);
      } else {
        heff_drop(v_a_241522);
        heff_drop(v_a_241513);
        heff_drop(v_a_241537);
        v_t_241539 = ((V)&g_heff_2ecompile_2einterp_2eprim_str108);
      }
      V v_t_241540 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241539, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_241525_24Ok, TAG_Ok, 1, (V[]){v_t_241540});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241526, 0ULL, 2);
      heff_drop(v_a_241522);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241522);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241525_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241526);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241522);
    heff_drop(v_a_241513);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241522);
    heff_drop(v_a_241513);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241543 = heff_field(v_x1_241525, 0);
    V v_ru_24x1_241525_24Bug = heff_take_reuse_n(v_x1_241525, 1ULL, 1);
    heff_drop(v_a_241522);
    heff_drop(v_a_241513);
    return heff_tag_at_n(v_ru_24x1_241525_24Bug, TAG_Bug, 1, (V[]){v_what_241543});
  }
  default: return heff_nomatch(v_x1_241525);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam113(V self, V *args) {
  V v_d_241514 = args[0];
  V v_a_241515 = args[1];
  V v_a_241513 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241516 = heff_tr(heff_call(v_a_241515, 1, (V[]){v_d_241514}));
  switch (heff_tag_of(v_x1_241516)) {
  case TAG_Ok: {
    V v_v_241517 = heff_field(v_x1_241516, 0);
    V v_ru_24x1_241516_24Ok = heff_take_reuse_n(v_x1_241516, 1ULL, 1);
    switch (heff_tag_of(v_v_241517)) {
    case TAG_VFun: {
      heff_take_n(v_v_241517, 0ULL, 1);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241516_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241517, 0ULL, 1);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241516_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241517, 0ULL, 2);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241516_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241522 = heff_field(v_v_241517, 0);
      heff_take_n(v_v_241517, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241516_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam114, 2, 2, (V[]){v_a_241522, v_a_241513})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241517, 0ULL, 1);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241516_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241517, 0ULL, 1);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241516_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241517, 0ULL, 1);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241516_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241517, 0ULL, 1);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241516_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241517, 0ULL, 1);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241516_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241517, 0ULL, 1);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241516_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241517, 0ULL, 2);
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241516_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241513);
      heff_drop_cell(v_ru_24x1_241516_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241517);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241513);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241513);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241552 = heff_field(v_x1_241516, 0);
    V v_ru_24x1_241516_24Bug = heff_take_reuse_n(v_x1_241516, 1ULL, 1);
    heff_drop(v_a_241513);
    return heff_tag_at_n(v_ru_24x1_241516_24Bug, TAG_Bug, 1, (V[]){v_what_241552});
  }
  default: return heff_nomatch(v_x1_241516);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam112(V self, V *args) {
  V v_d_241499 = args[0];
  V v_a_241500 = args[1];
  V v_x1_241501 = heff_tr(heff_call(v_a_241500, 1, (V[]){v_d_241499}));
  switch (heff_tag_of(v_x1_241501)) {
  case TAG_Ok: {
    V v_v_241502 = heff_field(v_x1_241501, 0);
    V v_ru_24x1_241501_24Ok = heff_take_reuse_n(v_x1_241501, 1ULL, 1);
    switch (heff_tag_of(v_v_241502)) {
    case TAG_VFun: {
      heff_take_n(v_v_241502, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241501_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241502, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241501_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241502, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241501_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241502, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241501_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241502, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241501_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241502, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241501_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241502, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241501_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241502, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241501_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241502, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241501_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241513 = heff_field(v_v_241502, 0);
      heff_take_n(v_v_241502, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241501_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam113, 2, 1, (V[]){v_a_241513})})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241502, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241501_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241501_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241502);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241555 = heff_field(v_x1_241501, 0);
    V v_ru_24x1_241501_24Bug = heff_take_reuse_n(v_x1_241501, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241501_24Bug, TAG_Bug, 1, (V[]){v_what_241555});
  }
  default: return heff_nomatch(v_x1_241501);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam118(V self, V *args) {
  V v_d_241576 = args[0];
  V v_a_241577 = args[1];
  V v_s_241557 = heff_env(self)[0];
  V v_m_241556 = heff_env(self)[1];
  V v_a_241566 = heff_env(self)[2];
  V v_a_241575 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_241578 = heff_tr(heff_call(v_a_241577, 1, (V[]){v_d_241576}));
  switch (heff_tag_of(v_x1_241578)) {
  case TAG_Ok: {
    V v_v_241579 = heff_field(v_x1_241578, 0);
    V v_ru_24x1_241578_24Ok = heff_take_reuse_n(v_x1_241578, 1ULL, 1);
    switch (heff_tag_of(v_v_241579)) {
    case TAG_VFun: {
      heff_take_n(v_v_241579, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop(v_a_241575);
      heff_drop_cell(v_ru_24x1_241578_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241579, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop(v_a_241575);
      heff_drop_cell(v_ru_24x1_241578_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241579, 0ULL, 2);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop(v_a_241575);
      heff_drop_cell(v_ru_24x1_241578_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241584 = heff_field(v_v_241579, 0);
      heff_take_n(v_v_241579, 1ULL, 1);
      return ({ V a_0 = v_ru_24x1_241578_24Ok; V a_1 = v_s_241557; V a_2 = v_m_241556; V a_3 = v_a_241566; V a_4 = v_a_241575; V a_5 = v_a_241584; V r_ = (g_heff_2ecompile_2einterp_2eintAtV_24tok1(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_s_241557); r_; });
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241579, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop(v_a_241575);
      heff_drop_cell(v_ru_24x1_241578_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241579, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop(v_a_241575);
      heff_drop_cell(v_ru_24x1_241578_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241579, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop(v_a_241575);
      heff_drop_cell(v_ru_24x1_241578_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241579, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop(v_a_241575);
      heff_drop_cell(v_ru_24x1_241578_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241579, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop(v_a_241575);
      heff_drop_cell(v_ru_24x1_241578_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241579, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop(v_a_241575);
      heff_drop_cell(v_ru_24x1_241578_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241579, 0ULL, 2);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop(v_a_241575);
      heff_drop_cell(v_ru_24x1_241578_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop(v_a_241575);
      heff_drop_cell(v_ru_24x1_241578_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241579);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241557);
    heff_drop(v_m_241556);
    heff_drop(v_a_241566);
    heff_drop(v_a_241575);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241557);
    heff_drop(v_m_241556);
    heff_drop(v_a_241566);
    heff_drop(v_a_241575);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241593 = heff_field(v_x1_241578, 0);
    V v_ru_24x1_241578_24Bug = heff_take_reuse_n(v_x1_241578, 1ULL, 1);
    heff_drop(v_s_241557);
    heff_drop(v_m_241556);
    heff_drop(v_a_241566);
    heff_drop(v_a_241575);
    return heff_tag_at_n(v_ru_24x1_241578_24Bug, TAG_Bug, 1, (V[]){v_what_241593});
  }
  default: return heff_nomatch(v_x1_241578);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam117(V self, V *args) {
  V v_d_241567 = args[0];
  V v_a_241568 = args[1];
  V v_s_241557 = heff_env(self)[0];
  V v_m_241556 = heff_env(self)[1];
  V v_a_241566 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241569 = heff_tr(heff_call(v_a_241568, 1, (V[]){v_d_241567}));
  switch (heff_tag_of(v_x1_241569)) {
  case TAG_Ok: {
    V v_v_241570 = heff_field(v_x1_241569, 0);
    V v_ru_24x1_241569_24Ok = heff_take_reuse_n(v_x1_241569, 1ULL, 1);
    switch (heff_tag_of(v_v_241570)) {
    case TAG_VFun: {
      heff_take_n(v_v_241570, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop_cell(v_ru_24x1_241569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241570, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop_cell(v_ru_24x1_241569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241570, 0ULL, 2);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop_cell(v_ru_24x1_241569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241575 = heff_field(v_v_241570, 0);
      heff_take_n(v_v_241570, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241569_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam118, 2, 4, (V[]){v_s_241557, v_m_241556, v_a_241566, v_a_241575})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241570, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop_cell(v_ru_24x1_241569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241570, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop_cell(v_ru_24x1_241569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241570, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop_cell(v_ru_24x1_241569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241570, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop_cell(v_ru_24x1_241569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241570, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop_cell(v_ru_24x1_241569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241570, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop_cell(v_ru_24x1_241569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241570, 0ULL, 2);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop_cell(v_ru_24x1_241569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop(v_a_241566);
      heff_drop_cell(v_ru_24x1_241569_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241570);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241557);
    heff_drop(v_m_241556);
    heff_drop(v_a_241566);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241557);
    heff_drop(v_m_241556);
    heff_drop(v_a_241566);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241602 = heff_field(v_x1_241569, 0);
    V v_ru_24x1_241569_24Bug = heff_take_reuse_n(v_x1_241569, 1ULL, 1);
    heff_drop(v_s_241557);
    heff_drop(v_m_241556);
    heff_drop(v_a_241566);
    return heff_tag_at_n(v_ru_24x1_241569_24Bug, TAG_Bug, 1, (V[]){v_what_241602});
  }
  default: return heff_nomatch(v_x1_241569);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam116(V self, V *args) {
  V v_d_241558 = args[0];
  V v_a_241559 = args[1];
  V v_s_241557 = heff_env(self)[0];
  V v_m_241556 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241560 = heff_tr(heff_call(v_a_241559, 1, (V[]){v_d_241558}));
  switch (heff_tag_of(v_x1_241560)) {
  case TAG_Ok: {
    V v_v_241561 = heff_field(v_x1_241560, 0);
    V v_ru_24x1_241560_24Ok = heff_take_reuse_n(v_x1_241560, 1ULL, 1);
    switch (heff_tag_of(v_v_241561)) {
    case TAG_VFun: {
      heff_take_n(v_v_241561, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop_cell(v_ru_24x1_241560_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241561, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop_cell(v_ru_24x1_241560_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241561, 0ULL, 2);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop_cell(v_ru_24x1_241560_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241566 = heff_field(v_v_241561, 0);
      heff_take_n(v_v_241561, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241560_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam117, 2, 3, (V[]){v_s_241557, v_m_241556, v_a_241566})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241561, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop_cell(v_ru_24x1_241560_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241561, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop_cell(v_ru_24x1_241560_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241561, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop_cell(v_ru_24x1_241560_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241561, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop_cell(v_ru_24x1_241560_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241561, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop_cell(v_ru_24x1_241560_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241561, 0ULL, 1);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop_cell(v_ru_24x1_241560_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241561, 0ULL, 2);
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop_cell(v_ru_24x1_241560_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_s_241557);
      heff_drop(v_m_241556);
      heff_drop_cell(v_ru_24x1_241560_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241561);
    }
  }
  case TAG_Abn: {
    heff_drop(v_s_241557);
    heff_drop(v_m_241556);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_s_241557);
    heff_drop(v_m_241556);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241611 = heff_field(v_x1_241560, 0);
    V v_ru_24x1_241560_24Bug = heff_take_reuse_n(v_x1_241560, 1ULL, 1);
    heff_drop(v_s_241557);
    heff_drop(v_m_241556);
    return heff_tag_at_n(v_ru_24x1_241560_24Bug, TAG_Bug, 1, (V[]){v_what_241611});
  }
  default: return heff_nomatch(v_x1_241560);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam115(V self, V *args) {
  V v_m_241556 = args[0];
  V v_s_241557 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam116, 2, 2, (V[]){v_s_241557, v_m_241556})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam121(V self, V *args) {
  V v_d_241630 = args[0];
  V v_a_241631 = args[1];
  V v_a_241620 = heff_env(self)[0];
  V v_a_241629 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241632 = heff_tr(heff_call(v_a_241631, 1, (V[]){v_d_241630}));
  switch (heff_tag_of(v_x1_241632)) {
  case TAG_Ok: {
    V v_v_241633 = heff_field(v_x1_241632, 0);
    V v_ru_24x1_241632_24Ok = heff_take_reuse_n(v_x1_241632, 1ULL, 1);
    switch (heff_tag_of(v_v_241633)) {
    case TAG_VFun: {
      heff_take_n(v_v_241633, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop(v_a_241629);
      heff_drop_cell(v_ru_24x1_241632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241633, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop(v_a_241629);
      heff_drop_cell(v_ru_24x1_241632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241633, 0ULL, 2);
      heff_drop(v_a_241620);
      heff_drop(v_a_241629);
      heff_drop_cell(v_ru_24x1_241632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241638 = heff_field(v_v_241633, 0);
      heff_take_n(v_v_241633, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2ebitsOfIntV_24tok1(v_ru_24x1_241632_24Ok, v_a_241620, v_a_241629, v_a_241638));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241633, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop(v_a_241629);
      heff_drop_cell(v_ru_24x1_241632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241633, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop(v_a_241629);
      heff_drop_cell(v_ru_24x1_241632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241633, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop(v_a_241629);
      heff_drop_cell(v_ru_24x1_241632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241633, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop(v_a_241629);
      heff_drop_cell(v_ru_24x1_241632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241633, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop(v_a_241629);
      heff_drop_cell(v_ru_24x1_241632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241633, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop(v_a_241629);
      heff_drop_cell(v_ru_24x1_241632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241633, 0ULL, 2);
      heff_drop(v_a_241620);
      heff_drop(v_a_241629);
      heff_drop_cell(v_ru_24x1_241632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241620);
      heff_drop(v_a_241629);
      heff_drop_cell(v_ru_24x1_241632_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241633);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241620);
    heff_drop(v_a_241629);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241620);
    heff_drop(v_a_241629);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241647 = heff_field(v_x1_241632, 0);
    V v_ru_24x1_241632_24Bug = heff_take_reuse_n(v_x1_241632, 1ULL, 1);
    heff_drop(v_a_241620);
    heff_drop(v_a_241629);
    return heff_tag_at_n(v_ru_24x1_241632_24Bug, TAG_Bug, 1, (V[]){v_what_241647});
  }
  default: return heff_nomatch(v_x1_241632);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam120(V self, V *args) {
  V v_d_241621 = args[0];
  V v_a_241622 = args[1];
  V v_a_241620 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241623 = heff_tr(heff_call(v_a_241622, 1, (V[]){v_d_241621}));
  switch (heff_tag_of(v_x1_241623)) {
  case TAG_Ok: {
    V v_v_241624 = heff_field(v_x1_241623, 0);
    V v_ru_24x1_241623_24Ok = heff_take_reuse_n(v_x1_241623, 1ULL, 1);
    switch (heff_tag_of(v_v_241624)) {
    case TAG_VFun: {
      heff_take_n(v_v_241624, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop_cell(v_ru_24x1_241623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241624, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop_cell(v_ru_24x1_241623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241624, 0ULL, 2);
      heff_drop(v_a_241620);
      heff_drop_cell(v_ru_24x1_241623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241629 = heff_field(v_v_241624, 0);
      heff_take_n(v_v_241624, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241623_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam121, 2, 2, (V[]){v_a_241620, v_a_241629})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241624, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop_cell(v_ru_24x1_241623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241624, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop_cell(v_ru_24x1_241623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241624, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop_cell(v_ru_24x1_241623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241624, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop_cell(v_ru_24x1_241623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241624, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop_cell(v_ru_24x1_241623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241624, 0ULL, 1);
      heff_drop(v_a_241620);
      heff_drop_cell(v_ru_24x1_241623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241624, 0ULL, 2);
      heff_drop(v_a_241620);
      heff_drop_cell(v_ru_24x1_241623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241620);
      heff_drop_cell(v_ru_24x1_241623_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241624);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241620);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241620);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241656 = heff_field(v_x1_241623, 0);
    V v_ru_24x1_241623_24Bug = heff_take_reuse_n(v_x1_241623, 1ULL, 1);
    heff_drop(v_a_241620);
    return heff_tag_at_n(v_ru_24x1_241623_24Bug, TAG_Bug, 1, (V[]){v_what_241656});
  }
  default: return heff_nomatch(v_x1_241623);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam119(V self, V *args) {
  V v_d_241612 = args[0];
  V v_a_241613 = args[1];
  V v_x1_241614 = heff_tr(heff_call(v_a_241613, 1, (V[]){v_d_241612}));
  switch (heff_tag_of(v_x1_241614)) {
  case TAG_Ok: {
    V v_v_241615 = heff_field(v_x1_241614, 0);
    V v_ru_24x1_241614_24Ok = heff_take_reuse_n(v_x1_241614, 1ULL, 1);
    switch (heff_tag_of(v_v_241615)) {
    case TAG_VFun: {
      heff_take_n(v_v_241615, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241614_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241615, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241614_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241615, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241614_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241620 = heff_field(v_v_241615, 0);
      heff_take_n(v_v_241615, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241614_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam120, 2, 1, (V[]){v_a_241620})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241615, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241614_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241615, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241614_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241615, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241614_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241615, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241614_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241615, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241614_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241615, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241614_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241615, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241614_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241614_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241615);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241665 = heff_field(v_x1_241614, 0);
    V v_ru_24x1_241614_24Bug = heff_take_reuse_n(v_x1_241614, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241614_24Bug, TAG_Bug, 1, (V[]){v_what_241665});
  }
  default: return heff_nomatch(v_x1_241614);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam122(V self, V *args) {
  V v_d_241666 = args[0];
  V v_l_241667 = args[1];
  V v_x1_241668 = heff_tr(heff_call(v_l_241667, 1, (V[]){v_d_241666}));
  switch (heff_tag_of(v_x1_241668)) {
  case TAG_Ok: {
    V v_v_241669 = heff_field(v_x1_241668, 0);
    heff_take_n(v_x1_241668, 1ULL, 1);
    V v_t_241670 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241669, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_241670; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ecompile_2einterp_2eprim_str113); V r_ = (g_heff_2ecompile_2einterp_2ebitsJoined(a_0, a_1, a_2)); heff_drop(v_t_241670); r_; });
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241671 = heff_field(v_x1_241668, 0);
    V v_ru_24x1_241668_24Bug = heff_take_reuse_n(v_x1_241668, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241668_24Bug, TAG_Bug, 1, (V[]){v_what_241671});
  }
  default: return heff_nomatch(v_x1_241668);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam125(V self, V *args) {
  V v_d_241683 = args[0];
  V v_a_241684 = args[1];
  V v_a_241682 = heff_env(self)[0];
  V v_m_241672 = heff_env(self)[1];
  V v_s_241673 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_241685 = heff_tr(heff_call(v_a_241684, 1, (V[]){v_d_241683}));
  switch (heff_tag_of(v_x1_241685)) {
  case TAG_Ok: {
    V v_v_241686 = heff_field(v_x1_241685, 0);
    V v_ru_24x1_241685_24Ok = heff_take_reuse_n(v_x1_241685, 1ULL, 1);
    switch (heff_tag_of(v_v_241686)) {
    case TAG_VFun: {
      heff_take_n(v_v_241686, 0ULL, 1);
      heff_drop(v_a_241682);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241685_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241686, 0ULL, 1);
      heff_drop(v_a_241682);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241685_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241686, 0ULL, 2);
      heff_drop(v_a_241682);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241685_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241691 = heff_field(v_v_241686, 0);
      heff_take_n(v_v_241686, 1ULL, 1);
      if ((heff_intLt_c_lent(v_a_241682, MK_INT(0LL), 2) || (heff_intLt_c_lent(v_a_241691, MK_INT(0LL), 2) || heff_intLt_c(heff_dup(v_m_241672), heff_intAdd(heff_dup(v_a_241682), heff_dup(v_a_241691)))))) {
        heff_drop(v_a_241682);
        heff_drop(v_m_241672);
        heff_drop(v_s_241673);
        heff_drop_cell(v_ru_24x1_241685_24Ok, 1);
        heff_drop(v_a_241691);
        return NTAG(TAG_Abn);
      } else {
        heff_drop(v_m_241672);
        V v_t_241692 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_heff_2ecompile_2einterp_2eprim_str115); V a_2 = v_s_241673; V a_3 = heff_dup(v_a_241682); V a_4 = heff_intAdd(v_a_241682, heff_dup(v_a_241691)); V r_ = (g_heff_2ecompile_2einterp_2ebitsCopy(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_s_241673); r_; });
        return heff_tag_at_n(v_ru_24x1_241685_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_a_241691, v_t_241692})});
      }
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241686, 0ULL, 1);
      heff_drop(v_a_241682);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241685_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241686, 0ULL, 1);
      heff_drop(v_a_241682);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241685_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241686, 0ULL, 1);
      heff_drop(v_a_241682);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241685_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241686, 0ULL, 1);
      heff_drop(v_a_241682);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241685_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241686, 0ULL, 1);
      heff_drop(v_a_241682);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241685_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241686, 0ULL, 1);
      heff_drop(v_a_241682);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241685_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241686, 0ULL, 2);
      heff_drop(v_a_241682);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241685_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241682);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241685_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241686);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241682);
    heff_drop(v_m_241672);
    heff_drop(v_s_241673);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241682);
    heff_drop(v_m_241672);
    heff_drop(v_s_241673);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241701 = heff_field(v_x1_241685, 0);
    V v_ru_24x1_241685_24Bug = heff_take_reuse_n(v_x1_241685, 1ULL, 1);
    heff_drop(v_a_241682);
    heff_drop(v_m_241672);
    heff_drop(v_s_241673);
    return heff_tag_at_n(v_ru_24x1_241685_24Bug, TAG_Bug, 1, (V[]){v_what_241701});
  }
  default: return heff_nomatch(v_x1_241685);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam124(V self, V *args) {
  V v_d_241674 = args[0];
  V v_a_241675 = args[1];
  V v_m_241672 = heff_env(self)[0];
  V v_s_241673 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_241676 = heff_tr(heff_call(v_a_241675, 1, (V[]){v_d_241674}));
  switch (heff_tag_of(v_x1_241676)) {
  case TAG_Ok: {
    V v_v_241677 = heff_field(v_x1_241676, 0);
    V v_ru_24x1_241676_24Ok = heff_take_reuse_n(v_x1_241676, 1ULL, 1);
    switch (heff_tag_of(v_v_241677)) {
    case TAG_VFun: {
      heff_take_n(v_v_241677, 0ULL, 1);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241677, 0ULL, 1);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241677, 0ULL, 2);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241682 = heff_field(v_v_241677, 0);
      heff_take_n(v_v_241677, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241676_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam125, 2, 3, (V[]){v_a_241682, v_m_241672, v_s_241673})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241677, 0ULL, 1);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241677, 0ULL, 1);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241677, 0ULL, 1);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241677, 0ULL, 1);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241677, 0ULL, 1);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241677, 0ULL, 1);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241677, 0ULL, 2);
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_m_241672);
      heff_drop(v_s_241673);
      heff_drop_cell(v_ru_24x1_241676_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241677);
    }
  }
  case TAG_Abn: {
    heff_drop(v_m_241672);
    heff_drop(v_s_241673);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_m_241672);
    heff_drop(v_s_241673);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241710 = heff_field(v_x1_241676, 0);
    V v_ru_24x1_241676_24Bug = heff_take_reuse_n(v_x1_241676, 1ULL, 1);
    heff_drop(v_m_241672);
    heff_drop(v_s_241673);
    return heff_tag_at_n(v_ru_24x1_241676_24Bug, TAG_Bug, 1, (V[]){v_what_241710});
  }
  default: return heff_nomatch(v_x1_241676);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam123(V self, V *args) {
  V v_m_241672 = args[0];
  V v_s_241673 = args[1];
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam124, 2, 2, (V[]){v_m_241672, v_s_241673})})});
}
V g_heff_2ecompile_2einterp_2eprim_lam126(V self, V *args) {
  V v_d_241711 = args[0];
  V v_a_241712 = args[1];
  V v_x1_241713 = heff_tr(heff_call(v_a_241712, 1, (V[]){v_d_241711}));
  switch (heff_tag_of(v_x1_241713)) {
  case TAG_Ok: {
    V v_v_241714 = heff_field(v_x1_241713, 0);
    V v_ru_24x1_241713_24Ok = heff_take_reuse_n(v_x1_241713, 1ULL, 1);
    switch (heff_tag_of(v_v_241714)) {
    case TAG_VFun: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241714, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241714, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VBytes: {
      V v_a_241725 = heff_field(v_v_241714, 0);
      heff_take_n(v_v_241714, 1ULL, 1);
      V v_t_241726 = heff_intMul(heff_strLength_lent(v_a_241725, 0), MK_INT(8LL));
      return heff_tag_at_n(v_ru_24x1_241713_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_t_241726, v_a_241725})});
    }
    case TAG_VBits: {
      heff_take_n(v_v_241714, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241713_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
    }
    default: return heff_nomatch(v_v_241714);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241729 = heff_field(v_x1_241713, 0);
    V v_ru_24x1_241713_24Bug = heff_take_reuse_n(v_x1_241713, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241713_24Bug, TAG_Bug, 1, (V[]){v_what_241729});
  }
  default: return heff_nomatch(v_x1_241713);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam127(V self, V *args) {
  V v_n_241730 = args[0];
  V v_s_241731 = args[1];
  if ((heff_unbox_word(heff_intMod(v_n_241730, MK_INT(8LL))) == ((int64_t)0ULL))) {
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_s_241731})});
  } else {
    heff_drop(v_s_241731);
    return NTAG(TAG_Abn);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam129(V self, V *args) {
  V v_m_241734 = args[0];
  V v_t_241735 = args[1];
  V v_n_241732 = heff_env(self)[0];
  V v_s_241733 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_241736;
  if ((heff_intEq_c_lent(v_n_241732, v_m_241734, 0) && heff_strEq_c_lent(v_s_241733, v_t_241735, 0))) {
    heff_drop(v_m_241734);
    heff_drop(v_t_241735);
    heff_drop(v_n_241732);
    heff_drop(v_s_241733);
    v_t_241736 = ((V)&g_heff_2ecompile_2einterp_2eprim_str119);
  } else {
    heff_drop(v_m_241734);
    heff_drop(v_t_241735);
    heff_drop(v_n_241732);
    heff_drop(v_s_241733);
    v_t_241736 = ((V)&g_heff_2ecompile_2einterp_2eprim_str120);
  }
  V v_t_241737 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241736, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241737});
}
V g_heff_2ecompile_2einterp_2eprim_lam128(V self, V *args) {
  V v_n_241732 = args[0];
  V v_s_241733 = args[1];
  V v_t_241738 = (g_heff_2ecompile_2einterp_2ebits1(heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam129, 2, 2, (V[]){v_n_241732, v_s_241733})));
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241738});
}
V g_heff_2ecompile_2einterp_2eprim_lam131(V self, V *args) {
  V v_d_241748 = args[0];
  V v_a_241749 = args[1];
  V v_a_241747 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241750 = heff_tr(heff_call(v_a_241749, 1, (V[]){v_d_241748}));
  switch (heff_tag_of(v_x1_241750)) {
  case TAG_Ok: {
    V v_v_241751 = heff_field(v_x1_241750, 0);
    V v_ru_24x1_241750_24Ok = heff_take_reuse_n(v_x1_241750, 1ULL, 1);
    switch (heff_tag_of(v_v_241751)) {
    case TAG_VFun: {
      heff_take_n(v_v_241751, 0ULL, 1);
      heff_drop(v_a_241747);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241751, 0ULL, 1);
      heff_drop(v_a_241747);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241751, 0ULL, 2);
      heff_drop(v_a_241747);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241751, 0ULL, 1);
      heff_drop(v_a_241747);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VFloat: {
      double v_a_241757 = heff_tflat_f64(v_v_241751, 0);
      heff_take_na(v_v_241751, 0ULL, 1);
      if (heff_intEq_c_lent(v_a_241747, MK_INT(64LL), 2)) {
        heff_drop(v_a_241747);
        V v_t_241758 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(11LL), MK_INT(52LL), v_a_241757));
        return heff_tag_at_n(v_ru_24x1_241750_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_241758})});
      } else {
        if (heff_intEq_c(v_a_241747, MK_INT(32LL))) {
          double v_t_241759 = ((double)((float)v_a_241757));
          V v_t_241760 = (g_heff_2ecompile_2einterp_2eieeeBits_w(MK_INT(8LL), MK_INT(23LL), v_t_241759));
          return heff_tag_at_n(v_ru_24x1_241750_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_241760})});
        } else {
          heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
          return NTAG(TAG_Abn);
        }
      }
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241751, 0ULL, 1);
      heff_drop(v_a_241747);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241751, 0ULL, 1);
      heff_drop(v_a_241747);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241751, 0ULL, 1);
      heff_drop(v_a_241747);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241751, 0ULL, 1);
      heff_drop(v_a_241747);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241751, 0ULL, 1);
      heff_drop(v_a_241747);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241751, 0ULL, 2);
      heff_drop(v_a_241747);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241747);
      heff_drop_cell(v_ru_24x1_241750_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
    }
    default: return heff_nomatch(v_v_241751);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241747);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241747);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241768 = heff_field(v_x1_241750, 0);
    V v_ru_24x1_241750_24Bug = heff_take_reuse_n(v_x1_241750, 1ULL, 1);
    heff_drop(v_a_241747);
    return heff_tag_at_n(v_ru_24x1_241750_24Bug, TAG_Bug, 1, (V[]){v_what_241768});
  }
  default: return heff_nomatch(v_x1_241750);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam130(V self, V *args) {
  V v_d_241739 = args[0];
  V v_a_241740 = args[1];
  V v_x1_241741 = heff_tr(heff_call(v_a_241740, 1, (V[]){v_d_241739}));
  switch (heff_tag_of(v_x1_241741)) {
  case TAG_Ok: {
    V v_v_241742 = heff_field(v_x1_241741, 0);
    V v_ru_24x1_241741_24Ok = heff_take_reuse_n(v_x1_241741, 1ULL, 1);
    switch (heff_tag_of(v_v_241742)) {
    case TAG_VFun: {
      heff_take_n(v_v_241742, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241741_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241742, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241741_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241742, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241741_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241747 = heff_field(v_v_241742, 0);
      heff_take_n(v_v_241742, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241741_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam131, 2, 1, (V[]){v_a_241747})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241742, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241741_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241742, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241741_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241742, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241741_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241742, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241741_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241742, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241741_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241742, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241741_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241742, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241741_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241741_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241742);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241777 = heff_field(v_x1_241741, 0);
    V v_ru_24x1_241741_24Bug = heff_take_reuse_n(v_x1_241741, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241741_24Bug, TAG_Bug, 1, (V[]){v_what_241777});
  }
  default: return heff_nomatch(v_x1_241741);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam133(V self, V *args) {
  V v_d_241787 = args[0];
  V v_a_241788 = args[1];
  V v_a_241786 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_241789 = heff_tr(heff_call(v_a_241788, 1, (V[]){v_d_241787}));
  switch (heff_tag_of(v_x1_241789)) {
  case TAG_Ok: {
    V v_v_241790 = heff_field(v_x1_241789, 0);
    V v_ru_24x1_241789_24Ok = heff_take_reuse_n(v_x1_241789, 1ULL, 1);
    switch (heff_tag_of(v_v_241790)) {
    case TAG_VFun: {
      heff_take_n(v_v_241790, 0ULL, 1);
      heff_drop(v_a_241786);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241790, 0ULL, 1);
      heff_drop(v_a_241786);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241790, 0ULL, 2);
      heff_drop(v_a_241786);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241795 = heff_field(v_v_241790, 0);
      heff_take_n(v_v_241790, 1ULL, 1);
      return (g_heff_2ecompile_2einterp_2efloatOfBitsV_24tok1(v_ru_24x1_241789_24Ok, v_a_241786, v_a_241795));
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241790, 0ULL, 1);
      heff_drop(v_a_241786);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241790, 0ULL, 1);
      heff_drop(v_a_241786);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241790, 0ULL, 1);
      heff_drop(v_a_241786);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241790, 0ULL, 1);
      heff_drop(v_a_241786);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241790, 0ULL, 1);
      heff_drop(v_a_241786);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241790, 0ULL, 1);
      heff_drop(v_a_241786);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241790, 0ULL, 2);
      heff_drop(v_a_241786);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop(v_a_241786);
      heff_drop_cell(v_ru_24x1_241789_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241790);
    }
  }
  case TAG_Abn: {
    heff_drop(v_a_241786);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_a_241786);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241804 = heff_field(v_x1_241789, 0);
    V v_ru_24x1_241789_24Bug = heff_take_reuse_n(v_x1_241789, 1ULL, 1);
    heff_drop(v_a_241786);
    return heff_tag_at_n(v_ru_24x1_241789_24Bug, TAG_Bug, 1, (V[]){v_what_241804});
  }
  default: return heff_nomatch(v_x1_241789);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam132(V self, V *args) {
  V v_d_241778 = args[0];
  V v_a_241779 = args[1];
  V v_x1_241780 = heff_tr(heff_call(v_a_241779, 1, (V[]){v_d_241778}));
  switch (heff_tag_of(v_x1_241780)) {
  case TAG_Ok: {
    V v_v_241781 = heff_field(v_x1_241780, 0);
    V v_ru_24x1_241780_24Ok = heff_take_reuse_n(v_x1_241780, 1ULL, 1);
    switch (heff_tag_of(v_v_241781)) {
    case TAG_VFun: {
      heff_take_n(v_v_241781, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241780_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241781, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241780_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241781, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241780_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241786 = heff_field(v_v_241781, 0);
      heff_take_n(v_v_241781, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241780_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eprim_lam133, 2, 1, (V[]){v_a_241786})})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241781, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241780_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241781, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241780_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241781, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241780_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241781, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241780_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241781, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241780_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241781, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241780_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241781, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241780_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241780_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241781);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241813 = heff_field(v_x1_241780, 0);
    V v_ru_24x1_241780_24Bug = heff_take_reuse_n(v_x1_241780, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241780_24Bug, TAG_Bug, 1, (V[]){v_what_241813});
  }
  default: return heff_nomatch(v_x1_241780);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam134(V self, V *args) {
  V v_a_241814 = args[0];
  V v_b_241815 = args[1];
  V v_t_241816;
  if (heff_intEq_c(v_a_241814, v_b_241815)) {
    v_t_241816 = ((V)&g_heff_2ecompile_2einterp_2eprim_str124);
  } else {
    v_t_241816 = ((V)&g_heff_2ecompile_2einterp_2eprim_str125);
  }
  V v_t_241817 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241816, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241817});
}
V g_heff_2ecompile_2einterp_2eprim_lam135(V self, V *args) {
  V v_a_241818 = args[0];
  V v_b_241819 = args[1];
  V v_t_241820;
  if (heff_intLt_c(v_a_241818, v_b_241819)) {
    v_t_241820 = ((V)&g_heff_2ecompile_2einterp_2eprim_str127);
  } else {
    v_t_241820 = ((V)&g_heff_2ecompile_2einterp_2eprim_str128);
  }
  V v_t_241821 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241820, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241821});
}
V g_heff_2ecompile_2einterp_2eprim_lam136(V self, V *args) {
  V v_a_241822 = args[0];
  V v_b_241823 = args[1];
  V v_t_241824;
  if (heff_intLe_c(v_a_241822, v_b_241823)) {
    v_t_241824 = ((V)&g_heff_2ecompile_2einterp_2eprim_str130);
  } else {
    v_t_241824 = ((V)&g_heff_2ecompile_2einterp_2eprim_str131);
  }
  V v_t_241825 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_241824, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_Ok, 1, (V[]){v_t_241825});
}
V g_heff_2ecompile_2einterp_2eprim_lam137(V self, V *args) {
  V v_d_241826 = args[0];
  V v_a_241827 = args[1];
  V v_x1_241828 = heff_tr(heff_call(v_a_241827, 1, (V[]){v_d_241826}));
  switch (heff_tag_of(v_x1_241828)) {
  case TAG_Ok: {
    V v_v_241829 = heff_field(v_x1_241828, 0);
    V v_ru_24x1_241828_24Ok = heff_take_reuse_n(v_x1_241828, 1ULL, 1);
    switch (heff_tag_of(v_v_241829)) {
    case TAG_VFun: {
      heff_take_n(v_v_241829, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241828_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241829, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241828_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241829, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241828_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241829, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241828_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241829, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241828_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241829, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241828_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241829, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241828_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VRune: {
      V v_a_241838 = heff_field(v_v_241829, 0);
      heff_take_n(v_v_241829, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_241828_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_a_241838})});
    }
    case TAG_VArr: {
      heff_take_n(v_v_241829, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241828_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241829, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241828_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241829, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241828_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241828_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotARune_get());
    }
    default: return heff_nomatch(v_v_241829);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241843 = heff_field(v_x1_241828, 0);
    V v_ru_24x1_241828_24Bug = heff_take_reuse_n(v_x1_241828, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241828_24Bug, TAG_Bug, 1, (V[]){v_what_241843});
  }
  default: return heff_nomatch(v_x1_241828);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam139(V self, V *args) {
  V v_d_241846 = args[0];
  V v_a_241847 = args[1];
  V f_ = v_a_241847;
  args[0] = v_d_241846;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2einterp_2eprim_lam138(V self, V *args) {
  V v_d_241844 = args[0];
  V v_u_241845 = args[1];
  heff_drop(v_d_241844);
  heff_drop(v_u_241845);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eprim_lam139_clo)})});
}
V g_heff_2ecompile_2einterp_2eprim_lam140(V self, V *args) {
  V v_d_241848 = args[0];
  V v_a_241849 = args[1];
  V v_x1_241850 = heff_tr(heff_call(v_a_241849, 1, (V[]){v_d_241848}));
  switch (heff_tag_of(v_x1_241850)) {
  case TAG_Ok: {
    V v_v_241851 = heff_field(v_x1_241850, 0);
    V v_ru_24x1_241850_24Ok = heff_take_reuse_n(v_x1_241850, 1ULL, 1);
    switch (heff_tag_of(v_v_241851)) {
    case TAG_VFun: {
      heff_take_n(v_v_241851, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241850_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241851, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241850_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241851, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241850_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VInt: {
      V v_a_241856 = heff_field(v_v_241851, 0);
      heff_take_n(v_v_241851, 1ULL, 1);
      V v_t_241857 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_241858 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(31LL)));
      V v_t_241859 = heff_intSub(v_a_241856, heff_intSub(MK_INT(0LL), v_t_241858));
      V v_t_241860 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(32LL)));
      V v_t_241861 = heff_intAdd(heff_intSub(MK_INT(0LL), v_t_241857), heff_intMod(v_t_241859, v_t_241860));
      return heff_tag_at_n(v_ru_24x1_241850_24Ok, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VRune, 1, (V[]){v_t_241861})});
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241851, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241850_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241851, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241850_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VStr: {
      heff_take_n(v_v_241851, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241850_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VRune: {
      heff_take_n(v_v_241851, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241850_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241851, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241850_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241851, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241850_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241851, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241850_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241850_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAnInt_get());
    }
    default: return heff_nomatch(v_v_241851);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241870 = heff_field(v_x1_241850, 0);
    V v_ru_24x1_241850_24Bug = heff_take_reuse_n(v_x1_241850, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241850_24Bug, TAG_Bug, 1, (V[]){v_what_241870});
  }
  default: return heff_nomatch(v_x1_241850);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam141(V self, V *args) {
  V v_d_241871 = args[0];
  V v_a_241872 = args[1];
  V v_x1_241873 = heff_tr(heff_call(v_a_241872, 1, (V[]){v_d_241871}));
  switch (heff_tag_of(v_x1_241873)) {
  case TAG_Ok: {
    V v_v_241874 = heff_field(v_x1_241873, 0);
    V v_ru_24x1_241873_24Ok = heff_take_reuse_n(v_x1_241873, 1ULL, 1);
    switch (heff_tag_of(v_v_241874)) {
    case TAG_VFun: {
      heff_take_n(v_v_241874, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241873_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VCons: {
      heff_take_n(v_v_241874, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241873_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VTag: {
      heff_take_n(v_v_241874, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241873_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VInt: {
      heff_take_n(v_v_241874, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241873_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat: {
      heff_take_na(v_v_241874, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241873_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_241874, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241873_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VStr: {
      V v_a_241882 = heff_field(v_v_241874, 0);
      heff_take_n(v_v_241874, 1ULL, 1);
      V v_t_241883 = (g_heff_2ecompile_2einterp_2etoListV_24f1646577013x1449479317(heff_strRunes(v_a_241882)));
      return heff_tag_at_n(v_ru_24x1_241873_24Ok, TAG_Ok, 1, (V[]){v_t_241883});
    }
    case TAG_VRune: {
      heff_take_n(v_v_241874, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241873_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VArr: {
      heff_take_n(v_v_241874, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241873_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBytes: {
      heff_take_n(v_v_241874, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_241873_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VBits: {
      heff_take_n(v_v_241874, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_241873_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    case TAG_VErased: {
      heff_drop_cell(v_ru_24x1_241873_24Ok, 1);
      return heff_dup(g_heff_2ecompile_2einterp_2enotAString_get());
    }
    default: return heff_nomatch(v_v_241874);
    }
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241889 = heff_field(v_x1_241873, 0);
    V v_ru_24x1_241873_24Bug = heff_take_reuse_n(v_x1_241873, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241873_24Bug, TAG_Bug, 1, (V[]){v_what_241889});
  }
  default: return heff_nomatch(v_x1_241873);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam142(V self, V *args) {
  V v_d_241890 = args[0];
  V v_l_241891 = args[1];
  V v_x1_241892 = heff_tr(heff_call(v_l_241891, 1, (V[]){v_d_241890}));
  switch (heff_tag_of(v_x1_241892)) {
  case TAG_Ok: {
    V v_v_241893 = heff_field(v_x1_241892, 0);
    V v_ru_24x1_241892_24Ok = heff_take_reuse_n(v_x1_241892, 1ULL, 1);
    V v_t_241894 = (g_heff_2ecompile_2einterp_2efromListV(v_v_241893, NTAG(TAG_Nil)));
    V v_t_241895 = (g_heff_2ecompile_2einterp_2eruneCodes(v_t_241894));
    V v_t_241896 = (g_list_2emap(heff_dup(g_runeFromInt_get()), v_t_241895));
    V v_t_241897 = heff_tag_n(TAG_VStr, 1, (V[]){heff_strOfRunes(v_t_241896)});
    return heff_tag_at_n(v_ru_24x1_241892_24Ok, TAG_Ok, 1, (V[]){v_t_241897});
  }
  case TAG_Abn: {
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_241898 = heff_field(v_x1_241892, 0);
    V v_ru_24x1_241892_24Bug = heff_take_reuse_n(v_x1_241892, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_241892_24Bug, TAG_Bug, 1, (V[]){v_what_241898});
  }
  default: return heff_nomatch(v_x1_241892);
  }
}
V g_heff_2ecompile_2einterp_2eprim_lam143(V self, V *args) {
  V v_d_241903 = args[0];
  V v_a_241904 = args[1];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_241903);
  heff_drop(v_a_241904);
  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eprim_str137), v_p_240)});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str0, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str2, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str3, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str5, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str6, 2, "{ ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str7, 2, " }");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str9, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str10, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str11, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str12, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str15, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str16, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str17, 1, " ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str18, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str20, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str21, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str22, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str23, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str24, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str25, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str26, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str27, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str28, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str29, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str30, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str31, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str32, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str33, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str34, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str35, 0, "");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str36, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str37, 1, "[");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str38, 1, "]");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str39, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str40, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str41, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str42, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str43, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str44, 1, ")");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str45, 1, "-");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str46, 1, "(");
HEFF_LIT(g_heff_2ecompile_2einterp_2eshowValGo_str47, 1, ")");
Clo g_heff_2ecompile_2einterp_2eshowValGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eshowValGo_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eshowValGo(V v_inArg_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_VFun: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_243 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_243, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str0))) {
        V v_t_244 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str1), heff_strAppend(v_t_244, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str2)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VCons: {
    V v_fs_245 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_keys_246 = heff_take_field(v_fs_245, 0);
    V v_values_247 = heff_get_n(v_fs_245, 2, 3);
    V v_t_248 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_246), heff_arrayToList(v_values_247)));
    V v_x2_249 = (g_list_2emap_24s1427000880x1925304966(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str3), v_t_248));
    V v_t_2412;
    switch (heff_tag_of(v_x2_249)) {
    case TAG_Nil: {
      v_t_2412 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_xs_2411 = heff_field(v_x2_249, 1);
      heff_take_n(v_x2_249, 3ULL, 2);
      v_t_2412 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str5); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
      break;
    }
    default: heff_nomatch(v_x2_249);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str6), heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str7)));
  }
  case TAG_VTag: {
    V v_x_2413 = heff_field(v_v_241, 0);
    V v_vs_2414 = heff_field(v_v_241, 1);
    V v_ru_24v_241_24VTag = heff_take_reuse_n(v_v_241, 3ULL, 2);
    HeffT2 v_t_2415 = (g_heff_2ecompile_2einterp_2elistValsGo_24cpr(heff_tag_at_n(v_ru_24v_241_24VTag, TAG_VTag, 2, (V[]){heff_dup(v_x_2413), heff_dup(v_vs_2414)}), NTAG(TAG_Nil)));
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        heff_drop(v_x_2413);
        heff_drop(v_vs_2414);
        V v_items_2418 = v_field_2417;
        V v_x2_2419 = (g_list_2emap_24s391931963x434308123(v_items_2418));
        V v_t_2422;
        switch (heff_tag_of(v_x2_2419)) {
        case TAG_Nil: {
          v_t_2422 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2420 = heff_field(v_x2_2419, 0);
          V v_xs_2421 = heff_field(v_x2_2419, 1);
          heff_take_n(v_x2_2419, 3ULL, 2);
          v_t_2422 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str9); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2419);
        }
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str10), heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str11)));
      } else {
        heff_drop(v_field_2417);
        switch (heff_tag_of(v_vs_2414)) {
        case TAG_Nil: {
          return v_x_2413;
        }
        case TAG_Cons: {
          if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
            V v_x2_2425 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str12), v_vs_2414));
            V v_t_2428;
            switch (heff_tag_of(v_x2_2425)) {
            case TAG_Nil: {
              v_t_2428 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str13);
              break;
            }
            case TAG_Cons: {
              V v_x_2426 = heff_field(v_x2_2425, 0);
              V v_xs_2427 = heff_field(v_x2_2425, 1);
              heff_take_n(v_x2_2425, 3ULL, 2);
              v_t_2428 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str14); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2425);
            }
            V v_t_2429 = heff_strAppend(v_x_2413, heff_strAppend(v_t_2428, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str15)));
            return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str16), v_t_2429);
          } else {
            V v_x2_2430 = (g_list_2emap_24s503834852x510769098(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str17), v_vs_2414));
            V v_t_2433;
            switch (heff_tag_of(v_x2_2430)) {
            case TAG_Nil: {
              v_t_2433 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str18);
              break;
            }
            case TAG_Cons: {
              V v_x_2431 = heff_field(v_x2_2430, 0);
              V v_xs_2432 = heff_field(v_x2_2430, 1);
              heff_take_n(v_x2_2430, 3ULL, 2);
              v_t_2433 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str19); V a_1 = v_x_2431; V a_2 = v_xs_2432; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2432); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2430);
            }
            return heff_strAppend(v_x_2413, v_t_2433);
          }
        }
        default: return heff_nomatch(v_vs_2414);
        }
      }
    }
  }
  case TAG_VInt: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2435 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2435, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str20))) {
        V v_t_2436 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str21), heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str22)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VFloat: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2438 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2438, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str23))) {
        V v_t_2439 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str24), heff_strAppend(v_t_2439, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str25)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VFloat32: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2441 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2441, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str26))) {
        V v_t_2442 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str27), heff_strAppend(v_t_2442, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str28)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VStr: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2444 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2444, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str29))) {
        V v_t_2445 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str30), heff_strAppend(v_t_2445, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str31)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VRune: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2447 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2447, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str32))) {
        V v_t_2448 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str33), heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str34)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VArr: {
    V v_xs_2449 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    V v_x2_2450 = (g_list_2emap_24s391931963x434308123(heff_arrayToList(v_xs_2449)));
    V v_t_2453;
    switch (heff_tag_of(v_x2_2450)) {
    case TAG_Nil: {
      v_t_2453 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2451 = heff_field(v_x2_2450, 0);
      V v_xs_2452 = heff_field(v_x2_2450, 1);
      heff_take_n(v_x2_2450, 3ULL, 2);
      v_t_2453 = ({ V a_0 = ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str36); V a_1 = v_x_2451; V a_2 = v_xs_2452; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2452); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2450);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str37), heff_strAppend(v_t_2453, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str38)));
  }
  case TAG_VBytes: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2455 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2455, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str39))) {
        V v_t_2456 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str40), heff_strAppend(v_t_2456, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str41)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 1); r_; });
    }
  }
  case TAG_VBits: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2459 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2459, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str42))) {
        V v_t_2460 = ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str43), heff_strAppend(v_t_2460, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str44)));
      } else {
        return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
      }
    } else {
      return ({ V a_0 = v_v_241; V r_ = (g_heff_2ecompile_2einterp_2escalarV(a_0)); heff_drop_tag(v_v_241, 2); r_; });
    }
  }
  case TAG_VErased: {
    if ((heff_dup(v_inArg_240) == NTAG(TAG_True))) {
      V v_s_2461 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      if (heff_strEq_c(heff_strSlice(v_s_2461, MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str45))) {
        V v_t_2462 = (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
        return heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eshowValGo_str46), heff_strAppend(v_t_2462, ((V)&g_heff_2ecompile_2einterp_2eshowValGo_str47)));
      } else {
        return (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
      }
    } else {
      return (g_heff_2ecompile_2einterp_2escalarV(v_v_241));
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2eshowValGo(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_lam0, 1, 0};
Clo g_heff_2ecompile_2einterp_2eapplyErased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eapplyErased_entry, 2, 0};

V g_heff_2ecompile_2einterp_2eapplyErased(V v_n_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_r_241)) {
  case TAG_RSucceeded: {
    V v_r1_242 = heff_dup(heff_field(v_r_241, 0));
    switch (heff_tag_of(v_r1_242)) {
    case TAG_VFun: {
      V v_f_243 = heff_field(v_r1_242, 0);
      V v_ru_24r1_242_24VFun = heff_take_reuse_n(v_r1_242, 1ULL, 1);
      switch (heff_tag_of(v_r_241)) {
      case TAG_RSucceeded: {
        V v_ru_24r_241_24RSucceeded = heff_take_reuse_n(v_r_241, 0ULL, 1);
        if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
          heff_drop(v_n_240);
          return heff_tag_at_n(v_ru_24r_241_24RSucceeded, TAG_RSucceeded, 1, (V[]){heff_tag_at_n(v_ru_24r1_242_24VFun, TAG_VFun, 1, (V[]){v_f_243})});
        } else {
          heff_drop_cell(v_ru_24r1_242_24VFun, 1);
          V v_x1_246 = heff_tr(heff_call(v_f_243, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2ecompile_2einterp_2eapplyErased_lam0_clo)}));
          V v_t_249;
          switch (heff_tag_of(v_x1_246)) {
          case TAG_Ok: {
            V v_v_247 = heff_field(v_x1_246, 0);
            heff_take_n(v_x1_246, 1ULL, 1);
            v_t_249 = heff_tag_at_n(v_ru_24r_241_24RSucceeded, TAG_RSucceeded, 1, (V[]){v_v_247});
            break;
          }
          case TAG_Abn: {
            heff_drop_cell(v_ru_24r_241_24RSucceeded, 1);
            v_t_249 = NTAG(TAG_RAbandoned);
            break;
          }
          case TAG_Div: {
            heff_drop_cell(v_ru_24r_241_24RSucceeded, 1);
            v_t_249 = NTAG(TAG_RDiverged);
            break;
          }
          case TAG_Bug: {
            V v_what_248 = heff_field(v_x1_246, 0);
            V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
            heff_drop_cell(v_ru_24r_241_24RSucceeded, 1);
            v_t_249 = heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_RBug, 1, (V[]){v_what_248});
            break;
          }
          default: heff_nomatch(v_x1_246);
          }
          V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
          V t_1 = v_t_249;
          v_n_240 = t_0;
          v_r_241 = t_1;
          goto top;
        }
      }
      default: return heff_nomatch(v_r_241);
      }
    }
    case TAG_VCons: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VTag: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VInt: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat: {
      heff_take_na(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VFloat32: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VStr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VRune: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VArr: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBytes: {
      heff_take_n(v_r1_242, 0ULL, 1);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VBits: {
      heff_take_n(v_r1_242, 0ULL, 2);
      heff_drop(v_n_240);
      return v_r_241;
    }
    case TAG_VErased: {
      heff_drop(v_n_240);
      return v_r_241;
    }
    default: return heff_nomatch(v_r1_242);
    }
  }
  case TAG_RAbandoned: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RDiverged: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  case TAG_RBug: {
    heff_drop(v_n_240);
    return v_r_241;
  }
  default: return heff_nomatch(v_r_241);
  }
}
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eapplyErased(a[0], a[1]);
}
V g_heff_2ecompile_2einterp_2eapplyErased_lam0(V self, V *args) {
  V v_d_245 = args[0];
  heff_drop(v_d_245);
  return heff_tag_n(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
}
Clo g_heff_2ecompile_2einterp_2ereachGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ereachGlobals_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ereachGlobals(V v_gs_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_gs_240, 8);
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_seen_241, v_k_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_k_243);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        V t_0 = v_gs_240;
        V t_1 = v_seen_241;
        V t_2 = v_rest_244;
        v_gs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_249 = (g_std_2emap_2einsert_24s93785294x875597928(v_seen_241, heff_dup(v_k_243), NTAG(TAG_MkUnit)));
        HeffT2 v_t_2410 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_gs_240, 1), v_k_243));
        V v_t_2424;
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            heff_drop(v_k_243);
            V v_e_2413 = v_field_2412;
            V v_t_2414 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_get_n(v_e_2413, 0, 4)));
            v_t_2424 = (g_heff_2eelab_2erename_2enubFirst(v_t_2414));
          } else {
            heff_drop(v_field_2412);
            HeffT2 v_t_2415 = ({ V a_0 = heff_rfield(v_gs_240, 2); V a_1 = v_k_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_k_243); r_; });
            {
              V v_field_2417 = v_t_2415.f[1];
              int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
              if ((v_tag_2416 == ((int64_t)0ULL))) {
                V v_k2_2418 = v_field_2417;
                HeffT2 v_t_2419 = ({ V a_0 = heff_rfield(v_gs_240, 1); V a_1 = v_k2_2418; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_k2_2418); r_; });
                {
                  V v_field_2421 = v_t_2419.f[1];
                  int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                  if ((v_tag_2420 == ((int64_t)0ULL))) {
                    V v_entry_2422 = v_field_2421;
                    V v_t_2423 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_get_n(v_entry_2422, 0, 4)));
                    v_t_2424 = (g_heff_2eelab_2erename_2enubFirst(v_t_2423));
                  } else {
                    heff_drop(v_field_2421);
                    v_t_2424 = NTAG(TAG_Nil);
                  }
                }
              } else {
                heff_drop(v_field_2417);
                v_t_2424 = NTAG(TAG_Nil);
              }
            }
          }
        }
        V v_t_2425 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x3_242_24Cons, v_t_2424, v_rest_244));
        V t_0 = v_gs_240;
        V t_1 = v_t_249;
        V t_2 = v_t_2425;
        v_gs_240 = t_0;
        v_seen_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2einterp_2ereachGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ereachGlobals(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2einterp_2ebitsOfIntV_24tok1_str0, 0, "");
Clo g_heff_2ecompile_2einterp_2ebitsOfIntV_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebitsOfIntV_24tok1_entry, 4, 0};

V g_heff_2ecompile_2einterp_2ebitsOfIntV_24tok1(V v_tok_240, V v_n_241, V v_f_242, V v_v_243) {
top: ;
  if ((heff_intLt_c_lent(v_n_241, MK_INT(0LL), 2) || heff_intLt_c_lent(MK_INT(64LL), v_n_241, 1))) {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_n_241);
    heff_drop(v_f_242);
    heff_drop(v_v_243);
    return NTAG(TAG_Abn);
  } else {
    V v_w_244 = (g_heff_2ecompile_2einterp_2ewordOf(heff_dup(v_n_241), v_f_242, v_v_243));
    V v_t_245 = heff_intDiv(heff_intAdd(heff_dup(v_n_241), MK_INT(7LL)), MK_INT(8LL));
    V v_t_246 = heff_intDiv(heff_intAdd(heff_dup(v_n_241), MK_INT(7LL)), MK_INT(8LL));
    V v_t_247 = heff_intSub(heff_intMul(v_t_246, MK_INT(8LL)), heff_dup(v_n_241));
    V v_t_248 = (g_heff_2ecompile_2einterp_2etwoTo(v_t_247));
    V v_t_249 = (g_heff_2ecompile_2einterp_2ebytesOfNat(v_t_245, heff_intMul(v_w_244, v_t_248), ((V)&g_heff_2ecompile_2einterp_2ebitsOfIntV_24tok1_str0)));
    return heff_tag_at_n(v_tok_240, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBits, 2, (V[]){v_n_241, v_t_249})});
  }
}
V g_heff_2ecompile_2einterp_2ebitsOfIntV_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2ebitsOfIntV_24tok1(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2einterp_2eintAtV_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eintAtV_24tok1_entry, 6, 0};

V g_heff_2ecompile_2einterp_2eintAtV_24tok1(V v_tok_240, V v_s_241, V v_limit_242, V v_o_243, V v_n_244, V v_f_245) {
top: ;
  if ((heff_intLt_c_lent(v_o_243, MK_INT(0LL), 2) || (heff_intLt_c_lent(v_n_244, MK_INT(0LL), 2) || (heff_intLt_c_lent(MK_INT(64LL), v_n_244, 1) || heff_intLt_c(heff_dup(v_limit_242), heff_intAdd(heff_dup(v_o_243), heff_dup(v_n_244))))))) {
    heff_drop_cell(v_tok_240, 1);
    heff_drop(v_limit_242);
    heff_drop(v_o_243);
    heff_drop(v_n_244);
    heff_drop(v_f_245);
    return NTAG(TAG_Abn);
  } else {
    heff_drop(v_limit_242);
    if ((heff_unbox_word(heff_intMod(heff_dup(v_f_245), MK_INT(2LL))) == ((int64_t)1ULL))) {
      V v_w_246 = (g_heff_2ecompile_2einterp_2ebitsRead(v_s_241, v_o_243, heff_dup(v_n_244), MK_INT(0LL)));
      V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intMod(heff_dup(v_n_244), MK_INT(8LL))));
      V v_t_248 = heff_intMul(MK_INT(8LL), heff_intDiv(heff_dup(v_n_244), MK_INT(8LL)));
      V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(v_t_248));
      V v_t_2410 = heff_intMul(heff_intMod(heff_dup(v_w_246), v_t_247), v_t_249);
      V v_u_2411 = (g_heff_2ecompile_2einterp_2elittleInGo(v_w_246, heff_dup(v_n_244), heff_intDiv(heff_dup(v_n_244), MK_INT(8LL)), MK_INT(0LL), v_t_2410));
      V v_t_2412 = heff_intMod(heff_intDiv(v_f_245, MK_INT(2LL)), MK_INT(2LL));
      V v_t_2415;
      if ((heff_unbox_word(v_t_2412) == ((int64_t)1ULL))) {
        if (heff_intLt_c_lent(MK_INT(0LL), v_n_244, 1)) {
          V v_y_2413 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intSub(heff_dup(v_n_244), MK_INT(1LL))));
          if (heff_intLe_c_lent(v_y_2413, v_u_2411, 1)) {
            V v_t_2414 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_244));
            v_t_2415 = heff_intSub(v_u_2411, v_t_2414);
          } else {
            heff_drop(v_n_244);
            v_t_2415 = v_u_2411;
          }
        } else {
          heff_drop(v_n_244);
          v_t_2415 = v_u_2411;
        }
      } else {
        heff_drop(v_n_244);
        v_t_2415 = v_u_2411;
      }
      return heff_tag_at_n(v_tok_240, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2415})});
    } else {
      V v_u_2416 = (g_heff_2ecompile_2einterp_2ebitsRead(v_s_241, v_o_243, heff_dup(v_n_244), MK_INT(0LL)));
      V v_t_2417 = heff_intMod(heff_intDiv(v_f_245, MK_INT(2LL)), MK_INT(2LL));
      V v_t_2420;
      if ((heff_unbox_word(v_t_2417) == ((int64_t)1ULL))) {
        if (heff_intLt_c_lent(MK_INT(0LL), v_n_244, 1)) {
          V v_y_2418 = (g_heff_2ecompile_2einterp_2etwoTo(heff_intSub(heff_dup(v_n_244), MK_INT(1LL))));
          if (heff_intLe_c_lent(v_y_2418, v_u_2416, 1)) {
            V v_t_2419 = (g_heff_2ecompile_2einterp_2etwoTo(v_n_244));
            v_t_2420 = heff_intSub(v_u_2416, v_t_2419);
          } else {
            heff_drop(v_n_244);
            v_t_2420 = v_u_2416;
          }
        } else {
          heff_drop(v_n_244);
          v_t_2420 = v_u_2416;
        }
      } else {
        heff_drop(v_n_244);
        v_t_2420 = v_u_2416;
      }
      return heff_tag_at_n(v_tok_240, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2420})});
    }
  }
}
V g_heff_2ecompile_2einterp_2eintAtV_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2einterp_2eintAtV_24tok1(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}