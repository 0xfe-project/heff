// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_args 9498020
#define LBL_binders 123633223
#define LBL_body 9524841
#define LBL_byName 571997869
#define LBL_ctx 308385
#define LBL_def 308863
#define LBL_head 9693863
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_inner 301714032
#define LBL_keys 9783995
#define LBL_large 304101205
#define LBL_n 328
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_params 951713969
#define LBL_rest 9992347
#define LBL_values 1123329101
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_im__indent[] = {LBL_im, LBL_indent};
static uint32_t shape_n__inner[] = {LBL_n, LBL_inner};
static uint32_t shape_names__binders__body[] = {LBL_names, LBL_binders, LBL_body};
static uint32_t shape_names__hide[] = {LBL_names, LBL_hide};
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
static uint32_t shape_names__rest__ctx[] = {LBL_names, LBL_rest, LBL_ctx};
static uint32_t shape_params__names__def__large[] = {LBL_params, LBL_names, LBL_def, LBL_large};
V g_heff_2edict_2ezipKV(V, V);
V g_heff_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2edict_2ezipKV_clo;
V g_heff_2epsurface_2ealtLine_24s1348772780x2097554404(V, V, V);
V g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_clo;
V g_heff_2epsurface_2eappPlain_24s659022660x920682911(V, V, V, V);
V g_heff_2epsurface_2eappPlain_24s659022660x920682911_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappPlain_24s659022660x920682911_clo;
V g_heff_2epsurface_2eappStr_24s929057901x1904324530(V, V, V, V);
V g_heff_2epsurface_2eappStr_24s929057901x1904324530_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eappStr_24s929057901x1904324530_clo;
V g_heff_2epsurface_2eargStrs_24s1323800423x1706881613(V, V, V, V, V);
V g_heff_2epsurface_2eargStrs_24s1323800423x1706881613_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eargStrs_24s1323800423x1706881613_clo;
V g_heff_2epsurface_2earrayNone_get(void);
V g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238(V, V, V, V, V);
V g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_clo;
V g_heff_2epsurface_2earrowGrouped_24s253772745x340926816(V, V, V, V);
V g_heff_2epsurface_2earrowGrouped_24s253772745x340926816_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowGrouped_24s253772745x340926816_clo;
V g_heff_2epsurface_2earrowStr_24s2117734577x852423791(V, V, V, V, V, V);
V g_heff_2epsurface_2earrowStr_24s2117734577x852423791_entry(V self, V *a);
extern Clo g_heff_2epsurface_2earrowStr_24s2117734577x852423791_clo;
V g_heff_2epsurface_2eelF_24s473646377x555746588(V, V, V, V);
V g_heff_2epsurface_2eelF_24s473646377x555746588_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s473646377x555746588_clo;
V g_heff_2epsurface_2eelF_24s733037190x667378878(V, V, V, V);
V g_heff_2epsurface_2eelF_24s733037190x667378878_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eelF_24s733037190x667378878_clo;
V g_heff_2epsurface_2eescAt(V, V);
V g_heff_2epsurface_2eescAt_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eescAt_clo;
V g_heff_2epsurface_2eformerAt(V, V, V, V);
V g_heff_2epsurface_2eformerAt_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eformerAt_clo;
V g_heff_2epsurface_2eformerOf_24s1996635939x1902066865(V, V, V);
V g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_clo;
V g_heff_2epsurface_2eformerParam(V, V, V);
V g_heff_2epsurface_2eformerParam_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eformerParam_clo;
V g_heff_2epsurface_2eimplicitGroup(V, V, V, V);
V g_heff_2epsurface_2eimplicitGroup_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eimplicitGroup_clo;
V g_heff_2epsurface_2eimplicitName(V, V, V);
V g_heff_2epsurface_2eimplicitName_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eimplicitName_clo;
V g_heff_2epsurface_2eisOperator(V);
V g_heff_2epsurface_2eisOperator_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eisOperator_clo;
V g_heff_2epsurface_2elamStr_24s2129544944x962470242(V, V, V, V);
V g_heff_2epsurface_2elamStr_24s2129544944x962470242_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elamStr_24s2129544944x962470242_clo;
V g_heff_2epsurface_2elambdas(V, V, V);
V g_heff_2epsurface_2elambdas_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elambdas_clo;
V g_heff_2epsurface_2elistItems(V);
V g_heff_2epsurface_2elistItems_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elistItems_clo;
V g_heff_2epsurface_2elocalName(V, V);
V g_heff_2epsurface_2elocalName_entry(V self, V *a);
extern Clo g_heff_2epsurface_2elocalName_clo;
V g_heff_2epsurface_2enth(V, V);
V g_heff_2epsurface_2enth_entry(V self, V *a);
extern Clo g_heff_2epsurface_2enth_clo;
V g_heff_2epsurface_2eopApp(V, V, V);
V g_heff_2epsurface_2eopApp_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eopApp_clo;
V g_heff_2epsurface_2eoperatorGo(V, V, V);
V g_heff_2epsurface_2eoperatorGo_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eoperatorGo_clo;
V g_heff_2epsurface_2eplainImplicits_get(void);
V g_heff_2epsurface_2eprimitiveOf(V);
V g_heff_2epsurface_2eprimitiveOf_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eprimitiveOf_clo;
V g_heff_2epsurface_2eprintSig_24s1956922268x1093670426(V, V, V, V);
V g_heff_2epsurface_2eprintSig_24s1956922268x1093670426_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eprintSig_24s1956922268x1093670426_clo;
V g_heff_2epsurface_2equoteGo(V, V, V);
V g_heff_2epsurface_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2epsurface_2equoteGo_clo;
V g_heff_2epsurface_2erecordField_24s464605383x1219605104(V, V, V, V);
V g_heff_2epsurface_2erecordField_24s464605383x1219605104_entry(V self, V *a);
extern Clo g_heff_2epsurface_2erecordField_24s464605383x1219605104_clo;
V g_heff_2epsurface_2espineGo(V, V);
V g_heff_2epsurface_2espineGo_entry(V self, V *a);
extern Clo g_heff_2epsurface_2espineGo_clo;
V g_heff_2epsurface_2estripIs(V);
V g_heff_2epsurface_2estripIs_entry(V self, V *a);
extern Clo g_heff_2epsurface_2estripIs_clo;
V g_heff_2epsurface_2etyF_24s1319128358x1023081884(V, V, V, V);
V g_heff_2epsurface_2etyF_24s1319128358x1023081884_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s1319128358x1023081884_clo;
V g_heff_2epsurface_2etyF_24s1378472881x2138997070(V, V, V, V);
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s1378472881x2138997070_clo;
V g_heff_2epsurface_2etyF_24s410763399x651256744(V, V, V, V);
V g_heff_2epsurface_2etyF_24s410763399x651256744_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etyF_24s410763399x651256744_clo;
V g_heff_2epsurface_2etypeFormer(V, V, V, V);
V g_heff_2epsurface_2etypeFormer_entry(V self, V *a);
extern Clo g_heff_2epsurface_2etypeFormer_clo;
V g_heff_2epsurface_2eunIsTy(V);
V g_heff_2epsurface_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2epsurface_2eunIsTy_clo;
V g_heff_2epsurface_2ewordOf(V);
V g_heff_2epsurface_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2epsurface_2ewordOf_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2econcatList(V, V);
V g_prelude_2econcatList_entry(V self, V *a);
extern Clo g_prelude_2econcatList_clo;
V g_prelude_2efilter(V, V);
V g_prelude_2efilter_entry(V self, V *a);
extern Clo g_prelude_2efilter_clo;
V g_prelude_2efoldl(V, V, V);
V g_prelude_2efoldl_entry(V self, V *a);
extern Clo g_prelude_2efoldl_clo;
V g_prelude_2efoldl_24s1226147011x367015740(V, V, V);
V g_prelude_2efoldl_24s1226147011x367015740_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1226147011x367015740_clo;
V g_prelude_2efoldl_24s1546929672x1472202881(V, V);
V g_prelude_2efoldl_24s1546929672x1472202881_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1546929672x1472202881_clo;
V g_prelude_2efoldl_24s1939305664x1902528268(V, V, V);
V g_prelude_2efoldl_24s1939305664x1902528268_entry(V self, V *a);
extern Clo g_prelude_2efoldl_24s1939305664x1902528268_clo;
V g_prelude_2emap(V, V);
V g_prelude_2emap_entry(V self, V *a);
extern Clo g_prelude_2emap_clo;
V g_prelude_2emap_24s1559710030x546042594(V, V);
V g_prelude_2emap_24s1559710030x546042594_entry(V self, V *a);
extern Clo g_prelude_2emap_24s1559710030x546042594_clo;
V g_prelude_2ereplicate(V, V);
V g_prelude_2ereplicate_entry(V self, V *a);
extern Clo g_prelude_2ereplicate_clo;
V g_prelude_2etake(V, V);
V g_prelude_2etake_entry(V self, V *a);
extern Clo g_prelude_2etake_clo;

static V g_heff_2epsurface_2earrayNone_val;
static int g_heff_2epsurface_2earrayNone_st;
static V g_heff_2epsurface_2earrayNone_init(void) {
  return heff_arrayFromList(NTAG(TAG_Nil));
}
V g_heff_2epsurface_2earrayNone_get(void) {
  if (g_heff_2epsurface_2earrayNone_st == 2) return g_heff_2epsurface_2earrayNone_val;
  if (g_heff_2epsurface_2earrayNone_st == 1) heff_fail("defined by itself");
  g_heff_2epsurface_2earrayNone_st = 1;
  g_heff_2epsurface_2earrayNone_val = heff_tr(g_heff_2epsurface_2earrayNone_init());
  g_heff_2epsurface_2earrayNone_st = 2;
  return g_heff_2epsurface_2earrayNone_val;
}
V g_heff_2epsurface_2eplainImplicits_lam0(V self, V *args); static Clo g_heff_2epsurface_2eplainImplicits_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eplainImplicits_lam0, 2, 0};

static V g_heff_2epsurface_2eplainImplicits_val;
static int g_heff_2epsurface_2eplainImplicits_st;
static V g_heff_2epsurface_2eplainImplicits_init(void) {
  return heff_rec(2, shape_names__hide, (V[]){((V)&g_heff_2epsurface_2eplainImplicits_lam0_clo), NTAG(TAG_True)});
}
V g_heff_2epsurface_2eplainImplicits_get(void) {
  if (g_heff_2epsurface_2eplainImplicits_st == 2) return g_heff_2epsurface_2eplainImplicits_val;
  if (g_heff_2epsurface_2eplainImplicits_st == 1) heff_fail("defined by itself");
  g_heff_2epsurface_2eplainImplicits_st = 1;
  g_heff_2epsurface_2eplainImplicits_val = heff_tr(g_heff_2epsurface_2eplainImplicits_init());
  g_heff_2epsurface_2eplainImplicits_st = 2;
  return g_heff_2epsurface_2eplainImplicits_val;
}
V g_heff_2epsurface_2eplainImplicits_lam0(V self, V *args) {
  V v_xs_240 = args[0];
  V v_e_241 = args[1];
  heff_drop(v_xs_240);
  heff_drop(v_e_241);
  return heff_dup(g_heff_2epsurface_2earrayNone_get());
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eescAt_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eescAt_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eescAt_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eescAt_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eescAt_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 116}};
Clo g_heff_2epsurface_2eescAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eescAt_entry, 2, 0};

V g_heff_2epsurface_2eescAt(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(34LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return ((V)&g_heff_2epsurface_2eescAt_str0);
  }
  case TAG_False: {
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(92LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return ((V)&g_heff_2epsurface_2eescAt_str1);
    }
    case TAG_False: {
      V v_t_244 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(10LL));
      switch (heff_tag_of(v_t_244)) {
      case TAG_True: {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        return ((V)&g_heff_2epsurface_2eescAt_str2);
      }
      case TAG_False: {
        V v_t_245 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(13LL));
        switch (heff_tag_of(v_t_245)) {
        case TAG_True: {
          heff_drop(v_s_240);
          heff_drop(v_i_241);
          return ((V)&g_heff_2epsurface_2eescAt_str3);
        }
        case TAG_False: {
          V v_t_246 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(9LL));
          switch (heff_tag_of(v_t_246)) {
          case TAG_True: {
            heff_drop(v_s_240);
            heff_drop(v_i_241);
            return ((V)&g_heff_2epsurface_2eescAt_str4);
          }
          case TAG_False: {
            return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
          }
          default: return heff_nomatch(v_t_246);
          }
        }
        default: return heff_nomatch(v_t_245);
        }
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2epsurface_2eescAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2eescAt(a[0], a[1]);
}
Clo g_heff_2epsurface_2equoteGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2equoteGo_entry, 3, 0};

V g_heff_2epsurface_2equoteGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return v_acc_242;
  }
  case TAG_False: {
    V v_t_244 = heff_strAppend(v_acc_242, (g_heff_2epsurface_2eescAt(heff_dup(v_s_240), heff_dup(v_i_241))));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_244;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2epsurface_2equoteGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2equoteGo(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2ewordOf_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 108, 117, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2ewordOf_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {109, 105, 110, 117, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2ewordOf_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 105, 109, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2ewordOf_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 108, 97, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2epsurface_2ewordOf_str4 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 101, 114, 99, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2ewordOf_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {101, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2ewordOf_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {108, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2ewordOf_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2ewordOf_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 109, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2ewordOf_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2ewordOf_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {98, 97, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2ewordOf_str11 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 97, 114, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2ewordOf_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2ewordOf_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2ewordOf_str14 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 97, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2ewordOf_str15 = {{0x80000000u, K_STR, 0}, 6, 6, {100, 111, 108, 108, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2ewordOf_str16 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 105, 108, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2ewordOf_str17 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 111, 108, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2ewordOf_str18 = {{0x80000000u, K_STR, 0}, 3, 3, {100, 111, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2epsurface_2ewordOf_str19 = {{0x80000000u, K_STR, 0}, 9, 9, {98, 97, 99, 107, 115, 108, 97, 115, 104}};
Clo g_heff_2epsurface_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2ewordOf_entry, 1, 0};

V g_heff_2epsurface_2ewordOf(V v_c_240) {
top: ;
  V v_t_241 = heff_intEq(heff_dup(v_c_240), MK_INT(43LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_c_240);
    return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str0)});
  }
  case TAG_False: {
    V v_t_242 = heff_intEq(heff_dup(v_c_240), MK_INT(45LL));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_c_240);
      return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str1)});
    }
    case TAG_False: {
      V v_t_243 = heff_intEq(heff_dup(v_c_240), MK_INT(42LL));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        heff_drop(v_c_240);
        return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str2)});
      }
      case TAG_False: {
        V v_t_244 = heff_intEq(heff_dup(v_c_240), MK_INT(47LL));
        switch (heff_tag_of(v_t_244)) {
        case TAG_True: {
          heff_drop(v_c_240);
          return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str3)});
        }
        case TAG_False: {
          V v_t_245 = heff_intEq(heff_dup(v_c_240), MK_INT(37LL));
          switch (heff_tag_of(v_t_245)) {
          case TAG_True: {
            heff_drop(v_c_240);
            return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str4)});
          }
          case TAG_False: {
            V v_t_246 = heff_intEq(heff_dup(v_c_240), MK_INT(61LL));
            switch (heff_tag_of(v_t_246)) {
            case TAG_True: {
              heff_drop(v_c_240);
              return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str5)});
            }
            case TAG_False: {
              V v_t_247 = heff_intEq(heff_dup(v_c_240), MK_INT(60LL));
              switch (heff_tag_of(v_t_247)) {
              case TAG_True: {
                heff_drop(v_c_240);
                return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str6)});
              }
              case TAG_False: {
                V v_t_248 = heff_intEq(heff_dup(v_c_240), MK_INT(62LL));
                switch (heff_tag_of(v_t_248)) {
                case TAG_True: {
                  heff_drop(v_c_240);
                  return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str7)});
                }
                case TAG_False: {
                  V v_t_249 = heff_intEq(heff_dup(v_c_240), MK_INT(38LL));
                  switch (heff_tag_of(v_t_249)) {
                  case TAG_True: {
                    heff_drop(v_c_240);
                    return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str8)});
                  }
                  case TAG_False: {
                    V v_t_2410 = heff_intEq(heff_dup(v_c_240), MK_INT(124LL));
                    switch (heff_tag_of(v_t_2410)) {
                    case TAG_True: {
                      heff_drop(v_c_240);
                      return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str9)});
                    }
                    case TAG_False: {
                      V v_t_2411 = heff_intEq(heff_dup(v_c_240), MK_INT(33LL));
                      switch (heff_tag_of(v_t_2411)) {
                      case TAG_True: {
                        heff_drop(v_c_240);
                        return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str10)});
                      }
                      case TAG_False: {
                        V v_t_2412 = heff_intEq(heff_dup(v_c_240), MK_INT(94LL));
                        switch (heff_tag_of(v_t_2412)) {
                        case TAG_True: {
                          heff_drop(v_c_240);
                          return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str11)});
                        }
                        case TAG_False: {
                          V v_t_2413 = heff_intEq(heff_dup(v_c_240), MK_INT(63LL));
                          switch (heff_tag_of(v_t_2413)) {
                          case TAG_True: {
                            heff_drop(v_c_240);
                            return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str12)});
                          }
                          case TAG_False: {
                            V v_t_2414 = heff_intEq(heff_dup(v_c_240), MK_INT(64LL));
                            switch (heff_tag_of(v_t_2414)) {
                            case TAG_True: {
                              heff_drop(v_c_240);
                              return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str13)});
                            }
                            case TAG_False: {
                              V v_t_2415 = heff_intEq(heff_dup(v_c_240), MK_INT(35LL));
                              switch (heff_tag_of(v_t_2415)) {
                              case TAG_True: {
                                heff_drop(v_c_240);
                                return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str14)});
                              }
                              case TAG_False: {
                                V v_t_2416 = heff_intEq(heff_dup(v_c_240), MK_INT(36LL));
                                switch (heff_tag_of(v_t_2416)) {
                                case TAG_True: {
                                  heff_drop(v_c_240);
                                  return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str15)});
                                }
                                case TAG_False: {
                                  V v_t_2417 = heff_intEq(heff_dup(v_c_240), MK_INT(126LL));
                                  switch (heff_tag_of(v_t_2417)) {
                                  case TAG_True: {
                                    heff_drop(v_c_240);
                                    return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str16)});
                                  }
                                  case TAG_False: {
                                    V v_t_2418 = heff_intEq(heff_dup(v_c_240), MK_INT(58LL));
                                    switch (heff_tag_of(v_t_2418)) {
                                    case TAG_True: {
                                      heff_drop(v_c_240);
                                      return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str17)});
                                    }
                                    case TAG_False: {
                                      V v_t_2419 = heff_intEq(heff_dup(v_c_240), MK_INT(46LL));
                                      switch (heff_tag_of(v_t_2419)) {
                                      case TAG_True: {
                                        heff_drop(v_c_240);
                                        return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str18)});
                                      }
                                      case TAG_False: {
                                        V v_t_2420 = heff_intEq(v_c_240, MK_INT(92LL));
                                        switch (heff_tag_of(v_t_2420)) {
                                        case TAG_True: {
                                          return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2epsurface_2ewordOf_str19)});
                                        }
                                        case TAG_False: {
                                          return NTAG(TAG_Nothing);
                                        }
                                        default: return heff_nomatch(v_t_2420);
                                        }
                                      }
                                      default: return heff_nomatch(v_t_2419);
                                      }
                                    }
                                    default: return heff_nomatch(v_t_2418);
                                    }
                                  }
                                  default: return heff_nomatch(v_t_2417);
                                  }
                                }
                                default: return heff_nomatch(v_t_2416);
                                }
                              }
                              default: return heff_nomatch(v_t_2415);
                              }
                            }
                            default: return heff_nomatch(v_t_2414);
                            }
                          }
                          default: return heff_nomatch(v_t_2413);
                          }
                        }
                        default: return heff_nomatch(v_t_2412);
                        }
                      }
                      default: return heff_nomatch(v_t_2411);
                      }
                    }
                    default: return heff_nomatch(v_t_2410);
                    }
                  }
                  default: return heff_nomatch(v_t_249);
                  }
                }
                default: return heff_nomatch(v_t_248);
                }
              }
              default: return heff_nomatch(v_t_247);
              }
            }
            default: return heff_nomatch(v_t_246);
            }
          }
          default: return heff_nomatch(v_t_245);
          }
        }
        default: return heff_nomatch(v_t_244);
        }
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2epsurface_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2ewordOf(a[0]);
}
Clo g_heff_2epsurface_2eoperatorGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eoperatorGo_entry, 3, 0};

V g_heff_2epsurface_2eoperatorGo(V v_x_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_x_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_x_240);
    heff_drop(v_i_241);
    return heff_tag(TAG_Just, 1, (V[]){(g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_acc_242))});
  }
  case TAG_False: {
    V v_t_244 = (g_heff_2epsurface_2ewordOf(heff_strCharCode(heff_dup(v_x_240), heff_dup(v_i_241))));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop(v_x_240);
      heff_drop(v_i_241);
      heff_drop(v_acc_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_w_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_tag(TAG_Cons, 2, (V[]){v_w_245, v_acc_242});
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2epsurface_2eoperatorGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2eoperatorGo(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eisOperator_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eisOperator_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eisOperator_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eisOperator_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {111, 112, 95}};
Clo g_heff_2epsurface_2eisOperator_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eisOperator_entry, 1, 0};

V g_heff_2epsurface_2eisOperator(V v_x_240) {
top: ;
  V v_t_241 = heff_strEq(heff_dup(v_x_240), ((V)&g_heff_2epsurface_2eisOperator_str0));
  V v_x3_247;
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_x_240);
    v_x3_247 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_False: {
    V v_x1_242 = (g_heff_2epsurface_2eoperatorGo(v_x_240, MK_INT(0LL), NTAG(TAG_Nil)));
    switch (heff_tag_of(v_x1_242)) {
    case TAG_Nothing: {
      v_x3_247 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_ws_243 = heff_field(v_x1_242, 0);
      V v_ru_24x1_242_24Just = heff_take_reuse_n(v_x1_242, 1ULL, 1);
      V v_t_246;
      switch (heff_tag_of(v_ws_243)) {
      case TAG_Nil: {
        v_t_246 = ((V)&g_heff_2epsurface_2eisOperator_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_244 = heff_field(v_ws_243, 0);
        V v_xs_245 = heff_field(v_ws_243, 1);
        heff_take_n(v_ws_243, 3ULL, 2);
        v_t_246 = ({ V a_0 = ((V)&g_heff_2epsurface_2eisOperator_str2); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
        break;
      }
      default: heff_nomatch(v_ws_243);
      }
      v_x3_247 = heff_tag_at(v_ru_24x1_242_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2epsurface_2eisOperator_str3), v_t_246)});
      break;
    }
    default: heff_nomatch(v_x1_242);
    }
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_247, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2epsurface_2eisOperator_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2eisOperator(a[0]);
}
Clo g_heff_2epsurface_2enth_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2enth_entry, 2, 0};

V g_heff_2epsurface_2enth(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_i_241);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    }
    case TAG_False: {
      V v_t_245 = heff_intLt(heff_dup(v_i_241), MK_INT(0LL));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      }
      case TAG_False: {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2epsurface_2enth_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2epsurface_2enth(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elocalName_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elocalName_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {39}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elocalName_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elocalName_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2epsurface_2elocalName_lam0(V self, V *args);
Clo g_heff_2epsurface_2elocalName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2elocalName_entry, 2, 0};

V g_heff_2epsurface_2elocalName(V v_xs_240, V v_i_241) {
top: ;
  V v_t_242 = (g_heff_2epsurface_2enth(v_xs_240, heff_dup(v_i_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_xs_240);
    return heff_strAppend(((V)&g_heff_2epsurface_2elocalName_str0), heff_intShow(v_i_241));
  }
  case TAG_Just: {
    V v_x_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_244 = (g_prelude_2etake(v_i_241, v_xs_240));
    V v_xs_246 = (g_prelude_2efilter(heff_clo(g_heff_2epsurface_2elocalName_lam0, 1, 1, (V[]){heff_dup(v_x_243)}), v_t_244));
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_246; V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    V v_x2_248 = (g_prelude_2ereplicate(v_t_247, ((V)&g_heff_2epsurface_2elocalName_str1)));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2epsurface_2elocalName_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2epsurface_2elocalName_str3); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    return heff_strAppend(v_x_243, v_t_2411);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2epsurface_2elocalName_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2elocalName(a[0], a[1]);
}
V g_heff_2epsurface_2elocalName_lam0(V self, V *args) {
  V v_y_245 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(v_y_245, v_x_243);
}
Clo g_heff_2epsurface_2espineGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2espineGo_entry, 2, 0};

V g_heff_2epsurface_2espineGo(V v_h_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_SLocal: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SGlobal: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SCode: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SApp: {
    V v_f_245 = heff_field(v_h_240, 0);
    V v_a_246 = heff_field(v_h_240, 1);
    V v_ru_24h_240_24SApp = heff_take_reuse_n(v_h_240, 3ULL, 2);
    V t_0 = v_f_245;
    V t_1 = heff_tag_at(v_ru_24h_240_24SApp, TAG_Cons, 2, (V[]){v_a_246, v_acc_241});
    v_h_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_SLam: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SCons: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SProj: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_STag: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SMatch: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SSpecialize: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SIs: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SOpaque: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SAbandon: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SRec: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SFix: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SImplicit: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SPrim: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SMetaApp: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitInt: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitFloat: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitString: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitFixed: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitFloat32: {
    return heff_rec(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  default: return heff_nomatch(v_h_240);
  }
}
V g_heff_2epsurface_2espineGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2espineGo(a[0], a[1]);
}
Clo g_heff_2epsurface_2eimplicitName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eimplicitName_entry, 3, 0};

V g_heff_2epsurface_2eimplicitName(V v_names_240, V v_i_241, V v_a_242) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_SLocal: {
    V v_x1_244 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_245 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24Just = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      switch (heff_tag_of(v_m_245)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_244_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_246 = heff_field(v_m_245, 0);
        heff_take_n(v_m_245, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_244_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_246, v_a_242})});
      }
      default: return heff_nomatch(v_m_245);
      }
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  case TAG_SGlobal: {
    V v_x1_248 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_249 = heff_field(v_x1_248, 0);
      V v_ru_24x1_248_24Just = heff_take_reuse_n(v_x1_248, 1ULL, 1);
      switch (heff_tag_of(v_m_249)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_248_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2410 = heff_field(v_m_249, 0);
        heff_take_n(v_m_249, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_248_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2410, v_a_242})});
      }
      default: return heff_nomatch(v_m_249);
      }
    }
    default: return heff_nomatch(v_x1_248);
    }
  }
  case TAG_SCode: {
    V v_x1_2412 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2413 = heff_field(v_x1_2412, 0);
      V v_ru_24x1_2412_24Just = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
      switch (heff_tag_of(v_m_2413)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2412_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2414 = heff_field(v_m_2413, 0);
        heff_take_n(v_m_2413, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2412_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2414, v_a_242})});
      }
      default: return heff_nomatch(v_m_2413);
      }
    }
    default: return heff_nomatch(v_x1_2412);
    }
  }
  case TAG_SApp: {
    V v_x1_2417 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2418 = heff_field(v_x1_2417, 0);
      V v_ru_24x1_2417_24Just = heff_take_reuse_n(v_x1_2417, 1ULL, 1);
      switch (heff_tag_of(v_m_2418)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2417_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2419 = heff_field(v_m_2418, 0);
        heff_take_n(v_m_2418, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2417_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2419, v_a_242})});
      }
      default: return heff_nomatch(v_m_2418);
      }
    }
    default: return heff_nomatch(v_x1_2417);
    }
  }
  case TAG_SLam: {
    V v_x1_2422 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2422)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2423 = heff_field(v_x1_2422, 0);
      V v_ru_24x1_2422_24Just = heff_take_reuse_n(v_x1_2422, 1ULL, 1);
      switch (heff_tag_of(v_m_2423)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2422_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2424 = heff_field(v_m_2423, 0);
        heff_take_n(v_m_2423, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2422_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2424, v_a_242})});
      }
      default: return heff_nomatch(v_m_2423);
      }
    }
    default: return heff_nomatch(v_x1_2422);
    }
  }
  case TAG_SCons: {
    V v_x1_2426 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2426)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2427 = heff_field(v_x1_2426, 0);
      V v_ru_24x1_2426_24Just = heff_take_reuse_n(v_x1_2426, 1ULL, 1);
      switch (heff_tag_of(v_m_2427)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2426_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2428 = heff_field(v_m_2427, 0);
        heff_take_n(v_m_2427, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2426_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2428, v_a_242})});
      }
      default: return heff_nomatch(v_m_2427);
      }
    }
    default: return heff_nomatch(v_x1_2426);
    }
  }
  case TAG_SProj: {
    V v_x1_2431 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2431)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2432 = heff_field(v_x1_2431, 0);
      V v_ru_24x1_2431_24Just = heff_take_reuse_n(v_x1_2431, 1ULL, 1);
      switch (heff_tag_of(v_m_2432)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2431_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2433 = heff_field(v_m_2432, 0);
        heff_take_n(v_m_2432, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2431_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2433, v_a_242})});
      }
      default: return heff_nomatch(v_m_2432);
      }
    }
    default: return heff_nomatch(v_x1_2431);
    }
  }
  case TAG_STag: {
    V v_x1_2436 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2436)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2437 = heff_field(v_x1_2436, 0);
      V v_ru_24x1_2436_24Just = heff_take_reuse_n(v_x1_2436, 1ULL, 1);
      switch (heff_tag_of(v_m_2437)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2436_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2438 = heff_field(v_m_2437, 0);
        heff_take_n(v_m_2437, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2436_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2438, v_a_242})});
      }
      default: return heff_nomatch(v_m_2437);
      }
    }
    default: return heff_nomatch(v_x1_2436);
    }
  }
  case TAG_SMatch: {
    V v_x1_2441 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2441)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2442 = heff_field(v_x1_2441, 0);
      V v_ru_24x1_2441_24Just = heff_take_reuse_n(v_x1_2441, 1ULL, 1);
      switch (heff_tag_of(v_m_2442)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2441_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2443 = heff_field(v_m_2442, 0);
        heff_take_n(v_m_2442, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2441_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2443, v_a_242})});
      }
      default: return heff_nomatch(v_m_2442);
      }
    }
    default: return heff_nomatch(v_x1_2441);
    }
  }
  case TAG_SSpecialize: {
    V v_x1_2447 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2447)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2448 = heff_field(v_x1_2447, 0);
      V v_ru_24x1_2447_24Just = heff_take_reuse_n(v_x1_2447, 1ULL, 1);
      switch (heff_tag_of(v_m_2448)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 3);
        heff_drop_cell(v_ru_24x1_2447_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2449 = heff_field(v_m_2448, 0);
        heff_take_n(v_m_2448, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2447_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2449, v_a_242})});
      }
      default: return heff_nomatch(v_m_2448);
      }
    }
    default: return heff_nomatch(v_x1_2447);
    }
  }
  case TAG_SIs: {
    V v_x1_2451 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2451)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2452 = heff_field(v_x1_2451, 0);
      V v_ru_24x1_2451_24Just = heff_take_reuse_n(v_x1_2451, 1ULL, 1);
      switch (heff_tag_of(v_m_2452)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2451_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2453 = heff_field(v_m_2452, 0);
        heff_take_n(v_m_2452, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2451_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2453, v_a_242})});
      }
      default: return heff_nomatch(v_m_2452);
      }
    }
    default: return heff_nomatch(v_x1_2451);
    }
  }
  case TAG_SOpaque: {
    V v_x1_2454 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2454)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2455 = heff_field(v_x1_2454, 0);
      V v_ru_24x1_2454_24Just = heff_take_reuse_n(v_x1_2454, 1ULL, 1);
      switch (heff_tag_of(v_m_2455)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_2454_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2456 = heff_field(v_m_2455, 0);
        heff_take_n(v_m_2455, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2454_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2456, v_a_242})});
      }
      default: return heff_nomatch(v_m_2455);
      }
    }
    default: return heff_nomatch(v_x1_2454);
    }
  }
  case TAG_SAbandon: {
    V v_x1_2457 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2457)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2458 = heff_field(v_x1_2457, 0);
      V v_ru_24x1_2457_24Just = heff_take_reuse_n(v_x1_2457, 1ULL, 1);
      switch (heff_tag_of(v_m_2458)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_2457_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2459 = heff_field(v_m_2458, 0);
        heff_take_n(v_m_2458, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2457_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2459, v_a_242})});
      }
      default: return heff_nomatch(v_m_2458);
      }
    }
    default: return heff_nomatch(v_x1_2457);
    }
  }
  case TAG_SRec: {
    V v_x1_2461 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2462 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24Just = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      switch (heff_tag_of(v_m_2462)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2461_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2463 = heff_field(v_m_2462, 0);
        heff_take_n(v_m_2462, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2461_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2463, v_a_242})});
      }
      default: return heff_nomatch(v_m_2462);
      }
    }
    default: return heff_nomatch(v_x1_2461);
    }
  }
  case TAG_SFix: {
    V v_x1_2466 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2466)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2467 = heff_field(v_x1_2466, 0);
      V v_ru_24x1_2466_24Just = heff_take_reuse_n(v_x1_2466, 1ULL, 1);
      switch (heff_tag_of(v_m_2467)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2466_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2468 = heff_field(v_m_2467, 0);
        heff_take_n(v_m_2467, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2466_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2468, v_a_242})});
      }
      default: return heff_nomatch(v_m_2467);
      }
    }
    default: return heff_nomatch(v_x1_2466);
    }
  }
  case TAG_SImplicit: {
    V v_n_2469 = heff_field(v_a_242, 0);
    V v_inner_2470 = heff_field(v_a_242, 1);
    heff_take_n(v_a_242, 3ULL, 2);
    heff_drop(v_names_240);
    heff_drop(v_i_241);
    return heff_tag(TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2469, v_inner_2470})});
  }
  case TAG_SPrim: {
    V v_x1_2472 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2472)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2473 = heff_field(v_x1_2472, 0);
      V v_ru_24x1_2472_24Just = heff_take_reuse_n(v_x1_2472, 1ULL, 1);
      switch (heff_tag_of(v_m_2473)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2472_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2474 = heff_field(v_m_2473, 0);
        heff_take_n(v_m_2473, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2472_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2474, v_a_242})});
      }
      default: return heff_nomatch(v_m_2473);
      }
    }
    default: return heff_nomatch(v_x1_2472);
    }
  }
  case TAG_SMetaApp: {
    V v_x1_2478 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2478)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2479 = heff_field(v_x1_2478, 0);
      V v_ru_24x1_2478_24Just = heff_take_reuse_n(v_x1_2478, 1ULL, 1);
      switch (heff_tag_of(v_m_2479)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 3);
        heff_drop_cell(v_ru_24x1_2478_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2480 = heff_field(v_m_2479, 0);
        heff_take_n(v_m_2479, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2478_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2480, v_a_242})});
      }
      default: return heff_nomatch(v_m_2479);
      }
    }
    default: return heff_nomatch(v_x1_2478);
    }
  }
  case TAG_SLitInt: {
    V v_x1_2482 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2482)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2483 = heff_field(v_x1_2482, 0);
      V v_ru_24x1_2482_24Just = heff_take_reuse_n(v_x1_2482, 1ULL, 1);
      switch (heff_tag_of(v_m_2483)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2482_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2484 = heff_field(v_m_2483, 0);
        heff_take_n(v_m_2483, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2482_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2484, v_a_242})});
      }
      default: return heff_nomatch(v_m_2483);
      }
    }
    default: return heff_nomatch(v_x1_2482);
    }
  }
  case TAG_SLitFloat: {
    V v_x1_2486 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2486)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2487 = heff_field(v_x1_2486, 0);
      V v_ru_24x1_2486_24Just = heff_take_reuse_n(v_x1_2486, 1ULL, 1);
      switch (heff_tag_of(v_m_2487)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2486_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2488 = heff_field(v_m_2487, 0);
        heff_take_n(v_m_2487, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2486_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2488, v_a_242})});
      }
      default: return heff_nomatch(v_m_2487);
      }
    }
    default: return heff_nomatch(v_x1_2486);
    }
  }
  case TAG_SLitString: {
    V v_x1_2490 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2490)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2491 = heff_field(v_x1_2490, 0);
      V v_ru_24x1_2490_24Just = heff_take_reuse_n(v_x1_2490, 1ULL, 1);
      switch (heff_tag_of(v_m_2491)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2490_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2492 = heff_field(v_m_2491, 0);
        heff_take_n(v_m_2491, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2490_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2492, v_a_242})});
      }
      default: return heff_nomatch(v_m_2491);
      }
    }
    default: return heff_nomatch(v_x1_2490);
    }
  }
  case TAG_SLitFixed: {
    V v_x1_2495 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2495)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2496 = heff_field(v_x1_2495, 0);
      V v_ru_24x1_2495_24Just = heff_take_reuse_n(v_x1_2495, 1ULL, 1);
      switch (heff_tag_of(v_m_2496)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2495_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2497 = heff_field(v_m_2496, 0);
        heff_take_n(v_m_2496, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2495_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_2497, v_a_242})});
      }
      default: return heff_nomatch(v_m_2496);
      }
    }
    default: return heff_nomatch(v_x1_2495);
    }
  }
  case TAG_SLitFloat32: {
    V v_x1_2499 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2499)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_24100 = heff_field(v_x1_2499, 0);
      V v_ru_24x1_2499_24Just = heff_take_reuse_n(v_x1_2499, 1ULL, 1);
      switch (heff_tag_of(v_m_24100)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2499_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_24101 = heff_field(v_m_24100, 0);
        heff_take_n(v_m_24100, 1ULL, 1);
        return heff_tag_at(v_ru_24x1_2499_24Just, TAG_Just, 1, (V[]){heff_rec(2, shape_n__inner, (V[]){v_n_24101, v_a_242})});
      }
      default: return heff_nomatch(v_m_24100);
      }
    }
    default: return heff_nomatch(v_x1_2499);
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2epsurface_2eimplicitName_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2eimplicitName(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elambdas_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2epsurface_2elambdas_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2elambdas_entry, 3, 0};

V g_heff_2epsurface_2elambdas(V v_ys_240, V v_bs_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SLocal: {
    V v_t_244 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_244, v_e_242});
  }
  case TAG_SGlobal: {
    V v_t_246 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_246, v_e_242});
  }
  case TAG_SCode: {
    V v_t_248 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_248, v_e_242});
  }
  case TAG_SApp: {
    V v_t_2411 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2411, v_e_242});
  }
  case TAG_SLam: {
    V v_it1_2412 = heff_field(v_e_242, 0);
    V v_it2_2413 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SLam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    switch (heff_tag_of(v_it1_2412)) {
    case TAG_SU: {
      heff_take_n(v_it1_2412, 0ULL, 1);
      switch (heff_tag_of(v_it2_2413)) {
      case TAG_MkAbs: {
        V v_x_2415 = heff_field(v_it2_2413, 0);
        V v_b_2416 = heff_field(v_it2_2413, 1);
        V v_ru_24it2_2413_24MkAbs = heff_take_reuse_n(v_it2_2413, 3ULL, 2);
        V t_0 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2415), v_ys_240});
        V t_1 = heff_tag_at(v_ru_24it2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2415, v_bs_241});
        V t_2 = v_b_2416;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2417 = heff_field(v_it2_2413, 0);
        heff_take_n(v_it2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2epsurface_2elambdas_str0), v_bs_241});
        V t_2 = v_b_2417;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_it2_2413);
      }
    }
    case TAG_SDecode: {
      heff_take_n(v_it1_2412, 0ULL, 1);
      switch (heff_tag_of(v_it2_2413)) {
      case TAG_MkAbs: {
        V v_x_2419 = heff_field(v_it2_2413, 0);
        V v_b_2420 = heff_field(v_it2_2413, 1);
        V v_ru_24it2_2413_24MkAbs = heff_take_reuse_n(v_it2_2413, 3ULL, 2);
        V t_0 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2419), v_ys_240});
        V t_1 = heff_tag_at(v_ru_24it2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2419, v_bs_241});
        V t_2 = v_b_2420;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2421 = heff_field(v_it2_2413, 0);
        heff_take_n(v_it2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2epsurface_2elambdas_str1), v_bs_241});
        V t_2 = v_b_2421;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_it2_2413);
      }
    }
    case TAG_SFunction: {
      V v_it14_2425 = heff_field(v_it1_2412, 3);
      heff_take_n(v_it1_2412, 8ULL, 5);
      switch (heff_tag_of(v_it14_2425)) {
      case TAG_Expl: {
        switch (heff_tag_of(v_it2_2413)) {
        case TAG_MkAbs: {
          V v_x_2427 = heff_field(v_it2_2413, 0);
          V v_b_2428 = heff_field(v_it2_2413, 1);
          V v_ru_24it2_2413_24MkAbs = heff_take_reuse_n(v_it2_2413, 3ULL, 2);
          V t_0 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2427), v_ys_240});
          V t_1 = heff_tag_at(v_ru_24it2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2427, v_bs_241});
          V t_2 = v_b_2428;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2429 = heff_field(v_it2_2413, 0);
          heff_take_n(v_it2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2epsurface_2elambdas_str2), v_bs_241});
          V t_2 = v_b_2429;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_it2_2413);
        }
      }
      case TAG_Impl: {
        switch (heff_tag_of(v_it2_2413)) {
        case TAG_MkAbs: {
          V v_x_2430 = heff_field(v_it2_2413, 0);
          V v_b_2431 = heff_field(v_it2_2413, 1);
          V v_ru_24it2_2413_24MkAbs = heff_take_reuse_n(v_it2_2413, 3ULL, 2);
          V v_t_2432 = heff_strAppend(((V)&g_heff_2epsurface_2elambdas_str3), heff_strAppend(heff_dup(v_x_2430), ((V)&g_heff_2epsurface_2elambdas_str4)));
          V t_0 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){v_x_2430, v_ys_240});
          V t_1 = heff_tag_at(v_ru_24it2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_t_2432, v_bs_241});
          V t_2 = v_b_2431;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2433 = heff_field(v_it2_2413, 0);
          heff_take_n(v_it2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2epsurface_2elambdas_str5), v_bs_241});
          V t_2 = v_b_2433;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_it2_2413);
        }
      }
      case TAG_Inst: {
        switch (heff_tag_of(v_it2_2413)) {
        case TAG_MkAbs: {
          V v_x_2434 = heff_field(v_it2_2413, 0);
          V v_b_2435 = heff_field(v_it2_2413, 1);
          V v_ru_24it2_2413_24MkAbs = heff_take_reuse_n(v_it2_2413, 3ULL, 2);
          V v_t_2436 = heff_strAppend(((V)&g_heff_2epsurface_2elambdas_str6), heff_strAppend(heff_dup(v_x_2434), ((V)&g_heff_2epsurface_2elambdas_str7)));
          V t_0 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){v_x_2434, v_ys_240});
          V t_1 = heff_tag_at(v_ru_24it2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_t_2436, v_bs_241});
          V t_2 = v_b_2435;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2437 = heff_field(v_it2_2413, 0);
          heff_take_n(v_it2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2epsurface_2elambdas_str8), v_bs_241});
          V t_2 = v_b_2437;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_it2_2413);
        }
      }
      default: return heff_nomatch(v_it14_2425);
      }
    }
    case TAG_SRecord: {
      heff_take_n(v_it1_2412, 0ULL, 3);
      switch (heff_tag_of(v_it2_2413)) {
      case TAG_MkAbs: {
        V v_x_2441 = heff_field(v_it2_2413, 0);
        V v_b_2442 = heff_field(v_it2_2413, 1);
        V v_ru_24it2_2413_24MkAbs = heff_take_reuse_n(v_it2_2413, 3ULL, 2);
        V t_0 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2441), v_ys_240});
        V t_1 = heff_tag_at(v_ru_24it2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2441, v_bs_241});
        V t_2 = v_b_2442;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2443 = heff_field(v_it2_2413, 0);
        heff_take_n(v_it2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2epsurface_2elambdas_str9), v_bs_241});
        V t_2 = v_b_2443;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_it2_2413);
      }
    }
    case TAG_SSum: {
      heff_take_n(v_it1_2412, 0ULL, 1);
      switch (heff_tag_of(v_it2_2413)) {
      case TAG_MkAbs: {
        V v_x_2445 = heff_field(v_it2_2413, 0);
        V v_b_2446 = heff_field(v_it2_2413, 1);
        V v_ru_24it2_2413_24MkAbs = heff_take_reuse_n(v_it2_2413, 3ULL, 2);
        V t_0 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2445), v_ys_240});
        V t_1 = heff_tag_at(v_ru_24it2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2445, v_bs_241});
        V t_2 = v_b_2446;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2447 = heff_field(v_it2_2413, 0);
        heff_take_n(v_it2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2epsurface_2elambdas_str10), v_bs_241});
        V t_2 = v_b_2447;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_it2_2413);
      }
    }
    case TAG_SIsTy: {
      heff_take_n(v_it1_2412, 0ULL, 1);
      switch (heff_tag_of(v_it2_2413)) {
      case TAG_MkAbs: {
        V v_x_2449 = heff_field(v_it2_2413, 0);
        V v_b_2450 = heff_field(v_it2_2413, 1);
        V v_ru_24it2_2413_24MkAbs = heff_take_reuse_n(v_it2_2413, 3ULL, 2);
        V t_0 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2449), v_ys_240});
        V t_1 = heff_tag_at(v_ru_24it2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2449, v_bs_241});
        V t_2 = v_b_2450;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2451 = heff_field(v_it2_2413, 0);
        heff_take_n(v_it2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2epsurface_2elambdas_str11), v_bs_241});
        V t_2 = v_b_2451;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_it2_2413);
      }
    }
    case TAG_SPrimInt: {
      switch (heff_tag_of(v_it2_2413)) {
      case TAG_MkAbs: {
        V v_x_2452 = heff_field(v_it2_2413, 0);
        V v_b_2453 = heff_field(v_it2_2413, 1);
        V v_ru_24it2_2413_24MkAbs = heff_take_reuse_n(v_it2_2413, 3ULL, 2);
        V t_0 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2452), v_ys_240});
        V t_1 = heff_tag_at(v_ru_24it2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2452, v_bs_241});
        V t_2 = v_b_2453;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2454 = heff_field(v_it2_2413, 0);
        heff_take_n(v_it2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2epsurface_2elambdas_str12), v_bs_241});
        V t_2 = v_b_2454;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_it2_2413);
      }
    }
    case TAG_SPrimFloat: {
      switch (heff_tag_of(v_it2_2413)) {
      case TAG_MkAbs: {
        V v_x_2455 = heff_field(v_it2_2413, 0);
        V v_b_2456 = heff_field(v_it2_2413, 1);
        V v_ru_24it2_2413_24MkAbs = heff_take_reuse_n(v_it2_2413, 3ULL, 2);
        V t_0 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2455), v_ys_240});
        V t_1 = heff_tag_at(v_ru_24it2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2455, v_bs_241});
        V t_2 = v_b_2456;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2457 = heff_field(v_it2_2413, 0);
        heff_take_n(v_it2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2epsurface_2elambdas_str13), v_bs_241});
        V t_2 = v_b_2457;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_it2_2413);
      }
    }
    case TAG_SPrimString: {
      switch (heff_tag_of(v_it2_2413)) {
      case TAG_MkAbs: {
        V v_x_2458 = heff_field(v_it2_2413, 0);
        V v_b_2459 = heff_field(v_it2_2413, 1);
        V v_ru_24it2_2413_24MkAbs = heff_take_reuse_n(v_it2_2413, 3ULL, 2);
        V t_0 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2458), v_ys_240});
        V t_1 = heff_tag_at(v_ru_24it2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2458, v_bs_241});
        V t_2 = v_b_2459;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2460 = heff_field(v_it2_2413, 0);
        heff_take_n(v_it2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2epsurface_2elambdas_str14), v_bs_241});
        V t_2 = v_b_2460;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_it2_2413);
      }
    }
    case TAG_SPrimArray: {
      heff_take_n(v_it1_2412, 0ULL, 1);
      switch (heff_tag_of(v_it2_2413)) {
      case TAG_MkAbs: {
        V v_x_2462 = heff_field(v_it2_2413, 0);
        V v_b_2463 = heff_field(v_it2_2413, 1);
        V v_ru_24it2_2413_24MkAbs = heff_take_reuse_n(v_it2_2413, 3ULL, 2);
        V t_0 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2462), v_ys_240});
        V t_1 = heff_tag_at(v_ru_24it2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2462, v_bs_241});
        V t_2 = v_b_2463;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2464 = heff_field(v_it2_2413, 0);
        heff_take_n(v_it2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2epsurface_2elambdas_str15), v_bs_241});
        V t_2 = v_b_2464;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_it2_2413);
      }
    }
    case TAG_SFixed: {
      heff_take_n(v_it1_2412, 0ULL, 1);
      switch (heff_tag_of(v_it2_2413)) {
      case TAG_MkAbs: {
        V v_x_2466 = heff_field(v_it2_2413, 0);
        V v_b_2467 = heff_field(v_it2_2413, 1);
        V v_ru_24it2_2413_24MkAbs = heff_take_reuse_n(v_it2_2413, 3ULL, 2);
        V t_0 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2466), v_ys_240});
        V t_1 = heff_tag_at(v_ru_24it2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2466, v_bs_241});
        V t_2 = v_b_2467;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2468 = heff_field(v_it2_2413, 0);
        heff_take_n(v_it2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2epsurface_2elambdas_str16), v_bs_241});
        V t_2 = v_b_2468;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_it2_2413);
      }
    }
    default: return heff_nomatch(v_it1_2412);
    }
  }
  case TAG_SCons: {
    V v_t_2470 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2470, v_e_242});
  }
  case TAG_SProj: {
    V v_t_2473 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2473, v_e_242});
  }
  case TAG_STag: {
    V v_t_2476 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2476, v_e_242});
  }
  case TAG_SMatch: {
    V v_t_2479 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2479, v_e_242});
  }
  case TAG_SSpecialize: {
    V v_t_2483 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2483, v_e_242});
  }
  case TAG_SIs: {
    V v_t_2485 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2485, v_e_242});
  }
  case TAG_SOpaque: {
    V v_t_2486 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2486, v_e_242});
  }
  case TAG_SAbandon: {
    V v_t_2487 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2487, v_e_242});
  }
  case TAG_SRec: {
    V v_t_2489 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2489, v_e_242});
  }
  case TAG_SFix: {
    V v_t_2492 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2492, v_e_242});
  }
  case TAG_SImplicit: {
    V v_t_2495 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2495, v_e_242});
  }
  case TAG_SPrim: {
    V v_t_2497 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2497, v_e_242});
  }
  case TAG_SMetaApp: {
    V v_t_24101 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24101, v_e_242});
  }
  case TAG_SLitInt: {
    V v_t_24103 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24103, v_e_242});
  }
  case TAG_SLitFloat: {
    V v_t_24105 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24105, v_e_242});
  }
  case TAG_SLitString: {
    V v_t_24107 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24107, v_e_242});
  }
  case TAG_SLitFixed: {
    V v_t_24110 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24110, v_e_242});
  }
  case TAG_SLitFloat32: {
    V v_t_24112 = (g_prelude_2efoldl_24s1546929672x1472202881(NTAG(TAG_Nil), v_bs_241));
    return heff_rec(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24112, v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2epsurface_2elambdas_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2elambdas(a[0], a[1], a[2]);
}
Clo g_heff_2epsurface_2eopApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eopApp_entry, 3, 0};

V g_heff_2epsurface_2eopApp(V v_c_240, V v_xs_241, V v_sp_242) {
top: ;
  V v_t_243 = heff_get(heff_dup(v_sp_242), LBL_head);
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SGlobal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_246 = heff_get(v_sp_242, LBL_args);
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nil: {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_l_247 = heff_field(v_t_246, 0);
      V v_it2_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      switch (heff_tag_of(v_it2_248)) {
      case TAG_Nil: {
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
        heff_drop(v_l_247);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_r2_249 = heff_field(v_it2_248, 0);
        V v_it22_2410 = heff_field(v_it2_248, 1);
        heff_take_n(v_it2_248, 3ULL, 2);
        switch (heff_tag_of(v_it22_2410)) {
        case TAG_Nil: {
          V v_t_2411 = (g_heff_2epsurface_2eisOperator(v_x_245));
          switch (heff_tag_of(v_t_2411)) {
          case TAG_True: {
            V v_t_2445;
            switch (heff_tag_of(v_l_247)) {
            case TAG_SLocal: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SGlobal: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SCode: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SApp: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SLam: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SCons: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SProj: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_STag: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SMatch: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SSpecialize: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SIs: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SOpaque: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SAbandon: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SRec: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SFix: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SImplicit: {
              v_t_2445 = NTAG(TAG_True);
              break;
            }
            case TAG_SPrim: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SMetaApp: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitInt: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitFloat: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitString: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitFixed: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitFloat32: {
              v_t_2445 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_l_247);
            }
            V v_x1_2479;
            switch (heff_tag_of(v_t_2445)) {
            case TAG_True: {
              v_x1_2479 = NTAG(TAG_True);
              break;
            }
            case TAG_False: {
              switch (heff_tag_of(v_r2_249)) {
              case TAG_SLocal: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SGlobal: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SCode: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SApp: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SLam: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SCons: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SProj: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_STag: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SMatch: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SSpecialize: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SIs: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SOpaque: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SAbandon: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SRec: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SFix: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SImplicit: {
                v_x1_2479 = NTAG(TAG_True);
                break;
              }
              case TAG_SPrim: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SMetaApp: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitInt: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitFloat: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitString: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitFixed: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitFloat32: {
                v_x1_2479 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_r2_249);
              }
              break;
            }
            default: heff_nomatch(v_t_2445);
            }
            switch (heff_tag_of(v_x1_2479)) {
            case TAG_True: {
              heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
              heff_drop(v_l_247);
              heff_drop(v_r2_249);
              return NTAG(TAG_Nothing);
            }
            case TAG_False: {
              return heff_tag_at(v_ru_24t_243_24SGlobal, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_l_247, v_r2_249})});
            }
            default: return heff_nomatch(v_x1_2479);
            }
          }
          case TAG_False: {
            heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
            heff_drop(v_l_247);
            heff_drop(v_r2_249);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_2411);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it22_2410, 0ULL, 2);
          heff_drop(v_x_245);
          heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
          heff_drop(v_l_247);
          heff_drop(v_r2_249);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it22_2410);
        }
      }
      default: return heff_nomatch(v_it2_248);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_SCode: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLam: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCons: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SIs: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SOpaque: {
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SAbandon: {
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrim: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitString: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat32: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_sp_242);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2epsurface_2eopApp_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2epsurface_2eopApp(a[0], a[1], a[2]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2elistItems_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {78, 105, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2elistItems_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {67, 111, 110, 115}};
Clo g_heff_2epsurface_2elistItems_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2elistItems_entry, 1, 0};

V g_heff_2epsurface_2elistItems(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCode: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    V v_x11_2411 = heff_field(v_x1_240, 0);
    V v_ts_2412 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24STag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2413 = heff_strEq(heff_dup(v_x11_2411), ((V)&g_heff_2epsurface_2elistItems_str0));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      heff_drop(v_x11_2411);
      heff_drop_cell(v_ru_24x1_240_24STag, 2);
      V v_t_2414 = heff_intEq(heff_arrayLength(v_ts_2412), MK_INT(0LL));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_True: {
        return heff_tag(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
      }
      case TAG_False: {
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    case TAG_False: {
      V v_t_2415 = heff_strEq(v_x11_2411, ((V)&g_heff_2epsurface_2elistItems_str1));
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        V v_t_2416 = heff_intEq(heff_arrayLength(heff_dup(v_ts_2412)), MK_INT(2LL));
        switch (heff_tag_of(v_t_2416)) {
        case TAG_True: {
          V v_t_2417 = heff_arrayIndex(heff_dup(v_ts_2412), MK_INT(0LL));
          V v_t_2418 = heff_arrayIndex(v_ts_2412, MK_INT(1LL));
          V v_x2_2419 = (g_heff_2epsurface_2elistItems(v_t_2418));
          switch (heff_tag_of(v_x2_2419)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x1_240_24STag, 2);
            heff_drop(v_t_2417);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_ts_2420 = heff_field(v_x2_2419, 0);
            V v_ru_24x2_2419_24Just = heff_take_reuse_n(v_x2_2419, 1ULL, 1);
            return heff_tag_at(v_ru_24x2_2419_24Just, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24x1_240_24STag, TAG_Cons, 2, (V[]){v_t_2417, v_ts_2420})});
          }
          default: return heff_nomatch(v_x2_2419);
          }
        }
        case TAG_False: {
          heff_drop(v_ts_2412);
          heff_drop_cell(v_ru_24x1_240_24STag, 2);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_t_2416);
        }
      }
      case TAG_False: {
        heff_drop(v_ts_2412);
        heff_drop_cell(v_ru_24x1_240_24STag, 2);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  case TAG_SMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_SIs: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SOpaque: {
    return NTAG(TAG_Nothing);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SImplicit: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2epsurface_2elistItems_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2elistItems(a[0]);
}
Clo g_heff_2epsurface_2eimplicitGroup_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eimplicitGroup_entry, 4, 0};

V g_heff_2epsurface_2eimplicitGroup(V v_names_240, V v_u_241, V v_rest_242, V v_ctx_243) {
top: ;
  switch (heff_tag_of(v_rest_242)) {
  case TAG_SU: {
    return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SDecode: {
    return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SFunction: {
    V v_it2_247 = heff_dup(heff_field(v_rest_242, 1));
    V v_it3_248 = heff_dup(heff_field(v_rest_242, 2));
    V v_it4_249 = heff_dup(heff_field(v_rest_242, 3));
    V v_it5_2410 = heff_dup(heff_field(v_rest_242, 4));
    switch (heff_tag_of(v_it2_247)) {
    case TAG_SU: {
      V v_u_27_2411 = heff_field(v_it2_247, 0);
      heff_take_n(v_it2_247, 1ULL, 1);
      switch (heff_tag_of(v_it3_248)) {
      case TAG_MkAbs: {
        V v_y_2412 = heff_field(v_it3_248, 0);
        V v_b_2413 = heff_field(v_it3_248, 1);
        V v_ru_24it3_248_24MkAbs = heff_take_reuse_n(v_it3_248, 3ULL, 2);
        switch (heff_tag_of(v_it4_249)) {
        case TAG_Expl: {
          heff_drop(v_it5_2410);
          heff_drop(v_u_27_2411);
          heff_drop(v_y_2412);
          heff_drop(v_b_2413);
          heff_drop_cell(v_ru_24it3_248_24MkAbs, 2);
          return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
        }
        case TAG_Impl: {
          switch (heff_tag_of(v_it5_2410)) {
          case TAG_Nothing: {
            V v_t_2414;
            switch (heff_tag_of(v_u_241)) {
            case TAG_SmallU: {
              switch (heff_tag_of(v_u_27_2411)) {
              case TAG_SmallU: {
                v_t_2414 = NTAG(TAG_True);
                break;
              }
              case TAG_LargeU: {
                v_t_2414 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_u_27_2411);
              }
              break;
            }
            case TAG_LargeU: {
              switch (heff_tag_of(v_u_27_2411)) {
              case TAG_SmallU: {
                v_t_2414 = NTAG(TAG_False);
                break;
              }
              case TAG_LargeU: {
                v_t_2414 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_u_27_2411);
              }
              break;
            }
            default: heff_nomatch(v_u_241);
            }
            switch (heff_tag_of(v_t_2414)) {
            case TAG_True: {
              heff_drop_tag(v_rest_242, 5);
              V v_t_2415 = heff_tag_at(v_ru_24it3_248_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_y_2412), NTAG(TAG_Nil)});
              V v_t_2416 = (g_prelude_2econcatList(v_names_240, v_t_2415));
              V t_0 = v_t_2416;
              V t_1 = v_u_241;
              V t_2 = v_b_2413;
              V t_3 = heff_tag(TAG_Cons, 2, (V[]){v_y_2412, v_ctx_243});
              v_names_240 = t_0;
              v_u_241 = t_1;
              v_rest_242 = t_2;
              v_ctx_243 = t_3;
              goto top;
            }
            case TAG_False: {
              heff_drop(v_y_2412);
              heff_drop(v_b_2413);
              heff_drop_cell(v_ru_24it3_248_24MkAbs, 2);
              return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
            }
            default: return heff_nomatch(v_t_2414);
            }
          }
          case TAG_Just: {
            heff_take_n(v_it5_2410, 0ULL, 1);
            heff_drop(v_u_27_2411);
            heff_drop(v_y_2412);
            heff_drop(v_b_2413);
            heff_drop_cell(v_ru_24it3_248_24MkAbs, 2);
            return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
          }
          default: return heff_nomatch(v_it5_2410);
          }
        }
        case TAG_Inst: {
          heff_drop(v_it5_2410);
          heff_drop(v_u_27_2411);
          heff_drop(v_y_2412);
          heff_drop(v_b_2413);
          heff_drop_cell(v_ru_24it3_248_24MkAbs, 2);
          return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
        }
        default: return heff_nomatch(v_it4_249);
        }
      }
      case TAG_AbsConst: {
        heff_take_n(v_it3_248, 0ULL, 1);
        heff_drop(v_it4_249);
        heff_drop(v_it5_2410);
        heff_drop(v_u_27_2411);
        return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
      }
      default: return heff_nomatch(v_it3_248);
      }
    }
    case TAG_SDecode: {
      heff_take_n(v_it2_247, 0ULL, 1);
      heff_drop(v_it3_248);
      heff_drop(v_it4_249);
      heff_drop(v_it5_2410);
      return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SFunction: {
      heff_take_n(v_it2_247, 0ULL, 5);
      heff_drop(v_it3_248);
      heff_drop(v_it4_249);
      heff_drop(v_it5_2410);
      return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SRecord: {
      heff_take_n(v_it2_247, 0ULL, 3);
      heff_drop(v_it3_248);
      heff_drop(v_it4_249);
      heff_drop(v_it5_2410);
      return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SSum: {
      heff_take_n(v_it2_247, 0ULL, 1);
      heff_drop(v_it3_248);
      heff_drop(v_it4_249);
      heff_drop(v_it5_2410);
      return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SIsTy: {
      heff_take_n(v_it2_247, 0ULL, 1);
      heff_drop(v_it3_248);
      heff_drop(v_it4_249);
      heff_drop(v_it5_2410);
      return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimInt: {
      heff_drop(v_it3_248);
      heff_drop(v_it4_249);
      heff_drop(v_it5_2410);
      return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimFloat: {
      heff_drop(v_it3_248);
      heff_drop(v_it4_249);
      heff_drop(v_it5_2410);
      return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimString: {
      heff_drop(v_it3_248);
      heff_drop(v_it4_249);
      heff_drop(v_it5_2410);
      return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimArray: {
      heff_take_n(v_it2_247, 0ULL, 1);
      heff_drop(v_it3_248);
      heff_drop(v_it4_249);
      heff_drop(v_it5_2410);
      return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SFixed: {
      heff_take_n(v_it2_247, 0ULL, 1);
      heff_drop(v_it3_248);
      heff_drop(v_it4_249);
      heff_drop(v_it5_2410);
      return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    default: return heff_nomatch(v_it2_247);
    }
  }
  case TAG_SRecord: {
    return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SSum: {
    return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SIsTy: {
    return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimInt: {
    return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimFloat: {
    return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimString: {
    return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimArray: {
    return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SFixed: {
    return heff_rec(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  default: return heff_nomatch(v_rest_242);
  }
}
V g_heff_2epsurface_2eimplicitGroup_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2epsurface_2eimplicitGroup(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2earrowGrouped_24s253772745x340926816_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2earrowGrouped_24s253772745x340926816_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2earrowGrouped_24s253772745x340926816_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2earrowGrouped_24s253772745x340926816_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2earrowGrouped_24s253772745x340926816_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {125, 32, 45, 62, 32}};
Clo g_heff_2epsurface_2earrowGrouped_24s253772745x340926816_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2earrowGrouped_24s253772745x340926816_entry, 4, 0};

V g_heff_2epsurface_2earrowGrouped_24s253772745x340926816(V v_c_240, V v_xs_241, V v_dom_242, V v_r_243) {
top: ;
  V v_t_244 = heff_get(heff_dup(v_r_243), LBL_names);
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2epsurface_2earrowGrouped_24s253772745x340926816_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_t_244, 0);
    V v_xs_246 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2epsurface_2earrowGrouped_24s253772745x340926816_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_248 = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(heff_dup(v_c_240), MK_INT(0LL), v_xs_241, v_dom_242));
  return heff_strAppend(((V)&g_heff_2epsurface_2earrowGrouped_24s253772745x340926816_str2), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2epsurface_2earrowGrouped_24s253772745x340926816_str3), heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2epsurface_2earrowGrouped_24s253772745x340926816_str4), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_get(heff_dup(v_r_243), LBL_ctx); V b_3 = heff_get(v_r_243, LBL_rest); V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; }))))));
}
V g_heff_2epsurface_2earrowGrouped_24s253772745x340926816_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2epsurface_2earrowGrouped_24s253772745x340926816(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {41, 32, 45, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {123, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str5 = {{0x80000000u, K_STR, 0}, 6, 6, {125, 125, 32, 45, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 45, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str7 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 45, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str8 = {{0x80000000u, K_STR, 0}, 6, 6, {123, 123, 95, 32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str9 = {{0x80000000u, K_STR, 0}, 6, 6, {125, 125, 32, 45, 62, 32}};
Clo g_heff_2epsurface_2earrowStr_24s2117734577x852423791_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2earrowStr_24s2117734577x852423791_entry, 6, 0};

V g_heff_2epsurface_2earrowStr_24s2117734577x852423791(V v_c_240, V v_xs_241, V v_level_242, V v_dom_243, V v_cod_244, V v_implicit_245) {
top: ;
  switch (heff_tag_of(v_cod_244)) {
  case TAG_MkAbs: {
    V v_x_246 = heff_field(v_cod_244, 0);
    V v_b_247 = heff_field(v_cod_244, 1);
    V v_ru_24cod_244_24MkAbs = heff_take_reuse_n(v_cod_244, 3ULL, 2);
    switch (heff_tag_of(v_implicit_245)) {
    case TAG_Expl: {
      heff_drop_cell(v_ru_24cod_244_24MkAbs, 2);
      V v_t_248 = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      return heff_strAppend(((V)&g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str0), heff_strAppend(heff_dup(v_x_246), heff_strAppend(((V)&g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str1), heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str2), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_tag(TAG_Cons, 2, (V[]){v_x_246, v_xs_241}); V a_3 = v_b_247; V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, a_3)); heff_drop(v_b_247); r_; }))))));
    }
    case TAG_Impl: {
      V v_t_2434;
      switch (heff_tag_of(v_dom_243)) {
      case TAG_SU: {
        V v_u_249 = heff_field(v_dom_243, 0);
        V v_t_2410 = heff_tag_at(v_ru_24cod_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2434 = (g_heff_2epsurface_2eimplicitGroup(v_t_2410, v_u_249, v_b_247, heff_tag(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})));
        break;
      }
      case TAG_SDecode: {
        V v_t_2412 = heff_tag_at(v_ru_24cod_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2434 = heff_rec(3, shape_names__rest__ctx, (V[]){v_t_2412, v_b_247, heff_tag(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SFunction: {
        V v_t_2418 = heff_tag_at(v_ru_24cod_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2434 = heff_rec(3, shape_names__rest__ctx, (V[]){v_t_2418, v_b_247, heff_tag(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SRecord: {
        V v_t_2422 = heff_tag_at(v_ru_24cod_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2434 = heff_rec(3, shape_names__rest__ctx, (V[]){v_t_2422, v_b_247, heff_tag(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SSum: {
        V v_t_2424 = heff_tag_at(v_ru_24cod_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2434 = heff_rec(3, shape_names__rest__ctx, (V[]){v_t_2424, v_b_247, heff_tag(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SIsTy: {
        V v_t_2426 = heff_tag_at(v_ru_24cod_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2434 = heff_rec(3, shape_names__rest__ctx, (V[]){v_t_2426, v_b_247, heff_tag(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimInt: {
        V v_t_2427 = heff_tag_at(v_ru_24cod_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2434 = heff_rec(3, shape_names__rest__ctx, (V[]){v_t_2427, v_b_247, heff_tag(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimFloat: {
        V v_t_2428 = heff_tag_at(v_ru_24cod_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2434 = heff_rec(3, shape_names__rest__ctx, (V[]){v_t_2428, v_b_247, heff_tag(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimString: {
        V v_t_2429 = heff_tag_at(v_ru_24cod_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2434 = heff_rec(3, shape_names__rest__ctx, (V[]){v_t_2429, v_b_247, heff_tag(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimArray: {
        V v_t_2431 = heff_tag_at(v_ru_24cod_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2434 = heff_rec(3, shape_names__rest__ctx, (V[]){v_t_2431, v_b_247, heff_tag(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SFixed: {
        V v_t_2433 = heff_tag_at(v_ru_24cod_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2434 = heff_rec(3, shape_names__rest__ctx, (V[]){v_t_2433, v_b_247, heff_tag(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      default: heff_nomatch(v_dom_243);
      }
      return (g_heff_2epsurface_2earrowGrouped_24s253772745x340926816(v_c_240, v_xs_241, v_dom_243, v_t_2434));
    }
    case TAG_Inst: {
      heff_drop_cell(v_ru_24cod_244_24MkAbs, 2);
      V v_t_2435 = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      return heff_strAppend(((V)&g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str3), heff_strAppend(heff_dup(v_x_246), heff_strAppend(((V)&g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str4), heff_strAppend(v_t_2435, heff_strAppend(((V)&g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str5), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_tag(TAG_Cons, 2, (V[]){v_x_246, v_xs_241}); V a_3 = v_b_247; V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, a_3)); heff_drop(v_b_247); r_; }))))));
    }
    default: return heff_nomatch(v_implicit_245);
    }
  }
  case TAG_AbsConst: {
    V v_b_2436 = heff_field(v_cod_244, 0);
    heff_take_n(v_cod_244, 1ULL, 1);
    switch (heff_tag_of(v_implicit_245)) {
    case TAG_Expl: {
      V v_t_2437 = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(heff_dup(v_c_240), MK_INT(1LL), heff_dup(v_xs_241), v_dom_243));
      return heff_strAppend(v_t_2437, heff_strAppend(((V)&g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str6), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_2436; V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, a_3)); heff_drop(v_b_2436); r_; })));
    }
    case TAG_Impl: {
      V v_t_2438 = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(heff_dup(v_c_240), MK_INT(1LL), heff_dup(v_xs_241), v_dom_243));
      return heff_strAppend(v_t_2438, heff_strAppend(((V)&g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str7), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_2436; V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, a_3)); heff_drop(v_b_2436); r_; })));
    }
    case TAG_Inst: {
      V v_t_2439 = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      return heff_strAppend(((V)&g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str8), heff_strAppend(v_t_2439, heff_strAppend(((V)&g_heff_2epsurface_2earrowStr_24s2117734577x852423791_str9), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_2436; V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, a_3)); heff_drop(v_b_2436); r_; }))));
    }
    default: return heff_nomatch(v_implicit_245);
    }
  }
  default: return heff_nomatch(v_cod_244);
  }
}
V g_heff_2epsurface_2earrowStr_24s2117734577x852423791_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2epsurface_2earrowStr_24s2117734577x852423791(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[2]); heff_drop(a[3]); heff_drop(a[5]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 58, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {125, 32, 45, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {123, 95, 32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 58, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {125, 32, 45, 62, 32}};
Clo g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_entry, 5, 0};

V g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238(V v_c_240, V v_xs_241, V v_dom_242, V v_x5_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkAbs: {
    V v_x_245 = heff_field(v_x5_243, 0);
    V v_b_246 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_t_247 = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_248 = (g_heff_2epsurface_2eelF_24s733037190x667378878(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    return heff_strAppend(((V)&g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_str0), heff_strAppend(heff_dup(v_x_245), heff_strAppend(((V)&g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_str1), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_str2), heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_str3), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_tag(TAG_Cons, 2, (V[]){v_x_245, v_xs_241}); V a_3 = v_b_246; V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, a_3)); heff_drop(v_b_246); r_; }))))))));
  }
  case TAG_AbsConst: {
    V v_b_249 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_t_2410 = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_2411 = (g_heff_2epsurface_2eelF_24s733037190x667378878(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    return heff_strAppend(((V)&g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_str4), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_str5), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_str6), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_249; V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, a_3)); heff_drop(v_b_249); r_; }))))));
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2erecordField_24s464605383x1219605104_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2erecordField_24s464605383x1219605104_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2erecordField_24s464605383x1219605104_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
Clo g_heff_2epsurface_2erecordField_24s464605383x1219605104_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2erecordField_24s464605383x1219605104_entry, 4, 0};

V g_heff_2epsurface_2erecordField_24s464605383x1219605104(V v_c_240, V v_ds_241, V v_acc_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_l_244 = heff_field(v_x5_243, 0);
    V v_t_245 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkPair = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_246 = heff_tag_at(v_ru_24x5_243_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_l_244), heff_get(heff_dup(v_acc_242), LBL_names)});
    V v_t_247 = ({ V a_0 = heff_dup(v_c_240); V a_1 = MK_INT(0LL); V a_2 = heff_get(heff_dup(v_acc_242), LBL_names); V a_3 = v_t_245; V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, a_3)); heff_drop(v_t_245); r_; });
    V v_t_248 = ({ V a_0 = heff_dup(v_l_244); V b_1 = heff_get(heff_dup(v_ds_241), LBL_byName); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_x4_2414;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_ds_241);
      v_x4_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_i_249 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
      V v_xs_2410 = heff_get(v_ds_241, LBL_values);
      V v_t_2411 = heff_intLe(MK_INT(0LL), heff_dup(v_i_249));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V v_t_2412 = heff_intLt(heff_dup(v_i_249), heff_arrayLength(heff_dup(v_xs_2410)));
        switch (heff_tag_of(v_t_2412)) {
        case TAG_True: {
          V v_t_2413 = heff_arrayIndex(v_xs_2410, v_i_249);
          v_x4_2414 = heff_tag_at(v_ru_24t_248_24Just, TAG_Just, 1, (V[]){v_t_2413});
          break;
        }
        case TAG_False: {
          heff_drop(v_i_249);
          heff_drop_cell(v_ru_24t_248_24Just, 1);
          heff_drop(v_xs_2410);
          v_x4_2414 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        break;
      }
      case TAG_False: {
        heff_drop(v_i_249);
        heff_drop_cell(v_ru_24t_248_24Just, 1);
        heff_drop(v_xs_2410);
        v_x4_2414 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2416;
    switch (heff_tag_of(v_x4_2414)) {
    case TAG_Nothing: {
      heff_drop(v_c_240);
      v_t_2416 = ((V)&g_heff_2epsurface_2erecordField_24s464605383x1219605104_str0);
      break;
    }
    case TAG_Just: {
      V v_d_2415 = heff_field(v_x4_2414, 0);
      heff_take_n(v_x4_2414, 1ULL, 1);
      v_t_2416 = heff_strAppend(((V)&g_heff_2epsurface_2erecordField_24s464605383x1219605104_str1), (g_heff_2epsurface_2eelF_24s733037190x667378878(v_c_240, MK_INT(0LL), heff_get(heff_dup(v_acc_242), LBL_names), v_d_2415)));
      break;
    }
    default: heff_nomatch(v_x4_2414);
    }
    V v_t_2417 = heff_strAppend(v_l_244, heff_strAppend(((V)&g_heff_2epsurface_2erecordField_24s464605383x1219605104_str2), heff_strAppend(v_t_247, v_t_2416)));
    V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_t_2419 = (g_prelude_2econcatList(heff_get(v_acc_242, LBL_out), v_t_2418));
    return heff_rec(2, shape_names__out, (V[]){v_t_246, v_t_2419});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2epsurface_2erecordField_24s464605383x1219605104_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2erecordField_24s464605383x1219605104(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {84, 104, 101, 111, 114, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 124, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str12 = {{0x80000000u, K_STR, 0}, 7, 7, {100, 97, 116, 97, 32, 123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str14 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str15 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str16 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str17 = {{0x80000000u, K_STR, 0}, 6, 6, {65, 114, 114, 97, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str20 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str21 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str22 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str23 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str24 = {{0x80000000u, K_STR, 0}, 5, 5, {85, 73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str25 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str26 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str27 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2epsurface_2etyF_24s1319128358x1023081884_str28 = {{0x80000000u, K_STR, 0}, 7, 7, {70, 108, 111, 97, 116, 51, 50}};
V g_heff_2epsurface_2etyF_24s1319128358x1023081884_lam0(V self, V *args);
V g_heff_2epsurface_2etyF_24s1319128358x1023081884_lam2(V self, V *args);
V g_heff_2epsurface_2etyF_24s1319128358x1023081884_lam1(V self, V *args);
Clo g_heff_2epsurface_2etyF_24s1319128358x1023081884_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2etyF_24s1319128358x1023081884_entry, 4, 0};

V g_heff_2epsurface_2etyF_24s1319128358x1023081884(V v_c_240, V v_p_241, V v_xs_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    V v_it1_244 = heff_field(v_t_243, 0);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str1);
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    HEFF_LAST return g_heff_2epsurface_2eelF_24s733037190x667378878(v_c_240, v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_t_243, 0);
    V v_dom_247 = heff_field(v_t_243, 1);
    V v_cod_248 = heff_field(v_t_243, 2);
    V v_implicit_249 = heff_field(v_t_243, 3);
    V v_dflt_2410 = heff_field(v_t_243, 4);
    V v_s_2412;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      v_s_2412 = (g_heff_2epsurface_2earrowStr_24s2117734577x852423791(v_c_240, v_xs_242, v_level_246, v_dom_247, heff_dup(v_cod_248), v_implicit_249));
      break;
    }
    case TAG_Just: {
      V v_d_2411 = heff_field(v_dflt_2410, 0);
      v_s_2412 = (g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238(v_c_240, v_xs_242, v_dom_247, heff_dup(v_cod_248), heff_dup(v_d_2411)));
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    V v_t_2413 = heff_intLe(MK_INT(1LL), v_p_241);
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str2), heff_strAppend(v_s_2412, ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str3)));
    }
    case TAG_False: {
      return v_s_2412;
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  case TAG_SRecord: {
    V v_fs_2415 = heff_field(v_t_243, 1);
    V v_ds_2416 = heff_field(v_t_243, 2);
    heff_drop(v_p_241);
    V v_t_2417 = heff_arrayToList(heff_get(heff_dup(v_fs_2415), LBL_keys));
    V v_t_2418 = heff_arrayToList(heff_get(heff_dup(v_fs_2415), LBL_values));
    V v_fs_2419 = (g_heff_2edict_2ezipKV(v_t_2417, v_t_2418));
    V v_t_2420 = heff_rec(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2423 = ({ V a_0 = heff_clo(g_heff_2epsurface_2etyF_24s1319128358x1023081884_lam0, 2, 2, (V[]){v_c_240, heff_dup(v_ds_2416)}); V a_1 = v_t_2420; V a_2 = v_fs_2419; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2419); r_; });
    V v_x2_2424 = heff_get(v_acc_2423, LBL_out);
    V v_t_2427;
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nil: {
      v_t_2427 = ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_xs_2426 = heff_field(v_x2_2424, 1);
      heff_take_n(v_x2_2424, 3ULL, 2);
      v_t_2427 = ({ V a_0 = ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str5); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2424);
    }
    return heff_strAppend(((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str6), heff_strAppend(v_t_2427, ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str7)));
  }
  case TAG_SSum: {
    V v_vs_2428 = heff_field(v_t_243, 0);
    heff_drop(v_p_241);
    V v_t_2429 = heff_arrayToList(heff_get(heff_dup(v_vs_2428), LBL_keys));
    V v_t_2430 = heff_arrayToList(heff_get(heff_dup(v_vs_2428), LBL_values));
    V v_t_2431 = (g_heff_2edict_2ezipKV(v_t_2429, v_t_2430));
    V v_x2_2439 = (g_prelude_2emap(heff_clo(g_heff_2epsurface_2etyF_24s1319128358x1023081884_lam1, 1, 2, (V[]){v_c_240, v_xs_242}), v_t_2431));
    V v_t_2442;
    switch (heff_tag_of(v_x2_2439)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_x2_2439, 0);
      V v_xs_2441 = heff_field(v_x2_2439, 1);
      heff_take_n(v_x2_2439, 3ULL, 2);
      v_t_2442 = ({ V a_0 = ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str11); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2439);
    }
    return heff_strAppend(((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str12), heff_strAppend(v_t_2442, ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str13)));
  }
  case TAG_SIsTy: {
    V v_t2_2443 = heff_field(v_t_243, 0);
    V t_0 = v_c_240;
    V t_1 = v_p_241;
    V t_2 = v_xs_242;
    V t_3 = v_t2_2443;
    v_c_240 = t_0;
    v_p_241 = t_1;
    v_xs_242 = t_2;
    v_t_243 = t_3;
    goto top;
  }
  case TAG_SPrimInt: {
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str14);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str15);
  }
  case TAG_SPrimString: {
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str16);
  }
  case TAG_SPrimArray: {
    V v_a_2444 = heff_field(v_t_243, 0);
    V v_s_2445 = heff_strAppend(((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str17), (g_heff_2epsurface_2etyF_24s1319128358x1023081884(v_c_240, MK_INT(2LL), v_xs_242, v_a_2444)));
    V v_t_2446 = heff_intLe(MK_INT(2LL), v_p_241);
    switch (heff_tag_of(v_t_2446)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str18), heff_strAppend(v_s_2445, ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str19)));
    }
    case TAG_False: {
      return v_s_2445;
    }
    default: return heff_nomatch(v_t_2446);
    }
  }
  case TAG_SFixed: {
    V v_w_2447 = heff_field(v_t_243, 0);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2447)) {
    case TAG_I8: {
      return ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str20);
    }
    case TAG_I16: {
      return ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str21);
    }
    case TAG_I32: {
      return ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str22);
    }
    case TAG_I64: {
      return ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str23);
    }
    case TAG_U8: {
      return ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str24);
    }
    case TAG_U16: {
      return ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str25);
    }
    case TAG_U32: {
      return ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str26);
    }
    case TAG_U64: {
      return ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str27);
    }
    case TAG_F32: {
      return ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str28);
    }
    default: return heff_nomatch(v_w_2447);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2epsurface_2etyF_24s1319128358x1023081884_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2epsurface_2etyF_24s1319128358x1023081884(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2epsurface_2etyF_24s1319128358x1023081884_lam0(V self, V *args) {
  V v_acc_2421 = args[0];
  V v_f_2422 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_ds_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2epsurface_2erecordField_24s464605383x1219605104(v_c_240, v_ds_2416, v_acc_2421, v_f_2422));
}
V g_heff_2epsurface_2etyF_24s1319128358x1023081884_lam2(V self, V *args) {
  V v_t2_2435 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_c_240; V a_1 = MK_INT(2LL); V a_2 = v_xs_242; V a_3 = v_t2_2435; V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, a_3)); heff_drop(v_t2_2435); r_; });
}
V g_heff_2epsurface_2etyF_24s1319128358x1023081884_lam1(V self, V *args) {
  V v_v_2432 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2432)) {
  case TAG_MkPair: {
    V v_t_2433 = heff_field(v_v_2432, 0);
    V v_ts_2434 = heff_field(v_v_2432, 1);
    V v_ru_24v_2432_24MkPair = heff_take_reuse_n(v_v_2432, 3ULL, 2);
    V v_x2_2436 = heff_tag_at(v_ru_24v_2432_24MkPair, TAG_Cons, 2, (V[]){v_t_2433, (g_prelude_2emap(heff_clo(g_heff_2epsurface_2etyF_24s1319128358x1023081884_lam2, 1, 2, (V[]){v_c_240, v_xs_242}), heff_arrayToList(v_ts_2434)))});
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_Nil: {
      return ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str8);
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_xs_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2epsurface_2etyF_24s1319128358x1023081884_str9); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_v_2432);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eargStrs_24s1323800423x1706881613_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2eargStrs_24s1323800423x1706881613_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 58, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eargStrs_24s1323800423x1706881613_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2epsurface_2eargStrs_24s1323800423x1706881613_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eargStrs_24s1323800423x1706881613_entry, 5, 0};

V g_heff_2epsurface_2eargStrs_24s1323800423x1706881613(V v_c_240, V v_xs_241, V v_names_242, V v_i_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_xs_241);
    heff_drop(v_names_242);
    heff_drop(v_i_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x6_244, 0);
    V v_rest_246 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    V v_t_247 = (g_heff_2epsurface_2eimplicitName(heff_dup(v_names_242), heff_dup(v_i_243), heff_dup(v_a_245)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      V v_t_248 = (g_heff_2epsurface_2eelF_24s733037190x667378878(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_241), v_a_245));
      return heff_tag_at(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_heff_2epsurface_2eargStrs_24s1323800423x1706881613(v_c_240, v_xs_241, v_names_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_rest_246))});
    }
    case TAG_Just: {
      V v_imp_249 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      heff_drop(v_a_245);
      V v_t_2410 = heff_get(heff_get(heff_dup(v_c_240), LBL_im), LBL_hide);
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x6_244_24Cons, 2);
        heff_drop(v_imp_249);
        V t_0 = v_c_240;
        V t_1 = v_xs_241;
        V t_2 = v_names_242;
        V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
        V t_4 = v_rest_246;
        v_c_240 = t_0;
        v_xs_241 = t_1;
        v_names_242 = t_2;
        v_i_243 = t_3;
        v_x6_244 = t_4;
        goto top;
      }
      case TAG_False: {
        V v_t_2411 = (g_heff_2epsurface_2eelF_24s733037190x667378878(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), heff_get(heff_dup(v_imp_249), LBL_inner)));
        V v_t_2412 = heff_strAppend(((V)&g_heff_2epsurface_2eargStrs_24s1323800423x1706881613_str0), heff_strAppend(heff_get(v_imp_249, LBL_n), heff_strAppend(((V)&g_heff_2epsurface_2eargStrs_24s1323800423x1706881613_str1), heff_strAppend(v_t_2411, ((V)&g_heff_2epsurface_2eargStrs_24s1323800423x1706881613_str2)))));
        return heff_tag_at(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2412, (g_heff_2epsurface_2eargStrs_24s1323800423x1706881613(v_c_240, v_xs_241, v_names_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_rest_246))});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2epsurface_2eargStrs_24s1323800423x1706881613_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2eargStrs_24s1323800423x1706881613(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappPlain_24s659022660x920682911_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappPlain_24s659022660x920682911_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappPlain_24s659022660x920682911_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2epsurface_2eappPlain_24s659022660x920682911_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eappPlain_24s659022660x920682911_entry, 4, 0};

V g_heff_2epsurface_2eappPlain_24s659022660x920682911(V v_c_240, V v_p_241, V v_xs_242, V v_sp_243) {
top: ;
  V v_headArg_244 = (g_heff_2epsurface_2eelF_24s733037190x667378878(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_242), heff_get(heff_dup(v_sp_243), LBL_head)));
  V v_t_245 = heff_get(heff_get(heff_dup(v_c_240), LBL_im), LBL_names);
  V v_t_246 = heff_tr(heff_apply(v_t_245, 2, (V[]){heff_dup(v_xs_242), heff_get(heff_dup(v_sp_243), LBL_head)}));
  V v_args_247 = (g_heff_2epsurface_2eargStrs_24s1323800423x1706881613(heff_dup(v_c_240), heff_dup(v_xs_242), v_t_246, MK_INT(0LL), heff_get(heff_dup(v_sp_243), LBL_args)));
  V v_headAlone_248 = (g_heff_2epsurface_2eelF_24s733037190x667378878(v_c_240, heff_dup(v_p_241), v_xs_242, heff_get(v_sp_243, LBL_head)));
  switch (heff_tag_of(v_args_247)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    heff_drop(v_headArg_244);
    return v_headAlone_248;
  }
  case TAG_Cons: {
    heff_drop(v_headAlone_248);
    V v_s_2411 = ({ V a_0 = ((V)&g_heff_2epsurface_2eappPlain_24s659022660x920682911_str0); V a_1 = v_headArg_244; V a_2 = v_args_247; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop_tag(v_args_247, 2); r_; });
    V v_t_2412 = heff_intLe(MK_INT(2LL), v_p_241);
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2epsurface_2eappPlain_24s659022660x920682911_str1), heff_strAppend(v_s_2411, ((V)&g_heff_2epsurface_2eappPlain_24s659022660x920682911_str2)));
    }
    case TAG_False: {
      return v_s_2411;
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_args_247);
  }
}
V g_heff_2epsurface_2eappPlain_24s659022660x920682911_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2eappPlain_24s659022660x920682911(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str15 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str17 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str18 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str19 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str20 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str21 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eappStr_24s929057901x1904324530_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2epsurface_2eappStr_24s929057901x1904324530_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eappStr_24s929057901x1904324530_entry, 4, 0};

V g_heff_2epsurface_2eappStr_24s929057901x1904324530(V v_c_240, V v_p_241, V v_xs_242, V v_t_243) {
top: ;
  V v_t_244 = (g_heff_2epsurface_2espineGo(heff_dup(v_t_243), NTAG(TAG_Nil)));
  V v_it_245 = (g_heff_2epsurface_2eopApp(v_c_240, v_xs_242, v_t_244));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    V v_t_246 = (g_heff_2epsurface_2espineGo(v_t_243, NTAG(TAG_Nil)));
    HEFF_LAST return g_heff_2epsurface_2eappPlain_24s659022660x920682911(v_c_240, v_p_241, v_xs_242, v_t_246);
  }
  case TAG_Just: {
    V v_it1_247 = heff_field(v_it_245, 0);
    heff_take_n(v_it_245, 1ULL, 1);
    switch (heff_tag_of(v_it1_247)) {
    case TAG_MkPair: {
      V v_l_248 = heff_field(v_it1_247, 0);
      V v_r2_249 = heff_field(v_it1_247, 1);
      heff_take_n(v_it1_247, 3ULL, 2);
      V v_t_2410 = (g_heff_2epsurface_2eelF_24s733037190x667378878(heff_dup(v_c_240), MK_INT(1LL), heff_dup(v_xs_242), v_l_248));
      V v_t_2411 = (g_heff_2epsurface_2espineGo(v_t_243, NTAG(TAG_Nil)));
      V v_x1_2412 = heff_get(v_t_2411, LBL_head);
      V v_t_2446;
      switch (heff_tag_of(v_x1_2412)) {
      case TAG_SLocal: {
        heff_take_n(v_x1_2412, 0ULL, 1);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str0);
        break;
      }
      case TAG_SGlobal: {
        V v_x_2414 = heff_field(v_x1_2412, 0);
        heff_take_n(v_x1_2412, 1ULL, 1);
        v_t_2446 = v_x_2414;
        break;
      }
      case TAG_SCode: {
        heff_take_n(v_x1_2412, 0ULL, 1);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str1);
        break;
      }
      case TAG_SApp: {
        heff_take_n(v_x1_2412, 0ULL, 2);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str2);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_x1_2412, 0ULL, 2);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str3);
        break;
      }
      case TAG_SCons: {
        heff_take_n(v_x1_2412, 0ULL, 1);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str4);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_x1_2412, 0ULL, 2);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str5);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_x1_2412, 0ULL, 2);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str6);
        break;
      }
      case TAG_SMatch: {
        heff_take_n(v_x1_2412, 0ULL, 2);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str7);
        break;
      }
      case TAG_SSpecialize: {
        heff_take_n(v_x1_2412, 0ULL, 3);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str8);
        break;
      }
      case TAG_SIs: {
        heff_take_n(v_x1_2412, 0ULL, 1);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str9);
        break;
      }
      case TAG_SOpaque: {
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str10);
        break;
      }
      case TAG_SAbandon: {
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str11);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_x1_2412, 0ULL, 1);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str12);
        break;
      }
      case TAG_SFix: {
        heff_take_n(v_x1_2412, 0ULL, 2);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str13);
        break;
      }
      case TAG_SImplicit: {
        heff_take_n(v_x1_2412, 0ULL, 2);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str14);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_x1_2412, 0ULL, 1);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str15);
        break;
      }
      case TAG_SMetaApp: {
        heff_take_n(v_x1_2412, 0ULL, 3);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str16);
        break;
      }
      case TAG_SLitInt: {
        heff_take_n(v_x1_2412, 0ULL, 1);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str17);
        break;
      }
      case TAG_SLitFloat: {
        heff_take_n(v_x1_2412, 0ULL, 1);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str18);
        break;
      }
      case TAG_SLitString: {
        heff_take_n(v_x1_2412, 0ULL, 1);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str19);
        break;
      }
      case TAG_SLitFixed: {
        heff_take_n(v_x1_2412, 0ULL, 2);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str20);
        break;
      }
      case TAG_SLitFloat32: {
        heff_take_n(v_x1_2412, 0ULL, 1);
        v_t_2446 = ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str21);
        break;
      }
      default: heff_nomatch(v_x1_2412);
      }
      V v_s_2447 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str22), heff_strAppend(v_t_2446, heff_strAppend(((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str23), (g_heff_2epsurface_2eelF_24s733037190x667378878(v_c_240, MK_INT(1LL), v_xs_242, v_r2_249))))));
      V v_t_2448 = heff_intLe(MK_INT(1LL), v_p_241);
      switch (heff_tag_of(v_t_2448)) {
      case TAG_True: {
        return heff_strAppend(((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str24), heff_strAppend(v_s_2447, ((V)&g_heff_2epsurface_2eappStr_24s929057901x1904324530_str25)));
      }
      case TAG_False: {
        return v_s_2447;
      }
      default: return heff_nomatch(v_t_2448);
      }
    }
    default: return heff_nomatch(v_it1_247);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2epsurface_2eappStr_24s929057901x1904324530_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2eappStr_24s929057901x1904324530(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elamStr_24s2129544944x962470242_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elamStr_24s2129544944x962470242_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elamStr_24s2129544944x962470242_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2elamStr_24s2129544944x962470242_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 45, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elamStr_24s2129544944x962470242_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2elamStr_24s2129544944x962470242_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2epsurface_2elamStr_24s2129544944x962470242_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2elamStr_24s2129544944x962470242_entry, 4, 0};

V g_heff_2epsurface_2elamStr_24s2129544944x962470242(V v_c_240, V v_p_241, V v_xs_242, V v_l_243) {
top: ;
  V v_t_244 = heff_get(heff_dup(v_l_243), LBL_binders);
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2epsurface_2elamStr_24s2129544944x962470242_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_t_244, 0);
    V v_xs_246 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2epsurface_2elamStr_24s2129544944x962470242_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_s_248 = heff_strAppend(((V)&g_heff_2epsurface_2elamStr_24s2129544944x962470242_str2), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2epsurface_2elamStr_24s2129544944x962470242_str3), (g_heff_2epsurface_2eelF_24s733037190x667378878(v_c_240, MK_INT(0LL), heff_get(heff_dup(v_l_243), LBL_names), heff_get(v_l_243, LBL_body))))));
  V v_t_249 = heff_intLe(MK_INT(1LL), v_p_241);
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    return heff_strAppend(((V)&g_heff_2epsurface_2elamStr_24s2129544944x962470242_str4), heff_strAppend(v_s_248, ((V)&g_heff_2epsurface_2elamStr_24s2129544944x962470242_str5)));
  }
  case TAG_False: {
    return v_s_248;
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2epsurface_2elamStr_24s2129544944x962470242_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2epsurface_2elamStr_24s2129544944x962470242(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 45, 62, 32}};
Clo g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_entry, 3, 0};

V g_heff_2epsurface_2ealtLine_24s1348772780x2097554404(V v_inner_240, V v_xs_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_t_243 = heff_field(v_x4_242, 0);
    V v_x42_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_244)) {
    case TAG_MkPair: {
      V v_ys_245 = heff_field(v_x42_244, 0);
      V v_body_246 = heff_field(v_x42_244, 1);
      V v_x2_247 = (g_prelude_2ereplicate(heff_get(heff_dup(v_inner_240), LBL_indent), ((V)&g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_str0)));
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2411 = ({ V a_0 = ((V)&g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_str3); V a_1 = heff_dup(v_t_243); V b_2 = heff_arrayToList(heff_dup(v_ys_245)); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_xs_2412 = (g_prelude_2efoldl_24s1546929672x1472202881(v_xs_241, heff_arrayToList(heff_dup(v_ys_245))));
      V v_t_2413 = (g_heff_2epsurface_2eelF_24s733037190x667378878(v_inner_240, MK_INT(0LL), v_xs_2412, heff_dup(v_body_246)));
      return heff_strAppend(((V)&g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_str4), heff_strAppend(v_t_2410, heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_str5), v_t_2413))));
    }
    default: return heff_nomatch(v_x42_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2epsurface_2ealtLine_24s1348772780x2097554404_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2epsurface_2ealtLine_24s1348772780x2097554404(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str17 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str18 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 97, 115, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str19 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str22 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 126, 32, 123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str23 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str24 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str27 = {{0x80000000u, K_STR, 0}, 8, 8, {60, 111, 112, 97, 113, 117, 101, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str28 = {{0x80000000u, K_STR, 0}, 7, 7, {97, 98, 97, 110, 100, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str29 = {{0x80000000u, K_STR, 0}, 7, 7, {60, 108, 111, 99, 97, 108, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str30 = {{0x80000000u, K_STR, 0}, 11, 11, {60, 112, 114, 105, 109, 105, 116, 105, 118, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str33 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s733037190x667378878_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
V g_heff_2epsurface_2eelF_24s733037190x667378878_lam0(V self, V *args);
V g_heff_2epsurface_2eelF_24s733037190x667378878_lam1(V self, V *args);
V g_heff_2epsurface_2eelF_24s733037190x667378878_lam2(V self, V *args);
V g_heff_2epsurface_2eelF_24s733037190x667378878_lam3(V self, V *args);
Clo g_heff_2epsurface_2eelF_24s733037190x667378878_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eelF_24s733037190x667378878_entry, 4, 0};

V g_heff_2epsurface_2eelF_24s733037190x667378878(V v_c_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    return (g_heff_2epsurface_2elocalName(v_xs_242, v_i_244));
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_246 = (g_heff_2epsurface_2eisOperator(heff_dup(v_x_245)));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str0), heff_strAppend(v_x_245, ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str1)));
    }
    case TAG_False: {
      return v_x_245;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_SCode: {
    V v_t_247 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    return ({ V a_0 = v_c_240; V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_247; V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  }
  case TAG_SApp: {
    V v_f_248 = heff_field(v_e_243, 0);
    V v_a_249 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    HEFF_LAST return g_heff_2epsurface_2eappStr_24s929057901x1904324530(v_c_240, v_p_241, v_xs_242, heff_tag_at(v_ru_24e_243_24SApp, TAG_SApp, 2, (V[]){v_f_248, v_a_249}));
  }
  case TAG_SLam: {
    V v_t_2410 = heff_field(v_e_243, 0);
    V v_b_2411 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SLam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2412 = (g_heff_2epsurface_2elambdas(heff_dup(v_xs_242), NTAG(TAG_Nil), heff_tag_at(v_ru_24e_243_24SLam, TAG_SLam, 2, (V[]){v_t_2410, v_b_2411})));
    return ({ V a_0 = v_c_240; V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_2412; V r_ = (g_heff_2epsurface_2elamStr_24s2129544944x962470242(a_0, a_1, a_2, a_3)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SCons: {
    V v_d_2413 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_p_241);
    V v_t_2414 = heff_arrayToList(heff_get(heff_dup(v_d_2413), LBL_keys));
    V v_t_2415 = heff_arrayToList(heff_get(v_d_2413, LBL_values));
    V v_t_2416 = (g_heff_2edict_2ezipKV(v_t_2414, v_t_2415));
    V v_x2_2420 = (g_prelude_2emap(heff_clo(g_heff_2epsurface_2eelF_24s733037190x667378878_lam0, 1, 2, (V[]){v_c_240, v_xs_242}), v_t_2416));
    V v_t_2423;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nil: {
      v_t_2423 = ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_xs_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      v_t_2423 = ({ V a_0 = ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str4); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str5), heff_strAppend(v_t_2423, ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str6)));
  }
  case TAG_SProj: {
    V v_e2_2424 = heff_field(v_e_243, 0);
    V v_l_2425 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    heff_drop(v_p_241);
    V v_t_2426 = (g_heff_2epsurface_2eelF_24s733037190x667378878(v_c_240, MK_INT(2LL), v_xs_242, v_e2_2424));
    return heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str7), v_l_2425));
  }
  case TAG_STag: {
    V v_x_2427 = heff_dup(heff_field(v_e_243, 0));
    V v_ts_2428 = heff_dup(heff_field(v_e_243, 1));
    V v_t_2429 = (g_heff_2epsurface_2elistItems(v_e_243));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nothing: {
      V v_t_2430 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_ts_2428)); V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2431 = heff_intEq(v_t_2430, MK_INT(0LL));
      switch (heff_tag_of(v_t_2431)) {
      case TAG_True: {
        heff_drop(v_c_240);
        heff_drop(v_p_241);
        heff_drop(v_xs_242);
        heff_drop(v_ts_2428);
        return v_x_2427;
      }
      case TAG_False: {
        V v_x2_2433 = heff_tag(TAG_Cons, 2, (V[]){v_x_2427, (g_prelude_2emap(heff_clo(g_heff_2epsurface_2eelF_24s733037190x667378878_lam1, 1, 2, (V[]){v_c_240, v_xs_242}), heff_arrayToList(v_ts_2428)))});
        V v_s_2436;
        switch (heff_tag_of(v_x2_2433)) {
        case TAG_Nil: {
          v_s_2436 = ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2434 = heff_field(v_x2_2433, 0);
          V v_xs_2435 = heff_field(v_x2_2433, 1);
          heff_take_n(v_x2_2433, 3ULL, 2);
          v_s_2436 = ({ V a_0 = ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str9); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2433);
        }
        V v_t_2437 = heff_intLe(MK_INT(2LL), v_p_241);
        switch (heff_tag_of(v_t_2437)) {
        case TAG_True: {
          return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str10), heff_strAppend(v_s_2436, ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str11)));
        }
        case TAG_False: {
          return v_s_2436;
        }
        default: return heff_nomatch(v_t_2437);
        }
      }
      default: return heff_nomatch(v_t_2431);
      }
    }
    case TAG_Just: {
      V v_items_2438 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      heff_drop(v_p_241);
      heff_drop(v_x_2427);
      heff_drop(v_ts_2428);
      V v_x2_2440 = (g_prelude_2emap(heff_clo(g_heff_2epsurface_2eelF_24s733037190x667378878_lam2, 1, 2, (V[]){v_c_240, v_xs_242}), v_items_2438));
      V v_t_2443;
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_Nil: {
        v_t_2443 = ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_xs_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        v_t_2443 = ({ V a_0 = ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str13); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2440);
      }
      return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str14), heff_strAppend(v_t_2443, ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str15)));
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  case TAG_SMatch: {
    V v_s_2444 = heff_field(v_e_243, 0);
    V v_cases_2445 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_2446 = (g_heff_2epsurface_2eelF_24s733037190x667378878(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_242), v_s_2444));
    V v_t_2447 = heff_arrayToList(heff_get(heff_dup(v_cases_2445), LBL_keys));
    V v_t_2448 = heff_arrayToList(heff_get(v_cases_2445, LBL_values));
    V v_t_2449 = (g_heff_2edict_2ezipKV(v_t_2447, v_t_2448));
    V v_x2_2453 = (g_prelude_2emap(heff_clo(g_heff_2epsurface_2eelF_24s733037190x667378878_lam3, 1, 2, (V[]){v_c_240, v_xs_242}), v_t_2449));
    V v_t_2456;
    switch (heff_tag_of(v_x2_2453)) {
    case TAG_Nil: {
      v_t_2456 = ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2454 = heff_field(v_x2_2453, 0);
      V v_xs_2455 = heff_field(v_x2_2453, 1);
      heff_take_n(v_x2_2453, 3ULL, 2);
      v_t_2456 = ({ V a_0 = ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str17); V a_1 = v_x_2454; V a_2 = v_xs_2455; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2455); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2453);
    }
    V v_s_2457 = heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str18), heff_strAppend(v_t_2446, heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str19), v_t_2456)));
    V v_t_2458 = heff_intLe(MK_INT(1LL), v_p_241);
    switch (heff_tag_of(v_t_2458)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str20), heff_strAppend(v_s_2457, ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str21)));
    }
    case TAG_False: {
      return v_s_2457;
    }
    default: return heff_nomatch(v_t_2458);
    }
  }
  case TAG_SSpecialize: {
    V v_e2_2459 = heff_field(v_e_243, 0);
    V v_x_2460 = heff_field(v_e_243, 1);
    V v_v_2461 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_t_2462 = (g_heff_2epsurface_2eelF_24s733037190x667378878(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_242), v_e2_2459));
    V v_t_2463 = (g_heff_2epsurface_2eelF_24s733037190x667378878(v_c_240, MK_INT(0LL), v_xs_242, v_v_2461));
    V v_s_2464 = heff_strAppend(v_t_2462, heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str22), heff_strAppend(v_x_2460, heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str23), heff_strAppend(v_t_2463, ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str24))))));
    V v_t_2465 = heff_intLe(MK_INT(1LL), v_p_241);
    switch (heff_tag_of(v_t_2465)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str25), heff_strAppend(v_s_2464, ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str26)));
    }
    case TAG_False: {
      return v_s_2464;
    }
    default: return heff_nomatch(v_t_2465);
    }
  }
  case TAG_SIs: {
    V v_e2_2466 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_p_241;
    V t_2 = v_xs_242;
    V t_3 = v_e2_2466;
    v_c_240 = t_0;
    v_p_241 = t_1;
    v_xs_242 = t_2;
    v_e_243 = t_3;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str27);
  }
  case TAG_SAbandon: {
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str28);
  }
  case TAG_SRec: {
    V v_e2_2467 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_p_241;
    V t_2 = v_xs_242;
    V t_3 = v_e2_2467;
    v_c_240 = t_0;
    v_p_241 = t_1;
    v_xs_242 = t_2;
    v_e_243 = t_3;
    goto top;
  }
  case TAG_SFix: {
    V v_it2_2469 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_it2_2469)) {
    case TAG_MkAbs: {
      V v_x_2470 = heff_field(v_it2_2469, 0);
      heff_take_n(v_it2_2469, 1ULL, 2);
      return v_x_2470;
    }
    case TAG_AbsConst: {
      heff_take_n(v_it2_2469, 0ULL, 1);
      return ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str29);
    }
    default: return heff_nomatch(v_it2_2469);
    }
  }
  case TAG_SImplicit: {
    V v_e2_2474 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    V t_0 = v_c_240;
    V t_1 = v_p_241;
    V t_2 = v_xs_242;
    V t_3 = v_e2_2474;
    v_c_240 = t_0;
    v_p_241 = t_1;
    v_xs_242 = t_2;
    v_e_243 = t_3;
    goto top;
  }
  case TAG_SPrim: {
    V v_x_2475 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str30), heff_strAppend(v_x_2475, ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str31)));
  }
  case TAG_SMetaApp: {
    V v_m_2476 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 3);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str32), heff_intShow(v_m_2476));
  }
  case TAG_SLitInt: {
    V v_i_2479 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_i_2479);
  }
  case TAG_SLitFloat: {
    V v_x_2480 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2480);
  }
  case TAG_SLitString: {
    V v_s_2481 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2482 = (g_heff_2epsurface_2equoteGo(v_s_2481, MK_INT(0LL), ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str33)));
    return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str34), heff_strAppend(v_t_2482, ((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str35)));
  }
  case TAG_SLitFixed: {
    V v_n_2484 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_n_2484);
  }
  case TAG_SLitFloat32: {
    V v_x_2485 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2485);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2epsurface_2eelF_24s733037190x667378878_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2eelF_24s733037190x667378878(a[0], a[1], a[2], a[3]);
}
V g_heff_2epsurface_2eelF_24s733037190x667378878_lam0(V self, V *args) {
  V v_f_2417 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2417)) {
  case TAG_MkPair: {
    V v_l_2418 = heff_field(v_f_2417, 0);
    V v_e_2419 = heff_field(v_f_2417, 1);
    heff_take_n(v_f_2417, 3ULL, 2);
    return heff_strAppend(v_l_2418, heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s733037190x667378878_str2), (g_heff_2epsurface_2eelF_24s733037190x667378878(v_c_240, MK_INT(0LL), v_xs_242, v_e_2419))));
  }
  default: return heff_nomatch(v_f_2417);
  }
}
V g_heff_2epsurface_2eelF_24s733037190x667378878_lam1(V self, V *args) {
  V v_a_2432 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2epsurface_2eelF_24s733037190x667378878(v_c_240, MK_INT(2LL), v_xs_242, v_a_2432));
}
V g_heff_2epsurface_2eelF_24s733037190x667378878_lam2(V self, V *args) {
  V v_a_2439 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2epsurface_2eelF_24s733037190x667378878(v_c_240, MK_INT(0LL), v_xs_242, v_a_2439));
}
V g_heff_2epsurface_2eelF_24s733037190x667378878_lam3(V self, V *args) {
  V v_alt_2450 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = heff_intAdd(heff_get(heff_dup(v_c_240), LBL_indent), MK_INT(2LL));
  V v_t_2452 = heff_rec(2, shape_im__indent, (V[]){heff_get(v_c_240, LBL_im), v_t_2451});
  return ({ V a_0 = v_t_2452; V a_1 = v_xs_242; V a_2 = v_alt_2450; V r_ = (g_heff_2epsurface_2ealtLine_24s1348772780x2097554404(a_0, a_1, a_2)); heff_drop(v_alt_2450); r_; });
}
Clo g_heff_2epsurface_2eprimitiveOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eprimitiveOf_entry, 1, 0};

V g_heff_2epsurface_2eprimitiveOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCode: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return NTAG(TAG_Nothing);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SImplicit: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrim: {
    V v_x_2424 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SPrim = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at(v_ru_24x1_240_24SPrim, TAG_Just, 1, (V[]){v_x_2424});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2epsurface_2eprimitiveOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2eprimitiveOf(a[0]);
}
Clo g_heff_2epsurface_2estripIs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2estripIs_entry, 1, 0};

V g_heff_2epsurface_2estripIs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_SLocal: {
    return v_e_240;
  }
  case TAG_SGlobal: {
    return v_e_240;
  }
  case TAG_SCode: {
    return v_e_240;
  }
  case TAG_SApp: {
    return v_e_240;
  }
  case TAG_SLam: {
    return v_e_240;
  }
  case TAG_SCons: {
    return v_e_240;
  }
  case TAG_SProj: {
    return v_e_240;
  }
  case TAG_STag: {
    return v_e_240;
  }
  case TAG_SMatch: {
    return v_e_240;
  }
  case TAG_SSpecialize: {
    return v_e_240;
  }
  case TAG_SIs: {
    V v_e1_2418 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    V t_0 = v_e1_2418;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return v_e_240;
  }
  case TAG_SAbandon: {
    return v_e_240;
  }
  case TAG_SRec: {
    return v_e_240;
  }
  case TAG_SFix: {
    return v_e_240;
  }
  case TAG_SImplicit: {
    return v_e_240;
  }
  case TAG_SPrim: {
    return v_e_240;
  }
  case TAG_SMetaApp: {
    return v_e_240;
  }
  case TAG_SLitInt: {
    return v_e_240;
  }
  case TAG_SLitFloat: {
    return v_e_240;
  }
  case TAG_SLitString: {
    return v_e_240;
  }
  case TAG_SLitFixed: {
    return v_e_240;
  }
  case TAG_SLitFloat32: {
    return v_e_240;
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2epsurface_2estripIs_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2estripIs(a[0]);
}
Clo g_heff_2epsurface_2eunIsTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eunIsTy_entry, 1, 0};

V g_heff_2epsurface_2eunIsTy(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_SU: {
    return v_d_240;
  }
  case TAG_SDecode: {
    return v_d_240;
  }
  case TAG_SFunction: {
    return v_d_240;
  }
  case TAG_SRecord: {
    return v_d_240;
  }
  case TAG_SSum: {
    return v_d_240;
  }
  case TAG_SIsTy: {
    V v_d1_2412 = heff_field(v_d_240, 0);
    heff_take_n(v_d_240, 1ULL, 1);
    V t_0 = v_d1_2412;
    v_d_240 = t_0;
    goto top;
  }
  case TAG_SPrimInt: {
    return v_d_240;
  }
  case TAG_SPrimFloat: {
    return v_d_240;
  }
  case TAG_SPrimString: {
    return v_d_240;
  }
  case TAG_SPrimArray: {
    return v_d_240;
  }
  case TAG_SFixed: {
    return v_d_240;
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2epsurface_2eunIsTy_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2eunIsTy(a[0]);
}
Clo g_heff_2epsurface_2eformerAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eformerAt_entry, 4, 0};

V g_heff_2epsurface_2eformerAt(V v_params_240, V v_ns_241, V v_b_242, V v_large_243) {
top: ;
  switch (heff_tag_of(v_b_242)) {
  case TAG_SLocal: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SGlobal: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SCode: {
    V v_d_246 = heff_field(v_b_242, 0);
    heff_take_n(v_b_242, 1ULL, 1);
    V v_t_247 = (g_heff_2epsurface_2eunIsTy(v_d_246));
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, v_t_247, v_large_243});
  }
  case TAG_SApp: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLam: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SCons: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SProj: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_STag: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SMatch: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SSpecialize: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SIs: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SOpaque: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SAbandon: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SRec: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SFix: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SImplicit: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SPrim: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SMetaApp: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitInt: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitFloat: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitString: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitFixed: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitFloat32: {
    return heff_rec(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  default: return heff_nomatch(v_b_242);
  }
}
V g_heff_2epsurface_2eformerAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2eformerAt(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {84, 104, 101, 111, 114, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 124, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str12 = {{0x80000000u, K_STR, 0}, 7, 7, {100, 97, 116, 97, 32, 123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str14 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str15 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str16 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str17 = {{0x80000000u, K_STR, 0}, 6, 6, {65, 114, 114, 97, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str20 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str21 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str22 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str23 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str24 = {{0x80000000u, K_STR, 0}, 5, 5, {85, 73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str25 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str26 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str27 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2epsurface_2etyF_24s1378472881x2138997070_str28 = {{0x80000000u, K_STR, 0}, 7, 7, {70, 108, 111, 97, 116, 51, 50}};
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam0(V self, V *args); static Clo g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam0, 2, 0};
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam1(V self, V *args); static Clo g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam1, 2, 0};
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam2(V self, V *args); static Clo g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam2, 2, 0};
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam4(V self, V *args); static Clo g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam4, 2, 0};
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam3(V self, V *args);
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam7(V self, V *args); static Clo g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam7, 2, 0};
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam6(V self, V *args);
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam5(V self, V *args);
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam8(V self, V *args); static Clo g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam8, 2, 0};
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam9(V self, V *args); static Clo g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam9, 2, 0};
Clo g_heff_2epsurface_2etyF_24s1378472881x2138997070_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2etyF_24s1378472881x2138997070_entry, 4, 0};

V g_heff_2epsurface_2etyF_24s1378472881x2138997070(V v_lit_240, V v_p_241, V v_xs_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    V v_it1_244 = heff_field(v_t_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str1);
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    V v_t_248 = heff_rec(2, shape_names__hide, (V[]){((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam0_clo), NTAG(TAG_False)});
    HEFF_LAST return g_heff_2epsurface_2eelF_24s733037190x667378878(heff_rec(2, shape_im__indent, (V[]){v_t_248, v_lit_240}), v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_249 = heff_field(v_t_243, 0);
    V v_dom_2410 = heff_field(v_t_243, 1);
    V v_cod_2411 = heff_field(v_t_243, 2);
    V v_implicit_2412 = heff_field(v_t_243, 3);
    V v_dflt_2413 = heff_field(v_t_243, 4);
    V v_s_2421;
    switch (heff_tag_of(v_dflt_2413)) {
    case TAG_Nothing: {
      V v_t_2416 = heff_rec(2, shape_names__hide, (V[]){((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam1_clo), NTAG(TAG_False)});
      v_s_2421 = (g_heff_2epsurface_2earrowStr_24s2117734577x852423791(heff_rec(2, shape_im__indent, (V[]){v_t_2416, v_lit_240}), v_xs_242, v_level_249, v_dom_2410, heff_dup(v_cod_2411), v_implicit_2412));
      break;
    }
    case TAG_Just: {
      V v_d_2417 = heff_field(v_dflt_2413, 0);
      V v_t_2420 = heff_rec(2, shape_names__hide, (V[]){((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam2_clo), NTAG(TAG_False)});
      v_s_2421 = (g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238(heff_rec(2, shape_im__indent, (V[]){v_t_2420, v_lit_240}), v_xs_242, v_dom_2410, heff_dup(v_cod_2411), heff_dup(v_d_2417)));
      break;
    }
    default: heff_nomatch(v_dflt_2413);
    }
    V v_t_2422 = heff_intLe(MK_INT(1LL), v_p_241);
    switch (heff_tag_of(v_t_2422)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str2), heff_strAppend(v_s_2421, ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str3)));
    }
    case TAG_False: {
      return v_s_2421;
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  case TAG_SRecord: {
    V v_fs_2424 = heff_field(v_t_243, 1);
    V v_ds_2425 = heff_field(v_t_243, 2);
    heff_drop(v_p_241);
    V v_t_2426 = heff_arrayToList(heff_get(heff_dup(v_fs_2424), LBL_keys));
    V v_t_2427 = heff_arrayToList(heff_get(heff_dup(v_fs_2424), LBL_values));
    V v_fs_2428 = (g_heff_2edict_2ezipKV(v_t_2426, v_t_2427));
    V v_t_2429 = heff_rec(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2435 = ({ V a_0 = heff_clo(g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam3, 2, 2, (V[]){v_lit_240, heff_dup(v_ds_2425)}); V a_1 = v_t_2429; V a_2 = v_fs_2428; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2428); r_; });
    V v_x2_2436 = heff_get(v_acc_2435, LBL_out);
    V v_t_2439;
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_Nil: {
      v_t_2439 = ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_xs_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      v_t_2439 = ({ V a_0 = ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str5); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2436);
    }
    return heff_strAppend(((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str6), heff_strAppend(v_t_2439, ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str7)));
  }
  case TAG_SSum: {
    V v_vs_2440 = heff_field(v_t_243, 0);
    heff_drop(v_p_241);
    V v_t_2441 = heff_arrayToList(heff_get(heff_dup(v_vs_2440), LBL_keys));
    V v_t_2442 = heff_arrayToList(heff_get(heff_dup(v_vs_2440), LBL_values));
    V v_t_2443 = (g_heff_2edict_2ezipKV(v_t_2441, v_t_2442));
    V v_x2_2454 = (g_prelude_2emap(heff_clo(g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam5, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2443));
    V v_t_2457;
    switch (heff_tag_of(v_x2_2454)) {
    case TAG_Nil: {
      v_t_2457 = ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2455 = heff_field(v_x2_2454, 0);
      V v_xs_2456 = heff_field(v_x2_2454, 1);
      heff_take_n(v_x2_2454, 3ULL, 2);
      v_t_2457 = ({ V a_0 = ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str11); V a_1 = v_x_2455; V a_2 = v_xs_2456; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2456); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2454);
    }
    return heff_strAppend(((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str12), heff_strAppend(v_t_2457, ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str13)));
  }
  case TAG_SIsTy: {
    V v_t2_2458 = heff_field(v_t_243, 0);
    V v_t_2461 = heff_rec(2, shape_names__hide, (V[]){((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam8_clo), NTAG(TAG_False)});
    HEFF_LAST return g_heff_2epsurface_2etyF_24s1319128358x1023081884(heff_rec(2, shape_im__indent, (V[]){v_t_2461, v_lit_240}), v_p_241, v_xs_242, v_t2_2458);
  }
  case TAG_SPrimInt: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str14);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str15);
  }
  case TAG_SPrimString: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str16);
  }
  case TAG_SPrimArray: {
    V v_a_2462 = heff_field(v_t_243, 0);
    V v_t_2465 = heff_rec(2, shape_names__hide, (V[]){((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam9_clo), NTAG(TAG_False)});
    V v_s_2466 = heff_strAppend(((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str17), (g_heff_2epsurface_2etyF_24s1319128358x1023081884(heff_rec(2, shape_im__indent, (V[]){v_t_2465, v_lit_240}), MK_INT(2LL), v_xs_242, v_a_2462)));
    V v_t_2467 = heff_intLe(MK_INT(2LL), v_p_241);
    switch (heff_tag_of(v_t_2467)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str18), heff_strAppend(v_s_2466, ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str19)));
    }
    case TAG_False: {
      return v_s_2466;
    }
    default: return heff_nomatch(v_t_2467);
    }
  }
  case TAG_SFixed: {
    V v_w_2468 = heff_field(v_t_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2468)) {
    case TAG_I8: {
      return ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str20);
    }
    case TAG_I16: {
      return ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str21);
    }
    case TAG_I32: {
      return ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str22);
    }
    case TAG_I64: {
      return ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str23);
    }
    case TAG_U8: {
      return ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str24);
    }
    case TAG_U16: {
      return ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str25);
    }
    case TAG_U32: {
      return ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str26);
    }
    case TAG_U64: {
      return ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str27);
    }
    case TAG_F32: {
      return ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str28);
    }
    default: return heff_nomatch(v_w_2468);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2epsurface_2etyF_24s1378472881x2138997070(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam0(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  heff_drop(v_a_246);
  heff_drop(v_a_247);
  return heff_dup(g_heff_2epsurface_2earrayNone_get());
}
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam1(V self, V *args) {
  V v_a_2414 = args[0];
  V v_a_2415 = args[1];
  heff_drop(v_a_2414);
  heff_drop(v_a_2415);
  return heff_dup(g_heff_2epsurface_2earrayNone_get());
}
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam2(V self, V *args) {
  V v_a_2418 = args[0];
  V v_a_2419 = args[1];
  heff_drop(v_a_2418);
  heff_drop(v_a_2419);
  return heff_dup(g_heff_2epsurface_2earrayNone_get());
}
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam4(V self, V *args) {
  V v_a_2432 = args[0];
  V v_a_2433 = args[1];
  heff_drop(v_a_2432);
  heff_drop(v_a_2433);
  return heff_dup(g_heff_2epsurface_2earrayNone_get());
}
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam3(V self, V *args) {
  V v_acc_2430 = args[0];
  V v_f_2431 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_rec(2, shape_names__hide, (V[]){((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam4_clo), NTAG(TAG_False)});
  return (g_heff_2epsurface_2erecordField_24s464605383x1219605104(heff_rec(2, shape_im__indent, (V[]){v_t_2434, v_lit_240}), v_ds_2425, v_acc_2430, v_f_2431));
}
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam7(V self, V *args) {
  V v_a_2448 = args[0];
  V v_a_2449 = args[1];
  heff_drop(v_a_2448);
  heff_drop(v_a_2449);
  return heff_dup(g_heff_2epsurface_2earrayNone_get());
}
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam6(V self, V *args) {
  V v_t2_2447 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_rec(2, shape_names__hide, (V[]){((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam7_clo), NTAG(TAG_False)});
  return ({ V a_0 = heff_rec(2, shape_im__indent, (V[]){v_t_2450, v_lit_240}); V a_1 = MK_INT(2LL); V a_2 = v_xs_242; V a_3 = v_t2_2447; V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, a_3)); heff_drop(v_t2_2447); r_; });
}
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam5(V self, V *args) {
  V v_v_2444 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2444)) {
  case TAG_MkPair: {
    V v_t_2445 = heff_field(v_v_2444, 0);
    V v_ts_2446 = heff_field(v_v_2444, 1);
    V v_ru_24v_2444_24MkPair = heff_take_reuse_n(v_v_2444, 3ULL, 2);
    V v_x2_2451 = heff_tag_at(v_ru_24v_2444_24MkPair, TAG_Cons, 2, (V[]){v_t_2445, (g_prelude_2emap(heff_clo(g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam6, 1, 2, (V[]){v_lit_240, v_xs_242}), heff_arrayToList(v_ts_2446)))});
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_Nil: {
      return ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str8);
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_xs_2453 = heff_field(v_x2_2451, 1);
      heff_take_n(v_x2_2451, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2epsurface_2etyF_24s1378472881x2138997070_str9); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
    }
    default: return heff_nomatch(v_x2_2451);
    }
  }
  default: return heff_nomatch(v_v_2444);
  }
}
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam8(V self, V *args) {
  V v_a_2459 = args[0];
  V v_a_2460 = args[1];
  heff_drop(v_a_2459);
  heff_drop(v_a_2460);
  return heff_dup(g_heff_2epsurface_2earrayNone_get());
}
V g_heff_2epsurface_2etyF_24s1378472881x2138997070_lam9(V self, V *args) {
  V v_a_2463 = args[0];
  V v_a_2464 = args[1];
  heff_drop(v_a_2463);
  heff_drop(v_a_2464);
  return heff_dup(g_heff_2epsurface_2earrayNone_get());
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2epsurface_2eformerParam_str1 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 58, 32, 84, 121, 112, 101, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerParam_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerParam_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerParam_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerParam_str12 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerParam_str15 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerParam_str18 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerParam_str21 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerParam_str24 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerParam_str27 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerParam_str30 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerParam_str33 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerParam_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2epsurface_2eformerParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eformerParam_entry, 3, 0};

V g_heff_2epsurface_2eformerParam(V v_ns_240, V v_x_241, V v_dom_242) {
top: ;
  switch (heff_tag_of(v_dom_242)) {
  case TAG_SU: {
    V v_it1_243 = heff_field(v_dom_242, 0);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_SmallU: {
      heff_drop(v_ns_240);
      V v_t_244 = heff_intLe(MK_INT(65LL), heff_strCharCode(heff_dup(v_x_241), MK_INT(0LL)));
      switch (heff_tag_of(v_t_244)) {
      case TAG_True: {
        V v_t_245 = heff_intLe(heff_strCharCode(heff_dup(v_x_241), MK_INT(0LL)), MK_INT(90LL));
        switch (heff_tag_of(v_t_245)) {
        case TAG_True: {
          return heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str0), heff_strAppend(v_x_241, ((V)&g_heff_2epsurface_2eformerParam_str1)));
        }
        case TAG_False: {
          return v_x_241;
        }
        default: return heff_nomatch(v_t_245);
        }
      }
      case TAG_False: {
        return v_x_241;
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    case TAG_LargeU: {
      V v_t_246 = (g_heff_2epsurface_2etyF_24s1378472881x2138997070(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
      return heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str2), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str3), heff_strAppend(v_t_246, ((V)&g_heff_2epsurface_2eformerParam_str4)))));
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  case TAG_SDecode: {
    V v_t_248 = (g_heff_2epsurface_2etyF_24s1378472881x2138997070(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str5), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str6), heff_strAppend(v_t_248, ((V)&g_heff_2epsurface_2eformerParam_str7)))));
  }
  case TAG_SFunction: {
    V v_t_2414 = (g_heff_2epsurface_2etyF_24s1378472881x2138997070(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str8), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str9), heff_strAppend(v_t_2414, ((V)&g_heff_2epsurface_2eformerParam_str10)))));
  }
  case TAG_SRecord: {
    V v_t_2418 = (g_heff_2epsurface_2etyF_24s1378472881x2138997070(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str11), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str12), heff_strAppend(v_t_2418, ((V)&g_heff_2epsurface_2eformerParam_str13)))));
  }
  case TAG_SSum: {
    V v_t_2420 = (g_heff_2epsurface_2etyF_24s1378472881x2138997070(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str14), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str15), heff_strAppend(v_t_2420, ((V)&g_heff_2epsurface_2eformerParam_str16)))));
  }
  case TAG_SIsTy: {
    V v_t_2422 = (g_heff_2epsurface_2etyF_24s1378472881x2138997070(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str17), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str18), heff_strAppend(v_t_2422, ((V)&g_heff_2epsurface_2eformerParam_str19)))));
  }
  case TAG_SPrimInt: {
    V v_t_2423 = (g_heff_2epsurface_2etyF_24s1378472881x2138997070(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str20), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str21), heff_strAppend(v_t_2423, ((V)&g_heff_2epsurface_2eformerParam_str22)))));
  }
  case TAG_SPrimFloat: {
    V v_t_2424 = (g_heff_2epsurface_2etyF_24s1378472881x2138997070(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str23), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str24), heff_strAppend(v_t_2424, ((V)&g_heff_2epsurface_2eformerParam_str25)))));
  }
  case TAG_SPrimString: {
    V v_t_2425 = (g_heff_2epsurface_2etyF_24s1378472881x2138997070(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str26), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str27), heff_strAppend(v_t_2425, ((V)&g_heff_2epsurface_2eformerParam_str28)))));
  }
  case TAG_SPrimArray: {
    V v_t_2427 = (g_heff_2epsurface_2etyF_24s1378472881x2138997070(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str29), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str30), heff_strAppend(v_t_2427, ((V)&g_heff_2epsurface_2eformerParam_str31)))));
  }
  case TAG_SFixed: {
    V v_t_2429 = (g_heff_2epsurface_2etyF_24s1378472881x2138997070(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str32), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2epsurface_2eformerParam_str33), heff_strAppend(v_t_2429, ((V)&g_heff_2epsurface_2eformerParam_str34)))));
  }
  default: return heff_nomatch(v_dom_242);
  }
}
V g_heff_2epsurface_2eformerParam_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2epsurface_2eformerParam(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2epsurface_2etypeFormer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2etypeFormer_entry, 4, 0};

V g_heff_2epsurface_2etypeFormer(V v_t_240, V v_body_241, V v_ns_242, V v_params_243) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_SU: {
    V v_u_244 = heff_field(v_t_240, 0);
    V v_ru_24t_240_24SU = heff_take_reuse_n(v_t_240, 1ULL, 1);
    V v_t_245 = (g_heff_2epsurface_2estripIs(v_body_241));
    V v_t_246;
    switch (heff_tag_of(v_u_244)) {
    case TAG_SmallU: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_LargeU: {
      v_t_246 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_u_244);
    }
    return heff_tag_at(v_ru_24t_240_24SU, TAG_Just, 1, (V[]){(g_heff_2epsurface_2eformerAt(v_params_243, v_ns_242, v_t_245, v_t_246))});
  }
  case TAG_SDecode: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_2425 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_2425;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SFunction: {
    V v_dom_2442 = heff_dup(heff_field(v_t_240, 1));
    V v_it3_2443 = heff_dup(heff_field(v_t_240, 2));
    V v_it4_2444 = heff_dup(heff_field(v_t_240, 3));
    switch (heff_tag_of(v_it3_2443)) {
    case TAG_MkAbs: {
      V v_cod_2447 = heff_field(v_it3_2443, 1);
      V v_ru_24it3_2443_24MkAbs = heff_take_reuse_n(v_it3_2443, 2ULL, 2);
      switch (heff_tag_of(v_it4_2444)) {
      case TAG_Expl: {
        switch (heff_tag_of(v_body_241)) {
        case TAG_SLocal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          V v_it2_2454 = heff_field(v_body_241, 1);
          V v_ru_24body_241_24SLam = heff_take_reuse_n(v_body_241, 2ULL, 2);
          heff_drop_tag(v_t_240, 5);
          switch (heff_tag_of(v_it2_2454)) {
          case TAG_MkAbs: {
            V v_x_2455 = heff_field(v_it2_2454, 0);
            V v_b_2456 = heff_field(v_it2_2454, 1);
            heff_take_n(v_it2_2454, 3ULL, 2);
            V v_t_2457 = ({ V a_0 = heff_dup(v_ns_242); V a_1 = heff_dup(v_x_2455); V a_2 = v_dom_2442; V r_ = (g_heff_2epsurface_2eformerParam(a_0, a_1, a_2)); heff_drop(v_dom_2442); r_; });
            V v_t_2458 = heff_tag_at(v_ru_24it3_2443_24MkAbs, TAG_Cons, 2, (V[]){v_t_2457, NTAG(TAG_Nil)});
            V v_t_2459 = (g_prelude_2econcatList(v_params_243, v_t_2458));
            V t_0 = v_cod_2447;
            V t_1 = v_b_2456;
            V t_2 = heff_tag_at(v_ru_24body_241_24SLam, TAG_Cons, 2, (V[]){v_x_2455, v_ns_242});
            V t_3 = v_t_2459;
            v_t_240 = t_0;
            v_body_241 = t_1;
            v_ns_242 = t_2;
            v_params_243 = t_3;
            goto top;
          }
          case TAG_AbsConst: {
            heff_take_n(v_it2_2454, 0ULL, 1);
            heff_drop(v_ns_242);
            heff_drop(v_params_243);
            heff_drop(v_dom_2442);
            heff_drop(v_cod_2447);
            heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
            heff_drop_cell(v_ru_24body_241_24SLam, 2);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_it2_2454);
          }
        }
        case TAG_SCons: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMatch: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          V v_b_2471 = heff_field(v_body_241, 0);
          heff_take_n(v_body_241, 1ULL, 1);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          V t_0 = v_t_240;
          V t_1 = v_b_2471;
          V t_2 = v_ns_242;
          V t_3 = v_params_243;
          v_t_240 = t_0;
          v_body_241 = t_1;
          v_ns_242 = t_2;
          v_params_243 = t_3;
          goto top;
        }
        case TAG_SOpaque: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat32: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2442);
          heff_drop(v_cod_2447);
          heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_body_241);
        }
      }
      case TAG_Impl: {
        heff_drop(v_dom_2442);
        heff_drop(v_cod_2447);
        heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
        switch (heff_tag_of(v_body_241)) {
        case TAG_SLocal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCons: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMatch: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          V v_b_24104 = heff_field(v_body_241, 0);
          heff_take_n(v_body_241, 1ULL, 1);
          V t_0 = v_t_240;
          V t_1 = v_b_24104;
          V t_2 = v_ns_242;
          V t_3 = v_params_243;
          v_t_240 = t_0;
          v_body_241 = t_1;
          v_ns_242 = t_2;
          v_params_243 = t_3;
          goto top;
        }
        case TAG_SOpaque: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat32: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_body_241);
        }
      }
      case TAG_Inst: {
        heff_drop(v_dom_2442);
        heff_drop(v_cod_2447);
        heff_drop_cell(v_ru_24it3_2443_24MkAbs, 2);
        switch (heff_tag_of(v_body_241)) {
        case TAG_SLocal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCons: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMatch: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          V v_b_24137 = heff_field(v_body_241, 0);
          heff_take_n(v_body_241, 1ULL, 1);
          V t_0 = v_t_240;
          V t_1 = v_b_24137;
          V t_2 = v_ns_242;
          V t_3 = v_params_243;
          v_t_240 = t_0;
          v_body_241 = t_1;
          v_ns_242 = t_2;
          v_params_243 = t_3;
          goto top;
        }
        case TAG_SOpaque: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat32: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_body_241);
        }
      }
      default: return heff_nomatch(v_it4_2444);
      }
    }
    case TAG_AbsConst: {
      heff_take_n(v_it3_2443, 0ULL, 1);
      heff_drop(v_dom_2442);
      heff_drop(v_it4_2444);
      switch (heff_tag_of(v_body_241)) {
      case TAG_SLocal: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SGlobal: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SCode: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SApp: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLam: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SCons: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SProj: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_STag: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SMatch: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_body_241, 0ULL, 3);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SIs: {
        V v_b_24171 = heff_field(v_body_241, 0);
        heff_take_n(v_body_241, 1ULL, 1);
        V t_0 = v_t_240;
        V t_1 = v_b_24171;
        V t_2 = v_ns_242;
        V t_3 = v_params_243;
        v_t_240 = t_0;
        v_body_241 = t_1;
        v_ns_242 = t_2;
        v_params_243 = t_3;
        goto top;
      }
      case TAG_SOpaque: {
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SAbandon: {
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SRec: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SFix: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SImplicit: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SPrim: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_body_241, 0ULL, 3);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitInt: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitFloat: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitString: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitFloat32: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_body_241);
      }
    }
    default: return heff_nomatch(v_it3_2443);
    }
  }
  case TAG_SRecord: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24207 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24207;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SSum: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24241 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24241;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SIsTy: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24275 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24275;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimInt: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24308 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24308;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimFloat: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24341 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24341;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimString: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24374 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24374;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimArray: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24408 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24408;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SFixed: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24442 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24442;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2epsurface_2etypeFormer_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2etypeFormer(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str17 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str18 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 97, 115, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str19 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str22 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 126, 32, 123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str23 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str24 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str27 = {{0x80000000u, K_STR, 0}, 8, 8, {60, 111, 112, 97, 113, 117, 101, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str28 = {{0x80000000u, K_STR, 0}, 7, 7, {97, 98, 97, 110, 100, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str29 = {{0x80000000u, K_STR, 0}, 7, 7, {60, 108, 111, 99, 97, 108, 62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str30 = {{0x80000000u, K_STR, 0}, 11, 11, {60, 112, 114, 105, 109, 105, 116, 105, 118, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {62}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {63}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str33 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eelF_24s473646377x555746588_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
V g_heff_2epsurface_2eelF_24s473646377x555746588_lam0(V self, V *args);
V g_heff_2epsurface_2eelF_24s473646377x555746588_lam1(V self, V *args);
V g_heff_2epsurface_2eelF_24s473646377x555746588_lam2(V self, V *args);
V g_heff_2epsurface_2eelF_24s473646377x555746588_lam3(V self, V *args);
Clo g_heff_2epsurface_2eelF_24s473646377x555746588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eelF_24s473646377x555746588_entry, 4, 0};

V g_heff_2epsurface_2eelF_24s473646377x555746588(V v_lit_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return (g_heff_2epsurface_2elocalName(v_xs_242, v_i_244));
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_246 = (g_heff_2epsurface_2eisOperator(heff_dup(v_x_245)));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str0), heff_strAppend(v_x_245, ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str1)));
    }
    case TAG_False: {
      return v_x_245;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_SCode: {
    V v_t_247 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    return ({ V a_0 = heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_247; V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  }
  case TAG_SApp: {
    V v_f_248 = heff_field(v_e_243, 0);
    V v_a_249 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    HEFF_LAST return g_heff_2epsurface_2eappStr_24s929057901x1904324530(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, heff_tag_at(v_ru_24e_243_24SApp, TAG_SApp, 2, (V[]){v_f_248, v_a_249}));
  }
  case TAG_SLam: {
    V v_t_2410 = heff_field(v_e_243, 0);
    V v_b_2411 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SLam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2412 = (g_heff_2epsurface_2elambdas(heff_dup(v_xs_242), NTAG(TAG_Nil), heff_tag_at(v_ru_24e_243_24SLam, TAG_SLam, 2, (V[]){v_t_2410, v_b_2411})));
    return ({ V a_0 = heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_2412; V r_ = (g_heff_2epsurface_2elamStr_24s2129544944x962470242(a_0, a_1, a_2, a_3)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SCons: {
    V v_d_2413 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_p_241);
    V v_t_2414 = heff_arrayToList(heff_get(heff_dup(v_d_2413), LBL_keys));
    V v_t_2415 = heff_arrayToList(heff_get(v_d_2413, LBL_values));
    V v_t_2416 = (g_heff_2edict_2ezipKV(v_t_2414, v_t_2415));
    V v_x2_2420 = (g_prelude_2emap(heff_clo(g_heff_2epsurface_2eelF_24s473646377x555746588_lam0, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2416));
    V v_t_2423;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nil: {
      v_t_2423 = ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_xs_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      v_t_2423 = ({ V a_0 = ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str4); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str5), heff_strAppend(v_t_2423, ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str6)));
  }
  case TAG_SProj: {
    V v_e2_2424 = heff_field(v_e_243, 0);
    V v_l_2425 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    heff_drop(v_p_241);
    V v_t_2426 = (g_heff_2epsurface_2eelF_24s733037190x667378878(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(2LL), v_xs_242, v_e2_2424));
    return heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str7), v_l_2425));
  }
  case TAG_STag: {
    V v_x_2427 = heff_dup(heff_field(v_e_243, 0));
    V v_ts_2428 = heff_dup(heff_field(v_e_243, 1));
    V v_t_2429 = (g_heff_2epsurface_2elistItems(v_e_243));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nothing: {
      V v_t_2430 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_ts_2428)); V r_ = (g_prelude_2efoldl_24s1226147011x367015740(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2431 = heff_intEq(v_t_2430, MK_INT(0LL));
      switch (heff_tag_of(v_t_2431)) {
      case TAG_True: {
        heff_drop(v_lit_240);
        heff_drop(v_p_241);
        heff_drop(v_xs_242);
        heff_drop(v_ts_2428);
        return v_x_2427;
      }
      case TAG_False: {
        V v_x2_2433 = heff_tag(TAG_Cons, 2, (V[]){v_x_2427, (g_prelude_2emap(heff_clo(g_heff_2epsurface_2eelF_24s473646377x555746588_lam1, 1, 2, (V[]){v_lit_240, v_xs_242}), heff_arrayToList(v_ts_2428)))});
        V v_s_2436;
        switch (heff_tag_of(v_x2_2433)) {
        case TAG_Nil: {
          v_s_2436 = ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2434 = heff_field(v_x2_2433, 0);
          V v_xs_2435 = heff_field(v_x2_2433, 1);
          heff_take_n(v_x2_2433, 3ULL, 2);
          v_s_2436 = ({ V a_0 = ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str9); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2433);
        }
        V v_t_2437 = heff_intLe(MK_INT(2LL), v_p_241);
        switch (heff_tag_of(v_t_2437)) {
        case TAG_True: {
          return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str10), heff_strAppend(v_s_2436, ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str11)));
        }
        case TAG_False: {
          return v_s_2436;
        }
        default: return heff_nomatch(v_t_2437);
        }
      }
      default: return heff_nomatch(v_t_2431);
      }
    }
    case TAG_Just: {
      V v_items_2438 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      heff_drop(v_p_241);
      heff_drop(v_x_2427);
      heff_drop(v_ts_2428);
      V v_x2_2440 = (g_prelude_2emap(heff_clo(g_heff_2epsurface_2eelF_24s473646377x555746588_lam2, 1, 2, (V[]){v_lit_240, v_xs_242}), v_items_2438));
      V v_t_2443;
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_Nil: {
        v_t_2443 = ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_xs_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        v_t_2443 = ({ V a_0 = ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str13); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2440);
      }
      return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str14), heff_strAppend(v_t_2443, ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str15)));
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  case TAG_SMatch: {
    V v_s_2444 = heff_field(v_e_243, 0);
    V v_cases_2445 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_2446 = (g_heff_2epsurface_2eelF_24s733037190x667378878(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), heff_dup(v_lit_240)}), MK_INT(0LL), heff_dup(v_xs_242), v_s_2444));
    V v_t_2447 = heff_arrayToList(heff_get(heff_dup(v_cases_2445), LBL_keys));
    V v_t_2448 = heff_arrayToList(heff_get(v_cases_2445, LBL_values));
    V v_t_2449 = (g_heff_2edict_2ezipKV(v_t_2447, v_t_2448));
    V v_x2_2452 = (g_prelude_2emap(heff_clo(g_heff_2epsurface_2eelF_24s473646377x555746588_lam3, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2449));
    V v_t_2455;
    switch (heff_tag_of(v_x2_2452)) {
    case TAG_Nil: {
      v_t_2455 = ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2453 = heff_field(v_x2_2452, 0);
      V v_xs_2454 = heff_field(v_x2_2452, 1);
      heff_take_n(v_x2_2452, 3ULL, 2);
      v_t_2455 = ({ V a_0 = ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str17); V a_1 = v_x_2453; V a_2 = v_xs_2454; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2454); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2452);
    }
    V v_s_2456 = heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str18), heff_strAppend(v_t_2446, heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str19), v_t_2455)));
    V v_t_2457 = heff_intLe(MK_INT(1LL), v_p_241);
    switch (heff_tag_of(v_t_2457)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str20), heff_strAppend(v_s_2456, ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str21)));
    }
    case TAG_False: {
      return v_s_2456;
    }
    default: return heff_nomatch(v_t_2457);
    }
  }
  case TAG_SSpecialize: {
    V v_e2_2458 = heff_field(v_e_243, 0);
    V v_x_2459 = heff_field(v_e_243, 1);
    V v_v_2460 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_t_2461 = (g_heff_2epsurface_2eelF_24s733037190x667378878(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), heff_dup(v_lit_240)}), MK_INT(2LL), heff_dup(v_xs_242), v_e2_2458));
    V v_t_2462 = (g_heff_2epsurface_2eelF_24s733037190x667378878(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(0LL), v_xs_242, v_v_2460));
    V v_s_2463 = heff_strAppend(v_t_2461, heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str22), heff_strAppend(v_x_2459, heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str23), heff_strAppend(v_t_2462, ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str24))))));
    V v_t_2464 = heff_intLe(MK_INT(1LL), v_p_241);
    switch (heff_tag_of(v_t_2464)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str25), heff_strAppend(v_s_2463, ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str26)));
    }
    case TAG_False: {
      return v_s_2463;
    }
    default: return heff_nomatch(v_t_2464);
    }
  }
  case TAG_SIs: {
    V v_e2_2465 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    HEFF_LAST return g_heff_2epsurface_2eelF_24s733037190x667378878(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_e2_2465);
  }
  case TAG_SOpaque: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str27);
  }
  case TAG_SAbandon: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str28);
  }
  case TAG_SRec: {
    V v_e2_2466 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    HEFF_LAST return g_heff_2epsurface_2eelF_24s733037190x667378878(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_e2_2466);
  }
  case TAG_SFix: {
    V v_it2_2468 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_it2_2468)) {
    case TAG_MkAbs: {
      V v_x_2469 = heff_field(v_it2_2468, 0);
      heff_take_n(v_it2_2468, 1ULL, 2);
      return v_x_2469;
    }
    case TAG_AbsConst: {
      heff_take_n(v_it2_2468, 0ULL, 1);
      return ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str29);
    }
    default: return heff_nomatch(v_it2_2468);
    }
  }
  case TAG_SImplicit: {
    V v_e2_2473 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    HEFF_LAST return g_heff_2epsurface_2eelF_24s733037190x667378878(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_e2_2473);
  }
  case TAG_SPrim: {
    V v_x_2474 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str30), heff_strAppend(v_x_2474, ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str31)));
  }
  case TAG_SMetaApp: {
    V v_m_2475 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 3);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str32), heff_intShow(v_m_2475));
  }
  case TAG_SLitInt: {
    V v_i_2478 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_i_2478);
  }
  case TAG_SLitFloat: {
    V v_x_2479 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2479);
  }
  case TAG_SLitString: {
    V v_s_2480 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2481 = (g_heff_2epsurface_2equoteGo(v_s_2480, MK_INT(0LL), ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str33)));
    return heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str34), heff_strAppend(v_t_2481, ((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str35)));
  }
  case TAG_SLitFixed: {
    V v_n_2483 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_n_2483);
  }
  case TAG_SLitFloat32: {
    V v_x_2484 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2484);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2epsurface_2eelF_24s473646377x555746588_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2eelF_24s473646377x555746588(a[0], a[1], a[2], a[3]);
}
V g_heff_2epsurface_2eelF_24s473646377x555746588_lam0(V self, V *args) {
  V v_f_2417 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2417)) {
  case TAG_MkPair: {
    V v_l_2418 = heff_field(v_f_2417, 0);
    V v_e_2419 = heff_field(v_f_2417, 1);
    heff_take_n(v_f_2417, 3ULL, 2);
    return heff_strAppend(v_l_2418, heff_strAppend(((V)&g_heff_2epsurface_2eelF_24s473646377x555746588_str2), (g_heff_2epsurface_2eelF_24s733037190x667378878(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(0LL), v_xs_242, v_e_2419))));
  }
  default: return heff_nomatch(v_f_2417);
  }
}
V g_heff_2epsurface_2eelF_24s473646377x555746588_lam1(V self, V *args) {
  V v_a_2432 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2epsurface_2eelF_24s733037190x667378878(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(2LL), v_xs_242, v_a_2432));
}
V g_heff_2epsurface_2eelF_24s473646377x555746588_lam2(V self, V *args) {
  V v_a_2439 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2epsurface_2eelF_24s733037190x667378878(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(0LL), v_xs_242, v_a_2439));
}
V g_heff_2epsurface_2eelF_24s473646377x555746588_lam3(V self, V *args) {
  V v_alt_2450 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), heff_intAdd(v_lit_240, MK_INT(2LL))});
  return ({ V a_0 = v_t_2451; V a_1 = v_xs_242; V a_2 = v_alt_2450; V r_ = (g_heff_2epsurface_2ealtLine_24s1348772780x2097554404(a_0, a_1, a_2)); heff_drop(v_alt_2450); r_; });
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 121, 112, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {84, 104, 101, 111, 114, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 124, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str12 = {{0x80000000u, K_STR, 0}, 7, 7, {100, 97, 116, 97, 32, 123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str14 = {{0x80000000u, K_STR, 0}, 3, 3, {73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str15 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 108, 111, 97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str16 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str17 = {{0x80000000u, K_STR, 0}, 6, 6, {65, 114, 114, 97, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str20 = {{0x80000000u, K_STR, 0}, 4, 4, {73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str21 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str22 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str23 = {{0x80000000u, K_STR, 0}, 5, 5, {73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str24 = {{0x80000000u, K_STR, 0}, 5, 5, {85, 73, 110, 116, 56}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str25 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 49, 54}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str26 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 51, 50}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str27 = {{0x80000000u, K_STR, 0}, 6, 6, {85, 73, 110, 116, 54, 52}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2epsurface_2etyF_24s410763399x651256744_str28 = {{0x80000000u, K_STR, 0}, 7, 7, {70, 108, 111, 97, 116, 51, 50}};
V g_heff_2epsurface_2etyF_24s410763399x651256744_lam0(V self, V *args);
V g_heff_2epsurface_2etyF_24s410763399x651256744_lam2(V self, V *args);
V g_heff_2epsurface_2etyF_24s410763399x651256744_lam1(V self, V *args);
Clo g_heff_2epsurface_2etyF_24s410763399x651256744_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2etyF_24s410763399x651256744_entry, 4, 0};

V g_heff_2epsurface_2etyF_24s410763399x651256744(V v_lit_240, V v_p_241, V v_xs_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    V v_it1_244 = heff_field(v_t_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str1);
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    HEFF_LAST return g_heff_2epsurface_2eelF_24s733037190x667378878(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_t_243, 0);
    V v_dom_247 = heff_field(v_t_243, 1);
    V v_cod_248 = heff_field(v_t_243, 2);
    V v_implicit_249 = heff_field(v_t_243, 3);
    V v_dflt_2410 = heff_field(v_t_243, 4);
    V v_s_2412;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      v_s_2412 = (g_heff_2epsurface_2earrowStr_24s2117734577x852423791(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), v_xs_242, v_level_246, v_dom_247, heff_dup(v_cod_248), v_implicit_249));
      break;
    }
    case TAG_Just: {
      V v_d_2411 = heff_field(v_dflt_2410, 0);
      v_s_2412 = (g_heff_2epsurface_2earrowDefault_24s1478603786x1899953238(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), v_xs_242, v_dom_247, heff_dup(v_cod_248), heff_dup(v_d_2411)));
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    V v_t_2413 = heff_intLe(MK_INT(1LL), v_p_241);
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str2), heff_strAppend(v_s_2412, ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str3)));
    }
    case TAG_False: {
      return v_s_2412;
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  case TAG_SRecord: {
    V v_fs_2415 = heff_field(v_t_243, 1);
    V v_ds_2416 = heff_field(v_t_243, 2);
    heff_drop(v_p_241);
    V v_t_2417 = heff_arrayToList(heff_get(heff_dup(v_fs_2415), LBL_keys));
    V v_t_2418 = heff_arrayToList(heff_get(heff_dup(v_fs_2415), LBL_values));
    V v_fs_2419 = (g_heff_2edict_2ezipKV(v_t_2417, v_t_2418));
    V v_t_2420 = heff_rec(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2423 = ({ V a_0 = heff_clo(g_heff_2epsurface_2etyF_24s410763399x651256744_lam0, 2, 2, (V[]){v_lit_240, heff_dup(v_ds_2416)}); V a_1 = v_t_2420; V a_2 = v_fs_2419; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2419); r_; });
    V v_x2_2424 = heff_get(v_acc_2423, LBL_out);
    V v_t_2427;
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nil: {
      v_t_2427 = ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_xs_2426 = heff_field(v_x2_2424, 1);
      heff_take_n(v_x2_2424, 3ULL, 2);
      v_t_2427 = ({ V a_0 = ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str5); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2424);
    }
    return heff_strAppend(((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str6), heff_strAppend(v_t_2427, ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str7)));
  }
  case TAG_SSum: {
    V v_vs_2428 = heff_field(v_t_243, 0);
    heff_drop(v_p_241);
    V v_t_2429 = heff_arrayToList(heff_get(heff_dup(v_vs_2428), LBL_keys));
    V v_t_2430 = heff_arrayToList(heff_get(heff_dup(v_vs_2428), LBL_values));
    V v_t_2431 = (g_heff_2edict_2ezipKV(v_t_2429, v_t_2430));
    V v_x2_2439 = (g_prelude_2emap(heff_clo(g_heff_2epsurface_2etyF_24s410763399x651256744_lam1, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2431));
    V v_t_2442;
    switch (heff_tag_of(v_x2_2439)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_x2_2439, 0);
      V v_xs_2441 = heff_field(v_x2_2439, 1);
      heff_take_n(v_x2_2439, 3ULL, 2);
      v_t_2442 = ({ V a_0 = ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str11); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2439);
    }
    return heff_strAppend(((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str12), heff_strAppend(v_t_2442, ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str13)));
  }
  case TAG_SIsTy: {
    V v_t2_2443 = heff_field(v_t_243, 0);
    HEFF_LAST return g_heff_2epsurface_2etyF_24s1319128358x1023081884(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_t2_2443);
  }
  case TAG_SPrimInt: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str14);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str15);
  }
  case TAG_SPrimString: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str16);
  }
  case TAG_SPrimArray: {
    V v_a_2444 = heff_field(v_t_243, 0);
    V v_s_2445 = heff_strAppend(((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str17), (g_heff_2epsurface_2etyF_24s1319128358x1023081884(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(2LL), v_xs_242, v_a_2444)));
    V v_t_2446 = heff_intLe(MK_INT(2LL), v_p_241);
    switch (heff_tag_of(v_t_2446)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str18), heff_strAppend(v_s_2445, ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str19)));
    }
    case TAG_False: {
      return v_s_2445;
    }
    default: return heff_nomatch(v_t_2446);
    }
  }
  case TAG_SFixed: {
    V v_w_2447 = heff_field(v_t_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2447)) {
    case TAG_I8: {
      return ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str20);
    }
    case TAG_I16: {
      return ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str21);
    }
    case TAG_I32: {
      return ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str22);
    }
    case TAG_I64: {
      return ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str23);
    }
    case TAG_U8: {
      return ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str24);
    }
    case TAG_U16: {
      return ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str25);
    }
    case TAG_U32: {
      return ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str26);
    }
    case TAG_U64: {
      return ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str27);
    }
    case TAG_F32: {
      return ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str28);
    }
    default: return heff_nomatch(v_w_2447);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2epsurface_2etyF_24s410763399x651256744_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2epsurface_2etyF_24s410763399x651256744(a[0], a[1], a[2], a[3]); heff_drop(a[3]); return r;
}
V g_heff_2epsurface_2etyF_24s410763399x651256744_lam0(V self, V *args) {
  V v_acc_2421 = args[0];
  V v_f_2422 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2epsurface_2erecordField_24s464605383x1219605104(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), v_ds_2416, v_acc_2421, v_f_2422));
}
V g_heff_2epsurface_2etyF_24s410763399x651256744_lam2(V self, V *args) {
  V v_t2_2435 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(2LL); V a_2 = v_xs_242; V a_3 = v_t2_2435; V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, a_3)); heff_drop(v_t2_2435); r_; });
}
V g_heff_2epsurface_2etyF_24s410763399x651256744_lam1(V self, V *args) {
  V v_v_2432 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2432)) {
  case TAG_MkPair: {
    V v_t_2433 = heff_field(v_v_2432, 0);
    V v_ts_2434 = heff_field(v_v_2432, 1);
    V v_ru_24v_2432_24MkPair = heff_take_reuse_n(v_v_2432, 3ULL, 2);
    V v_x2_2436 = heff_tag_at(v_ru_24v_2432_24MkPair, TAG_Cons, 2, (V[]){v_t_2433, (g_prelude_2emap(heff_clo(g_heff_2epsurface_2etyF_24s410763399x651256744_lam2, 1, 2, (V[]){v_lit_240, v_xs_242}), heff_arrayToList(v_ts_2434)))});
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_Nil: {
      return ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str8);
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_xs_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2epsurface_2etyF_24s410763399x651256744_str9); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_v_2432);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str9 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str10 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str14 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {116, 104, 101, 111, 114, 121, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str17 = {{0x80000000u, K_STR, 0}, 7, 7, {32, 119, 104, 101, 114, 101, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str20 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str21 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str24 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str25 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str27 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str28 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 124, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str29 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str30 = {{0x80000000u, K_STR, 0}, 5, 5, {100, 97, 116, 97, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str33 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str34 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str37 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str38 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str41 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str42 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str43 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str44 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str45 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str46 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str47 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str48 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str49 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str50 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str52 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str53 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 121, 112, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str54 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str55 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
V g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_lam0(V self, V *args);
V g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_lam2(V self, V *args);
V g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_lam1(V self, V *args);
Clo g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_entry, 3, 0};

V g_heff_2epsurface_2eformerOf_24s1996635939x1902066865(V v_lit_240, V v_name_241, V v_tf_242) {
top: ;
  V v_t_243 = heff_get(heff_dup(v_tf_242), LBL_def);
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    V v_ru_24t_243_24SU = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_245 = heff_get(heff_dup(v_tf_242), LBL_large);
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop(v_tf_242);
      heff_drop_cell(v_ru_24t_243_24SU, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_246 = ({ V a_0 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str0); V a_1 = v_name_241; V b_2 = heff_get(heff_dup(v_tf_242), LBL_params); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_247 = ({ V a_0 = heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_get(heff_dup(v_tf_242), LBL_names); V b_3 = heff_get(v_tf_242, LBL_def); V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_248 = heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str1), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str2), heff_strAppend(v_t_247, ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str3)))));
      return heff_tag_at(v_ru_24t_243_24SU, TAG_Just, 1, (V[]){v_t_248});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_SDecode: {
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_2410 = heff_get(heff_dup(v_tf_242), LBL_large);
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop(v_tf_242);
      heff_drop_cell(v_ru_24t_243_24SDecode, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2411 = ({ V a_0 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str4); V a_1 = v_name_241; V b_2 = heff_get(heff_dup(v_tf_242), LBL_params); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2412 = ({ V a_0 = heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_get(heff_dup(v_tf_242), LBL_names); V b_3 = heff_get(v_tf_242, LBL_def); V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2413 = heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str5), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str6), heff_strAppend(v_t_2412, ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str7)))));
      return heff_tag_at(v_ru_24t_243_24SDecode, TAG_Just, 1, (V[]){v_t_2413});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  case TAG_SFunction: {
    heff_take_n(v_t_243, 0ULL, 5);
    V v_t_2419 = heff_get(heff_dup(v_tf_242), LBL_large);
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop(v_tf_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2420 = ({ V a_0 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str8); V a_1 = v_name_241; V b_2 = heff_get(heff_dup(v_tf_242), LBL_params); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2421 = ({ V a_0 = heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_get(heff_dup(v_tf_242), LBL_names); V b_3 = heff_get(v_tf_242, LBL_def); V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2422 = heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str9), heff_strAppend(v_t_2420, heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str10), heff_strAppend(v_t_2421, ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str11)))));
      return heff_tag(TAG_Just, 1, (V[]){v_t_2422});
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  case TAG_SRecord: {
    V v_fs_2424 = heff_field(v_t_243, 1);
    V v_ds_2425 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 6ULL, 3);
    V v_t_2426 = heff_get(heff_dup(v_tf_242), LBL_large);
    switch (heff_tag_of(v_t_2426)) {
    case TAG_True: {
      V v_t_2427 = ({ V a_0 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str12); V a_1 = v_name_241; V b_2 = heff_get(heff_dup(v_tf_242), LBL_params); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2428 = heff_arrayToList(heff_get(heff_dup(v_fs_2424), LBL_keys));
      V v_t_2429 = heff_arrayToList(heff_get(v_fs_2424, LBL_values));
      V v_fs_2430 = (g_heff_2edict_2ezipKV(v_t_2428, v_t_2429));
      V v_t_2431 = heff_rec(2, shape_names__out, (V[]){heff_get(v_tf_242, LBL_names), NTAG(TAG_Nil)});
      V v_acc_2434 = ({ V a_0 = heff_clo(g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_lam0, 2, 2, (V[]){v_lit_240, v_ds_2425}); V a_1 = v_t_2431; V a_2 = v_fs_2430; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2430); r_; });
      V v_x2_2435 = (g_prelude_2emap_24s1559710030x546042594(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str13), heff_get(v_acc_2434, LBL_out)));
      V v_t_2438;
      switch (heff_tag_of(v_x2_2435)) {
      case TAG_Nil: {
        v_t_2438 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str14);
        break;
      }
      case TAG_Cons: {
        V v_x_2436 = heff_field(v_x2_2435, 0);
        V v_xs_2437 = heff_field(v_x2_2435, 1);
        heff_take_n(v_x2_2435, 3ULL, 2);
        v_t_2438 = ({ V a_0 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str15); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2435);
      }
      V v_t_2439 = heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str16), heff_strAppend(v_t_2427, heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str17), heff_strAppend(v_t_2438, ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str18)))));
      return heff_tag(TAG_Just, 1, (V[]){v_t_2439});
    }
    case TAG_False: {
      heff_drop(v_fs_2424);
      heff_drop(v_ds_2425);
      V v_t_2440 = ({ V a_0 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str19); V a_1 = v_name_241; V b_2 = heff_get(heff_dup(v_tf_242), LBL_params); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2441 = ({ V a_0 = heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_get(heff_dup(v_tf_242), LBL_names); V b_3 = heff_get(v_tf_242, LBL_def); V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2442 = heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str20), heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str21), heff_strAppend(v_t_2441, ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str22)))));
      return heff_tag(TAG_Just, 1, (V[]){v_t_2442});
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  case TAG_SSum: {
    V v_vs_2443 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2444 = heff_get(heff_dup(v_tf_242), LBL_large);
    switch (heff_tag_of(v_t_2444)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop(v_tf_242);
      heff_drop(v_vs_2443);
      heff_drop_cell(v_ru_24t_243_24SSum, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2445 = ({ V a_0 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str23); V a_1 = v_name_241; V b_2 = heff_get(heff_dup(v_tf_242), LBL_params); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2446 = heff_arrayToList(heff_get(heff_dup(v_vs_2443), LBL_keys));
      V v_t_2447 = heff_arrayToList(heff_get(heff_dup(v_vs_2443), LBL_values));
      V v_x1_2448 = (g_heff_2edict_2ezipKV(v_t_2446, v_t_2447));
      V v_t_2451;
      switch (heff_tag_of(v_x1_2448)) {
      case TAG_Nil: {
        v_t_2451 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_x1_2448, 0ULL, 2);
        v_t_2451 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x1_2448);
      }
      V v_t_2466;
      switch (heff_tag_of(v_t_2451)) {
      case TAG_True: {
        heff_drop(v_lit_240);
        heff_drop(v_tf_242);
        heff_drop(v_vs_2443);
        v_t_2466 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str24);
        break;
      }
      case TAG_False: {
        V v_t_2452 = heff_arrayToList(heff_get(heff_dup(v_vs_2443), LBL_keys));
        V v_t_2453 = heff_arrayToList(heff_get(v_vs_2443, LBL_values));
        V v_t_2454 = (g_heff_2edict_2ezipKV(v_t_2452, v_t_2453));
        V v_x2_2462 = (g_prelude_2emap(heff_clo(g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_lam1, 1, 2, (V[]){v_lit_240, v_tf_242}), v_t_2454));
        V v_t_2465;
        switch (heff_tag_of(v_x2_2462)) {
        case TAG_Nil: {
          v_t_2465 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str27);
          break;
        }
        case TAG_Cons: {
          V v_x_2463 = heff_field(v_x2_2462, 0);
          V v_xs_2464 = heff_field(v_x2_2462, 1);
          heff_take_n(v_x2_2462, 3ULL, 2);
          v_t_2465 = ({ V a_0 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str28); V a_1 = v_x_2463; V a_2 = v_xs_2464; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2464); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2462);
        }
        v_t_2466 = heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str29), v_t_2465);
        break;
      }
      default: heff_nomatch(v_t_2451);
      }
      V v_t_2467 = heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str30), heff_strAppend(v_t_2445, heff_strAppend(v_t_2466, ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str31))));
      return heff_tag_at(v_ru_24t_243_24SSum, TAG_Just, 1, (V[]){v_t_2467});
    }
    default: return heff_nomatch(v_t_2444);
    }
  }
  case TAG_SIsTy: {
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_2469 = heff_get(heff_dup(v_tf_242), LBL_large);
    switch (heff_tag_of(v_t_2469)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop(v_tf_242);
      heff_drop_cell(v_ru_24t_243_24SIsTy, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2470 = ({ V a_0 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str32); V a_1 = v_name_241; V b_2 = heff_get(heff_dup(v_tf_242), LBL_params); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2471 = ({ V a_0 = heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_get(heff_dup(v_tf_242), LBL_names); V b_3 = heff_get(v_tf_242, LBL_def); V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2472 = heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str33), heff_strAppend(v_t_2470, heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str34), heff_strAppend(v_t_2471, ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str35)))));
      return heff_tag_at(v_ru_24t_243_24SIsTy, TAG_Just, 1, (V[]){v_t_2472});
    }
    default: return heff_nomatch(v_t_2469);
    }
  }
  case TAG_SPrimInt: {
    V v_t_2473 = heff_get(heff_dup(v_tf_242), LBL_large);
    switch (heff_tag_of(v_t_2473)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop(v_tf_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2474 = ({ V a_0 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str36); V a_1 = v_name_241; V b_2 = heff_get(heff_dup(v_tf_242), LBL_params); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2475 = ({ V a_0 = heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_get(heff_dup(v_tf_242), LBL_names); V b_3 = heff_get(v_tf_242, LBL_def); V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2476 = heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str37), heff_strAppend(v_t_2474, heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str38), heff_strAppend(v_t_2475, ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str39)))));
      return heff_tag(TAG_Just, 1, (V[]){v_t_2476});
    }
    default: return heff_nomatch(v_t_2473);
    }
  }
  case TAG_SPrimFloat: {
    V v_t_2477 = heff_get(heff_dup(v_tf_242), LBL_large);
    switch (heff_tag_of(v_t_2477)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop(v_tf_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2478 = ({ V a_0 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str40); V a_1 = v_name_241; V b_2 = heff_get(heff_dup(v_tf_242), LBL_params); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2479 = ({ V a_0 = heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_get(heff_dup(v_tf_242), LBL_names); V b_3 = heff_get(v_tf_242, LBL_def); V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2480 = heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str41), heff_strAppend(v_t_2478, heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str42), heff_strAppend(v_t_2479, ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str43)))));
      return heff_tag(TAG_Just, 1, (V[]){v_t_2480});
    }
    default: return heff_nomatch(v_t_2477);
    }
  }
  case TAG_SPrimString: {
    V v_t_2481 = heff_get(heff_dup(v_tf_242), LBL_large);
    switch (heff_tag_of(v_t_2481)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop(v_tf_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2482 = ({ V a_0 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str44); V a_1 = v_name_241; V b_2 = heff_get(heff_dup(v_tf_242), LBL_params); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2483 = ({ V a_0 = heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_get(heff_dup(v_tf_242), LBL_names); V b_3 = heff_get(v_tf_242, LBL_def); V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2484 = heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str45), heff_strAppend(v_t_2482, heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str46), heff_strAppend(v_t_2483, ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str47)))));
      return heff_tag(TAG_Just, 1, (V[]){v_t_2484});
    }
    default: return heff_nomatch(v_t_2481);
    }
  }
  case TAG_SPrimArray: {
    V v_ru_24t_243_24SPrimArray = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_2486 = heff_get(heff_dup(v_tf_242), LBL_large);
    switch (heff_tag_of(v_t_2486)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop(v_tf_242);
      heff_drop_cell(v_ru_24t_243_24SPrimArray, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2487 = ({ V a_0 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str48); V a_1 = v_name_241; V b_2 = heff_get(heff_dup(v_tf_242), LBL_params); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2488 = ({ V a_0 = heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_get(heff_dup(v_tf_242), LBL_names); V b_3 = heff_get(v_tf_242, LBL_def); V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2489 = heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str49), heff_strAppend(v_t_2487, heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str50), heff_strAppend(v_t_2488, ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str51)))));
      return heff_tag_at(v_ru_24t_243_24SPrimArray, TAG_Just, 1, (V[]){v_t_2489});
    }
    default: return heff_nomatch(v_t_2486);
    }
  }
  case TAG_SFixed: {
    V v_ru_24t_243_24SFixed = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_2491 = heff_get(heff_dup(v_tf_242), LBL_large);
    switch (heff_tag_of(v_t_2491)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop(v_tf_242);
      heff_drop_cell(v_ru_24t_243_24SFixed, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2492 = ({ V a_0 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str52); V a_1 = v_name_241; V b_2 = heff_get(heff_dup(v_tf_242), LBL_params); V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_t_2493 = ({ V a_0 = heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_get(heff_dup(v_tf_242), LBL_names); V b_3 = heff_get(v_tf_242, LBL_def); V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2494 = heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str53), heff_strAppend(v_t_2492, heff_strAppend(((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str54), heff_strAppend(v_t_2493, ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str55)))));
      return heff_tag_at(v_ru_24t_243_24SFixed, TAG_Just, 1, (V[]){v_t_2494});
    }
    default: return heff_nomatch(v_t_2491);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2eformerOf_24s1996635939x1902066865(a[0], a[1], a[2]);
}
V g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_lam0(V self, V *args) {
  V v_acc_2432 = args[0];
  V v_f_2433 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2epsurface_2erecordField_24s464605383x1219605104(heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}), v_ds_2425, v_acc_2432, v_f_2433));
}
V g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_lam2(V self, V *args) {
  V v_t2_2458 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_tf_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = heff_rec(2, shape_im__indent, (V[]){heff_dup(g_heff_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(2LL); V a_2 = heff_get(v_tf_242, LBL_names); V a_3 = v_t2_2458; V r_ = (g_heff_2epsurface_2etyF_24s1319128358x1023081884(a_0, a_1, a_2, a_3)); heff_drop(v_t2_2458); r_; });
}
V g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_lam1(V self, V *args) {
  V v_v_2455 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_tf_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2455)) {
  case TAG_MkPair: {
    V v_t_2456 = heff_field(v_v_2455, 0);
    V v_ts_2457 = heff_field(v_v_2455, 1);
    V v_ru_24v_2455_24MkPair = heff_take_reuse_n(v_v_2455, 3ULL, 2);
    V v_x2_2459 = heff_tag_at(v_ru_24v_2455_24MkPair, TAG_Cons, 2, (V[]){v_t_2456, (g_prelude_2emap(heff_clo(g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_lam2, 1, 2, (V[]){v_lit_240, v_tf_242}), heff_arrayToList(v_ts_2457)))});
    switch (heff_tag_of(v_x2_2459)) {
    case TAG_Nil: {
      return ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str25);
    }
    case TAG_Cons: {
      V v_x_2460 = heff_field(v_x2_2459, 0);
      V v_xs_2461 = heff_field(v_x2_2459, 1);
      heff_take_n(v_x2_2459, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2epsurface_2eformerOf_24s1996635939x1902066865_str26); V a_1 = v_x_2460; V a_2 = v_xs_2461; V r_ = (g_prelude_2efoldl_24s1939305664x1902528268(a_0, a_1, a_2)); heff_drop(v_xs_2461); r_; });
    }
    default: return heff_nomatch(v_x2_2459);
    }
  }
  default: return heff_nomatch(v_v_2455);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eprintSig_24s1956922268x1093670426_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eprintSig_24s1956922268x1093670426_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2epsurface_2eprintSig_24s1956922268x1093670426_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2epsurface_2eprintSig_24s1956922268x1093670426_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2epsurface_2eprintSig_24s1956922268x1093670426_clo = {{0x80000000u, K_CLO, 0}, g_heff_2epsurface_2eprintSig_24s1956922268x1093670426_entry, 4, 0};

V g_heff_2epsurface_2eprintSig_24s1956922268x1093670426(V v_name_240, V v_shown_241, V v_t_242, V v_body_243) {
top: ;
  V v_t_244 = (g_heff_2epsurface_2eprimitiveOf(heff_dup(v_body_243)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_heff_2epsurface_2etyF_24s410763399x651256744(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_242));
    V v_d_246 = heff_strAppend(v_shown_241, heff_strAppend(((V)&g_heff_2epsurface_2eprintSig_24s1956922268x1093670426_str0), heff_strAppend(v_t_245, ((V)&g_heff_2epsurface_2eprintSig_24s1956922268x1093670426_str1))));
    V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_name_240), NTAG(TAG_Nil)});
    V v_t_248 = (g_heff_2epsurface_2etypeFormer(v_t_242, v_body_243, v_t_247, NTAG(TAG_Nil)));
    V v_x2_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_name_240);
      v_x2_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_tf_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      v_x2_2410 = (g_heff_2epsurface_2eformerOf_24s1996635939x1902066865(MK_INT(0LL), v_name_240, v_tf_249));
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nothing: {
      return v_d_246;
    }
    case TAG_Just: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      heff_take_n(v_x2_2410, 1ULL, 1);
      heff_drop(v_d_246);
      return v_x_2411;
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  case TAG_Just: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_name_240);
    heff_drop(v_body_243);
    V v_t_2413 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_242; V r_ = (g_heff_2epsurface_2etyF_24s410763399x651256744(a_0, a_1, a_2, a_3)); heff_drop(v_t_242); r_; });
    return heff_strAppend(v_shown_241, heff_strAppend(((V)&g_heff_2epsurface_2eprintSig_24s1956922268x1093670426_str2), heff_strAppend(v_t_2413, ((V)&g_heff_2epsurface_2eprintSig_24s1956922268x1093670426_str3))));
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2epsurface_2eprintSig_24s1956922268x1093670426_entry(V self, V *a) {
  (void)self;
  return g_heff_2epsurface_2eprintSig_24s1956922268x1093670426(a[0], a[1], a[2], a[3]);
}