// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Pend 2230
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Settled 45257
#define TAG_Signalled 34337
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failed 665164648
#define LBL_file 9638467
#define LBL_group 299987609
#define LBL_heff 9694020
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_message 1186782793
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_out 319944
#define LBL_outcomes 803130769
#define LBL_output 941629484
#define LBL_package 1572278921
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_reports 1326460931
#define LBL_root 10001833
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_timeout 1065429926
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_wrong 314763719
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502(V, V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235(V, V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235_clo;
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696(V, V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_clo;
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250(V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250_clo;
V g_heff_2ebuild_2epackaging_2ebuildText_get(void);
V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231(V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_clo;
V g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536(V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_clo;
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876(V, V, V, V);
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_clo;
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0_clo;
V g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563(V, V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_clo;
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738(V, V);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_clo;
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139(V, V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_clo;
V g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156(V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_clo;
V g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258(V, V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_clo;
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859(V, V, V);
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_clo;
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823(V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_clo;
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT5 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_clo;
V g_heff_2ebuild_2etesting_2eaddRes(V, V);
V g_heff_2ebuild_2etesting_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eaddRes_clo;
V g_heff_2ebuild_2etesting_2enoRes_get(void);
V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949(V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949_clo;
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856(V, V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856_clo;
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869(V, V, V, V);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(V, V);
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(V, V, V);
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str1, 13, "build : Build");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str2, 37, "build = { backend = C, run = \"main\" }");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str3, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str5, 21, "-- heff home with it.");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str7, 69, "-- page's script of it.  A field `ships = [...]` would name files and");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str8, 69, "-- directories of the project's root for `heff install` to put in the");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str10, 69, "-- main.hf's `main`, compiled through C (by `zig cc`); `Page` makes a");

static V g_heff_2ebuild_2epackaging_2ebuildText_val;
static HEFF_ONCE g_heff_2ebuild_2epackaging_2ebuildText_st;
static V g_heff_2ebuild_2epackaging_2ebuildText_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2ebuildText_str9); V a_1 = ((V)&g_heff_2ebuild_2epackaging_2ebuildText_str10); V a_2 = v_t_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ebuild_2epackaging_2ebuildText_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2epackaging_2ebuildText_st)) return g_heff_2ebuild_2epackaging_2ebuildText_val;
  return heff_global(&g_heff_2ebuild_2epackaging_2ebuildText_val, &g_heff_2ebuild_2epackaging_2ebuildText_st, g_heff_2ebuild_2epackaging_2ebuildText_init);
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_str0, 5, "win32");
V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam0(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam0, 1, 0};
V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam2(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam2, 3, 0};
V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_entry, 5, 0};

V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231(V v_e_240, V v_dir_241, V v_x2_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_dir_241);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_f_247 = heff_field(v_x21_245, 0);
      heff_take_n(v_x21_245, 1ULL, 2);
      V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam0_clo)})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2416, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam1, 1, 6, (V[]){v_dir_241, v_f_247, v_e_240, v_p_243, v_rest_246, v_p_244})));
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam0(V self, V *args) {
  V v_s_249 = args[0];
  return v_s_249;
}
V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2427 = args[1];
  V v_k_2428 = args[2];
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_p_244;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_f_247, v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_f_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    heff_take_n(v_x_2430, 0ULL, 1);
    heff_drop(v_f_247);
    return (g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231(v_e_240, v_dir_241, v_rest_246, v_p_243, v_p_244));
  }
  case TAG_Right: {
    heff_take_n(v_x_2430, 0ULL, 1);
    return (g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231(v_e_240, v_dir_241, v_rest_246, v_p_243, heff_clo_n(g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam4, 1, 2, (V[]){v_p_244, v_f_247})));
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_dir_241 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2418;
  if (heff_strEq_c(v_x_2417, ((V)&g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_dir_241)));
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_f_247)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2421); r_; });
  V v_path_2423 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2422));
  V v_c_2424 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2423; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2423); r_; });
  V v_t_2425 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2429 = heff_tr(heff_call(v_c_2424, 2, (V[]){v_t_2425, ((V)&g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam2_clo)}));
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2eexisting_24s961713840x1253168231_lam3, 1, 6, (V[]){v_e_240, v_dir_241, v_rest_246, v_p_243, v_p_244, v_f_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_str2, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_str4, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_str5, 1, "\012");
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam0(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam0, 1, 0};
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam2(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam2, 3, 0};
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam4(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam4, 3, 0};
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam6(V self, V *args);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam7(V self, V *args);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam5(V self, V *args);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_entry, 5, 0};

V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823(V v_e_240, V v_dir_241, V v_x2_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_dir_241);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_f_247 = heff_field(v_x21_245, 0);
      V v_text_248 = heff_field(v_x21_245, 1);
      heff_take_n(v_x21_245, 3ULL, 2);
      V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam0_clo)})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2416, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam1, 1, 7, (V[]){v_dir_241, v_f_247, v_e_240, v_p_243, v_text_248, v_rest_246, v_p_244})));
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam0(V self, V *args) {
  V v_s_249 = args[0];
  return v_s_249;
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam2(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_2439 = args[1];
  V v_k_2440 = args[2];
  heff_drop(v_hd_2439);
  V f_ = v_k_2440;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam4(V self, V *args) {
  V v_x_2461 = args[0];
  V v_hd_2462 = args[1];
  V v_k_2463 = args[2];
  heff_drop(v_hd_2462);
  V f_ = v_k_2463;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2461});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam6(V self, V *args) {
  V v_x_2479 = args[0];
  V v_p_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2479);
  V f_ = v_p_244;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam7(V self, V *args) {
  V v_x_2493 = args[0];
  V v_p_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2493);
  V f_ = v_p_244;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam5(V self, V *args) {
  V v_x_2465 = args[0];
  V v_x_2445 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_st_2418 = heff_env(self)[6];
  V v_f_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  switch (heff_tag_of(v_x_2465)) {
  case TAG_Left: {
    V v_ru_24x_2465_24Left = heff_take_reuse_n(v_x_2465, 0ULL, 1);
    if (((heff_dup(v_x_2445) == NTAG(TAG_True)) && 0)) {
      heff_drop(v_x_2445);
      heff_drop(v_st_2418);
      heff_drop(v_f_247);
      heff_drop_cell(v_ru_24x_2465_24Left, 1);
      return (g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823(v_e_240, v_dir_241, v_rest_246, v_p_243, v_p_244));
    } else {
      heff_drop(v_x_2445);
      heff_drop(v_rest_246);
      V v_t_2467 = (g_std_2epath_2eparse(heff_dup(v_st_2418), v_dir_241));
      V v_t_2468 = (g_std_2epath_2eparse(heff_dup(v_st_2418), v_f_247));
      V v_t_2469 = (g_std_2epath_2ejoin(v_t_2467, v_t_2468));
      V v_t_2470 = ({ V a_0 = v_st_2418; V a_1 = v_t_2469; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2469); r_; });
      V v_str_2471 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_str2), v_t_2470);
      V v_t_2472 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2471, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_str3)), NTAG(TAG_MkUnit)});
      V v_t_2473 = heff_tag_at_n(v_ru_24x_2465_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
      V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
      V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
      V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
      V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
      V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2478}), v_p_243, heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam6, 1, 1, (V[]){v_p_244})));
    }
  }
  case TAG_Right: {
    V v_ru_24x_2465_24Right = heff_take_reuse_n(v_x_2465, 0ULL, 1);
    if ((heff_dup(v_x_2445) == NTAG(TAG_True))) {
      heff_drop(v_x_2445);
      heff_drop(v_st_2418);
      heff_drop(v_f_247);
      heff_drop_cell(v_ru_24x_2465_24Right, 1);
      return (g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823(v_e_240, v_dir_241, v_rest_246, v_p_243, v_p_244));
    } else {
      heff_drop(v_x_2445);
      heff_drop(v_rest_246);
      V v_t_2481 = (g_std_2epath_2eparse(heff_dup(v_st_2418), v_dir_241));
      V v_t_2482 = (g_std_2epath_2eparse(heff_dup(v_st_2418), v_f_247));
      V v_t_2483 = (g_std_2epath_2ejoin(v_t_2481, v_t_2482));
      V v_t_2484 = ({ V a_0 = v_st_2418; V a_1 = v_t_2483; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2483); r_; });
      V v_str_2485 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_str4), v_t_2484);
      V v_t_2486 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2485, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_str5)), NTAG(TAG_MkUnit)});
      V v_t_2487 = heff_tag_at_n(v_ru_24x_2465_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
      V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
      V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
      V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
      V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
      V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2492}), v_p_243, heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam7, 1, 1, (V[]){v_p_244})));
    }
  }
  default: return heff_nomatch(v_x_2465);
  }
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam3(V self, V *args) {
  V v_x_2442 = args[0];
  V v_st_2418 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_f_247 = heff_env(self)[2];
  V v_text_248 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  V v_rest_246 = heff_env(self)[6];
  V v_p_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x_2445;
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Left: {
    heff_take_n(v_x_2442, 0ULL, 1);
    v_x_2445 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2442, 0ULL, 1);
    v_x_2445 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2442);
  }
  V v_t_2446 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_dir_241)));
  V v_t_2447 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_f_247)));
  V v_t_2448 = (g_std_2epath_2ejoin(v_t_2446, v_t_2447));
  V v_s_2449 = ({ V a_0 = v_st_2418; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2448); r_; });
  V v_path_2450 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2449));
  int64_t v_t_2451 = (heff_unbox_word(heff_strLength_lent(v_f_247, 0)) - ((int64_t)3ULL));
  V v_t_2452 = heff_strSlice(heff_dup(v_f_247), heff_box_word(v_t_2451), heff_strLength_lent(v_f_247, 0));
  V v_text_2458;
  if (heff_strEq_c(v_t_2452, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_str1))) {
    HeffT2 v_t_2453 = (g_heff_2esyntax_2eformat_2eformat_24cpr(heff_dup(v_text_248)));
    {
      V v_field_2455 = v_t_2453.f[1];
      int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
      if ((v_tag_2454 == ((int64_t)0ULL))) {
        V v_x_2456 = v_field_2455;
        heff_drop(v_x_2456);
        v_text_2458 = v_text_248;
      } else {
        heff_drop(v_text_248);
        V v_out_2457 = v_field_2455;
        v_text_2458 = v_out_2457;
      }
    }
  } else {
    v_text_2458 = v_text_248;
  }
  V v_c_2459 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2450; V a_2 = v_text_2458; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2450); r_; });
  V v_t_2460 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2464 = heff_tr(heff_call(v_c_2459, 2, (V[]){v_t_2460, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam4_clo)}));
  V f_ = v_c_2464;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam5, 1, 8, (V[]){v_x_2445, v_e_240, v_dir_241, v_rest_246, v_p_243, v_p_244, v_st_2418, v_f_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_dir_241 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_text_248 = heff_env(self)[4];
  V v_rest_246 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2418;
  if (heff_strEq_c(v_x_2417, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_dir_241)));
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_f_247)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  HeffT3 v_t_2423 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2418), v_s_2422));
  V v_t_2433;
  {
    V v_field_2424 = v_t_2423.f[0];
    V v_field_2425 = v_t_2423.f[1];
    V v_field_2426 = v_t_2423.f[2];
    V v_d_2427 = v_field_2424;
    V v_a_2428 = v_field_2425;
    V v_xs_2429 = v_field_2426;
    V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2429));
    V v_xs_2431 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2430; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2430); r_; });
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
    v_t_2433 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2427, v_a_2428, v_t_2432});
  }
  V v_s_2434 = ({ V a_0 = v_st_2418; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2433); r_; });
  V v_path_2435 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2434));
  V v_c_2436 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2435; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_2435); r_; });
  V v_t_2437 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2441 = heff_tr(heff_call(v_c_2436, 2, (V[]){v_t_2437, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam2_clo)}));
  V f_ = v_c_2441;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s843312882x140591823_lam3, 1, 8, (V[]){v_st_2418, v_dir_241, v_f_247, v_text_248, v_e_240, v_p_243, v_rest_246, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_lam2(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_lam2, 3, 0};
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_lam1(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_lam0(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_entry, 4, 0};

V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876(V v_e_240, V v_dir_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502(heff_dup(v_e_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_lam0, 1, 4, (V[]){v_e_240, v_hd_242, v_dir_241, v_k_243})));
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_2410 = args[1];
  V v_k_2411 = args[2];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Left: {
    heff_take_n(v_x_2413, 0ULL, 1);
    return ({ V a_0 = v_e_240; V a_1 = v_hd_242; V a_2 = v_dir_241; V a_3 = v_x_244; V a_4 = v_k_243; V b_5 = NTAG(TAG_Nothing); V r_ = (g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0(a_0, a_1, a_2, a_3, a_4, b_5)); heff_drop(b_5); r_; });
  }
  case TAG_Right: {
    V v_y_2415 = heff_field(v_x_2413, 0);
    V v_ru_24x_2413_24Right = heff_take_reuse_n(v_x_2413, 1ULL, 1);
    HeffT2 v_t_2416 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_y_2415));
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      V v_x_2426;
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_2413_24Right, 1);
        V v_p_2419 = v_field_2418;
        heff_drop(v_p_2419);
        v_x_2426 = NTAG(TAG_Nothing);
      } else {
        V v_x_2420 = v_field_2418;
        HeffT2 v_t_2421 = ({ V a_0 = v_x_2420; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_2420); r_; });
        {
          V v_field_2423 = v_t_2421.f[1];
          int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
          if ((v_tag_2422 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x_2413_24Right, 1);
            V v_x_2424 = v_field_2423;
            heff_drop(v_x_2424);
            v_x_2426 = NTAG(TAG_Nothing);
          } else {
            V v_p_2425 = v_field_2423;
            v_x_2426 = heff_tag_at_n(v_ru_24x_2413_24Right, TAG_Just, 1, (V[]){heff_get_n(v_p_2425, 1, 4)});
          }
        }
      }
      return ({ V a_0 = v_e_240; V a_1 = v_hd_242; V a_2 = v_dir_241; V a_3 = v_x_244; V a_4 = v_k_243; V a_5 = v_x_2426; V r_ = (g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_2426); r_; });
    }
  }
  default: return heff_nomatch(v_x_2413);
  }
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_245));
  V v_c_247 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_246; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_246); r_; });
  V v_t_248 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2412 = heff_tr(heff_call(v_c_247, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_lam2_clo)}));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_lam3, 1, 5, (V[]){v_e_240, v_hd_242, v_dir_241, v_x_244, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_dir_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eownPackage_24s2025560055x1262108696(heff_dup(v_e_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s1313674352x37659876_lam1, 1, 5, (V[]){v_e_240, v_hd_242, v_dir_241, v_x_244, v_k_243})));
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_str0, 0, "");
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam0(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam5(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam6(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_entry, 3, 0};

V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859(V v_e_240, V v_x1_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    return heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x1_241, 0);
    V v_rest_246 = heff_field(v_x1_241, 1);
    V v_c_247 = (g_heff_2ebuild_2etesting_2etestOneF_24s1666780449x615347949(MK_INT(2026LL), ((V)&g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_str0), MK_INT(1LL), heff_dup(v_e_240), heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam1, 2, 4, (V[]){v_c_247, v_e_240, v_acc_242, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam3(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_r_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = v_r_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_file_2415 = heff_env(self)[1];
  V v_wrong_2417 = heff_env(self)[2];
  V v_reports_2418 = heff_env(self)[3];
  V v_hd_2420 = heff_env(self)[4];
  V v_k_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2etesting_2etestReport_24s1026466923x1801215856(v_e_240, v_file_2415, v_wrong_2417, v_reports_2418, v_x_2422, v_hd_2420, v_k_2421));
}
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam4(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_c_2419 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_file_2415 = heff_env(self)[2];
  V v_wrong_2417 = heff_env(self)[3];
  V v_reports_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2419;
  args[0] = heff_dup(v_hd_2420);
  args[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam5, 1, 6, (V[]){v_e_240, v_file_2415, v_wrong_2417, v_reports_2418, v_hd_2420, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425 = (g_heff_2ebuild_2etesting_2eaddRes(v_acc_242, v_x_2424));
  V v_t_2426 = ({ V a_0 = v_e_240; V a_1 = v_rest_246; V a_2 = v_t_2425; V r_ = (g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2426;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2423;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Settled: {
    V v_r_2411 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    v_c_2423 = heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam3, 2, 1, (V[]){v_r_2411});
    break;
  }
  case TAG_Pend: {
    V v_p_2414 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    V v_file_2415 = heff_take_field(v_p_2414, 0);
    V v_outcomes_2416 = heff_take_field(v_p_2414, 3);
    V v_wrong_2417 = heff_take_field(v_p_2414, 1);
    V v_reports_2418 = heff_get_n(v_p_2414, 2, 7);
    V v_c_2419 = ({ V a_0 = heff_dup(v_e_240); V b_1 = NTAG(TAG_False); V a_2 = heff_dup(v_file_2415); V a_3 = v_outcomes_2416; V r_ = (g_heff_2ebuild_2etesting_2ewithGoldens_24s298431660x2102340869(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
    v_c_2423 = heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam4, 2, 5, (V[]){v_c_2419, heff_dup(v_e_240), v_file_2415, v_wrong_2417, v_reports_2418});
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_248);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam6, 1, 5, (V[]){v_acc_242, v_e_240, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859_lam2, 1, 5, (V[]){v_e_240, v_hd_248, v_acc_242, v_rest_246, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str0, 3, "git");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str4, 6, ": git ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str9, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str11, 2, ": ");
V g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_lam0(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_lam0, 1, 0};
V g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_entry, 5, 0};

V g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536(V v_e_240, V v_what_241, V v_argv_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str0), heff_dup(v_argv_242), ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str1), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_245, ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2413, v_hd_243, heff_clo_n(g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_lam1, 1, 3, (V[]){v_argv_242, v_what_241, v_k_244})));
}
V g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_argv_242 = heff_env(self)[0];
  V v_what_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_ended_2415 = heff_take_field(v_x_2414, 0);
  V v_err_2416 = heff_get_n(v_x_2414, 2, 3);
  V v_t_2420;
  switch (heff_tag_of(v_ended_2415)) {
  case TAG_Exited: {
    V v_n_2417 = heff_dup(heff_field(v_ended_2415, 0));
    v_t_2420 = heff_bool(heff_intEq_c_lent(v_n_2417, MK_INT(0LL), 2));
    heff_drop(v_n_2417);
    break;
  }
  case TAG_Signalled: {
    v_t_2420 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2420 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2420 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_ended_2415);
  }
  V v_x_2440;
  if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
    heff_drop(v_argv_242);
    heff_drop(v_what_241);
    heff_drop(v_ended_2415);
    heff_drop(v_err_2416);
    heff_drop(v_t_2420);
    v_x_2440 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_2420);
    V v_t_2423;
    switch (heff_tag_of(v_argv_242)) {
    case TAG_Nil: {
      v_t_2423 = ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_argv_242, 0);
      V v_xs_2422 = heff_field(v_argv_242, 1);
      heff_take_n(v_argv_242, 3ULL, 2);
      v_t_2423 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str3); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_argv_242);
    }
    V v_t_2424 = heff_strAppend(heff_strAppend(v_what_241, ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str4)), v_t_2423);
    V v_t_2433;
    switch (heff_tag_of(v_ended_2415)) {
    case TAG_Exited: {
      heff_take_n(v_ended_2415, 0ULL, 1);
      v_t_2433 = ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str5);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_ended_2415, 0ULL, 1);
      v_t_2433 = ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str6);
      break;
    }
    case TAG_TimedOut: {
      v_t_2433 = ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str7);
      break;
    }
    case TAG_NotRun: {
      V v_err_2427 = heff_field(v_ended_2415, 0);
      heff_take_n(v_ended_2415, 1ULL, 1);
      V v_path_2428 = heff_take_field(v_err_2427, 3);
      V v_name_2429 = heff_take_field(v_err_2427, 1);
      V v_message_2430 = heff_get_n(v_err_2427, 2, 4);
      V v_t_2431 = heff_strAppend(heff_strAppend(v_path_2428, ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str8)), v_name_2429);
      V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2431, ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str9)), v_message_2430);
      v_t_2433 = heff_strAppend(v_t_2432, ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str10));
      break;
    }
    default: heff_nomatch(v_ended_2415);
    }
    V v_s_2434 = heff_strAppend(v_t_2433, v_err_2416);
    V v_t_2435 = (g_prelude_2eskipSpaces(v_s_2434, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2436 = (heff_unbox_word(heff_strLength_lent(v_s_2434, 0)) - ((int64_t)1ULL));
    V v_t_2437 = (g_prelude_2eskipSpaces(v_s_2434, heff_box_word(v_t_2436), MK_INT(-1LL)));
    V v_t_2438 = heff_strSlice(v_s_2434, v_t_2435, heff_intAdd(v_t_2437, MK_INT(1LL)));
    V v_t_2439 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536_str11)), v_t_2438);
    v_x_2440 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2439});
  }
  V f_ = v_k_244;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str2, 2, "-m");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str3, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str4, 2, "-a");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str5, 10, "not tagged");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str7, 4, "push");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str8, 6, "origin");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str9, 18, "tagged, not pushed");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str10, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str11, 1, " ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str12, 7, ", tag v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str14, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str16, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str17, 1, "\012");
V g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_lam1(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_lam0(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_entry, 5, 0};

V g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156(V v_e_240, V v_v_241, V v_pk_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str0), heff_dup(v_v_241)), NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str1), heff_dup(v_v_241)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str2), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str4), v_t_246})});
  HEFF_LAST return g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str5), v_t_247, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_lam0, 1, 5, (V[]){v_v_241, v_e_240, v_hd_243, v_pk_242, v_k_244}));
}
V g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_lam2(V self, V *args) {
  V v_x_2431 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2431);
  V v_t_2432 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_pk_242 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str10), heff_get_n(v_pk_242, 0, 4));
    V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str11)), heff_dup(v_v_241));
    V v_t_2414 = heff_strAppend(heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str12)), v_v_241);
    V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str13)), NTAG(TAG_MkUnit)});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), v_hd_243, v_k_244));
  }
  case TAG_Just: {
    V v_why_2422 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Just = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    heff_drop_rec(v_pk_242, 4);
    heff_drop(v_v_241);
    V v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str14), v_why_2422), ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str15));
    V v_t_2424 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2423, NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_at_n(v_ru_24x_2411_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_lam2, 1, 3, (V[]){v_e_240, v_hd_243, v_k_244})));
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_lam3(V self, V *args) {
  V v_x_2448 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2448);
  V v_t_2449 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2455}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_v_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_pk_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str6), heff_dup(v_v_241)), NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str8), v_t_249})});
    return (g_heff_2ebuild_2epackaging_2egitOk_24s1600644197x1511166536(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str9), v_t_2410, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_lam1, 1, 5, (V[]){v_pk_242, v_v_241, v_e_240, v_hd_243, v_k_244})));
  }
  case TAG_Just: {
    V v_why_2439 = heff_field(v_x_248, 0);
    V v_ru_24x_248_24Just = heff_take_reuse_n(v_x_248, 1ULL, 1);
    heff_drop(v_v_241);
    heff_drop_rec(v_pk_242, 4);
    V v_t_2440 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str16), v_why_2439), ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_str17));
    V v_t_2441 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2440, NTAG(TAG_MkUnit)});
    V v_t_2442 = heff_tag_at_n(v_ru_24x_248_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156_lam3, 1, 3, (V[]){v_e_240, v_hd_243, v_k_244})));
  }
  default: return heff_nomatch(v_x_248);
  }
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_str0, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_str1, 27, " expectations do not hold, ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_str2, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_str3, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_str4, 37, " tests fail, or a file does not check");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_str5, 1, "\012");
V g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_lam0(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_entry, 6, 0};

V g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258(V v_e_240, V v_v_241, V v_pk_242, V v_r_243, V v_p_244, V v_p_245) {
top: ;
  V v_failed_246 = heff_take_field(v_r_243, 3);
  V v_testsFailed_247 = heff_take_field(v_r_243, 6);
  V v_unchecked_248 = heff_take_field(v_r_243, 4);
  V v_total_249 = heff_take_field(v_r_243, 2);
  V v_tests_2410 = heff_get_n(v_r_243, 5, 8);
  V v_t_2413;
  if (heff_intLt_c_lent(MK_INT(0LL), v_failed_246, 1)) {
    heff_drop(v_unchecked_248);
    v_t_2413 = NTAG(TAG_True);
  } else {
    if (heff_intLt_c_lent(MK_INT(0LL), v_testsFailed_247, 1)) {
      heff_drop(v_unchecked_248);
      v_t_2413 = NTAG(TAG_True);
    } else {
      switch (heff_tag_of(v_unchecked_248)) {
      case TAG_Nil: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_unchecked_248, 0ULL, 2);
        v_t_2413 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_unchecked_248);
      }
    }
  }
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_v_241);
    heff_drop(v_pk_242);
    heff_drop(v_t_2413);
    V v_t_2414 = heff_strAppend(heff_intShow(v_failed_246), ((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_str0));
    V v_t_2415 = heff_strAppend(v_t_2414, heff_intShow(v_total_249));
    V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_str1)), heff_intShow(v_testsFailed_247));
    V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_str2)), heff_intShow(v_tests_2410));
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_str3), heff_strAppend(v_t_2417, ((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_str4)));
    V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_str5)), NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_lam0, 1, 3, (V[]){v_e_240, v_p_244, v_p_245})));
  } else {
    heff_drop(v_failed_246);
    heff_drop(v_testsFailed_247);
    heff_drop(v_total_249);
    heff_drop(v_tests_2410);
    heff_drop(v_t_2413);
    return (g_heff_2ebuild_2epackaging_2epublishTag_24s1082125591x825915156(v_e_240, v_v_241, v_pk_242, v_p_244, v_p_245));
  }
}
V g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258_lam0(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_p_244, v_p_245));
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str0, 3, "git");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str1, 6, "status");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str2, 11, "--porcelain");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str3, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str4, 2, "-q");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str5, 8, "--verify");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str6, 3, "git");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str7, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str12, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str13, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str15, 25, "not in a git repository: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str16, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str17, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str19, 67, "heff publish: what is published is what is committed: commit first\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str20, 1, "v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str21, 18, " is tagged already");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str22, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str23, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str24, 0, "");
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam1(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam1, 1, 0};
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam5(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam7(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam6(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam0(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam8(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam8, 1, 0};
Clo g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_entry, 6, 0};

V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139(V v_e_240, V v_v_241, V v_pk_242, V v_src_243, V v_hd_244, V v_k_245) {
top: ;
  V v_lit_246 = ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str0);
  V v_lit_247 = ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str1);
  V v_lit_248 = ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str2);
  V v_lit_249 = MK_INT(0LL);
  V v_lit_2410 = MK_INT(0LL);
  V v_e_2411 = heff_dup(v_e_240);
  V v_p_2412 = heff_dup(v_hd_244);
  V v_p_24112 = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam0, 1, 6, (V[]){v_v_241, v_e_240, v_hd_244, v_k_245, v_src_243, v_pk_242});
  V v_t_24113 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_248, NTAG(TAG_Nil)});
  V v_t_24114 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_lit_246, heff_tag_n(TAG_Cons, 2, (V[]){v_lit_247, v_t_24113}), ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str24), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), v_lit_249, v_lit_2410, NTAG(TAG_False)});
  V v_t_24116 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_24114, ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam8_clo)})});
  V v_t_24117 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
  V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
  V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
  V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
  V v_t_24121 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
  V v_t_24122 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24121})});
  return (g_co_2eop_24s310169282x2049378029(v_e_2411, v_t_24122, v_p_2412, v_p_24112));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam1(V self, V *args) {
  V v_r_2420 = args[0];
  return v_r_2420;
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam3(V self, V *args) {
  V v_x_2456 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2456);
  V v_t_2457 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2463}), v_hd_244, v_k_245));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam4(V self, V *args) {
  V v_x_2477 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2477);
  V v_t_2478 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2484}), v_hd_244, v_k_245));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam5(V self, V *args) {
  V v_x_2499 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2499);
  V v_t_24100 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24100})});
  V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
  V v_t_24103 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24105})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24106}), v_hd_244, v_k_245));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam7(V self, V *args) {
  V v_x_24111 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  V v_pk_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2epackaging_2epublishTested_24s179218861x1855107258(v_e_240, v_v_241, v_pk_242, v_x_24111, v_hd_244, v_k_245));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam6(V self, V *args) {
  V v_x_24109 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  V v_pk_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_24110 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_x_24109; V a_2 = heff_dup(g_heff_2ebuild_2etesting_2enoRes_get()); V r_ = (g_heff_2ebuild_2epackaging_2etestAll_24s768696130x1504572859(a_0, a_1, a_2)); heff_drop(v_x_24109); r_; });
  V f_ = v_c_24110;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam7, 1, 5, (V[]){v_e_240, v_v_241, v_pk_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_ended_2414 = heff_env(self)[0];
  V v_err_2415 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_out_2416 = heff_env(self)[5];
  V v_v_241 = heff_env(self)[6];
  V v_src_243 = heff_env(self)[7];
  V v_pk_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2432;
  switch (heff_tag_of(v_ended_2414)) {
  case TAG_Exited: {
    V v_n_2429 = heff_dup(heff_field(v_ended_2414, 0));
    v_t_2432 = heff_bool(!heff_intEq_c_lent(v_n_2429, MK_INT(0LL), 2));
    heff_drop(v_n_2429);
    break;
  }
  case TAG_Signalled: {
    v_t_2432 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2432 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2432 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_ended_2414);
  }
  if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2428, 3);
    heff_drop(v_out_2416);
    heff_drop(v_v_241);
    heff_drop(v_src_243);
    heff_drop(v_pk_242);
    heff_drop(v_t_2432);
    V v_t_2441;
    switch (heff_tag_of(v_ended_2414)) {
    case TAG_Exited: {
      heff_take_n(v_ended_2414, 0ULL, 1);
      v_t_2441 = ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str9);
      break;
    }
    case TAG_Signalled: {
      heff_take_n(v_ended_2414, 0ULL, 1);
      v_t_2441 = ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str10);
      break;
    }
    case TAG_TimedOut: {
      v_t_2441 = ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str11);
      break;
    }
    case TAG_NotRun: {
      V v_err_2435 = heff_field(v_ended_2414, 0);
      heff_take_n(v_ended_2414, 1ULL, 1);
      V v_path_2436 = heff_take_field(v_err_2435, 3);
      V v_name_2437 = heff_take_field(v_err_2435, 1);
      V v_message_2438 = heff_get_n(v_err_2435, 2, 4);
      V v_t_2439 = heff_strAppend(heff_strAppend(v_path_2436, ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str12)), v_name_2437);
      V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2439, ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str13)), v_message_2438);
      v_t_2441 = heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str14));
      break;
    }
    default: heff_nomatch(v_ended_2414);
    }
    V v_s_2442 = heff_strAppend(v_t_2441, v_err_2415);
    V v_t_2443 = (g_prelude_2eskipSpaces(v_s_2442, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2444 = (heff_unbox_word(heff_strLength_lent(v_s_2442, 0)) - ((int64_t)1ULL));
    V v_t_2445 = (g_prelude_2eskipSpaces(v_s_2442, heff_box_word(v_t_2444), MK_INT(-1LL)));
    V v_t_2446 = heff_strSlice(v_s_2442, v_t_2443, heff_intAdd(v_t_2445, MK_INT(1LL)));
    V v_why_2447 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str15), v_t_2446);
    V v_t_2448 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str16), v_why_2447), ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str17));
    V v_t_2449 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2448, NTAG(TAG_MkUnit)});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2455}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam3, 1, 3, (V[]){v_e_240, v_hd_244, v_k_245})));
  } else {
    heff_drop(v_ended_2414);
    heff_drop(v_err_2415);
    heff_drop(v_t_2432);
    V v_s_2464 = v_out_2416;
    V v_t_2465 = (g_prelude_2eskipSpaces(v_s_2464, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2466 = (heff_unbox_word(heff_strLength_lent(v_s_2464, 0)) - ((int64_t)1ULL));
    V v_t_2467 = (g_prelude_2eskipSpaces(v_s_2464, heff_box_word(v_t_2466), MK_INT(-1LL)));
    V v_t_2468 = heff_strSlice(v_s_2464, v_t_2465, heff_intAdd(v_t_2467, MK_INT(1LL)));
    V v_x1_2469 = heff_bool(heff_strEq_c_lent(v_t_2468, ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str18), 2));
    heff_drop(v_t_2468);
    if (!(heff_dup(v_x1_2469) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2428, 3);
      heff_drop(v_v_241);
      heff_drop(v_src_243);
      heff_drop(v_pk_242);
      heff_drop(v_x1_2469);
      V v_t_2470 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str19), NTAG(TAG_MkUnit)});
      V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
      V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
      V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
      V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
      V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
      V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2476}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam4, 1, 3, (V[]){v_e_240, v_hd_244, v_k_245})));
    } else {
      heff_drop(v_x1_2469);
      V v_t_2485 = heff_get_n(v_x_2428, 0, 3);
      V v_t_2489;
      switch (heff_tag_of(v_t_2485)) {
      case TAG_Exited: {
        V v_n_2486 = heff_field(v_t_2485, 0);
        heff_take_n(v_t_2485, 1ULL, 1);
        v_t_2489 = heff_bool(heff_intEq_c_lent(v_n_2486, MK_INT(0LL), 2));
        heff_drop(v_n_2486);
        break;
      }
      case TAG_Signalled: {
        heff_take_n(v_t_2485, 0ULL, 1);
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      case TAG_TimedOut: {
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      case TAG_NotRun: {
        heff_take_n(v_t_2485, 0ULL, 1);
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2485);
      }
      if ((heff_dup(v_t_2489) == NTAG(TAG_True))) {
        heff_drop(v_src_243);
        heff_drop(v_pk_242);
        heff_drop(v_t_2489);
        V v_t_2490 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str20), v_v_241), ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str21));
        V v_t_2491 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str22), v_t_2490), ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str23));
        V v_t_2492 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2491, NTAG(TAG_MkUnit)});
        V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
        V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
        V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
        V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
        V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
        V v_t_2498 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2497})});
        return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2498}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam5, 1, 3, (V[]){v_e_240, v_hd_244, v_k_245})));
      } else {
        heff_drop(v_t_2489);
        V v_t_24107 = heff_tag_n(TAG_Cons, 2, (V[]){v_src_243, NTAG(TAG_Nil)});
        V v_c_24108 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1545515160x1777955235(heff_dup(v_e_240), v_t_24107, NTAG(TAG_Nil)));
        V f_ = v_c_24108;
        heff_room[0] = heff_dup(v_hd_244);
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam6, 1, 5, (V[]){v_e_240, v_hd_244, v_v_241, v_pk_242, v_k_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_v_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_src_243 = heff_env(self)[4];
  V v_pk_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_ended_2414 = heff_take_field(v_x_2413, 0);
  V v_err_2415 = heff_take_field(v_x_2413, 2);
  V v_out_2416 = heff_get_n(v_x_2413, 1, 3);
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str3), heff_dup(v_v_241)), NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str5), v_t_2417})});
  V v_t_2419 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str7), v_t_2418}), ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_str8), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2419, ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam1_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2427, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam2, 1, 9, (V[]){v_ended_2414, v_err_2415, v_e_240, v_hd_244, v_k_245, v_out_2416, v_v_241, v_src_243, v_pk_242})));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139_lam8(V self, V *args) {
  V v_r_24115 = args[0];
  return v_r_24115;
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_str1, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_str3, 3, "src");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_str4, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_str6, 3, "src");
V g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_lam0(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_entry, 6, 0};

V g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563(V v_e_240, V v_v_241, V v_l_242, V v_pk_243, V v_z_244, V v_z_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(heff_rfield(v_pk_243, 0)), heff_dup(v_v_241)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_v_241);
      heff_drop_rec(v_l_242, 5);
      V v_why_249 = v_field_248;
      V v_t_2410 = heff_strAppend(heff_get_n(v_pk_243, 0, 4), ((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_str0));
      V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_str1), heff_strAppend(v_t_2410, v_why_249));
      V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_str2)), NTAG(TAG_MkUnit)});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_lam0, 1, 3, (V[]){v_e_240, v_z_244, v_z_245})));
    } else {
      heff_drop(v_field_248);
      V v_st_2427 = heff_get_n(heff_dup(heff_rfield(v_l_242, 2)), 5, 6);
      V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_l_242, 2)), 0, 6);
      V v_t_2429 = (g_std_2epath_2eparse(heff_dup(v_st_2427), v_t_2428));
      V v_t_2430 = (g_std_2epath_2eparse(heff_dup(v_st_2427), ((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_str3)));
      V v_t_2431 = (g_std_2epath_2ejoin(v_t_2429, v_t_2430));
      V v_t_2432 = ({ V a_0 = v_st_2427; V a_1 = v_t_2431; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2427); heff_drop(v_t_2431); r_; });
      V v_c_2433 = (g_heff_2ebuild_2eload_2eownDir_24s156033820x515369250(heff_dup(v_e_240), heff_dup(heff_rfield(v_l_242, 2)), v_t_2432));
      return heff_tail(v_c_2433, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_lam1, 1, 6, (V[]){v_e_240, v_z_244, v_z_245, v_l_242, v_v_241, v_pk_243})});
    }
  }
}
V g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_lam0(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2419);
  V v_t_2420 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_lam2(V self, V *args) {
  V v_x_2444 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2444);
  V v_t_2445 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2451}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_lam1(V self, V *args) {
  V v_x_2434 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_l_242 = heff_env(self)[3];
  V v_v_241 = heff_env(self)[4];
  V v_pk_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Left: {
    V v_why_2435 = heff_field(v_x_2434, 0);
    V v_ru_24x_2434_24Left = heff_take_reuse_n(v_x_2434, 1ULL, 1);
    heff_drop_rec(v_l_242, 5);
    heff_drop(v_v_241);
    heff_drop_rec(v_pk_243, 4);
    V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_str4), v_why_2435), ((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_str5));
    V v_t_2437 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2436, NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tag_at_n(v_ru_24x_2434_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_lam2, 1, 3, (V[]){v_e_240, v_z_244, v_z_245})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2434, 0ULL, 1);
    V v_st_2453 = heff_get_n(heff_dup(heff_rfield(v_l_242, 2)), 5, 6);
    V v_t_2454 = heff_get_n(heff_get_n(v_l_242, 2, 5), 0, 6);
    V v_t_2455 = (g_std_2epath_2eparse(heff_dup(v_st_2453), v_t_2454));
    V v_t_2456 = (g_std_2epath_2eparse(heff_dup(v_st_2453), ((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563_str6)));
    V v_t_2457 = (g_std_2epath_2ejoin(v_t_2455, v_t_2456));
    V v_t_2458 = ({ V a_0 = v_st_2453; V a_1 = v_t_2457; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2453); heff_drop(v_t_2457); r_; });
    return (g_heff_2ebuild_2epackaging_2epublishGit_24s2047385785x559373139(v_e_240, v_v_241, v_pk_243, v_t_2458, v_z_244, v_z_245));
  }
  default: return heff_nomatch(v_x_2434);
  }
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str1, 64, "heff publish: no package.hf here: publish at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str2, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str3, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str4, 39, "heff publish: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str5, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str6, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str7, 1, "`");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str8, 22, "` is no version: a.b.c");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str9, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str10, 1, "\012");
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam0(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam0, 3, 0};
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam8(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam9(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam10(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam7(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam6(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam5(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam1(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam12(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam11(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_entry, 2, 0};

V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738(V v_e_240, V v_v_241) {
top: ;
  HeffT5 v_t_242 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    V v_field_246 = v_t_242.f[3];
    V v_field_247 = v_t_242.f[4];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_245, heff_tag_n(TAG_Cons, 2, (V[]){v_field_246, v_field_247})});
      V v_x_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_field_244, v_t_248});
      heff_drop_tag(v_x_249, 2);
      V v_path_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str0)));
      V v_c_2411 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2410; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2410); r_; });
      V v_t_2412 = (g_exception_2eattempted(heff_dup(v_e_240)));
      V v_c_2416 = heff_tr(heff_call(v_c_2411, 2, (V[]){v_t_2412, ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam0_clo)}));
      return heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam1, 2, 3, (V[]){v_c_2416, v_e_240, v_v_241});
    } else {
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      heff_drop(v_field_246);
      heff_drop(v_field_247);
      return heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam11, 2, 2, (V[]){v_v_241, v_e_240});
    }
  }
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738(a[0], a[1]);
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_2414 = args[1];
  V v_k_2415 = args[2];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2428);
  V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_hd_2417, v_k_2418));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam8(V self, V *args) {
  V v_x_2451 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2451);
  V v_t_2452 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2458}), v_hd_2417, v_k_2418));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam9(V self, V *args) {
  V v_x_2467 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2467);
  V v_t_2468 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2474}), v_hd_2417, v_k_2418));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam10(V self, V *args) {
  V v_x_2483 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2483);
  V v_t_2484 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2489})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2490}), v_hd_2417, v_k_2418));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam7(V self, V *args) {
  V v_x_2442 = args[0];
  V v_x_2437 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2417 = heff_env(self)[2];
  V v_k_2418 = heff_env(self)[3];
  V v_x_2438 = heff_env(self)[4];
  V v_cs_2441 = heff_env(self)[5];
  V v_v_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2442);
  V v_t_2443 = heff_dup(heff_rfield(v_x_2437, 3));
  switch (heff_tag_of(v_t_2443)) {
  case TAG_Nothing: {
    heff_drop_rec(v_x_2437, 5);
    heff_drop(v_x_2438);
    heff_drop(v_cs_2441);
    heff_drop(v_v_241);
    V v_t_2444 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str4), NTAG(TAG_MkUnit)});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2450}), heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam8, 1, 3, (V[]){v_e_240, v_hd_2417, v_k_2418})));
  }
  case TAG_Just: {
    V v_pk_2459 = heff_field(v_t_2443, 0);
    V v_ru_24t_2443_24Just = heff_take_reuse_n(v_t_2443, 1ULL, 1);
    if (heff_intLt_c(MK_INT(0LL), v_x_2438)) {
      heff_drop_rec(v_x_2437, 5);
      heff_drop(v_cs_2441);
      heff_drop(v_v_241);
      heff_drop(v_pk_2459);
      V v_t_2460 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str5), NTAG(TAG_MkUnit)});
      V v_t_2461 = heff_tag_at_n(v_ru_24t_2443_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
      V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
      V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
      V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
      V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
      V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2466}), heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam9, 1, 3, (V[]){v_e_240, v_hd_2417, v_k_2418})));
    } else {
      V v_t_2475 = ({ V a_0 = v_cs_2441; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_2441); r_; });
      if ((heff_dup(v_t_2475) == NTAG(TAG_True))) {
        heff_drop_rec(v_x_2437, 5);
        heff_drop(v_v_241);
        heff_drop(v_pk_2459);
        heff_drop(v_t_2475);
        V v_t_2476 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str6), NTAG(TAG_MkUnit)});
        V v_t_2477 = heff_tag_at_n(v_ru_24t_2443_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
        V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
        V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
        V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
        V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
        V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
        return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2482}), heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam10, 1, 3, (V[]){v_e_240, v_hd_2417, v_k_2418})));
      } else {
        heff_drop_cell(v_ru_24t_2443_24Just, 1);
        heff_drop(v_t_2475);
        return (g_heff_2ebuild_2epackaging_2epublishChecked_24s2045525341x1450289563(v_e_240, v_v_241, v_x_2437, v_pk_2459, v_hd_2417, v_k_2418));
      }
    }
  }
  default: return heff_nomatch(v_t_2443);
  }
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam6(V self, V *args) {
  V v_x_2440 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_x_2437 = heff_env(self)[2];
  V v_k_2418 = heff_env(self)[3];
  V v_x_2438 = heff_env(self)[4];
  V v_v_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_cs_2441 = heff_get_n(v_x_2440, 0, 2);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(heff_dup(v_e_240), heff_dup(v_cs_2441), heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam7, 1, 7, (V[]){v_x_2437, v_e_240, v_hd_2417, v_k_2418, v_x_2438, v_cs_2441, v_v_241})));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam5(V self, V *args) {
  V v_x_2438 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2437 = heff_env(self)[1];
  V v_hd_2417 = heff_env(self)[2];
  V v_k_2418 = heff_env(self)[3];
  V v_v_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2439 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(heff_dup(v_e_240), heff_dup(v_x_2437)));
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_hd_2417);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam6, 1, 6, (V[]){v_e_240, v_hd_2417, v_x_2437, v_k_2418, v_x_2438, v_v_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam4(V self, V *args) {
  V v_x_2437 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  V v_v_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str3), heff_dup(heff_rfield(v_x_2437, 1)), MK_INT(0LL), heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam5, 1, 5, (V[]){v_e_240, v_x_2437, v_hd_2417, v_k_2418, v_v_241})));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2417 = heff_env(self)[1];
  V v_k_2418 = heff_env(self)[2];
  V v_v_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 0ULL, 1);
    heff_drop(v_v_241);
    V v_t_2421 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str1), NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_at_n(v_ru_24x_2419_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam3, 1, 3, (V[]){v_e_240, v_hd_2417, v_k_2418})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2419, 0ULL, 1);
    return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str2), heff_dup(v_hd_2417), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam4, 1, 4, (V[]){v_e_240, v_hd_2417, v_k_2418, v_v_241})));
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam2, 1, 4, (V[]){v_e_240, v_hd_2417, v_k_2418, v_v_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam12(V self, V *args) {
  V v_x_24102 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2491 = heff_env(self)[1];
  V v_k_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24102);
  V v_t_24103 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24108})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_24109}), v_hd_2491, v_k_2492));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam11(V self, V *args) {
  V v_hd_2491 = args[0];
  V v_k_2492 = args[1];
  V v_v_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2493 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str7), v_v_241), ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str8));
  V v_t_2494 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str9), v_t_2493), ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_str10));
  V v_t_2495 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2494, NTAG(TAG_MkUnit)});
  V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24100})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24101}), heff_dup(v_hd_2491), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s513764101x1939619738_lam12, 1, 3, (V[]){v_e_240, v_hd_2491, v_k_2492})));
}