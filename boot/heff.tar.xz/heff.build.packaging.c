// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_MkPath 49630
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Pend 2230
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Settled 45257
#define TAG_Signalled 34337
#define TAG_Throw 56084
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failed 665164648
#define LBL_file 9638467
#define LBL_group 299987609
#define LBL_heff 9694020
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_out 319944
#define LBL_outcomes 803130769
#define LBL_output 941629484
#define LBL_package 1572278921
#define LBL_paths 307797256
#define LBL_reports 1326460931
#define LBL_root 10001833
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_timeout 1065429926
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_wrong 314763719
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056_clo;
V g_heff_2ebuild_2epackaging_2ebuildText_get(void);
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481(V, V, V, V);
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_clo;
V g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416(V, V, V, V);
V g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_clo;
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296(V, V, V);
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_clo;
V g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970(V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_clo;
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562(V);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_clo;
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513(V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_clo;
V g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279(V, V, V, V);
V g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_clo;
V g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412(V, V, V, V, V);
V g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_clo;
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857(V, V);
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_clo;
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524(V, V, V, V);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_entry(V self, V *a);
extern Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2ebuild_2etesting_2eaddRes(V, V);
V g_heff_2ebuild_2etesting_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eaddRes_clo;
V g_heff_2ebuild_2etesting_2enoRes_get(void);
V g_heff_2ebuild_2etesting_2etestOneF_24s900984027x316192925(V, V, V, V);
V g_heff_2ebuild_2etesting_2etestOneF_24s900984027x316192925_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestOneF_24s900984027x316192925_clo;
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462(V, V, V, V, V, V);
V g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462_clo;
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176(V, V, V);
V g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s1552018029x993523539(V, V);
V g_list_2ekeepIf_24s1552018029x993523539_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1552018029x993523539_clo;
V g_list_2emap_24f1285463828x1893111862(V, V, V);
V g_list_2emap_24f1285463828x1893111862_entry(V self, V *a);
extern Clo g_list_2emap_24f1285463828x1893111862_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str1, 13, "build : Build");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str2, 37, "build = { backend = C, run = \"main\" }");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str3, 15, "import manifest");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str5, 21, "-- heff home with it.");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str7, 69, "-- page's script of it.  A field `ships = [...]` would name files and");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str8, 69, "-- directories of the project's root for `heff install` to put in the");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ebuildText_str10, 69, "-- main.hf's `main`, compiled through C (by `zig cc`); `Page` makes a");

static V g_heff_2ebuild_2epackaging_2ebuildText_val;
static HEFF_ONCE g_heff_2ebuild_2epackaging_2ebuildText_st;
static V g_heff_2ebuild_2epackaging_2ebuildText_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2ebuildText_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2ebuildText_str9); V a_1 = ((V)&g_heff_2ebuild_2epackaging_2ebuildText_str10); V a_2 = v_t_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2ebuild_2epackaging_2ebuildText_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2epackaging_2ebuildText_st)) return g_heff_2ebuild_2epackaging_2ebuildText_val;
  return heff_global(&g_heff_2ebuild_2epackaging_2ebuildText_val, &g_heff_2ebuild_2epackaging_2ebuildText_st, g_heff_2ebuild_2epackaging_2ebuildText_init);
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_str0, 5, "win32");
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam0(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam0, 1, 0};
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam2(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam2, 1, 0};
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam3(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam3, 1, 0};
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam6(V self, V *args);
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam5(V self, V *args);
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_entry, 4, 0};

V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop_rec(v_p_242, 3);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      heff_take_n(v_x21_244, 1ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_242, 2)), 1, (V[]){v_t_2415}));
      return heff_tail(heff_dup(heff_rfield(v_p_242, 1)), 2, (V[]){v_t_2416, heff_clo_n(g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam1, 1, 5, (V[]){v_dir_240, v_f_246, v_p_242, v_rest_245, v_p_243})});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam2(V self, V *args) {
  V v_r_2425 = args[0];
  return v_r_2425;
}
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam4(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_x_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  switch (heff_tag_of(v_x_2433)) {
  case TAG_Left: {
    V v_err_2434 = heff_field(v_x_2433, 0);
    V v_ru_24x_2433_24Left = heff_take_reuse_n(v_x_2433, 1ULL, 1);
    V v_t_2435 = heff_tag_at_n(v_ru_24x_2433_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2434})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2435));
  }
  case TAG_Right: {
    V v_x_2436 = heff_field(v_x_2433, 0);
    heff_take_n(v_x_2433, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam4, 2, 1, (V[]){v_x_2436});
  }
  default: return heff_nomatch(v_x_2433);
  }
}
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam6(V self, V *args) {
  V v_x_2443 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_p_243;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_f_246, v_x_2443});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam5(V self, V *args) {
  V v_x_2440 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_f_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Left: {
    heff_take_n(v_x_2440, 0ULL, 1);
    heff_drop(v_f_246);
    return (g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481(v_dir_240, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_Right: {
    heff_take_n(v_x_2440, 0ULL, 1);
    return (g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481(v_dir_240, v_rest_245, v_p_242, heff_clo_n(g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam6, 1, 2, (V[]){v_p_243, v_f_246})));
  }
  default: return heff_nomatch(v_x_2440);
  }
}
V g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2418;
  if (heff_strEq_c(v_x_2417, ((V)&g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_dir_240)));
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_f_246)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2421); r_; });
  V v_path_2423 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2422));
  V v_t_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2423; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2423); r_; });
  V v_a_2426 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2424, ((V)&g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam2_clo)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  V v_c_2439 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam3_clo)));
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481_lam5, 1, 5, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243, v_f_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_str2, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_str4, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_str5, 1, "\012");
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam0(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam0, 1, 0};
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam2(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam2, 1, 0};
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam3(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam3, 1, 0};
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam6(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam6, 1, 0};
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam8(V self, V *args);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam7(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam7, 1, 0};
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam10(V self, V *args);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam11(V self, V *args);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam9(V self, V *args);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam5(V self, V *args);
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_entry, 4, 0};

V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop_rec(v_p_242, 3);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_242, 2)), 1, (V[]){v_t_2415}));
      return heff_tail(heff_dup(heff_rfield(v_p_242, 1)), 2, (V[]){v_t_2416, heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam1, 1, 6, (V[]){v_dir_240, v_f_246, v_p_242, v_text_247, v_rest_245, v_p_243})});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam2(V self, V *args) {
  V v_r_2437 = args[0];
  return v_r_2437;
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam4(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  V v_x_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2449);
  V f_ = v_k_2450;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2448});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam3(V self, V *args) {
  V v_x_2445 = args[0];
  switch (heff_tag_of(v_x_2445)) {
  case TAG_Left: {
    V v_err_2446 = heff_field(v_x_2445, 0);
    V v_ru_24x_2445_24Left = heff_take_reuse_n(v_x_2445, 1ULL, 1);
    V v_t_2447 = heff_tag_at_n(v_ru_24x_2445_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2446})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2447));
  }
  case TAG_Right: {
    V v_x_2448 = heff_field(v_x_2445, 0);
    heff_take_n(v_x_2445, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam4, 2, 1, (V[]){v_x_2448});
  }
  default: return heff_nomatch(v_x_2445);
  }
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam6(V self, V *args) {
  V v_r_2470 = args[0];
  return v_r_2470;
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam8(V self, V *args) {
  V v_hd_2482 = args[0];
  V v_k_2483 = args[1];
  V v_x_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2482);
  V f_ = v_k_2483;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2481});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam7(V self, V *args) {
  V v_x_2478 = args[0];
  switch (heff_tag_of(v_x_2478)) {
  case TAG_Left: {
    V v_err_2479 = heff_field(v_x_2478, 0);
    V v_ru_24x_2478_24Left = heff_take_reuse_n(v_x_2478, 1ULL, 1);
    V v_t_2480 = heff_tag_at_n(v_ru_24x_2478_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2479})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2480));
  }
  case TAG_Right: {
    V v_x_2481 = heff_field(v_x_2478, 0);
    heff_take_n(v_x_2478, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam8, 2, 1, (V[]){v_x_2481});
  }
  default: return heff_nomatch(v_x_2478);
  }
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam10(V self, V *args) {
  V v_x_24100 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24100);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam11(V self, V *args) {
  V v_x_24115 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24115);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam9(V self, V *args) {
  V v_x_2485 = args[0];
  V v_x_2455 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_st_2418 = heff_env(self)[5];
  V v_f_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2485)) {
  case TAG_Left: {
    V v_ru_24x_2485_24Left = heff_take_reuse_n(v_x_2485, 0ULL, 1);
    if (((heff_dup(v_x_2455) == NTAG(TAG_True)) && 0)) {
      heff_drop(v_x_2455);
      heff_drop(v_st_2418);
      heff_drop(v_f_246);
      heff_drop_cell(v_ru_24x_2485_24Left, 1);
      return (g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524(v_dir_240, v_rest_245, v_p_242, v_p_243));
    } else {
      heff_drop(v_x_2455);
      heff_drop(v_rest_245);
      V v_t_2487 = (g_std_2epath_2eparse(heff_dup(v_st_2418), v_dir_240));
      V v_t_2488 = (g_std_2epath_2eparse(heff_dup(v_st_2418), v_f_246));
      V v_t_2489 = (g_std_2epath_2ejoin(v_t_2487, v_t_2488));
      V v_t_2490 = ({ V a_0 = v_st_2418; V a_1 = v_t_2489; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2489); r_; });
      V v_str_2491 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_str2), v_t_2490);
      V v_t_2492 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2491, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_str3)), NTAG(TAG_MkUnit)});
      V v_t_2493 = heff_tag_at_n(v_ru_24x_2485_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
      V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
      V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
      V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
      V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
      V v_t_2498 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2497})});
      V v_t_2499 = heff_tr(heff_call(heff_take_field(v_p_242, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2498})}));
      V f_ = heff_get_n(v_p_242, 1, 3);
      heff_room[0] = v_t_2499;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam10, 1, 1, (V[]){v_p_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Right: {
    V v_ru_24x_2485_24Right = heff_take_reuse_n(v_x_2485, 0ULL, 1);
    if ((heff_dup(v_x_2455) == NTAG(TAG_True))) {
      heff_drop(v_x_2455);
      heff_drop(v_st_2418);
      heff_drop(v_f_246);
      heff_drop_cell(v_ru_24x_2485_24Right, 1);
      return (g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524(v_dir_240, v_rest_245, v_p_242, v_p_243));
    } else {
      heff_drop(v_x_2455);
      heff_drop(v_rest_245);
      V v_t_24102 = (g_std_2epath_2eparse(heff_dup(v_st_2418), v_dir_240));
      V v_t_24103 = (g_std_2epath_2eparse(heff_dup(v_st_2418), v_f_246));
      V v_t_24104 = (g_std_2epath_2ejoin(v_t_24102, v_t_24103));
      V v_t_24105 = ({ V a_0 = v_st_2418; V a_1 = v_t_24104; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_24104); r_; });
      V v_str_24106 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_str4), v_t_24105);
      V v_t_24107 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_24106, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_str5)), NTAG(TAG_MkUnit)});
      V v_t_24108 = heff_tag_at_n(v_ru_24x_2485_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
      V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
      V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
      V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
      V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
      V v_t_24113 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24112})});
      V v_t_24114 = heff_tr(heff_call(heff_take_field(v_p_242, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24113})}));
      V f_ = heff_get_n(v_p_242, 1, 3);
      heff_room[0] = v_t_24114;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam11, 1, 1, (V[]){v_p_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_x_2485);
  }
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam5(V self, V *args) {
  V v_x_2452 = args[0];
  V v_st_2418 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x_2455;
  switch (heff_tag_of(v_x_2452)) {
  case TAG_Left: {
    heff_take_n(v_x_2452, 0ULL, 1);
    v_x_2455 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2452, 0ULL, 1);
    v_x_2455 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2452);
  }
  V v_t_2456 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_dir_240)));
  V v_t_2457 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_f_246)));
  V v_t_2458 = (g_std_2epath_2ejoin(v_t_2456, v_t_2457));
  V v_s_2459 = ({ V a_0 = v_st_2418; V a_1 = v_t_2458; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2458); r_; });
  V v_path_2460 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2459));
  int64_t v_t_2461 = (heff_unbox_word(heff_strLength_lent(v_f_246, 0)) - ((int64_t)3ULL));
  V v_t_2462 = heff_strSlice(heff_dup(v_f_246), heff_box_word(v_t_2461), heff_strLength_lent(v_f_246, 0));
  V v_text_2468;
  if (heff_strEq_c(v_t_2462, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_str1))) {
    HeffT2 v_t_2463 = (g_heff_2esyntax_2eformat_2eformat_24cpr(heff_dup(v_text_247)));
    {
      V v_field_2465 = v_t_2463.f[1];
      int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
      if ((v_tag_2464 == ((int64_t)0ULL))) {
        V v_x_2466 = v_field_2465;
        heff_drop(v_x_2466);
        v_text_2468 = v_text_247;
      } else {
        heff_drop(v_text_247);
        V v_out_2467 = v_field_2465;
        v_text_2468 = v_out_2467;
      }
    }
  } else {
    v_text_2468 = v_text_247;
  }
  V v_t_2469 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2460; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2460); r_; });
  V v_a_2471 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2469, v_text_2468, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam6_clo)});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
  V v_c_2484 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2477}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam7_clo)));
  V f_ = v_c_2484;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam9, 1, 7, (V[]){v_x_2455, v_dir_240, v_rest_245, v_p_242, v_p_243, v_st_2418, v_f_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2418;
  if (heff_strEq_c(v_x_2417, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_dir_240)));
  V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2418), heff_dup(v_f_246)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  HeffT3 v_t_2423 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2418), v_s_2422));
  V v_t_2433;
  {
    V v_field_2424 = v_t_2423.f[0];
    V v_field_2425 = v_t_2423.f[1];
    V v_field_2426 = v_t_2423.f[2];
    V v_d_2427 = v_field_2424;
    V v_a_2428 = v_field_2425;
    V v_xs_2429 = v_field_2426;
    V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2429));
    V v_xs_2431 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2430; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2430); r_; });
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
    v_t_2433 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2427, v_a_2428, v_t_2432});
  }
  V v_s_2434 = ({ V a_0 = v_st_2418; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2433); r_; });
  V v_path_2435 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2434));
  V v_t_2436 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2435; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2435); r_; });
  V v_a_2438 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2436, ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam2_clo)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  V v_c_2451 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam3_clo)));
  V f_ = v_c_2451;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524_lam5, 1, 7, (V[]){v_st_2418, v_dir_240, v_f_246, v_text_247, v_p_242, v_rest_245, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str4, 5, "0.1.0");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str5, 22, "package = { module = \"");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str6, 11, "\", heff = \"");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str7, 3, "\" }");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str8, 35, "import manifest\012\012package : Package\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str10, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str12, 4, "src/");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str13, 12, "/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str14, 7, "module ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str15, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str17, 27, "greeting : String -> String");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str18, 38, "greeting name = \"Hello, \" ^ name ^ \"!\"");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str19, 24, "-- | >>> greeting \"heff\"");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str20, 19, "-- | \"Hello, heff!\"");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str22, 26, "-- | a greeting, of `name`");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str24, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str25, 66, "-- A module of the package, as every file of src/ is: `heff build`");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str26, 52, "-- checks them all, and `heff test` their doc tests.");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str27, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str28, 8, "/main.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str29, 15, "-- The program ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str30, 42, ": `heff build` builds it to .heff/bin/, as");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str31, 29, "-- a build, by `heff run app/");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str32, 10, "/main.hf`.");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str33, 11, "module app.");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str34, 5, ".main");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str35, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str36, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str37, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str38, 20, "main : Co stdio Unit");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str39, 24, "main = program (io := _)");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str40, 34, "program = print (greeting \"world\")");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str41, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str42, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str43, 60, "program : {e : HFunctor} -> {{io : stdio <: e}} -> Co e Unit");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str44, 13, "import std.io");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str45, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str46, 9, "import co");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str47, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str48, 68, "-- build.hf says, and `heff install` into ~/.heff/bin/; run, without");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str49, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str50, 4, "app/");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str51, 9, "/build.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str52, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str53, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str54, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str55, 8, "greets =");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str56, 64, "  unit \"greeting\" (assertEqual (greeting \"test\") \"Hello, test!\")");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str57, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str58, 13, "greets : Test");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str59, 12, "import check");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str60, 20, "module test.greeting");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str61, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str62, 9, "-- tests.");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str63, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str64, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str65, 68, "-- `heff test` runs the tests of every file of test/ (and src/): the");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str66, 71, "-- definitions of type `Test` (lib/check.hf), after the watches and doc");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str67, 16, "test/greeting.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str68, 10, ".gitignore");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str69, 7, ".heff/\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str70, 1, ".");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str71, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str72, 20, "heff: the directory ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str73, 82, " has no name to name a package by: say the project's directory, as `heff init DIR`");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str74, 21, "heff: the directory `");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str75, 25, "` cannot name a package (");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str76, 36, "): name it otherwise, as `heff init ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str77, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str78, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str79, 1, "_");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str80, 1, "_");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str81, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str82, 1, "_");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str83, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str84, 3, "app");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str85, 4, "pkg_");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str86, 4, "_app");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str87, 1, "`");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str88, 62, "heff: `heff` is heff's own package: name the project otherwise");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str89, 23, "heff: a new project in ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str90, 56, "; there, `heff build` builds it and `heff test` tests it");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str91, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str92, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str93, 5, " has ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str94, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str95, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str96, 25, " already; nothing written");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str97, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str98, 1, "\012");
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam2(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam2, 1, 0};
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam5(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam6(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam7(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam1(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam9(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam9, 1, 0};
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam11(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam10(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam10, 1, 0};
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam12(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam8(V self, V *args);
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam0(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_entry, 3, 0};

V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam0, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242})));
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam2(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam5(V self, V *args) {
  V v_x_24115 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_24115) == NTAG(TAG_True))) {
    heff_drop(v_x_24115);
    V v_t_24116 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str89), v_dir_240), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str90));
    V v_t_24117 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_24116, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str91)), NTAG(TAG_MkUnit)});
    V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24117})});
    V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
    V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
    V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
    V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24122})});
    V v_t_24124 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24123})}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_24124;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_24115);
    heff_drop(v_dir_240);
    return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_241, v_k_242));
  }
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam6(V self, V *args) {
  V v_x_24140 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24140);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam7(V self, V *args) {
  V v_x_24150 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24150);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam4(V self, V *args) {
  V v_x_2486 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2438 = heff_env(self)[2];
  V v_x_2485 = heff_env(self)[3];
  V v_hd_241 = heff_env(self)[4];
  V v_k_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_shown_2487;
  if (heff_strEq_c_lent(v_dir_240, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str70), 2)) {
    v_shown_2487 = v_x_243;
  } else {
    heff_drop(v_x_243);
    v_shown_2487 = heff_dup(v_dir_240);
  }
  V v_name_2488 = v_x_2438;
  V v_t_24114;
  if (heff_strEq_c_lent(v_name_2488, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str71), 2)) {
    heff_drop(v_name_2488);
    V v_t_2489 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str72), v_shown_2487), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str73));
    v_t_24114 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2489});
  } else {
    heff_drop(v_shown_2487);
    HeffT2 v_t_2490 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_name_2488));
    {
      V v_field_2492 = v_t_2490.f[1];
      int64_t v_tag_2491 = ((int64_t)v_t_2490.f[0]);
      if ((v_tag_2491 == ((int64_t)0ULL))) {
        V v_why_2493 = v_field_2492;
        V v_t_2494 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str74), heff_dup(v_name_2488)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str75));
        V v_t_2495 = heff_strAppend(heff_strAppend(v_t_2494, v_why_2493), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str76));
        V v_x_2496 = v_name_2488;
        V v_x2_2497 = (g_list_2emap_24f1285463828x1893111862(heff_dup(v_x_2496), MK_INT(0LL), heff_strLength(v_x_2496)));
        V v_s_24100;
        switch (heff_tag_of(v_x2_2497)) {
        case TAG_Nil: {
          v_s_24100 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str77);
          break;
        }
        case TAG_Cons: {
          V v_x_2498 = heff_field(v_x2_2497, 0);
          V v_xs_2499 = heff_field(v_x2_2497, 1);
          heff_take_n(v_x2_2497, 3ULL, 2);
          v_s_24100 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str78); V a_1 = v_x_2498; V a_2 = v_xs_2499; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2499); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2497);
        }
        V v_t_24101 = ({ V b_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str79); V a_1 = v_s_24100; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str80), v_s_24100, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_24100); r_; });
        V v_x2_24102 = (g_list_2ekeepIf_24s1552018029x993523539(MK_INT(0LL), v_t_24101));
        V v_x_24105;
        switch (heff_tag_of(v_x2_24102)) {
        case TAG_Nil: {
          v_x_24105 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str81);
          break;
        }
        case TAG_Cons: {
          V v_x_24103 = heff_field(v_x2_24102, 0);
          V v_xs_24104 = heff_field(v_x2_24102, 1);
          heff_take_n(v_x2_24102, 3ULL, 2);
          v_x_24105 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str82); V a_1 = v_x_24103; V a_2 = v_xs_24104; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24104); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24102);
        }
        V v_x_24106;
        if (heff_strEq_c_lent(v_x_24105, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str83), 2)) {
          heff_drop(v_x_24105);
          v_x_24106 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str84);
        } else {
          if (((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_24105, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_x_24105, MK_INT(0LL), 2)) <= ((int64_t)57ULL)))) {
            v_x_24106 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str85), v_x_24105);
          } else {
            v_x_24106 = v_x_24105;
          }
        }
        HeffT2 v_t_24107 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_x_24106));
        V v_t_24111;
        {
          V v_field_24109 = v_t_24107.f[1];
          int64_t v_tag_24108 = ((int64_t)v_t_24107.f[0]);
          v_t_24111 = heff_bool(((v_tag_24108 == ((int64_t)0ULL)) ? ({ V v_x_24110 = heff_dup(v_field_24109); int c_ = 0; heff_drop(v_x_24110); c_; }) : 1));
          heff_drop(v_field_24109);
        }
        V v_t_24112;
        if (((heff_dup(v_t_24111) == NTAG(TAG_True)) && !heff_strEq_c(heff_dup(v_x_24106), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get())))) {
          heff_drop(v_t_24111);
          v_t_24112 = v_x_24106;
        } else {
          heff_drop(v_t_24111);
          v_t_24112 = heff_strAppend(v_x_24106, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str86));
        }
        V v_t_24113 = heff_strAppend(heff_strAppend(v_t_2495, v_t_24112), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str87));
        v_t_24114 = heff_tag_n(TAG_Just, 1, (V[]){v_t_24113});
      } else {
        heff_drop(v_field_2492);
        if (heff_strEq_c(v_name_2488, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
          v_t_24114 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str88)});
        } else {
          v_t_24114 = NTAG(TAG_Nothing);
        }
      }
    }
  }
  switch (heff_tag_of(v_t_24114)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_x_2486)) {
    case TAG_Nil: {
      return (g_heff_2ebuild_2epackaging_2ewriteAll_24s1304404963x1954388524(heff_dup(v_dir_240), v_x_2485, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam5, 1, 3, (V[]){v_dir_240, v_hd_241, v_k_242})));
    }
    case TAG_Cons: {
      heff_drop_tag(v_x_2485, 2);
      V v_t_24127 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str92), v_dir_240), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str93));
      V v_t_24130;
      switch (heff_tag_of(v_x_2486)) {
      case TAG_Nil: {
        v_t_24130 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str94);
        break;
      }
      case TAG_Cons: {
        V v_x_24128 = heff_field(v_x_2486, 0);
        V v_xs_24129 = heff_field(v_x_2486, 1);
        heff_take_n(v_x_2486, 3ULL, 2);
        v_t_24130 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str95); V a_1 = v_x_24128; V a_2 = v_xs_24129; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24129); r_; });
        break;
      }
      default: heff_nomatch(v_x_2486);
      }
      V v_str_24131 = heff_strAppend(heff_strAppend(v_t_24127, v_t_24130), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str96));
      V v_t_24132 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_24131, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str97)), NTAG(TAG_MkUnit)});
      V v_t_24133 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24132})});
      V v_t_24134 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24133})});
      V v_t_24135 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24134})});
      V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
      V v_t_24137 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24136})});
      V v_t_24138 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24137})});
      V v_t_24139 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24138})}));
      V f_ = heff_dup(heff_rfield(v_hd_241, 1));
      heff_room[0] = v_t_24139;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam6, 1, 2, (V[]){v_hd_241, v_k_242});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_x_2486);
    }
  }
  case TAG_Just: {
    V v_why_24141 = heff_field(v_t_24114, 0);
    V v_ru_24t_24114_24Just = heff_take_reuse_n(v_t_24114, 1ULL, 1);
    heff_drop(v_x_2486);
    heff_drop(v_dir_240);
    heff_drop_tag(v_x_2485, 2);
    V v_t_24142 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_why_24141, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str98)), NTAG(TAG_MkUnit)});
    V v_t_24143 = heff_tag_at_n(v_ru_24t_24114_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
    V v_t_24144 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24143})});
    V v_t_24145 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24144})});
    V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
    V v_t_24147 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24146})});
    V v_t_24148 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24147})});
    V v_t_24149 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24148})}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_24149;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam7, 1, 2, (V[]){v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_24114);
  }
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2415;
  if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str0))) {
    v_st_2415 = NTAG(TAG_Windows);
  } else {
    v_st_2415 = NTAG(TAG_Posix);
  }
  V v_dir_2416 = heff_dup(v_dir_240);
  V v_x3_2417 = heff_dup(v_x_243);
  V v_x_2438;
  if (heff_strEq_c_lent(v_dir_2416, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str1), 2)) {
    heff_drop(v_dir_2416);
    HeffT3 v_t_2418 = (g_std_2epath_2eparse_24cpr(v_st_2415, v_x3_2417));
    {
      V v_field_2419 = v_t_2418.f[0];
      V v_field_2420 = v_t_2418.f[1];
      V v_field_2421 = v_t_2418.f[2];
      V v_x11_2422 = v_field_2419;
      heff_drop(v_x11_2422);
      V v_x12_2423 = v_field_2420;
      heff_drop(v_x12_2423);
      V v_xs_2424 = v_field_2421;
      V v_x1_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
      switch (heff_tag_of(v_x1_2425)) {
      case TAG_Nil: {
        v_x_2438 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2426 = heff_field(v_x1_2425, 0);
        heff_take_n(v_x1_2425, 1ULL, 2);
        v_x_2438 = v_x_2426;
        break;
      }
      default: heff_nomatch(v_x1_2425);
      }
    }
  } else {
    heff_drop(v_x3_2417);
    HeffT3 v_t_2428 = (g_std_2epath_2eparse_24cpr(v_st_2415, v_dir_2416));
    {
      V v_field_2429 = v_t_2428.f[0];
      V v_field_2430 = v_t_2428.f[1];
      V v_field_2431 = v_t_2428.f[2];
      V v_x11_2432 = v_field_2429;
      heff_drop(v_x11_2432);
      V v_x12_2433 = v_field_2430;
      heff_drop(v_x12_2433);
      V v_xs_2434 = v_field_2431;
      V v_x1_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2434));
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_Nil: {
        v_x_2438 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_2436 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 2);
        v_x_2438 = v_x_2436;
        break;
      }
      default: heff_nomatch(v_x1_2435);
      }
    }
  }
  V v_name_2439 = heff_dup(v_x_2438);
  V v_v_2441;
  switch (heff_tag_of(v_x_244)) {
  case TAG_Nothing: {
    v_v_2441 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str4);
    break;
  }
  case TAG_Just: {
    V v_x_2440 = heff_field(v_x_244, 0);
    heff_take_n(v_x_244, 1ULL, 1);
    v_v_2441 = v_x_2440;
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V v_t_2442 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str5), heff_dup(v_name_2439)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str6));
  V v_t_2443 = heff_strAppend(heff_strAppend(v_t_2442, v_v_2441), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str7));
  V v_t_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str8), v_t_2443), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str9));
  V v_t_2445 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str10), heff_strAppend(v_t_2444, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str11))});
  V v_t_2446 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str12), heff_dup(v_name_2439)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str13));
  V v_name_2447 = heff_dup(v_name_2439);
  V v_t_2448 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str14), v_name_2447), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str15));
  V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str16), NTAG(TAG_Nil)});
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str17), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str18), v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str19), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str20), v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str22), v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str23), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, v_t_2452})});
  V v_t_2454 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str24); V a_1 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str25); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str26), v_t_2453}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2455 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str27), heff_dup(v_name_2439)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str28));
  V v_name_2456 = heff_dup(v_name_2439);
  V v_t_2457 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str29), heff_dup(v_name_2456)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str30));
  V v_t_2458 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str31), heff_dup(v_name_2456)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str32));
  V v_t_2459 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str33), heff_dup(v_name_2456)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str34));
  V v_t_2460 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str35), v_name_2456), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str36));
  V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str37), NTAG(TAG_Nil)});
  V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str38), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str39), v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str40), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str41), v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str42), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str43), v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str44), v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str45), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str46), v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str47), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str48), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, v_t_2467})});
  V v_t_2469 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str49); V a_1 = v_t_2457; V a_2 = v_t_2468; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2468, 2); r_; });
  V v_t_2470 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str50), heff_dup(v_name_2439)), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str51));
  V v_name_2471 = v_name_2439;
  V v_t_2472 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str52), v_name_2471), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str53));
  V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str54), NTAG(TAG_Nil)});
  V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str55), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str56), v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str57), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str58), v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str59), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2472, v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str60), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str61), v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str62), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str63), v_t_2477})});
  V v_t_2479 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str64); V a_1 = ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str65); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str66), v_t_2478}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str67), v_t_2479}), NTAG(TAG_Nil)});
  V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2470, heff_dup(g_heff_2ebuild_2epackaging_2ebuildText_get())}), v_t_2480});
  V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2455, v_t_2469}), v_t_2481});
  V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2446, v_t_2454}), v_t_2482});
  V v_t_2484 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str68), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_str69)}), v_t_2483});
  V v_x_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_t_2484});
  return (g_heff_2ebuild_2epackaging_2eexisting_24s1153296299x636699481(heff_dup(v_dir_240), heff_dup(v_x_2485), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam4, 1, 6, (V[]){v_dir_240, v_x_243, v_x_2438, v_x_2485, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam2_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam3, 1, 5, (V[]){v_dir_240, v_x_243, v_x_244, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam9(V self, V *args) {
  V v_r_24155 = args[0];
  return v_r_24155;
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam11(V self, V *args) {
  V v_hd_24167 = args[0];
  V v_k_24168 = args[1];
  V v_x_24166 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24167);
  V f_ = v_k_24168;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24166});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam10(V self, V *args) {
  V v_x_24163 = args[0];
  switch (heff_tag_of(v_x_24163)) {
  case TAG_Left: {
    V v_err_24164 = heff_field(v_x_24163, 0);
    V v_ru_24x_24163_24Left = heff_take_reuse_n(v_x_24163, 1ULL, 1);
    V v_t_24165 = heff_tag_at_n(v_ru_24x_24163_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_24164})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_24165));
  }
  case TAG_Right: {
    V v_x_24166 = heff_field(v_x_24163, 0);
    heff_take_n(v_x_24163, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam11, 2, 1, (V[]){v_x_24166});
  }
  default: return heff_nomatch(v_x_24163);
  }
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam12(V self, V *args) {
  V v_x_24170 = args[0];
  V v_k_24151 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_24170)) {
  case TAG_Left: {
    heff_take_n(v_x_24170, 0ULL, 1);
    V f_ = v_k_24151;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_24172 = heff_field(v_x_24170, 0);
    V v_ru_24x_24170_24Right = heff_take_reuse_n(v_x_24170, 1ULL, 1);
    HeffT2 v_t_24173 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_y_24172));
    {
      V v_field_24175 = v_t_24173.f[1];
      int64_t v_tag_24174 = ((int64_t)v_t_24173.f[0]);
      V v_x_24183;
      if ((v_tag_24174 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_24170_24Right, 1);
        V v_p_24176 = v_field_24175;
        heff_drop(v_p_24176);
        v_x_24183 = NTAG(TAG_Nothing);
      } else {
        V v_x_24177 = v_field_24175;
        HeffT2 v_t_24178 = ({ V a_0 = v_x_24177; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(a_0)); heff_drop(v_x_24177); r_; });
        {
          V v_field_24180 = v_t_24178.f[1];
          int64_t v_tag_24179 = ((int64_t)v_t_24178.f[0]);
          if ((v_tag_24179 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x_24170_24Right, 1);
            V v_x_24181 = v_field_24180;
            heff_drop(v_x_24181);
            v_x_24183 = NTAG(TAG_Nothing);
          } else {
            V v_p_24182 = v_field_24180;
            v_x_24183 = heff_tag_at_n(v_ru_24x_24170_24Right, TAG_Just, 1, (V[]){heff_get_n(v_p_24182, 1, 4)});
          }
        }
      }
      V f_ = v_k_24151;
      args[0] = v_x_24183;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  default: return heff_nomatch(v_x_24170);
  }
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam8(V self, V *args) {
  V v_x_24152 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_24151 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_path_24153 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_24152));
  V v_t_24154 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24153; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24153); r_; });
  V v_a_24156 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_24154, ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam9_clo)});
  V v_t_24157 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24156})});
  V v_t_24158 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24157})});
  V v_t_24159 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24158})});
  V v_t_24160 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24159})});
  V v_t_24161 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24160})});
  V v_t_24162 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24161})});
  V v_c_24169 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_24162}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam10_clo)));
  V f_ = v_c_24169;
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam12, 1, 1, (V[]){v_k_24151});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_k_24151 = heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam1, 1, 4, (V[]){heff_dup(v_hd_241), v_dir_240, v_x_243, v_k_242});
  return (g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2epackaging_2einitCmd_24s933941641x658452296_lam8, 1, 2, (V[]){v_hd_241, v_k_24151})));
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_str0, 0, "");
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam0(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam5(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam6(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_entry, 2, 0};

V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam0, 2, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_c_246 = (g_heff_2ebuild_2etesting_2etestOneF_24s900984027x316192925(MK_INT(2026LL), ((V)&g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_str0), MK_INT(1LL), heff_dup(v_f_244)));
    return heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam1, 2, 3, (V[]){v_c_246, v_acc_241, heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_acc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_acc_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam3(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_r_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = v_r_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_file_2414 = heff_env(self)[0];
  V v_wrong_2416 = heff_env(self)[1];
  V v_reports_2417 = heff_env(self)[2];
  V v_hd_2419 = heff_env(self)[3];
  V v_k_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2etesting_2etestReport_24s625756074x2006207462(v_file_2414, v_wrong_2416, v_reports_2417, v_x_2421, v_hd_2419, v_k_2420));
}
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam4(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_file_2414 = heff_env(self)[1];
  V v_wrong_2416 = heff_env(self)[2];
  V v_reports_2417 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam5, 1, 5, (V[]){v_file_2414, v_wrong_2416, v_reports_2417, v_hd_2419, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2424 = (g_heff_2ebuild_2etesting_2eaddRes(v_acc_241, v_x_2423));
  V v_t_2425 = ({ V a_0 = v_rest_245; V a_1 = v_t_2424; V r_ = (g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_t_2425;
  heff_room[0] = v_hd_247;
  heff_room[1] = v_k_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2422;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Settled: {
    V v_r_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_c_2422 = heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam3, 2, 1, (V[]){v_r_2410});
    break;
  }
  case TAG_Pend: {
    V v_p_2413 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_file_2414 = heff_take_field(v_p_2413, 0);
    V v_outcomes_2415 = heff_take_field(v_p_2413, 3);
    V v_wrong_2416 = heff_take_field(v_p_2413, 1);
    V v_reports_2417 = heff_get_n(v_p_2413, 2, 7);
    V v_c_2418 = (g_heff_2ebuild_2etesting_2ewithGoldens_24s514338264x1125087176(NTAG(TAG_False), heff_dup(v_file_2414), v_outcomes_2415));
    v_c_2422 = heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam4, 2, 4, (V[]){v_c_2418, v_file_2414, v_wrong_2416, v_reports_2417});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam6, 1, 4, (V[]){v_acc_241, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857_lam2, 1, 4, (V[]){v_hd_247, v_acc_241, v_rest_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_str0, 3, "git");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_str4, 6, ": git ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_str5, 2, ": ");
V g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_lam0(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_lam0, 1, 0};
V g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_entry, 4, 0};

V g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416(V v_what_240, V v_argv_241, V v_hd_242, V v_k_243) {
top: ;
  V v_bind_244 = heff_take_field(v_hd_242, 1);
  V v_malg_245 = heff_get_n(v_hd_242, 2, 3);
  V v_t_246 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_str0), heff_dup(v_argv_241), ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_str1), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_246, ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tr(heff_call(v_malg_245, 1, (V[]){v_t_2414}));
  return heff_tail(v_bind_244, 2, (V[]){v_t_2415, heff_clo_n(g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_lam1, 1, 3, (V[]){v_argv_241, v_what_240, v_k_243})});
}
V g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_lam0(V self, V *args) {
  V v_r_247 = args[0];
  return v_r_247;
}
V g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_argv_241 = heff_env(self)[0];
  V v_what_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_ended_2417 = heff_take_field(v_x_2416, 0);
  V v_err_2418 = heff_get_n(v_x_2416, 2, 3);
  V v_t_2421;
  switch (heff_tag_of(v_ended_2417)) {
  case TAG_Exited: {
    V v_n_2419 = heff_field(v_ended_2417, 0);
    heff_take_n(v_ended_2417, 1ULL, 1);
    v_t_2421 = heff_bool(heff_intEq_c_lent(v_n_2419, MK_INT(0LL), 2));
    heff_drop(v_n_2419);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2417, 0ULL, 1);
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_ended_2417);
  }
  V v_x_2432;
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop(v_argv_241);
    heff_drop(v_what_240);
    heff_drop(v_err_2418);
    heff_drop(v_t_2421);
    v_x_2432 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_2421);
    V v_t_2424;
    switch (heff_tag_of(v_argv_241)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_argv_241, 0);
      V v_xs_2423 = heff_field(v_argv_241, 1);
      heff_take_n(v_argv_241, 3ULL, 2);
      v_t_2424 = ({ V a_0 = ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_str3); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_argv_241);
    }
    V v_t_2425 = heff_strAppend(heff_strAppend(v_what_240, ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_str4)), v_t_2424);
    V v_s_2426 = v_err_2418;
    V v_t_2427 = (g_prelude_2eskipSpaces(v_s_2426, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2428 = (heff_unbox_word(heff_strLength_lent(v_s_2426, 0)) - ((int64_t)1ULL));
    V v_t_2429 = (g_prelude_2eskipSpaces(v_s_2426, heff_box_word(v_t_2428), MK_INT(-1LL)));
    V v_t_2430 = heff_strSlice(v_s_2426, v_t_2427, heff_intAdd(v_t_2429, MK_INT(1LL)));
    V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416_str5)), v_t_2430);
    v_x_2432 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2431});
  }
  V f_ = v_k_243;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str2, 2, "-m");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str3, 3, "tag");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str4, 2, "-a");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str5, 10, "not tagged");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str6, 1, "v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str7, 4, "push");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str8, 6, "origin");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str9, 18, "tagged, not pushed");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str10, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str11, 1, " ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str12, 7, ", tag v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str13, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str14, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str15, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str16, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str17, 1, "\012");
V g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_lam1(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_lam0(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_entry, 4, 0};

V g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279(V v_v_240, V v_pk_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str0), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str1), heff_dup(v_v_240)), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str2), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str4), v_t_245})});
  HEFF_LAST return g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str5), v_t_246, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_lam0, 1, 4, (V[]){v_v_240, v_hd_242, v_pk_241, v_k_243}));
}
V g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_lam2(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2432);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_pk_241 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str10), heff_get_n(v_pk_241, 0, 4));
    V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str11)), heff_dup(v_v_240));
    V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str12)), v_v_240);
    V v_t_2414 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str13)), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})}));
    V f_ = heff_get_n(v_hd_242, 1, 3);
    heff_room[0] = v_t_2421;
    heff_room[1] = v_k_243;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_why_2422 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    heff_drop_rec(v_pk_241, 4);
    heff_drop(v_v_240);
    V v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str14), v_why_2422), ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str15));
    V v_t_2424 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2423, NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})}));
    V f_ = heff_dup(heff_rfield(v_hd_242, 1));
    heff_room[0] = v_t_2431;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_lam2, 1, 2, (V[]){v_hd_242, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_lam3(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2443);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_242, v_k_243));
}
V g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str6), heff_dup(v_v_240)), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str8), v_t_248})});
    return (g_heff_2ebuild_2epackaging_2egitOk_24s1548968891x1898002416(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str9), v_t_249, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_lam1, 1, 4, (V[]){v_pk_241, v_v_240, v_hd_242, v_k_243})));
  }
  case TAG_Just: {
    V v_why_2433 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_241, 4);
    V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str16), v_why_2433), ((V)&g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_str17));
    V v_t_2435 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2434, NTAG(TAG_MkUnit)});
    V v_t_2436 = heff_tag_at_n(v_ru_24x_247_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})}));
    V f_ = heff_dup(heff_rfield(v_hd_242, 1));
    heff_room[0] = v_t_2442;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279_lam3, 1, 2, (V[]){v_hd_242, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_247);
  }
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_str0, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_str1, 27, " expectations do not hold, ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_str2, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_str3, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_str4, 37, " tests fail, or a file does not check");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_str5, 1, "\012");
V g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_lam0(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_entry, 5, 0};

V g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412(V v_v_240, V v_pk_241, V v_r_242, V v_p_243, V v_p_244) {
top: ;
  V v_failed_245 = heff_take_field(v_r_242, 3);
  V v_testsFailed_246 = heff_take_field(v_r_242, 6);
  V v_unchecked_247 = heff_take_field(v_r_242, 4);
  V v_total_248 = heff_take_field(v_r_242, 2);
  V v_tests_249 = heff_get_n(v_r_242, 5, 8);
  V v_t_2412;
  if (heff_intLt_c_lent(MK_INT(0LL), v_failed_245, 1)) {
    heff_drop(v_unchecked_247);
    v_t_2412 = NTAG(TAG_True);
  } else {
    if (heff_intLt_c_lent(MK_INT(0LL), v_testsFailed_246, 1)) {
      heff_drop(v_unchecked_247);
      v_t_2412 = NTAG(TAG_True);
    } else {
      switch (heff_tag_of(v_unchecked_247)) {
      case TAG_Nil: {
        v_t_2412 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_unchecked_247, 0ULL, 2);
        v_t_2412 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_unchecked_247);
      }
    }
  }
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_v_240);
    heff_drop(v_pk_241);
    heff_drop(v_t_2412);
    V v_t_2413 = heff_strAppend(heff_intShow(v_failed_245), ((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_str0));
    V v_t_2414 = heff_strAppend(v_t_2413, heff_intShow(v_total_248));
    V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_str1)), heff_intShow(v_testsFailed_246));
    V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_str2)), heff_intShow(v_tests_249));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_str3), heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_str4)));
    V v_t_2418 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2417, ((V)&g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_str5)), NTAG(TAG_MkUnit)});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})}));
    return heff_tail(heff_dup(heff_rfield(v_p_243, 1)), 2, (V[]){v_t_2425, heff_clo_n(g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_lam0, 1, 2, (V[]){v_p_243, v_p_244})});
  } else {
    heff_drop(v_failed_245);
    heff_drop(v_testsFailed_246);
    heff_drop(v_total_248);
    heff_drop(v_tests_249);
    heff_drop(v_t_2412);
    return (g_heff_2ebuild_2epackaging_2epublishTag_24s1380552859x772717279(v_v_240, v_pk_241, v_p_243, v_p_244));
  }
}
V g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412_lam0(V self, V *args) {
  V v_x_2426 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_p_243, v_p_244));
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str0, 3, "git");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str1, 6, "status");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str2, 11, "--porcelain");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str3, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str4, 2, "-q");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str5, 8, "--verify");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str6, 3, "git");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str7, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str9, 25, "not in a git repository: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str10, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str13, 67, "heff publish: what is published is what is committed: commit first\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str14, 1, "v");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str15, 18, " is tagged already");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str16, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str17, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str18, 0, "");
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam1(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam1, 1, 0};
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam5(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam7(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam6(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam0(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam8(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam8, 1, 0};
Clo g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_entry, 5, 0};

V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513(V v_v_240, V v_pk_241, V v_src_242, V v_hd_243, V v_k_244) {
top: ;
  V v_lit_245 = ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str0);
  V v_lit_246 = ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str1);
  V v_lit_247 = ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str2);
  V v_lit_248 = MK_INT(0LL);
  V v_lit_249 = MK_INT(0LL);
  V v_p_2410 = heff_dup(v_hd_243);
  V v_bind_2411 = heff_take_field(v_p_2410, 1);
  V v_malg_2412 = heff_get_n(v_p_2410, 2, 3);
  V v_p_2484 = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam0, 1, 5, (V[]){v_v_240, v_hd_243, v_k_244, v_src_242, v_pk_241});
  V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_247, NTAG(TAG_Nil)});
  V v_t_2486 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_lit_245, heff_tag_n(TAG_Cons, 2, (V[]){v_lit_246, v_t_2485}), ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str18), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), v_lit_248, v_lit_249, NTAG(TAG_False)});
  V v_t_2488 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2486, ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam8_clo)})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tr(heff_call(v_malg_2412, 1, (V[]){v_t_2494}));
  return heff_tail(v_bind_2411, 2, (V[]){v_t_2495, v_p_2484});
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam1(V self, V *args) {
  V v_r_2420 = args[0];
  return v_r_2420;
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam3(V self, V *args) {
  V v_x_2448 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2448);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam4(V self, V *args) {
  V v_x_2463 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2463);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam5(V self, V *args) {
  V v_x_2478 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2478);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam7(V self, V *args) {
  V v_x_2483 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_pk_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2epackaging_2epublishTested_24s1008701037x1328252412(v_v_240, v_pk_241, v_x_2483, v_hd_243, v_k_244));
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam6(V self, V *args) {
  V v_x_2481 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  V v_pk_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2482 = ({ V a_0 = v_x_2481; V a_1 = heff_dup(g_heff_2ebuild_2etesting_2enoRes_get()); V r_ = (g_heff_2ebuild_2epackaging_2etestAll_24s1128591548x1194875857(a_0, a_1)); heff_drop(v_x_2481); r_; });
  V f_ = v_c_2482;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam7, 1, 4, (V[]){v_v_240, v_pk_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam2(V self, V *args) {
  V v_x_2429 = args[0];
  V v_ended_2414 = heff_env(self)[0];
  V v_err_2415 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_out_2416 = heff_env(self)[4];
  V v_v_240 = heff_env(self)[5];
  V v_src_242 = heff_env(self)[6];
  V v_pk_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2432;
  switch (heff_tag_of(v_ended_2414)) {
  case TAG_Exited: {
    V v_n_2430 = heff_field(v_ended_2414, 0);
    heff_take_n(v_ended_2414, 1ULL, 1);
    v_t_2432 = heff_bool(!heff_intEq_c_lent(v_n_2430, MK_INT(0LL), 2));
    heff_drop(v_n_2430);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2414, 0ULL, 1);
    v_t_2432 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2432 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2432 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_ended_2414);
  }
  if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2429, 3);
    heff_drop(v_out_2416);
    heff_drop(v_v_240);
    heff_drop(v_src_242);
    heff_drop(v_pk_241);
    heff_drop(v_t_2432);
    V v_s_2433 = v_err_2415;
    V v_t_2434 = (g_prelude_2eskipSpaces(v_s_2433, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_s_2433, 0)) - ((int64_t)1ULL));
    V v_t_2436 = (g_prelude_2eskipSpaces(v_s_2433, heff_box_word(v_t_2435), MK_INT(-1LL)));
    V v_t_2437 = heff_strSlice(v_s_2433, v_t_2434, heff_intAdd(v_t_2436, MK_INT(1LL)));
    V v_why_2438 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str9), v_t_2437);
    V v_t_2439 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str10), v_why_2438), ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str11));
    V v_t_2440 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2439, NTAG(TAG_MkUnit)});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})}));
    V f_ = heff_dup(heff_rfield(v_hd_243, 1));
    heff_room[0] = v_t_2447;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam3, 1, 2, (V[]){v_hd_243, v_k_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_err_2415);
    heff_drop(v_t_2432);
    V v_s_2449 = v_out_2416;
    V v_t_2450 = (g_prelude_2eskipSpaces(v_s_2449, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2451 = (heff_unbox_word(heff_strLength_lent(v_s_2449, 0)) - ((int64_t)1ULL));
    V v_t_2452 = (g_prelude_2eskipSpaces(v_s_2449, heff_box_word(v_t_2451), MK_INT(-1LL)));
    V v_t_2453 = heff_strSlice(v_s_2449, v_t_2450, heff_intAdd(v_t_2452, MK_INT(1LL)));
    V v_x1_2454 = heff_bool(heff_strEq_c_lent(v_t_2453, ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str12), 2));
    heff_drop(v_t_2453);
    if (!(heff_dup(v_x1_2454) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2429, 3);
      heff_drop(v_v_240);
      heff_drop(v_src_242);
      heff_drop(v_pk_241);
      heff_drop(v_x1_2454);
      V v_t_2455 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str13), NTAG(TAG_MkUnit)});
      V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
      V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
      V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
      V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
      V v_t_2461 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2460})});
      V v_t_2462 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})}));
      V f_ = heff_dup(heff_rfield(v_hd_243, 1));
      heff_room[0] = v_t_2462;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam4, 1, 2, (V[]){v_hd_243, v_k_244});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x1_2454);
      V v_t_2464 = heff_get_n(v_x_2429, 0, 3);
      V v_t_2467;
      switch (heff_tag_of(v_t_2464)) {
      case TAG_Exited: {
        V v_n_2465 = heff_field(v_t_2464, 0);
        heff_take_n(v_t_2464, 1ULL, 1);
        v_t_2467 = heff_bool(heff_intEq_c_lent(v_n_2465, MK_INT(0LL), 2));
        heff_drop(v_n_2465);
        break;
      }
      case TAG_Signalled: {
        heff_take_n(v_t_2464, 0ULL, 1);
        v_t_2467 = NTAG(TAG_False);
        break;
      }
      case TAG_TimedOut: {
        v_t_2467 = NTAG(TAG_False);
        break;
      }
      case TAG_NotRun: {
        v_t_2467 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2464);
      }
      if ((heff_dup(v_t_2467) == NTAG(TAG_True))) {
        heff_drop(v_src_242);
        heff_drop(v_pk_241);
        heff_drop(v_t_2467);
        V v_t_2468 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str14), v_v_240), ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str15));
        V v_t_2469 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str16), v_t_2468), ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str17));
        V v_t_2470 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2469, NTAG(TAG_MkUnit)});
        V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
        V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
        V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
        V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
        V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
        V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
        V v_t_2477 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})}));
        V f_ = heff_dup(heff_rfield(v_hd_243, 1));
        heff_room[0] = v_t_2477;
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam5, 1, 2, (V[]){v_hd_243, v_k_244});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2467);
        V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){v_src_242, NTAG(TAG_Nil)});
        V v_c_2480 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(v_t_2479, NTAG(TAG_Nil)));
        V f_ = v_c_2480;
        heff_room[0] = heff_dup(v_hd_243);
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam6, 1, 4, (V[]){v_hd_243, v_v_240, v_pk_241, v_k_244});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_v_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_src_242 = heff_env(self)[3];
  V v_pk_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_ended_2414 = heff_take_field(v_x_2413, 0);
  V v_err_2415 = heff_take_field(v_x_2413, 2);
  V v_out_2416 = heff_get_n(v_x_2413, 1, 3);
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str3), heff_dup(v_v_240)), NTAG(TAG_Nil)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str5), v_t_2417})});
  V v_t_2419 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str7), v_t_2418}), ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_str8), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2419, ((V)&g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam1_clo)})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2427}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2428;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam2, 1, 8, (V[]){v_ended_2414, v_err_2415, v_hd_243, v_k_244, v_out_2416, v_v_240, v_src_242, v_pk_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513_lam8(V self, V *args) {
  V v_r_2487 = args[0];
  return v_r_2487;
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_str1, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_str3, 3, "src");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_str4, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_str6, 3, "src");
V g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_lam0(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_lam1(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_entry, 5, 0};

V g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970(V v_v_240, V v_l_241, V v_pk_242, V v_z_243, V v_z_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(heff_rfield(v_pk_242, 0)), heff_dup(v_v_240)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_v_240);
      heff_drop_rec(v_l_241, 5);
      V v_why_248 = v_field_247;
      V v_t_249 = heff_strAppend(heff_get_n(v_pk_242, 0, 4), ((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_str0));
      V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_str1), heff_strAppend(v_t_249, v_why_248));
      V v_t_2411 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_str2)), NTAG(TAG_MkUnit)});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})}));
      return heff_tail(heff_dup(heff_rfield(v_z_243, 1)), 2, (V[]){v_t_2418, heff_clo_n(g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_lam0, 1, 2, (V[]){v_z_243, v_z_244})});
    } else {
      heff_drop(v_field_247);
      V v_st_2420 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 5, 6);
      V v_t_2421 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 0, 6);
      V v_t_2422 = (g_std_2epath_2eparse(heff_dup(v_st_2420), v_t_2421));
      V v_t_2423 = (g_std_2epath_2eparse(heff_dup(v_st_2420), ((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_str3)));
      V v_t_2424 = (g_std_2epath_2ejoin(v_t_2422, v_t_2423));
      V v_t_2425 = ({ V a_0 = v_st_2420; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2420); heff_drop(v_t_2424); r_; });
      V v_c_2426 = (g_heff_2ebuild_2eload_2eownDir_24s1052128964x1221930056(heff_dup(heff_rfield(v_l_241, 2)), v_t_2425));
      return heff_tail(v_c_2426, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_lam1, 1, 5, (V[]){v_z_243, v_z_244, v_l_241, v_v_240, v_pk_242})});
    }
  }
}
V g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_lam0(V self, V *args) {
  V v_x_2419 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2419);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_243, v_z_244));
}
V g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_lam2(V self, V *args) {
  V v_x_2438 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2438);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_243, v_z_244));
}
V g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_lam1(V self, V *args) {
  V v_x_2427 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  V v_pk_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    V v_why_2428 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Left = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    heff_drop_rec(v_l_241, 5);
    heff_drop(v_v_240);
    heff_drop_rec(v_pk_242, 4);
    V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_str4), v_why_2428), ((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_str5));
    V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2429, NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_at_n(v_ru_24x_2427_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})}));
    V f_ = heff_dup(heff_rfield(v_z_243, 1));
    heff_room[0] = v_t_2437;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_lam2, 1, 2, (V[]){v_z_243, v_z_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2427, 0ULL, 1);
    V v_st_2440 = heff_get_n(heff_dup(heff_rfield(v_l_241, 2)), 5, 6);
    V v_t_2441 = heff_get_n(heff_get_n(v_l_241, 2, 5), 0, 6);
    V v_t_2442 = (g_std_2epath_2eparse(heff_dup(v_st_2440), v_t_2441));
    V v_t_2443 = (g_std_2epath_2eparse(heff_dup(v_st_2440), ((V)&g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970_str6)));
    V v_t_2444 = (g_std_2epath_2ejoin(v_t_2442, v_t_2443));
    V v_t_2445 = ({ V a_0 = v_st_2440; V a_1 = v_t_2444; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2440); heff_drop(v_t_2444); r_; });
    return (g_heff_2ebuild_2epackaging_2epublishGit_24s868337546x1739772513(v_v_240, v_pk_242, v_t_2445, v_z_243, v_z_244));
  }
  default: return heff_nomatch(v_x_2427);
  }
}
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str1, 64, "heff publish: no package.hf here: publish at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str2, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str3, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str4, 39, "heff publish: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str5, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str6, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str7, 1, "`");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str8, 22, "` is no version: a.b.c");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str9, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str10, 1, "\012");
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam0(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam0, 1, 0};
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam2(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam1(V self, V *args); static Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam1, 1, 0};
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam5(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam10(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam11(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam12(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam9(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam8(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam7(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam6(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam4(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam3(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam14(V self, V *args);
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam13(V self, V *args);
Clo g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_entry, 1, 0};

V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562(V v_v_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_x_244 = v_field_243;
      heff_drop(v_x_244);
      V v_path_245 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str0)));
      V v_t_246 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_245; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_245); r_; });
      V v_a_248 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_246, ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam0_clo)});
      V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_248})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
      V v_c_2421 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam1_clo)));
      return heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam3, 2, 2, (V[]){v_c_2421, v_v_240});
    } else {
      heff_drop(v_field_243);
      return heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam13, 2, 1, (V[]){v_v_240});
    }
  }
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562(a[0]);
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam0(V self, V *args) {
  V v_r_247 = args[0];
  return v_r_247;
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_x_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_err_2416 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Left = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    V v_t_2417 = heff_tag_at_n(v_ru_24x_2415_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2416})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2417));
  }
  case TAG_Right: {
    V v_x_2418 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam2, 2, 1, (V[]){v_x_2418});
  }
  default: return heff_nomatch(v_x_2415);
  }
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_2422 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2434);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2422, v_k_2423));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam10(V self, V *args) {
  V v_x_2452 = args[0];
  V v_hd_2422 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2452);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2422, v_k_2423));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam11(V self, V *args) {
  V v_x_2462 = args[0];
  V v_hd_2422 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2462);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2422, v_k_2423));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam12(V self, V *args) {
  V v_x_2472 = args[0];
  V v_hd_2422 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2472);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2422, v_k_2423));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_x_2437 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_cs_2441 = heff_env(self)[4];
  V v_v_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2442);
  V v_t_2443 = heff_dup(heff_rfield(v_x_2437, 3));
  switch (heff_tag_of(v_t_2443)) {
  case TAG_Nothing: {
    heff_drop_rec(v_x_2437, 5);
    heff_drop(v_x_2438);
    heff_drop(v_cs_2441);
    heff_drop(v_v_240);
    V v_t_2444 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str4), NTAG(TAG_MkUnit)});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2422, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})}));
    V f_ = heff_dup(heff_rfield(v_hd_2422, 1));
    heff_room[0] = v_t_2451;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam10, 1, 2, (V[]){v_hd_2422, v_k_2423});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_pk_2453 = heff_field(v_t_2443, 0);
    V v_ru_24t_2443_24Just = heff_take_reuse_n(v_t_2443, 1ULL, 1);
    if (heff_intLt_c(MK_INT(0LL), v_x_2438)) {
      heff_drop_rec(v_x_2437, 5);
      heff_drop(v_cs_2441);
      heff_drop(v_v_240);
      heff_drop(v_pk_2453);
      V v_t_2454 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str5), NTAG(TAG_MkUnit)});
      V v_t_2455 = heff_tag_at_n(v_ru_24t_2443_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
      V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
      V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
      V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
      V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
      V v_t_2461 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2422, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2460})}));
      V f_ = heff_dup(heff_rfield(v_hd_2422, 1));
      heff_room[0] = v_t_2461;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam11, 1, 2, (V[]){v_hd_2422, v_k_2423});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      V v_t_2463 = ({ V a_0 = v_cs_2441; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_2441); r_; });
      if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
        heff_drop_rec(v_x_2437, 5);
        heff_drop(v_v_240);
        heff_drop(v_pk_2453);
        heff_drop(v_t_2463);
        V v_t_2464 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str6), NTAG(TAG_MkUnit)});
        V v_t_2465 = heff_tag_at_n(v_ru_24t_2443_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
        V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
        V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
        V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
        V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
        V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
        V v_t_2471 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2422, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})}));
        V f_ = heff_dup(heff_rfield(v_hd_2422, 1));
        heff_room[0] = v_t_2471;
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam12, 1, 2, (V[]){v_hd_2422, v_k_2423});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_cell(v_ru_24t_2443_24Just, 1);
        heff_drop(v_t_2463);
        return (g_heff_2ebuild_2epackaging_2epublishChecked_24s286257718x21630970(v_v_240, v_x_2437, v_pk_2453, v_hd_2422, v_k_2423));
      }
    }
  }
  default: return heff_nomatch(v_t_2443);
  }
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam8(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_2422 = heff_env(self)[0];
  V v_x_2437 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_v_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_cs_2441 = heff_get_n(v_x_2440, 0, 2);
  return ({ V a_0 = v_cs_2441; V a_1 = heff_dup(v_hd_2422); V a_2 = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam9, 1, 6, (V[]){v_x_2437, v_hd_2422, v_k_2423, v_x_2438, heff_dup(v_cs_2441), v_v_240}); V r_ = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(a_0, a_1, a_2)); heff_drop(v_cs_2441); r_; });
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam7(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2437 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2439 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_x_2437)));
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_hd_2422);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam8, 1, 5, (V[]){v_hd_2422, v_x_2437, v_k_2423, v_x_2438, v_v_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_2422 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  V v_v_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str3), heff_dup(heff_rfield(v_x_2437, 1)), MK_INT(0LL), heff_dup(v_hd_2422), heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam7, 1, 4, (V[]){v_x_2437, v_hd_2422, v_k_2423, v_v_240})));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_2422 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  V v_v_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    V v_ru_24x_2424_24Left = heff_take_reuse_n(v_x_2424, 0ULL, 1);
    heff_drop(v_v_240);
    V v_t_2426 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str1), NTAG(TAG_MkUnit)});
    V v_t_2427 = heff_tag_at_n(v_ru_24x_2424_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2422, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})}));
    V f_ = heff_dup(heff_rfield(v_hd_2422, 1));
    heff_room[0] = v_t_2433;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam5, 1, 2, (V[]){v_hd_2422, v_k_2423});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2424, 0ULL, 1);
    V v_c_2436 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str2)));
    V f_ = v_c_2436;
    heff_room[0] = heff_dup(v_hd_2422);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam6, 1, 3, (V[]){v_hd_2422, v_k_2423, v_v_240});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_v_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam4, 1, 3, (V[]){v_hd_2422, v_k_2423, v_v_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam14(V self, V *args) {
  V v_x_2485 = args[0];
  V v_hd_2473 = heff_env(self)[0];
  V v_k_2474 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2485);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2473, v_k_2474));
}
V g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam13(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k_2474 = args[1];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2475 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str7), v_v_240), ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str8));
  V v_t_2476 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str9), v_t_2475), ((V)&g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_str10));
  V v_t_2477 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2476, NTAG(TAG_MkUnit)});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2473, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})}));
  V f_ = heff_dup(heff_rfield(v_hd_2473, 1));
  args[0] = v_t_2484;
  args[1] = heff_clo_n(g_heff_2ebuild_2epackaging_2epublishCmd_24s422655747x928996562_lam14, 1, 2, (V[]){v_hd_2473, v_k_2474});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}