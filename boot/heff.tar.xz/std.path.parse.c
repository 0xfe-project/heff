// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2eparse_2ekeep_240_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2eparse_2ekeep_240_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
Clo g_std_2epath_2eparse_2ekeep_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2eparse_2ekeep_240_entry, 1, 0};

V g_std_2epath_2eparse_2ekeep_240(V v_x1_240) {
top: ;
  V v_t_241 = heff_strEq(heff_dup(v_x1_240), ((V)&g_std_2epath_2eparse_2ekeep_240_str0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_x1_240);
    heff_drop(v_t_241);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    heff_drop(v_t_241);
    V v_t_242 = heff_strEq(v_x1_240, ((V)&g_std_2epath_2eparse_2ekeep_240_str1));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_t_242);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      heff_drop(v_t_242);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_std_2epath_2eparse_2ekeep_240_entry(V self, V *a) {
  (void)self;
  return g_std_2epath_2eparse_2ekeep_240(a[0]);
}