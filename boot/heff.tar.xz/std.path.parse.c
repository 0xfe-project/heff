// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_std_2epath_2eparse_2ekeep_240(V);
V g_std_2epath_2eparse_2ekeep_240_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_2ekeep_240_clo;
HEFF_LIT(g_std_2epath_2eparse_2ekeep_240_str0, 0, "");
HEFF_LIT(g_std_2epath_2eparse_2ekeep_240_str1, 1, ".");
Clo g_std_2epath_2eparse_2ekeep_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2eparse_2ekeep_240_entry, 1, 0};

V g_std_2epath_2eparse_2ekeep_240(V v_x1_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_x1_240, ((V)&g_std_2epath_2eparse_2ekeep_240_str0), 2) ? 0 : !heff_strEq_c_lent(v_x1_240, ((V)&g_std_2epath_2eparse_2ekeep_240_str1), 2)));
  return v_ret_24bool;
}
V g_std_2epath_2eparse_2ekeep_240_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2epath_2eparse_2ekeep_240(a0); heff_drop(a0); return r;
}