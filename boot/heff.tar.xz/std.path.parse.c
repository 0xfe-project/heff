// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_std_2epath_2eparse_2ekeep_240(V);
V g_std_2epath_2eparse_2ekeep_240_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_2ekeep_240_clo;
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2eparse_2ekeep_240_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2epath_2eparse_2ekeep_240_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
Clo g_std_2epath_2eparse_2ekeep_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2epath_2eparse_2ekeep_240_entry, 1, 0};

V g_std_2epath_2eparse_2ekeep_240(V v_x1_240) {
top: ;
  if (heff_strEq_c(heff_dup(v_x1_240), ((V)&g_std_2epath_2eparse_2ekeep_240_str0))) {
    heff_drop(v_x1_240);
    return NTAG(TAG_False);
  } else {
    if (heff_strEq_c(v_x1_240, ((V)&g_std_2epath_2eparse_2ekeep_240_str1))) {
      return NTAG(TAG_False);
    } else {
      return NTAG(TAG_True);
    }
  }
}
V g_std_2epath_2eparse_2ekeep_240_entry(V self, V *a) {
  (void)self;
  return g_std_2epath_2eparse_2ekeep_240(a[0]);
}