// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CBool 61457
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_DoneOrErrno 39355
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_MkCode 2932
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_UFixed 18334
#define TAG_UFn 31401
#define TAG_UOp 31682
#define TAG_URel 1603
#define TAG_UToDouble 51807
#define LBL_arg 306384
#define LBL_args 9498020
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_defs 9574869
#define LBL_ems 310085
#define LBL_end 310101
#define LBL_entry 298026124
#define LBL_errors 652506774
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_fresh 299054408
#define LBL_fun 311289
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_lprotos 613175609
#define LBL_name 9869138
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_post 9942375
#define LBL_pre 320797
#define LBL_prefix 967031229
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_s 333
#define LBL_shapes 1043573789
#define LBL_source 1050636102
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_tags 10047712
#define LBL_tuples 1084651734
#define LBL_ver 326173
#define LBL_wrapper 1827365593
static uint32_t shape_arg__pre__post[] = {LBL_arg, LBL_pre, LBL_post};
static uint32_t shape_ems__s__fresh[] = {LBL_ems, LBL_s, LBL_fresh};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
static uint32_t shape_prefix__end[] = {LBL_prefix, LBL_end};
static uint32_t shape_protos__code[] = {LBL_protos, LBL_code};
static uint32_t shape_source__errors[] = {LBL_source, LBL_errors};
static uint32_t shape_tags__lbls__facts[] = {LBL_tags, LBL_lbls, LBL_facts};
V g_heff_2ecompile_2eemitc_2eargC(V, V, V);
V g_heff_2ecompile_2eemitc_2eargC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargC_clo;
V g_heff_2ecompile_2eemitc_2eargLine(V, V);
V g_heff_2ecompile_2eemitc_2eargLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargLine_clo;
V g_heff_2ecompile_2eemitc_2eargLines_24dps(V, V, V);
V g_heff_2ecompile_2eemitc_2eargLines_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eargLines_24dps_clo;
V g_heff_2ecompile_2eemitc_2ecallLent(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallLent_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallLent_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC(V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo;
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(V, V);
V g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps_clo;
V g_heff_2ecompile_2eemitc_2eceOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eceOf_clo;
V g_heff_2ecompile_2eemitc_2echeckEnd(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckEnd_clo;
V g_heff_2ecompile_2eemitc_2echeckOut(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckOut_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
HeffT2 g_heff_2ecompile_2eemitc_2edefC_24cpr(V, V, V);
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eemitAt(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eemitAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eemitAt_clo;
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void);
V g_heff_2ecompile_2eemitc_2eexpF(V, V);
V g_heff_2ecompile_2eemitc_2eexpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eexpF_clo;
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efixedU(V, V, V);
V g_heff_2ecompile_2eemitc_2efixedU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedU_clo;
V g_heff_2ecompile_2eemitc_2efunHead(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2efunHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunHead_clo;
V g_heff_2ecompile_2eemitc_2efunTypeName(V);
V g_heff_2ecompile_2eemitc_2efunTypeName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunTypeName_clo;
V g_heff_2ecompile_2eemitc_2egivenMask(V, V, V);
V g_heff_2ecompile_2eemitc_2egivenMask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2egivenMask_clo;
V g_heff_2ecompile_2eemitc_2eglueCallOf(V);
V g_heff_2ecompile_2eemitc_2eglueCallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglueCallOf_clo;
V g_heff_2ecompile_2eemitc_2ehashedGo(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ehashedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehashedGo_clo;
V g_heff_2ecompile_2eemitc_2ekeptOf(V, V, V);
V g_heff_2ecompile_2eemitc_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ekeptOf_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2elamC(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamC_clo;
HeffT2 g_heff_2ecompile_2eemitc_2elamLines_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elentPrimC(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elentPrimC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentPrimC_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emergeKept(V, V, V);
V g_heff_2ecompile_2eemitc_2emergeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emergeKept_clo;
V g_heff_2ecompile_2eemitc_2emoduleParts(V, V);
V g_heff_2ecompile_2eemitc_2emoduleParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emoduleParts_clo;
V g_heff_2ecompile_2eemitc_2enumbered(V, V, V);
V g_heff_2ecompile_2eemitc_2enumbered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enumbered_clo;
V g_heff_2ecompile_2eemitc_2epartCount(V, V);
V g_heff_2ecompile_2eemitc_2epartCount_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartCount_clo;
V g_heff_2ecompile_2eemitc_2epartsFrom(V, V, V, V);
V g_heff_2ecompile_2eemitc_2epartsFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epartsFrom_clo;
V g_heff_2ecompile_2eemitc_2epointerFnLines(V, V, V, V);
V g_heff_2ecompile_2eemitc_2epointerFnLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epointerFnLines_clo;
V g_heff_2ecompile_2eemitc_2epointerFnLines_24dps(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epointerFnLines_24dps_clo;
V g_heff_2ecompile_2eemitc_2eprimLit(V, V);
V g_heff_2ecompile_2eemitc_2eprimLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimLit_clo;
V g_heff_2ecompile_2eemitc_2eprogramCE(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eprogramCE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprogramCE_clo;
V g_heff_2ecompile_2eemitc_2eprojShapesW(V, V);
V g_heff_2ecompile_2eemitc_2eprojShapesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprojShapesW_clo;
V g_heff_2ecompile_2eemitc_2epushOwn(V, V, V);
V g_heff_2ecompile_2eemitc_2epushOwn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epushOwn_clo;
V g_heff_2ecompile_2eemitc_2eroomed(V);
V g_heff_2ecompile_2eemitc_2eroomed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eroomed_clo;
HeffT2 g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(V, V);
V g_heff_2ecompile_2eemitc_2estrLit(V, V, V);
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estrLit_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void);
HeffT2 g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eunboxed(V);
V g_heff_2ecompile_2eemitc_2eunboxed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eunboxed_clo;
V g_heff_2ecompile_2eemitc_2eunboxedC(V, V);
V g_heff_2ecompile_2eemitc_2eunboxedC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eunboxedC_clo;
HeffT2 g_heff_2ecompile_2eemitc_2evalDef_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapped(V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapped_clo;
V g_heff_2ecompile_2efacts_2esureOnlyHere(V, V, V);
V g_heff_2ecompile_2efacts_2esureOnlyHere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efacts_2esureOnlyHere_clo;
HeffT2 g_heff_2ecompile_2eimperative_2edefOf_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2egenOf(V);
V g_heff_2ecompile_2eimperative_2egenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2egenOf_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2elower_2ercOf(V, V);
V g_heff_2ecompile_2elower_2ercOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ercOf_clo;
V g_heff_2ecompile_2eowned_2elendingPrim(V);
V g_heff_2ecompile_2eowned_2elendingPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2elendingPrim_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_list_2eall_24s1465078656x604124530(V);
V g_list_2eall_24s1465078656x604124530_entry(V self, V *a);
extern Clo g_list_2eall_24s1465078656x604124530_clo;
V g_list_2eall_24s1793250635x935291087(V);
V g_list_2eall_24s1793250635x935291087_entry(V self, V *a);
extern Clo g_list_2eall_24s1793250635x935291087_clo;
V g_list_2eany_24s63755471x810534073(V, V);
V g_list_2eany_24s63755471x810534073_entry(V self, V *a);
extern Clo g_list_2eany_24s63755471x810534073_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f409057300x985797598(V, V);
V g_list_2efoldl_24f409057300x985797598_entry(V self, V *a);
extern Clo g_list_2efoldl_24f409057300x985797598_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1882737314x358197882(V, V, V, V);
V g_list_2efoldl_24s1882737314x358197882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1882737314x358197882_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s478006518x1380334353(V);
V g_list_2ekeepIf_24s478006518x1380334353_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s478006518x1380334353_clo;
V g_list_2emap_24f1005417903x1119563692(V, V, V);
V g_list_2emap_24f1005417903x1119563692_entry(V self, V *a);
extern Clo g_list_2emap_24f1005417903x1119563692_clo;
V g_list_2emap_24f1512150482x179770396(V, V, V, V);
V g_list_2emap_24f1512150482x179770396_entry(V self, V *a);
extern Clo g_list_2emap_24f1512150482x179770396_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1215346472x331828322(V);
V g_list_2emap_24s1215346472x331828322_entry(V self, V *a);
extern Clo g_list_2emap_24s1215346472x331828322_clo;
V g_list_2emap_24s1275294336x693095586(V, V);
V g_list_2emap_24s1275294336x693095586_entry(V self, V *a);
extern Clo g_list_2emap_24s1275294336x693095586_clo;
V g_list_2emap_24s1613211967x1923010103(V, V, V, V);
V g_list_2emap_24s1613211967x1923010103_entry(V self, V *a);
extern Clo g_list_2emap_24s1613211967x1923010103_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s577269653x49010166(V);
V g_list_2emap_24s577269653x49010166_entry(V self, V *a);
extern Clo g_list_2emap_24s577269653x49010166_clo;
V g_list_2emap_24s976303750x321235480(V);
V g_list_2emap_24s976303750x321235480_entry(V self, V *a);
extern Clo g_list_2emap_24s976303750x321235480_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1737719962x691725464(V, V, V, V, V, V, V, V, V);
V g_list_2ezipWith_24s1737719962x691725464_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1737719962x691725464_clo;
V g_list_2ezipWith_24s952564628x174753269(V, V, V, V, V);
V g_list_2ezipWith_24s952564628x174753269_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s952564628x174753269_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoListOnto(V, V);
V g_std_2eordmap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoListOnto_clo;
Clo g_heff_2ecompile_2eemitc_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eelemS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eemitc_2enumbered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enumbered_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2enumbered(V v_n_240, V v_x2_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_m_242, v_x_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        V t_0 = v_n_240;
        V t_1 = v_xs_244;
        V t_2 = v_m_242;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        v_m_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_249 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_242, heff_dup(v_x_243), heff_dup(v_n_240)));
        V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
        V t_1 = v_xs_244;
        V t_2 = v_t_249;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        v_m_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2enumbered_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enumbered(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str0, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str1, 12, ")((uint64_t)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str2, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str3, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str4, 11, " (uint64_t)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str5, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str6, 2, "))");
Clo g_heff_2ecompile_2eemitc_2ewrapped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ewrapped_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ewrapped(V v_w_240, V v_op_241, V v_vs_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
  V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapped_str0), v_t_243), ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str1));
  V v_t_247;
  switch (heff_tag_of(v_vs_242)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_vs_242, 0);
    v_t_247 = heff_dup(v_x_245);
    break;
  }
  default: heff_nomatch(v_vs_242);
  }
  V v_t_248 = heff_strAppend(heff_strAppend(v_t_244, v_t_247), ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str3));
  V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, v_op_241), ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str4));
  HeffT3 v_t_2410 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
  V v_t_2416;
  {
    V v_field_2412 = v_t_2410.f[1];
    V v_field_2413 = v_t_2410.f[2];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_x_2414 = v_field_2412;
      V v_x12_2415 = v_field_2413;
      heff_drop(v_x12_2415);
      v_t_2416 = v_x_2414;
    } else {
      heff_drop(v_field_2412);
      heff_drop(v_field_2413);
      v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str5);
    }
  }
  return heff_strAppend(heff_strAppend(v_t_249, v_t_2416), ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str6));
}
V g_heff_2ecompile_2eemitc_2ewrapped_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2ewrapped(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str2, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str3, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str4, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str6, 10, "heff_bool(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str8, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str9, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str10, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str11, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str12, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str15, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str16, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str17, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str18, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str19, 9, "((double)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eunboxedC_str20, 1, ")");
Clo g_heff_2ecompile_2eemitc_2eunboxedC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eunboxedC_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eunboxedC(V v_x1_240, V v_vs_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_UFixed: {
    V v_w_242 = heff_field(v_x1_240, 0);
    V v_op_243 = heff_field(v_x1_240, 1);
    return (g_heff_2ecompile_2eemitc_2efixedU(v_w_242, v_op_243, v_vs_241));
  }
  case TAG_URel: {
    V v_op_244 = heff_field(v_x1_240, 0);
    V v_t_247;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_vs_241, 0);
      v_t_247 = heff_dup(v_x_245);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str1), v_t_247), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str2));
    V v_t_249 = heff_strAppend(heff_strAppend(v_t_248, heff_dup(v_op_244)), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str3));
    HeffT3 v_t_2410 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_2416;
    {
      V v_field_2412 = v_t_2410.f[1];
      V v_field_2413 = v_t_2410.f[2];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_x_2414 = v_field_2412;
        V v_x12_2415 = v_field_2413;
        heff_drop(v_x12_2415);
        v_t_2416 = v_x_2414;
      } else {
        heff_drop(v_field_2412);
        heff_drop(v_field_2413);
        v_t_2416 = ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str4);
      }
    }
    V v_t_2417 = heff_strAppend(heff_strAppend(v_t_249, v_t_2416), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str5));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str6), v_t_2417), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str7));
  }
  case TAG_UOp: {
    V v_op_2418 = heff_field(v_x1_240, 0);
    V v_t_2421;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2421 = ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_vs_241, 0);
      v_t_2421 = heff_dup(v_x_2419);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str9), v_t_2421), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str10));
    V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, heff_dup(v_op_2418)), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str11));
    HeffT3 v_t_2424 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_241));
    V v_t_2430;
    {
      V v_field_2426 = v_t_2424.f[1];
      V v_field_2427 = v_t_2424.f[2];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      if ((v_tag_2425 == ((int64_t)0ULL))) {
        V v_x_2428 = v_field_2426;
        V v_x12_2429 = v_field_2427;
        heff_drop(v_x12_2429);
        v_t_2430 = v_x_2428;
      } else {
        heff_drop(v_field_2426);
        heff_drop(v_field_2427);
        v_t_2430 = ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str12);
      }
    }
    return heff_strAppend(heff_strAppend(v_t_2423, v_t_2430), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str13));
  }
  case TAG_UFn: {
    V v_f_2431 = heff_field(v_x1_240, 0);
    V v_t_2434;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2434 = ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str14);
      break;
    }
    case TAG_Cons: {
      V v_x_2432 = heff_field(v_vs_241, 0);
      V v_xs_2433 = heff_field(v_vs_241, 1);
      v_t_2434 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str15), heff_dup(v_x_2432), v_xs_2433));
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    V v_t_2435 = heff_strAppend(heff_strAppend(heff_dup(v_f_2431), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str16)), v_t_2434);
    return heff_strAppend(v_t_2435, ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str17));
  }
  case TAG_UToDouble: {
    V v_t_2438;
    switch (heff_tag_of(v_vs_241)) {
    case TAG_Nil: {
      v_t_2438 = ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str18);
      break;
    }
    case TAG_Cons: {
      V v_x_2436 = heff_field(v_vs_241, 0);
      v_t_2438 = heff_dup(v_x_2436);
      break;
    }
    default: heff_nomatch(v_vs_241);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str19), v_t_2438), ((V)&g_heff_2ecompile_2eemitc_2eunboxedC_str20));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2eunboxedC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2eunboxedC(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str0, 2, "a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str1, 4, "V a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str2, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str3, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str4, 2, "a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str5, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str6, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str7, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str8, 3, " a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str9, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str10, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str12, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str13, 2, "a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str14, 4, "V a_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str15, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str16, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str17, 2, "b_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str18, 4, "V b_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str19, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str20, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str21, 12, "heff_drop(b_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eargC_str22, 2, ");");
V g_heff_2ecompile_2eemitc_2eargC_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eargC_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eargC_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eargC_lam3(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eargC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eargC_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eargC(V v_k_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Given: {
    V v_e_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_m_244 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_243}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eargC_lam0, 1, 2, (V[]){v_m_244, v_i_241});
  }
  case TAG_GivenU: {
    V v_r_2414 = heff_field(v_x3_242, 0);
    V v_e_2415 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_2416 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_2415}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eargC_lam1, 1, 3, (V[]){v_m_2416, v_i_241, v_r_2414});
  }
  case TAG_LentVar: {
    V v_x_2428 = heff_field(v_x3_242, 0);
    V v_drops_2429 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    heff_drop_rec(v_k_240, 6);
    V v_t_2430 = ({ V a_0 = v_x_2428; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eargC_str11); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_2428); r_; });
    V v_v_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str12), v_t_2430);
    V v_post_2432 = (g_list_2emap_24s577269653x49010166(v_drops_2429));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eargC_lam2, 1, 3, (V[]){v_i_241, v_v_2431, v_post_2432});
  }
  case TAG_LentValue: {
    V v_e_2438 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    V v_m_2439 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_2438}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eargC_lam3, 1, 2, (V[]){v_m_2439, v_i_241});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2eargC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eargC(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eemitc_2eargC_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str0), heff_intShow(heff_dup(v_i_241)));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str1), heff_intShow(v_i_241));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2eargC_str2)), v_x_247);
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2eargC_str3)), NTAG(TAG_Nil)});
    V v_t_2413 = heff_rec_n(3, shape_arg__pre__post, (V[]){v_t_249, v_t_2412, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_s_248});
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eemitc_2eargC_lam1(V self, V *args) {
  V v_s_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_r_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str4), heff_intShow(heff_dup(v_i_241)));
    V v_t_2423;
    switch (heff_tag_of(v_r_2414)) {
    case TAG_RepV: {
      v_t_2423 = ((V)&g_heff_2ecompile_2eemitc_2eargC_str5);
      break;
    }
    case TAG_RepFix: {
      V v_w_2422 = heff_field(v_r_2414, 0);
      heff_take_n(v_r_2414, 1ULL, 1);
      v_t_2423 = ({ V a_0 = v_w_2422; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2422); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_2423 = ((V)&g_heff_2ecompile_2eemitc_2eargC_str6);
      break;
    }
    case TAG_RepInt: {
      v_t_2423 = ((V)&g_heff_2ecompile_2eemitc_2eargC_str7);
      break;
    }
    default: heff_nomatch(v_r_2414);
    }
    V v_t_2424 = heff_strAppend(heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2eemitc_2eargC_str8)), heff_intShow(v_i_241));
    V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2eargC_str9)), v_x_2419);
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2425, ((V)&g_heff_2ecompile_2eemitc_2eargC_str10)), NTAG(TAG_Nil)});
    V v_x_2427 = heff_rec_n(3, shape_arg__pre__post, (V[]){v_t_2421, v_t_2426, NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2eemitc_2eargC_lam2(V self, V *args) {
  V v_s_2433 = args[0];
  V v_i_241 = heff_env(self)[0];
  V v_v_2431 = heff_env(self)[1];
  V v_post_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str13), heff_intShow(heff_dup(v_i_241)));
  V v_t_2435 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str14), heff_intShow(v_i_241));
  V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2ecompile_2eemitc_2eargC_str15)), v_v_2431);
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2436, ((V)&g_heff_2ecompile_2eemitc_2eargC_str16)), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_rec_n(3, shape_arg__pre__post, (V[]){v_t_2434, v_t_2437, v_post_2432}), v_s_2433});
}
V g_heff_2ecompile_2eemitc_2eargC_lam3(V self, V *args) {
  V v_s_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_s_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_s_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    V v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str17), heff_intShow(heff_dup(v_i_241)));
    V v_t_2445 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str18), heff_intShow(heff_dup(v_i_241)));
    V v_t_2446 = heff_strAppend(heff_strAppend(v_t_2445, ((V)&g_heff_2ecompile_2eemitc_2eargC_str19)), v_x_2442);
    V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2446, ((V)&g_heff_2ecompile_2eemitc_2eargC_str20)), NTAG(TAG_Nil)});
    V v_t_2448 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eargC_str21), heff_intShow(v_i_241));
    V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eemitc_2eargC_str22)), NTAG(TAG_Nil)});
    return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(3, shape_arg__pre__post, (V[]){v_t_2444, v_t_2447, v_t_2449}), v_s_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str0, 4, "  V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str1, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str3, 8, " = args[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str4, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str5, 4, "  V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str6, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str8, 18, " = heff_env(self)[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str9, 2, "];");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str10, 22, "  heff_clo_take(self, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str11, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str12, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str13, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str14, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elamLines_24cpr_str15, 19, "(V self, V *args) {");

HeffT2 g_heff_2ecompile_2eemitc_2elamLines_24cpr(V v_k_240, V v_xs_241, V v_fv_242, V v_body_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_t_245 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_244, MK_INT(1LL))));
  V v_t_246 = (g_list_2ezipWith_24s1737719962x691725464(((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str0), ((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str1), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str2), ((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str3), ((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str4), v_xs_241, v_t_245));
  V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fv_242));
  V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(1LL))));
  V v_t_249 = (g_list_2ezipWith_24s1737719962x691725464(((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str5), ((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str6), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str7), ((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str8), ((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str9), heff_dup(v_fv_242), v_t_248));
  V v_t_2414;
  switch (heff_tag_of(v_fv_242)) {
  case TAG_Nil: {
    v_t_2414 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fv_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop_tag(v_fv_242, 2); r_; });
    V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str10), heff_intShow(v_t_2412));
    v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str11)), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_fv_242);
  }
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str12), NTAG(TAG_Nil)});
  V v_t_2416 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2415, ((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str13), v_body_243));
  V v_t_2417 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2416));
  V v_t_2418 = (g_prelude_2e_2b_2b(v_t_249, v_t_2417));
  V v_ys_2419 = (g_prelude_2e_2b_2b(v_t_246, v_t_2418));
  V v_f_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str14), v_k_240), ((V)&g_heff_2ecompile_2eemitc_2elamLines_24cpr_str15));
  return ((HeffT2){{v_f_2420, v_ys_2419}});
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2elentPrimC_str0, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elentPrimC_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elentPrimC_str2, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elentPrimC_str3, 6, "_lent(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elentPrimC_str4, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2elentPrimC_str5, 1, ")");
V g_heff_2ecompile_2eemitc_2elentPrimC_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2elentPrimC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2elentPrimC_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2elentPrimC(V v_k_240, V v_p_241, V v_suffix_242, V v_es_243) {
top: ;
  V v_t_244 = (g_list_2emap_24s1275294336x693095586(heff_dup(v_es_243), heff_dup(v_es_243)));
  V v_m_245 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_t_244));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2elentPrimC_lam0, 1, 4, (V[]){v_m_245, heff_dup(v_p_241), v_suffix_242, v_es_243});
}
V g_heff_2ecompile_2eemitc_2elentPrimC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2elentPrimC(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eemitc_2elentPrimC_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_suffix_242 = heff_env(self)[2];
  V v_es_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = ({ V a_0 = v_p_241; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_241); r_; });
    V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2elentPrimC_str0), v_t_2410), v_suffix_242);
    V v_t_2414;
    switch (heff_tag_of(v_x_248)) {
    case TAG_Nil: {
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2elentPrimC_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x_248, 0);
      V v_xs_2413 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      v_t_2414 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2elentPrimC_str2); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2elentPrimC_str3)), v_t_2414);
    V v_t_2416 = ({ V a_0 = v_es_243; V a_1 = v_es_243; V a_2 = MK_INT(1LL); V r_ = (g_heff_2ecompile_2eemitc_2egivenMask(a_0, a_1, a_2)); heff_drop(v_es_243); r_; });
    V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2ecompile_2eemitc_2elentPrimC_str4)), heff_intShow(v_t_2416));
    V v_x_2418 = heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2elentPrimC_str5));
    return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_2418, v_s_249});
  }
  default: return heff_nomatch(v_x2_247);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str1, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str3, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str4, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str7, 5, "((V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str8, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str9, 5, "_clo)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str11, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str12, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str13, 7, "_get())");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str15, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str16, 6, "_get()");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str17, 7, "MK_INT(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str18, 3, "LL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str19, 10, "HEFF_BIG(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str20, 2, "\")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str21, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str22, 13, "heff_flt(NAN)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str23, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str24, 18, "heff_flt(INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str25, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str26, 19, "heff_flt(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str27, 9, "heff_flt(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str28, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str29, 8, "HEFF_LIT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str30, 10, "HEFF_BYTES");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str31, 7, "MK_INT(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str32, 3, "LL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str33, 10, "HEFF_BIG(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str34, 2, "\")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str35, 7, "MK_INT(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str36, 3, "LL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str37, 16, "heff_f32((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str38, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str39, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str40, 5, "NTAG(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str41, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str42, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str43, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str44, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str45, 3, "){{");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str46, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str47, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str48, 3, "}})");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str49, 11, "heff_tag_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str50, 12, "heff_tag_nf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str51, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str52, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str53, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str54, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str55, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str56, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str57, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str58, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str59, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str60, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str61, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str62, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str63, 14, "heff_tag_at_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str64, 15, "heff_tag_at_nf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str65, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str66, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str67, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str68, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str69, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str70, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str71, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str72, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str73, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str74, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str75, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str76, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str77, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str78, 11, "heff_rec_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str79, 12, "heff_rec_nf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str80, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str81, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str82, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str83, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str84, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str85, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str86, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str87, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str88, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str89, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str90, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str91, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str92, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str93, 1, "u");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str94, 5, "V rv_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str95, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str96, 2, "; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str97, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str98, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str99, 3, "({ ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str100, 24, "V rr_ = heff_rec_reuse_n");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str101, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str102, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str103, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str104, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str105, 5, "ULL, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str106, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str107, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str108, 17, "heff_rfield(rr_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str109, 7, ") = rv_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str110, 2, "; ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str111, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str112, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str113, 3, "); ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str114, 7, "rr_; })");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str115, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str116, 12, "heff_rfield(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str117, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str118, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str119, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str120, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str121, 12, "heff_rget_v(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str122, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str123, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str124, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str125, 11, "heff_get_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str126, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str127, 11, "heff_rflat_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str128, 10, "heff_rget_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str129, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str130, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str131, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str132, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str133, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str134, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str135, 15, "heff_get_nflat_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str136, 11, "heff_get_n_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str137, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str138, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str139, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str140, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str141, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str142, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str143, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str144, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str145, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str146, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str147, 10, "heff_word_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str148, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str149, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str150, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str151, 16, "heff_take_field(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str152, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str153, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str154, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str155, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str156, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str157, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str158, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str159, 9, "heff_get(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str160, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str161, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str162, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str163, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str164, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str165, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str166, 8, "heff_tr(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str167, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str168, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str169, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str170, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str171, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str172, 2, "_w");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str173, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str174, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str175, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str176, 2, "))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str177, 18, "heff_tr(heff_call(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str178, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str179, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str180, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str181, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str182, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str183, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str184, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str185, 2, "))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str186, 10, "heff_bool(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str187, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str188, 14, "heff_abandon()");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str189, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str190, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str191, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str192, 9, "heff_box_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str193, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str194, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str195, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str196, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str197, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str198, 11, "heff_unbox_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str199, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str200, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str201, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str202, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str203, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str204, 10, "heff_peek_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str205, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str206, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str207, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str208, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str209, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str210, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str211, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str212, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str213, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str214, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str215, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str216, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str217, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str218, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str219, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str220, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str221, 2, ")-");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str222, 4, "ULL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str223, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str224, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str225, 4, "ULL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str226, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str227, 3, "NAN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str228, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str229, 8, "INFINITY");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str230, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str231, 11, "(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str232, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str233, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str234, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str235, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str236, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str237, 3, "NAN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str238, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str239, 8, "INFINITY");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str240, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str241, 11, "(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str242, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str243, 1, ")");
V g_heff_2ecompile_2eemitc_2eexpF_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam12(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam13(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam14(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam15(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam16(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam17(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam18(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam19(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam20(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam21(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam22(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam23(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam24(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam25(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam26(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam27(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2eexpF_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eexpF_lam27, 1, 0};
V g_heff_2ecompile_2eemitc_2eexpF_lam28(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam29(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam30(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam31(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam32(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam33(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam34(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam35(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eexpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eexpF_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eexpF(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_RLocal: {
    V v_x_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_243 = ({ V a_0 = v_x_242; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_242); r_; });
    V v_x_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str1), v_t_243);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam0, 1, 1, (V[]){v_x_244});
  }
  case TAG_RDup: {
    V v_x_246 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_247 = ({ V a_0 = v_x_246; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str2); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_246); r_; });
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str3), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str4), v_t_247));
    V v_x_249 = heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str5));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam1, 1, 1, (V[]){v_x_249});
  }
  case TAG_RClo: {
    V v_g_2411 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2412 = ({ V a_0 = v_g_2411; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str6); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_2411); r_; });
    V v_t_2413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str7), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str8), v_t_2412));
    V v_x_2414 = heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str9));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam2, 1, 1, (V[]){v_x_2414});
  }
  case TAG_RGet: {
    V v_g_2416 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2417 = ({ V a_0 = v_g_2416; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str10); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_2416); r_; });
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str11), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str12), v_t_2417));
    V v_x_2419 = heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str13));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam3, 1, 1, (V[]){v_x_2419});
  }
  case TAG_RGetRaw: {
    V v_g_2421 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2422 = ({ V a_0 = v_g_2421; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str14); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_2421); r_; });
    V v_x_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str15), v_t_2422), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str16));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam4, 1, 1, (V[]){v_x_2423});
  }
  case TAG_RInt: {
    V v_n_2425 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam5, 1, 1, (V[]){v_n_2425});
  }
  case TAG_RFloat: {
    V v_x_2430 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam6, 1, 1, (V[]){v_x_2430});
  }
  case TAG_RStr: {
    V v_s_2434 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2estrLit_clo), 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eexpF_str29), v_s_2434});
  }
  case TAG_RBytes: {
    V v_s_2435 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2estrLit_clo), 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eexpF_str30), v_s_2435});
  }
  case TAG_RFixed: {
    V v_w_2436 = heff_field(v_x2_241, 0);
    V v_n_2437 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_k_240, 6);
    V v_w_2438 = v_w_2436;
    V v_n_2439 = v_n_2437;
    int64_t v_t_2440;
    switch (heff_tag_of(v_w_2438)) {
    case TAG_I8: {
      v_t_2440 = ((int64_t)8ULL);
      break;
    }
    case TAG_I16: {
      v_t_2440 = ((int64_t)16ULL);
      break;
    }
    case TAG_I32: {
      v_t_2440 = ((int64_t)32ULL);
      break;
    }
    case TAG_I64: {
      v_t_2440 = ((int64_t)64ULL);
      break;
    }
    case TAG_U8: {
      v_t_2440 = ((int64_t)8ULL);
      break;
    }
    case TAG_U16: {
      v_t_2440 = ((int64_t)16ULL);
      break;
    }
    case TAG_U32: {
      v_t_2440 = ((int64_t)32ULL);
      break;
    }
    case TAG_U64: {
      v_t_2440 = ((int64_t)64ULL);
      break;
    }
    case TAG_F32: {
      v_t_2440 = ((int64_t)32ULL);
      break;
    }
    default: heff_nomatch(v_w_2438);
    }
    V v_x_2444;
    if ((v_t_2440 == ((int64_t)64ULL))) {
      if ((heff_intLt_c_lent(v_n_2439, HEFF_BIG("4611686018427387904"), 2) && heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_n_2439, 1))) {
        V v_t_2441 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str31), heff_intShow(v_n_2439));
        v_x_2444 = heff_strAppend(v_t_2441, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str32));
      } else {
        V v_t_2442 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str33), heff_intShow(v_n_2439));
        v_x_2444 = heff_strAppend(v_t_2442, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str34));
      }
    } else {
      V v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str35), heff_intShow(v_n_2439));
      v_x_2444 = heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str36));
    }
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam7, 1, 1, (V[]){v_x_2444});
  }
  case TAG_RF32: {
    V v_x_2446 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam8, 1, 1, (V[]){v_x_2446});
  }
  case TAG_RNTag: {
    V v_t_2449 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2450 = ({ V a_0 = v_t_2449; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str39); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2449); r_; });
    V v_t_2451 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str40), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str41), v_t_2450));
    V v_x_2452 = heff_strAppend(v_t_2451, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str42));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam9, 1, 1, (V[]){v_x_2452});
  }
  case TAG_RTag: {
    V v_t_2454 = heff_field(v_x2_241, 0);
    V v_flat_2455 = heff_field(v_x2_241, 1);
    V v_es_2456 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2457 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), heff_dup(v_es_2456)));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam10, 1, 4, (V[]){v_m_2457, v_t_2454, v_es_2456, v_flat_2455});
  }
  case TAG_RTagIn: {
    V v_ru_2483 = heff_field(v_x2_241, 0);
    V v_t_2484 = heff_field(v_x2_241, 1);
    V v_flat_2485 = heff_field(v_x2_241, 2);
    V v_es_2486 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_f_2487 = heff_get_n(v_k_240, 0, 6);
    V v_m_2488 = heff_tr(heff_call(heff_dup(v_f_2487), 1, (V[]){v_ru_2483}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam11, 1, 5, (V[]){v_m_2488, v_f_2487, v_es_2486, v_flat_2485, v_t_2484});
  }
  case TAG_RRec: {
    V v_ls_24117 = heff_field(v_x2_241, 0);
    V v_flat_24118 = heff_field(v_x2_241, 1);
    V v_es_24119 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24120 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24119));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam12, 1, 3, (V[]){v_m_24120, v_ls_24117, v_flat_24118});
  }
  case TAG_RRecIn: {
    V v_x_24144 = heff_field(v_x2_241, 0);
    V v_keep_24145 = heff_field(v_x2_241, 1);
    V v_kept_24146 = heff_field(v_x2_241, 2);
    V v_flat_24147 = heff_field(v_x2_241, 3);
    V v_n_24148 = heff_field(v_x2_241, 4);
    V v_ls_24149 = heff_field(v_x2_241, 5);
    V v_changed_24150 = heff_field(v_x2_241, 6);
    V v_su_24151 = heff_field(v_x2_241, 7);
    heff_take_n(v_x2_241, 255ULL, 8);
    V v_t_24152 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_changed_24150)));
    V v_m_24153 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_t_24152));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam13, 1, 9, (V[]){v_m_24153, v_ls_24149, v_su_24151, v_x_24144, v_keep_24145, v_kept_24146, v_flat_24147, v_n_24148, v_changed_24150});
  }
  case TAG_RField: {
    V v_e_24191 = heff_field(v_x2_241, 0);
    V v_i_24192 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24193 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24191}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam14, 1, 2, (V[]){v_m_24193, v_i_24192});
  }
  case TAG_RDupE: {
    V v_e_24200 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_24201 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24200}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam15, 1, 1, (V[]){v_m_24201});
  }
  case TAG_RFieldV: {
    V v_e_24207 = heff_field(v_x2_241, 0);
    V v_i_24208 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24209 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24207}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam16, 1, 2, (V[]){v_m_24209, v_i_24208});
  }
  case TAG_RGetN: {
    V v_e_24216 = heff_field(v_x2_241, 0);
    V v_i_24217 = heff_field(v_x2_241, 1);
    V v_n_24218 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24219 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24216}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam17, 1, 3, (V[]){v_m_24219, v_i_24217, v_n_24218});
  }
  case TAG_RFieldU: {
    V v_r_24227 = heff_field(v_x2_241, 0);
    V v_su_24228 = heff_field(v_x2_241, 1);
    V v_e_24229 = heff_field(v_x2_241, 2);
    V v_i_24230 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_24231;
    if ((heff_dup(v_su_24228) == NTAG(TAG_True))) {
      heff_drop(v_su_24228);
      v_t_24231 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str127);
    } else {
      heff_drop(v_su_24228);
      v_t_24231 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str128);
    }
    V v_t_24233;
    switch (heff_tag_of(v_r_24227)) {
    case TAG_RepV: {
      v_t_24233 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str129);
      break;
    }
    case TAG_RepFix: {
      V v_w_24232 = heff_field(v_r_24227, 0);
      heff_take_n(v_r_24227, 1ULL, 1);
      v_t_24233 = ({ V a_0 = v_w_24232; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24232); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24233 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str130);
      break;
    }
    case TAG_RepInt: {
      v_t_24233 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str131);
      break;
    }
    default: heff_nomatch(v_r_24227);
    }
    V v_pre_24234 = heff_strAppend(heff_strAppend(v_t_24231, v_t_24233), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str132));
    V v_m_24235 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24229}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam18, 1, 3, (V[]){v_m_24235, v_i_24230, v_pre_24234});
  }
  case TAG_RGetNU: {
    V v_r_24242 = heff_field(v_x2_241, 0);
    V v_su_24243 = heff_field(v_x2_241, 1);
    V v_e_24244 = heff_field(v_x2_241, 2);
    V v_i_24245 = heff_field(v_x2_241, 3);
    V v_n_24246 = heff_field(v_x2_241, 4);
    heff_take_n(v_x2_241, 31ULL, 5);
    V v_t_24247;
    if ((heff_dup(v_su_24243) == NTAG(TAG_True))) {
      heff_drop(v_su_24243);
      v_t_24247 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str135);
    } else {
      heff_drop(v_su_24243);
      v_t_24247 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str136);
    }
    V v_t_24249;
    switch (heff_tag_of(v_r_24242)) {
    case TAG_RepV: {
      v_t_24249 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str137);
      break;
    }
    case TAG_RepFix: {
      V v_w_24248 = heff_field(v_r_24242, 0);
      heff_take_n(v_r_24242, 1ULL, 1);
      v_t_24249 = ({ V a_0 = v_w_24248; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24248); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24249 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str138);
      break;
    }
    case TAG_RepInt: {
      v_t_24249 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str139);
      break;
    }
    default: heff_nomatch(v_r_24242);
    }
    V v_pre_24250 = heff_strAppend(heff_strAppend(v_t_24247, v_t_24249), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str140));
    V v_m_24251 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24244}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam19, 1, 4, (V[]){v_m_24251, v_i_24245, v_n_24246, v_pre_24250});
  }
  case TAG_RWord: {
    V v_r_24259 = heff_field(v_x2_241, 0);
    V v_e_24260 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24262;
    switch (heff_tag_of(v_r_24259)) {
    case TAG_RepV: {
      v_t_24262 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str144);
      break;
    }
    case TAG_RepFix: {
      V v_w_24261 = heff_field(v_r_24259, 0);
      heff_take_n(v_r_24259, 1ULL, 1);
      v_t_24262 = ({ V a_0 = v_w_24261; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24261); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24262 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str145);
      break;
    }
    case TAG_RepInt: {
      v_t_24262 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str146);
      break;
    }
    default: heff_nomatch(v_r_24259);
    }
    V v_pre_24263 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str147), v_t_24262), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str148));
    V v_m_24264 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24260}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam20, 1, 2, (V[]){v_m_24264, v_pre_24263});
  }
  case TAG_RTakeField: {
    V v_x_24270 = heff_field(v_x2_241, 0);
    V v_i_24271 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_k_240, 6);
    V v_t_24272 = ({ V a_0 = v_x_24270; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str150); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_24270); r_; });
    V v_t_24273 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str151), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str152), v_t_24272));
    V v_t_24274 = heff_strAppend(heff_strAppend(v_t_24273, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str153)), heff_intShow(v_i_24271));
    V v_x_24275 = heff_strAppend(v_t_24274, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str154));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam21, 1, 1, (V[]){v_x_24275});
  }
  case TAG_RGetLabel: {
    V v_e_24277 = heff_field(v_x2_241, 0);
    V v_l_24278 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24279 = ({ V a_0 = v_l_24278; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str155); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_l_24278); r_; });
    V v_t_24280 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str156), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str157), v_t_24279));
    V v_post_24281 = heff_strAppend(v_t_24280, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str158));
    V v_m_24282 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24277}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam22, 1, 2, (V[]){v_m_24282, v_post_24281});
  }
  case TAG_RPrimFn: {
    V v_p_24288 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2eprimLit_clo), 1, (V[]){v_p_24288});
  }
  case TAG_RPrim: {
    V v_p_24289 = heff_field(v_x2_241, 0);
    V v_es_24290 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24291 = (g_heff_2ecompile_2eowned_2elendingPrim(v_p_24289));
    V v_t_24293;
    if ((heff_dup(v_t_24291) == NTAG(TAG_True))) {
      heff_drop(v_t_24291);
      V v_t_24292 = (g_list_2eall_24s1465078656x604124530(v_es_24290));
      if ((heff_dup(v_t_24292) == NTAG(TAG_True))) {
        heff_drop(v_t_24292);
        v_t_24293 = (g_list_2eany_24s63755471x810534073(v_es_24290, v_es_24290));
      } else {
        heff_drop(v_t_24292);
        v_t_24293 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_t_24291);
      v_t_24293 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24293) == NTAG(TAG_True))) {
      heff_drop(v_t_24293);
      return ({ V a_0 = v_k_240; V a_1 = v_p_24289; V a_2 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str160); V a_3 = v_es_24290; V r_ = (g_heff_2ecompile_2eemitc_2elentPrimC(a_0, a_1, a_2, a_3)); heff_drop(v_p_24289); r_; });
    } else {
      heff_drop(v_t_24293);
      V v_m_24294 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24290));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam23, 1, 2, (V[]){v_m_24294, v_p_24289});
    }
  }
  case TAG_RLam: {
    V v_xs_24305 = heff_field(v_x2_241, 0);
    V v_fv_24306 = heff_field(v_x2_241, 1);
    V v_held_24307 = heff_field(v_x2_241, 2);
    V v_x24_24308 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    switch (heff_tag_of(v_x24_24308)) {
    case TAG_MkCode: {
      V v_body_24309 = heff_field(v_x24_24308, 0);
      heff_take_n(v_x24_24308, 1ULL, 1);
      return heff_tail(((V)&g_heff_2ecompile_2eemitc_2elamC_clo), 5, (V[]){v_k_240, v_xs_24305, v_fv_24306, v_held_24307, v_body_24309});
    }
    default: return heff_nomatch(v_x24_24308);
    }
  }
  case TAG_RCall: {
    V v_g_24310 = heff_field(v_x2_241, 0);
    V v_tr_24311 = heff_field(v_x2_241, 1);
    V v_w_24312 = heff_field(v_x2_241, 2);
    V v_args_24313 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_k_24314 = v_k_240;
    V v_g_24315 = v_g_24310;
    V v_tr_24316 = v_tr_24311;
    V v_w_24317 = v_w_24312;
    V v_args_24318 = v_args_24313;
    V v_t_24319 = (g_list_2eall_24s1793250635x935291087(v_args_24318));
    if ((heff_dup(v_t_24319) == NTAG(TAG_True))) {
      heff_drop(v_t_24319);
      V v_t_24320 = (g_list_2emap_24s976303750x321235480(v_args_24318));
      V v_m_24321 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_24314, 0, 6), v_t_24320));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam24, 1, 4, (V[]){v_m_24321, v_tr_24316, v_w_24317, v_g_24315});
    } else {
      heff_drop(v_t_24319);
      return ({ V a_0 = v_k_24314; V a_1 = v_g_24315; V a_2 = v_tr_24316; V a_3 = v_w_24317; V a_4 = v_args_24318; V r_ = (g_heff_2ecompile_2eemitc_2ecallLent(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_g_24315); heff_drop(v_tr_24316); heff_drop(v_w_24317); r_; });
    }
  }
  case TAG_RApply: {
    V v_f_24336 = heff_field(v_x2_241, 0);
    V v_es_24337 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_f_24338 = heff_get_n(v_k_240, 0, 6);
    V v_m_24339 = heff_tr(heff_call(heff_dup(v_f_24338), 1, (V[]){v_f_24336}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam25, 1, 3, (V[]){v_m_24339, v_f_24338, v_es_24337});
  }
  case TAG_RBool: {
    V v_c_24363 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_24364 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_c_24363));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam26, 1, 1, (V[]){v_m_24364});
  }
  case TAG_RAbandon: {
    heff_drop_rec(v_k_240, 6);
    return ((V)&g_heff_2ecompile_2eemitc_2eexpF_lam27_clo);
  }
  case TAG_RBox: {
    V v_r_24371 = heff_field(v_x2_241, 0);
    V v_e_24372 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24374;
    switch (heff_tag_of(v_r_24371)) {
    case TAG_RepV: {
      v_t_24374 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str189);
      break;
    }
    case TAG_RepFix: {
      V v_w_24373 = heff_field(v_r_24371, 0);
      heff_take_n(v_r_24371, 1ULL, 1);
      v_t_24374 = ({ V a_0 = v_w_24373; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24373); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24374 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str190);
      break;
    }
    case TAG_RepInt: {
      v_t_24374 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str191);
      break;
    }
    default: heff_nomatch(v_r_24371);
    }
    V v_pre_24375 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str192), v_t_24374), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str193));
    V v_m_24376 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24372}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam28, 1, 2, (V[]){v_m_24376, v_pre_24375});
  }
  case TAG_RUnbox: {
    V v_r_24382 = heff_field(v_x2_241, 0);
    V v_e_24383 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24385;
    switch (heff_tag_of(v_r_24382)) {
    case TAG_RepV: {
      v_t_24385 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str195);
      break;
    }
    case TAG_RepFix: {
      V v_w_24384 = heff_field(v_r_24382, 0);
      heff_take_n(v_r_24382, 1ULL, 1);
      v_t_24385 = ({ V a_0 = v_w_24384; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24384); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24385 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str196);
      break;
    }
    case TAG_RepInt: {
      v_t_24385 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str197);
      break;
    }
    default: heff_nomatch(v_r_24382);
    }
    V v_pre_24386 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str198), v_t_24385), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str199));
    V v_m_24387 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24383}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam29, 1, 2, (V[]){v_m_24387, v_pre_24386});
  }
  case TAG_RPeek: {
    V v_r_24393 = heff_field(v_x2_241, 0);
    V v_e_24394 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24396;
    switch (heff_tag_of(v_r_24393)) {
    case TAG_RepV: {
      v_t_24396 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str201);
      break;
    }
    case TAG_RepFix: {
      V v_w_24395 = heff_field(v_r_24393, 0);
      heff_take_n(v_r_24393, 1ULL, 1);
      v_t_24396 = ({ V a_0 = v_w_24395; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24395); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24396 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str202);
      break;
    }
    case TAG_RepInt: {
      v_t_24396 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str203);
      break;
    }
    default: heff_nomatch(v_r_24393);
    }
    V v_pre_24397 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str204), v_t_24396), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str205));
    V v_m_24398 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24394}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam30, 1, 2, (V[]){v_m_24398, v_pre_24397});
  }
  case TAG_RPrimU: {
    V v_p_24404 = heff_field(v_x2_241, 0);
    V v_es_24405 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24406 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24405));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam31, 1, 2, (V[]){v_m_24406, v_p_24404});
  }
  case TAG_RPrimAt: {
    V v_p_24413 = heff_field(v_x2_241, 0);
    V v_r_24414 = heff_field(v_x2_241, 1);
    V v_es_24415 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_24416 = (g_heff_2ecompile_2eowned_2elendingPrim(v_p_24413));
    V v_t_24418;
    if ((heff_dup(v_t_24416) == NTAG(TAG_True))) {
      heff_drop(v_t_24416);
      V v_t_24417 = (g_list_2eall_24s1465078656x604124530(v_es_24415));
      if ((heff_dup(v_t_24417) == NTAG(TAG_True))) {
        heff_drop(v_t_24417);
        v_t_24418 = (g_list_2eany_24s63755471x810534073(v_es_24415, v_es_24415));
      } else {
        heff_drop(v_t_24417);
        v_t_24418 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_t_24416);
      v_t_24418 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24418) == NTAG(TAG_True))) {
      heff_drop(v_t_24418);
      V v_t_24420;
      switch (heff_tag_of(v_r_24414)) {
      case TAG_RepV: {
        v_t_24420 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str207);
        break;
      }
      case TAG_RepFix: {
        V v_w_24419 = heff_field(v_r_24414, 0);
        heff_take_n(v_r_24414, 1ULL, 1);
        v_t_24420 = ({ V a_0 = v_w_24419; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24419); r_; });
        break;
      }
      case TAG_RepF64: {
        v_t_24420 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str208);
        break;
      }
      case TAG_RepInt: {
        v_t_24420 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str209);
        break;
      }
      default: heff_nomatch(v_r_24414);
      }
      return ({ V a_0 = v_k_240; V a_1 = v_p_24413; V a_2 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str210), v_t_24420); V a_3 = v_es_24415; V r_ = (g_heff_2ecompile_2eemitc_2elentPrimC(a_0, a_1, a_2, a_3)); heff_drop(v_p_24413); r_; });
    } else {
      heff_drop(v_t_24418);
      V v_m_24421 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24415));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam32, 1, 3, (V[]){v_m_24421, v_p_24413, v_r_24414});
    }
  }
  case TAG_RFixU: {
    V v_w_24435 = heff_field(v_x2_241, 0);
    V v_n_24436 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_k_240, 6);
    V v_w_24437 = v_w_24435;
    V v_n_24438 = v_n_24436;
    V v_x_24445;
    if (heff_intLt_c_lent(v_n_24438, MK_INT(0LL), 2)) {
      V v_t_24439 = ({ V a_0 = v_w_24437; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_24437); r_; });
      V v_t_24440 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str220), v_t_24439), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str221));
      V v_t_24441 = heff_intShow(heff_intSub(MK_INT(0LL), v_n_24438));
      v_x_24445 = heff_strAppend(heff_strAppend(v_t_24440, v_t_24441), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str222));
    } else {
      V v_t_24442 = ({ V a_0 = v_w_24437; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_24437); r_; });
      V v_t_24443 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str223), v_t_24442), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str224));
      V v_t_24444 = heff_strAppend(v_t_24443, heff_intShow(v_n_24438));
      v_x_24445 = heff_strAppend(v_t_24444, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str225));
    }
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam33, 1, 1, (V[]){v_x_24445});
  }
  case TAG_RF32U: {
    V v_x_24447 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam34, 1, 1, (V[]){v_x_24447});
  }
  case TAG_RF64U: {
    V v_x_24452 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam35, 1, 1, (V[]){v_x_24452});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eexpF(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2eexpF_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_244, v_s_245});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_2410});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam2(V self, V *args) {
  V v_s_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2414, v_s_2415});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam3(V self, V *args) {
  V v_s_2420 = args[0];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_s_2420});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2423, v_s_2424});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam5(V self, V *args) {
  V v_s_2426 = args[0];
  V v_n_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429;
  if ((heff_intLt_c_lent(v_n_2425, HEFF_BIG("4611686018427387904"), 2) && heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_n_2425, 1))) {
    V v_t_2427 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str17), heff_intShow(v_n_2425));
    v_t_2429 = heff_strAppend(v_t_2427, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str18));
  } else {
    V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str19), heff_intShow(v_n_2425));
    v_t_2429 = heff_strAppend(v_t_2428, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str20));
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2429, v_s_2426});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam6(V self, V *args) {
  V v_s_2431 = args[0];
  V v_x_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433;
  if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2430)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str21))) {
    heff_drop(v_x_2430);
    v_t_2433 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str22);
  } else {
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2430)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str23))) {
      heff_drop(v_x_2430);
      v_t_2433 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str24);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2430)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str25))) {
        heff_drop(v_x_2430);
        v_t_2433 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str26);
      } else {
        V v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str27), heff_floatShow(v_x_2430));
        v_t_2433 = heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str28));
      }
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, v_s_2431});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam7(V self, V *args) {
  V v_s_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2444, v_s_2445});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam8(V self, V *args) {
  V v_s_2447 = args[0];
  V v_x_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str37), heff_floatShow(v_x_2446));
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(v_t_2448, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str38)), v_s_2447});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam9(V self, V *args) {
  V v_s_2453 = args[0];
  V v_x_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2452, v_s_2453});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam10(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_t_2454 = heff_env(self)[1];
  V v_es_2456 = heff_env(self)[2];
  V v_flat_2455 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    V v_x_2482;
    if (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2454, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_t_2454, MK_INT(0LL), 2)) == ((int64_t)35ULL)))) {
      heff_drop(v_t_2454);
      heff_drop(v_flat_2455);
      V v_n_2462 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2456; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2456); r_; });
      V v_t_2463 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str43), heff_intShow(v_n_2462));
      V v_t_2464 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str44), v_t_2463), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str45));
      V v_t_2467;
      switch (heff_tag_of(v_x_2460)) {
      case TAG_Nil: {
        v_t_2467 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str46);
        break;
      }
      case TAG_Cons: {
        V v_x_2465 = heff_field(v_x_2460, 0);
        V v_xs_2466 = heff_field(v_x_2460, 1);
        heff_take_n(v_x_2460, 3ULL, 2);
        v_t_2467 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str47); V a_1 = v_x_2465; V a_2 = v_xs_2466; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2466); r_; });
        break;
      }
      default: heff_nomatch(v_x_2460);
      }
      v_x_2482 = heff_strAppend(heff_strAppend(v_t_2464, v_t_2467), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str48));
    } else {
      V v_t_2468;
      if (heff_intEq_c_lent(v_flat_2455, MK_INT(0LL), 2)) {
        v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str49);
      } else {
        v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str50);
      }
      V v_t_2469 = ({ V a_0 = v_t_2454; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str51); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2454); r_; });
      V v_t_2470 = heff_strAppend(v_t_2468, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str52), v_t_2469));
      V v_t_2471 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2456; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2456); r_; });
      V v_t_2472 = heff_strAppend(heff_strAppend(v_t_2470, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str53)), heff_intShow(v_t_2471));
      V v_t_2474;
      if (heff_intEq_c_lent(v_flat_2455, MK_INT(0LL), 2)) {
        heff_drop(v_flat_2455);
        v_t_2474 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str54);
      } else {
        V v_t_2473 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str55), heff_intShow(v_flat_2455));
        v_t_2474 = heff_strAppend(v_t_2473, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str56));
      }
      V v_t_2480;
      switch (heff_tag_of(v_x_2460)) {
      case TAG_Nil: {
        v_t_2480 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str57);
        break;
      }
      case TAG_Cons: {
        V v_t_2479;
        switch (heff_tag_of(v_x_2460)) {
        case TAG_Nil: {
          v_t_2479 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str58);
          break;
        }
        case TAG_Cons: {
          V v_x_2477 = heff_field(v_x_2460, 0);
          V v_xs_2478 = heff_field(v_x_2460, 1);
          heff_take_n(v_x_2460, 3ULL, 2);
          v_t_2479 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str59); V a_1 = v_x_2477; V a_2 = v_xs_2478; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2478); r_; });
          break;
        }
        default: heff_nomatch(v_x_2460);
        }
        v_t_2480 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str60), v_t_2479), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str61));
        break;
      }
      default: heff_nomatch(v_x_2460);
      }
      V v_t_2481 = heff_strAppend(heff_strAppend(v_t_2472, v_t_2474), v_t_2480);
      v_x_2482 = heff_strAppend(v_t_2481, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str62));
    }
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){v_x_2482, v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam11(V self, V *args) {
  V v_s_2489 = args[0];
  V v_m_2488 = heff_env(self)[0];
  V v_f_2487 = heff_env(self)[1];
  V v_es_2486 = heff_env(self)[2];
  V v_flat_2485 = heff_env(self)[3];
  V v_t_2484 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2490 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_s_2489}));
  switch (heff_tag_of(v_x2_2490)) {
  case TAG_MkPair: {
    V v_x_2491 = heff_field(v_x2_2490, 0);
    V v_s_2492 = heff_field(v_x2_2490, 1);
    V v_ru_24x2_2490_24MkPair = heff_take_reuse_n(v_x2_2490, 3ULL, 2);
    V v_m_2493 = (g_prelude_2etraverse_24s1362847681x1386678580(v_f_2487, heff_dup(v_es_2486)));
    V v_x2_2494 = heff_tr(heff_call(v_m_2493, 1, (V[]){v_s_2492}));
    switch (heff_tag_of(v_x2_2494)) {
    case TAG_MkPair: {
      V v_x_2495 = heff_field(v_x2_2494, 0);
      V v_s_2496 = heff_field(v_x2_2494, 1);
      V v_ru_24x2_2494_24MkPair = heff_take_reuse_n(v_x2_2494, 3ULL, 2);
      V v_t_2497;
      if (heff_intEq_c_lent(v_flat_2485, MK_INT(0LL), 2)) {
        v_t_2497 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str63);
      } else {
        v_t_2497 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str64);
      }
      V v_t_2498 = heff_strAppend(heff_strAppend(v_t_2497, heff_dup(v_x_2491)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str65));
      V v_t_2499 = ({ V a_0 = v_t_2484; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str66); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2484); r_; });
      V v_t_24100 = heff_strAppend(v_t_2498, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str67), v_t_2499));
      V v_t_24101 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2486; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2486); r_; });
      V v_t_24102 = heff_strAppend(heff_strAppend(v_t_24100, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str68)), heff_intShow(v_t_24101));
      V v_t_24104;
      if (heff_intEq_c_lent(v_flat_2485, MK_INT(0LL), 2)) {
        heff_drop(v_flat_2485);
        v_t_24104 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str69);
      } else {
        V v_t_24103 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str70), heff_intShow(v_flat_2485));
        v_t_24104 = heff_strAppend(v_t_24103, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str71));
      }
      HeffT3 v_t_24105 = ({ V a_0 = MK_INT(1LL); V b_1 = heff_tag_at_n(v_ru_24x2_2494_24MkPair, TAG_Cons, 2, (V[]){v_x_2491, v_x_2495}); HeffT3 r_ = (g_list_2edrop_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_24114;
      {
        V v_field_24107 = v_t_24105.f[1];
        V v_field_24108 = v_t_24105.f[2];
        int64_t v_tag_24106 = ((int64_t)v_t_24105.f[0]);
        if ((v_tag_24106 == ((int64_t)0ULL))) {
          V v_x11_24109 = heff_dup(v_field_24107);
          heff_drop(v_x11_24109);
          V v_x12_24110 = heff_dup(v_field_24108);
          heff_drop(v_x12_24110);
          V v_t_24113;
          if ((v_tag_24106 == ((int64_t)0ULL))) {
            V v_x_24111 = v_field_24107;
            V v_xs_24112 = v_field_24108;
            v_t_24113 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str72); V a_1 = v_x_24111; V a_2 = v_xs_24112; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24112); r_; });
          } else {
            heff_drop(v_field_24107);
            heff_drop(v_field_24108);
            v_t_24113 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str73);
          }
          v_t_24114 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str74), v_t_24113), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str75));
        } else {
          heff_drop(v_field_24107);
          heff_drop(v_field_24108);
          v_t_24114 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str76);
        }
      }
      V v_t_24115 = heff_strAppend(heff_strAppend(v_t_24102, v_t_24104), v_t_24114);
      V v_x_24116 = heff_strAppend(v_t_24115, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str77));
      return heff_tag_at_n(v_ru_24x2_2490_24MkPair, TAG_MkPair, 2, (V[]){v_x_24116, v_s_2496});
    }
    default: return heff_nomatch(v_x2_2494);
    }
  }
  default: return heff_nomatch(v_x2_2490);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam12(V self, V *args) {
  V v_s_24121 = args[0];
  V v_m_24120 = heff_env(self)[0];
  V v_ls_24117 = heff_env(self)[1];
  V v_flat_24118 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24122 = heff_tr(heff_call(v_m_24120, 1, (V[]){v_s_24121}));
  switch (heff_tag_of(v_x2_24122)) {
  case TAG_MkPair: {
    V v_x_24123 = heff_field(v_x2_24122, 0);
    V v_s_24124 = heff_field(v_x2_24122, 1);
    V v_ru_24x2_24122_24MkPair = heff_take_reuse_n(v_x2_24122, 3ULL, 2);
    HeffT2 v_t_24125 = (g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(heff_dup(v_ls_24117), v_s_24124));
    {
      V v_field_24126 = v_t_24125.f[0];
      V v_field_24127 = v_t_24125.f[1];
      V v_x_24128 = v_field_24126;
      V v_s_24129 = v_field_24127;
      V v_t_24130;
      if (heff_intEq_c_lent(v_flat_24118, MK_INT(0LL), 2)) {
        v_t_24130 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str78);
      } else {
        v_t_24130 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str79);
      }
      V v_t_24131 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ls_24117; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ls_24117); r_; });
      V v_t_24132 = heff_strAppend(v_t_24130, heff_intShow(v_t_24131));
      V v_t_24133 = heff_strAppend(heff_strAppend(v_t_24132, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str80)), v_x_24128);
      V v_t_24135;
      if (heff_intEq_c_lent(v_flat_24118, MK_INT(0LL), 2)) {
        heff_drop(v_flat_24118);
        v_t_24135 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str81);
      } else {
        V v_t_24134 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str82), heff_intShow(v_flat_24118));
        v_t_24135 = heff_strAppend(v_t_24134, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str83));
      }
      V v_t_24141;
      switch (heff_tag_of(v_x_24123)) {
      case TAG_Nil: {
        v_t_24141 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str84);
        break;
      }
      case TAG_Cons: {
        V v_t_24140;
        switch (heff_tag_of(v_x_24123)) {
        case TAG_Nil: {
          v_t_24140 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str85);
          break;
        }
        case TAG_Cons: {
          V v_x_24138 = heff_field(v_x_24123, 0);
          V v_xs_24139 = heff_field(v_x_24123, 1);
          heff_take_n(v_x_24123, 3ULL, 2);
          v_t_24140 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str86); V a_1 = v_x_24138; V a_2 = v_xs_24139; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24139); r_; });
          break;
        }
        default: heff_nomatch(v_x_24123);
        }
        v_t_24141 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str87), v_t_24140), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str88));
        break;
      }
      default: heff_nomatch(v_x_24123);
      }
      V v_t_24142 = heff_strAppend(heff_strAppend(v_t_24133, v_t_24135), v_t_24141);
      V v_x_24143 = heff_strAppend(v_t_24142, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str89));
      return heff_tag_at_n(v_ru_24x2_24122_24MkPair, TAG_MkPair, 2, (V[]){v_x_24143, v_s_24129});
    }
  }
  default: return heff_nomatch(v_x2_24122);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam13(V self, V *args) {
  V v_s_24154 = args[0];
  V v_m_24153 = heff_env(self)[0];
  V v_ls_24149 = heff_env(self)[1];
  V v_su_24151 = heff_env(self)[2];
  V v_x_24144 = heff_env(self)[3];
  V v_keep_24145 = heff_env(self)[4];
  V v_kept_24146 = heff_env(self)[5];
  V v_flat_24147 = heff_env(self)[6];
  V v_n_24148 = heff_env(self)[7];
  V v_changed_24150 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x2_24155 = heff_tr(heff_call(v_m_24153, 1, (V[]){v_s_24154}));
  switch (heff_tag_of(v_x2_24155)) {
  case TAG_MkPair: {
    V v_x_24156 = heff_field(v_x2_24155, 0);
    V v_s_24157 = heff_field(v_x2_24155, 1);
    V v_ru_24x2_24155_24MkPair = heff_take_reuse_n(v_x2_24155, 3ULL, 2);
    HeffT2 v_t_24158 = (g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(v_ls_24149, v_s_24157));
    {
      V v_field_24159 = v_t_24158.f[0];
      V v_field_24160 = v_t_24158.f[1];
      V v_x_24161 = v_field_24159;
      V v_s_24162 = v_field_24160;
      V v_suffix_24163;
      if ((heff_dup(v_su_24151) == NTAG(TAG_True))) {
        heff_drop(v_su_24151);
        v_suffix_24163 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str90);
      } else {
        heff_drop(v_su_24151);
        v_suffix_24163 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str91);
      }
      V v_x_24164 = v_x_24144;
      V v_shape_24165 = v_x_24161;
      V v_keep_24166 = v_keep_24145;
      V v_t_24167 = heff_strAppend(heff_intShow(v_kept_24146), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str92));
      V v_t_24168 = heff_strAppend(v_t_24167, heff_intShow(v_flat_24147));
      V v_flats_24169 = heff_strAppend(v_t_24168, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str93));
      V v_n_24170 = v_n_24148;
      V v_vs_24171 = v_x_24156;
      V v_changed_24172 = (g_list_2emap_24s1937570095x2110149801(v_changed_24150));
      V v_x2_24173 = (g_list_2ezipWith_24s952564628x174753269(((V)&g_heff_2ecompile_2eemitc_2eexpF_str94), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str95), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str96), v_vs_24171, heff_dup(v_changed_24172)));
      V v_t_24176;
      switch (heff_tag_of(v_x2_24173)) {
      case TAG_Nil: {
        v_t_24176 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str97);
        break;
      }
      case TAG_Cons: {
        V v_x_24174 = heff_field(v_x2_24173, 0);
        V v_xs_24175 = heff_field(v_x2_24173, 1);
        heff_take_n(v_x2_24173, 3ULL, 2);
        v_t_24176 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str98); V a_1 = v_x_24174; V a_2 = v_xs_24175; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24175); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24173);
      }
      V v_t_24177 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str99), v_t_24176), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str100));
      V v_t_24178 = heff_strAppend(heff_strAppend(v_t_24177, v_suffix_24163), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str101));
      V v_t_24179 = ({ V a_0 = v_x_24164; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str102); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_24164); r_; });
      V v_t_24180 = heff_strAppend(v_t_24178, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str103), v_t_24179));
      V v_t_24181 = heff_strAppend(heff_strAppend(v_t_24180, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str104)), heff_intShow(v_keep_24166));
      V v_t_24182 = heff_strAppend(heff_strAppend(v_t_24181, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str105)), heff_intShow(v_n_24170));
      V v_t_24183 = heff_strAppend(heff_strAppend(v_t_24182, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str106)), v_shape_24165);
      V v_t_24184 = heff_strAppend(heff_strAppend(v_t_24183, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str107)), v_flats_24169);
      V v_x2_24185 = (g_list_2emap_24s1613211967x1923010103(((V)&g_heff_2ecompile_2eemitc_2eexpF_str108), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str109), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str110), v_changed_24172));
      V v_t_24188;
      switch (heff_tag_of(v_x2_24185)) {
      case TAG_Nil: {
        v_t_24188 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str111);
        break;
      }
      case TAG_Cons: {
        V v_x_24186 = heff_field(v_x2_24185, 0);
        V v_xs_24187 = heff_field(v_x2_24185, 1);
        heff_take_n(v_x2_24185, 3ULL, 2);
        v_t_24188 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str112); V a_1 = v_x_24186; V a_2 = v_xs_24187; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24187); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24185);
      }
      V v_t_24189 = heff_strAppend(heff_strAppend(v_t_24184, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str113)), v_t_24188);
      V v_x_24190 = heff_strAppend(v_t_24189, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str114));
      return heff_tag_at_n(v_ru_24x2_24155_24MkPair, TAG_MkPair, 2, (V[]){v_x_24190, v_s_24162});
    }
  }
  default: return heff_nomatch(v_x2_24155);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam14(V self, V *args) {
  V v_s_24194 = args[0];
  V v_m_24193 = heff_env(self)[0];
  V v_i_24192 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24195 = heff_tr(heff_call(v_m_24193, 1, (V[]){v_s_24194}));
  switch (heff_tag_of(v_x2_24195)) {
  case TAG_MkPair: {
    V v_x_24196 = heff_field(v_x2_24195, 0);
    V v_s_24197 = heff_field(v_x2_24195, 1);
    V v_ru_24x2_24195_24MkPair = heff_take_reuse_n(v_x2_24195, 3ULL, 2);
    V v_t_24198 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str115), heff_intShow(v_i_24192));
    V v_t_24199 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str116), v_x_24196), heff_strAppend(v_t_24198, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str117)));
    return heff_tag_at_n(v_ru_24x2_24195_24MkPair, TAG_MkPair, 2, (V[]){v_t_24199, v_s_24197});
  }
  default: return heff_nomatch(v_x2_24195);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam15(V self, V *args) {
  V v_s_24202 = args[0];
  V v_m_24201 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24203 = heff_tr(heff_call(v_m_24201, 1, (V[]){v_s_24202}));
  switch (heff_tag_of(v_x2_24203)) {
  case TAG_MkPair: {
    V v_x_24204 = heff_field(v_x2_24203, 0);
    V v_s_24205 = heff_field(v_x2_24203, 1);
    V v_ru_24x2_24203_24MkPair = heff_take_reuse_n(v_x2_24203, 3ULL, 2);
    V v_t_24206 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str118), v_x_24204), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str119));
    return heff_tag_at_n(v_ru_24x2_24203_24MkPair, TAG_MkPair, 2, (V[]){v_t_24206, v_s_24205});
  }
  default: return heff_nomatch(v_x2_24203);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam16(V self, V *args) {
  V v_s_24210 = args[0];
  V v_m_24209 = heff_env(self)[0];
  V v_i_24208 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24211 = heff_tr(heff_call(v_m_24209, 1, (V[]){v_s_24210}));
  switch (heff_tag_of(v_x2_24211)) {
  case TAG_MkPair: {
    V v_x_24212 = heff_field(v_x2_24211, 0);
    V v_s_24213 = heff_field(v_x2_24211, 1);
    V v_ru_24x2_24211_24MkPair = heff_take_reuse_n(v_x2_24211, 3ULL, 2);
    V v_t_24214 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str120), heff_intShow(v_i_24208));
    V v_t_24215 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str121), v_x_24212), heff_strAppend(v_t_24214, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str122)));
    return heff_tag_at_n(v_ru_24x2_24211_24MkPair, TAG_MkPair, 2, (V[]){v_t_24215, v_s_24213});
  }
  default: return heff_nomatch(v_x2_24211);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam17(V self, V *args) {
  V v_s_24220 = args[0];
  V v_m_24219 = heff_env(self)[0];
  V v_i_24217 = heff_env(self)[1];
  V v_n_24218 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24221 = heff_tr(heff_call(v_m_24219, 1, (V[]){v_s_24220}));
  switch (heff_tag_of(v_x2_24221)) {
  case TAG_MkPair: {
    V v_x_24222 = heff_field(v_x2_24221, 0);
    V v_s_24223 = heff_field(v_x2_24221, 1);
    V v_ru_24x2_24221_24MkPair = heff_take_reuse_n(v_x2_24221, 3ULL, 2);
    V v_t_24224 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str123), heff_intShow(v_i_24217));
    V v_t_24225 = heff_strAppend(heff_strAppend(v_t_24224, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str124)), heff_intShow(v_n_24218));
    V v_t_24226 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str125), v_x_24222), heff_strAppend(v_t_24225, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str126)));
    return heff_tag_at_n(v_ru_24x2_24221_24MkPair, TAG_MkPair, 2, (V[]){v_t_24226, v_s_24223});
  }
  default: return heff_nomatch(v_x2_24221);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam18(V self, V *args) {
  V v_s_24236 = args[0];
  V v_m_24235 = heff_env(self)[0];
  V v_i_24230 = heff_env(self)[1];
  V v_pre_24234 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24237 = heff_tr(heff_call(v_m_24235, 1, (V[]){v_s_24236}));
  switch (heff_tag_of(v_x2_24237)) {
  case TAG_MkPair: {
    V v_x_24238 = heff_field(v_x2_24237, 0);
    V v_s_24239 = heff_field(v_x2_24237, 1);
    V v_ru_24x2_24237_24MkPair = heff_take_reuse_n(v_x2_24237, 3ULL, 2);
    V v_t_24240 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str133), heff_intShow(v_i_24230));
    V v_t_24241 = heff_strAppend(heff_strAppend(v_pre_24234, v_x_24238), heff_strAppend(v_t_24240, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str134)));
    return heff_tag_at_n(v_ru_24x2_24237_24MkPair, TAG_MkPair, 2, (V[]){v_t_24241, v_s_24239});
  }
  default: return heff_nomatch(v_x2_24237);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam19(V self, V *args) {
  V v_s_24252 = args[0];
  V v_m_24251 = heff_env(self)[0];
  V v_i_24245 = heff_env(self)[1];
  V v_n_24246 = heff_env(self)[2];
  V v_pre_24250 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24253 = heff_tr(heff_call(v_m_24251, 1, (V[]){v_s_24252}));
  switch (heff_tag_of(v_x2_24253)) {
  case TAG_MkPair: {
    V v_x_24254 = heff_field(v_x2_24253, 0);
    V v_s_24255 = heff_field(v_x2_24253, 1);
    V v_ru_24x2_24253_24MkPair = heff_take_reuse_n(v_x2_24253, 3ULL, 2);
    V v_t_24256 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str141), heff_intShow(v_i_24245));
    V v_t_24257 = heff_strAppend(heff_strAppend(v_t_24256, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str142)), heff_intShow(v_n_24246));
    V v_t_24258 = heff_strAppend(heff_strAppend(v_pre_24250, v_x_24254), heff_strAppend(v_t_24257, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str143)));
    return heff_tag_at_n(v_ru_24x2_24253_24MkPair, TAG_MkPair, 2, (V[]){v_t_24258, v_s_24255});
  }
  default: return heff_nomatch(v_x2_24253);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam20(V self, V *args) {
  V v_s_24265 = args[0];
  V v_m_24264 = heff_env(self)[0];
  V v_pre_24263 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24266 = heff_tr(heff_call(v_m_24264, 1, (V[]){v_s_24265}));
  switch (heff_tag_of(v_x2_24266)) {
  case TAG_MkPair: {
    V v_x_24267 = heff_field(v_x2_24266, 0);
    V v_s_24268 = heff_field(v_x2_24266, 1);
    V v_ru_24x2_24266_24MkPair = heff_take_reuse_n(v_x2_24266, 3ULL, 2);
    V v_t_24269 = heff_strAppend(heff_strAppend(v_pre_24263, v_x_24267), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str149));
    return heff_tag_at_n(v_ru_24x2_24266_24MkPair, TAG_MkPair, 2, (V[]){v_t_24269, v_s_24268});
  }
  default: return heff_nomatch(v_x2_24266);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam21(V self, V *args) {
  V v_s_24276 = args[0];
  V v_x_24275 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24275, v_s_24276});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam22(V self, V *args) {
  V v_s_24283 = args[0];
  V v_m_24282 = heff_env(self)[0];
  V v_post_24281 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24284 = heff_tr(heff_call(v_m_24282, 1, (V[]){v_s_24283}));
  switch (heff_tag_of(v_x2_24284)) {
  case TAG_MkPair: {
    V v_x_24285 = heff_field(v_x2_24284, 0);
    V v_s_24286 = heff_field(v_x2_24284, 1);
    V v_ru_24x2_24284_24MkPair = heff_take_reuse_n(v_x2_24284, 3ULL, 2);
    V v_t_24287 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str159), v_x_24285), v_post_24281);
    return heff_tag_at_n(v_ru_24x2_24284_24MkPair, TAG_MkPair, 2, (V[]){v_t_24287, v_s_24286});
  }
  default: return heff_nomatch(v_x2_24284);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam23(V self, V *args) {
  V v_s_24295 = args[0];
  V v_m_24294 = heff_env(self)[0];
  V v_p_24289 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24296 = heff_tr(heff_call(v_m_24294, 1, (V[]){v_s_24295}));
  switch (heff_tag_of(v_x2_24296)) {
  case TAG_MkPair: {
    V v_x_24297 = heff_field(v_x2_24296, 0);
    V v_s_24298 = heff_field(v_x2_24296, 1);
    V v_ru_24x2_24296_24MkPair = heff_take_reuse_n(v_x2_24296, 3ULL, 2);
    V v_t_24299 = ({ V a_0 = v_p_24289; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_24289); r_; });
    V v_t_24300 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str161), v_t_24299), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str162));
    V v_t_24303;
    switch (heff_tag_of(v_x_24297)) {
    case TAG_Nil: {
      v_t_24303 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str163);
      break;
    }
    case TAG_Cons: {
      V v_x_24301 = heff_field(v_x_24297, 0);
      V v_xs_24302 = heff_field(v_x_24297, 1);
      heff_take_n(v_x_24297, 3ULL, 2);
      v_t_24303 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str164); V a_1 = v_x_24301; V a_2 = v_xs_24302; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24302); r_; });
      break;
    }
    default: heff_nomatch(v_x_24297);
    }
    V v_x_24304 = heff_strAppend(heff_strAppend(v_t_24300, v_t_24303), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str165));
    return heff_tag_at_n(v_ru_24x2_24296_24MkPair, TAG_MkPair, 2, (V[]){v_x_24304, v_s_24298});
  }
  default: return heff_nomatch(v_x2_24296);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam24(V self, V *args) {
  V v_s_24322 = args[0];
  V v_m_24321 = heff_env(self)[0];
  V v_tr_24316 = heff_env(self)[1];
  V v_w_24317 = heff_env(self)[2];
  V v_g_24315 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24323 = heff_tr(heff_call(v_m_24321, 1, (V[]){v_s_24322}));
  switch (heff_tag_of(v_x2_24323)) {
  case TAG_MkPair: {
    V v_x_24324 = heff_field(v_x2_24323, 0);
    V v_s_24325 = heff_field(v_x2_24323, 1);
    V v_ru_24x2_24323_24MkPair = heff_take_reuse_n(v_x2_24323, 3ULL, 2);
    V v_t_24326;
    if ((heff_dup(v_tr_24316) == NTAG(TAG_True))) {
      heff_drop(v_tr_24316);
      v_t_24326 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str166);
    } else {
      heff_drop(v_tr_24316);
      v_t_24326 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str167);
    }
    V v_t_24330;
    switch (heff_tag_of(v_w_24317)) {
    case TAG_Nothing: {
      V v_t_24327 = ({ V a_0 = v_g_24315; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str168); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_24315); r_; });
      v_t_24330 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str169), v_t_24327);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_w_24317, 0ULL, 1);
      V v_t_24329 = ({ V a_0 = v_g_24315; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str170); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_24315); r_; });
      v_t_24330 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str171), v_t_24329), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str172));
      break;
    }
    default: heff_nomatch(v_w_24317);
    }
    V v_t_24331 = heff_strAppend(heff_strAppend(v_t_24326, v_t_24330), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str173));
    V v_t_24334;
    switch (heff_tag_of(v_x_24324)) {
    case TAG_Nil: {
      v_t_24334 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str174);
      break;
    }
    case TAG_Cons: {
      V v_x_24332 = heff_field(v_x_24324, 0);
      V v_xs_24333 = heff_field(v_x_24324, 1);
      heff_take_n(v_x_24324, 3ULL, 2);
      v_t_24334 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str175); V a_1 = v_x_24332; V a_2 = v_xs_24333; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24333); r_; });
      break;
    }
    default: heff_nomatch(v_x_24324);
    }
    V v_x_24335 = heff_strAppend(heff_strAppend(v_t_24331, v_t_24334), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str176));
    return heff_tag_at_n(v_ru_24x2_24323_24MkPair, TAG_MkPair, 2, (V[]){v_x_24335, v_s_24325});
  }
  default: return heff_nomatch(v_x2_24323);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam25(V self, V *args) {
  V v_s_24340 = args[0];
  V v_m_24339 = heff_env(self)[0];
  V v_f_24338 = heff_env(self)[1];
  V v_es_24337 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24341 = heff_tr(heff_call(v_m_24339, 1, (V[]){v_s_24340}));
  switch (heff_tag_of(v_x2_24341)) {
  case TAG_MkPair: {
    V v_x_24342 = heff_field(v_x2_24341, 0);
    V v_s_24343 = heff_field(v_x2_24341, 1);
    V v_ru_24x2_24341_24MkPair = heff_take_reuse_n(v_x2_24341, 3ULL, 2);
    V v_m_24344 = (g_prelude_2etraverse_24s1362847681x1386678580(v_f_24338, heff_dup(v_es_24337)));
    V v_x2_24345 = heff_tr(heff_call(v_m_24344, 1, (V[]){v_s_24343}));
    switch (heff_tag_of(v_x2_24345)) {
    case TAG_MkPair: {
      V v_x_24346 = heff_field(v_x2_24345, 0);
      V v_s_24347 = heff_field(v_x2_24345, 1);
      V v_ru_24x2_24345_24MkPair = heff_take_reuse_n(v_x2_24345, 3ULL, 2);
      V v_t_24348 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str177), heff_dup(v_x_24342)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str178));
      V v_t_24349 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_24337; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_24337); r_; });
      V v_t_24350 = heff_strAppend(v_t_24348, heff_intShow(v_t_24349));
      HeffT3 v_t_24351 = ({ V a_0 = MK_INT(1LL); V b_1 = heff_tag_at_n(v_ru_24x2_24345_24MkPair, TAG_Cons, 2, (V[]){v_x_24342, v_x_24346}); HeffT3 r_ = (g_list_2edrop_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_24360;
      {
        V v_field_24353 = v_t_24351.f[1];
        V v_field_24354 = v_t_24351.f[2];
        int64_t v_tag_24352 = ((int64_t)v_t_24351.f[0]);
        if ((v_tag_24352 == ((int64_t)0ULL))) {
          V v_x11_24355 = heff_dup(v_field_24353);
          heff_drop(v_x11_24355);
          V v_x12_24356 = heff_dup(v_field_24354);
          heff_drop(v_x12_24356);
          V v_t_24359;
          if ((v_tag_24352 == ((int64_t)0ULL))) {
            V v_x_24357 = v_field_24353;
            V v_xs_24358 = v_field_24354;
            v_t_24359 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str179); V a_1 = v_x_24357; V a_2 = v_xs_24358; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24358); r_; });
          } else {
            heff_drop(v_field_24353);
            heff_drop(v_field_24354);
            v_t_24359 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str180);
          }
          v_t_24360 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str181), v_t_24359), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str182));
        } else {
          heff_drop(v_field_24353);
          heff_drop(v_field_24354);
          v_t_24360 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str183);
        }
      }
      V v_t_24361 = heff_strAppend(heff_strAppend(v_t_24350, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str184)), v_t_24360);
      V v_x_24362 = heff_strAppend(v_t_24361, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str185));
      return heff_tag_at_n(v_ru_24x2_24341_24MkPair, TAG_MkPair, 2, (V[]){v_x_24362, v_s_24347});
    }
    default: return heff_nomatch(v_x2_24345);
    }
  }
  default: return heff_nomatch(v_x2_24341);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam26(V self, V *args) {
  V v_s_24365 = args[0];
  V v_m_24364 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24366 = heff_tr(heff_call(v_m_24364, 1, (V[]){v_s_24365}));
  switch (heff_tag_of(v_x2_24366)) {
  case TAG_MkPair: {
    V v_x_24367 = heff_field(v_x2_24366, 0);
    V v_s_24368 = heff_field(v_x2_24366, 1);
    V v_ru_24x2_24366_24MkPair = heff_take_reuse_n(v_x2_24366, 3ULL, 2);
    V v_t_24369 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str186), v_x_24367), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str187));
    return heff_tag_at_n(v_ru_24x2_24366_24MkPair, TAG_MkPair, 2, (V[]){v_t_24369, v_s_24368});
  }
  default: return heff_nomatch(v_x2_24366);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam27(V self, V *args) {
  V v_s_24370 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eexpF_str188), v_s_24370});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam28(V self, V *args) {
  V v_s_24377 = args[0];
  V v_m_24376 = heff_env(self)[0];
  V v_pre_24375 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24378 = heff_tr(heff_call(v_m_24376, 1, (V[]){v_s_24377}));
  switch (heff_tag_of(v_x2_24378)) {
  case TAG_MkPair: {
    V v_x_24379 = heff_field(v_x2_24378, 0);
    V v_s_24380 = heff_field(v_x2_24378, 1);
    V v_ru_24x2_24378_24MkPair = heff_take_reuse_n(v_x2_24378, 3ULL, 2);
    V v_t_24381 = heff_strAppend(heff_strAppend(v_pre_24375, v_x_24379), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str194));
    return heff_tag_at_n(v_ru_24x2_24378_24MkPair, TAG_MkPair, 2, (V[]){v_t_24381, v_s_24380});
  }
  default: return heff_nomatch(v_x2_24378);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam29(V self, V *args) {
  V v_s_24388 = args[0];
  V v_m_24387 = heff_env(self)[0];
  V v_pre_24386 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24389 = heff_tr(heff_call(v_m_24387, 1, (V[]){v_s_24388}));
  switch (heff_tag_of(v_x2_24389)) {
  case TAG_MkPair: {
    V v_x_24390 = heff_field(v_x2_24389, 0);
    V v_s_24391 = heff_field(v_x2_24389, 1);
    V v_ru_24x2_24389_24MkPair = heff_take_reuse_n(v_x2_24389, 3ULL, 2);
    V v_t_24392 = heff_strAppend(heff_strAppend(v_pre_24386, v_x_24390), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str200));
    return heff_tag_at_n(v_ru_24x2_24389_24MkPair, TAG_MkPair, 2, (V[]){v_t_24392, v_s_24391});
  }
  default: return heff_nomatch(v_x2_24389);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam30(V self, V *args) {
  V v_s_24399 = args[0];
  V v_m_24398 = heff_env(self)[0];
  V v_pre_24397 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24400 = heff_tr(heff_call(v_m_24398, 1, (V[]){v_s_24399}));
  switch (heff_tag_of(v_x2_24400)) {
  case TAG_MkPair: {
    V v_x_24401 = heff_field(v_x2_24400, 0);
    V v_s_24402 = heff_field(v_x2_24400, 1);
    V v_ru_24x2_24400_24MkPair = heff_take_reuse_n(v_x2_24400, 3ULL, 2);
    V v_t_24403 = heff_strAppend(heff_strAppend(v_pre_24397, v_x_24401), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str206));
    return heff_tag_at_n(v_ru_24x2_24400_24MkPair, TAG_MkPair, 2, (V[]){v_t_24403, v_s_24402});
  }
  default: return heff_nomatch(v_x2_24400);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam31(V self, V *args) {
  V v_s_24407 = args[0];
  V v_m_24406 = heff_env(self)[0];
  V v_p_24404 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24408 = heff_tr(heff_call(v_m_24406, 1, (V[]){v_s_24407}));
  switch (heff_tag_of(v_x2_24408)) {
  case TAG_MkPair: {
    V v_x_24409 = heff_field(v_x2_24408, 0);
    V v_s_24410 = heff_field(v_x2_24408, 1);
    V v_ru_24x2_24408_24MkPair = heff_take_reuse_n(v_x2_24408, 3ULL, 2);
    V v_t_24411 = (g_heff_2ecompile_2eemitc_2eunboxed(v_p_24404));
    V v_x_24412 = ({ V a_0 = v_t_24411; V a_1 = v_x_24409; V r_ = (g_heff_2ecompile_2eemitc_2eunboxedC(a_0, a_1)); heff_drop(v_t_24411); heff_drop(v_x_24409); r_; });
    return heff_tag_at_n(v_ru_24x2_24408_24MkPair, TAG_MkPair, 2, (V[]){v_x_24412, v_s_24410});
  }
  default: return heff_nomatch(v_x2_24408);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam32(V self, V *args) {
  V v_s_24422 = args[0];
  V v_m_24421 = heff_env(self)[0];
  V v_p_24413 = heff_env(self)[1];
  V v_r_24414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24423 = heff_tr(heff_call(v_m_24421, 1, (V[]){v_s_24422}));
  switch (heff_tag_of(v_x2_24423)) {
  case TAG_MkPair: {
    V v_x_24424 = heff_field(v_x2_24423, 0);
    V v_s_24425 = heff_field(v_x2_24423, 1);
    V v_ru_24x2_24423_24MkPair = heff_take_reuse_n(v_x2_24423, 3ULL, 2);
    V v_t_24426 = ({ V a_0 = v_p_24413; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_p_24413); r_; });
    V v_t_24427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str211), v_t_24426), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str212));
    V v_t_24429;
    switch (heff_tag_of(v_r_24414)) {
    case TAG_RepV: {
      v_t_24429 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str213);
      break;
    }
    case TAG_RepFix: {
      V v_w_24428 = heff_field(v_r_24414, 0);
      heff_take_n(v_r_24414, 1ULL, 1);
      v_t_24429 = ({ V a_0 = v_w_24428; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24428); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24429 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str214);
      break;
    }
    case TAG_RepInt: {
      v_t_24429 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str215);
      break;
    }
    default: heff_nomatch(v_r_24414);
    }
    V v_t_24430 = heff_strAppend(heff_strAppend(v_t_24427, v_t_24429), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str216));
    V v_t_24433;
    switch (heff_tag_of(v_x_24424)) {
    case TAG_Nil: {
      v_t_24433 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str217);
      break;
    }
    case TAG_Cons: {
      V v_x_24431 = heff_field(v_x_24424, 0);
      V v_xs_24432 = heff_field(v_x_24424, 1);
      heff_take_n(v_x_24424, 3ULL, 2);
      v_t_24433 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str218); V a_1 = v_x_24431; V a_2 = v_xs_24432; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24432); r_; });
      break;
    }
    default: heff_nomatch(v_x_24424);
    }
    V v_x_24434 = heff_strAppend(heff_strAppend(v_t_24430, v_t_24433), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str219));
    return heff_tag_at_n(v_ru_24x2_24423_24MkPair, TAG_MkPair, 2, (V[]){v_x_24434, v_s_24425});
  }
  default: return heff_nomatch(v_x2_24423);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam33(V self, V *args) {
  V v_s_24446 = args[0];
  V v_x_24445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24445, v_s_24446});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam34(V self, V *args) {
  V v_s_24448 = args[0];
  V v_x_24447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24450;
  if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24447)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str226))) {
    heff_drop(v_x_24447);
    v_t_24450 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str227);
  } else {
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24447)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str228))) {
      heff_drop(v_x_24447);
      v_t_24450 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str229);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24447)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str230))) {
        heff_drop(v_x_24447);
        v_t_24450 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str231);
      } else {
        V v_t_24449 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str232), heff_floatShow(v_x_24447));
        v_t_24450 = heff_strAppend(v_t_24449, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str233));
      }
    }
  }
  V v_t_24451 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str234), v_t_24450), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str235));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24451, v_s_24448});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam35(V self, V *args) {
  V v_s_24453 = args[0];
  V v_x_24452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24455;
  if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24452)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str236))) {
    heff_drop(v_x_24452);
    v_t_24455 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str237);
  } else {
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24452)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str238))) {
      heff_drop(v_x_24452);
      v_t_24455 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str239);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24452)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str240))) {
        heff_drop(v_x_24452);
        v_t_24455 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str241);
      } else {
        V v_t_24454 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str242), heff_floatShow(v_x_24452));
        v_t_24455 = heff_strAppend(v_t_24454, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str243));
      }
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24455, v_s_24453});
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str1, 7, "V f_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str2, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str3, 10, "heff_room[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str4, 4, "] = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str5, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str6, 19, "if (heff_exact(f_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str7, 62, ", heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str8, 21, "return heff_tail(f_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str9, 8, ", (V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str10, 10, "heff_room[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str11, 1, "]");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str13, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eroomed_str14, 3, "});");
Clo g_heff_2ecompile_2eemitc_2eroomed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eroomed_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eroomed(V v_vs_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_vs_240)) {
  case TAG_Nil: {
    v_t_243 = ((V)&g_heff_2ecompile_2eemitc_2eroomed_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_vs_240, 0);
    v_t_243 = heff_dup(v_x_241);
    break;
  }
  default: heff_nomatch(v_vs_240);
  }
  V v_t_244 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eroomed_str1), v_t_243), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str2));
  V v_t_245 = (g_list_2edrop(MK_INT(1LL), v_vs_240));
  V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_247 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_246, MK_INT(2LL))));
  V v_t_248 = (g_list_2ezipWith_24s952564628x174753269(((V)&g_heff_2ecompile_2eemitc_2eroomed_str3), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str4), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str5), v_t_245, v_t_247));
  V v_t_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2410 = heff_intShow(heff_intSub(v_t_249, MK_INT(1LL)));
  V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eroomed_str6), v_t_2410), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str7));
  V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2413 = heff_intShow(heff_intSub(v_t_2412, MK_INT(1LL)));
  V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eroomed_str8), v_t_2413), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str9));
  V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_x2_2416 = (g_list_2emap_24f1512150482x179770396(((V)&g_heff_2ecompile_2eemitc_2eroomed_str10), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str11), MK_INT(0LL), heff_intSub(v_t_2415, MK_INT(2LL))));
  V v_t_2419;
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nil: {
    v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2eroomed_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_xs_2418 = heff_field(v_x2_2416, 1);
    heff_take_n(v_x2_2416, 3ULL, 2);
    v_t_2419 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eroomed_str13); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2416);
  }
  V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2414, v_t_2419), ((V)&g_heff_2ecompile_2eemitc_2eroomed_str14));
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
  V v_ys_2422 = (g_prelude_2e_2b_2b(v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2421})));
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_ys_2422});
}
V g_heff_2ecompile_2eemitc_2eroomed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eroomed(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str0, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str1, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str2, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str3, 2, " {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str4, 6, "top: ;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str5, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str6, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str7, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str8, 0, "");

HeffT2 g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr(V v_tu_240, V v_n_241, V v_f_242, V v_z_243) {
top: ;
  V v_reprs_244 = heff_take_field(v_f_242, 5);
  V v_entry_245 = heff_take_field(v_f_242, 3);
  V v_body_246 = heff_take_field(v_f_242, 4);
  V v_key_247 = heff_take_field(v_f_242, 0);
  V v_params_248 = heff_take_field(v_f_242, 1);
  V v_wrapper_249 = heff_get_n(v_f_242, 7, 8);
  V v_t_2410 = (g_heff_2ecompile_2eemitc_2eckOf(v_reprs_244, heff_dup(v_tu_240), heff_dup(v_n_241)));
  V v_m_2411 = heff_tr(heff_call(heff_get_n(v_t_2410, 1, 6), 1, (V[]){v_entry_245}));
  V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_z_243}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_s_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    V v_t_2415 = (g_heff_2ecompile_2eemitc_2eckOf(v_reprs_244, v_tu_240, heff_dup(v_n_241)));
    V v_m_2416 = heff_tr(heff_call(heff_get_n(v_t_2415, 1, 6), 1, (V[]){v_body_246}));
    V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2414}));
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_s_2419 = heff_field(v_x2_2417, 1);
      V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
      V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str0), heff_intShow(heff_dup(v_n_241)));
      V v_t_2422;
      switch (heff_tag_of(v_wrapper_249)) {
      case TAG_Nothing: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        v_t_2422 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_wrapper_249);
      }
      V v_t_2423 = ({ V a_0 = v_key_247; V a_1 = heff_dup(v_params_248); V a_2 = v_reprs_244; V a_3 = v_t_2420; V a_4 = v_t_2422; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2422); r_; });
      V v_t_2424 = heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str1)), NTAG(TAG_Nil)});
      V v_t_2425 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str2), heff_intShow(v_n_241));
      V v_t_2427;
      switch (heff_tag_of(v_wrapper_249)) {
      case TAG_Nothing: {
        v_t_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_wrapper_249, 0ULL, 1);
        v_t_2427 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_wrapper_249);
      }
      V v_t_2428 = ({ V a_0 = v_key_247; V a_1 = v_params_248; V a_2 = v_reprs_244; V a_3 = v_t_2425; V a_4 = v_t_2427; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_key_247); heff_drop(v_reprs_244); heff_drop(v_t_2427); r_; });
      V v_t_2429 = heff_strAppend(v_t_2428, ((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str3));
      V v_t_2430 = heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str4), NTAG(TAG_Nil)});
      V v_t_2431 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2430, ((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str5), v_x_2413));
      V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str6), NTAG(TAG_Nil)});
      V v_ys_2433 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2432, ((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str7), v_x_2418));
      V v_t_2434 = (g_prelude_2e_2b_2b(v_t_2431, v_ys_2433));
      V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2etupleFunDef_24cpr_str8), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_t_2434})});
      V v_x_2436 = heff_rec_n(2, shape_protos__code, (V[]){v_t_2424, v_t_2435});
      return ((HeffT2){{v_x_2436, v_s_2419}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2417)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_2412)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str1, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str2, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str3, 11, "_get(void);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str5, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str6, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str7, 5, "_val;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str9, 17, "static HEFF_ONCE ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str10, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str11, 4, "_st;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str13, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str14, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str15, 13, "_init(void) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str16, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str18, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str19, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str21, 16, "  if (HEFF_DONE(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str22, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str23, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str24, 13, "_st)) return ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str25, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str26, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str27, 22, "  return heff_global(&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str28, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str29, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str30, 7, "_val, &");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str31, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str32, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str33, 5, "_st, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str34, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str35, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str36, 7, "_init);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str37, 5, "_val;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str38, 12, "_get(void) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str39, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2evalDef_24cpr_str40, 0, "");

HeffT2 g_heff_2ecompile_2eemitc_2evalDef_24cpr(V v_tu_240, V v_key_241, V v_body_242, V v_rs_243, V v_z_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2eemitc_2eckOf(v_rs_243, v_tu_240, MK_INT(0LL)));
  V v_m_246 = heff_tr(heff_call(heff_get_n(v_t_245, 1, 6), 1, (V[]){v_body_242}));
  V v_x2_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_244}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_t_2410 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str0)));
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str1), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str2), v_t_2410));
    V v_t_2412 = heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str3)), NTAG(TAG_Nil)});
    V v_t_2413 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str4)));
    V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str5), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str6), v_t_2413));
    V v_t_2415 = heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str7));
    V v_t_2416 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str8)));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str9), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str10), v_t_2416));
    V v_t_2418 = heff_strAppend(v_t_2417, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str11));
    V v_t_2419 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str12)));
    V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str13), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str14), v_t_2419));
    V v_t_2421 = heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str15));
    V v_t_2422 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str16), v_x_248));
    V v_t_2423 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str17)));
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str18), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str19), v_t_2423));
    V v_t_2425 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str20)));
    V v_t_2426 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str21), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str22), v_t_2425));
    V v_t_2427 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str23)));
    V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str24)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str25), v_t_2427));
    V v_t_2429 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str26)));
    V v_t_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str27), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str28), v_t_2429));
    V v_t_2431 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str29)));
    V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2430, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str30)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str31), v_t_2431));
    V v_t_2433 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_241, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str32)));
    V v_t_2434 = heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str33)), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str34), v_t_2433));
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str35), NTAG(TAG_Nil)});
    V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2434, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str36)), v_t_2435});
    V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2428, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str37)), v_t_2436});
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str38)), v_t_2437});
    V v_ys_2439 = (g_prelude_2e_2b_2b(v_t_2422, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str39), v_t_2438})));
    V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_ys_2439})});
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2evalDef_24cpr_str40), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2440})});
    V v_x_2442 = heff_rec_n(2, shape_protos__code, (V[]){v_t_2412, v_t_2441});
    return ((HeffT2){{v_x_2442, v_s_249}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_247)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str0, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str1, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str2, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str3, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str4, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str5, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str6, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str7, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str8, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str9, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str10, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str11, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str12, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str13, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str14, 3, "int");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str15, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str16, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str17, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str18, 2, " (");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunTypeName_str19, 1, ")");
Clo g_heff_2ecompile_2eemitc_2efunTypeName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efunTypeName_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2efunTypeName(V v_b_240) {
top: ;
  V v_result_241 = heff_take_field(v_b_240, 3);
  V v_args_242 = heff_get_n(v_b_240, 2, 5);
  V v_t_2411;
  switch (heff_tag_of(v_result_241)) {
  case TAG_Gives: {
    V v_t_243 = heff_field(v_result_241, 0);
    heff_take_n(v_result_241, 1ULL, 1);
    switch (heff_tag_of(v_t_243)) {
    case TAG_CInteger: {
      V v_t_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      v_t_2411 = v_t_244;
      break;
    }
    case TAG_CDouble: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str0);
      break;
    }
    case TAG_CBool: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str1);
      break;
    }
    case TAG_CString: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str2);
      break;
    }
    case TAG_CText: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str3);
      break;
    }
    case TAG_COwnedString: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str4);
      break;
    }
    case TAG_CPointer: {
      V v_t_245 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 2);
      v_t_2411 = heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str5));
      break;
    }
    case TAG_CVoid: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str6);
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    break;
  }
  case TAG_GivesOrErrno: {
    V v_t_247 = heff_field(v_result_241, 0);
    heff_take_n(v_result_241, 1ULL, 1);
    switch (heff_tag_of(v_t_247)) {
    case TAG_CInteger: {
      V v_t_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_2411 = v_t_248;
      break;
    }
    case TAG_CDouble: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str7);
      break;
    }
    case TAG_CBool: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str8);
      break;
    }
    case TAG_CString: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str9);
      break;
    }
    case TAG_CText: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str10);
      break;
    }
    case TAG_COwnedString: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str11);
      break;
    }
    case TAG_CPointer: {
      V v_t_249 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 2);
      v_t_2411 = heff_strAppend(v_t_249, ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str12));
      break;
    }
    case TAG_CVoid: {
      v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str13);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    break;
  }
  case TAG_DoneOrErrno: {
    v_t_2411 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str14);
    break;
  }
  default: heff_nomatch(v_result_241);
  }
  V v_t_2417;
  switch (heff_tag_of(v_args_242)) {
  case TAG_Nil: {
    v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str15);
    break;
  }
  case TAG_Cons: {
    V v_x2_2414 = (g_list_2emap_24s1215346472x331828322(v_args_242));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_xs_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str17); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2414);
    }
    break;
  }
  default: heff_nomatch(v_args_242);
  }
  V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str18)), v_t_2417);
  return heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2eemitc_2efunTypeName_str19));
}
V g_heff_2ecompile_2eemitc_2efunTypeName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2efunTypeName(a[0]);
}
Clo g_heff_2ecompile_2eemitc_2eargLines_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eargLines_24dps_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eargLines_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = ({ V a_0 = heff_dup(v_i_240); V a_1 = v_t_243; V r_ = (g_heff_2ecompile_2eemitc_2eargLine(a_0, a_1)); heff_drop(v_t_243); r_; });
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_rest_244;
    V t_2 = v_cell_246;
    v_i_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eargLines_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eargLines_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str0, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str2, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str4, 1, ")");
Clo g_heff_2ecompile_2eemitc_2eglueCallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglueCallOf_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eglueCallOf(V v_b_240) {
top: ;
  V v_fun_241 = heff_take_field(v_b_240, 1);
  V v_args_242 = heff_get_n(v_b_240, 2, 5);
  V v_t_243 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_242); r_; });
  V v_x2_244 = (g_list_2emap_24f1005417903x1119563692(((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str0), MK_INT(0LL), heff_intSub(v_t_243, MK_INT(1LL))));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = heff_strAppend(heff_strAppend(v_fun_241, ((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str3)), v_t_247);
  return heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str4));
}
V g_heff_2ecompile_2eemitc_2eglueCallOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglueCallOf(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_str0, 9, "heff_ffi_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_str1, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_str2, 12, "static void ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_str3, 12, "(void *q) { ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_str4, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2epointerFnLines_str5, 8, " *)q); }");
Clo g_heff_2ecompile_2eemitc_2epointerFnLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2epointerFnLines_entry, 4, 0};

V g_heff_2ecompile_2eemitc_2epointerFnLines(V v_leaf_240, V v_what_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_leaf_240);
    heff_drop(v_what_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_MkPair: {
      V v_t_246 = heff_field(v_x41_244, 0);
      V v_r_247 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_str0), heff_dup(v_leaf_240)), ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_str1));
      V v_t_249 = heff_strAppend(heff_dup(v_what_241), heff_intShow(heff_dup(v_i_242)));
      V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_str2), heff_strAppend(v_t_248, v_t_249));
      V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_str3)), v_r_247);
      V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_str4)), v_t_246);
      V v_cell_2413 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2eemitc_2epointerFnLines_str5)), heff_hole()});
      V v_u_2414 = (g_heff_2ecompile_2eemitc_2epointerFnLines_24dps(v_leaf_240, v_what_241, heff_box_word((heff_unbox_word(v_i_242) + ((int64_t)1ULL))), v_rest_245, heff_dup(v_cell_2413)));
      heff_drop(v_u_2414);
      return v_cell_2413;
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eemitc_2epointerFnLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2epointerFnLines(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemptyCS_str0, 0, "");

static V g_heff_2ecompile_2eemitc_2eemptyCS_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eemptyCS_st;
static V g_heff_2ecompile_2eemitc_2eemptyCS_init(void) {
  return heff_rec_n(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){((V)&g_heff_2ecompile_2eemitc_2eemptyCS_str0), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eemptyCS_st)) return g_heff_2ecompile_2eemitc_2eemptyCS_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eemptyCS_val, &g_heff_2ecompile_2eemitc_2eemptyCS_st, g_heff_2ecompile_2eemitc_2eemptyCS_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str0, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str1, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str2, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str3, 4, "LBL_");
Clo g_heff_2ecompile_2eemitc_2eceOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eceOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eceOf(V v_provs_240, V v_facts_241, V v_names_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_x_243 = heff_field(v_names_242, 0);
    v_t_245 = heff_dup(v_x_243);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_t_247 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str0); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_246; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_245, v_t_247));
  V v_xs_249 = (g_list_2ekeepIf_24s478006518x1380334353(v_t_248));
  V v_m_2410 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_249; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_xs_249); r_; });
  V v_t_2411 = ({ V a_0 = v_m_2410; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2410); r_; });
  V v_t_2412 = (g_list_2emap_24s1937570095x2110149801(v_t_2411));
  V v_t_2413 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V a_2 = heff_dup(g_std_2eordmap_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2enumbered(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2414 = ({ V a_0 = MK_INT(10LL); V a_1 = MK_INT(65526LL); V a_2 = v_t_2412; V a_3 = v_t_2413; V a_4 = heff_dup(g_std_2eordmap_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2ehashedGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2412); r_; });
  V v_t_2417;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_names_242, 1);
    v_t_2417 = heff_dup(v_y_2416);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_t_2419 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str1); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2418; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2418); r_; });
  V v_xs_2420 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2419));
  V v_m_2421 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_xs_2420; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_xs_2420); r_; });
  V v_t_2422 = ({ V a_0 = v_m_2421; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2421); r_; });
  V v_t_2423 = (g_list_2emap_24s1937570095x2110149801(v_t_2422));
  V v_t_2424 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(2147483647LL); V a_2 = v_t_2423; V a_3 = heff_dup(g_std_2eordmap_2eempty_get()); V a_4 = heff_dup(g_std_2eordmap_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2ehashedGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2423); r_; });
  V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_t_2426 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str2); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2425; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2425); r_; });
  V v_t_2427 = (g_prelude_2e_2b_2b(heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()), v_t_2426));
  V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_provs_240));
  V v_t_2429 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str3); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2428; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2428); r_; });
  V v_t_2430 = ({ V a_0 = v_t_2427; V a_1 = v_t_2429; V a_2 = v_facts_241; V r_ = (g_heff_2ecompile_2efacts_2esureOnlyHere(a_0, a_1, a_2)); heff_drop(v_t_2427); heff_drop(v_t_2429); r_; });
  return heff_rec_n(3, shape_tags__lbls__facts, (V[]){v_t_2414, v_t_2424, v_t_2430});
}
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eceOf(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2emoduleParts_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2emoduleParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emoduleParts_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2emoduleParts(V v_size_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_m_242 = heff_field(v_x2_241, 0);
    V v_ps_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkPair = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eemitc_2emoduleParts_lam0, 2, 1, (V[]){v_size_240}), MK_INT(0LL), v_ps_243));
    V v_b_248 = (g_heff_2ecompile_2eemitc_2epartCount(v_t_247, MK_INT(1LL)));
    if (heff_intEq_c_lent(v_b_248, MK_INT(1LL), 2)) {
      heff_drop(v_b_248);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24MkPair, TAG_MkPair, 2, (V[]){v_m_242, v_ps_243}), NTAG(TAG_Nil)});
    } else {
      heff_drop_cell(v_ru_24x2_241_24MkPair, 2);
      return (g_heff_2ecompile_2eemitc_2epartsFrom(v_m_242, v_b_248, v_ps_243, MK_INT(0LL)));
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2emoduleParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emoduleParts(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2emoduleParts_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_p_245 = args[1];
  V v_size_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tr(heff_call(v_size_240, 1, (V[]){v_p_245}));
  return heff_intAdd(v_n_244, v_t_246);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprojShapesW_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eprojShapesW_str1, 1, ",");
Clo g_heff_2ecompile_2eemitc_2eprojShapesW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eprojShapesW_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eprojShapesW(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_acc_240;
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V t_0 = v_acc_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_b_247, v_rest_243});
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x21_242, 0);
      V v_argv_249 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x21_242_24EApp, v_argv_249, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2410});
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2412 = heff_field(v_x21_242, 1);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, v_rest_243})});
      V t_0 = v_acc_240;
      V t_1 = v_t_2414;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      V v_t_2417 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x2_241_24Cons, v_fs_2415, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2417;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      V v_sh_2420 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 4);
      V v_t_2424;
      switch (heff_tag_of(v_sh_2420)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_heff_2ecompile_2eemitc_2eprojShapesW_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_sh_2420, 0);
        V v_xs_2423 = heff_field(v_sh_2420, 1);
        heff_take_n(v_sh_2420, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eprojShapesW_str1); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_sh_2420);
      }
      V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2424, v_acc_240});
      V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2418, v_rest_243});
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ETag: {
      V v_argv_2426 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 3);
      V v_t_2428 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_2426, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2428;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2429 = heff_field(v_x21_242, 0);
      V v_arms_2430 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_2431 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2430, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_s_2429, v_t_2431});
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_argv_2434 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2435 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_2434, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2435;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECall: {
      V v_argv_2437 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 2ULL, 2);
      V v_t_2438 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_argv_2437, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2438;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x21_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2446 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2447 = ({ V a_0 = v_c_2446; V a_1 = v_rest_243; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2446); r_; });
      V t_0 = v_acc_240;
      V t_1 = v_t_2447;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2449 = heff_field(v_x21_242, 1);
      V v_b_2450 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 6ULL, 3);
      V v_t_2451 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_a_2449, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2450, v_rest_243})});
      V t_0 = v_acc_240;
      V t_1 = v_t_2451;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2452 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2453 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_es_2452, v_rest_243));
      V t_0 = v_acc_240;
      V t_1 = v_t_2453;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_acc_240;
      V t_1 = v_rest_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eprojShapesW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eprojShapesW(a[0], a[1]);
}
Clo g_heff_2ecompile_2eemitc_2emergeKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2emergeKept_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2emergeKept(V v_o_240, V v_k_241, V v_s_242) {
top: ;
  V v_lams_243 = heff_take_field(v_k_241, 5);
  V v_lprotos_244 = heff_take_field(v_k_241, 4);
  V v_strs_245 = heff_take_field(v_k_241, 3);
  V v_shapes_246 = heff_take_field(v_k_241, 6);
  V v_prims_247 = heff_get_n(v_k_241, 7, 8);
  V v_t_248 = (g_heff_2ecompile_2eemitc_2epushOwn(heff_dup(v_o_240), v_lams_243, heff_take_field(v_s_242, 2)));
  V v_t_249 = (g_heff_2ecompile_2eemitc_2epushOwn(heff_dup(v_o_240), v_lprotos_244, heff_take_field(v_s_242, 3)));
  V v_t_2410 = (g_heff_2ecompile_2eemitc_2epushOwn(heff_dup(v_o_240), v_strs_245, heff_take_field(v_s_242, 5)));
  V v_t_2411 = (g_heff_2ecompile_2eemitc_2epushOwn(heff_dup(v_o_240), v_shapes_246, heff_take_field(v_s_242, 6)));
  V v_t_2412 = (g_heff_2ecompile_2eemitc_2epushOwn(v_o_240, v_prims_247, heff_take_field(v_s_242, 7)));
  return ({ V rv_2 = v_t_248; V rv_3 = v_t_249; V rv_5 = v_t_2410; V rv_6 = v_t_2411; V rv_7 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_s_242, 19ULL, 8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, 783u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2ecompile_2eemitc_2emergeKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2emergeKept(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str1, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str5, 2, "g_");
Clo g_heff_2ecompile_2eemitc_2eemitAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eemitAt_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2eemitAt(V v_ce_240, V v_kept_241, V v_acc_242, V v_d_243, V v_own_244, V v_v_245) {
top: ;
  HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_kept_241, heff_rfield(v_d_243, 0)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    V v_t_2410;
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_k_249 = v_field_248;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_249, 0)), heff_dup(v_v_245))) {
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){v_k_249});
      } else {
        heff_drop_rec(v_k_249, 8);
        v_t_2410 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_field_248);
      v_t_2410 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nothing: {
      V v_acc_2411 = v_acc_242;
      V v_ems_2412 = heff_take_field(v_acc_2411, 0);
      V v_s_2413 = heff_take_field(v_acc_2411, 1);
      V v_fresh_2414 = heff_get_n(v_acc_2411, 2, 3);
      V v_key_2415 = heff_dup(heff_rfield(v_d_243, 0));
      V v_v_2416 = v_v_245;
      V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 8, 11);
      V v_t_2428;
      switch (heff_tag_of(v_own_244)) {
      case TAG_MkPair: {
        V v_b0_2418 = heff_field(v_own_244, 0);
        V v_n_2419 = heff_field(v_own_244, 1);
        V v_t_2420 = (g_heff_2ecompile_2eimperative_2egenOf(NTAG(TAG_True)));
        V v_t_2421 = heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(heff_rfield(v_d_243, 0)), heff_dup(heff_rfield(v_d_243, 1)), heff_dup(v_b0_2418)});
        HeffT2 v_t_2422 = (g_heff_2ecompile_2eimperative_2edefOf_24cpr(v_t_2420, v_t_2421, heff_dup(v_n_2419)));
        V v_t_2427;
        {
          V v_field_2423 = v_t_2422.f[0];
          V v_field_2424 = v_t_2422.f[1];
          V v_x_2425 = v_field_2423;
          V v_y_2426 = v_field_2424;
          heff_drop(v_y_2426);
          v_t_2427 = v_x_2425;
        }
        v_t_2428 = (g_heff_2ecompile_2elower_2ercOf(heff_get_n(v_ce_240, 2, 3), v_t_2427));
        break;
      }
      default: heff_nomatch(v_own_244);
      }
      V v_t_2429 = ({ V b_0 = heff_get_n(v_d_243, 0, 3); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eemitAt_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V v_o_2430 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eemitAt_str1), v_t_2429);
      V v_t_2431 = heff_rec_n(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){v_o_2430, MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      HeffT2 v_t_2432 = ({ V a_0 = v_t_2417; V a_1 = v_t_2428; V a_2 = v_t_2431; HeffT2 r_ = (g_heff_2ecompile_2eemitc_2edefC_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2428); r_; });
      {
        V v_field_2433 = v_t_2432.f[0];
        V v_field_2434 = v_t_2432.f[1];
        V v_e_2435 = v_field_2433;
        V v_s1_2436 = v_field_2434;
        V v_t_2437 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_2415, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eemitAt_str2)));
        V v_t_2438 = (g_heff_2ecompile_2eemitc_2ekeptOf(heff_dup(v_v_2416), heff_dup(v_e_2435), heff_dup(v_s1_2436)));
        V v_t_2439 = (g_heff_2ecompile_2eemitc_2emergeKept(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eemitAt_str3), v_t_2437), v_t_2438, v_s_2413));
        V v_t_2440 = (g_heff_2ecompile_2eemitc_2ekeptOf(v_v_2416, heff_dup(v_e_2435), v_s1_2436));
        V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_key_2415, v_t_2440}), v_fresh_2414});
        return heff_rec_n(3, shape_ems__s__fresh, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_e_2435, v_ems_2412}), v_t_2439, v_t_2441});
      }
    }
    case TAG_Just: {
      V v_k_2442 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 1);
      heff_drop_rec(v_ce_240, 3);
      heff_drop(v_v_245);
      V v_t_2443 = heff_rec_n(2, shape_protos__code, (V[]){heff_dup(heff_rfield(v_k_2442, 1)), heff_dup(heff_rfield(v_k_2442, 2))});
      V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, heff_take_field(v_acc_242, 0)});
      V v_t_2445 = ({ V b_0 = heff_get_n(v_d_243, 0, 3); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eemitAt_str4); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
      V v_t_2446 = (g_heff_2ecompile_2eemitc_2emergeKept(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eemitAt_str5), v_t_2445), v_k_2442, heff_take_field(v_acc_242, 1)));
      return ({ V rv_0 = v_t_2444; V rv_1 = v_t_2446; V rr_ = heff_rec_reuse_nf(v_acc_242, 4ULL, 3, shape_ems__s__fresh, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
}
V g_heff_2ecompile_2eemitc_2eemitAt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ecompile_2eemitc_2eemitAt(a[0], a1, a[2], a[3], a4, a[5]); heff_drop(a1); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2echeckOut_str0, 18, "#define HEFF_CHECK");
Clo g_heff_2ecompile_2eemitc_2echeckOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2echeckOut_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2echeckOut(V v_runtime_240, V v_exports_241, V v_l_242) {
top: ;
  V v_defs_243 = heff_take_field(v_l_242, 0);
  V v_facts_244 = heff_take_field(v_l_242, 1);
  V v_errors_245 = heff_get_n(v_l_242, 2, 3);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2echeckOut_str0), NTAG(TAG_Nil)});
  V v_t_247 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2echeckEnd_clo), 2, (V[]){v_exports_241, heff_dup(v_defs_243)}));
  V v_ending_248 = heff_rec_n(2, shape_prefix__end, (V[]){v_t_246, v_t_247});
  V v_defs_249 = v_defs_243;
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_2411 = (g_list_2efoldl_24f409057300x985797598(NTAG(TAG_Nil), heff_dup(v_defs_249)));
  V v_names_2412 = (g_list_2efoldl_24s1659194469x1936830512(v_t_2410, v_t_2411));
  V v_t_2413 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_facts_244; V a_2 = v_names_2412; V r_ = (g_heff_2ecompile_2eemitc_2eceOf(a_0, a_1, a_2)); heff_drop(v_names_2412); r_; });
  V v_t_2414 = (g_heff_2ecompile_2eemitc_2eprogramCE(v_runtime_240, NTAG(TAG_Nil), v_ending_248, v_defs_249, v_t_2413));
  return heff_rec_n(2, shape_source__errors, (V[]){v_t_2414, v_errors_245});
}
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2echeckOut(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ethreadsLine_str0, 22, "#define HEFF_THREADS 1");

static V g_heff_2ecompile_2eemitc_2ethreadsLine_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2ethreadsLine_st;
static V g_heff_2ecompile_2eemitc_2ethreadsLine_init(void) {
  return ((V)&g_heff_2ecompile_2eemitc_2ethreadsLine_str0);
}
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2ethreadsLine_st)) return g_heff_2ecompile_2eemitc_2ethreadsLine_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2ethreadsLine_val, &g_heff_2ecompile_2eemitc_2ethreadsLine_st, g_heff_2ecompile_2eemitc_2ethreadsLine_init);
}
Clo g_heff_2ecompile_2eemitc_2ecatMaybesC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ecatMaybesC_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2ecatMaybesC(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2eemitc_2ecatMaybesC_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2ecatMaybesC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2ecatMaybesC(a[0]);
}