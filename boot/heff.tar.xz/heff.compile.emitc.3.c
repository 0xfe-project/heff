// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CBool 61457
#define TAG_CDouble 41794
#define TAG_CInteger 35664
#define TAG_COwnedString 41814
#define TAG_CPointer 51967
#define TAG_CSharedPointer 39972
#define TAG_CString 35384
#define TAG_CText 64164
#define TAG_CVoid 1823
#define TAG_DoneOrErrno 39355
#define TAG_Gives 9364
#define TAG_GivesOrErrno 3434
#define TAG_MkCode 2932
#define TAG_MkWrapper 39179
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Tip 31527
#define LBL_answered 245579351
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_code 9554612
#define LBL_ems 310085
#define LBL_entry 298026124
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_flat 9641024
#define LBL_fresh 299054408
#define LBL_fun 311289
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lazy 9809979
#define LBL_lbls 9810500
#define LBL_lent 9813446
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_reprs 309759928
#define LBL_ret 322331
#define LBL_s 333
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tags 10047712
#define LBL_tuples 1084651734
#define LBL_ver 326173
#define LBL_words 314676931
#define LBL_workers 1757018875
#define LBL_wrapper 1827365593
static uint32_t shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words[] = {LBL_arity, LBL_bounce, LBL_lazy, LBL_lent, LBL_workers, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tuples, LBL_words};
static uint32_t shape_ems__s__fresh[] = {LBL_ems, LBL_s, LBL_fresh};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
static uint32_t shape_protos__code[] = {LBL_protos, LBL_code};
static uint32_t shape_tags__lbls__facts[] = {LBL_tags, LBL_lbls, LBL_facts};
V g_heff_2ecompile_2eemitc_2eanswerLines(V);
V g_heff_2ecompile_2eemitc_2eanswerLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eanswerLines_clo;
V g_heff_2ecompile_2eemitc_2ecallC(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallC_clo;
V g_heff_2ecompile_2eemitc_2eceOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eceOf_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
V g_heff_2ecompile_2eemitc_2edefC(V, V, V);
V g_heff_2ecompile_2eemitc_2edefC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edefC_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eemitAt(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eemitAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eemitAt_clo;
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void);
V g_heff_2ecompile_2eemitc_2eentryCall(V, V, V);
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eentryCall_clo;
V g_heff_2ecompile_2eemitc_2eexpF(V, V);
V g_heff_2ecompile_2eemitc_2eexpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eexpF_clo;
V g_heff_2ecompile_2eemitc_2efixedConst(V, V);
V g_heff_2ecompile_2eemitc_2efixedConst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedConst_clo;
V g_heff_2ecompile_2eemitc_2efixedLit(V, V);
V g_heff_2ecompile_2eemitc_2efixedLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedLit_clo;
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efreshEmitted(V, V, V, V);
V g_heff_2ecompile_2eemitc_2efreshEmitted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efreshEmitted_clo;
V g_heff_2ecompile_2eemitc_2efunDef(V, V, V);
V g_heff_2ecompile_2eemitc_2efunDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunDef_clo;
V g_heff_2ecompile_2eemitc_2efunHead(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2efunHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunHead_clo;
V g_heff_2ecompile_2eemitc_2eglueCallOf(V);
V g_heff_2ecompile_2eemitc_2eglueCallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglueCallOf_clo;
V g_heff_2ecompile_2eemitc_2ehashedGo(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ehashedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehashedGo_clo;
V g_heff_2ecompile_2eemitc_2einPlace(V);
V g_heff_2ecompile_2eemitc_2einPlace_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2einPlace_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2elamC(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamC_clo;
V g_heff_2ecompile_2eemitc_2elendingPrims_get(void);
V g_heff_2ecompile_2eemitc_2elentPrimC(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elentPrimC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentPrimC_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emergeKept(V, V, V);
V g_heff_2ecompile_2eemitc_2emergeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emergeKept_clo;
V g_heff_2ecompile_2eemitc_2enumbered(V, V, V);
V g_heff_2ecompile_2eemitc_2enumbered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enumbered_clo;
V g_heff_2ecompile_2eemitc_2eparamList(V, V);
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamList_clo;
V g_heff_2ecompile_2eemitc_2eprimLit(V, V);
V g_heff_2ecompile_2eemitc_2eprimLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimLit_clo;
V g_heff_2ecompile_2eemitc_2eprimU(V, V);
V g_heff_2ecompile_2eemitc_2eprimU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimU_clo;
V g_heff_2ecompile_2eemitc_2eresultTypeName(V);
V g_heff_2ecompile_2eemitc_2eresultTypeName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eresultTypeName_clo;
HeffT2 g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(V, V);
V g_heff_2ecompile_2eemitc_2eshapesOnlyHere(V, V);
V g_heff_2ecompile_2eemitc_2eshapesOnlyHere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapesOnlyHere_clo;
V g_heff_2ecompile_2eemitc_2estrLit(V, V, V);
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estrLit_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void);
V g_heff_2ecompile_2eemitc_2eupdateText(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eupdateText_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eupdateText_clo;
V g_heff_2ecompile_2eemitc_2ewrapped(V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapped_clo;
V g_heff_2ecompile_2eemitc_2ewrapperCode(V, V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapperCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapperCode_clo;
V g_heff_2ecompile_2eemitc_2ewrapperProto(V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapperProto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapperProto_clo;
V g_heff_2ecompile_2elower_2ecDef(V, V, V);
V g_heff_2ecompile_2elower_2ecDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecDef_clo;
V g_list_2eall_24s1909236649x7702533(V);
V g_list_2eall_24s1909236649x7702533_entry(V self, V *a);
extern Clo g_list_2eall_24s1909236649x7702533_clo;
V g_list_2eany_24s808001422x1111416318(V, V);
V g_list_2eany_24s808001422x1111416318_entry(V self, V *a);
extern Clo g_list_2eany_24s808001422x1111416318_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1967523567x64647275(V);
V g_list_2efilter_24s1967523567x64647275_entry(V self, V *a);
extern Clo g_list_2efilter_24s1967523567x64647275_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1882737314x358197882(V, V, V, V);
V g_list_2efoldl_24s1882737314x358197882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1882737314x358197882_clo;
V g_list_2efoldl_24s477184376x1963488659(V, V);
V g_list_2efoldl_24s477184376x1963488659_entry(V self, V *a);
extern Clo g_list_2efoldl_24s477184376x1963488659_clo;
V g_list_2efoldl_24s651278233x871164524(V, V);
V g_list_2efoldl_24s651278233x871164524_entry(V self, V *a);
extern Clo g_list_2efoldl_24s651278233x871164524_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24f1005417903x1119563692(V, V, V);
V g_list_2emap_24f1005417903x1119563692_entry(V self, V *a);
extern Clo g_list_2emap_24f1005417903x1119563692_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s706961545x2112949112(V, V, V, V, V);
V g_list_2ezipWith_24s706961545x2112949112_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s706961545x2112949112_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ecompile_2eemitc_2enumbered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enumbered_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2enumbered(V v_n_240, V v_x2_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_m_242, v_x_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        heff_drop(v_x_249);
        V t_0 = v_n_240;
        V t_1 = v_xs_244;
        V t_2 = v_m_242;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        v_m_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_2410 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_242, heff_dup(v_x_243), heff_dup(v_n_240)));
        V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
        V t_1 = v_xs_244;
        V t_2 = v_t_2410;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        v_m_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2enumbered_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enumbered(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str2, 11, " (uint64_t)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str3, 2, "))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str4, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str5, 12, ")((uint64_t)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str6, 2, "((");
Clo g_heff_2ecompile_2eemitc_2ewrapped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ewrapped_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ewrapped(V v_w_240, V v_op_241, V v_vs_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
  V v_t_246;
  switch (heff_tag_of(v_vs_242)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_vs_242, 0);
    v_t_246 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_vs_242);
  }
  HeffT3 v_t_247 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
  V v_t_2414;
  {
    V v_field_249 = v_t_247.f[1];
    V v_field_2410 = v_t_247.f[2];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2412 = v_field_249;
      V v_x12_2413 = v_field_2410;
      heff_drop(v_x12_2413);
      v_t_2414 = v_x_2412;
    } else {
      heff_drop(v_field_249);
      heff_drop(v_field_2410);
      v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str1);
    }
  }
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapped_str2), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str3)));
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapped_str4), heff_strAppend(v_op_241, v_t_2415));
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapped_str5), heff_strAppend(v_t_246, v_t_2416));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapped_str6), heff_strAppend(v_t_243, v_t_2417));
}
V g_heff_2ecompile_2eemitc_2ewrapped_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2ewrapped(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str1, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str3, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str5, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str7, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str8, 5, "_clo)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str9, 5, "((V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str11, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str12, 7, "_get())");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str13, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str15, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str16, 6, "_get()");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str17, 3, "LL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str18, 7, "MK_INT(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str19, 2, "\")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str20, 10, "HEFF_BIG(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str21, 2, "\")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str22, 10, "HEFF_BIG(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str23, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str24, 13, "heff_flt(NAN)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str25, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str26, 18, "heff_flt(INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str27, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str28, 19, "heff_flt(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str29, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str30, 9, "heff_flt(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str31, 8, "HEFF_LIT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str32, 10, "HEFF_BYTES");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str33, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str34, 16, "heff_f32((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str35, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str36, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str37, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str38, 5, "NTAG(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str39, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str40, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str41, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str42, 3, "){{");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str43, 3, "}})");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str44, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str45, 11, "heff_tag_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str46, 12, "heff_tag_nf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str47, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str48, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str49, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str50, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str51, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str52, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str53, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str54, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str55, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str56, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str57, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str58, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str59, 14, "heff_tag_at_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str60, 15, "heff_tag_at_nf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str61, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str62, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str63, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str64, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str65, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str66, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str67, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str68, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str69, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str70, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str71, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str72, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str73, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str74, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str75, 11, "heff_rec_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str76, 12, "heff_rec_nf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str77, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str78, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str79, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str80, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str81, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str82, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str83, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str84, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str85, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str86, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str87, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str88, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str89, 1, "u");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str90, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str91, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str92, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str93, 12, "heff_rfield(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str94, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str95, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str96, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str97, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str98, 12, "heff_rget_v(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str99, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str100, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str101, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str102, 11, "heff_get_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str103, 11, "heff_rflat_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str104, 10, "heff_rget_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str105, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str106, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str107, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str108, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str109, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str110, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str111, 15, "heff_get_nflat_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str112, 11, "heff_get_n_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str113, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str114, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str115, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str116, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str117, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str118, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str119, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str120, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str121, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str122, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str123, 10, "heff_word_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str124, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str125, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str126, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str127, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str128, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str129, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str130, 16, "heff_take_field(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str131, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str132, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str133, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str134, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str135, 9, "heff_get(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str136, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str137, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str138, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str139, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str140, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str141, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str142, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str143, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str144, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str145, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str146, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str147, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str148, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str149, 2, "))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str150, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str151, 18, "heff_tr(heff_call(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str152, 10, "heff_bool(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str153, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str154, 14, "heff_abandon()");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str155, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str156, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str157, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str158, 9, "heff_box_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str159, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str160, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str161, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str162, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str163, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str164, 11, "heff_unbox_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str165, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str166, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str167, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str168, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str169, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str170, 10, "heff_peek_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str171, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str172, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str173, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str174, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str175, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str176, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str177, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str178, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str179, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str180, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str181, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str182, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str183, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str184, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str185, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str186, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str187, 3, "NAN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str188, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str189, 8, "INFINITY");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str190, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str191, 11, "(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str192, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str193, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str194, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str195, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str196, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str197, 3, "NAN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str198, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str199, 8, "INFINITY");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str200, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str201, 11, "(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str202, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str203, 1, "(");
V g_heff_2ecompile_2eemitc_2eexpF_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam12(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam13(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam14(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam15(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam16(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam17(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam18(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam19(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam20(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam21(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam22(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam23(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam24(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam25(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam26(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2eexpF_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eexpF_lam26, 1, 0};
V g_heff_2ecompile_2eemitc_2eexpF_lam27(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam28(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam29(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam30(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam31(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam32(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam33(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam34(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eexpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eexpF_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eexpF(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_RLocal: {
    V v_x_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_243 = ({ V a_0 = v_x_242; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_242); r_; });
    V v_x_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str1), v_t_243);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam0, 1, 1, (V[]){v_x_244});
  }
  case TAG_RDup: {
    V v_x_246 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_247 = ({ V a_0 = v_x_246; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str2); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_246); r_; });
    V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str3), v_t_247), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str4));
    V v_x_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str5), v_t_248);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam1, 1, 1, (V[]){v_x_249});
  }
  case TAG_RClo: {
    V v_g_2411 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2412 = ({ V a_0 = v_g_2411; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str6); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_2411); r_; });
    V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str7), v_t_2412), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str8));
    V v_x_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str9), v_t_2413);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam2, 1, 1, (V[]){v_x_2414});
  }
  case TAG_RGet: {
    V v_g_2416 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2417 = ({ V a_0 = v_g_2416; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str10); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_2416); r_; });
    V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str11), v_t_2417), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str12));
    V v_x_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str13), v_t_2418);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam3, 1, 1, (V[]){v_x_2419});
  }
  case TAG_RGetRaw: {
    V v_g_2421 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2422 = ({ V a_0 = v_g_2421; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str14); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_2421); r_; });
    V v_x_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str15), v_t_2422), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str16));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam4, 1, 1, (V[]){v_x_2423});
  }
  case TAG_RInt: {
    V v_n_2425 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam5, 1, 1, (V[]){v_n_2425});
  }
  case TAG_RFloat: {
    V v_x_2433 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam6, 1, 1, (V[]){v_x_2433});
  }
  case TAG_RStr: {
    V v_s_2440 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2estrLit_clo), 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eexpF_str31), v_s_2440});
  }
  case TAG_RBytes: {
    V v_s_2441 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2estrLit_clo), 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eexpF_str32), v_s_2441});
  }
  case TAG_RFixed: {
    V v_w_2442 = heff_field(v_x2_241, 0);
    V v_n_2443 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_k_240, 6);
    V v_x_2444 = ({ V a_0 = v_w_2442; V a_1 = v_n_2443; V r_ = (g_heff_2ecompile_2eemitc_2efixedLit(a_0, a_1)); heff_drop(v_w_2442); r_; });
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam7, 1, 1, (V[]){v_x_2444});
  }
  case TAG_RF32: {
    V v_x_2446 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam8, 1, 1, (V[]){v_x_2446});
  }
  case TAG_RNTag: {
    V v_t_2449 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2450 = ({ V a_0 = v_t_2449; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str35); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2449); r_; });
    V v_t_2451 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str36), v_t_2450), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str37));
    V v_x_2452 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str38), v_t_2451);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam9, 1, 1, (V[]){v_x_2452});
  }
  case TAG_RTag: {
    V v_t_2454 = heff_field(v_x2_241, 0);
    V v_flat_2455 = heff_field(v_x2_241, 1);
    V v_es_2456 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2457 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), heff_dup(v_es_2456)));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam10, 1, 4, (V[]){v_m_2457, v_t_2454, v_es_2456, v_flat_2455});
  }
  case TAG_RTagIn: {
    V v_ru_2487 = heff_field(v_x2_241, 0);
    V v_t_2488 = heff_field(v_x2_241, 1);
    V v_flat_2489 = heff_field(v_x2_241, 2);
    V v_es_2490 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_2491 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), heff_tag_n(TAG_Cons, 2, (V[]){v_ru_2487, heff_dup(v_es_2490)})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam11, 1, 4, (V[]){v_m_2491, v_flat_2489, v_t_2488, v_es_2490});
  }
  case TAG_RRec: {
    V v_ls_24123 = heff_field(v_x2_241, 0);
    V v_flat_24124 = heff_field(v_x2_241, 1);
    V v_es_24125 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24126 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24125));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam12, 1, 3, (V[]){v_m_24126, v_ls_24123, v_flat_24124});
  }
  case TAG_RRecIn: {
    V v_x_24152 = heff_field(v_x2_241, 0);
    V v_keep_24153 = heff_field(v_x2_241, 1);
    V v_kept_24154 = heff_field(v_x2_241, 2);
    V v_flat_24155 = heff_field(v_x2_241, 3);
    V v_n_24156 = heff_field(v_x2_241, 4);
    V v_ls_24157 = heff_field(v_x2_241, 5);
    V v_changed_24158 = heff_field(v_x2_241, 6);
    V v_su_24159 = heff_field(v_x2_241, 7);
    heff_take_n(v_x2_241, 255ULL, 8);
    V v_t_24160 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_changed_24158)));
    V v_m_24161 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_t_24160));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam13, 1, 9, (V[]){v_m_24161, v_ls_24157, v_su_24159, v_flat_24155, v_kept_24154, v_changed_24158, v_x_24152, v_keep_24153, v_n_24156});
  }
  case TAG_RField: {
    V v_e_24176 = heff_field(v_x2_241, 0);
    V v_i_24177 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24178 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24176}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam14, 1, 2, (V[]){v_m_24178, v_i_24177});
  }
  case TAG_RDupE: {
    V v_e_24185 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_24186 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24185}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam15, 1, 1, (V[]){v_m_24186});
  }
  case TAG_RFieldV: {
    V v_e_24192 = heff_field(v_x2_241, 0);
    V v_i_24193 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24194 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24192}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam16, 1, 2, (V[]){v_m_24194, v_i_24193});
  }
  case TAG_RGetN: {
    V v_e_24201 = heff_field(v_x2_241, 0);
    V v_i_24202 = heff_field(v_x2_241, 1);
    V v_n_24203 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24204 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24201}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam17, 1, 3, (V[]){v_m_24204, v_n_24203, v_i_24202});
  }
  case TAG_RFieldU: {
    V v_r_24212 = heff_field(v_x2_241, 0);
    V v_su_24213 = heff_field(v_x2_241, 1);
    V v_e_24214 = heff_field(v_x2_241, 2);
    V v_i_24215 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_24216;
    if ((heff_dup(v_su_24213) == NTAG(TAG_True))) {
      heff_drop(v_su_24213);
      v_t_24216 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str103);
    } else {
      heff_drop(v_su_24213);
      v_t_24216 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str104);
    }
    V v_t_24218;
    switch (heff_tag_of(v_r_24212)) {
    case TAG_RepV: {
      v_t_24218 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str105);
      break;
    }
    case TAG_RepFix: {
      V v_w_24217 = heff_field(v_r_24212, 0);
      heff_take_n(v_r_24212, 1ULL, 1);
      v_t_24218 = ({ V a_0 = v_w_24217; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24217); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24218 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str106);
      break;
    }
    case TAG_RepInt: {
      v_t_24218 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str107);
      break;
    }
    default: heff_nomatch(v_r_24212);
    }
    V v_pre_24219 = heff_strAppend(v_t_24216, heff_strAppend(v_t_24218, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str108)));
    V v_m_24220 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24214}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam18, 1, 3, (V[]){v_m_24220, v_i_24215, v_pre_24219});
  }
  case TAG_RGetNU: {
    V v_r_24227 = heff_field(v_x2_241, 0);
    V v_su_24228 = heff_field(v_x2_241, 1);
    V v_e_24229 = heff_field(v_x2_241, 2);
    V v_i_24230 = heff_field(v_x2_241, 3);
    V v_n_24231 = heff_field(v_x2_241, 4);
    heff_take_n(v_x2_241, 31ULL, 5);
    V v_t_24232;
    if ((heff_dup(v_su_24228) == NTAG(TAG_True))) {
      heff_drop(v_su_24228);
      v_t_24232 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str111);
    } else {
      heff_drop(v_su_24228);
      v_t_24232 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str112);
    }
    V v_t_24234;
    switch (heff_tag_of(v_r_24227)) {
    case TAG_RepV: {
      v_t_24234 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str113);
      break;
    }
    case TAG_RepFix: {
      V v_w_24233 = heff_field(v_r_24227, 0);
      heff_take_n(v_r_24227, 1ULL, 1);
      v_t_24234 = ({ V a_0 = v_w_24233; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24233); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24234 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str114);
      break;
    }
    case TAG_RepInt: {
      v_t_24234 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str115);
      break;
    }
    default: heff_nomatch(v_r_24227);
    }
    V v_pre_24235 = heff_strAppend(v_t_24232, heff_strAppend(v_t_24234, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str116)));
    V v_m_24236 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24229}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam19, 1, 4, (V[]){v_m_24236, v_n_24231, v_i_24230, v_pre_24235});
  }
  case TAG_RWord: {
    V v_r_24244 = heff_field(v_x2_241, 0);
    V v_e_24245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24247;
    switch (heff_tag_of(v_r_24244)) {
    case TAG_RepV: {
      v_t_24247 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str120);
      break;
    }
    case TAG_RepFix: {
      V v_w_24246 = heff_field(v_r_24244, 0);
      heff_take_n(v_r_24244, 1ULL, 1);
      v_t_24247 = ({ V a_0 = v_w_24246; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24246); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24247 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str121);
      break;
    }
    case TAG_RepInt: {
      v_t_24247 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str122);
      break;
    }
    default: heff_nomatch(v_r_24244);
    }
    V v_pre_24248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str123), heff_strAppend(v_t_24247, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str124)));
    V v_m_24249 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24245}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam20, 1, 2, (V[]){v_m_24249, v_pre_24248});
  }
  case TAG_RTakeField: {
    V v_x_24255 = heff_field(v_x2_241, 0);
    V v_i_24256 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_k_240, 6);
    V v_t_24257 = ({ V a_0 = v_x_24255; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str126); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_24255); r_; });
    V v_t_24258 = heff_strAppend(heff_intShow(v_i_24256), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str127));
    V v_t_24259 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str128), v_t_24257), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str129), v_t_24258));
    V v_x_24260 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str130), v_t_24259);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam21, 1, 1, (V[]){v_x_24260});
  }
  case TAG_RGetLabel: {
    V v_e_24262 = heff_field(v_x2_241, 0);
    V v_l_24263 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24264 = ({ V a_0 = v_l_24263; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str131); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_l_24263); r_; });
    V v_t_24265 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str132), v_t_24264), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str133));
    V v_post_24266 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str134), v_t_24265);
    V v_m_24267 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24262}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam22, 1, 2, (V[]){v_m_24267, v_post_24266});
  }
  case TAG_RPrimFn: {
    V v_p_24273 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2eprimLit_clo), 1, (V[]){v_p_24273});
  }
  case TAG_RPrim: {
    V v_p_24274 = heff_field(v_x2_241, 0);
    V v_es_24275 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24276 = ({ V a_0 = v_p_24274; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2elendingPrims_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_24278;
    if ((heff_dup(v_t_24276) == NTAG(TAG_True))) {
      heff_drop(v_t_24276);
      V v_t_24277 = (g_list_2eall_24s1909236649x7702533(v_es_24275));
      if ((heff_dup(v_t_24277) == NTAG(TAG_True))) {
        heff_drop(v_t_24277);
        v_t_24278 = (g_list_2eany_24s808001422x1111416318(v_es_24275, v_es_24275));
      } else {
        heff_drop(v_t_24277);
        v_t_24278 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_t_24276);
      v_t_24278 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24278) == NTAG(TAG_True))) {
      heff_drop(v_t_24278);
      return (g_heff_2ecompile_2eemitc_2elentPrimC(v_k_240, v_p_24274, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str136), v_es_24275));
    } else {
      heff_drop(v_t_24278);
      V v_m_24279 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24275));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam23, 1, 2, (V[]){v_m_24279, v_p_24274});
    }
  }
  case TAG_RLam: {
    V v_xs_24289 = heff_field(v_x2_241, 0);
    V v_fv_24290 = heff_field(v_x2_241, 1);
    V v_held_24291 = heff_field(v_x2_241, 2);
    V v_x24_24292 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    switch (heff_tag_of(v_x24_24292)) {
    case TAG_MkCode: {
      V v_body_24293 = heff_field(v_x24_24292, 0);
      heff_take_n(v_x24_24292, 1ULL, 1);
      return heff_tail(((V)&g_heff_2ecompile_2eemitc_2elamC_clo), 5, (V[]){v_k_240, v_xs_24289, v_fv_24290, v_held_24291, v_body_24293});
    }
    default: return heff_nomatch(v_x24_24292);
    }
  }
  case TAG_RCall: {
    V v_g_24294 = heff_field(v_x2_241, 0);
    V v_tr_24295 = heff_field(v_x2_241, 1);
    V v_w_24296 = heff_field(v_x2_241, 2);
    V v_args_24297 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    return ({ V a_0 = v_k_240; V a_1 = v_g_24294; V a_2 = v_tr_24295; V a_3 = v_w_24296; V a_4 = v_args_24297; V r_ = (g_heff_2ecompile_2eemitc_2ecallC(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_g_24294); heff_drop(v_tr_24295); heff_drop(v_w_24296); r_; });
  }
  case TAG_RApply: {
    V v_f_24298 = heff_field(v_x2_241, 0);
    V v_es_24299 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RApply = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_24300 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), heff_tag_at_n(v_ru_24x2_241_24RApply, TAG_Cons, 2, (V[]){v_f_24298, heff_dup(v_es_24299)})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam24, 1, 2, (V[]){v_m_24300, v_es_24299});
  }
  case TAG_RBool: {
    V v_c_24325 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_24326 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_c_24325));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam25, 1, 1, (V[]){v_m_24326});
  }
  case TAG_RAbandon: {
    heff_drop_rec(v_k_240, 6);
    return ((V)&g_heff_2ecompile_2eemitc_2eexpF_lam26_clo);
  }
  case TAG_RBox: {
    V v_r_24333 = heff_field(v_x2_241, 0);
    V v_e_24334 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24336;
    switch (heff_tag_of(v_r_24333)) {
    case TAG_RepV: {
      v_t_24336 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str155);
      break;
    }
    case TAG_RepFix: {
      V v_w_24335 = heff_field(v_r_24333, 0);
      heff_take_n(v_r_24333, 1ULL, 1);
      v_t_24336 = ({ V a_0 = v_w_24335; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24335); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24336 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str156);
      break;
    }
    case TAG_RepInt: {
      v_t_24336 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str157);
      break;
    }
    default: heff_nomatch(v_r_24333);
    }
    V v_pre_24337 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str158), heff_strAppend(v_t_24336, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str159)));
    V v_m_24338 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24334}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam27, 1, 2, (V[]){v_m_24338, v_pre_24337});
  }
  case TAG_RUnbox: {
    V v_r_24344 = heff_field(v_x2_241, 0);
    V v_e_24345 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24347;
    switch (heff_tag_of(v_r_24344)) {
    case TAG_RepV: {
      v_t_24347 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str161);
      break;
    }
    case TAG_RepFix: {
      V v_w_24346 = heff_field(v_r_24344, 0);
      heff_take_n(v_r_24344, 1ULL, 1);
      v_t_24347 = ({ V a_0 = v_w_24346; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24346); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24347 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str162);
      break;
    }
    case TAG_RepInt: {
      v_t_24347 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str163);
      break;
    }
    default: heff_nomatch(v_r_24344);
    }
    V v_pre_24348 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str164), heff_strAppend(v_t_24347, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str165)));
    V v_m_24349 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24345}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam28, 1, 2, (V[]){v_m_24349, v_pre_24348});
  }
  case TAG_RPeek: {
    V v_r_24355 = heff_field(v_x2_241, 0);
    V v_e_24356 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24358;
    switch (heff_tag_of(v_r_24355)) {
    case TAG_RepV: {
      v_t_24358 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str167);
      break;
    }
    case TAG_RepFix: {
      V v_w_24357 = heff_field(v_r_24355, 0);
      heff_take_n(v_r_24355, 1ULL, 1);
      v_t_24358 = ({ V a_0 = v_w_24357; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24357); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24358 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str168);
      break;
    }
    case TAG_RepInt: {
      v_t_24358 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str169);
      break;
    }
    default: heff_nomatch(v_r_24355);
    }
    V v_pre_24359 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str170), heff_strAppend(v_t_24358, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str171)));
    V v_m_24360 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24356}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam29, 1, 2, (V[]){v_m_24360, v_pre_24359});
  }
  case TAG_RPrimU: {
    V v_p_24366 = heff_field(v_x2_241, 0);
    V v_es_24367 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24368 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24367));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam30, 1, 2, (V[]){v_m_24368, v_p_24366});
  }
  case TAG_RPrimAt: {
    V v_p_24374 = heff_field(v_x2_241, 0);
    V v_r_24375 = heff_field(v_x2_241, 1);
    V v_es_24376 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_24377 = ({ V a_0 = v_p_24374; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2elendingPrims_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_24379;
    if ((heff_dup(v_t_24377) == NTAG(TAG_True))) {
      heff_drop(v_t_24377);
      V v_t_24378 = (g_list_2eall_24s1909236649x7702533(v_es_24376));
      if ((heff_dup(v_t_24378) == NTAG(TAG_True))) {
        heff_drop(v_t_24378);
        v_t_24379 = (g_list_2eany_24s808001422x1111416318(v_es_24376, v_es_24376));
      } else {
        heff_drop(v_t_24378);
        v_t_24379 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_t_24377);
      v_t_24379 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24379) == NTAG(TAG_True))) {
      heff_drop(v_t_24379);
      V v_t_24381;
      switch (heff_tag_of(v_r_24375)) {
      case TAG_RepV: {
        v_t_24381 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str173);
        break;
      }
      case TAG_RepFix: {
        V v_w_24380 = heff_field(v_r_24375, 0);
        heff_take_n(v_r_24375, 1ULL, 1);
        v_t_24381 = ({ V a_0 = v_w_24380; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24380); r_; });
        break;
      }
      case TAG_RepF64: {
        v_t_24381 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str174);
        break;
      }
      case TAG_RepInt: {
        v_t_24381 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str175);
        break;
      }
      default: heff_nomatch(v_r_24375);
      }
      return (g_heff_2ecompile_2eemitc_2elentPrimC(v_k_240, v_p_24374, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str176), v_t_24381), v_es_24376));
    } else {
      heff_drop(v_t_24379);
      V v_m_24382 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24376));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam31, 1, 3, (V[]){v_m_24382, v_r_24375, v_p_24374});
    }
  }
  case TAG_RFixU: {
    V v_w_24395 = heff_field(v_x2_241, 0);
    V v_n_24396 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_k_240, 6);
    V v_x_24397 = ({ V a_0 = v_w_24395; V a_1 = v_n_24396; V r_ = (g_heff_2ecompile_2eemitc_2efixedConst(a_0, a_1)); heff_drop(v_w_24395); r_; });
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam32, 1, 1, (V[]){v_x_24397});
  }
  case TAG_RF32U: {
    V v_x_24399 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam33, 1, 1, (V[]){v_x_24399});
  }
  case TAG_RF64U: {
    V v_x_24407 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam34, 1, 1, (V[]){v_x_24407});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eexpF(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2eexpF_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_244, v_s_245});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_2410});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam2(V self, V *args) {
  V v_s_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2414, v_s_2415});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam3(V self, V *args) {
  V v_s_2420 = args[0];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_s_2420});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2423, v_s_2424});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam5(V self, V *args) {
  V v_s_2426 = args[0];
  V v_n_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432;
  if (heff_intLt_c_lent(v_n_2425, HEFF_BIG("4611686018427387904"), 2)) {
    if (heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_n_2425, 1)) {
      V v_t_2429 = heff_strAppend(heff_intShow(v_n_2425), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str17));
      v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str18), v_t_2429);
    } else {
      V v_t_2430 = heff_strAppend(heff_intShow(v_n_2425), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str19));
      v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str20), v_t_2430);
    }
  } else {
    V v_t_2431 = heff_strAppend(heff_intShow(v_n_2425), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str21));
    v_t_2432 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str22), v_t_2431);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2432, v_s_2426});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam6(V self, V *args) {
  V v_s_2434 = args[0];
  V v_x_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2439;
  if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2433)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str23))) {
    heff_drop(v_x_2433);
    v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str24);
  } else {
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2433)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str25))) {
      heff_drop(v_x_2433);
      v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str26);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2433)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str27))) {
        heff_drop(v_x_2433);
        v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str28);
      } else {
        V v_t_2438 = heff_strAppend(heff_floatShow(v_x_2433), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str29));
        v_t_2439 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str30), v_t_2438);
      }
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2439, v_s_2434});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam7(V self, V *args) {
  V v_s_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2444, v_s_2445});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam8(V self, V *args) {
  V v_s_2447 = args[0];
  V v_x_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_strAppend(heff_floatShow(v_x_2446), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str33));
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str34), v_t_2448), v_s_2447});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam9(V self, V *args) {
  V v_s_2453 = args[0];
  V v_x_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2452, v_s_2453});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam10(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_t_2454 = heff_env(self)[1];
  V v_es_2456 = heff_env(self)[2];
  V v_flat_2455 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    V v_t_2463 = heff_bool(((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2454, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_t_2454, MK_INT(0LL), 2)) == ((int64_t)35ULL))));
    V v_x_2486;
    if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
      heff_drop(v_t_2454);
      heff_drop(v_flat_2455);
      heff_drop(v_t_2463);
      V v_n_2464 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2456; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2456); r_; });
      V v_t_2465 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str39), heff_intShow(v_n_2464));
      V v_t_2468;
      switch (heff_tag_of(v_x_2460)) {
      case TAG_Nil: {
        v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str40);
        break;
      }
      case TAG_Cons: {
        V v_x_2466 = heff_field(v_x_2460, 0);
        V v_xs_2467 = heff_field(v_x_2460, 1);
        heff_take_n(v_x_2460, 3ULL, 2);
        v_t_2468 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str41); V a_1 = v_x_2466; V a_2 = v_xs_2467; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2467); r_; });
        break;
      }
      default: heff_nomatch(v_x_2460);
      }
      V v_t_2469 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str42), heff_strAppend(v_t_2468, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str43)));
      v_x_2486 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str44), heff_strAppend(v_t_2465, v_t_2469));
    } else {
      heff_drop(v_t_2463);
      V v_t_2471;
      if (heff_intEq_c_lent(v_flat_2455, MK_INT(0LL), 2)) {
        v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str45);
      } else {
        v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str46);
      }
      V v_t_2472 = ({ V a_0 = v_t_2454; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str47); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2454); r_; });
      V v_t_2473 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2456; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2456); r_; });
      V v_t_2476;
      if (heff_intEq_c_lent(v_flat_2455, MK_INT(0LL), 2)) {
        heff_drop(v_flat_2455);
        v_t_2476 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str48);
      } else {
        V v_t_2475 = heff_strAppend(heff_intShow(v_flat_2455), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str49));
        v_t_2476 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str50), v_t_2475);
      }
      V v_t_2482;
      switch (heff_tag_of(v_x_2460)) {
      case TAG_Nil: {
        v_t_2482 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str51);
        break;
      }
      case TAG_Cons: {
        V v_t_2481;
        switch (heff_tag_of(v_x_2460)) {
        case TAG_Nil: {
          v_t_2481 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str52);
          break;
        }
        case TAG_Cons: {
          V v_x_2479 = heff_field(v_x_2460, 0);
          V v_xs_2480 = heff_field(v_x_2460, 1);
          heff_take_n(v_x_2460, 3ULL, 2);
          v_t_2481 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str53); V a_1 = v_x_2479; V a_2 = v_xs_2480; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2480); r_; });
          break;
        }
        default: heff_nomatch(v_x_2460);
        }
        v_t_2482 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str54), heff_strAppend(v_t_2481, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str55)));
        break;
      }
      default: heff_nomatch(v_x_2460);
      }
      V v_t_2483 = heff_strAppend(v_t_2476, heff_strAppend(v_t_2482, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str56)));
      V v_t_2484 = heff_strAppend(heff_intShow(v_t_2473), v_t_2483);
      V v_t_2485 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str57), v_t_2472), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str58), v_t_2484));
      v_x_2486 = heff_strAppend(v_t_2471, v_t_2485);
    }
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){v_x_2486, v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam11(V self, V *args) {
  V v_s_2492 = args[0];
  V v_m_2491 = heff_env(self)[0];
  V v_flat_2489 = heff_env(self)[1];
  V v_t_2488 = heff_env(self)[2];
  V v_es_2490 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2493 = heff_tr(heff_call(v_m_2491, 1, (V[]){v_s_2492}));
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_MkPair: {
    V v_x_2494 = heff_field(v_x2_2493, 0);
    V v_s_2495 = heff_field(v_x2_2493, 1);
    V v_ru_24x2_2493_24MkPair = heff_take_reuse_n(v_x2_2493, 3ULL, 2);
    V v_t_2497;
    if (heff_intEq_c_lent(v_flat_2489, MK_INT(0LL), 2)) {
      v_t_2497 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str59);
    } else {
      v_t_2497 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str60);
    }
    V v_t_24100;
    switch (heff_tag_of(v_x_2494)) {
    case TAG_Nil: {
      v_t_24100 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str61);
      break;
    }
    case TAG_Cons: {
      V v_x_2498 = heff_dup(heff_field(v_x_2494, 0));
      v_t_24100 = v_x_2498;
      break;
    }
    default: heff_nomatch(v_x_2494);
    }
    V v_t_24101 = ({ V a_0 = v_t_2488; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str62); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2488); r_; });
    V v_t_24102 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2490; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2490); r_; });
    V v_t_24105;
    if (heff_intEq_c_lent(v_flat_2489, MK_INT(0LL), 2)) {
      heff_drop(v_flat_2489);
      v_t_24105 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str63);
    } else {
      V v_t_24104 = heff_strAppend(heff_intShow(v_flat_2489), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str64));
      v_t_24105 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str65), v_t_24104);
    }
    HeffT3 v_t_24106 = ({ V a_0 = MK_INT(1LL); V a_1 = v_x_2494; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_x_2494); r_; });
    V v_t_24117;
    {
      V v_field_24108 = v_t_24106.f[1];
      V v_field_24109 = v_t_24106.f[2];
      int64_t v_tag_24107 = ((int64_t)v_t_24106.f[0]);
      if ((v_tag_24107 == ((int64_t)0ULL))) {
        V v_x11_24111 = heff_dup(v_field_24108);
        heff_drop(v_x11_24111);
        V v_x12_24112 = heff_dup(v_field_24109);
        heff_drop(v_x12_24112);
        V v_t_24116;
        if ((v_tag_24107 == ((int64_t)0ULL))) {
          V v_x_24114 = v_field_24108;
          V v_xs_24115 = v_field_24109;
          v_t_24116 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str66); V a_1 = v_x_24114; V a_2 = v_xs_24115; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24115); r_; });
        } else {
          heff_drop(v_field_24108);
          heff_drop(v_field_24109);
          v_t_24116 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str67);
        }
        v_t_24117 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str68), heff_strAppend(v_t_24116, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str69)));
      } else {
        heff_drop(v_field_24108);
        heff_drop(v_field_24109);
        v_t_24117 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str70);
      }
    }
    V v_t_24118 = heff_strAppend(v_t_24105, heff_strAppend(v_t_24117, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str71)));
    V v_t_24119 = heff_strAppend(heff_intShow(v_t_24102), v_t_24118);
    V v_t_24120 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str72), v_t_24101), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str73), v_t_24119));
    V v_t_24121 = heff_strAppend(v_t_24100, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str74), v_t_24120));
    V v_x_24122 = heff_strAppend(v_t_2497, v_t_24121);
    return heff_tag_at_n(v_ru_24x2_2493_24MkPair, TAG_MkPair, 2, (V[]){v_x_24122, v_s_2495});
  }
  default: return heff_nomatch(v_x2_2493);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam12(V self, V *args) {
  V v_s_24127 = args[0];
  V v_m_24126 = heff_env(self)[0];
  V v_ls_24123 = heff_env(self)[1];
  V v_flat_24124 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24128 = heff_tr(heff_call(v_m_24126, 1, (V[]){v_s_24127}));
  switch (heff_tag_of(v_x2_24128)) {
  case TAG_MkPair: {
    V v_x_24129 = heff_field(v_x2_24128, 0);
    V v_s_24130 = heff_field(v_x2_24128, 1);
    V v_ru_24x2_24128_24MkPair = heff_take_reuse_n(v_x2_24128, 3ULL, 2);
    HeffT2 v_t_24131 = (g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(heff_dup(v_ls_24123), v_s_24130));
    {
      V v_field_24132 = v_t_24131.f[0];
      V v_field_24133 = v_t_24131.f[1];
      V v_x_24134 = v_field_24132;
      V v_s_24135 = v_field_24133;
      V v_t_24137;
      if (heff_intEq_c_lent(v_flat_24124, MK_INT(0LL), 2)) {
        v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str75);
      } else {
        v_t_24137 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str76);
      }
      V v_t_24138 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ls_24123; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ls_24123); r_; });
      V v_t_24141;
      if (heff_intEq_c_lent(v_flat_24124, MK_INT(0LL), 2)) {
        heff_drop(v_flat_24124);
        v_t_24141 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str77);
      } else {
        V v_t_24140 = heff_strAppend(heff_intShow(v_flat_24124), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str78));
        v_t_24141 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str79), v_t_24140);
      }
      V v_t_24147;
      switch (heff_tag_of(v_x_24129)) {
      case TAG_Nil: {
        v_t_24147 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str80);
        break;
      }
      case TAG_Cons: {
        V v_t_24146;
        switch (heff_tag_of(v_x_24129)) {
        case TAG_Nil: {
          v_t_24146 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str81);
          break;
        }
        case TAG_Cons: {
          V v_x_24144 = heff_field(v_x_24129, 0);
          V v_xs_24145 = heff_field(v_x_24129, 1);
          heff_take_n(v_x_24129, 3ULL, 2);
          v_t_24146 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str82); V a_1 = v_x_24144; V a_2 = v_xs_24145; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24145); r_; });
          break;
        }
        default: heff_nomatch(v_x_24129);
        }
        v_t_24147 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str83), heff_strAppend(v_t_24146, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str84)));
        break;
      }
      default: heff_nomatch(v_x_24129);
      }
      V v_t_24148 = heff_strAppend(v_t_24141, heff_strAppend(v_t_24147, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str85)));
      V v_t_24149 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str86), heff_strAppend(v_x_24134, v_t_24148));
      V v_t_24150 = heff_strAppend(heff_intShow(v_t_24138), v_t_24149);
      V v_x_24151 = heff_strAppend(v_t_24137, v_t_24150);
      return heff_tag_at_n(v_ru_24x2_24128_24MkPair, TAG_MkPair, 2, (V[]){v_x_24151, v_s_24135});
    }
  }
  default: return heff_nomatch(v_x2_24128);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam13(V self, V *args) {
  V v_s_24162 = args[0];
  V v_m_24161 = heff_env(self)[0];
  V v_ls_24157 = heff_env(self)[1];
  V v_su_24159 = heff_env(self)[2];
  V v_flat_24155 = heff_env(self)[3];
  V v_kept_24154 = heff_env(self)[4];
  V v_changed_24158 = heff_env(self)[5];
  V v_x_24152 = heff_env(self)[6];
  V v_keep_24153 = heff_env(self)[7];
  V v_n_24156 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x2_24163 = heff_tr(heff_call(v_m_24161, 1, (V[]){v_s_24162}));
  switch (heff_tag_of(v_x2_24163)) {
  case TAG_MkPair: {
    V v_x_24164 = heff_field(v_x2_24163, 0);
    V v_s_24165 = heff_field(v_x2_24163, 1);
    V v_ru_24x2_24163_24MkPair = heff_take_reuse_n(v_x2_24163, 3ULL, 2);
    HeffT2 v_t_24166 = (g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(v_ls_24157, v_s_24165));
    {
      V v_field_24167 = v_t_24166.f[0];
      V v_field_24168 = v_t_24166.f[1];
      V v_x_24169 = v_field_24167;
      V v_s_24170 = v_field_24168;
      V v_t_24171;
      if ((heff_dup(v_su_24159) == NTAG(TAG_True))) {
        heff_drop(v_su_24159);
        v_t_24171 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str87);
      } else {
        heff_drop(v_su_24159);
        v_t_24171 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str88);
      }
      V v_t_24172 = heff_strAppend(heff_intShow(v_flat_24155), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str89));
      V v_t_24173 = heff_strAppend(heff_intShow(v_kept_24154), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str90), v_t_24172));
      V v_t_24174 = (g_list_2emap_24s1937570095x2110149801(v_changed_24158));
      V v_x_24175 = ({ V a_0 = v_t_24171; V a_1 = v_x_24152; V a_2 = v_x_24169; V a_3 = v_keep_24153; V a_4 = v_t_24173; V a_5 = v_n_24156; V a_6 = v_x_24164; V a_7 = v_t_24174; V r_ = (g_heff_2ecompile_2eemitc_2eupdateText(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_24152); r_; });
      return heff_tag_at_n(v_ru_24x2_24163_24MkPair, TAG_MkPair, 2, (V[]){v_x_24175, v_s_24170});
    }
  }
  default: return heff_nomatch(v_x2_24163);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam14(V self, V *args) {
  V v_s_24179 = args[0];
  V v_m_24178 = heff_env(self)[0];
  V v_i_24177 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24180 = heff_tr(heff_call(v_m_24178, 1, (V[]){v_s_24179}));
  switch (heff_tag_of(v_x2_24180)) {
  case TAG_MkPair: {
    V v_x_24181 = heff_field(v_x2_24180, 0);
    V v_s_24182 = heff_field(v_x2_24180, 1);
    V v_ru_24x2_24180_24MkPair = heff_take_reuse_n(v_x2_24180, 3ULL, 2);
    V v_t_24183 = heff_strAppend(heff_intShow(v_i_24177), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str91));
    V v_t_24184 = heff_strAppend(v_x_24181, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str92), v_t_24183));
    return heff_tag_at_n(v_ru_24x2_24180_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str93), v_t_24184), v_s_24182});
  }
  default: return heff_nomatch(v_x2_24180);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam15(V self, V *args) {
  V v_s_24187 = args[0];
  V v_m_24186 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24188 = heff_tr(heff_call(v_m_24186, 1, (V[]){v_s_24187}));
  switch (heff_tag_of(v_x2_24188)) {
  case TAG_MkPair: {
    V v_x_24189 = heff_field(v_x2_24188, 0);
    V v_s_24190 = heff_field(v_x2_24188, 1);
    V v_ru_24x2_24188_24MkPair = heff_take_reuse_n(v_x2_24188, 3ULL, 2);
    V v_t_24191 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str94), heff_strAppend(v_x_24189, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str95)));
    return heff_tag_at_n(v_ru_24x2_24188_24MkPair, TAG_MkPair, 2, (V[]){v_t_24191, v_s_24190});
  }
  default: return heff_nomatch(v_x2_24188);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam16(V self, V *args) {
  V v_s_24195 = args[0];
  V v_m_24194 = heff_env(self)[0];
  V v_i_24193 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24196 = heff_tr(heff_call(v_m_24194, 1, (V[]){v_s_24195}));
  switch (heff_tag_of(v_x2_24196)) {
  case TAG_MkPair: {
    V v_x_24197 = heff_field(v_x2_24196, 0);
    V v_s_24198 = heff_field(v_x2_24196, 1);
    V v_ru_24x2_24196_24MkPair = heff_take_reuse_n(v_x2_24196, 3ULL, 2);
    V v_t_24199 = heff_strAppend(heff_intShow(v_i_24193), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str96));
    V v_t_24200 = heff_strAppend(v_x_24197, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str97), v_t_24199));
    return heff_tag_at_n(v_ru_24x2_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str98), v_t_24200), v_s_24198});
  }
  default: return heff_nomatch(v_x2_24196);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam17(V self, V *args) {
  V v_s_24205 = args[0];
  V v_m_24204 = heff_env(self)[0];
  V v_n_24203 = heff_env(self)[1];
  V v_i_24202 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24206 = heff_tr(heff_call(v_m_24204, 1, (V[]){v_s_24205}));
  switch (heff_tag_of(v_x2_24206)) {
  case TAG_MkPair: {
    V v_x_24207 = heff_field(v_x2_24206, 0);
    V v_s_24208 = heff_field(v_x2_24206, 1);
    V v_ru_24x2_24206_24MkPair = heff_take_reuse_n(v_x2_24206, 3ULL, 2);
    V v_t_24209 = heff_strAppend(heff_intShow(v_n_24203), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str99));
    V v_t_24210 = heff_strAppend(heff_intShow(v_i_24202), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str100), v_t_24209));
    V v_t_24211 = heff_strAppend(v_x_24207, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str101), v_t_24210));
    return heff_tag_at_n(v_ru_24x2_24206_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str102), v_t_24211), v_s_24208});
  }
  default: return heff_nomatch(v_x2_24206);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam18(V self, V *args) {
  V v_s_24221 = args[0];
  V v_m_24220 = heff_env(self)[0];
  V v_i_24215 = heff_env(self)[1];
  V v_pre_24219 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24222 = heff_tr(heff_call(v_m_24220, 1, (V[]){v_s_24221}));
  switch (heff_tag_of(v_x2_24222)) {
  case TAG_MkPair: {
    V v_x_24223 = heff_field(v_x2_24222, 0);
    V v_s_24224 = heff_field(v_x2_24222, 1);
    V v_ru_24x2_24222_24MkPair = heff_take_reuse_n(v_x2_24222, 3ULL, 2);
    V v_t_24225 = heff_strAppend(heff_intShow(v_i_24215), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str109));
    V v_t_24226 = heff_strAppend(v_x_24223, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str110), v_t_24225));
    return heff_tag_at_n(v_ru_24x2_24222_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_pre_24219, v_t_24226), v_s_24224});
  }
  default: return heff_nomatch(v_x2_24222);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam19(V self, V *args) {
  V v_s_24237 = args[0];
  V v_m_24236 = heff_env(self)[0];
  V v_n_24231 = heff_env(self)[1];
  V v_i_24230 = heff_env(self)[2];
  V v_pre_24235 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24238 = heff_tr(heff_call(v_m_24236, 1, (V[]){v_s_24237}));
  switch (heff_tag_of(v_x2_24238)) {
  case TAG_MkPair: {
    V v_x_24239 = heff_field(v_x2_24238, 0);
    V v_s_24240 = heff_field(v_x2_24238, 1);
    V v_ru_24x2_24238_24MkPair = heff_take_reuse_n(v_x2_24238, 3ULL, 2);
    V v_t_24241 = heff_strAppend(heff_intShow(v_n_24231), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str117));
    V v_t_24242 = heff_strAppend(heff_intShow(v_i_24230), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str118), v_t_24241));
    V v_t_24243 = heff_strAppend(v_x_24239, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str119), v_t_24242));
    return heff_tag_at_n(v_ru_24x2_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_pre_24235, v_t_24243), v_s_24240});
  }
  default: return heff_nomatch(v_x2_24238);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam20(V self, V *args) {
  V v_s_24250 = args[0];
  V v_m_24249 = heff_env(self)[0];
  V v_pre_24248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24251 = heff_tr(heff_call(v_m_24249, 1, (V[]){v_s_24250}));
  switch (heff_tag_of(v_x2_24251)) {
  case TAG_MkPair: {
    V v_x_24252 = heff_field(v_x2_24251, 0);
    V v_s_24253 = heff_field(v_x2_24251, 1);
    V v_ru_24x2_24251_24MkPair = heff_take_reuse_n(v_x2_24251, 3ULL, 2);
    V v_t_24254 = heff_strAppend(v_pre_24248, heff_strAppend(v_x_24252, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str125)));
    return heff_tag_at_n(v_ru_24x2_24251_24MkPair, TAG_MkPair, 2, (V[]){v_t_24254, v_s_24253});
  }
  default: return heff_nomatch(v_x2_24251);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam21(V self, V *args) {
  V v_s_24261 = args[0];
  V v_x_24260 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24260, v_s_24261});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam22(V self, V *args) {
  V v_s_24268 = args[0];
  V v_m_24267 = heff_env(self)[0];
  V v_post_24266 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24269 = heff_tr(heff_call(v_m_24267, 1, (V[]){v_s_24268}));
  switch (heff_tag_of(v_x2_24269)) {
  case TAG_MkPair: {
    V v_x_24270 = heff_field(v_x2_24269, 0);
    V v_s_24271 = heff_field(v_x2_24269, 1);
    V v_ru_24x2_24269_24MkPair = heff_take_reuse_n(v_x2_24269, 3ULL, 2);
    V v_t_24272 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str135), heff_strAppend(v_x_24270, v_post_24266));
    return heff_tag_at_n(v_ru_24x2_24269_24MkPair, TAG_MkPair, 2, (V[]){v_t_24272, v_s_24271});
  }
  default: return heff_nomatch(v_x2_24269);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam23(V self, V *args) {
  V v_s_24280 = args[0];
  V v_m_24279 = heff_env(self)[0];
  V v_p_24274 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24281 = heff_tr(heff_call(v_m_24279, 1, (V[]){v_s_24280}));
  switch (heff_tag_of(v_x2_24281)) {
  case TAG_MkPair: {
    V v_x_24282 = heff_field(v_x2_24281, 0);
    V v_s_24283 = heff_field(v_x2_24281, 1);
    V v_ru_24x2_24281_24MkPair = heff_take_reuse_n(v_x2_24281, 3ULL, 2);
    V v_t_24286;
    switch (heff_tag_of(v_x_24282)) {
    case TAG_Nil: {
      v_t_24286 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str137);
      break;
    }
    case TAG_Cons: {
      V v_x_24284 = heff_field(v_x_24282, 0);
      V v_xs_24285 = heff_field(v_x_24282, 1);
      heff_take_n(v_x_24282, 3ULL, 2);
      v_t_24286 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str138); V a_1 = v_x_24284; V a_2 = v_xs_24285; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24285); r_; });
      break;
    }
    default: heff_nomatch(v_x_24282);
    }
    V v_t_24287 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str139), heff_strAppend(v_t_24286, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str140)));
    V v_x_24288 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str141), v_p_24274), v_t_24287);
    return heff_tag_at_n(v_ru_24x2_24281_24MkPair, TAG_MkPair, 2, (V[]){v_x_24288, v_s_24283});
  }
  default: return heff_nomatch(v_x2_24281);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam24(V self, V *args) {
  V v_s_24301 = args[0];
  V v_m_24300 = heff_env(self)[0];
  V v_es_24299 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24302 = heff_tr(heff_call(v_m_24300, 1, (V[]){v_s_24301}));
  switch (heff_tag_of(v_x2_24302)) {
  case TAG_MkPair: {
    V v_x_24303 = heff_field(v_x2_24302, 0);
    V v_s_24304 = heff_field(v_x2_24302, 1);
    V v_ru_24x2_24302_24MkPair = heff_take_reuse_n(v_x2_24302, 3ULL, 2);
    V v_t_24307;
    switch (heff_tag_of(v_x_24303)) {
    case TAG_Nil: {
      v_t_24307 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str142);
      break;
    }
    case TAG_Cons: {
      V v_x_24305 = heff_dup(heff_field(v_x_24303, 0));
      v_t_24307 = v_x_24305;
      break;
    }
    default: heff_nomatch(v_x_24303);
    }
    V v_t_24308 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_24299; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_24299); r_; });
    HeffT3 v_t_24309 = ({ V a_0 = MK_INT(1LL); V a_1 = v_x_24303; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_x_24303); r_; });
    V v_t_24320;
    {
      V v_field_24311 = v_t_24309.f[1];
      V v_field_24312 = v_t_24309.f[2];
      int64_t v_tag_24310 = ((int64_t)v_t_24309.f[0]);
      if ((v_tag_24310 == ((int64_t)0ULL))) {
        V v_x11_24314 = heff_dup(v_field_24311);
        heff_drop(v_x11_24314);
        V v_x12_24315 = heff_dup(v_field_24312);
        heff_drop(v_x12_24315);
        V v_t_24319;
        if ((v_tag_24310 == ((int64_t)0ULL))) {
          V v_x_24317 = v_field_24311;
          V v_xs_24318 = v_field_24312;
          v_t_24319 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str143); V a_1 = v_x_24317; V a_2 = v_xs_24318; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24318); r_; });
        } else {
          heff_drop(v_field_24311);
          heff_drop(v_field_24312);
          v_t_24319 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str144);
        }
        v_t_24320 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str145), heff_strAppend(v_t_24319, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str146)));
      } else {
        heff_drop(v_field_24311);
        heff_drop(v_field_24312);
        v_t_24320 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str147);
      }
    }
    V v_t_24321 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str148), heff_strAppend(v_t_24320, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str149)));
    V v_t_24322 = heff_strAppend(heff_intShow(v_t_24308), v_t_24321);
    V v_t_24323 = heff_strAppend(v_t_24307, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str150), v_t_24322));
    V v_x_24324 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str151), v_t_24323);
    return heff_tag_at_n(v_ru_24x2_24302_24MkPair, TAG_MkPair, 2, (V[]){v_x_24324, v_s_24304});
  }
  default: return heff_nomatch(v_x2_24302);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam25(V self, V *args) {
  V v_s_24327 = args[0];
  V v_m_24326 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24328 = heff_tr(heff_call(v_m_24326, 1, (V[]){v_s_24327}));
  switch (heff_tag_of(v_x2_24328)) {
  case TAG_MkPair: {
    V v_x_24329 = heff_field(v_x2_24328, 0);
    V v_s_24330 = heff_field(v_x2_24328, 1);
    V v_ru_24x2_24328_24MkPair = heff_take_reuse_n(v_x2_24328, 3ULL, 2);
    V v_t_24331 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str152), heff_strAppend(v_x_24329, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str153)));
    return heff_tag_at_n(v_ru_24x2_24328_24MkPair, TAG_MkPair, 2, (V[]){v_t_24331, v_s_24330});
  }
  default: return heff_nomatch(v_x2_24328);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam26(V self, V *args) {
  V v_s_24332 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eexpF_str154), v_s_24332});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam27(V self, V *args) {
  V v_s_24339 = args[0];
  V v_m_24338 = heff_env(self)[0];
  V v_pre_24337 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24340 = heff_tr(heff_call(v_m_24338, 1, (V[]){v_s_24339}));
  switch (heff_tag_of(v_x2_24340)) {
  case TAG_MkPair: {
    V v_x_24341 = heff_field(v_x2_24340, 0);
    V v_s_24342 = heff_field(v_x2_24340, 1);
    V v_ru_24x2_24340_24MkPair = heff_take_reuse_n(v_x2_24340, 3ULL, 2);
    V v_t_24343 = heff_strAppend(v_pre_24337, heff_strAppend(v_x_24341, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str160)));
    return heff_tag_at_n(v_ru_24x2_24340_24MkPair, TAG_MkPair, 2, (V[]){v_t_24343, v_s_24342});
  }
  default: return heff_nomatch(v_x2_24340);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam28(V self, V *args) {
  V v_s_24350 = args[0];
  V v_m_24349 = heff_env(self)[0];
  V v_pre_24348 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24351 = heff_tr(heff_call(v_m_24349, 1, (V[]){v_s_24350}));
  switch (heff_tag_of(v_x2_24351)) {
  case TAG_MkPair: {
    V v_x_24352 = heff_field(v_x2_24351, 0);
    V v_s_24353 = heff_field(v_x2_24351, 1);
    V v_ru_24x2_24351_24MkPair = heff_take_reuse_n(v_x2_24351, 3ULL, 2);
    V v_t_24354 = heff_strAppend(v_pre_24348, heff_strAppend(v_x_24352, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str166)));
    return heff_tag_at_n(v_ru_24x2_24351_24MkPair, TAG_MkPair, 2, (V[]){v_t_24354, v_s_24353});
  }
  default: return heff_nomatch(v_x2_24351);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam29(V self, V *args) {
  V v_s_24361 = args[0];
  V v_m_24360 = heff_env(self)[0];
  V v_pre_24359 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24362 = heff_tr(heff_call(v_m_24360, 1, (V[]){v_s_24361}));
  switch (heff_tag_of(v_x2_24362)) {
  case TAG_MkPair: {
    V v_x_24363 = heff_field(v_x2_24362, 0);
    V v_s_24364 = heff_field(v_x2_24362, 1);
    V v_ru_24x2_24362_24MkPair = heff_take_reuse_n(v_x2_24362, 3ULL, 2);
    V v_t_24365 = heff_strAppend(v_pre_24359, heff_strAppend(v_x_24363, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str172)));
    return heff_tag_at_n(v_ru_24x2_24362_24MkPair, TAG_MkPair, 2, (V[]){v_t_24365, v_s_24364});
  }
  default: return heff_nomatch(v_x2_24362);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam30(V self, V *args) {
  V v_s_24369 = args[0];
  V v_m_24368 = heff_env(self)[0];
  V v_p_24366 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24370 = heff_tr(heff_call(v_m_24368, 1, (V[]){v_s_24369}));
  switch (heff_tag_of(v_x2_24370)) {
  case TAG_MkPair: {
    V v_x_24371 = heff_field(v_x2_24370, 0);
    V v_s_24372 = heff_field(v_x2_24370, 1);
    V v_ru_24x2_24370_24MkPair = heff_take_reuse_n(v_x2_24370, 3ULL, 2);
    V v_x_24373 = ({ V a_0 = v_p_24366; V a_1 = v_x_24371; V r_ = (g_heff_2ecompile_2eemitc_2eprimU(a_0, a_1)); heff_drop(v_x_24371); r_; });
    return heff_tag_at_n(v_ru_24x2_24370_24MkPair, TAG_MkPair, 2, (V[]){v_x_24373, v_s_24372});
  }
  default: return heff_nomatch(v_x2_24370);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam31(V self, V *args) {
  V v_s_24383 = args[0];
  V v_m_24382 = heff_env(self)[0];
  V v_r_24375 = heff_env(self)[1];
  V v_p_24374 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24384 = heff_tr(heff_call(v_m_24382, 1, (V[]){v_s_24383}));
  switch (heff_tag_of(v_x2_24384)) {
  case TAG_MkPair: {
    V v_x_24385 = heff_field(v_x2_24384, 0);
    V v_s_24386 = heff_field(v_x2_24384, 1);
    V v_ru_24x2_24384_24MkPair = heff_take_reuse_n(v_x2_24384, 3ULL, 2);
    V v_t_24388;
    switch (heff_tag_of(v_r_24375)) {
    case TAG_RepV: {
      v_t_24388 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str177);
      break;
    }
    case TAG_RepFix: {
      V v_w_24387 = heff_field(v_r_24375, 0);
      heff_take_n(v_r_24375, 1ULL, 1);
      v_t_24388 = ({ V a_0 = v_w_24387; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24387); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24388 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str178);
      break;
    }
    case TAG_RepInt: {
      v_t_24388 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str179);
      break;
    }
    default: heff_nomatch(v_r_24375);
    }
    V v_t_24391;
    switch (heff_tag_of(v_x_24385)) {
    case TAG_Nil: {
      v_t_24391 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str180);
      break;
    }
    case TAG_Cons: {
      V v_x_24389 = heff_field(v_x_24385, 0);
      V v_xs_24390 = heff_field(v_x_24385, 1);
      heff_take_n(v_x_24385, 3ULL, 2);
      v_t_24391 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str181); V a_1 = v_x_24389; V a_2 = v_xs_24390; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24390); r_; });
      break;
    }
    default: heff_nomatch(v_x_24385);
    }
    V v_t_24392 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str182), heff_strAppend(v_t_24391, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str183)));
    V v_t_24393 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str184), heff_strAppend(v_t_24388, v_t_24392));
    V v_x_24394 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str185), v_p_24374), v_t_24393);
    return heff_tag_at_n(v_ru_24x2_24384_24MkPair, TAG_MkPair, 2, (V[]){v_x_24394, v_s_24386});
  }
  default: return heff_nomatch(v_x2_24384);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam32(V self, V *args) {
  V v_s_24398 = args[0];
  V v_x_24397 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24397, v_s_24398});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam33(V self, V *args) {
  V v_s_24400 = args[0];
  V v_x_24399 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24405;
  if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24399)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str186))) {
    heff_drop(v_x_24399);
    v_t_24405 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str187);
  } else {
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24399)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str188))) {
      heff_drop(v_x_24399);
      v_t_24405 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str189);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24399)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str190))) {
        heff_drop(v_x_24399);
        v_t_24405 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str191);
      } else {
        V v_t_24404 = heff_strAppend(heff_floatShow(v_x_24399), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str192));
        v_t_24405 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str193), v_t_24404);
      }
    }
  }
  V v_t_24406 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str194), heff_strAppend(v_t_24405, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str195)));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24406, v_s_24400});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam34(V self, V *args) {
  V v_s_24408 = args[0];
  V v_x_24407 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24413;
  if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24407)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str196))) {
    heff_drop(v_x_24407);
    v_t_24413 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str197);
  } else {
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24407)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str198))) {
      heff_drop(v_x_24407);
      v_t_24413 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str199);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24407)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str200))) {
        heff_drop(v_x_24407);
        v_t_24413 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str201);
      } else {
        V v_t_24412 = heff_strAppend(heff_floatShow(v_x_24407), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str202));
        v_t_24413 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str203), v_t_24412);
      }
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24413, v_s_24408});
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str1, 7, "V f_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str2, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str3, 5, "args[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str4, 4, "] = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str5, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str6, 19, "if (heff_exact(f_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str7, 52, ", args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str8, 21, "return heff_tail(f_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str9, 8, ", args);");
Clo g_heff_2ecompile_2eemitc_2einPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2einPlace_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2einPlace(V v_vs_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_vs_240)) {
  case TAG_Nil: {
    v_t_243 = ((V)&g_heff_2ecompile_2eemitc_2einPlace_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_vs_240, 0);
    v_t_243 = heff_dup(v_x_241);
    break;
  }
  default: heff_nomatch(v_vs_240);
  }
  V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2einPlace_str1), heff_strAppend(v_t_243, ((V)&g_heff_2ecompile_2eemitc_2einPlace_str2)));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  V v_t_246 = (g_list_2edrop(MK_INT(1LL), v_vs_240));
  V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(2LL))));
  V v_t_249 = (g_list_2ezipWith_24s706961545x2112949112(((V)&g_heff_2ecompile_2eemitc_2einPlace_str3), ((V)&g_heff_2ecompile_2eemitc_2einPlace_str4), ((V)&g_heff_2ecompile_2eemitc_2einPlace_str5), v_t_246, v_t_248));
  V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2411 = heff_intShow(heff_intSub(v_t_2410, MK_INT(1LL)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2einPlace_str6), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2einPlace_str7)));
  V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2414 = heff_intShow(heff_intSub(v_t_2413, MK_INT(1LL)));
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2einPlace_str8), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemitc_2einPlace_str9)));
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2416})));
  return (g_prelude_2e_2b_2b(v_t_245, v_t_2417));
}
V g_heff_2ecompile_2eemitc_2einPlace_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2einPlace(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperProto_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperProto_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperProto_str2, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperProto_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperProto_str4, 9, "static V ");
Clo g_heff_2ecompile_2eemitc_2ewrapperProto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ewrapperProto_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ewrapperProto(V v_key_240, V v_rs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkWrapper: {
      V v_ws_244 = heff_field(v_x31_243, 0);
      V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ewrapperProto_str0)));
      V v_t_247 = (g_heff_2ecompile_2eemitc_2eckOf(v_rs_241, heff_dup(g_std_2emap_2eempty_get()), MK_INT(0LL)));
      V v_t_248 = (g_heff_2ecompile_2eemitc_2eparamList(v_t_247, heff_dup(v_ws_244)));
      V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapperProto_str1), heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2ewrapperProto_str2)));
      V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapperProto_str3), v_t_246), v_t_249);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapperProto_str4), v_t_2410), NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2ewrapperProto_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2ewrapperProto(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str0, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str1, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str2, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str4, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str5, 21, "_entry(V self, V *a);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str8, 5, ", 0};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str9, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str10, 8, "_entry, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str11, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str12, 33, "_clo = {{0x80000000u, K_CLO, 0}, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str13, 11, "static Clo ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str14, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str15, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str16, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str17, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str18, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str19, 6, "top: ;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str20, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str21, 2, " {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str22, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str23, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str24, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str25, 22, "_entry(V self, V *a) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str26, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str27, 13, "  (void)self;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str28, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str29, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str30, 0, "");
Clo g_heff_2ecompile_2eemitc_2efunDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efunDef_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2efunDef(V v_tu_240, V v_f_241, V v_z_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eemitc_2eckOf(heff_rfield(v_f_241, 5), heff_dup(v_tu_240), MK_INT(0LL)));
  V v_m_244 = heff_tr(heff_call(heff_get_n(v_t_243, 1, 6), 1, (V[]){heff_take_field(v_f_241, 3)}));
  V v_x2_245 = heff_tr(heff_call(v_m_244, 1, (V[]){v_z_242}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_s_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2eemitc_2eckOf(heff_rfield(v_f_241, 5), heff_dup(v_tu_240), MK_INT(0LL)));
    V v_m_249 = heff_tr(heff_call(heff_get_n(v_t_248, 1, 6), 1, (V[]){heff_take_field(v_f_241, 4)}));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_247}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
      V v_m_2413 = (g_heff_2ecompile_2eemitc_2ewrapperCode(v_tu_240, heff_rfield(v_f_241, 0), heff_rfield(v_f_241, 5), heff_rfield(v_f_241, 7)));
      V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2412}));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_s_2416 = heff_field(v_x2_2414, 1);
        V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
        V v_t_2417 = heff_dup(heff_rfield(v_f_241, 6));
        V v_t_2419;
        switch (heff_tag_of(v_t_2417)) {
        case TAG_RepV: {
          v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str0);
          break;
        }
        case TAG_RepFix: {
          V v_w_2418 = heff_field(v_t_2417, 0);
          heff_take_n(v_t_2417, 1ULL, 1);
          v_t_2419 = ({ V a_0 = v_w_2418; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2418); r_; });
          break;
        }
        case TAG_RepF64: {
          v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str1);
          break;
        }
        case TAG_RepInt: {
          v_t_2419 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str2);
          break;
        }
        default: heff_nomatch(v_t_2417);
        }
        V v_t_2420 = heff_dup(heff_rfield(v_f_241, 7));
        V v_t_2422;
        switch (heff_tag_of(v_t_2420)) {
        case TAG_Nothing: {
          v_t_2422 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2420, 0ULL, 1);
          v_t_2422 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_t_2420);
        }
        V v_t_2423 = ({ V a_0 = heff_rfield(v_f_241, 0); V a_1 = heff_dup(heff_rfield(v_f_241, 1)); V a_2 = heff_rfield(v_f_241, 5); V a_3 = v_t_2419; V a_4 = v_t_2422; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2422); r_; });
        V v_t_2424 = (g_heff_2ecompile_2eemitc_2ewrapperProto(heff_rfield(v_f_241, 0), heff_rfield(v_f_241, 5), heff_rfield(v_f_241, 7)));
        V v_t_2425 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_f_241, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str3)));
        V v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str4), v_t_2425), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str5));
        V v_t_2427 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_f_241, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str6)));
        V v_t_2428 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_f_241, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str7)));
        V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 1)));
        V v_t_2430 = heff_strAppend(heff_intShow(v_t_2429), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str8));
        V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str9), v_t_2428), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str10), v_t_2430));
        V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str11), v_t_2427), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str12), v_t_2431));
        V v_t_2433 = heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str13), v_t_2432), NTAG(TAG_Nil)});
        V v_t_2434 = heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str14), v_t_2426), v_t_2433});
        V v_t_2435 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2434));
        V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2eemitc_2efunDef_str15)), v_t_2435});
        V v_t_2437 = heff_take_field(v_f_241, 6);
        V v_t_2439;
        switch (heff_tag_of(v_t_2437)) {
        case TAG_RepV: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str16);
          break;
        }
        case TAG_RepFix: {
          V v_w_2438 = heff_field(v_t_2437, 0);
          heff_take_n(v_t_2437, 1ULL, 1);
          v_t_2439 = ({ V a_0 = v_w_2438; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2438); r_; });
          break;
        }
        case TAG_RepF64: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str17);
          break;
        }
        case TAG_RepInt: {
          v_t_2439 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str18);
          break;
        }
        default: heff_nomatch(v_t_2437);
        }
        V v_t_2440 = heff_take_field(v_f_241, 7);
        V v_t_2442;
        switch (heff_tag_of(v_t_2440)) {
        case TAG_Nothing: {
          v_t_2442 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2440, 0ULL, 1);
          v_t_2442 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_t_2440);
        }
        V v_t_2443 = ({ V a_0 = heff_rfield(v_f_241, 0); V a_1 = heff_dup(heff_rfield(v_f_241, 1)); V a_2 = heff_rfield(v_f_241, 5); V a_3 = v_t_2439; V a_4 = v_t_2442; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2442); r_; });
        V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str19), NTAG(TAG_Nil)});
        V v_t_2445 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2444, ((V)&g_heff_2ecompile_2eemitc_2efunDef_str20), v_x_246));
        V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2443, ((V)&g_heff_2ecompile_2eemitc_2efunDef_str21)), v_t_2445});
        V v_t_2447 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ecompile_2eemitc_2efunDef_str22), v_x_2411));
        V v_t_2448 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_f_241, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str23)));
        V v_t_2449 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str24), v_t_2448), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str25));
        V v_t_2450 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_241, 1)));
        V v_t_2451 = ({ V b_0 = heff_take_field(v_f_241, 0); V a_1 = heff_get_n(v_f_241, 2, 8); V a_2 = v_t_2450; V r_ = (g_heff_2ecompile_2eemitc_2eentryCall(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str26), NTAG(TAG_Nil)});
        V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str27), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, v_t_2452})});
        V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str28), v_t_2449), v_t_2453});
        V v_t_2455 = (g_prelude_2e_2b_2b(v_x_2415, v_t_2454));
        V v_t_2456 = (g_prelude_2e_2b_2b(v_t_2447, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str29), v_t_2455})));
        V v_t_2457 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str30), v_t_2446}), v_t_2456));
        V v_x_2458 = heff_rec_n(2, shape_protos__code, (V[]){v_t_2436, v_t_2457});
        return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_2458, v_s_2416});
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ecompile_2eemitc_2efunDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2efunDef(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str0, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str1, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str2, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str3, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str4, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str5, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str6, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str7, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str8, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str9, 4, "bool");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str10, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str11, 12, "const char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str12, 6, "char *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str13, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str14, 2, " *");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str15, 4, "void");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eresultTypeName_str16, 3, "int");
Clo g_heff_2ecompile_2eemitc_2eresultTypeName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eresultTypeName_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eresultTypeName(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Gives: {
    V v_t_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_t_241)) {
    case TAG_CInteger: {
      V v_t_242 = heff_field(v_t_241, 0);
      return heff_dup(v_t_242);
    }
    case TAG_CDouble: {
      return ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str0);
    }
    case TAG_CBool: {
      return ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str1);
    }
    case TAG_CString: {
      return ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str2);
    }
    case TAG_CText: {
      return ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str3);
    }
    case TAG_COwnedString: {
      return ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str4);
    }
    case TAG_CPointer: {
      V v_t_243 = heff_field(v_t_241, 0);
      return heff_strAppend(heff_dup(v_t_243), ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str5));
    }
    case TAG_CSharedPointer: {
      V v_t_245 = heff_field(v_t_241, 0);
      return heff_strAppend(heff_dup(v_t_245), ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str6));
    }
    case TAG_CVoid: {
      return ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str7);
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_GivesOrErrno: {
    V v_t_248 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_t_248)) {
    case TAG_CInteger: {
      V v_t_249 = heff_field(v_t_248, 0);
      return heff_dup(v_t_249);
    }
    case TAG_CDouble: {
      return ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str8);
    }
    case TAG_CBool: {
      return ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str9);
    }
    case TAG_CString: {
      return ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str10);
    }
    case TAG_CText: {
      return ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str11);
    }
    case TAG_COwnedString: {
      return ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str12);
    }
    case TAG_CPointer: {
      V v_t_2410 = heff_field(v_t_248, 0);
      return heff_strAppend(heff_dup(v_t_2410), ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str13));
    }
    case TAG_CSharedPointer: {
      V v_t_2412 = heff_field(v_t_248, 0);
      return heff_strAppend(heff_dup(v_t_2412), ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str14));
    }
    case TAG_CVoid: {
      return ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str15);
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  case TAG_DoneOrErrno: {
    return ((V)&g_heff_2ecompile_2eemitc_2eresultTypeName_str16);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eemitc_2eresultTypeName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2eresultTypeName(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str0, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str2, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str4, 1, ")");
Clo g_heff_2ecompile_2eemitc_2eglueCallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglueCallOf_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eglueCallOf(V v_b_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_b_240, 2)));
  V v_x2_242 = (g_list_2emap_24f1005417903x1119563692(((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str0), MK_INT(0LL), heff_intSub(v_t_241, MK_INT(1LL))));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str2); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str3), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str4)));
  return heff_strAppend(heff_get_n(v_b_240, 1, 5), v_t_246);
}
V g_heff_2ecompile_2eemitc_2eglueCallOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglueCallOf(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str0, 3, "));");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str1, 31, "    return heff_tail(k, 1, &x);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str2, 17, "    heff_drop(p);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str3, 28, "    V x = heff_answer(f, r);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str4, 33, "    V f = heff_dup(heff_field(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str5, 3, "));");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str6, 31, "    return heff_tail(k, 1, &x);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str7, 17, "    heff_drop(p);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str8, 12, "    (void)r;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str9, 33, "    V x = heff_dup(heff_field(p, ");
Clo g_heff_2ecompile_2eemitc_2eanswerLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eanswerLines_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eanswerLines(V v_b_240) {
top: ;
  V v_t_241 = heff_take_field(v_b_240, 4);
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    V v_t_242 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_b_240, 2, 5); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_243 = heff_strAppend(heff_intShow(v_t_242), ((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str0));
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str1), NTAG(TAG_Nil)});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str3), v_t_244})});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str4), v_t_243), v_t_245});
  } else {
    heff_drop(v_t_241);
    V v_t_246 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_b_240, 2, 5); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_247 = heff_strAppend(heff_intShow(v_t_246), ((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str5));
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str6), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str8), v_t_248})});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str9), v_t_247), v_t_249});
  }
}
V g_heff_2ecompile_2eemitc_2eanswerLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eanswerLines(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemptyCS_str0, 0, "");

static V g_heff_2ecompile_2eemitc_2eemptyCS_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eemptyCS_st;
static V g_heff_2ecompile_2eemitc_2eemptyCS_init(void) {
  return heff_rec_n(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){((V)&g_heff_2ecompile_2eemitc_2eemptyCS_str0), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eemptyCS_st)) return g_heff_2ecompile_2eemitc_2eemptyCS_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eemptyCS_val, &g_heff_2ecompile_2eemitc_2eemptyCS_st, g_heff_2ecompile_2eemitc_2eemptyCS_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str0, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str1, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str2, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str3, 4, "TAG_");
V g_heff_2ecompile_2eemitc_2eceOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eceOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eceOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eceOf(V v_provs_240, V v_facts_241, V v_names_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_x_243 = heff_field(v_names_242, 0);
    v_t_245 = heff_dup(v_x_243);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_t_247 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str0); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_246; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_245, v_t_247));
  V v_xs_249 = (g_list_2efilter_24s1967523567x64647275(v_t_248));
  V v_m_2410 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_xs_249; V r_ = (g_list_2efoldl_24s477184376x1963488659(a_0, a_1)); heff_drop(v_xs_249); r_; });
  V v_t_2411 = ({ V a_0 = v_m_2410; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2410); r_; });
  V v_t_2412 = (g_list_2emap_24s1937570095x2110149801(v_t_2411));
  V v_t_2413 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V a_2 = heff_dup(g_std_2emap_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2enumbered(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2414 = ({ V a_0 = MK_INT(10LL); V a_1 = MK_INT(65526LL); V a_2 = v_t_2412; V a_3 = v_t_2413; V a_4 = heff_dup(g_std_2emap_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2ehashedGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2412); r_; });
  V v_t_2417;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_names_242, 1);
    v_t_2417 = heff_dup(v_y_2416);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_t_2419 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str1); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2418; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2418); r_; });
  V v_xs_2420 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2419));
  V v_m_2421 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_xs_2420; V r_ = (g_list_2efoldl_24s477184376x1963488659(a_0, a_1)); heff_drop(v_xs_2420); r_; });
  V v_t_2422 = ({ V a_0 = v_m_2421; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2421); r_; });
  V v_t_2423 = (g_list_2emap_24s1937570095x2110149801(v_t_2422));
  V v_t_2424 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(2147483647LL); V a_2 = v_t_2423; V a_3 = heff_dup(g_std_2emap_2eempty_get()); V a_4 = heff_dup(g_std_2emap_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2ehashedGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2423); r_; });
  V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_t_2426 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str2); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2425; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2425); r_; });
  V v_su_2427 = ({ V a_0 = v_t_2426; V a_1 = heff_rfield(v_facts_241, 7); V r_ = (g_heff_2ecompile_2eemitc_2eshapesOnlyHere(a_0, a_1)); heff_drop(v_t_2426); r_; });
  V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_provs_240));
  V v_t_2429 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str3); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2428; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2428); r_; });
  V v_others_2430 = (g_prelude_2e_2b_2b(heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()), v_t_2429));
  V v_t_2431 = (g_std_2emap_2etoListOnto(heff_rfield(v_facts_241, 6), NTAG(TAG_Nil)));
  V v_ps_2437 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eemitc_2eceOf_lam0, 1, 1, (V[]){v_others_2430}), v_t_2431));
  V v_su_2438 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2437; V r_ = (g_list_2efoldl_24s651278233x871164524(a_0, a_1)); heff_drop(v_ps_2437); r_; });
  V v_t_2439 = ({ V rv_6 = v_su_2438; V rv_7 = v_su_2427; V rr_ = heff_rec_reuse_nf(v_facts_241, 831ULL, 10, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words, 987135u, 0u); heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_rec_n(3, shape_tags__lbls__facts, (V[]){v_t_2414, v_t_2424, v_t_2439});
}
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eceOf(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2eceOf_lam0(V self, V *args) {
  V v_p_2432 = args[0];
  V v_others_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435;
  switch (heff_tag_of(v_p_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_p_2432, 0);
    heff_take_n(v_p_2432, 1ULL, 2);
    v_t_2435 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_p_2432);
  }
  V v_x1_2436 = ({ V a_0 = v_t_2435; V a_1 = v_others_2430; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_t_2435); heff_drop(v_others_2430); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2436) == NTAG(TAG_True)));
  heff_drop(v_x1_2436);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str1, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str5, 2, "g_");
Clo g_heff_2ecompile_2eemitc_2eemitAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eemitAt_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2eemitAt(V v_ce_240, V v_kept_241, V v_acc_242, V v_d_243, V v_own_244, V v_v_245) {
top: ;
  HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_kept_241, heff_rfield(v_d_243, 0)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_k_2410 = v_field_248;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2410, 0)), heff_dup(v_v_245))) {
        heff_drop_rec(v_ce_240, 3);
        heff_drop(v_v_245);
        V v_t_2412 = heff_rec_n(2, shape_protos__code, (V[]){heff_dup(heff_rfield(v_k_2410, 1)), heff_dup(heff_rfield(v_k_2410, 2))});
        V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, heff_take_field(v_acc_242, 0)});
        V v_t_2414 = ({ V b_0 = heff_get_n(v_d_243, 0, 3); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eemitAt_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
        V v_t_2415 = (g_heff_2ecompile_2eemitc_2emergeKept(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eemitAt_str1), v_t_2414), v_k_2410, heff_take_field(v_acc_242, 1)));
        return ({ V rv_0 = v_t_2413; V rv_1 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_acc_242, 4ULL, 3, shape_ems__s__fresh, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      } else {
        heff_drop_rec(v_k_2410, 8);
        V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 8, 10);
        V v_t_2417 = (g_heff_2ecompile_2elower_2ecDef(heff_get_n(v_ce_240, 2, 3), heff_dup(v_d_243), v_own_244));
        V v_t_2418 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_d_243, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eemitAt_str2)));
        V v_o_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eemitAt_str3), v_t_2418);
        V v_t_2420 = heff_rec_n(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){v_o_2419, MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
        V v_t_2421 = ({ V a_0 = v_t_2416; V a_1 = v_t_2417; V a_2 = v_t_2420; V r_ = (g_heff_2ecompile_2eemitc_2edefC(a_0, a_1, a_2)); heff_drop(v_t_2417); r_; });
        return (g_heff_2ecompile_2eemitc_2efreshEmitted(v_acc_242, heff_get_n(v_d_243, 0, 3), v_v_245, v_t_2421));
      }
    } else {
      heff_drop(v_field_248);
      V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 8, 10);
      V v_t_2423 = (g_heff_2ecompile_2elower_2ecDef(heff_get_n(v_ce_240, 2, 3), heff_dup(v_d_243), v_own_244));
      V v_t_2424 = (g_heff_2ecompile_2eemitc_2emangleW(heff_rfield(v_d_243, 0), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eemitAt_str4)));
      V v_o_2425 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eemitAt_str5), v_t_2424);
      V v_t_2426 = heff_rec_n(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){v_o_2425, MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      V v_t_2427 = ({ V a_0 = v_t_2422; V a_1 = v_t_2423; V a_2 = v_t_2426; V r_ = (g_heff_2ecompile_2eemitc_2edefC(a_0, a_1, a_2)); heff_drop(v_t_2423); r_; });
      return (g_heff_2ecompile_2eemitc_2efreshEmitted(v_acc_242, heff_get_n(v_d_243, 0, 3), v_v_245, v_t_2427));
    }
  }
}
V g_heff_2ecompile_2eemitc_2eemitAt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ecompile_2eemitc_2eemitAt(a[0], a1, a[2], a[3], a4, a[5]); heff_drop(a1); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ethreadsLine_str0, 22, "#define HEFF_THREADS 1");

static V g_heff_2ecompile_2eemitc_2ethreadsLine_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2ethreadsLine_st;
static V g_heff_2ecompile_2eemitc_2ethreadsLine_init(void) {
  return ((V)&g_heff_2ecompile_2eemitc_2ethreadsLine_str0);
}
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2ethreadsLine_st)) return g_heff_2ecompile_2eemitc_2ethreadsLine_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2ethreadsLine_val, &g_heff_2ecompile_2eemitc_2ethreadsLine_st, g_heff_2ecompile_2eemitc_2ethreadsLine_init);
}