// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_MkCode 2932
#define TAG_MkWrapper 39179
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Tip 31527
#define LBL_answered 245579351
#define LBL_args 9498020
#define LBL_arity 294440695
#define LBL_body 9524841
#define LBL_bounce 563936691
#define LBL_code 9554612
#define LBL_ems 310085
#define LBL_entry 298026124
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_flat 9641024
#define LBL_fresh 299054408
#define LBL_fun 311289
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lazy 9809979
#define LBL_lbls 9810500
#define LBL_lent 9813446
#define LBL_name 9869138
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_reprs 309759928
#define LBL_ret 322331
#define LBL_s 333
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_sure 10037468
#define LBL_sureRecs 1275638267
#define LBL_tags 10047712
#define LBL_tokens 1078955205
#define LBL_tuples 1084651734
#define LBL_ver 326173
#define LBL_words 314676931
#define LBL_workers 1757018875
#define LBL_wrapper 1827365593
static uint32_t shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens[] = {LBL_arity, LBL_bounce, LBL_lazy, LBL_lent, LBL_workers, LBL_flat, LBL_sure, LBL_sureRecs, LBL_tuples, LBL_words, LBL_tokens};
static uint32_t shape_ems__s__fresh[] = {LBL_ems, LBL_s, LBL_fresh};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
static uint32_t shape_protos__code[] = {LBL_protos, LBL_code};
static uint32_t shape_tags__lbls__facts[] = {LBL_tags, LBL_lbls, LBL_facts};
V g_heff_2ecompile_2eemitc_2eanswerLines(V);
V g_heff_2ecompile_2eemitc_2eanswerLines_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eanswerLines_clo;
V g_heff_2ecompile_2eemitc_2ecallC(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallC_clo;
V g_heff_2ecompile_2eemitc_2eceOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eceOf_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
V g_heff_2ecompile_2eemitc_2edefC(V, V, V);
V g_heff_2ecompile_2eemitc_2edefC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edefC_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eemitAt(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eemitAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eemitAt_clo;
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void);
V g_heff_2ecompile_2eemitc_2eentryCall(V, V, V);
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eentryCall_clo;
V g_heff_2ecompile_2eemitc_2eexpF(V, V);
V g_heff_2ecompile_2eemitc_2eexpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eexpF_clo;
V g_heff_2ecompile_2eemitc_2efixedConst(V, V);
V g_heff_2ecompile_2eemitc_2efixedConst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedConst_clo;
V g_heff_2ecompile_2eemitc_2efixedLit(V, V);
V g_heff_2ecompile_2eemitc_2efixedLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedLit_clo;
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efreshEmitted(V, V, V, V);
V g_heff_2ecompile_2eemitc_2efreshEmitted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efreshEmitted_clo;
V g_heff_2ecompile_2eemitc_2efunDef(V, V, V);
V g_heff_2ecompile_2eemitc_2efunDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunDef_clo;
V g_heff_2ecompile_2eemitc_2efunHead(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2efunHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunHead_clo;
V g_heff_2ecompile_2eemitc_2eglueCallOf(V);
V g_heff_2ecompile_2eemitc_2eglueCallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglueCallOf_clo;
V g_heff_2ecompile_2eemitc_2ehashedGo(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ehashedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehashedGo_clo;
V g_heff_2ecompile_2eemitc_2einPlace(V);
V g_heff_2ecompile_2eemitc_2einPlace_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2einPlace_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2elamC(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamC_clo;
V g_heff_2ecompile_2eemitc_2elentPrimC(V, V, V, V);
V g_heff_2ecompile_2eemitc_2elentPrimC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elentPrimC_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emergeKept(V, V, V);
V g_heff_2ecompile_2eemitc_2emergeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emergeKept_clo;
V g_heff_2ecompile_2eemitc_2enumbered(V, V, V);
V g_heff_2ecompile_2eemitc_2enumbered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enumbered_clo;
V g_heff_2ecompile_2eemitc_2eparamList(V, V);
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamList_clo;
V g_heff_2ecompile_2eemitc_2eprimLit(V, V);
V g_heff_2ecompile_2eemitc_2eprimLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimLit_clo;
V g_heff_2ecompile_2eemitc_2eprimU(V, V);
V g_heff_2ecompile_2eemitc_2eprimU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimU_clo;
HeffT2 g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(V, V);
V g_heff_2ecompile_2eemitc_2estrLit(V, V, V);
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estrLit_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void);
V g_heff_2ecompile_2eemitc_2eupdateText(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eupdateText_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eupdateText_clo;
V g_heff_2ecompile_2eemitc_2ewrapped(V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapped_clo;
V g_heff_2ecompile_2eemitc_2ewrapperCode(V, V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapperCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapperCode_clo;
V g_heff_2ecompile_2eemitc_2ewrapperProto(V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapperProto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapperProto_clo;
HeffT2 g_heff_2ecompile_2eimperative_2edefOf_24cpr(V, V, V);
V g_heff_2ecompile_2eimperative_2egenOf(V);
V g_heff_2ecompile_2eimperative_2egenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2egenOf_clo;
V g_heff_2ecompile_2elower_2ercOf(V, V);
V g_heff_2ecompile_2elower_2ercOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ercOf_clo;
V g_heff_2ecompile_2eowned_2eelemS(V, V);
V g_heff_2ecompile_2eowned_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2eelemS_clo;
V g_heff_2ecompile_2eowned_2elendingPrims_get(void);
V g_list_2eall_24s1465078656x604124530(V);
V g_list_2eall_24s1465078656x604124530_entry(V self, V *a);
extern Clo g_list_2eall_24s1465078656x604124530_clo;
V g_list_2eany_24s1338755034x1627180165(V, V, V, V, V, V, V, V);
V g_list_2eany_24s1338755034x1627180165_entry(V self, V *a);
extern Clo g_list_2eany_24s1338755034x1627180165_clo;
V g_list_2eany_24s63755471x810534073(V, V);
V g_list_2eany_24s63755471x810534073_entry(V self, V *a);
extern Clo g_list_2eany_24s63755471x810534073_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1882737314x358197882(V, V, V, V);
V g_list_2efoldl_24s1882737314x358197882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1882737314x358197882_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2efoldl_24s571527232x333134686(V, V);
V g_list_2efoldl_24s571527232x333134686_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571527232x333134686_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s478006518x1380334353(V);
V g_list_2ekeepIf_24s478006518x1380334353_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s478006518x1380334353_clo;
V g_list_2emap_24f1005417903x1119563692(V, V, V);
V g_list_2emap_24f1005417903x1119563692_entry(V self, V *a);
extern Clo g_list_2emap_24f1005417903x1119563692_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s706961545x2112949112(V, V, V, V, V);
V g_list_2ezipWith_24s706961545x2112949112_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s706961545x2112949112_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1306153264x1245859556(V, V, V);
V g_prelude_2e_2b_2b_24f1306153264x1245859556_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1306153264x1245859556_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s1362847681x1386678580(V, V);
V g_prelude_2etraverse_24s1362847681x1386678580_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1362847681x1386678580_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ecompile_2eemitc_2enumbered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enumbered_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2enumbered(V v_n_240, V v_x2_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_m_242, v_x_243));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_248 = v_field_247;
        heff_drop(v_x_248);
        V t_0 = v_n_240;
        V t_1 = v_xs_244;
        V t_2 = v_m_242;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        v_m_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_247);
        V v_t_249 = (g_std_2emap_2einsert_24s93785294x875597928(v_m_242, heff_dup(v_x_243), heff_dup(v_n_240)));
        V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
        V t_1 = v_xs_244;
        V t_2 = v_t_249;
        v_n_240 = t_0;
        v_x2_241 = t_1;
        v_m_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2enumbered_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enumbered(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str2, 11, " (uint64_t)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str3, 2, "))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str4, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str5, 12, ")((uint64_t)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str6, 2, "((");
Clo g_heff_2ecompile_2eemitc_2ewrapped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ewrapped_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ewrapped(V v_w_240, V v_op_241, V v_vs_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
  V v_t_246;
  switch (heff_tag_of(v_vs_242)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_vs_242, 0);
    v_t_246 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_vs_242);
  }
  HeffT3 v_t_247 = (g_list_2edrop_24cpr(MK_INT(1LL), v_vs_242));
  V v_t_2413;
  {
    V v_field_249 = v_t_247.f[1];
    V v_field_2410 = v_t_247.f[2];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_249;
      V v_x12_2412 = v_field_2410;
      heff_drop(v_x12_2412);
      v_t_2413 = v_x_2411;
    } else {
      heff_drop(v_field_249);
      heff_drop(v_field_2410);
      v_t_2413 = ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str1);
    }
  }
  V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapped_str2), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str3)));
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapped_str4), heff_strAppend(v_op_241, v_t_2414));
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapped_str5), heff_strAppend(v_t_246, v_t_2415));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapped_str6), heff_strAppend(v_t_243, v_t_2416));
}
V g_heff_2ecompile_2eemitc_2ewrapped_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2ewrapped(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str1, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str3, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str5, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str7, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str8, 5, "_clo)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str9, 5, "((V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str11, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str12, 7, "_get())");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str13, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str15, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str16, 6, "_get()");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str17, 3, "LL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str18, 7, "MK_INT(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str19, 2, "\")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str20, 10, "HEFF_BIG(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str21, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str22, 13, "heff_flt(NAN)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str23, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str24, 18, "heff_flt(INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str25, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str26, 19, "heff_flt(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str27, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str28, 9, "heff_flt(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str29, 8, "HEFF_LIT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str30, 10, "HEFF_BYTES");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str31, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str32, 16, "heff_f32((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str33, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str34, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str35, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str36, 5, "NTAG(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str37, 5, "HeffT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str38, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str39, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str40, 3, "){{");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str41, 3, "}})");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str42, 2, "((");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str43, 11, "heff_tag_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str44, 12, "heff_tag_nf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str45, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str46, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str47, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str48, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str49, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str50, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str51, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str52, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str53, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str54, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str55, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str56, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str57, 14, "heff_tag_at_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str58, 15, "heff_tag_at_nf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str59, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str60, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str61, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str62, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str63, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str64, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str65, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str66, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str67, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str68, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str69, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str70, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str71, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str72, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str73, 11, "heff_rec_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str74, 12, "heff_rec_nf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str75, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str76, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str77, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str78, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str79, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str80, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str81, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str82, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str83, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str84, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str85, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str86, 1, "f");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str87, 1, "u");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str88, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str89, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str90, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str91, 12, "heff_rfield(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str92, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str93, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str94, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str95, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str96, 12, "heff_rget_v(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str97, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str98, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str99, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str100, 11, "heff_get_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str101, 11, "heff_rflat_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str102, 10, "heff_rget_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str103, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str104, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str105, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str106, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str107, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str108, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str109, 15, "heff_get_nflat_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str110, 11, "heff_get_n_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str111, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str112, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str113, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str114, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str115, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str116, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str117, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str118, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str119, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str120, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str121, 10, "heff_word_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str122, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str123, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str124, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str125, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str126, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str127, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str128, 16, "heff_take_field(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str129, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str130, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str131, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str132, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str133, 9, "heff_get(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str134, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str135, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str136, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str137, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str138, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str139, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str140, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str141, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str142, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str143, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str144, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str145, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str146, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str147, 2, "))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str148, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str149, 18, "heff_tr(heff_call(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str150, 10, "heff_bool(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str151, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str152, 14, "heff_abandon()");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str153, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str154, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str155, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str156, 9, "heff_box_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str157, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str158, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str159, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str160, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str161, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str162, 11, "heff_unbox_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str163, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str164, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str165, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str166, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str167, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str168, 10, "heff_peek_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str169, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str170, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str171, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str172, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str173, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str174, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str175, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str176, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str177, 4, "word");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str178, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str179, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str180, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str181, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str182, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str183, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str184, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str185, 3, "NAN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str186, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str187, 8, "INFINITY");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str188, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str189, 11, "(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str190, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str191, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str192, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str193, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str194, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str195, 3, "NAN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str196, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str197, 8, "INFINITY");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str198, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str199, 11, "(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str200, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str201, 1, "(");
V g_heff_2ecompile_2eemitc_2eexpF_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam12(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam13(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam14(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam15(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam16(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam17(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam18(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam19(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam20(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam21(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam22(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam23(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam24(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam25(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam26(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2eexpF_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eexpF_lam26, 1, 0};
V g_heff_2ecompile_2eemitc_2eexpF_lam27(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam28(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam29(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam30(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam31(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam32(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam33(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam34(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eexpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eexpF_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eexpF(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_RLocal: {
    V v_x_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_243 = ({ V a_0 = v_x_242; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_242); r_; });
    V v_x_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str1), v_t_243);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam0, 1, 1, (V[]){v_x_244});
  }
  case TAG_RDup: {
    V v_x_246 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_247 = ({ V a_0 = v_x_246; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str2); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_246); r_; });
    V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str3), v_t_247), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str4));
    V v_x_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str5), v_t_248);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam1, 1, 1, (V[]){v_x_249});
  }
  case TAG_RClo: {
    V v_g_2411 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2412 = ({ V a_0 = v_g_2411; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str6); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_2411); r_; });
    V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str7), v_t_2412), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str8));
    V v_x_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str9), v_t_2413);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam2, 1, 1, (V[]){v_x_2414});
  }
  case TAG_RGet: {
    V v_g_2416 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2417 = ({ V a_0 = v_g_2416; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str10); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_2416); r_; });
    V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str11), v_t_2417), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str12));
    V v_x_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str13), v_t_2418);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam3, 1, 1, (V[]){v_x_2419});
  }
  case TAG_RGetRaw: {
    V v_g_2421 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2422 = ({ V a_0 = v_g_2421; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str14); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_g_2421); r_; });
    V v_x_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str15), v_t_2422), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str16));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam4, 1, 1, (V[]){v_x_2423});
  }
  case TAG_RInt: {
    V v_n_2425 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam5, 1, 1, (V[]){v_n_2425});
  }
  case TAG_RFloat: {
    V v_x_2430 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam6, 1, 1, (V[]){v_x_2430});
  }
  case TAG_RStr: {
    V v_s_2434 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2estrLit_clo), 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eexpF_str29), v_s_2434});
  }
  case TAG_RBytes: {
    V v_s_2435 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2estrLit_clo), 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eexpF_str30), v_s_2435});
  }
  case TAG_RFixed: {
    V v_w_2436 = heff_field(v_x2_241, 0);
    V v_n_2437 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_k_240, 6);
    V v_x_2438 = ({ V a_0 = v_w_2436; V a_1 = v_n_2437; V r_ = (g_heff_2ecompile_2eemitc_2efixedLit(a_0, a_1)); heff_drop(v_w_2436); r_; });
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam7, 1, 1, (V[]){v_x_2438});
  }
  case TAG_RF32: {
    V v_x_2440 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam8, 1, 1, (V[]){v_x_2440});
  }
  case TAG_RNTag: {
    V v_t_2443 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    V v_t_2444 = ({ V a_0 = v_t_2443; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str33); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2443); r_; });
    V v_t_2445 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str34), v_t_2444), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str35));
    V v_x_2446 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str36), v_t_2445);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam9, 1, 1, (V[]){v_x_2446});
  }
  case TAG_RTag: {
    V v_t_2448 = heff_field(v_x2_241, 0);
    V v_flat_2449 = heff_field(v_x2_241, 1);
    V v_es_2450 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2451 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), heff_dup(v_es_2450)));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam10, 1, 4, (V[]){v_m_2451, v_t_2448, v_es_2450, v_flat_2449});
  }
  case TAG_RTagIn: {
    V v_ru_2477 = heff_field(v_x2_241, 0);
    V v_t_2478 = heff_field(v_x2_241, 1);
    V v_flat_2479 = heff_field(v_x2_241, 2);
    V v_es_2480 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_2481 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), heff_tag_n(TAG_Cons, 2, (V[]){v_ru_2477, heff_dup(v_es_2480)})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam11, 1, 4, (V[]){v_m_2481, v_flat_2479, v_t_2478, v_es_2480});
  }
  case TAG_RRec: {
    V v_ls_24109 = heff_field(v_x2_241, 0);
    V v_flat_24110 = heff_field(v_x2_241, 1);
    V v_es_24111 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24112 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24111));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam12, 1, 3, (V[]){v_m_24112, v_ls_24109, v_flat_24110});
  }
  case TAG_RRecIn: {
    V v_x_24136 = heff_field(v_x2_241, 0);
    V v_keep_24137 = heff_field(v_x2_241, 1);
    V v_kept_24138 = heff_field(v_x2_241, 2);
    V v_flat_24139 = heff_field(v_x2_241, 3);
    V v_n_24140 = heff_field(v_x2_241, 4);
    V v_ls_24141 = heff_field(v_x2_241, 5);
    V v_changed_24142 = heff_field(v_x2_241, 6);
    V v_su_24143 = heff_field(v_x2_241, 7);
    heff_take_n(v_x2_241, 255ULL, 8);
    V v_t_24144 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_changed_24142)));
    V v_m_24145 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_t_24144));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam13, 1, 9, (V[]){v_m_24145, v_ls_24141, v_su_24143, v_flat_24139, v_kept_24138, v_changed_24142, v_x_24136, v_keep_24137, v_n_24140});
  }
  case TAG_RField: {
    V v_e_24160 = heff_field(v_x2_241, 0);
    V v_i_24161 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24162 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24160}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam14, 1, 2, (V[]){v_m_24162, v_i_24161});
  }
  case TAG_RDupE: {
    V v_e_24169 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_24170 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24169}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam15, 1, 1, (V[]){v_m_24170});
  }
  case TAG_RFieldV: {
    V v_e_24176 = heff_field(v_x2_241, 0);
    V v_i_24177 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24178 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24176}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam16, 1, 2, (V[]){v_m_24178, v_i_24177});
  }
  case TAG_RGetN: {
    V v_e_24185 = heff_field(v_x2_241, 0);
    V v_i_24186 = heff_field(v_x2_241, 1);
    V v_n_24187 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24188 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24185}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam17, 1, 3, (V[]){v_m_24188, v_n_24187, v_i_24186});
  }
  case TAG_RFieldU: {
    V v_r_24196 = heff_field(v_x2_241, 0);
    V v_su_24197 = heff_field(v_x2_241, 1);
    V v_e_24198 = heff_field(v_x2_241, 2);
    V v_i_24199 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_24200;
    if ((heff_dup(v_su_24197) == NTAG(TAG_True))) {
      heff_drop(v_su_24197);
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str101);
    } else {
      heff_drop(v_su_24197);
      v_t_24200 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str102);
    }
    V v_t_24202;
    switch (heff_tag_of(v_r_24196)) {
    case TAG_RepV: {
      v_t_24202 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str103);
      break;
    }
    case TAG_RepFix: {
      V v_w_24201 = heff_field(v_r_24196, 0);
      heff_take_n(v_r_24196, 1ULL, 1);
      v_t_24202 = ({ V a_0 = v_w_24201; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24201); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24202 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str104);
      break;
    }
    case TAG_RepInt: {
      v_t_24202 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str105);
      break;
    }
    default: heff_nomatch(v_r_24196);
    }
    V v_pre_24203 = heff_strAppend(v_t_24200, heff_strAppend(v_t_24202, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str106)));
    V v_m_24204 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24198}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam18, 1, 3, (V[]){v_m_24204, v_i_24199, v_pre_24203});
  }
  case TAG_RGetNU: {
    V v_r_24211 = heff_field(v_x2_241, 0);
    V v_su_24212 = heff_field(v_x2_241, 1);
    V v_e_24213 = heff_field(v_x2_241, 2);
    V v_i_24214 = heff_field(v_x2_241, 3);
    V v_n_24215 = heff_field(v_x2_241, 4);
    heff_take_n(v_x2_241, 31ULL, 5);
    V v_t_24216;
    if ((heff_dup(v_su_24212) == NTAG(TAG_True))) {
      heff_drop(v_su_24212);
      v_t_24216 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str109);
    } else {
      heff_drop(v_su_24212);
      v_t_24216 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str110);
    }
    V v_t_24218;
    switch (heff_tag_of(v_r_24211)) {
    case TAG_RepV: {
      v_t_24218 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str111);
      break;
    }
    case TAG_RepFix: {
      V v_w_24217 = heff_field(v_r_24211, 0);
      heff_take_n(v_r_24211, 1ULL, 1);
      v_t_24218 = ({ V a_0 = v_w_24217; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24217); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24218 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str112);
      break;
    }
    case TAG_RepInt: {
      v_t_24218 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str113);
      break;
    }
    default: heff_nomatch(v_r_24211);
    }
    V v_pre_24219 = heff_strAppend(v_t_24216, heff_strAppend(v_t_24218, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str114)));
    V v_m_24220 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24213}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam19, 1, 4, (V[]){v_m_24220, v_n_24215, v_i_24214, v_pre_24219});
  }
  case TAG_RWord: {
    V v_r_24228 = heff_field(v_x2_241, 0);
    V v_e_24229 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24231;
    switch (heff_tag_of(v_r_24228)) {
    case TAG_RepV: {
      v_t_24231 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str118);
      break;
    }
    case TAG_RepFix: {
      V v_w_24230 = heff_field(v_r_24228, 0);
      heff_take_n(v_r_24228, 1ULL, 1);
      v_t_24231 = ({ V a_0 = v_w_24230; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24230); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24231 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str119);
      break;
    }
    case TAG_RepInt: {
      v_t_24231 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str120);
      break;
    }
    default: heff_nomatch(v_r_24228);
    }
    V v_pre_24232 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str121), heff_strAppend(v_t_24231, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str122)));
    V v_m_24233 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24229}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam20, 1, 2, (V[]){v_m_24233, v_pre_24232});
  }
  case TAG_RTakeField: {
    V v_x_24239 = heff_field(v_x2_241, 0);
    V v_i_24240 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_k_240, 6);
    V v_t_24241 = ({ V a_0 = v_x_24239; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str124); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_24239); r_; });
    V v_t_24242 = heff_strAppend(heff_intShow(v_i_24240), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str125));
    V v_t_24243 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str126), v_t_24241), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str127), v_t_24242));
    V v_x_24244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str128), v_t_24243);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam21, 1, 1, (V[]){v_x_24244});
  }
  case TAG_RGetLabel: {
    V v_e_24246 = heff_field(v_x2_241, 0);
    V v_l_24247 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24248 = ({ V a_0 = v_l_24247; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str129); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_l_24247); r_; });
    V v_t_24249 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str130), v_t_24248), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str131));
    V v_post_24250 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str132), v_t_24249);
    V v_m_24251 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24246}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam22, 1, 2, (V[]){v_m_24251, v_post_24250});
  }
  case TAG_RPrimFn: {
    V v_p_24257 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2eprimLit_clo), 1, (V[]){v_p_24257});
  }
  case TAG_RPrim: {
    V v_p_24258 = heff_field(v_x2_241, 0);
    V v_es_24259 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24260 = ({ V a_0 = v_p_24258; V b_1 = heff_dup(g_heff_2ecompile_2eowned_2elendingPrims_get()); V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_24262;
    if ((heff_dup(v_t_24260) == NTAG(TAG_True))) {
      heff_drop(v_t_24260);
      V v_t_24261 = (g_list_2eall_24s1465078656x604124530(v_es_24259));
      if ((heff_dup(v_t_24261) == NTAG(TAG_True))) {
        heff_drop(v_t_24261);
        v_t_24262 = (g_list_2eany_24s63755471x810534073(v_es_24259, v_es_24259));
      } else {
        heff_drop(v_t_24261);
        v_t_24262 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_t_24260);
      v_t_24262 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24262) == NTAG(TAG_True))) {
      heff_drop(v_t_24262);
      return (g_heff_2ecompile_2eemitc_2elentPrimC(v_k_240, v_p_24258, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str134), v_es_24259));
    } else {
      heff_drop(v_t_24262);
      V v_m_24263 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24259));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam23, 1, 2, (V[]){v_m_24263, v_p_24258});
    }
  }
  case TAG_RLam: {
    V v_xs_24273 = heff_field(v_x2_241, 0);
    V v_fv_24274 = heff_field(v_x2_241, 1);
    V v_held_24275 = heff_field(v_x2_241, 2);
    V v_x24_24276 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    switch (heff_tag_of(v_x24_24276)) {
    case TAG_MkCode: {
      V v_body_24277 = heff_field(v_x24_24276, 0);
      heff_take_n(v_x24_24276, 1ULL, 1);
      return heff_tail(((V)&g_heff_2ecompile_2eemitc_2elamC_clo), 5, (V[]){v_k_240, v_xs_24273, v_fv_24274, v_held_24275, v_body_24277});
    }
    default: return heff_nomatch(v_x24_24276);
    }
  }
  case TAG_RCall: {
    V v_g_24278 = heff_field(v_x2_241, 0);
    V v_tr_24279 = heff_field(v_x2_241, 1);
    V v_w_24280 = heff_field(v_x2_241, 2);
    V v_args_24281 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    return ({ V a_0 = v_k_240; V a_1 = v_g_24278; V a_2 = v_tr_24279; V a_3 = v_w_24280; V a_4 = v_args_24281; V r_ = (g_heff_2ecompile_2eemitc_2ecallC(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_g_24278); heff_drop(v_tr_24279); heff_drop(v_w_24280); r_; });
  }
  case TAG_RApply: {
    V v_f_24282 = heff_field(v_x2_241, 0);
    V v_es_24283 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RApply = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_24284 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), heff_tag_at_n(v_ru_24x2_241_24RApply, TAG_Cons, 2, (V[]){v_f_24282, heff_dup(v_es_24283)})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam24, 1, 2, (V[]){v_m_24284, v_es_24283});
  }
  case TAG_RBool: {
    V v_c_24307 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_24308 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_c_24307));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam25, 1, 1, (V[]){v_m_24308});
  }
  case TAG_RAbandon: {
    heff_drop_rec(v_k_240, 6);
    return ((V)&g_heff_2ecompile_2eemitc_2eexpF_lam26_clo);
  }
  case TAG_RBox: {
    V v_r_24315 = heff_field(v_x2_241, 0);
    V v_e_24316 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24318;
    switch (heff_tag_of(v_r_24315)) {
    case TAG_RepV: {
      v_t_24318 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str153);
      break;
    }
    case TAG_RepFix: {
      V v_w_24317 = heff_field(v_r_24315, 0);
      heff_take_n(v_r_24315, 1ULL, 1);
      v_t_24318 = ({ V a_0 = v_w_24317; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24317); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24318 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str154);
      break;
    }
    case TAG_RepInt: {
      v_t_24318 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str155);
      break;
    }
    default: heff_nomatch(v_r_24315);
    }
    V v_pre_24319 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str156), heff_strAppend(v_t_24318, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str157)));
    V v_m_24320 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24316}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam27, 1, 2, (V[]){v_m_24320, v_pre_24319});
  }
  case TAG_RUnbox: {
    V v_r_24326 = heff_field(v_x2_241, 0);
    V v_e_24327 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24329;
    switch (heff_tag_of(v_r_24326)) {
    case TAG_RepV: {
      v_t_24329 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str159);
      break;
    }
    case TAG_RepFix: {
      V v_w_24328 = heff_field(v_r_24326, 0);
      heff_take_n(v_r_24326, 1ULL, 1);
      v_t_24329 = ({ V a_0 = v_w_24328; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24328); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24329 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str160);
      break;
    }
    case TAG_RepInt: {
      v_t_24329 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str161);
      break;
    }
    default: heff_nomatch(v_r_24326);
    }
    V v_pre_24330 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str162), heff_strAppend(v_t_24329, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str163)));
    V v_m_24331 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24327}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam28, 1, 2, (V[]){v_m_24331, v_pre_24330});
  }
  case TAG_RPeek: {
    V v_r_24337 = heff_field(v_x2_241, 0);
    V v_e_24338 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24340;
    switch (heff_tag_of(v_r_24337)) {
    case TAG_RepV: {
      v_t_24340 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str165);
      break;
    }
    case TAG_RepFix: {
      V v_w_24339 = heff_field(v_r_24337, 0);
      heff_take_n(v_r_24337, 1ULL, 1);
      v_t_24340 = ({ V a_0 = v_w_24339; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24339); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24340 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str166);
      break;
    }
    case TAG_RepInt: {
      v_t_24340 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str167);
      break;
    }
    default: heff_nomatch(v_r_24337);
    }
    V v_pre_24341 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str168), heff_strAppend(v_t_24340, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str169)));
    V v_m_24342 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 6), 1, (V[]){v_e_24338}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam29, 1, 2, (V[]){v_m_24342, v_pre_24341});
  }
  case TAG_RPrimU: {
    V v_p_24348 = heff_field(v_x2_241, 0);
    V v_es_24349 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24350 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24349));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam30, 1, 2, (V[]){v_m_24350, v_p_24348});
  }
  case TAG_RPrimAt: {
    V v_p_24356 = heff_field(v_x2_241, 0);
    V v_r_24357 = heff_field(v_x2_241, 1);
    V v_es_24358 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_24359 = ({ V a_0 = v_p_24356; V b_1 = heff_dup(g_heff_2ecompile_2eowned_2elendingPrims_get()); V r_ = (g_heff_2ecompile_2eowned_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_24361;
    if ((heff_dup(v_t_24359) == NTAG(TAG_True))) {
      heff_drop(v_t_24359);
      V v_t_24360 = (g_list_2eall_24s1465078656x604124530(v_es_24358));
      if ((heff_dup(v_t_24360) == NTAG(TAG_True))) {
        heff_drop(v_t_24360);
        v_t_24361 = (g_list_2eany_24s63755471x810534073(v_es_24358, v_es_24358));
      } else {
        heff_drop(v_t_24360);
        v_t_24361 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_t_24359);
      v_t_24361 = NTAG(TAG_False);
    }
    if ((heff_dup(v_t_24361) == NTAG(TAG_True))) {
      heff_drop(v_t_24361);
      V v_t_24363;
      switch (heff_tag_of(v_r_24357)) {
      case TAG_RepV: {
        v_t_24363 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str171);
        break;
      }
      case TAG_RepFix: {
        V v_w_24362 = heff_field(v_r_24357, 0);
        heff_take_n(v_r_24357, 1ULL, 1);
        v_t_24363 = ({ V a_0 = v_w_24362; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24362); r_; });
        break;
      }
      case TAG_RepF64: {
        v_t_24363 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str172);
        break;
      }
      case TAG_RepInt: {
        v_t_24363 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str173);
        break;
      }
      default: heff_nomatch(v_r_24357);
      }
      return (g_heff_2ecompile_2eemitc_2elentPrimC(v_k_240, v_p_24356, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str174), v_t_24363), v_es_24358));
    } else {
      heff_drop(v_t_24361);
      V v_m_24364 = (g_prelude_2etraverse_24s1362847681x1386678580(heff_get_n(v_k_240, 0, 6), v_es_24358));
      return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam31, 1, 3, (V[]){v_m_24364, v_r_24357, v_p_24356});
    }
  }
  case TAG_RFixU: {
    V v_w_24377 = heff_field(v_x2_241, 0);
    V v_n_24378 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_k_240, 6);
    V v_x_24379 = ({ V a_0 = v_w_24377; V a_1 = v_n_24378; V r_ = (g_heff_2ecompile_2eemitc_2efixedConst(a_0, a_1)); heff_drop(v_w_24377); r_; });
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam32, 1, 1, (V[]){v_x_24379});
  }
  case TAG_RF32U: {
    V v_x_24381 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam33, 1, 1, (V[]){v_x_24381});
  }
  case TAG_RF64U: {
    V v_x_24386 = heff_tget_v(v_x2_241, 0);
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_k_240, 6);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam34, 1, 1, (V[]){v_x_24386});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eexpF(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2eexpF_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_244, v_s_245});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_2410});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam2(V self, V *args) {
  V v_s_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2414, v_s_2415});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam3(V self, V *args) {
  V v_s_2420 = args[0];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_s_2420});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2423, v_s_2424});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam5(V self, V *args) {
  V v_s_2426 = args[0];
  V v_n_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429;
  if ((heff_intLt_c_lent(v_n_2425, HEFF_BIG("4611686018427387904"), 2) && heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_n_2425, 1))) {
    V v_t_2427 = heff_strAppend(heff_intShow(v_n_2425), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str17));
    v_t_2429 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str18), v_t_2427);
  } else {
    V v_t_2428 = heff_strAppend(heff_intShow(v_n_2425), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str19));
    v_t_2429 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str20), v_t_2428);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2429, v_s_2426});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam6(V self, V *args) {
  V v_s_2431 = args[0];
  V v_x_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433;
  if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2430)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str21))) {
    heff_drop(v_x_2430);
    v_t_2433 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str22);
  } else {
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2430)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str23))) {
      heff_drop(v_x_2430);
      v_t_2433 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str24);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2430)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str25))) {
        heff_drop(v_x_2430);
        v_t_2433 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str26);
      } else {
        V v_t_2432 = heff_strAppend(heff_floatShow(v_x_2430), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str27));
        v_t_2433 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str28), v_t_2432);
      }
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, v_s_2431});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam7(V self, V *args) {
  V v_s_2439 = args[0];
  V v_x_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2438, v_s_2439});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam8(V self, V *args) {
  V v_s_2441 = args[0];
  V v_x_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_strAppend(heff_floatShow(v_x_2440), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str31));
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str32), v_t_2442), v_s_2441});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam9(V self, V *args) {
  V v_s_2447 = args[0];
  V v_x_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2446, v_s_2447});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam10(V self, V *args) {
  V v_s_2452 = args[0];
  V v_m_2451 = heff_env(self)[0];
  V v_t_2448 = heff_env(self)[1];
  V v_es_2450 = heff_env(self)[2];
  V v_flat_2449 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2453 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_s_2452}));
  switch (heff_tag_of(v_x2_2453)) {
  case TAG_MkPair: {
    V v_x_2454 = heff_field(v_x2_2453, 0);
    V v_s_2455 = heff_field(v_x2_2453, 1);
    V v_ru_24x2_2453_24MkPair = heff_take_reuse_n(v_x2_2453, 3ULL, 2);
    V v_x_2476;
    if (((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_t_2448, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_t_2448, MK_INT(0LL), 2)) == ((int64_t)35ULL)))) {
      heff_drop(v_t_2448);
      heff_drop(v_flat_2449);
      V v_n_2456 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2450; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2450); r_; });
      V v_t_2457 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str37), heff_intShow(v_n_2456));
      V v_t_2460;
      switch (heff_tag_of(v_x_2454)) {
      case TAG_Nil: {
        v_t_2460 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str38);
        break;
      }
      case TAG_Cons: {
        V v_x_2458 = heff_field(v_x_2454, 0);
        V v_xs_2459 = heff_field(v_x_2454, 1);
        heff_take_n(v_x_2454, 3ULL, 2);
        v_t_2460 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str39); V a_1 = v_x_2458; V a_2 = v_xs_2459; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2459); r_; });
        break;
      }
      default: heff_nomatch(v_x_2454);
      }
      V v_t_2461 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str40), heff_strAppend(v_t_2460, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str41)));
      v_x_2476 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str42), heff_strAppend(v_t_2457, v_t_2461));
    } else {
      V v_t_2462;
      if (heff_intEq_c_lent(v_flat_2449, MK_INT(0LL), 2)) {
        v_t_2462 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str43);
      } else {
        v_t_2462 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str44);
      }
      V v_t_2463 = ({ V a_0 = v_t_2448; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str45); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2448); r_; });
      V v_t_2464 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2450; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2450); r_; });
      V v_t_2466;
      if (heff_intEq_c_lent(v_flat_2449, MK_INT(0LL), 2)) {
        heff_drop(v_flat_2449);
        v_t_2466 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str46);
      } else {
        V v_t_2465 = heff_strAppend(heff_intShow(v_flat_2449), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str47));
        v_t_2466 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str48), v_t_2465);
      }
      V v_t_2472;
      switch (heff_tag_of(v_x_2454)) {
      case TAG_Nil: {
        v_t_2472 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str49);
        break;
      }
      case TAG_Cons: {
        V v_t_2471;
        switch (heff_tag_of(v_x_2454)) {
        case TAG_Nil: {
          v_t_2471 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str50);
          break;
        }
        case TAG_Cons: {
          V v_x_2469 = heff_field(v_x_2454, 0);
          V v_xs_2470 = heff_field(v_x_2454, 1);
          heff_take_n(v_x_2454, 3ULL, 2);
          v_t_2471 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str51); V a_1 = v_x_2469; V a_2 = v_xs_2470; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2470); r_; });
          break;
        }
        default: heff_nomatch(v_x_2454);
        }
        v_t_2472 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str52), heff_strAppend(v_t_2471, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str53)));
        break;
      }
      default: heff_nomatch(v_x_2454);
      }
      V v_t_2473 = heff_strAppend(v_t_2466, heff_strAppend(v_t_2472, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str54)));
      V v_t_2474 = heff_strAppend(heff_intShow(v_t_2464), v_t_2473);
      V v_t_2475 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str55), v_t_2463), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str56), v_t_2474));
      v_x_2476 = heff_strAppend(v_t_2462, v_t_2475);
    }
    return heff_tag_at_n(v_ru_24x2_2453_24MkPair, TAG_MkPair, 2, (V[]){v_x_2476, v_s_2455});
  }
  default: return heff_nomatch(v_x2_2453);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam11(V self, V *args) {
  V v_s_2482 = args[0];
  V v_m_2481 = heff_env(self)[0];
  V v_flat_2479 = heff_env(self)[1];
  V v_t_2478 = heff_env(self)[2];
  V v_es_2480 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2483 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_s_2482}));
  switch (heff_tag_of(v_x2_2483)) {
  case TAG_MkPair: {
    V v_x_2484 = heff_field(v_x2_2483, 0);
    V v_s_2485 = heff_field(v_x2_2483, 1);
    V v_ru_24x2_2483_24MkPair = heff_take_reuse_n(v_x2_2483, 3ULL, 2);
    V v_t_2486;
    if (heff_intEq_c_lent(v_flat_2479, MK_INT(0LL), 2)) {
      v_t_2486 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str57);
    } else {
      v_t_2486 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str58);
    }
    V v_t_2489;
    switch (heff_tag_of(v_x_2484)) {
    case TAG_Nil: {
      v_t_2489 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str59);
      break;
    }
    case TAG_Cons: {
      V v_x_2487 = heff_dup(heff_field(v_x_2484, 0));
      v_t_2489 = v_x_2487;
      break;
    }
    default: heff_nomatch(v_x_2484);
    }
    V v_t_2490 = ({ V a_0 = v_t_2478; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str60); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_t_2478); r_; });
    V v_t_2491 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2480; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_2480); r_; });
    V v_t_2493;
    if (heff_intEq_c_lent(v_flat_2479, MK_INT(0LL), 2)) {
      heff_drop(v_flat_2479);
      v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str61);
    } else {
      V v_t_2492 = heff_strAppend(heff_intShow(v_flat_2479), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str62));
      v_t_2493 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str63), v_t_2492);
    }
    HeffT3 v_t_2494 = ({ V a_0 = MK_INT(1LL); V a_1 = v_x_2484; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_x_2484); r_; });
    V v_t_24103;
    {
      V v_field_2496 = v_t_2494.f[1];
      V v_field_2497 = v_t_2494.f[2];
      int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
      if ((v_tag_2495 == ((int64_t)0ULL))) {
        V v_x11_2498 = heff_dup(v_field_2496);
        heff_drop(v_x11_2498);
        V v_x12_2499 = heff_dup(v_field_2497);
        heff_drop(v_x12_2499);
        V v_t_24102;
        if ((v_tag_2495 == ((int64_t)0ULL))) {
          V v_x_24100 = v_field_2496;
          V v_xs_24101 = v_field_2497;
          v_t_24102 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str64); V a_1 = v_x_24100; V a_2 = v_xs_24101; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24101); r_; });
        } else {
          heff_drop(v_field_2496);
          heff_drop(v_field_2497);
          v_t_24102 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str65);
        }
        v_t_24103 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str66), heff_strAppend(v_t_24102, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str67)));
      } else {
        heff_drop(v_field_2496);
        heff_drop(v_field_2497);
        v_t_24103 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str68);
      }
    }
    V v_t_24104 = heff_strAppend(v_t_2493, heff_strAppend(v_t_24103, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str69)));
    V v_t_24105 = heff_strAppend(heff_intShow(v_t_2491), v_t_24104);
    V v_t_24106 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str70), v_t_2490), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str71), v_t_24105));
    V v_t_24107 = heff_strAppend(v_t_2489, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str72), v_t_24106));
    V v_x_24108 = heff_strAppend(v_t_2486, v_t_24107);
    return heff_tag_at_n(v_ru_24x2_2483_24MkPair, TAG_MkPair, 2, (V[]){v_x_24108, v_s_2485});
  }
  default: return heff_nomatch(v_x2_2483);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam12(V self, V *args) {
  V v_s_24113 = args[0];
  V v_m_24112 = heff_env(self)[0];
  V v_ls_24109 = heff_env(self)[1];
  V v_flat_24110 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24114 = heff_tr(heff_call(v_m_24112, 1, (V[]){v_s_24113}));
  switch (heff_tag_of(v_x2_24114)) {
  case TAG_MkPair: {
    V v_x_24115 = heff_field(v_x2_24114, 0);
    V v_s_24116 = heff_field(v_x2_24114, 1);
    V v_ru_24x2_24114_24MkPair = heff_take_reuse_n(v_x2_24114, 3ULL, 2);
    HeffT2 v_t_24117 = (g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(heff_dup(v_ls_24109), v_s_24116));
    {
      V v_field_24118 = v_t_24117.f[0];
      V v_field_24119 = v_t_24117.f[1];
      V v_x_24120 = v_field_24118;
      V v_s_24121 = v_field_24119;
      V v_t_24122;
      if (heff_intEq_c_lent(v_flat_24110, MK_INT(0LL), 2)) {
        v_t_24122 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str73);
      } else {
        v_t_24122 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str74);
      }
      V v_t_24123 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ls_24109; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_ls_24109); r_; });
      V v_t_24125;
      if (heff_intEq_c_lent(v_flat_24110, MK_INT(0LL), 2)) {
        heff_drop(v_flat_24110);
        v_t_24125 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str75);
      } else {
        V v_t_24124 = heff_strAppend(heff_intShow(v_flat_24110), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str76));
        v_t_24125 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str77), v_t_24124);
      }
      V v_t_24131;
      switch (heff_tag_of(v_x_24115)) {
      case TAG_Nil: {
        v_t_24131 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str78);
        break;
      }
      case TAG_Cons: {
        V v_t_24130;
        switch (heff_tag_of(v_x_24115)) {
        case TAG_Nil: {
          v_t_24130 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str79);
          break;
        }
        case TAG_Cons: {
          V v_x_24128 = heff_field(v_x_24115, 0);
          V v_xs_24129 = heff_field(v_x_24115, 1);
          heff_take_n(v_x_24115, 3ULL, 2);
          v_t_24130 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str80); V a_1 = v_x_24128; V a_2 = v_xs_24129; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24129); r_; });
          break;
        }
        default: heff_nomatch(v_x_24115);
        }
        v_t_24131 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str81), heff_strAppend(v_t_24130, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str82)));
        break;
      }
      default: heff_nomatch(v_x_24115);
      }
      V v_t_24132 = heff_strAppend(v_t_24125, heff_strAppend(v_t_24131, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str83)));
      V v_t_24133 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str84), heff_strAppend(v_x_24120, v_t_24132));
      V v_t_24134 = heff_strAppend(heff_intShow(v_t_24123), v_t_24133);
      V v_x_24135 = heff_strAppend(v_t_24122, v_t_24134);
      return heff_tag_at_n(v_ru_24x2_24114_24MkPair, TAG_MkPair, 2, (V[]){v_x_24135, v_s_24121});
    }
  }
  default: return heff_nomatch(v_x2_24114);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam13(V self, V *args) {
  V v_s_24146 = args[0];
  V v_m_24145 = heff_env(self)[0];
  V v_ls_24141 = heff_env(self)[1];
  V v_su_24143 = heff_env(self)[2];
  V v_flat_24139 = heff_env(self)[3];
  V v_kept_24138 = heff_env(self)[4];
  V v_changed_24142 = heff_env(self)[5];
  V v_x_24136 = heff_env(self)[6];
  V v_keep_24137 = heff_env(self)[7];
  V v_n_24140 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x2_24147 = heff_tr(heff_call(v_m_24145, 1, (V[]){v_s_24146}));
  switch (heff_tag_of(v_x2_24147)) {
  case TAG_MkPair: {
    V v_x_24148 = heff_field(v_x2_24147, 0);
    V v_s_24149 = heff_field(v_x2_24147, 1);
    V v_ru_24x2_24147_24MkPair = heff_take_reuse_n(v_x2_24147, 3ULL, 2);
    HeffT2 v_t_24150 = (g_heff_2ecompile_2eemitc_2eshapeLit_24cpr(v_ls_24141, v_s_24149));
    {
      V v_field_24151 = v_t_24150.f[0];
      V v_field_24152 = v_t_24150.f[1];
      V v_x_24153 = v_field_24151;
      V v_s_24154 = v_field_24152;
      V v_t_24155;
      if ((heff_dup(v_su_24143) == NTAG(TAG_True))) {
        heff_drop(v_su_24143);
        v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str85);
      } else {
        heff_drop(v_su_24143);
        v_t_24155 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str86);
      }
      V v_t_24156 = heff_strAppend(heff_intShow(v_flat_24139), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str87));
      V v_t_24157 = heff_strAppend(heff_intShow(v_kept_24138), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str88), v_t_24156));
      V v_t_24158 = (g_list_2emap_24s1937570095x2110149801(v_changed_24142));
      V v_x_24159 = ({ V a_0 = v_t_24155; V a_1 = v_x_24136; V a_2 = v_x_24153; V a_3 = v_keep_24137; V a_4 = v_t_24157; V a_5 = v_n_24140; V a_6 = v_x_24148; V a_7 = v_t_24158; V r_ = (g_heff_2ecompile_2eemitc_2eupdateText(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_24136); r_; });
      return heff_tag_at_n(v_ru_24x2_24147_24MkPair, TAG_MkPair, 2, (V[]){v_x_24159, v_s_24154});
    }
  }
  default: return heff_nomatch(v_x2_24147);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam14(V self, V *args) {
  V v_s_24163 = args[0];
  V v_m_24162 = heff_env(self)[0];
  V v_i_24161 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24164 = heff_tr(heff_call(v_m_24162, 1, (V[]){v_s_24163}));
  switch (heff_tag_of(v_x2_24164)) {
  case TAG_MkPair: {
    V v_x_24165 = heff_field(v_x2_24164, 0);
    V v_s_24166 = heff_field(v_x2_24164, 1);
    V v_ru_24x2_24164_24MkPair = heff_take_reuse_n(v_x2_24164, 3ULL, 2);
    V v_t_24167 = heff_strAppend(heff_intShow(v_i_24161), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str89));
    V v_t_24168 = heff_strAppend(v_x_24165, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str90), v_t_24167));
    return heff_tag_at_n(v_ru_24x2_24164_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str91), v_t_24168), v_s_24166});
  }
  default: return heff_nomatch(v_x2_24164);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam15(V self, V *args) {
  V v_s_24171 = args[0];
  V v_m_24170 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24172 = heff_tr(heff_call(v_m_24170, 1, (V[]){v_s_24171}));
  switch (heff_tag_of(v_x2_24172)) {
  case TAG_MkPair: {
    V v_x_24173 = heff_field(v_x2_24172, 0);
    V v_s_24174 = heff_field(v_x2_24172, 1);
    V v_ru_24x2_24172_24MkPair = heff_take_reuse_n(v_x2_24172, 3ULL, 2);
    V v_t_24175 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str92), heff_strAppend(v_x_24173, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str93)));
    return heff_tag_at_n(v_ru_24x2_24172_24MkPair, TAG_MkPair, 2, (V[]){v_t_24175, v_s_24174});
  }
  default: return heff_nomatch(v_x2_24172);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam16(V self, V *args) {
  V v_s_24179 = args[0];
  V v_m_24178 = heff_env(self)[0];
  V v_i_24177 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24180 = heff_tr(heff_call(v_m_24178, 1, (V[]){v_s_24179}));
  switch (heff_tag_of(v_x2_24180)) {
  case TAG_MkPair: {
    V v_x_24181 = heff_field(v_x2_24180, 0);
    V v_s_24182 = heff_field(v_x2_24180, 1);
    V v_ru_24x2_24180_24MkPair = heff_take_reuse_n(v_x2_24180, 3ULL, 2);
    V v_t_24183 = heff_strAppend(heff_intShow(v_i_24177), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str94));
    V v_t_24184 = heff_strAppend(v_x_24181, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str95), v_t_24183));
    return heff_tag_at_n(v_ru_24x2_24180_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str96), v_t_24184), v_s_24182});
  }
  default: return heff_nomatch(v_x2_24180);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam17(V self, V *args) {
  V v_s_24189 = args[0];
  V v_m_24188 = heff_env(self)[0];
  V v_n_24187 = heff_env(self)[1];
  V v_i_24186 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24190 = heff_tr(heff_call(v_m_24188, 1, (V[]){v_s_24189}));
  switch (heff_tag_of(v_x2_24190)) {
  case TAG_MkPair: {
    V v_x_24191 = heff_field(v_x2_24190, 0);
    V v_s_24192 = heff_field(v_x2_24190, 1);
    V v_ru_24x2_24190_24MkPair = heff_take_reuse_n(v_x2_24190, 3ULL, 2);
    V v_t_24193 = heff_strAppend(heff_intShow(v_n_24187), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str97));
    V v_t_24194 = heff_strAppend(heff_intShow(v_i_24186), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str98), v_t_24193));
    V v_t_24195 = heff_strAppend(v_x_24191, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str99), v_t_24194));
    return heff_tag_at_n(v_ru_24x2_24190_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str100), v_t_24195), v_s_24192});
  }
  default: return heff_nomatch(v_x2_24190);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam18(V self, V *args) {
  V v_s_24205 = args[0];
  V v_m_24204 = heff_env(self)[0];
  V v_i_24199 = heff_env(self)[1];
  V v_pre_24203 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24206 = heff_tr(heff_call(v_m_24204, 1, (V[]){v_s_24205}));
  switch (heff_tag_of(v_x2_24206)) {
  case TAG_MkPair: {
    V v_x_24207 = heff_field(v_x2_24206, 0);
    V v_s_24208 = heff_field(v_x2_24206, 1);
    V v_ru_24x2_24206_24MkPair = heff_take_reuse_n(v_x2_24206, 3ULL, 2);
    V v_t_24209 = heff_strAppend(heff_intShow(v_i_24199), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str107));
    V v_t_24210 = heff_strAppend(v_x_24207, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str108), v_t_24209));
    return heff_tag_at_n(v_ru_24x2_24206_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_pre_24203, v_t_24210), v_s_24208});
  }
  default: return heff_nomatch(v_x2_24206);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam19(V self, V *args) {
  V v_s_24221 = args[0];
  V v_m_24220 = heff_env(self)[0];
  V v_n_24215 = heff_env(self)[1];
  V v_i_24214 = heff_env(self)[2];
  V v_pre_24219 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24222 = heff_tr(heff_call(v_m_24220, 1, (V[]){v_s_24221}));
  switch (heff_tag_of(v_x2_24222)) {
  case TAG_MkPair: {
    V v_x_24223 = heff_field(v_x2_24222, 0);
    V v_s_24224 = heff_field(v_x2_24222, 1);
    V v_ru_24x2_24222_24MkPair = heff_take_reuse_n(v_x2_24222, 3ULL, 2);
    V v_t_24225 = heff_strAppend(heff_intShow(v_n_24215), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str115));
    V v_t_24226 = heff_strAppend(heff_intShow(v_i_24214), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str116), v_t_24225));
    V v_t_24227 = heff_strAppend(v_x_24223, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str117), v_t_24226));
    return heff_tag_at_n(v_ru_24x2_24222_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_pre_24219, v_t_24227), v_s_24224});
  }
  default: return heff_nomatch(v_x2_24222);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam20(V self, V *args) {
  V v_s_24234 = args[0];
  V v_m_24233 = heff_env(self)[0];
  V v_pre_24232 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24235 = heff_tr(heff_call(v_m_24233, 1, (V[]){v_s_24234}));
  switch (heff_tag_of(v_x2_24235)) {
  case TAG_MkPair: {
    V v_x_24236 = heff_field(v_x2_24235, 0);
    V v_s_24237 = heff_field(v_x2_24235, 1);
    V v_ru_24x2_24235_24MkPair = heff_take_reuse_n(v_x2_24235, 3ULL, 2);
    V v_t_24238 = heff_strAppend(v_pre_24232, heff_strAppend(v_x_24236, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str123)));
    return heff_tag_at_n(v_ru_24x2_24235_24MkPair, TAG_MkPair, 2, (V[]){v_t_24238, v_s_24237});
  }
  default: return heff_nomatch(v_x2_24235);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam21(V self, V *args) {
  V v_s_24245 = args[0];
  V v_x_24244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24244, v_s_24245});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam22(V self, V *args) {
  V v_s_24252 = args[0];
  V v_m_24251 = heff_env(self)[0];
  V v_post_24250 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24253 = heff_tr(heff_call(v_m_24251, 1, (V[]){v_s_24252}));
  switch (heff_tag_of(v_x2_24253)) {
  case TAG_MkPair: {
    V v_x_24254 = heff_field(v_x2_24253, 0);
    V v_s_24255 = heff_field(v_x2_24253, 1);
    V v_ru_24x2_24253_24MkPair = heff_take_reuse_n(v_x2_24253, 3ULL, 2);
    V v_t_24256 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str133), heff_strAppend(v_x_24254, v_post_24250));
    return heff_tag_at_n(v_ru_24x2_24253_24MkPair, TAG_MkPair, 2, (V[]){v_t_24256, v_s_24255});
  }
  default: return heff_nomatch(v_x2_24253);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam23(V self, V *args) {
  V v_s_24264 = args[0];
  V v_m_24263 = heff_env(self)[0];
  V v_p_24258 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24265 = heff_tr(heff_call(v_m_24263, 1, (V[]){v_s_24264}));
  switch (heff_tag_of(v_x2_24265)) {
  case TAG_MkPair: {
    V v_x_24266 = heff_field(v_x2_24265, 0);
    V v_s_24267 = heff_field(v_x2_24265, 1);
    V v_ru_24x2_24265_24MkPair = heff_take_reuse_n(v_x2_24265, 3ULL, 2);
    V v_t_24270;
    switch (heff_tag_of(v_x_24266)) {
    case TAG_Nil: {
      v_t_24270 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str135);
      break;
    }
    case TAG_Cons: {
      V v_x_24268 = heff_field(v_x_24266, 0);
      V v_xs_24269 = heff_field(v_x_24266, 1);
      heff_take_n(v_x_24266, 3ULL, 2);
      v_t_24270 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str136); V a_1 = v_x_24268; V a_2 = v_xs_24269; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24269); r_; });
      break;
    }
    default: heff_nomatch(v_x_24266);
    }
    V v_t_24271 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str137), heff_strAppend(v_t_24270, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str138)));
    V v_x_24272 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str139), v_p_24258), v_t_24271);
    return heff_tag_at_n(v_ru_24x2_24265_24MkPair, TAG_MkPair, 2, (V[]){v_x_24272, v_s_24267});
  }
  default: return heff_nomatch(v_x2_24265);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam24(V self, V *args) {
  V v_s_24285 = args[0];
  V v_m_24284 = heff_env(self)[0];
  V v_es_24283 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24286 = heff_tr(heff_call(v_m_24284, 1, (V[]){v_s_24285}));
  switch (heff_tag_of(v_x2_24286)) {
  case TAG_MkPair: {
    V v_x_24287 = heff_field(v_x2_24286, 0);
    V v_s_24288 = heff_field(v_x2_24286, 1);
    V v_ru_24x2_24286_24MkPair = heff_take_reuse_n(v_x2_24286, 3ULL, 2);
    V v_t_24291;
    switch (heff_tag_of(v_x_24287)) {
    case TAG_Nil: {
      v_t_24291 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str140);
      break;
    }
    case TAG_Cons: {
      V v_x_24289 = heff_dup(heff_field(v_x_24287, 0));
      v_t_24291 = v_x_24289;
      break;
    }
    default: heff_nomatch(v_x_24287);
    }
    V v_t_24292 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_24283; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_es_24283); r_; });
    HeffT3 v_t_24293 = ({ V a_0 = MK_INT(1LL); V a_1 = v_x_24287; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_x_24287); r_; });
    V v_t_24302;
    {
      V v_field_24295 = v_t_24293.f[1];
      V v_field_24296 = v_t_24293.f[2];
      int64_t v_tag_24294 = ((int64_t)v_t_24293.f[0]);
      if ((v_tag_24294 == ((int64_t)0ULL))) {
        V v_x11_24297 = heff_dup(v_field_24295);
        heff_drop(v_x11_24297);
        V v_x12_24298 = heff_dup(v_field_24296);
        heff_drop(v_x12_24298);
        V v_t_24301;
        if ((v_tag_24294 == ((int64_t)0ULL))) {
          V v_x_24299 = v_field_24295;
          V v_xs_24300 = v_field_24296;
          v_t_24301 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str141); V a_1 = v_x_24299; V a_2 = v_xs_24300; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24300); r_; });
        } else {
          heff_drop(v_field_24295);
          heff_drop(v_field_24296);
          v_t_24301 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str142);
        }
        v_t_24302 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str143), heff_strAppend(v_t_24301, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str144)));
      } else {
        heff_drop(v_field_24295);
        heff_drop(v_field_24296);
        v_t_24302 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str145);
      }
    }
    V v_t_24303 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str146), heff_strAppend(v_t_24302, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str147)));
    V v_t_24304 = heff_strAppend(heff_intShow(v_t_24292), v_t_24303);
    V v_t_24305 = heff_strAppend(v_t_24291, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str148), v_t_24304));
    V v_x_24306 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str149), v_t_24305);
    return heff_tag_at_n(v_ru_24x2_24286_24MkPair, TAG_MkPair, 2, (V[]){v_x_24306, v_s_24288});
  }
  default: return heff_nomatch(v_x2_24286);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam25(V self, V *args) {
  V v_s_24309 = args[0];
  V v_m_24308 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24310 = heff_tr(heff_call(v_m_24308, 1, (V[]){v_s_24309}));
  switch (heff_tag_of(v_x2_24310)) {
  case TAG_MkPair: {
    V v_x_24311 = heff_field(v_x2_24310, 0);
    V v_s_24312 = heff_field(v_x2_24310, 1);
    V v_ru_24x2_24310_24MkPair = heff_take_reuse_n(v_x2_24310, 3ULL, 2);
    V v_t_24313 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str150), heff_strAppend(v_x_24311, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str151)));
    return heff_tag_at_n(v_ru_24x2_24310_24MkPair, TAG_MkPair, 2, (V[]){v_t_24313, v_s_24312});
  }
  default: return heff_nomatch(v_x2_24310);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam26(V self, V *args) {
  V v_s_24314 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eexpF_str152), v_s_24314});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam27(V self, V *args) {
  V v_s_24321 = args[0];
  V v_m_24320 = heff_env(self)[0];
  V v_pre_24319 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24322 = heff_tr(heff_call(v_m_24320, 1, (V[]){v_s_24321}));
  switch (heff_tag_of(v_x2_24322)) {
  case TAG_MkPair: {
    V v_x_24323 = heff_field(v_x2_24322, 0);
    V v_s_24324 = heff_field(v_x2_24322, 1);
    V v_ru_24x2_24322_24MkPair = heff_take_reuse_n(v_x2_24322, 3ULL, 2);
    V v_t_24325 = heff_strAppend(v_pre_24319, heff_strAppend(v_x_24323, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str158)));
    return heff_tag_at_n(v_ru_24x2_24322_24MkPair, TAG_MkPair, 2, (V[]){v_t_24325, v_s_24324});
  }
  default: return heff_nomatch(v_x2_24322);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam28(V self, V *args) {
  V v_s_24332 = args[0];
  V v_m_24331 = heff_env(self)[0];
  V v_pre_24330 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24333 = heff_tr(heff_call(v_m_24331, 1, (V[]){v_s_24332}));
  switch (heff_tag_of(v_x2_24333)) {
  case TAG_MkPair: {
    V v_x_24334 = heff_field(v_x2_24333, 0);
    V v_s_24335 = heff_field(v_x2_24333, 1);
    V v_ru_24x2_24333_24MkPair = heff_take_reuse_n(v_x2_24333, 3ULL, 2);
    V v_t_24336 = heff_strAppend(v_pre_24330, heff_strAppend(v_x_24334, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str164)));
    return heff_tag_at_n(v_ru_24x2_24333_24MkPair, TAG_MkPair, 2, (V[]){v_t_24336, v_s_24335});
  }
  default: return heff_nomatch(v_x2_24333);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam29(V self, V *args) {
  V v_s_24343 = args[0];
  V v_m_24342 = heff_env(self)[0];
  V v_pre_24341 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24344 = heff_tr(heff_call(v_m_24342, 1, (V[]){v_s_24343}));
  switch (heff_tag_of(v_x2_24344)) {
  case TAG_MkPair: {
    V v_x_24345 = heff_field(v_x2_24344, 0);
    V v_s_24346 = heff_field(v_x2_24344, 1);
    V v_ru_24x2_24344_24MkPair = heff_take_reuse_n(v_x2_24344, 3ULL, 2);
    V v_t_24347 = heff_strAppend(v_pre_24341, heff_strAppend(v_x_24345, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str170)));
    return heff_tag_at_n(v_ru_24x2_24344_24MkPair, TAG_MkPair, 2, (V[]){v_t_24347, v_s_24346});
  }
  default: return heff_nomatch(v_x2_24344);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam30(V self, V *args) {
  V v_s_24351 = args[0];
  V v_m_24350 = heff_env(self)[0];
  V v_p_24348 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24352 = heff_tr(heff_call(v_m_24350, 1, (V[]){v_s_24351}));
  switch (heff_tag_of(v_x2_24352)) {
  case TAG_MkPair: {
    V v_x_24353 = heff_field(v_x2_24352, 0);
    V v_s_24354 = heff_field(v_x2_24352, 1);
    V v_ru_24x2_24352_24MkPair = heff_take_reuse_n(v_x2_24352, 3ULL, 2);
    V v_x_24355 = ({ V a_0 = v_p_24348; V a_1 = v_x_24353; V r_ = (g_heff_2ecompile_2eemitc_2eprimU(a_0, a_1)); heff_drop(v_x_24353); r_; });
    return heff_tag_at_n(v_ru_24x2_24352_24MkPair, TAG_MkPair, 2, (V[]){v_x_24355, v_s_24354});
  }
  default: return heff_nomatch(v_x2_24352);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam31(V self, V *args) {
  V v_s_24365 = args[0];
  V v_m_24364 = heff_env(self)[0];
  V v_r_24357 = heff_env(self)[1];
  V v_p_24356 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24366 = heff_tr(heff_call(v_m_24364, 1, (V[]){v_s_24365}));
  switch (heff_tag_of(v_x2_24366)) {
  case TAG_MkPair: {
    V v_x_24367 = heff_field(v_x2_24366, 0);
    V v_s_24368 = heff_field(v_x2_24366, 1);
    V v_ru_24x2_24366_24MkPair = heff_take_reuse_n(v_x2_24366, 3ULL, 2);
    V v_t_24370;
    switch (heff_tag_of(v_r_24357)) {
    case TAG_RepV: {
      v_t_24370 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str175);
      break;
    }
    case TAG_RepFix: {
      V v_w_24369 = heff_field(v_r_24357, 0);
      heff_take_n(v_r_24357, 1ULL, 1);
      v_t_24370 = ({ V a_0 = v_w_24369; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24369); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24370 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str176);
      break;
    }
    case TAG_RepInt: {
      v_t_24370 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str177);
      break;
    }
    default: heff_nomatch(v_r_24357);
    }
    V v_t_24373;
    switch (heff_tag_of(v_x_24367)) {
    case TAG_Nil: {
      v_t_24373 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str178);
      break;
    }
    case TAG_Cons: {
      V v_x_24371 = heff_field(v_x_24367, 0);
      V v_xs_24372 = heff_field(v_x_24367, 1);
      heff_take_n(v_x_24367, 3ULL, 2);
      v_t_24373 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str179); V a_1 = v_x_24371; V a_2 = v_xs_24372; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24372); r_; });
      break;
    }
    default: heff_nomatch(v_x_24367);
    }
    V v_t_24374 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str180), heff_strAppend(v_t_24373, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str181)));
    V v_t_24375 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str182), heff_strAppend(v_t_24370, v_t_24374));
    V v_x_24376 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str183), v_p_24356), v_t_24375);
    return heff_tag_at_n(v_ru_24x2_24366_24MkPair, TAG_MkPair, 2, (V[]){v_x_24376, v_s_24368});
  }
  default: return heff_nomatch(v_x2_24366);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam32(V self, V *args) {
  V v_s_24380 = args[0];
  V v_x_24379 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24379, v_s_24380});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam33(V self, V *args) {
  V v_s_24382 = args[0];
  V v_x_24381 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24384;
  if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24381)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str184))) {
    heff_drop(v_x_24381);
    v_t_24384 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str185);
  } else {
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24381)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str186))) {
      heff_drop(v_x_24381);
      v_t_24384 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str187);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24381)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str188))) {
        heff_drop(v_x_24381);
        v_t_24384 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str189);
      } else {
        V v_t_24383 = heff_strAppend(heff_floatShow(v_x_24381), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str190));
        v_t_24384 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str191), v_t_24383);
      }
    }
  }
  V v_t_24385 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str192), heff_strAppend(v_t_24384, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str193)));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24385, v_s_24382});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam34(V self, V *args) {
  V v_s_24387 = args[0];
  V v_x_24386 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24389;
  if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24386)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str194))) {
    heff_drop(v_x_24386);
    v_t_24389 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str195);
  } else {
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24386)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str196))) {
      heff_drop(v_x_24386);
      v_t_24389 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str197);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24386)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str198))) {
        heff_drop(v_x_24386);
        v_t_24389 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str199);
      } else {
        V v_t_24388 = heff_strAppend(heff_floatShow(v_x_24386), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str200));
        v_t_24389 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str201), v_t_24388);
      }
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24389, v_s_24387});
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str1, 7, "V f_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str2, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str3, 5, "args[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str4, 4, "] = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str5, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str6, 19, "if (heff_exact(f_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str7, 52, ", args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str8, 21, "return heff_tail(f_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str9, 8, ", args);");
Clo g_heff_2ecompile_2eemitc_2einPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2einPlace_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2einPlace(V v_vs_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_vs_240)) {
  case TAG_Nil: {
    v_t_243 = ((V)&g_heff_2ecompile_2eemitc_2einPlace_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_vs_240, 0);
    v_t_243 = heff_dup(v_x_241);
    break;
  }
  default: heff_nomatch(v_vs_240);
  }
  V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2einPlace_str1), heff_strAppend(v_t_243, ((V)&g_heff_2ecompile_2eemitc_2einPlace_str2)));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  V v_t_246 = (g_list_2edrop(MK_INT(1LL), v_vs_240));
  V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_247, MK_INT(2LL))));
  V v_t_249 = (g_list_2ezipWith_24s706961545x2112949112(((V)&g_heff_2ecompile_2eemitc_2einPlace_str3), ((V)&g_heff_2ecompile_2eemitc_2einPlace_str4), ((V)&g_heff_2ecompile_2eemitc_2einPlace_str5), v_t_246, v_t_248));
  V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2411 = heff_intShow(heff_intSub(v_t_2410, MK_INT(1LL)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2einPlace_str6), heff_strAppend(v_t_2411, ((V)&g_heff_2ecompile_2eemitc_2einPlace_str7)));
  V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2414 = heff_intShow(heff_intSub(v_t_2413, MK_INT(1LL)));
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2einPlace_str8), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemitc_2einPlace_str9)));
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2416})));
  return (g_prelude_2e_2b_2b(v_t_245, v_t_2417));
}
V g_heff_2ecompile_2eemitc_2einPlace_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2einPlace(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperProto_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperProto_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperProto_str2, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperProto_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapperProto_str4, 9, "static V ");
Clo g_heff_2ecompile_2eemitc_2ewrapperProto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ewrapperProto_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ewrapperProto(V v_key_240, V v_rs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkWrapper: {
      V v_ws_244 = heff_field(v_x31_243, 0);
      V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_240, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2ewrapperProto_str0)));
      V v_t_247 = (g_heff_2ecompile_2eemitc_2eckOf(v_rs_241, heff_dup(g_std_2emap_2eempty_get()), MK_INT(0LL)));
      V v_t_248 = (g_heff_2ecompile_2eemitc_2eparamList(v_t_247, heff_dup(v_ws_244)));
      V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapperProto_str1), heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2eemitc_2ewrapperProto_str2)));
      V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapperProto_str3), v_t_246), v_t_249);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapperProto_str4), v_t_2410), NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eemitc_2ewrapperProto_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2ewrapperProto(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str0, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str1, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str2, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str4, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str5, 21, "_entry(V self, V *a);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str8, 5, ", 0};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str9, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str10, 8, "_entry, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str11, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str12, 33, "_clo = {{0x80000000u, K_CLO, 0}, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str13, 11, "static Clo ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str14, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str15, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str16, 1, "V");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str17, 6, "double");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str18, 7, "int64_t");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str19, 6, "top: ;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str20, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str21, 2, " {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str22, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str23, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str24, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str25, 22, "_entry(V self, V *a) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str26, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str27, 13, "  (void)self;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str28, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str29, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str30, 0, "");
Clo g_heff_2ecompile_2eemitc_2efunDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efunDef_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2efunDef(V v_tu_240, V v_f_241, V v_z_242) {
top: ;
  V v_reprs_243 = heff_take_field(v_f_241, 5);
  V v_entry_244 = heff_take_field(v_f_241, 3);
  V v_body_245 = heff_take_field(v_f_241, 4);
  V v_key_246 = heff_take_field(v_f_241, 0);
  V v_wrapper_247 = heff_take_field(v_f_241, 7);
  V v_params_248 = heff_take_field(v_f_241, 1);
  V v_ret_249 = heff_take_field(v_f_241, 6);
  V v_lent_2410 = heff_get_n(v_f_241, 2, 8);
  V v_t_2411 = (g_heff_2ecompile_2eemitc_2eckOf(v_reprs_243, heff_dup(v_tu_240), MK_INT(0LL)));
  V v_m_2412 = heff_tr(heff_call(heff_get_n(v_t_2411, 1, 6), 1, (V[]){v_entry_244}));
  V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_242}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2eemitc_2eckOf(v_reprs_243, heff_dup(v_tu_240), MK_INT(0LL)));
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_t_2416, 1, 6), 1, (V[]){v_body_245}));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2415}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_s_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      V v_m_2421 = (g_heff_2ecompile_2eemitc_2ewrapperCode(v_tu_240, v_key_246, v_reprs_243, v_wrapper_247));
      V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_s_2420}));
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_MkPair: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_s_2424 = heff_field(v_x2_2422, 1);
        V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
        V v_t_2426;
        switch (heff_tag_of(v_ret_249)) {
        case TAG_RepV: {
          v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str0);
          break;
        }
        case TAG_RepFix: {
          V v_w_2425 = heff_dup(heff_field(v_ret_249, 0));
          v_t_2426 = ({ V a_0 = v_w_2425; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2425); r_; });
          break;
        }
        case TAG_RepF64: {
          v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str1);
          break;
        }
        case TAG_RepInt: {
          v_t_2426 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str2);
          break;
        }
        default: heff_nomatch(v_ret_249);
        }
        V v_t_2428;
        switch (heff_tag_of(v_wrapper_247)) {
        case TAG_Nothing: {
          v_t_2428 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          v_t_2428 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_wrapper_247);
        }
        V v_t_2429 = ({ V a_0 = v_key_246; V a_1 = heff_dup(v_params_248); V a_2 = v_reprs_243; V a_3 = v_t_2426; V a_4 = v_t_2428; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2428); r_; });
        V v_t_2430 = (g_heff_2ecompile_2eemitc_2ewrapperProto(v_key_246, v_reprs_243, v_wrapper_247));
        V v_t_2431 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str3)));
        V v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str4), v_t_2431), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str5));
        V v_t_2433 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str6)));
        V v_t_2434 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str7)));
        V v_t_2435 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_params_248));
        V v_t_2436 = heff_strAppend(heff_intShow(v_t_2435), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str8));
        V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str9), v_t_2434), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str10), v_t_2436));
        V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str11), v_t_2433), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str12), v_t_2437));
        V v_t_2439 = heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str13), v_t_2438), NTAG(TAG_Nil)});
        V v_t_2440 = heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str14), v_t_2432), v_t_2439});
        V v_t_2441 = (g_prelude_2e_2b_2b(v_t_2430, v_t_2440));
        V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2429, ((V)&g_heff_2ecompile_2eemitc_2efunDef_str15)), v_t_2441});
        V v_t_2444;
        switch (heff_tag_of(v_ret_249)) {
        case TAG_RepV: {
          v_t_2444 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str16);
          break;
        }
        case TAG_RepFix: {
          V v_w_2443 = heff_field(v_ret_249, 0);
          heff_take_n(v_ret_249, 1ULL, 1);
          v_t_2444 = ({ V a_0 = v_w_2443; V r_ = (g_heff_2ecompile_2eemitc_2efixedType(a_0)); heff_drop(v_w_2443); r_; });
          break;
        }
        case TAG_RepF64: {
          v_t_2444 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str17);
          break;
        }
        case TAG_RepInt: {
          v_t_2444 = ((V)&g_heff_2ecompile_2eemitc_2efunDef_str18);
          break;
        }
        default: heff_nomatch(v_ret_249);
        }
        V v_t_2446;
        switch (heff_tag_of(v_wrapper_247)) {
        case TAG_Nothing: {
          v_t_2446 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_wrapper_247, 0ULL, 1);
          v_t_2446 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_wrapper_247);
        }
        V v_t_2447 = ({ V a_0 = v_key_246; V a_1 = heff_dup(v_params_248); V a_2 = v_reprs_243; V a_3 = v_t_2444; V a_4 = v_t_2446; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_reprs_243); heff_drop(v_t_2446); r_; });
        V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str19), NTAG(TAG_Nil)});
        V v_t_2449 = (g_prelude_2e_2b_2b_24f1306153264x1245859556(v_t_2448, ((V)&g_heff_2ecompile_2eemitc_2efunDef_str20), v_x_2414));
        V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2447, ((V)&g_heff_2ecompile_2eemitc_2efunDef_str21)), v_t_2449});
        V v_t_2451 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ecompile_2eemitc_2efunDef_str22), v_x_2419));
        V v_t_2452 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str23)));
        V v_t_2453 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str24), v_t_2452), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str25));
        V v_t_2454 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_params_248; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_params_248); r_; });
        V v_t_2455 = ({ V a_0 = v_key_246; V a_1 = v_lent_2410; V a_2 = v_t_2454; V r_ = (g_heff_2ecompile_2eemitc_2eentryCall(a_0, a_1, a_2)); heff_drop(v_key_246); r_; });
        V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str26), NTAG(TAG_Nil)});
        V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str27), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_t_2456})});
        V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str28), v_t_2453), v_t_2457});
        V v_t_2459 = (g_prelude_2e_2b_2b(v_x_2423, v_t_2458));
        V v_t_2460 = (g_prelude_2e_2b_2b(v_t_2451, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str29), v_t_2459})));
        V v_t_2461 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str30), v_t_2450}), v_t_2460));
        V v_x_2462 = heff_rec_n(2, shape_protos__code, (V[]){v_t_2442, v_t_2461});
        return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2462, v_s_2424});
      }
      default: return heff_nomatch(v_x2_2422);
      }
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2eemitc_2efunDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2efunDef(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str0, 1, "a");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str2, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eglueCallOf_str4, 1, ")");
Clo g_heff_2ecompile_2eemitc_2eglueCallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eglueCallOf_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eglueCallOf(V v_b_240) {
top: ;
  V v_fun_241 = heff_take_field(v_b_240, 1);
  V v_args_242 = heff_get_n(v_b_240, 2, 5);
  V v_t_243 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_242); r_; });
  V v_x2_244 = (g_list_2emap_24f1005417903x1119563692(((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str0), MK_INT(0LL), heff_intSub(v_t_243, MK_INT(1LL))));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str3), heff_strAppend(v_t_247, ((V)&g_heff_2ecompile_2eemitc_2eglueCallOf_str4)));
  return heff_strAppend(v_fun_241, v_t_248);
}
V g_heff_2ecompile_2eemitc_2eglueCallOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eglueCallOf(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str0, 3, "));");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str1, 31, "    return heff_tail(k, 1, &x);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str2, 17, "    heff_drop(p);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str3, 28, "    V x = heff_answer(f, r);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str4, 33, "    V f = heff_dup(heff_field(p, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str5, 3, "));");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str6, 31, "    return heff_tail(k, 1, &x);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str7, 17, "    heff_drop(p);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str8, 12, "    (void)r;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eanswerLines_str9, 33, "    V x = heff_dup(heff_field(p, ");
Clo g_heff_2ecompile_2eemitc_2eanswerLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eanswerLines_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2eanswerLines(V v_b_240) {
top: ;
  V v_answered_241 = heff_take_field(v_b_240, 4);
  V v_args_242 = heff_get_n(v_b_240, 2, 5);
  if ((heff_dup(v_answered_241) == NTAG(TAG_True))) {
    heff_drop(v_answered_241);
    V v_t_243 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_242); r_; });
    V v_t_244 = heff_strAppend(heff_intShow(v_t_243), ((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str0));
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str1), NTAG(TAG_Nil)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str3), v_t_245})});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str4), v_t_244), v_t_246});
  } else {
    heff_drop(v_answered_241);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_242); r_; });
    V v_t_248 = heff_strAppend(heff_intShow(v_t_247), ((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str5));
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str6), NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str8), v_t_249})});
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eanswerLines_str9), v_t_248), v_t_2410});
  }
}
V g_heff_2ecompile_2eemitc_2eanswerLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eanswerLines(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemptyCS_str0, 0, "");

static V g_heff_2ecompile_2eemitc_2eemptyCS_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eemptyCS_st;
static V g_heff_2ecompile_2eemitc_2eemptyCS_init(void) {
  return heff_rec_n(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){((V)&g_heff_2ecompile_2eemitc_2eemptyCS_str0), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eemptyCS_st)) return g_heff_2ecompile_2eemitc_2eemptyCS_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eemptyCS_val, &g_heff_2ecompile_2eemitc_2eemptyCS_st, g_heff_2ecompile_2eemitc_2eemptyCS_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str0, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str1, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str2, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str3, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str4, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str5, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str6, 1, ",");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str7, 4, "TAG_");
V g_heff_2ecompile_2eemitc_2eceOf_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eceOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eceOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eceOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eceOf(V v_provs_240, V v_facts_241, V v_names_242) {
top: ;
  V v_sureRecs_243 = heff_take_field(v_facts_241, 7);
  V v_sure_244 = heff_take_field(v_facts_241, 6);
  V v_arity_245 = heff_take_field(v_facts_241, 0);
  V v_bounce_246 = heff_take_field(v_facts_241, 1);
  V v_lazy_247 = heff_take_field(v_facts_241, 2);
  V v_lent_248 = heff_take_field(v_facts_241, 3);
  V v_workers_249 = heff_take_field(v_facts_241, 4);
  V v_flat_2410 = heff_take_field(v_facts_241, 5);
  V v_tuples_2411 = heff_take_field(v_facts_241, 8);
  V v_words_2412 = heff_take_field(v_facts_241, 9);
  V v_tokens_2413 = heff_get_n(v_facts_241, 10, 11);
  V v_t_2416;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_names_242, 0);
    v_t_2416 = heff_dup(v_x_2414);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_t_2418 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str0); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2417; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2417); r_; });
  V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2418));
  V v_xs_2420 = (g_list_2ekeepIf_24s478006518x1380334353(v_t_2419));
  V v_m_2421 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_xs_2420; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_xs_2420); r_; });
  V v_t_2422 = ({ V a_0 = v_m_2421; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2421); r_; });
  V v_t_2423 = (g_list_2emap_24s1937570095x2110149801(v_t_2422));
  V v_t_2424 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V a_2 = heff_dup(g_std_2emap_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2enumbered(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2425 = ({ V a_0 = MK_INT(10LL); V a_1 = MK_INT(65526LL); V a_2 = v_t_2423; V a_3 = v_t_2424; V a_4 = heff_dup(g_std_2emap_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2ehashedGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2423); r_; });
  V v_t_2428;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_field(v_names_242, 1);
    v_t_2428 = heff_dup(v_y_2427);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_t_2430 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str1); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2429; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2429); r_; });
  V v_xs_2431 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2430));
  V v_m_2432 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_xs_2431; V r_ = (g_list_2efoldl_24s1923368998x1291788787(a_0, a_1)); heff_drop(v_xs_2431); r_; });
  V v_t_2433 = ({ V a_0 = v_m_2432; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2432); r_; });
  V v_t_2434 = (g_list_2emap_24s1937570095x2110149801(v_t_2433));
  V v_t_2435 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(2147483647LL); V a_2 = v_t_2434; V a_3 = heff_dup(g_std_2emap_2eempty_get()); V a_4 = heff_dup(g_std_2emap_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2ehashedGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2434); r_; });
  V v_t_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_lbls_2437 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str2); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2436; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2436); r_; });
  V v_t_2438 = ({ V a_0 = v_sureRecs_243; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_sureRecs_243); r_; });
  V v_ps_2441 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eemitc_2eceOf_lam0, 1, 1, (V[]){v_lbls_2437}), v_t_2438));
  V v_su_2442 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2441; V r_ = (g_list_2efoldl_24s571527232x333134686(a_0, a_1)); heff_drop(v_ps_2441); r_; });
  V v_t_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_provs_240));
  V v_t_2444 = ({ V b_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str7); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2443; V r_ = (g_list_2efoldl_24s1882737314x358197882(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2443); r_; });
  V v_others_2445 = (g_prelude_2e_2b_2b(heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()), v_t_2444));
  V v_t_2446 = ({ V a_0 = v_sure_244; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_sure_244); r_; });
  V v_ps_2452 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eemitc_2eceOf_lam1, 1, 1, (V[]){v_others_2445}), v_t_2446));
  V v_su_2453 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2452; V r_ = (g_list_2efoldl_24s571527232x333134686(a_0, a_1)); heff_drop(v_ps_2452); r_; });
  return heff_rec_n(3, shape_tags__lbls__facts, (V[]){v_t_2425, v_t_2435, heff_rec_n(11, shape_arity__bounce__lazy__lent__workers__flat__sure__sureRecs__tuples__words__tokens, (V[]){v_arity_245, v_bounce_246, v_lazy_247, v_lent_248, v_workers_249, v_flat_2410, v_su_2453, v_su_2442, v_tuples_2411, v_words_2412, v_tokens_2413})});
}
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eceOf(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eemitc_2eceOf_lam0(V self, V *args) {
  V v_p_2439 = args[0];
  V v_lbls_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2440 = ({ V a_0 = MK_INT(0LL); V a_1 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str3); V a_2 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str4); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str5); V a_4 = v_p_2439; V a_5 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str6); V b_6 = MK_INT(0LL); V a_7 = v_lbls_2437; V r_ = (g_list_2eany_24s1338755034x1627180165(a_0, a_1, a_2, a_3, a_4, a_5, b_6, a_7)); heff_drop(v_p_2439); heff_drop(b_6); heff_drop(v_lbls_2437); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2440) == NTAG(TAG_True)));
  heff_drop(v_x1_2440);
  return v_ret_24bool;
}
V g_heff_2ecompile_2eemitc_2eceOf_lam1(V self, V *args) {
  V v_p_2447 = args[0];
  V v_others_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450;
  switch (heff_tag_of(v_p_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_field(v_p_2447, 0);
    heff_take_n(v_p_2447, 1ULL, 2);
    v_t_2450 = v_x_2448;
    break;
  }
  default: heff_nomatch(v_p_2447);
  }
  V v_x1_2451 = ({ V a_0 = v_t_2450; V a_1 = v_others_2445; V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, a_1)); heff_drop(v_t_2450); heff_drop(v_others_2445); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2451) == NTAG(TAG_True)));
  heff_drop(v_x1_2451);
  return v_ret_24bool;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str1, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str3, 2, "g_");
Clo g_heff_2ecompile_2eemitc_2eemitAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eemitAt_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2eemitAt(V v_ce_240, V v_kept_241, V v_acc_242, V v_d_243, V v_own_244, V v_v_245) {
top: ;
  V v_key_246 = heff_take_field(v_d_243, 0);
  V v_name_247 = heff_get_n(v_d_243, 1, 3);
  HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_kept_241, v_key_246));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    V v_t_2412;
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_k_2411 = v_field_2410;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2411, 0)), heff_dup(v_v_245))) {
        v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){v_k_2411});
      } else {
        heff_drop_rec(v_k_2411, 8);
        v_t_2412 = NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_field_2410);
      v_t_2412 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_ce_240, 2)), 8, 11);
      V v_t_2423;
      switch (heff_tag_of(v_own_244)) {
      case TAG_MkPair: {
        V v_b0_2414 = heff_field(v_own_244, 0);
        V v_n_2415 = heff_field(v_own_244, 1);
        V v_t_2416 = (g_heff_2ecompile_2eimperative_2egenOf(NTAG(TAG_True)));
        HeffT2 v_t_2417 = (g_heff_2ecompile_2eimperative_2edefOf_24cpr(v_t_2416, heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_key_246), v_name_247, heff_dup(v_b0_2414)}), heff_dup(v_n_2415)));
        V v_t_2422;
        {
          V v_field_2418 = v_t_2417.f[0];
          V v_field_2419 = v_t_2417.f[1];
          V v_x_2420 = v_field_2418;
          V v_y_2421 = v_field_2419;
          heff_drop(v_y_2421);
          v_t_2422 = v_x_2420;
        }
        v_t_2423 = (g_heff_2ecompile_2elower_2ercOf(heff_get_n(v_ce_240, 2, 3), v_t_2422));
        break;
      }
      default: heff_nomatch(v_own_244);
      }
      V v_t_2424 = (g_heff_2ecompile_2eemitc_2emangleW(v_key_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eemitAt_str0)));
      V v_o_2425 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eemitAt_str1), v_t_2424);
      V v_t_2426 = heff_rec_n(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){v_o_2425, MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      V v_t_2427 = ({ V a_0 = v_t_2413; V a_1 = v_t_2423; V a_2 = v_t_2426; V r_ = (g_heff_2ecompile_2eemitc_2edefC(a_0, a_1, a_2)); heff_drop(v_t_2423); r_; });
      return (g_heff_2ecompile_2eemitc_2efreshEmitted(v_acc_242, v_key_246, v_v_245, v_t_2427));
    }
    case TAG_Just: {
      V v_k_2428 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      heff_drop_rec(v_ce_240, 3);
      heff_drop(v_v_245);
      heff_drop(v_name_247);
      V v_t_2429 = heff_rec_n(2, shape_protos__code, (V[]){heff_dup(heff_rfield(v_k_2428, 1)), heff_dup(heff_rfield(v_k_2428, 2))});
      V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, heff_take_field(v_acc_242, 0)});
      V v_t_2431 = ({ V a_0 = v_key_246; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_heff_2ecompile_2eemitc_2eemitAt_str2); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_key_246); r_; });
      V v_t_2432 = (g_heff_2ecompile_2eemitc_2emergeKept(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eemitAt_str3), v_t_2431), v_k_2428, heff_take_field(v_acc_242, 1)));
      return ({ V rv_0 = v_t_2430; V rv_1 = v_t_2432; V rr_ = heff_rec_reuse_nf(v_acc_242, 4ULL, 3, shape_ems__s__fresh, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
}
V g_heff_2ecompile_2eemitc_2eemitAt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ecompile_2eemitc_2eemitAt(a[0], a1, a[2], a[3], a4, a[5]); heff_drop(a1); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ethreadsLine_str0, 22, "#define HEFF_THREADS 1");

static V g_heff_2ecompile_2eemitc_2ethreadsLine_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2ethreadsLine_st;
static V g_heff_2ecompile_2eemitc_2ethreadsLine_init(void) {
  return ((V)&g_heff_2ecompile_2eemitc_2ethreadsLine_str0);
}
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2ethreadsLine_st)) return g_heff_2ecompile_2eemitc_2ethreadsLine_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2ethreadsLine_val, &g_heff_2ecompile_2eemitc_2ethreadsLine_st, g_heff_2ecompile_2eemitc_2ethreadsLine_init);
}