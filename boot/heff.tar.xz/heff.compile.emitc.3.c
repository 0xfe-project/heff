// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_DFun 8330
#define TAG_DVal 23084
#define TAG_MkCode 2932
#define TAG_MkWrapper 39179
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_ems 310085
#define LBL_entry 298026124
#define LBL_exp 310423
#define LBL_facts 298546081
#define LBL_fresh 299054408
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lbls 9810500
#define LBL_lent 9813446
#define LBL_nlam 9879345
#define LBL_nstr 9886666
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_reprs 309759928
#define LBL_ret 322331
#define LBL_s 333
#define LBL_shapes 1043573789
#define LBL_stmts 311127493
#define LBL_strs 10036521
#define LBL_tags 10047712
#define LBL_ver 326173
#define LBL_wrapper 1827365593
static uint32_t shape_ems__s__fresh[] = {LBL_ems, LBL_s, LBL_fresh};
static uint32_t shape_owner__nlam__lams__protos__nstr__strs__shapes__prims[] = {LBL_owner, LBL_nlam, LBL_lams, LBL_protos, LBL_nstr, LBL_strs, LBL_shapes, LBL_prims};
static uint32_t shape_protos__code[] = {LBL_protos, LBL_code};
static uint32_t shape_tags__lbls__facts[] = {LBL_tags, LBL_lbls, LBL_facts};
V g_heff_2ecompile_2eemitc_2eagain(V, V, V);
V g_heff_2ecompile_2eemitc_2eagain_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eagain_clo;
V g_heff_2ecompile_2eemitc_2ecallC(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecallC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecallC_clo;
V g_heff_2ecompile_2eemitc_2eceOf(V, V, V);
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eceOf_clo;
V g_heff_2ecompile_2eemitc_2eckOf(V);
V g_heff_2ecompile_2eemitc_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eckOf_clo;
V g_heff_2ecompile_2eemitc_2eemitAt(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eemitAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eemitAt_clo;
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void);
V g_heff_2ecompile_2eemitc_2eentryCall(V, V, V);
V g_heff_2ecompile_2eemitc_2eentryCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eentryCall_clo;
V g_heff_2ecompile_2eemitc_2eexpF(V, V);
V g_heff_2ecompile_2eemitc_2eexpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eexpF_clo;
V g_heff_2ecompile_2eemitc_2efixedConst(V, V);
V g_heff_2ecompile_2eemitc_2efixedConst_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedConst_clo;
V g_heff_2ecompile_2eemitc_2efixedLit(V, V);
V g_heff_2ecompile_2eemitc_2efixedLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedLit_clo;
V g_heff_2ecompile_2eemitc_2efixedSuffix(V);
V g_heff_2ecompile_2eemitc_2efixedSuffix_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedSuffix_clo;
V g_heff_2ecompile_2eemitc_2efixedType(V);
V g_heff_2ecompile_2eemitc_2efixedType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedType_clo;
V g_heff_2ecompile_2eemitc_2efixedU(V, V);
V g_heff_2ecompile_2eemitc_2efixedU_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efixedU_clo;
V g_heff_2ecompile_2eemitc_2efloat64U(V, V);
V g_heff_2ecompile_2eemitc_2efloat64U_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efloat64U_clo;
V g_heff_2ecompile_2eemitc_2efreshEmitted(V, V, V, V);
V g_heff_2ecompile_2eemitc_2efreshEmitted_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efreshEmitted_clo;
V g_heff_2ecompile_2eemitc_2efunDef(V);
V g_heff_2ecompile_2eemitc_2efunDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunDef_clo;
V g_heff_2ecompile_2eemitc_2efunHead(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2efunHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2efunHead_clo;
V g_heff_2ecompile_2eemitc_2ehashedGo(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ehashedGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ehashedGo_clo;
V g_heff_2ecompile_2eemitc_2einPlace(V);
V g_heff_2ecompile_2eemitc_2einPlace_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2einPlace_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2elamC(V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2elamC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2elamC_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2emergeKept(V, V, V);
V g_heff_2ecompile_2eemitc_2emergeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emergeKept_clo;
V g_heff_2ecompile_2eemitc_2enumbered(V, V, V);
V g_heff_2ecompile_2eemitc_2enumbered_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enumbered_clo;
V g_heff_2ecompile_2eemitc_2eparamList(V, V);
V g_heff_2ecompile_2eemitc_2eparamList_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eparamList_clo;
V g_heff_2ecompile_2eemitc_2eprimLit(V, V);
V g_heff_2ecompile_2eemitc_2eprimLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eprimLit_clo;
V g_heff_2ecompile_2eemitc_2eshapeLit(V, V);
V g_heff_2ecompile_2eemitc_2eshapeLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eshapeLit_clo;
V g_heff_2ecompile_2eemitc_2estrLit(V, V, V);
V g_heff_2ecompile_2eemitc_2estrLit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2estrLit_clo;
V g_heff_2ecompile_2eemitc_2etestC(V, V);
V g_heff_2ecompile_2eemitc_2etestC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etestC_clo;
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void);
V g_heff_2ecompile_2eemitc_2etraverseC(V, V);
V g_heff_2ecompile_2eemitc_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etraverseC_clo;
V g_heff_2ecompile_2eemitc_2eupdateText(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2eupdateText_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eupdateText_clo;
V g_heff_2ecompile_2eemitc_2evalDef(V, V, V);
V g_heff_2ecompile_2eemitc_2evalDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2evalDef_clo;
V g_heff_2ecompile_2eemitc_2ewrapped(V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapped_clo;
V g_heff_2ecompile_2eemitc_2ewrapperCode(V, V, V);
V g_heff_2ecompile_2eemitc_2ewrapperCode_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ewrapperCode_clo;
V g_heff_2ecompile_2elower_2ecDef(V, V, V);
V g_heff_2ecompile_2elower_2ecDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecDef_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter_24s1967523567x64647275(V);
V g_list_2efilter_24s1967523567x64647275_entry(V self, V *a);
extern Clo g_list_2efilter_24s1967523567x64647275_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1414103338x1084960320(V, V, V, V);
V g_list_2efoldl_24s1414103338x1084960320_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1414103338x1084960320_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1814128165x1680687847(V, V, V, V, V);
V g_list_2ezipWith_24s1814128165x1680687847_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1814128165x1680687847_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s1907923014x815971565(V, V, V, V, V);
V g_list_2ezipWith_24s1907923014x815971565_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1907923014x815971565_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1280198663x1762821176(V, V, V);
V g_prelude_2e_2b_2b_24f1280198663x1762821176_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1280198663x1762821176_clo;
V g_prelude_2e_2b_2b_24f1882260109x1043267855(V, V, V, V, V, V, V, V, V);
V g_prelude_2e_2b_2b_24f1882260109x1043267855_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1882260109x1043267855_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_heff_2ecompile_2eemitc_2enumbered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2enumbered_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2enumbered(V v_n_240, V v_x2_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return v_m_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_243), v_m_242));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_243), heff_dup(v_n_240), v_m_242));
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_t_246;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_m_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      V t_0 = v_n_240;
      V t_1 = v_xs_244;
      V t_2 = v_m_242;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_m_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2enumbered_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eemitc_2enumbered(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eemitc_2etraverseC_lam0(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2etraverseC_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etraverseC_lam0, 1, 0};
V g_heff_2ecompile_2eemitc_2etraverseC_lam1(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2etraverseC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2etraverseC_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2etraverseC(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eemitc_2etraverseC_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2etraverseC_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2etraverseC_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2etraverseC(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2etraverseC_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_heff_2ecompile_2eemitc_2etraverseC_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2eemitc_2etraverseC(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str1, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str2, 11, " (uint64_t)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str3, 2, "))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str4, 1, " ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str5, 12, ")((uint64_t)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2ewrapped_str6, 2, "((");
Clo g_heff_2ecompile_2eemitc_2ewrapped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2ewrapped_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2ewrapped(V v_w_240, V v_op_241, V v_vs_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eemitc_2efixedType(v_w_240));
  V v_x2_246;
  switch (heff_tag_of(v_vs_242)) {
  case TAG_Nil: {
    v_x2_246 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_dup(heff_field(v_vs_242, 0));
    v_x2_246 = heff_tag_n(TAG_Just, 1, (V[]){v_x_244});
    break;
  }
  default: heff_nomatch(v_vs_242);
  }
  V v_t_248;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nothing: {
    v_t_248 = ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str0);
    break;
  }
  case TAG_Just: {
    V v_x_247 = heff_field(v_x2_246, 0);
    heff_take_n(v_x2_246, 1ULL, 1);
    v_t_248 = v_x_247;
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_x1_249 = (g_list_2edrop(MK_INT(1LL), v_vs_242));
  V v_x2_2412;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Nil: {
    v_x2_2412 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 2);
    v_x2_2412 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2410});
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  V v_t_2414;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nothing: {
    v_t_2414 = ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    heff_take_n(v_x2_2412, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapped_str2), heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eemitc_2ewrapped_str3)));
  V v_t_2416 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapped_str4), heff_strAppend(v_op_241, v_t_2415));
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapped_str5), heff_strAppend(v_t_248, v_t_2416));
  return heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2ewrapped_str6), heff_strAppend(v_t_243, v_t_2417));
}
V g_heff_2ecompile_2eemitc_2ewrapped_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eemitc_2ewrapped(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str1, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str3, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str5, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str7, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str8, 5, "_clo)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str9, 5, "((V)&");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str11, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str12, 7, "_get())");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str13, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str15, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str16, 6, "_get()");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str17, 3, "LL)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str18, 7, "MK_INT(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str19, 2, "\")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str20, 10, "HEFF_BIG(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str21, 2, "\")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str22, 10, "HEFF_BIG(\"");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str23, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str24, 13, "heff_flt(NAN)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str25, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str26, 18, "heff_flt(INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str27, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str28, 19, "heff_flt(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str29, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str30, 9, "heff_flt(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str31, 8, "HEFF_LIT");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str32, 10, "HEFF_BYTES");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str33, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str34, 16, "heff_f32((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str35, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str36, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str37, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str38, 5, "NTAG(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str39, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str40, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str41, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str42, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str43, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str44, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str45, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str46, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str47, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str48, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str49, 11, "heff_tag_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str50, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str51, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str52, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str53, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str54, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str55, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str56, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str57, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str58, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str59, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str60, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str61, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str62, 14, "heff_tag_at_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str63, 11, "heff_rec_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str64, 12, "heff_rec_nf(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str65, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str66, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str67, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str68, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str69, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str70, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str71, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str72, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str73, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str74, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str75, 1, "u");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str76, 3, "u, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str77, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str78, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str79, 12, "heff_rfield(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str80, 9, "heff_dup(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str81, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str82, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str83, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str84, 12, "heff_rget_v(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str85, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str86, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str87, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str88, 11, "heff_get_n(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str89, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str90, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str91, 10, "heff_rget_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str92, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str93, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str94, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str95, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str96, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str97, 11, "heff_get_n_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str98, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str99, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str100, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str101, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str102, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str103, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str104, 10, "heff_word_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str105, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str106, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str107, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str108, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str109, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str110, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str111, 16, "heff_take_field(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str112, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str113, 4, "LBL_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str114, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str115, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str116, 9, "heff_get(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str117, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str118, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str119, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str120, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str121, 5, "heff_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str122, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str123, 4, "NULL");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str124, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str125, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str126, 6, "(V[]){");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str127, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str128, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str129, 2, "))");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str130, 2, ", ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str131, 18, "heff_tr(heff_call(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str132, 10, "heff_bool(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str133, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str134, 14, "heff_abandon()");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str135, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str136, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str137, 9, "heff_box_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str138, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str139, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str140, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str141, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str142, 11, "heff_unbox_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str143, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str144, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str145, 1, "v");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str146, 3, "f64");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str147, 10, "heff_peek_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str148, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str149, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str150, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str151, 3, "NAN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str152, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str153, 8, "INFINITY");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str154, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str155, 11, "(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str156, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str157, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str158, 8, "((float)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str159, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str160, 3, "NaN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str161, 3, "NAN");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str162, 8, "Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str163, 8, "INFINITY");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str164, 9, "-Infinity");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str165, 11, "(-INFINITY)");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str166, 1, ")");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eexpF_str167, 1, "(");
V g_heff_2ecompile_2eemitc_2eexpF_lam0(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam1(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam2(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam3(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam4(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam5(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam6(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam7(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam8(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam9(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam10(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam11(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam12(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam13(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam14(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam15(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam16(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam17(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam18(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam19(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam20(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam21(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam22(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam23(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam24(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam25(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam26(V self, V *args); static Clo g_heff_2ecompile_2eemitc_2eexpF_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eexpF_lam26, 1, 0};
V g_heff_2ecompile_2eemitc_2eexpF_lam27(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam28(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam29(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam30(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam31(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam32(V self, V *args);
V g_heff_2ecompile_2eemitc_2eexpF_lam33(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2eexpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eexpF_entry, 2, 0};

V g_heff_2ecompile_2eemitc_2eexpF(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_RLocal: {
    V v_x_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_242, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str0)));
    V v_x_244 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str1), v_t_243);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam0, 1, 1, (V[]){v_x_244});
  }
  case TAG_RDup: {
    V v_x_246 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    V v_t_247 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_246, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str2)));
    V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str3), v_t_247), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str4));
    V v_x_249 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str5), v_t_248);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam1, 1, 1, (V[]){v_x_249});
  }
  case TAG_RClo: {
    V v_g_2411 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    V v_t_2412 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_2411, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str6)));
    V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str7), v_t_2412), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str8));
    V v_x_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str9), v_t_2413);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam2, 1, 1, (V[]){v_x_2414});
  }
  case TAG_RGet: {
    V v_g_2416 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    V v_t_2417 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_2416, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str10)));
    V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str11), v_t_2417), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str12));
    V v_x_2419 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str13), v_t_2418);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam3, 1, 1, (V[]){v_x_2419});
  }
  case TAG_RGetRaw: {
    V v_g_2421 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    V v_t_2422 = (g_heff_2ecompile_2eemitc_2emangleW(v_g_2421, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str14)));
    V v_x_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str15), v_t_2422), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str16));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam4, 1, 1, (V[]){v_x_2423});
  }
  case TAG_RInt: {
    V v_n_2425 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    V v_x_2431;
    if (heff_intLt_c(heff_dup(v_n_2425), HEFF_BIG("4611686018427387904"))) {
      if (heff_intLe_c(MK_INT(-4611686018427387904LL), heff_dup(v_n_2425))) {
        V v_t_2428 = heff_strAppend(heff_intShow(v_n_2425), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str17));
        v_x_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str18), v_t_2428);
      } else {
        V v_t_2429 = heff_strAppend(heff_intShow(v_n_2425), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str19));
        v_x_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str20), v_t_2429);
      }
    } else {
      V v_t_2430 = heff_strAppend(heff_intShow(v_n_2425), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str21));
      v_x_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str22), v_t_2430);
    }
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam5, 1, 1, (V[]){v_x_2431});
  }
  case TAG_RFloat: {
    V v_x_2433 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    V v_x_2438;
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2433)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str23))) {
      heff_drop(v_x_2433);
      v_x_2438 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str24);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2433)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str25))) {
        heff_drop(v_x_2433);
        v_x_2438 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str26);
      } else {
        if (heff_strEq_c(heff_floatShow(heff_dup(v_x_2433)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str27))) {
          heff_drop(v_x_2433);
          v_x_2438 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str28);
        } else {
          V v_t_2437 = heff_strAppend(heff_floatShow(v_x_2433), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str29));
          v_x_2438 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str30), v_t_2437);
        }
      }
    }
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam6, 1, 1, (V[]){v_x_2438});
  }
  case TAG_RStr: {
    V v_s_2440 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2estrLit_clo), 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eexpF_str31), v_s_2440});
  }
  case TAG_RBytes: {
    V v_s_2441 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2estrLit_clo), 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eexpF_str32), v_s_2441});
  }
  case TAG_RFixed: {
    V v_w_2442 = heff_field(v_x2_241, 0);
    V v_n_2443 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_k_240, 3);
    V v_x_2444 = ({ V a_0 = v_w_2442; V a_1 = v_n_2443; V r_ = (g_heff_2ecompile_2eemitc_2efixedLit(a_0, a_1)); heff_drop(v_w_2442); r_; });
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam7, 1, 1, (V[]){v_x_2444});
  }
  case TAG_RF32: {
    V v_x_2446 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam8, 1, 1, (V[]){v_x_2446});
  }
  case TAG_RNTag: {
    V v_t_2449 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    V v_t_2450 = (g_heff_2ecompile_2eemitc_2emangleW(v_t_2449, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str35)));
    V v_t_2451 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str36), v_t_2450), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str37));
    V v_x_2452 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str38), v_t_2451);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam9, 1, 1, (V[]){v_x_2452});
  }
  case TAG_RTag: {
    V v_t_2454 = heff_field(v_x2_241, 0);
    V v_es_2455 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2456 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), heff_dup(v_es_2455)));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam10, 1, 3, (V[]){v_m_2456, v_t_2454, v_es_2455});
  }
  case TAG_RTagIn: {
    V v_ru_2473 = heff_field(v_x2_241, 0);
    V v_t_2474 = heff_field(v_x2_241, 1);
    V v_es_2475 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2476 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), heff_tag_n(TAG_Cons, 2, (V[]){v_ru_2473, heff_dup(v_es_2475)})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam11, 1, 3, (V[]){v_m_2476, v_t_2474, v_es_2475});
  }
  case TAG_RRec: {
    V v_ls_24100 = heff_field(v_x2_241, 0);
    V v_flat_24101 = heff_field(v_x2_241, 1);
    V v_es_24102 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24103 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_es_24102));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam12, 1, 3, (V[]){v_m_24103, v_ls_24100, v_flat_24101});
  }
  case TAG_RRecIn: {
    V v_x_24127 = heff_field(v_x2_241, 0);
    V v_keep_24128 = heff_field(v_x2_241, 1);
    V v_kept_24129 = heff_field(v_x2_241, 2);
    V v_flat_24130 = heff_field(v_x2_241, 3);
    V v_n_24131 = heff_field(v_x2_241, 4);
    V v_ls_24132 = heff_field(v_x2_241, 5);
    V v_changed_24133 = heff_field(v_x2_241, 6);
    heff_take_n(v_x2_241, 127ULL, 7);
    V v_t_24134 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_changed_24133)));
    V v_m_24135 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_t_24134));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam13, 1, 8, (V[]){v_m_24135, v_ls_24132, v_flat_24130, v_kept_24129, v_changed_24133, v_x_24127, v_keep_24128, v_n_24131});
  }
  case TAG_RField: {
    V v_e_24147 = heff_field(v_x2_241, 0);
    V v_i_24148 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24149 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_24147}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam14, 1, 2, (V[]){v_m_24149, v_i_24148});
  }
  case TAG_RDupE: {
    V v_e_24156 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_24157 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_24156}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam15, 1, 1, (V[]){v_m_24157});
  }
  case TAG_RFieldV: {
    V v_e_24163 = heff_field(v_x2_241, 0);
    V v_i_24164 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24165 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_24163}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam16, 1, 2, (V[]){v_m_24165, v_i_24164});
  }
  case TAG_RGetN: {
    V v_e_24172 = heff_field(v_x2_241, 0);
    V v_i_24173 = heff_field(v_x2_241, 1);
    V v_n_24174 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24175 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_24172}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam17, 1, 3, (V[]){v_m_24175, v_n_24174, v_i_24173});
  }
  case TAG_RFieldU: {
    V v_r_24183 = heff_field(v_x2_241, 0);
    V v_e_24184 = heff_field(v_x2_241, 1);
    V v_i_24185 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_24187;
    switch (heff_tag_of(v_r_24183)) {
    case TAG_RepV: {
      v_t_24187 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str89);
      break;
    }
    case TAG_RepFix: {
      V v_w_24186 = heff_field(v_r_24183, 0);
      heff_take_n(v_r_24183, 1ULL, 1);
      v_t_24187 = ({ V a_0 = v_w_24186; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24186); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24187 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str90);
      break;
    }
    default: heff_nomatch(v_r_24183);
    }
    V v_pre_24188 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str91), heff_strAppend(v_t_24187, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str92)));
    V v_m_24189 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_24184}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam18, 1, 3, (V[]){v_m_24189, v_i_24185, v_pre_24188});
  }
  case TAG_RGetNU: {
    V v_r_24196 = heff_field(v_x2_241, 0);
    V v_e_24197 = heff_field(v_x2_241, 1);
    V v_i_24198 = heff_field(v_x2_241, 2);
    V v_n_24199 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_24201;
    switch (heff_tag_of(v_r_24196)) {
    case TAG_RepV: {
      v_t_24201 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str95);
      break;
    }
    case TAG_RepFix: {
      V v_w_24200 = heff_field(v_r_24196, 0);
      heff_take_n(v_r_24196, 1ULL, 1);
      v_t_24201 = ({ V a_0 = v_w_24200; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24200); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24201 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str96);
      break;
    }
    default: heff_nomatch(v_r_24196);
    }
    V v_pre_24202 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str97), heff_strAppend(v_t_24201, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str98)));
    V v_m_24203 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_24197}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam19, 1, 4, (V[]){v_m_24203, v_n_24199, v_i_24198, v_pre_24202});
  }
  case TAG_RWord: {
    V v_r_24211 = heff_field(v_x2_241, 0);
    V v_e_24212 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24214;
    switch (heff_tag_of(v_r_24211)) {
    case TAG_RepV: {
      v_t_24214 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str102);
      break;
    }
    case TAG_RepFix: {
      V v_w_24213 = heff_field(v_r_24211, 0);
      heff_take_n(v_r_24211, 1ULL, 1);
      v_t_24214 = ({ V a_0 = v_w_24213; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24213); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24214 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str103);
      break;
    }
    default: heff_nomatch(v_r_24211);
    }
    V v_pre_24215 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str104), heff_strAppend(v_t_24214, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str105)));
    V v_m_24216 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_24212}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam20, 1, 2, (V[]){v_m_24216, v_pre_24215});
  }
  case TAG_RTakeField: {
    V v_x_24222 = heff_field(v_x2_241, 0);
    V v_i_24223 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_k_240, 3);
    V v_t_24224 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_24222, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str107)));
    V v_t_24225 = heff_strAppend(heff_intShow(v_i_24223), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str108));
    V v_t_24226 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str109), v_t_24224), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str110), v_t_24225));
    V v_x_24227 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str111), v_t_24226);
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam21, 1, 1, (V[]){v_x_24227});
  }
  case TAG_RGetLabel: {
    V v_e_24229 = heff_field(v_x2_241, 0);
    V v_l_24230 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24231 = (g_heff_2ecompile_2eemitc_2emangleW(v_l_24230, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str112)));
    V v_t_24232 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str113), v_t_24231), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str114));
    V v_post_24233 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str115), v_t_24232);
    V v_m_24234 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_24229}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam22, 1, 2, (V[]){v_m_24234, v_post_24233});
  }
  case TAG_RPrimFn: {
    V v_p_24240 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    return heff_tail(((V)&g_heff_2ecompile_2eemitc_2eprimLit_clo), 1, (V[]){v_p_24240});
  }
  case TAG_RPrim: {
    V v_p_24241 = heff_field(v_x2_241, 0);
    V v_es_24242 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24243 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_es_24242));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam23, 1, 2, (V[]){v_m_24243, v_p_24241});
  }
  case TAG_RLam: {
    V v_xs_24253 = heff_field(v_x2_241, 0);
    V v_fv_24254 = heff_field(v_x2_241, 1);
    V v_held_24255 = heff_field(v_x2_241, 2);
    V v_x24_24256 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    switch (heff_tag_of(v_x24_24256)) {
    case TAG_MkCode: {
      V v_body_24257 = heff_field(v_x24_24256, 0);
      heff_take_n(v_x24_24256, 1ULL, 1);
      return heff_tail(((V)&g_heff_2ecompile_2eemitc_2elamC_clo), 5, (V[]){v_k_240, v_xs_24253, v_fv_24254, v_held_24255, v_body_24257});
    }
    default: return heff_nomatch(v_x24_24256);
    }
  }
  case TAG_RCall: {
    V v_g_24258 = heff_field(v_x2_241, 0);
    V v_tr_24259 = heff_field(v_x2_241, 1);
    V v_w_24260 = heff_field(v_x2_241, 2);
    V v_args_24261 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    return ({ V a_0 = v_k_240; V a_1 = v_g_24258; V a_2 = v_tr_24259; V a_3 = v_w_24260; V a_4 = v_args_24261; V r_ = (g_heff_2ecompile_2eemitc_2ecallC(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_tr_24259); heff_drop(v_w_24260); r_; });
  }
  case TAG_RApply: {
    V v_f_24262 = heff_field(v_x2_241, 0);
    V v_es_24263 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24RApply = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_24264 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), heff_tag_at_n(v_ru_24x2_241_24RApply, TAG_Cons, 2, (V[]){v_f_24262, heff_dup(v_es_24263)})));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam24, 1, 2, (V[]){v_m_24264, v_es_24263});
  }
  case TAG_RBool: {
    V v_c_24286 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_m_24287 = (g_heff_2ecompile_2eemitc_2etestC(v_k_240, v_c_24286));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam25, 1, 1, (V[]){v_m_24287});
  }
  case TAG_RAbandon: {
    heff_drop_rec(v_k_240, 3);
    return ((V)&g_heff_2ecompile_2eemitc_2eexpF_lam26_clo);
  }
  case TAG_RBox: {
    V v_r_24294 = heff_field(v_x2_241, 0);
    V v_e_24295 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24297;
    switch (heff_tag_of(v_r_24294)) {
    case TAG_RepV: {
      v_t_24297 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str135);
      break;
    }
    case TAG_RepFix: {
      V v_w_24296 = heff_field(v_r_24294, 0);
      heff_take_n(v_r_24294, 1ULL, 1);
      v_t_24297 = ({ V a_0 = v_w_24296; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24296); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24297 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str136);
      break;
    }
    default: heff_nomatch(v_r_24294);
    }
    V v_pre_24298 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str137), heff_strAppend(v_t_24297, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str138)));
    V v_m_24299 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_24295}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam27, 1, 2, (V[]){v_m_24299, v_pre_24298});
  }
  case TAG_RUnbox: {
    V v_r_24305 = heff_field(v_x2_241, 0);
    V v_e_24306 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24308;
    switch (heff_tag_of(v_r_24305)) {
    case TAG_RepV: {
      v_t_24308 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str140);
      break;
    }
    case TAG_RepFix: {
      V v_w_24307 = heff_field(v_r_24305, 0);
      heff_take_n(v_r_24305, 1ULL, 1);
      v_t_24308 = ({ V a_0 = v_w_24307; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24307); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24308 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str141);
      break;
    }
    default: heff_nomatch(v_r_24305);
    }
    V v_pre_24309 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str142), heff_strAppend(v_t_24308, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str143)));
    V v_m_24310 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_24306}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam28, 1, 2, (V[]){v_m_24310, v_pre_24309});
  }
  case TAG_RPeek: {
    V v_r_24316 = heff_field(v_x2_241, 0);
    V v_e_24317 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24319;
    switch (heff_tag_of(v_r_24316)) {
    case TAG_RepV: {
      v_t_24319 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str145);
      break;
    }
    case TAG_RepFix: {
      V v_w_24318 = heff_field(v_r_24316, 0);
      heff_take_n(v_r_24316, 1ULL, 1);
      v_t_24319 = ({ V a_0 = v_w_24318; V r_ = (g_heff_2ecompile_2eemitc_2efixedSuffix(a_0)); heff_drop(v_w_24318); r_; });
      break;
    }
    case TAG_RepF64: {
      v_t_24319 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str146);
      break;
    }
    default: heff_nomatch(v_r_24316);
    }
    V v_pre_24320 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str147), heff_strAppend(v_t_24319, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str148)));
    V v_m_24321 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 3), 1, (V[]){v_e_24317}));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam29, 1, 2, (V[]){v_m_24321, v_pre_24320});
  }
  case TAG_RPrimU: {
    V v_p_24327 = heff_field(v_x2_241, 0);
    V v_es_24328 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_24329 = (g_heff_2ecompile_2eemitc_2etraverseC(heff_get_n(v_k_240, 0, 3), v_es_24328));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam30, 1, 2, (V[]){v_m_24329, v_p_24327});
  }
  case TAG_RFixU: {
    V v_w_24337 = heff_field(v_x2_241, 0);
    V v_n_24338 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    heff_drop_rec(v_k_240, 3);
    V v_x_24339 = ({ V a_0 = v_w_24337; V a_1 = v_n_24338; V r_ = (g_heff_2ecompile_2eemitc_2efixedConst(a_0, a_1)); heff_drop(v_w_24337); r_; });
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam31, 1, 1, (V[]){v_x_24339});
  }
  case TAG_RF32U: {
    V v_x_24341 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    V v_t_24346;
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24341)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str150))) {
      heff_drop(v_x_24341);
      v_t_24346 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str151);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24341)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str152))) {
        heff_drop(v_x_24341);
        v_t_24346 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str153);
      } else {
        if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24341)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str154))) {
          heff_drop(v_x_24341);
          v_t_24346 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str155);
        } else {
          V v_t_24345 = heff_strAppend(heff_floatShow(v_x_24341), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str156));
          v_t_24346 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str157), v_t_24345);
        }
      }
    }
    V v_x_24347 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str158), heff_strAppend(v_t_24346, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str159)));
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam32, 1, 1, (V[]){v_x_24347});
  }
  case TAG_RF64U: {
    V v_x_24349 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_k_240, 3);
    V v_x_24354;
    if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24349)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str160))) {
      heff_drop(v_x_24349);
      v_x_24354 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str161);
    } else {
      if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24349)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str162))) {
        heff_drop(v_x_24349);
        v_x_24354 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str163);
      } else {
        if (heff_strEq_c(heff_floatShow(heff_dup(v_x_24349)), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str164))) {
          heff_drop(v_x_24349);
          v_x_24354 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str165);
        } else {
          V v_t_24353 = heff_strAppend(heff_floatShow(v_x_24349), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str166));
          v_x_24354 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str167), v_t_24353);
        }
      }
    }
    return heff_clo_n(g_heff_2ecompile_2eemitc_2eexpF_lam33, 1, 1, (V[]){v_x_24354});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eexpF(a[0], a[1]);
}
V g_heff_2ecompile_2eemitc_2eexpF_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_244, v_s_245});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_2410});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam2(V self, V *args) {
  V v_s_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2414, v_s_2415});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam3(V self, V *args) {
  V v_s_2420 = args[0];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_s_2420});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2423, v_s_2424});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam5(V self, V *args) {
  V v_s_2432 = args[0];
  V v_x_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2431, v_s_2432});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam6(V self, V *args) {
  V v_s_2439 = args[0];
  V v_x_2438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2438, v_s_2439});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam7(V self, V *args) {
  V v_s_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2444, v_s_2445});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam8(V self, V *args) {
  V v_s_2447 = args[0];
  V v_x_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_strAppend(heff_floatShow(v_x_2446), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str33));
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str34), v_t_2448), v_s_2447});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam9(V self, V *args) {
  V v_s_2453 = args[0];
  V v_x_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2452, v_s_2453});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam10(V self, V *args) {
  V v_s_2457 = args[0];
  V v_m_2456 = heff_env(self)[0];
  V v_t_2454 = heff_env(self)[1];
  V v_es_2455 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2458 = heff_tr(heff_call(v_m_2456, 1, (V[]){v_s_2457}));
  switch (heff_tag_of(v_x2_2458)) {
  case TAG_MkPair: {
    V v_x_2459 = heff_field(v_x2_2458, 0);
    V v_s_2460 = heff_field(v_x2_2458, 1);
    V v_ru_24x2_2458_24MkPair = heff_take_reuse_n(v_x2_2458, 3ULL, 2);
    V v_t_2461 = (g_heff_2ecompile_2eemitc_2emangleW(v_t_2454, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str39)));
    V v_t_2462 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2455; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_es_2455); r_; });
    V v_t_2468;
    switch (heff_tag_of(v_x_2459)) {
    case TAG_Nil: {
      v_t_2468 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str40);
      break;
    }
    case TAG_Cons: {
      V v_t_2467;
      switch (heff_tag_of(v_x_2459)) {
      case TAG_Nil: {
        v_t_2467 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str41);
        break;
      }
      case TAG_Cons: {
        V v_x_2465 = heff_field(v_x_2459, 0);
        V v_xs_2466 = heff_field(v_x_2459, 1);
        heff_take_n(v_x_2459, 3ULL, 2);
        v_t_2467 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str42); V a_1 = v_x_2465; V a_2 = v_xs_2466; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2466); r_; });
        break;
      }
      default: heff_nomatch(v_x_2459);
      }
      v_t_2468 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str43), heff_strAppend(v_t_2467, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str44)));
      break;
    }
    default: heff_nomatch(v_x_2459);
    }
    V v_t_2469 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str45), heff_strAppend(v_t_2468, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str46)));
    V v_t_2470 = heff_strAppend(heff_intShow(v_t_2462), v_t_2469);
    V v_t_2471 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str47), v_t_2461), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str48), v_t_2470));
    V v_x_2472 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str49), v_t_2471);
    return heff_tag_at_n(v_ru_24x2_2458_24MkPair, TAG_MkPair, 2, (V[]){v_x_2472, v_s_2460});
  }
  default: return heff_nomatch(v_x2_2458);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam11(V self, V *args) {
  V v_s_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  V v_t_2474 = heff_env(self)[1];
  V v_es_2475 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2478 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_s_2477}));
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_MkPair: {
    V v_x_2479 = heff_field(v_x2_2478, 0);
    V v_s_2480 = heff_field(v_x2_2478, 1);
    V v_ru_24x2_2478_24MkPair = heff_take_reuse_n(v_x2_2478, 3ULL, 2);
    V v_x2_2483;
    switch (heff_tag_of(v_x_2479)) {
    case TAG_Nil: {
      v_x2_2483 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2481 = heff_dup(heff_field(v_x_2479, 0));
      v_x2_2483 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2481});
      break;
    }
    default: heff_nomatch(v_x_2479);
    }
    V v_t_2485;
    switch (heff_tag_of(v_x2_2483)) {
    case TAG_Nothing: {
      v_t_2485 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str50);
      break;
    }
    case TAG_Just: {
      V v_x_2484 = heff_field(v_x2_2483, 0);
      heff_take_n(v_x2_2483, 1ULL, 1);
      v_t_2485 = v_x_2484;
      break;
    }
    default: heff_nomatch(v_x2_2483);
    }
    V v_t_2486 = (g_heff_2ecompile_2eemitc_2emangleW(v_t_2474, MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str51)));
    V v_t_2487 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_2475; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_es_2475); r_; });
    V v_vs_2488 = (g_list_2edrop(MK_INT(1LL), v_x_2479));
    V v_t_2494;
    switch (heff_tag_of(v_vs_2488)) {
    case TAG_Nil: {
      v_t_2494 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str52);
      break;
    }
    case TAG_Cons: {
      V v_t_2493;
      switch (heff_tag_of(v_vs_2488)) {
      case TAG_Nil: {
        v_t_2493 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str53);
        break;
      }
      case TAG_Cons: {
        V v_x_2491 = heff_field(v_vs_2488, 0);
        V v_xs_2492 = heff_field(v_vs_2488, 1);
        heff_take_n(v_vs_2488, 3ULL, 2);
        v_t_2493 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str54); V a_1 = v_x_2491; V a_2 = v_xs_2492; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2492); r_; });
        break;
      }
      default: heff_nomatch(v_vs_2488);
      }
      v_t_2494 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str55), heff_strAppend(v_t_2493, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str56)));
      break;
    }
    default: heff_nomatch(v_vs_2488);
    }
    V v_t_2495 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str57), heff_strAppend(v_t_2494, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str58)));
    V v_t_2496 = heff_strAppend(heff_intShow(v_t_2487), v_t_2495);
    V v_t_2497 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str59), v_t_2486), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str60), v_t_2496));
    V v_t_2498 = heff_strAppend(v_t_2485, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str61), v_t_2497));
    V v_x_2499 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str62), v_t_2498);
    return heff_tag_at_n(v_ru_24x2_2478_24MkPair, TAG_MkPair, 2, (V[]){v_x_2499, v_s_2480});
  }
  default: return heff_nomatch(v_x2_2478);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam12(V self, V *args) {
  V v_s_24104 = args[0];
  V v_m_24103 = heff_env(self)[0];
  V v_ls_24100 = heff_env(self)[1];
  V v_flat_24101 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24105 = heff_tr(heff_call(v_m_24103, 1, (V[]){v_s_24104}));
  switch (heff_tag_of(v_x2_24105)) {
  case TAG_MkPair: {
    V v_x_24106 = heff_field(v_x2_24105, 0);
    V v_s_24107 = heff_field(v_x2_24105, 1);
    V v_ru_24x2_24105_24MkPair = heff_take_reuse_n(v_x2_24105, 3ULL, 2);
    V v_x2_24108 = (g_heff_2ecompile_2eemitc_2eshapeLit(heff_dup(v_ls_24100), v_s_24107));
    switch (heff_tag_of(v_x2_24108)) {
    case TAG_MkPair: {
      V v_x_24109 = heff_field(v_x2_24108, 0);
      V v_s_24110 = heff_field(v_x2_24108, 1);
      heff_take_n(v_x2_24108, 3ULL, 2);
      V v_t_24112;
      if (heff_intEq_c(heff_dup(v_flat_24101), MK_INT(0LL))) {
        v_t_24112 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str63);
      } else {
        v_t_24112 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str64);
      }
      V v_t_24113 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_ls_24100; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_ls_24100); r_; });
      V v_t_24116;
      if (heff_intEq_c(heff_dup(v_flat_24101), MK_INT(0LL))) {
        heff_drop(v_flat_24101);
        v_t_24116 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str65);
      } else {
        V v_t_24115 = heff_strAppend(heff_intShow(v_flat_24101), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str66));
        v_t_24116 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str67), v_t_24115);
      }
      V v_t_24122;
      switch (heff_tag_of(v_x_24106)) {
      case TAG_Nil: {
        v_t_24122 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str68);
        break;
      }
      case TAG_Cons: {
        V v_t_24121;
        switch (heff_tag_of(v_x_24106)) {
        case TAG_Nil: {
          v_t_24121 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str69);
          break;
        }
        case TAG_Cons: {
          V v_x_24119 = heff_field(v_x_24106, 0);
          V v_xs_24120 = heff_field(v_x_24106, 1);
          heff_take_n(v_x_24106, 3ULL, 2);
          v_t_24121 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str70); V a_1 = v_x_24119; V a_2 = v_xs_24120; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24120); r_; });
          break;
        }
        default: heff_nomatch(v_x_24106);
        }
        v_t_24122 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str71), heff_strAppend(v_t_24121, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str72)));
        break;
      }
      default: heff_nomatch(v_x_24106);
      }
      V v_t_24123 = heff_strAppend(v_t_24116, heff_strAppend(v_t_24122, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str73)));
      V v_t_24124 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str74), heff_strAppend(v_x_24109, v_t_24123));
      V v_t_24125 = heff_strAppend(heff_intShow(v_t_24113), v_t_24124);
      V v_x_24126 = heff_strAppend(v_t_24112, v_t_24125);
      return heff_tag_at_n(v_ru_24x2_24105_24MkPair, TAG_MkPair, 2, (V[]){v_x_24126, v_s_24110});
    }
    default: return heff_nomatch(v_x2_24108);
    }
  }
  default: return heff_nomatch(v_x2_24105);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam13(V self, V *args) {
  V v_s_24136 = args[0];
  V v_m_24135 = heff_env(self)[0];
  V v_ls_24132 = heff_env(self)[1];
  V v_flat_24130 = heff_env(self)[2];
  V v_kept_24129 = heff_env(self)[3];
  V v_changed_24133 = heff_env(self)[4];
  V v_x_24127 = heff_env(self)[5];
  V v_keep_24128 = heff_env(self)[6];
  V v_n_24131 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x2_24137 = heff_tr(heff_call(v_m_24135, 1, (V[]){v_s_24136}));
  switch (heff_tag_of(v_x2_24137)) {
  case TAG_MkPair: {
    V v_x_24138 = heff_field(v_x2_24137, 0);
    V v_s_24139 = heff_field(v_x2_24137, 1);
    V v_ru_24x2_24137_24MkPair = heff_take_reuse_n(v_x2_24137, 3ULL, 2);
    V v_x2_24140 = (g_heff_2ecompile_2eemitc_2eshapeLit(v_ls_24132, v_s_24139));
    switch (heff_tag_of(v_x2_24140)) {
    case TAG_MkPair: {
      V v_x_24141 = heff_field(v_x2_24140, 0);
      V v_s_24142 = heff_field(v_x2_24140, 1);
      heff_take_n(v_x2_24140, 3ULL, 2);
      V v_t_24143 = heff_strAppend(heff_intShow(v_flat_24130), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str75));
      V v_t_24144 = heff_strAppend(heff_intShow(v_kept_24129), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str76), v_t_24143));
      V v_t_24145 = (g_list_2emap_24s1937570095x2110149801(v_changed_24133));
      V v_x_24146 = (g_heff_2ecompile_2eemitc_2eupdateText(v_x_24127, v_x_24141, v_keep_24128, v_t_24144, v_n_24131, v_x_24138, v_t_24145));
      return heff_tag_at_n(v_ru_24x2_24137_24MkPair, TAG_MkPair, 2, (V[]){v_x_24146, v_s_24142});
    }
    default: return heff_nomatch(v_x2_24140);
    }
  }
  default: return heff_nomatch(v_x2_24137);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam14(V self, V *args) {
  V v_s_24150 = args[0];
  V v_m_24149 = heff_env(self)[0];
  V v_i_24148 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24151 = heff_tr(heff_call(v_m_24149, 1, (V[]){v_s_24150}));
  switch (heff_tag_of(v_x2_24151)) {
  case TAG_MkPair: {
    V v_x_24152 = heff_field(v_x2_24151, 0);
    V v_s_24153 = heff_field(v_x2_24151, 1);
    V v_ru_24x2_24151_24MkPair = heff_take_reuse_n(v_x2_24151, 3ULL, 2);
    V v_t_24154 = heff_strAppend(heff_intShow(v_i_24148), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str77));
    V v_t_24155 = heff_strAppend(v_x_24152, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str78), v_t_24154));
    return heff_tag_at_n(v_ru_24x2_24151_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str79), v_t_24155), v_s_24153});
  }
  default: return heff_nomatch(v_x2_24151);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam15(V self, V *args) {
  V v_s_24158 = args[0];
  V v_m_24157 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24159 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_s_24158}));
  switch (heff_tag_of(v_x2_24159)) {
  case TAG_MkPair: {
    V v_x_24160 = heff_field(v_x2_24159, 0);
    V v_s_24161 = heff_field(v_x2_24159, 1);
    V v_ru_24x2_24159_24MkPair = heff_take_reuse_n(v_x2_24159, 3ULL, 2);
    V v_t_24162 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str80), heff_strAppend(v_x_24160, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str81)));
    return heff_tag_at_n(v_ru_24x2_24159_24MkPair, TAG_MkPair, 2, (V[]){v_t_24162, v_s_24161});
  }
  default: return heff_nomatch(v_x2_24159);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam16(V self, V *args) {
  V v_s_24166 = args[0];
  V v_m_24165 = heff_env(self)[0];
  V v_i_24164 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24167 = heff_tr(heff_call(v_m_24165, 1, (V[]){v_s_24166}));
  switch (heff_tag_of(v_x2_24167)) {
  case TAG_MkPair: {
    V v_x_24168 = heff_field(v_x2_24167, 0);
    V v_s_24169 = heff_field(v_x2_24167, 1);
    V v_ru_24x2_24167_24MkPair = heff_take_reuse_n(v_x2_24167, 3ULL, 2);
    V v_t_24170 = heff_strAppend(heff_intShow(v_i_24164), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str82));
    V v_t_24171 = heff_strAppend(v_x_24168, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str83), v_t_24170));
    return heff_tag_at_n(v_ru_24x2_24167_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str84), v_t_24171), v_s_24169});
  }
  default: return heff_nomatch(v_x2_24167);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam17(V self, V *args) {
  V v_s_24176 = args[0];
  V v_m_24175 = heff_env(self)[0];
  V v_n_24174 = heff_env(self)[1];
  V v_i_24173 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24177 = heff_tr(heff_call(v_m_24175, 1, (V[]){v_s_24176}));
  switch (heff_tag_of(v_x2_24177)) {
  case TAG_MkPair: {
    V v_x_24178 = heff_field(v_x2_24177, 0);
    V v_s_24179 = heff_field(v_x2_24177, 1);
    V v_ru_24x2_24177_24MkPair = heff_take_reuse_n(v_x2_24177, 3ULL, 2);
    V v_t_24180 = heff_strAppend(heff_intShow(v_n_24174), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str85));
    V v_t_24181 = heff_strAppend(heff_intShow(v_i_24173), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str86), v_t_24180));
    V v_t_24182 = heff_strAppend(v_x_24178, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str87), v_t_24181));
    return heff_tag_at_n(v_ru_24x2_24177_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str88), v_t_24182), v_s_24179});
  }
  default: return heff_nomatch(v_x2_24177);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam18(V self, V *args) {
  V v_s_24190 = args[0];
  V v_m_24189 = heff_env(self)[0];
  V v_i_24185 = heff_env(self)[1];
  V v_pre_24188 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24191 = heff_tr(heff_call(v_m_24189, 1, (V[]){v_s_24190}));
  switch (heff_tag_of(v_x2_24191)) {
  case TAG_MkPair: {
    V v_x_24192 = heff_field(v_x2_24191, 0);
    V v_s_24193 = heff_field(v_x2_24191, 1);
    V v_ru_24x2_24191_24MkPair = heff_take_reuse_n(v_x2_24191, 3ULL, 2);
    V v_t_24194 = heff_strAppend(heff_intShow(v_i_24185), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str93));
    V v_t_24195 = heff_strAppend(v_x_24192, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str94), v_t_24194));
    return heff_tag_at_n(v_ru_24x2_24191_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_pre_24188, v_t_24195), v_s_24193});
  }
  default: return heff_nomatch(v_x2_24191);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam19(V self, V *args) {
  V v_s_24204 = args[0];
  V v_m_24203 = heff_env(self)[0];
  V v_n_24199 = heff_env(self)[1];
  V v_i_24198 = heff_env(self)[2];
  V v_pre_24202 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24205 = heff_tr(heff_call(v_m_24203, 1, (V[]){v_s_24204}));
  switch (heff_tag_of(v_x2_24205)) {
  case TAG_MkPair: {
    V v_x_24206 = heff_field(v_x2_24205, 0);
    V v_s_24207 = heff_field(v_x2_24205, 1);
    V v_ru_24x2_24205_24MkPair = heff_take_reuse_n(v_x2_24205, 3ULL, 2);
    V v_t_24208 = heff_strAppend(heff_intShow(v_n_24199), ((V)&g_heff_2ecompile_2eemitc_2eexpF_str99));
    V v_t_24209 = heff_strAppend(heff_intShow(v_i_24198), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str100), v_t_24208));
    V v_t_24210 = heff_strAppend(v_x_24206, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str101), v_t_24209));
    return heff_tag_at_n(v_ru_24x2_24205_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_pre_24202, v_t_24210), v_s_24207});
  }
  default: return heff_nomatch(v_x2_24205);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam20(V self, V *args) {
  V v_s_24217 = args[0];
  V v_m_24216 = heff_env(self)[0];
  V v_pre_24215 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24218 = heff_tr(heff_call(v_m_24216, 1, (V[]){v_s_24217}));
  switch (heff_tag_of(v_x2_24218)) {
  case TAG_MkPair: {
    V v_x_24219 = heff_field(v_x2_24218, 0);
    V v_s_24220 = heff_field(v_x2_24218, 1);
    V v_ru_24x2_24218_24MkPair = heff_take_reuse_n(v_x2_24218, 3ULL, 2);
    V v_t_24221 = heff_strAppend(v_pre_24215, heff_strAppend(v_x_24219, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str106)));
    return heff_tag_at_n(v_ru_24x2_24218_24MkPair, TAG_MkPair, 2, (V[]){v_t_24221, v_s_24220});
  }
  default: return heff_nomatch(v_x2_24218);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam21(V self, V *args) {
  V v_s_24228 = args[0];
  V v_x_24227 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24227, v_s_24228});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam22(V self, V *args) {
  V v_s_24235 = args[0];
  V v_m_24234 = heff_env(self)[0];
  V v_post_24233 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24236 = heff_tr(heff_call(v_m_24234, 1, (V[]){v_s_24235}));
  switch (heff_tag_of(v_x2_24236)) {
  case TAG_MkPair: {
    V v_x_24237 = heff_field(v_x2_24236, 0);
    V v_s_24238 = heff_field(v_x2_24236, 1);
    V v_ru_24x2_24236_24MkPair = heff_take_reuse_n(v_x2_24236, 3ULL, 2);
    V v_t_24239 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str116), heff_strAppend(v_x_24237, v_post_24233));
    return heff_tag_at_n(v_ru_24x2_24236_24MkPair, TAG_MkPair, 2, (V[]){v_t_24239, v_s_24238});
  }
  default: return heff_nomatch(v_x2_24236);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam23(V self, V *args) {
  V v_s_24244 = args[0];
  V v_m_24243 = heff_env(self)[0];
  V v_p_24241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24245 = heff_tr(heff_call(v_m_24243, 1, (V[]){v_s_24244}));
  switch (heff_tag_of(v_x2_24245)) {
  case TAG_MkPair: {
    V v_x_24246 = heff_field(v_x2_24245, 0);
    V v_s_24247 = heff_field(v_x2_24245, 1);
    V v_ru_24x2_24245_24MkPair = heff_take_reuse_n(v_x2_24245, 3ULL, 2);
    V v_t_24250;
    switch (heff_tag_of(v_x_24246)) {
    case TAG_Nil: {
      v_t_24250 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str117);
      break;
    }
    case TAG_Cons: {
      V v_x_24248 = heff_field(v_x_24246, 0);
      V v_xs_24249 = heff_field(v_x_24246, 1);
      heff_take_n(v_x_24246, 3ULL, 2);
      v_t_24250 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str118); V a_1 = v_x_24248; V a_2 = v_xs_24249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24249); r_; });
      break;
    }
    default: heff_nomatch(v_x_24246);
    }
    V v_t_24251 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str119), heff_strAppend(v_t_24250, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str120)));
    V v_x_24252 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str121), v_p_24241), v_t_24251);
    return heff_tag_at_n(v_ru_24x2_24245_24MkPair, TAG_MkPair, 2, (V[]){v_x_24252, v_s_24247});
  }
  default: return heff_nomatch(v_x2_24245);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam24(V self, V *args) {
  V v_s_24265 = args[0];
  V v_m_24264 = heff_env(self)[0];
  V v_es_24263 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24266 = heff_tr(heff_call(v_m_24264, 1, (V[]){v_s_24265}));
  switch (heff_tag_of(v_x2_24266)) {
  case TAG_MkPair: {
    V v_x_24267 = heff_field(v_x2_24266, 0);
    V v_s_24268 = heff_field(v_x2_24266, 1);
    V v_ru_24x2_24266_24MkPair = heff_take_reuse_n(v_x2_24266, 3ULL, 2);
    V v_x2_24271;
    switch (heff_tag_of(v_x_24267)) {
    case TAG_Nil: {
      v_x2_24271 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_24269 = heff_dup(heff_field(v_x_24267, 0));
      v_x2_24271 = heff_tag_n(TAG_Just, 1, (V[]){v_x_24269});
      break;
    }
    default: heff_nomatch(v_x_24267);
    }
    V v_t_24273;
    switch (heff_tag_of(v_x2_24271)) {
    case TAG_Nothing: {
      v_t_24273 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str122);
      break;
    }
    case TAG_Just: {
      V v_x_24272 = heff_field(v_x2_24271, 0);
      heff_take_n(v_x2_24271, 1ULL, 1);
      v_t_24273 = v_x_24272;
      break;
    }
    default: heff_nomatch(v_x2_24271);
    }
    V v_t_24274 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_es_24263; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_es_24263); r_; });
    V v_vs_24275 = (g_list_2edrop(MK_INT(1LL), v_x_24267));
    V v_t_24281;
    switch (heff_tag_of(v_vs_24275)) {
    case TAG_Nil: {
      v_t_24281 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str123);
      break;
    }
    case TAG_Cons: {
      V v_t_24280;
      switch (heff_tag_of(v_vs_24275)) {
      case TAG_Nil: {
        v_t_24280 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str124);
        break;
      }
      case TAG_Cons: {
        V v_x_24278 = heff_field(v_vs_24275, 0);
        V v_xs_24279 = heff_field(v_vs_24275, 1);
        heff_take_n(v_vs_24275, 3ULL, 2);
        v_t_24280 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eexpF_str125); V a_1 = v_x_24278; V a_2 = v_xs_24279; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24279); r_; });
        break;
      }
      default: heff_nomatch(v_vs_24275);
      }
      v_t_24281 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str126), heff_strAppend(v_t_24280, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str127)));
      break;
    }
    default: heff_nomatch(v_vs_24275);
    }
    V v_t_24282 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str128), heff_strAppend(v_t_24281, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str129)));
    V v_t_24283 = heff_strAppend(heff_intShow(v_t_24274), v_t_24282);
    V v_t_24284 = heff_strAppend(v_t_24273, heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str130), v_t_24283));
    V v_x_24285 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str131), v_t_24284);
    return heff_tag_at_n(v_ru_24x2_24266_24MkPair, TAG_MkPair, 2, (V[]){v_x_24285, v_s_24268});
  }
  default: return heff_nomatch(v_x2_24266);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam25(V self, V *args) {
  V v_s_24288 = args[0];
  V v_m_24287 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24289 = heff_tr(heff_call(v_m_24287, 1, (V[]){v_s_24288}));
  switch (heff_tag_of(v_x2_24289)) {
  case TAG_MkPair: {
    V v_x_24290 = heff_field(v_x2_24289, 0);
    V v_s_24291 = heff_field(v_x2_24289, 1);
    V v_ru_24x2_24289_24MkPair = heff_take_reuse_n(v_x2_24289, 3ULL, 2);
    V v_t_24292 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eexpF_str132), heff_strAppend(v_x_24290, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str133)));
    return heff_tag_at_n(v_ru_24x2_24289_24MkPair, TAG_MkPair, 2, (V[]){v_t_24292, v_s_24291});
  }
  default: return heff_nomatch(v_x2_24289);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam26(V self, V *args) {
  V v_s_24293 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eexpF_str134), v_s_24293});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam27(V self, V *args) {
  V v_s_24300 = args[0];
  V v_m_24299 = heff_env(self)[0];
  V v_pre_24298 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24301 = heff_tr(heff_call(v_m_24299, 1, (V[]){v_s_24300}));
  switch (heff_tag_of(v_x2_24301)) {
  case TAG_MkPair: {
    V v_x_24302 = heff_field(v_x2_24301, 0);
    V v_s_24303 = heff_field(v_x2_24301, 1);
    V v_ru_24x2_24301_24MkPair = heff_take_reuse_n(v_x2_24301, 3ULL, 2);
    V v_t_24304 = heff_strAppend(v_pre_24298, heff_strAppend(v_x_24302, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str139)));
    return heff_tag_at_n(v_ru_24x2_24301_24MkPair, TAG_MkPair, 2, (V[]){v_t_24304, v_s_24303});
  }
  default: return heff_nomatch(v_x2_24301);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam28(V self, V *args) {
  V v_s_24311 = args[0];
  V v_m_24310 = heff_env(self)[0];
  V v_pre_24309 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24312 = heff_tr(heff_call(v_m_24310, 1, (V[]){v_s_24311}));
  switch (heff_tag_of(v_x2_24312)) {
  case TAG_MkPair: {
    V v_x_24313 = heff_field(v_x2_24312, 0);
    V v_s_24314 = heff_field(v_x2_24312, 1);
    V v_ru_24x2_24312_24MkPair = heff_take_reuse_n(v_x2_24312, 3ULL, 2);
    V v_t_24315 = heff_strAppend(v_pre_24309, heff_strAppend(v_x_24313, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str144)));
    return heff_tag_at_n(v_ru_24x2_24312_24MkPair, TAG_MkPair, 2, (V[]){v_t_24315, v_s_24314});
  }
  default: return heff_nomatch(v_x2_24312);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam29(V self, V *args) {
  V v_s_24322 = args[0];
  V v_m_24321 = heff_env(self)[0];
  V v_pre_24320 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24323 = heff_tr(heff_call(v_m_24321, 1, (V[]){v_s_24322}));
  switch (heff_tag_of(v_x2_24323)) {
  case TAG_MkPair: {
    V v_x_24324 = heff_field(v_x2_24323, 0);
    V v_s_24325 = heff_field(v_x2_24323, 1);
    V v_ru_24x2_24323_24MkPair = heff_take_reuse_n(v_x2_24323, 3ULL, 2);
    V v_t_24326 = heff_strAppend(v_pre_24320, heff_strAppend(v_x_24324, ((V)&g_heff_2ecompile_2eemitc_2eexpF_str149)));
    return heff_tag_at_n(v_ru_24x2_24323_24MkPair, TAG_MkPair, 2, (V[]){v_t_24326, v_s_24325});
  }
  default: return heff_nomatch(v_x2_24323);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam30(V self, V *args) {
  V v_s_24330 = args[0];
  V v_m_24329 = heff_env(self)[0];
  V v_p_24327 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24331 = heff_tr(heff_call(v_m_24329, 1, (V[]){v_s_24330}));
  switch (heff_tag_of(v_x2_24331)) {
  case TAG_MkPair: {
    V v_x_24332 = heff_field(v_x2_24331, 0);
    V v_s_24333 = heff_field(v_x2_24331, 1);
    V v_ru_24x2_24331_24MkPair = heff_take_reuse_n(v_x2_24331, 3ULL, 2);
    V v_x2_24334 = (g_heff_2eelab_2efixed_2efixedPrimOf(heff_dup(v_p_24327)));
    V v_x_24336;
    switch (heff_tag_of(v_x2_24334)) {
    case TAG_Nothing: {
      v_x_24336 = (g_heff_2ecompile_2eemitc_2efloat64U(v_p_24327, v_x_24332));
      break;
    }
    case TAG_Just: {
      V v_fp_24335 = heff_field(v_x2_24334, 0);
      heff_take_n(v_x2_24334, 1ULL, 1);
      heff_drop(v_p_24327);
      v_x_24336 = (g_heff_2ecompile_2eemitc_2efixedU(v_fp_24335, v_x_24332));
      break;
    }
    default: heff_nomatch(v_x2_24334);
    }
    return heff_tag_at_n(v_ru_24x2_24331_24MkPair, TAG_MkPair, 2, (V[]){v_x_24336, v_s_24333});
  }
  default: return heff_nomatch(v_x2_24331);
  }
}
V g_heff_2ecompile_2eemitc_2eexpF_lam31(V self, V *args) {
  V v_s_24340 = args[0];
  V v_x_24339 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24339, v_s_24340});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam32(V self, V *args) {
  V v_s_24348 = args[0];
  V v_x_24347 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24347, v_s_24348});
}
V g_heff_2ecompile_2eemitc_2eexpF_lam33(V self, V *args) {
  V v_s_24355 = args[0];
  V v_x_24354 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24354, v_s_24355});
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagain_str0, 3, " t_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagain_str1, 3, " = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagain_str2, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagain_str3, 9, "goto top;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagain_str4, 2, "v_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagain_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagain_str6, 5, " = t_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eagain_str7, 1, ";");
Clo g_heff_2ecompile_2eemitc_2eagain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eagain_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eagain(V v_ts_240, V v_ps_241, V v_vs_242) {
top: ;
  V v_t_243 = (g_list_2ezipWith_24s1876717925x1404326288(v_ts_240, heff_dup(v_vs_242)));
  V v_t_244 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_242));
  V v_t_245 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_244, MK_INT(1LL))));
  V v_t_246 = (g_list_2ezipWith_24s1907923014x815971565(((V)&g_heff_2ecompile_2eemitc_2eagain_str0), ((V)&g_heff_2ecompile_2eemitc_2eagain_str1), ((V)&g_heff_2ecompile_2eemitc_2eagain_str2), v_t_243, v_t_245));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2eagain_str3), NTAG(TAG_Nil)});
  V v_t_248 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_242; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_vs_242); r_; });
  V v_t_249 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_248, MK_INT(1LL))));
  V v_t_2410 = (g_prelude_2e_2b_2b_24f1882260109x1043267855(v_t_247, ((V)&g_heff_2ecompile_2eemitc_2eagain_str4), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eagain_str5), ((V)&g_heff_2ecompile_2eemitc_2eagain_str6), ((V)&g_heff_2ecompile_2eemitc_2eagain_str7), v_ps_241, v_t_249));
  return (g_prelude_2e_2b_2b(v_t_246, v_t_2410));
}
V g_heff_2ecompile_2eemitc_2eagain_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2eagain(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str0, 1, "0");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str1, 7, "V f_ = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str2, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str3, 5, "args[");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str4, 4, "] = ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str5, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str6, 19, "if (heff_exact(f_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str7, 52, ", args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str8, 21, "return heff_tail(f_, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2einPlace_str9, 8, ", args);");
Clo g_heff_2ecompile_2eemitc_2einPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2einPlace_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2einPlace(V v_vs_240) {
top: ;
  V v_x2_243;
  switch (heff_tag_of(v_vs_240)) {
  case TAG_Nil: {
    v_x2_243 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_241 = heff_dup(heff_field(v_vs_240, 0));
    v_x2_243 = heff_tag_n(TAG_Just, 1, (V[]){v_x_241});
    break;
  }
  default: heff_nomatch(v_vs_240);
  }
  V v_t_245;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_heff_2ecompile_2eemitc_2einPlace_str0);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_243, 0);
    heff_take_n(v_x2_243, 1ULL, 1);
    v_t_245 = v_x_244;
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_246 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2einPlace_str1), heff_strAppend(v_t_245, ((V)&g_heff_2ecompile_2eemitc_2einPlace_str2)));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = (g_list_2edrop(MK_INT(1LL), heff_dup(v_vs_240)));
  V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2410 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_249, MK_INT(2LL))));
  V v_t_2411 = (g_list_2ezipWith_24s1814128165x1680687847(((V)&g_heff_2ecompile_2eemitc_2einPlace_str3), ((V)&g_heff_2ecompile_2eemitc_2einPlace_str4), ((V)&g_heff_2ecompile_2eemitc_2einPlace_str5), v_t_248, v_t_2410));
  V v_t_2412 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_240));
  V v_t_2413 = heff_intShow(heff_intSub(v_t_2412, MK_INT(1LL)));
  V v_t_2414 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2einPlace_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2ecompile_2eemitc_2einPlace_str7)));
  V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_vs_240; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_vs_240); r_; });
  V v_t_2416 = heff_intShow(heff_intSub(v_t_2415, MK_INT(1LL)));
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2einPlace_str8), heff_strAppend(v_t_2416, ((V)&g_heff_2ecompile_2eemitc_2einPlace_str9)));
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
  V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2418})));
  return (g_prelude_2e_2b_2b(v_t_247, v_t_2419));
}
V g_heff_2ecompile_2eemitc_2einPlace_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2einPlace(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str1, 1, "(");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str2, 2, ");");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str3, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str4, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str6, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str7, 21, "_entry(V self, V *a);");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str10, 5, ", 0};");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str11, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str12, 8, "_entry, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str13, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str14, 33, "_clo = {{0x80000000u, K_CLO, 0}, ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str15, 11, "static Clo ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str16, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str17, 1, ";");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str18, 6, "top: ;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str19, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str20, 2, " {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str21, 2, "  ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str23, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str24, 22, "_entry(V self, V *a) {");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str25, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str26, 13, "  (void)self;");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str27, 9, "static V ");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str28, 1, "}");
HEFF_LIT(g_heff_2ecompile_2eemitc_2efunDef_str29, 0, "");
V g_heff_2ecompile_2eemitc_2efunDef_lam0(V self, V *args);
Clo g_heff_2ecompile_2eemitc_2efunDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2efunDef_entry, 1, 0};

V g_heff_2ecompile_2eemitc_2efunDef(V v_f_240) {
top: ;
  V v_t_241 = (g_heff_2ecompile_2eemitc_2eckOf(heff_rfield(v_f_240, 5)));
  V v_m_242 = heff_tr(heff_call(heff_get_n(v_t_241, 1, 3), 1, (V[]){heff_dup(heff_rfield(v_f_240, 3))}));
  return heff_clo_n(g_heff_2ecompile_2eemitc_2efunDef_lam0, 1, 2, (V[]){v_m_242, v_f_240});
}
V g_heff_2ecompile_2eemitc_2efunDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eemitc_2efunDef(a[0]);
}
V g_heff_2ecompile_2eemitc_2efunDef_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_244 = heff_tr(heff_call(v_m_242, 1, (V[]){v_s_243}));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_s_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_247 = (g_heff_2ecompile_2eemitc_2eckOf(heff_rfield(v_f_240, 5)));
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_t_247, 1, 3), 1, (V[]){heff_take_field(v_f_240, 4)}));
    V v_x2_249 = heff_tr(heff_call(v_m_248, 1, (V[]){v_s_246}));
    switch (heff_tag_of(v_x2_249)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_s_2411 = heff_field(v_x2_249, 1);
      V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
      V v_m_2412 = (g_heff_2ecompile_2eemitc_2ewrapperCode(heff_dup(heff_rfield(v_f_240, 0)), heff_rfield(v_f_240, 5), heff_rfield(v_f_240, 7)));
      V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        V v_s_2415 = heff_field(v_x2_2413, 1);
        V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
        V v_t_2416 = heff_dup(heff_rfield(v_f_240, 7));
        V v_t_2418;
        switch (heff_tag_of(v_t_2416)) {
        case TAG_Nothing: {
          v_t_2418 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2416, 0ULL, 1);
          v_t_2418 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_t_2416);
        }
        V v_t_2419 = ({ V a_0 = heff_dup(heff_rfield(v_f_240, 0)); V a_1 = heff_dup(heff_rfield(v_f_240, 1)); V a_2 = heff_rfield(v_f_240, 5); V a_3 = heff_rfield(v_f_240, 6); V a_4 = v_t_2418; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2418); r_; });
        V v_t_2420 = heff_dup(heff_rfield(v_f_240, 7));
        V v_t_2429;
        switch (heff_tag_of(v_t_2420)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x2_244_24MkPair, 2);
          v_t_2429 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_x31_2421 = heff_field(v_t_2420, 0);
          heff_take_n(v_t_2420, 1ULL, 1);
          switch (heff_tag_of(v_x31_2421)) {
          case TAG_MkWrapper: {
            V v_ws_2422 = heff_field(v_x31_2421, 0);
            heff_take_n(v_x31_2421, 1ULL, 2);
            V v_t_2424 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_f_240, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str0)));
            V v_t_2425 = (g_heff_2ecompile_2eemitc_2eckOf(heff_rfield(v_f_240, 5)));
            V v_t_2426 = (g_heff_2ecompile_2eemitc_2eparamList(v_t_2425, v_ws_2422));
            V v_t_2427 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str1), heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2eemitc_2efunDef_str2)));
            V v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str3), v_t_2424), v_t_2427);
            v_t_2429 = heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str4), v_t_2428), NTAG(TAG_Nil)});
            break;
          }
          default: heff_nomatch(v_x31_2421);
          }
          break;
        }
        default: heff_nomatch(v_t_2420);
        }
        V v_t_2430 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_f_240, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str5)));
        V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str6), v_t_2430), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str7));
        V v_t_2432 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_f_240, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str8)));
        V v_t_2433 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_f_240, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str9)));
        V v_t_2434 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_240, 1)));
        V v_t_2435 = heff_strAppend(heff_intShow(v_t_2434), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str10));
        V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str11), v_t_2433), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str12), v_t_2435));
        V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str13), v_t_2432), heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str14), v_t_2436));
        V v_t_2438 = heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str15), v_t_2437), NTAG(TAG_Nil)});
        V v_t_2439 = heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str16), v_t_2431), v_t_2438});
        V v_t_2440 = (g_prelude_2e_2b_2b(v_t_2429, v_t_2439));
        V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2419, ((V)&g_heff_2ecompile_2eemitc_2efunDef_str17)), v_t_2440});
        V v_t_2442 = heff_take_field(v_f_240, 7);
        V v_t_2444;
        switch (heff_tag_of(v_t_2442)) {
        case TAG_Nothing: {
          v_t_2444 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_t_2442, 0ULL, 1);
          v_t_2444 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_t_2442);
        }
        V v_t_2445 = ({ V a_0 = heff_dup(heff_rfield(v_f_240, 0)); V a_1 = heff_dup(heff_rfield(v_f_240, 1)); V a_2 = heff_rfield(v_f_240, 5); V a_3 = heff_rfield(v_f_240, 6); V a_4 = v_t_2444; V r_ = (g_heff_2ecompile_2eemitc_2efunHead(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2444); r_; });
        V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str18), NTAG(TAG_Nil)});
        V v_t_2447 = (g_prelude_2e_2b_2b_24f1280198663x1762821176(v_t_2446, ((V)&g_heff_2ecompile_2eemitc_2efunDef_str19), v_x_245));
        V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2445, ((V)&g_heff_2ecompile_2eemitc_2efunDef_str20)), v_t_2447});
        V v_t_2449 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2ecompile_2eemitc_2efunDef_str21), v_x_2410));
        V v_t_2450 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_f_240, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str22)));
        V v_t_2451 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str23), v_t_2450), ((V)&g_heff_2ecompile_2eemitc_2efunDef_str24));
        V v_t_2452 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_240, 1)));
        V v_t_2453 = (g_heff_2ecompile_2eemitc_2eentryCall(heff_take_field(v_f_240, 0), heff_get_n(v_f_240, 2, 8), v_t_2452));
        V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str25), NTAG(TAG_Nil)});
        V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str26), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, v_t_2454})});
        V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2efunDef_str27), v_t_2451), v_t_2455});
        V v_t_2457 = (g_prelude_2e_2b_2b(v_x_2414, v_t_2456));
        V v_t_2458 = (g_prelude_2e_2b_2b(v_t_2449, heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str28), v_t_2457})));
        V v_t_2459 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eemitc_2efunDef_str29), v_t_2448}), v_t_2458));
        V v_x_2460 = heff_rec_n(2, shape_protos__code, (V[]){v_t_2441, v_t_2459});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2460, v_s_2415});
      }
      default: return heff_nomatch(v_x2_2413);
      }
    }
    default: return heff_nomatch(v_x2_249);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemptyCS_str0, 0, "");

static V g_heff_2ecompile_2eemitc_2eemptyCS_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2eemptyCS_st;
static V g_heff_2ecompile_2eemitc_2eemptyCS_init(void) {
  return heff_rec_n(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){((V)&g_heff_2ecompile_2eemitc_2eemptyCS_str0), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2eemptyCS_st)) return g_heff_2ecompile_2eemitc_2eemptyCS_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2eemptyCS_val, &g_heff_2ecompile_2eemitc_2eemptyCS_st, g_heff_2ecompile_2eemitc_2eemptyCS_init);
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str0, 4, "TAG_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eceOf_str1, 4, "LBL_");
Clo g_heff_2ecompile_2eemitc_2eceOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eceOf_entry, 3, 0};

V g_heff_2ecompile_2eemitc_2eceOf(V v_provs_240, V v_facts_241, V v_names_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_x_243 = heff_field(v_names_242, 0);
    v_t_245 = heff_dup(v_x_243);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_provs_240)));
  V v_t_247 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str0); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_246; V r_ = (g_list_2efoldl_24s1414103338x1084960320(a_0, a_1, a_2, a_3)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_prelude_2e_2b_2b(v_t_245, v_t_247));
  V v_xs_249 = (g_list_2efilter_24s1967523567x64647275(v_t_248));
  V v_m_2410 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_249; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_249); r_; });
  V v_t_2411 = ({ V a_0 = v_m_2410; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2410); r_; });
  V v_t_2412 = (g_list_2emap_24s1937570095x2110149801(v_t_2411));
  V v_t_2413 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V a_2 = heff_dup(g_map_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2enumbered(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2414 = ({ V a_0 = MK_INT(10LL); V a_1 = MK_INT(65526LL); V a_2 = v_t_2412; V a_3 = v_t_2413; V a_4 = heff_dup(g_map_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2ehashedGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2412); r_; });
  V v_t_2417;
  switch (heff_tag_of(v_names_242)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_names_242, 1);
    v_t_2417 = heff_dup(v_y_2416);
    break;
  }
  default: heff_nomatch(v_names_242);
  }
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_provs_240));
  V v_t_2419 = ({ V a_0 = ((V)&g_heff_2ecompile_2eemitc_2eceOf_str1); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2418; V r_ = (g_list_2efoldl_24s1414103338x1084960320(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); r_; });
  V v_xs_2420 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2419));
  V v_m_2421 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2420; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_xs_2420); r_; });
  V v_t_2422 = ({ V a_0 = v_m_2421; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2421); r_; });
  V v_t_2423 = (g_list_2emap_24s1937570095x2110149801(v_t_2422));
  V v_t_2424 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(2147483647LL); V a_2 = v_t_2423; V a_3 = heff_dup(g_map_2eempty_get()); V a_4 = heff_dup(g_map_2eempty_get()); V r_ = (g_heff_2ecompile_2eemitc_2ehashedGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2423); r_; });
  return heff_rec_n(3, shape_tags__lbls__facts, (V[]){v_t_2414, v_t_2424, v_facts_241});
}
V g_heff_2ecompile_2eemitc_2eceOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eemitc_2eceOf(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str1, 2, "g_");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eemitc_2eemitAt_str3, 2, "g_");
Clo g_heff_2ecompile_2eemitc_2eemitAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eemitc_2eemitAt_entry, 6, 0};

V g_heff_2ecompile_2eemitc_2eemitAt(V v_ce_240, V v_kept_241, V v_acc_242, V v_d_243, V v_own_244, V v_v_245) {
top: ;
  V v_x2_246 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_243, 0)), v_kept_241));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_k_247 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Just = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_k_247, 0)), heff_dup(v_v_245))) {
      v_t_249 = heff_tag_at_n(v_ru_24x2_246_24Just, TAG_Just, 1, (V[]){v_k_247});
    } else {
      heff_drop_rec(v_k_247, 8);
      heff_drop_cell(v_ru_24x2_246_24Just, 1);
      v_t_249 = NTAG(TAG_Nothing);
    }
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    V v_x1_2410 = (g_heff_2ecompile_2elower_2ecDef(heff_get_n(v_ce_240, 2, 3), heff_dup(v_d_243), v_own_244));
    V v_t_2415;
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_DFun: {
      V v_f_2411 = heff_field(v_x1_2410, 0);
      heff_take_n(v_x1_2410, 1ULL, 1);
      v_t_2415 = (g_heff_2ecompile_2eemitc_2efunDef(v_f_2411));
      break;
    }
    case TAG_DVal: {
      V v_key_2412 = heff_field(v_x1_2410, 0);
      V v_body_2413 = heff_field(v_x1_2410, 1);
      V v_rs_2414 = heff_field(v_x1_2410, 2);
      heff_take_n(v_x1_2410, 7ULL, 3);
      v_t_2415 = ({ V a_0 = v_key_2412; V a_1 = v_body_2413; V a_2 = v_rs_2414; V r_ = (g_heff_2ecompile_2eemitc_2evalDef(a_0, a_1, a_2)); heff_drop(v_rs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_x1_2410);
    }
    V v_t_2416 = (g_heff_2ecompile_2eemitc_2emangleW(heff_dup(heff_rfield(v_d_243, 0)), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eemitAt_str0)));
    V v_o_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eemitAt_str1), v_t_2416);
    V v_t_2418 = heff_rec_n(8, shape_owner__nlam__lams__protos__nstr__strs__shapes__prims, (V[]){v_o_2417, MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2419 = heff_tr(heff_call(v_t_2415, 1, (V[]){v_t_2418}));
    return (g_heff_2ecompile_2eemitc_2efreshEmitted(v_acc_242, heff_get_n(v_d_243, 0, 3), v_v_245, v_t_2419));
  }
  case TAG_Just: {
    V v_k_2420 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    heff_drop_rec(v_ce_240, 3);
    heff_drop(v_v_245);
    V v_t_2421 = heff_rec_n(2, shape_protos__code, (V[]){heff_dup(heff_rfield(v_k_2420, 1)), heff_dup(heff_rfield(v_k_2420, 2))});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, heff_take_field(v_acc_242, 0)});
    V v_t_2423 = (g_heff_2ecompile_2eemitc_2emangleW(heff_get_n(v_d_243, 0, 3), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ecompile_2eemitc_2eemitAt_str2)));
    V v_t_2424 = (g_heff_2ecompile_2eemitc_2emergeKept(heff_strAppend(((V)&g_heff_2ecompile_2eemitc_2eemitAt_str3), v_t_2423), v_k_2420, heff_take_field(v_acc_242, 1)));
    return ({ V rv_0 = v_t_2422; V rv_1 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_acc_242, 4ULL, 3, shape_ems__s__fresh, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2ecompile_2eemitc_2eemitAt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_heff_2ecompile_2eemitc_2eemitAt(a[0], a1, a[2], a[3], a4, a[5]); heff_drop(a1); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2ecompile_2eemitc_2ethreadsLine_str0, 22, "#define HEFF_THREADS 1");

static V g_heff_2ecompile_2eemitc_2ethreadsLine_val;
static HEFF_ONCE g_heff_2ecompile_2eemitc_2ethreadsLine_st;
static V g_heff_2ecompile_2eemitc_2ethreadsLine_init(void) {
  return ((V)&g_heff_2ecompile_2eemitc_2ethreadsLine_str0);
}
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eemitc_2ethreadsLine_st)) return g_heff_2ecompile_2eemitc_2ethreadsLine_val;
  return heff_global(&g_heff_2ecompile_2eemitc_2ethreadsLine_val, &g_heff_2ecompile_2eemitc_2ethreadsLine_st, g_heff_2ecompile_2eemitc_2ethreadsLine_init);
}