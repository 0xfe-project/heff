// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ImplicitParam 51130
#define TAG_IntWord 51777
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_PatAs 19989
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_RuneWord 42901
#define TAG_SetField 47531
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StringWord 15530
#define TAG_TagVariant 25174
#define TAG_TypeWord 10401
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_cmt 308164
#define LBL_comments 142722952
#define LBL_decl 9574769
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_err 310239
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_i 323
#define LBL_imports 10411951
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tokens 1078955205
static uint32_t shape_e__decl[] = {LBL_e, LBL_decl};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_imports__decls__diags[] = {LBL_imports, LBL_decls, LBL_diags};
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_clo;
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2eformat_2ealtKey(V, V);
V g_heff_2esyntax_2eformat_2ealtKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ealtKey_clo;
V g_heff_2esyntax_2eformat_2eequationKey(V, V);
V g_heff_2esyntax_2eformat_2eequationKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eequationKey_clo;
V g_heff_2esyntax_2eformat_2efieldDeclKey(V, V);
V g_heff_2esyntax_2eformat_2efieldDeclKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2efieldDeclKey_clo;
V g_heff_2esyntax_2eformat_2efieldSetKey(V, V);
V g_heff_2esyntax_2eformat_2efieldSetKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2efieldSetKey_clo;
V g_heff_2esyntax_2eformat_2eformat(V);
V g_heff_2esyntax_2eformat_2eformat_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eformat_clo;
V g_heff_2esyntax_2eformat_2ekeyDeclF(V, V);
V g_heff_2esyntax_2eformat_2ekeyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyDeclF_clo;
V g_heff_2esyntax_2eformat_2ekeyTermF(V, V);
V g_heff_2esyntax_2eformat_2ekeyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyTermF_clo;
V g_heff_2esyntax_2eformat_2ekeys_get(void);
V g_heff_2esyntax_2eformat_2elamKey(V, V);
V g_heff_2esyntax_2eformat_2elamKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2elamKey_clo;
V g_heff_2esyntax_2eformat_2emeaningFrom(V);
V g_heff_2esyntax_2eformat_2emeaningFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2emeaningFrom_clo;
V g_heff_2esyntax_2eformat_2eparamKey(V, V);
V g_heff_2esyntax_2eformat_2eparamKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eparamKey_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2eformat_2epiKey(V, V);
V g_heff_2esyntax_2eformat_2epiKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epiKey_clo;
V g_heff_2esyntax_2eformat_2esameMeaning(V, V, V, V);
V g_heff_2esyntax_2eformat_2esameMeaning_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2esameMeaning_clo;
V g_heff_2esyntax_2eformat_2estmtKey(V, V);
V g_heff_2esyntax_2eformat_2estmtKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2estmtKey_clo;
V g_heff_2esyntax_2eformat_2estrsEq(V, V);
V g_heff_2esyntax_2eformat_2estrsEq_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2estrsEq_clo;
V g_heff_2esyntax_2eformat_2evariantKey(V, V);
V g_heff_2esyntax_2eformat_2evariantKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2evariantKey_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_clo;
V g_heff_2esyntax_2esurface_2ereadLexed_24s1088510898x79166857(V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_24s1088510898x79166857_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_24s1088510898x79166857_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1195846327x230486685(V, V, V, V, V, V, V);
V g_list_2emap_24s1195846327x230486685_entry(V self, V *a);
extern Clo g_list_2emap_24s1195846327x230486685_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_list_2emap_24s1561756891x1126436879(V);
V g_list_2emap_24s1561756891x1126436879_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_clo;
V g_list_2emap_24s1602529591x1809288035(V);
V g_list_2emap_24s1602529591x1809288035_entry(V self, V *a);
extern Clo g_list_2emap_24s1602529591x1809288035_clo;
V g_list_2emap_24s424270175x1918189508(V);
V g_list_2emap_24s424270175x1918189508_entry(V self, V *a);
extern Clo g_list_2emap_24s424270175x1918189508_clo;
V g_list_2emap_24s953916415x1126219438(V, V);
V g_list_2emap_24s953916415x1126219438_entry(V self, V *a);
extern Clo g_list_2emap_24s953916415x1126219438_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str3, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str4, 3, "var");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str7, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str8, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str9, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str13, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str14, 3, "tag");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str15, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str17, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str18, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str19, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str21, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str22, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str23, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str24, 2, "op");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str25, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str27, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str28, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str29, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str30, 3, "int");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str31, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str33, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str34, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str35, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str36, 5, "float");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str37, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str39, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str40, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str41, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str42, 6, "string");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str43, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str45, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str46, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str47, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str48, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str49, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str50, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str51, 5, "field");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str53, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str54, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str55, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str56, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str57, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str58, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str59, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str60, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str61, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str62, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str63, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str64, 6, "record");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str65, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str66, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str67, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str68, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str69, 6, "String");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str70, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str71, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str72, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str73, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str74, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str75, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str76, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str77, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str78, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str79, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str80, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str81, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str82, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str83, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str84, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str85, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str86, 4, "word");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str87, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str88, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str89, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str90, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str91, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str92, 2, "as");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str93, 1, ")");
Clo g_heff_2esyntax_2eformat_2epatKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2epatKey_entry, 1, 0};

V g_heff_2esyntax_2eformat_2epatKey(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      V v_x2_245 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str0), v_t_244));
      V v_t_248;
      switch (heff_tag_of(v_x2_245)) {
      case TAG_Nil: {
        v_t_248 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_246 = heff_field(v_x2_245, 0);
        V v_xs_247 = heff_field(v_x2_245, 1);
        heff_take_n(v_x2_245, 3ULL, 2);
        v_t_248 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
        break;
      }
      default: heff_nomatch(v_x2_245);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str3), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str4), heff_strAppend(v_t_248, ((V)&g_heff_2esyntax_2eformat_2epatKey_str5))));
    }
    case TAG_PatTag: {
      V v_t_249 = heff_field(v_x11_241, 0);
      V v_ps_2411 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_x2_2412 = (g_list_2emap(((V)&g_heff_2esyntax_2eformat_2epatKey_clo), v_ps_2411));
      V v_t_2415;
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nil: {
        v_t_2415 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str6);
        break;
      }
      case TAG_Cons: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        V v_xs_2414 = heff_field(v_x2_2412, 1);
        heff_take_n(v_x2_2412, 3ULL, 2);
        v_t_2415 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str7); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2412);
      }
      V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str8), heff_strAppend(v_t_2415, ((V)&g_heff_2esyntax_2eformat_2epatKey_str9)));
      V v_t_2417 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      V v_parts_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2417});
      V v_x2_2419 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str10), v_parts_2418));
      V v_t_2422;
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_Nil: {
        v_t_2422 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2420 = heff_field(v_x2_2419, 0);
        V v_xs_2421 = heff_field(v_x2_2419, 1);
        heff_take_n(v_x2_2419, 3ULL, 2);
        v_t_2422 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str12); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2419);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str13), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str14), heff_strAppend(v_t_2422, ((V)&g_heff_2esyntax_2eformat_2epatKey_str15))));
    }
    case TAG_PatOp: {
      V v_x_2423 = heff_field(v_x11_241, 0);
      V v_ps_2425 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_x2_2426 = (g_list_2emap(((V)&g_heff_2esyntax_2eformat_2epatKey_clo), v_ps_2425));
      V v_t_2429;
      switch (heff_tag_of(v_x2_2426)) {
      case TAG_Nil: {
        v_t_2429 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str16);
        break;
      }
      case TAG_Cons: {
        V v_x_2427 = heff_field(v_x2_2426, 0);
        V v_xs_2428 = heff_field(v_x2_2426, 1);
        heff_take_n(v_x2_2426, 3ULL, 2);
        v_t_2429 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str17); V a_1 = v_x_2427; V a_2 = v_xs_2428; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2428); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2426);
      }
      V v_t_2430 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str18), heff_strAppend(v_t_2429, ((V)&g_heff_2esyntax_2eformat_2epatKey_str19)));
      V v_t_2431 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
      V v_parts_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2423, v_t_2431});
      V v_x2_2433 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str20), v_parts_2432));
      V v_t_2436;
      switch (heff_tag_of(v_x2_2433)) {
      case TAG_Nil: {
        v_t_2436 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str21);
        break;
      }
      case TAG_Cons: {
        V v_x_2434 = heff_field(v_x2_2433, 0);
        V v_xs_2435 = heff_field(v_x2_2433, 1);
        heff_take_n(v_x2_2433, 3ULL, 2);
        v_t_2436 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str22); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2433);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str23), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str24), heff_strAppend(v_t_2436, ((V)&g_heff_2esyntax_2eformat_2epatKey_str25))));
    }
    case TAG_PatInt: {
      V v_i_2437 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2438 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){heff_intShow(v_i_2437), NTAG(TAG_Nil)});
      V v_x2_2439 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str26), v_t_2438));
      V v_t_2442;
      switch (heff_tag_of(v_x2_2439)) {
      case TAG_Nil: {
        v_t_2442 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str27);
        break;
      }
      case TAG_Cons: {
        V v_x_2440 = heff_field(v_x2_2439, 0);
        V v_xs_2441 = heff_field(v_x2_2439, 1);
        heff_take_n(v_x2_2439, 3ULL, 2);
        v_t_2442 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str28); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2439);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str29), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str30), heff_strAppend(v_t_2442, ((V)&g_heff_2esyntax_2eformat_2epatKey_str31))));
    }
    case TAG_PatFloat: {
      V v_x_2443 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2444 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){heff_floatShow(v_x_2443), NTAG(TAG_Nil)});
      V v_x2_2445 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str32), v_t_2444));
      V v_t_2448;
      switch (heff_tag_of(v_x2_2445)) {
      case TAG_Nil: {
        v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str33);
        break;
      }
      case TAG_Cons: {
        V v_x_2446 = heff_field(v_x2_2445, 0);
        V v_xs_2447 = heff_field(v_x2_2445, 1);
        heff_take_n(v_x2_2445, 3ULL, 2);
        v_t_2448 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str34); V a_1 = v_x_2446; V a_2 = v_xs_2447; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2447); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2445);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str35), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str36), heff_strAppend(v_t_2448, ((V)&g_heff_2esyntax_2eformat_2epatKey_str37))));
    }
    case TAG_PatString: {
      V v_x_2449 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2450 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2449, NTAG(TAG_Nil)});
      V v_x2_2451 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str38), v_t_2450));
      V v_t_2454;
      switch (heff_tag_of(v_x2_2451)) {
      case TAG_Nil: {
        v_t_2454 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str39);
        break;
      }
      case TAG_Cons: {
        V v_x_2452 = heff_field(v_x2_2451, 0);
        V v_xs_2453 = heff_field(v_x2_2451, 1);
        heff_take_n(v_x2_2451, 3ULL, 2);
        v_t_2454 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str40); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2451);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str41), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str42), heff_strAppend(v_t_2454, ((V)&g_heff_2esyntax_2eformat_2epatKey_str43))));
    }
    case TAG_PatRune: {
      V v_c_2455 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2456 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){heff_intShow(v_c_2455), NTAG(TAG_Nil)});
      V v_x2_2457 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str44), v_t_2456));
      V v_t_2460;
      switch (heff_tag_of(v_x2_2457)) {
      case TAG_Nil: {
        v_t_2460 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str45);
        break;
      }
      case TAG_Cons: {
        V v_x_2458 = heff_field(v_x2_2457, 0);
        V v_xs_2459 = heff_field(v_x2_2457, 1);
        heff_take_n(v_x2_2457, 3ULL, 2);
        v_t_2460 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str46); V a_1 = v_x_2458; V a_2 = v_xs_2459; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2459); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2457);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str47), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str48), heff_strAppend(v_t_2460, ((V)&g_heff_2esyntax_2eformat_2epatKey_str49))));
    }
    case TAG_PatRecord: {
      V v_fs_2461 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_x2_2462 = (g_list_2emap_24s1195846327x230486685(((V)&g_heff_2esyntax_2eformat_2epatKey_str50), ((V)&g_heff_2esyntax_2eformat_2epatKey_str51), ((V)&g_heff_2esyntax_2eformat_2epatKey_str52), ((V)&g_heff_2esyntax_2eformat_2epatKey_str53), ((V)&g_heff_2esyntax_2eformat_2epatKey_str54), ((V)&g_heff_2esyntax_2eformat_2epatKey_str55), v_fs_2461));
      V v_t_2465;
      switch (heff_tag_of(v_x2_2462)) {
      case TAG_Nil: {
        v_t_2465 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str56);
        break;
      }
      case TAG_Cons: {
        V v_x_2463 = heff_field(v_x2_2462, 0);
        V v_xs_2464 = heff_field(v_x2_2462, 1);
        heff_take_n(v_x2_2462, 3ULL, 2);
        v_t_2465 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str57); V a_1 = v_x_2463; V a_2 = v_xs_2464; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2464); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2462);
      }
      V v_t_2466 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str58), heff_strAppend(v_t_2465, ((V)&g_heff_2esyntax_2eformat_2epatKey_str59)));
      V v_parts_2467 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
      V v_x2_2468 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str60), v_parts_2467));
      V v_t_2471;
      switch (heff_tag_of(v_x2_2468)) {
      case TAG_Nil: {
        v_t_2471 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str61);
        break;
      }
      case TAG_Cons: {
        V v_x_2469 = heff_field(v_x2_2468, 0);
        V v_xs_2470 = heff_field(v_x2_2468, 1);
        heff_take_n(v_x2_2468, 3ULL, 2);
        v_t_2471 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str62); V a_1 = v_x_2469; V a_2 = v_xs_2470; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2470); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2468);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str63), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str64), heff_strAppend(v_t_2471, ((V)&g_heff_2esyntax_2eformat_2epatKey_str65))));
    }
    case TAG_PatWord: {
      V v_w_2472 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2474;
      switch (heff_tag_of(v_w_2472)) {
      case TAG_TypeWord: {
        v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str66);
        break;
      }
      case TAG_IntWord: {
        v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str67);
        break;
      }
      case TAG_FloatWord: {
        v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str68);
        break;
      }
      case TAG_StringWord: {
        v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str69);
        break;
      }
      case TAG_RuneWord: {
        v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str70);
        break;
      }
      case TAG_ArrayWord: {
        v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str71);
        break;
      }
      case TAG_AbandonWord: {
        v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str72);
        break;
      }
      case TAG_FixedWord: {
        V v_w_2473 = heff_field(v_w_2472, 0);
        heff_take_n(v_w_2472, 1ULL, 1);
        switch (heff_tag_of(v_w_2473)) {
        case TAG_I8: {
          v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str73);
          break;
        }
        case TAG_I16: {
          v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str74);
          break;
        }
        case TAG_I32: {
          v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str75);
          break;
        }
        case TAG_I64: {
          v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str76);
          break;
        }
        case TAG_U8: {
          v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str77);
          break;
        }
        case TAG_U16: {
          v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str78);
          break;
        }
        case TAG_U32: {
          v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str79);
          break;
        }
        case TAG_U64: {
          v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str80);
          break;
        }
        case TAG_F32: {
          v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str81);
          break;
        }
        default: heff_nomatch(v_w_2473);
        }
        break;
      }
      default: heff_nomatch(v_w_2472);
      }
      V v_parts_2475 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2474, NTAG(TAG_Nil)});
      V v_x2_2476 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str82), v_parts_2475));
      V v_t_2479;
      switch (heff_tag_of(v_x2_2476)) {
      case TAG_Nil: {
        v_t_2479 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str83);
        break;
      }
      case TAG_Cons: {
        V v_x_2477 = heff_field(v_x2_2476, 0);
        V v_xs_2478 = heff_field(v_x2_2476, 1);
        heff_take_n(v_x2_2476, 3ULL, 2);
        v_t_2479 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str84); V a_1 = v_x_2477; V a_2 = v_xs_2478; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2478); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2476);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str85), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str86), heff_strAppend(v_t_2479, ((V)&g_heff_2esyntax_2eformat_2epatKey_str87))));
    }
    case TAG_PatAs: {
      V v_x_2480 = heff_field(v_x11_241, 0);
      V v_q_2482 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_t_2483 = (g_heff_2esyntax_2eformat_2epatKey(v_q_2482));
      V v_t_2484 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2483, NTAG(TAG_Nil)});
      V v_parts_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2480, v_t_2484});
      V v_x2_2486 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str88), v_parts_2485));
      V v_t_2489;
      switch (heff_tag_of(v_x2_2486)) {
      case TAG_Nil: {
        v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str89);
        break;
      }
      case TAG_Cons: {
        V v_x_2487 = heff_field(v_x2_2486, 0);
        V v_xs_2488 = heff_field(v_x2_2486, 1);
        heff_take_n(v_x2_2486, 3ULL, 2);
        v_t_2489 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str90); V a_1 = v_x_2487; V a_2 = v_xs_2488; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2488); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2486);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str91), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str92), heff_strAppend(v_t_2489, ((V)&g_heff_2esyntax_2eformat_2epatKey_str93))));
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2epatKey(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str3, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str4, 8, "explicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str9, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str10, 8, "implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str11, 1, ")");
Clo g_heff_2esyntax_2eformat_2eparamKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2eparamKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2eparamKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_t_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_246}));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_248});
      V v_x2_2410 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2eparamKey_str0), v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str3), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str4), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2eformat_2eparamKey_str5))));
    }
    case TAG_ImplicitParam: {
      V v_x_2414 = heff_field(v_x21_242, 0);
      V v_t_2416 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2416}));
      V v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      V v_parts_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2414, v_t_2418});
      V v_x2_2420 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2eparamKey_str6), v_parts_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str8); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str9), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str10), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2eformat_2eparamKey_str11))));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2eparamKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2eparamKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str3, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str4, 5, "named");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str9, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str10, 8, "implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str15, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str16, 8, "implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str17, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str21, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str22, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str23, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str25, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str27, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str28, 4, "anon");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str29, 1, ")");
Clo g_heff_2esyntax_2eformat_2epiKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2epiKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2epiKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_244)}));
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_parts_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_242), v_t_246});
    V v_x2_248 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epiKey_str0), v_parts_247));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str2); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str3), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str4), heff_strAppend(v_t_2411, ((V)&g_heff_2esyntax_2eformat_2epiKey_str5))));
  }
  case TAG_PiImplicit: {
    V v_x_2412 = heff_field(v_x2_241, 0);
    V v_t_2415 = heff_field(v_x2_241, 3);
    V v_x25_2416 = heff_field(v_x2_241, 4);
    switch (heff_tag_of(v_x25_2416)) {
    case TAG_Nothing: {
      V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2415)}));
      V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      V v_parts_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2412), v_t_2418});
      V v_x2_2420 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epiKey_str6), v_parts_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str8); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str9), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str10), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2eformat_2epiKey_str11))));
    }
    case TAG_Just: {
      V v_d_2424 = heff_field(v_x25_2416, 0);
      V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){heff_dup(v_t_2415)}));
      V v_t_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_d_2424)}));
      V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
      V v_parts_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2412), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, v_t_2427})});
      V v_x2_2429 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epiKey_str12), v_parts_2428));
      V v_t_2432;
      switch (heff_tag_of(v_x2_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_x2_2429, 0);
        V v_xs_2431 = heff_field(v_x2_2429, 1);
        heff_take_n(v_x2_2429, 3ULL, 2);
        v_t_2432 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str14); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2429);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str15), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str16), heff_strAppend(v_t_2432, ((V)&g_heff_2esyntax_2eformat_2epiKey_str17))));
    }
    default: return heff_nomatch(v_x25_2416);
    }
  }
  case TAG_PiInstance: {
    V v_x_2433 = heff_field(v_x2_241, 0);
    V v_t_2436 = heff_field(v_x2_241, 3);
    V v_t_2437 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2436)}));
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
    V v_parts_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2433), v_t_2438});
    V v_x2_2440 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epiKey_str18), v_parts_2439));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str20); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str21), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str22), heff_strAppend(v_t_2443, ((V)&g_heff_2esyntax_2eformat_2epiKey_str23))));
  }
  case TAG_PiAnon: {
    V v_t_2444 = heff_field(v_x2_241, 0);
    V v_t_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2444)}));
    V v_parts_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
    V v_x2_2447 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epiKey_str24), v_parts_2446));
    V v_t_2450;
    switch (heff_tag_of(v_x2_2447)) {
    case TAG_Nil: {
      v_t_2450 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str25);
      break;
    }
    case TAG_Cons: {
      V v_x_2448 = heff_field(v_x2_2447, 0);
      V v_xs_2449 = heff_field(v_x2_2447, 1);
      heff_take_n(v_x2_2447, 3ULL, 2);
      v_t_2450 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str26); V a_1 = v_x_2448; V a_2 = v_xs_2449; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2449); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2447);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str27), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str28), heff_strAppend(v_t_2450, ((V)&g_heff_2esyntax_2eformat_2epiKey_str29))));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2epiKey_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2eformat_2epiKey(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str3, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str4, 4, "name");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str9, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str10, 8, "implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str15, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str16, 3, "ann");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str17, 1, ")");
Clo g_heff_2esyntax_2eformat_2elamKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2elamKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2elamKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_LamName: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24LamName = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    heff_drop_rec(v_r_240, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x2_241_24LamName, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
    V v_x2_245 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2elamKey_str0), v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str3), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str4), heff_strAppend(v_t_248, ((V)&g_heff_2esyntax_2eformat_2elamKey_str5))));
  }
  case TAG_LamImplicit: {
    V v_x_249 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24LamImplicit = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    heff_drop_rec(v_r_240, 2);
    V v_t_2411 = heff_tag_at_n(v_ru_24x2_241_24LamImplicit, TAG_Cons, 2, (V[]){v_x_249, NTAG(TAG_Nil)});
    V v_x2_2412 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2elamKey_str6), v_t_2411));
    V v_t_2415;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_xs_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      v_t_2415 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str8); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str9), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str10), heff_strAppend(v_t_2415, ((V)&g_heff_2esyntax_2eformat_2elamKey_str11))));
  }
  case TAG_LamAnn: {
    V v_x_2416 = heff_field(v_x2_241, 0);
    V v_t_2418 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2418}));
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
    V v_parts_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, v_t_2420});
    V v_x2_2422 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2elamKey_str12), v_parts_2421));
    V v_t_2425;
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      v_t_2425 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str13);
      break;
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      v_t_2425 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str14); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2422);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str15), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str16), heff_strAppend(v_t_2425, ((V)&g_heff_2esyntax_2eformat_2elamKey_str17))));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2elamKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2elamKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str3, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str4, 5, "field");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str9, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str10, 5, "field");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str15, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str16, 3, "bad");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str17, 1, ")");
Clo g_heff_2esyntax_2eformat_2efieldDeclKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2efieldDeclKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2efieldDeclKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_x214_247 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 13ULL, 4);
      switch (heff_tag_of(v_x214_247)) {
      case TAG_Nothing: {
        V v_t_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_246}));
        V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
        V v_parts_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_249});
        V v_x2_2411 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str0), v_parts_2410));
        V v_t_2414;
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_Nil: {
          v_t_2414 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_x2_2411, 0);
          V v_xs_2413 = heff_field(v_x2_2411, 1);
          heff_take_n(v_x2_2411, 3ULL, 2);
          v_t_2414 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str2); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2411);
        }
        return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str3), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str4), heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str5))));
      }
      case TAG_Just: {
        V v_d_2415 = heff_field(v_x214_247, 0);
        heff_take_n(v_x214_247, 1ULL, 1);
        V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_246}));
        V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_2415}));
        V v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
        V v_parts_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2418})});
        V v_x2_2420 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str6), v_parts_2419));
        V v_t_2423;
        switch (heff_tag_of(v_x2_2420)) {
        case TAG_Nil: {
          v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str7);
          break;
        }
        case TAG_Cons: {
          V v_x_2421 = heff_field(v_x2_2420, 0);
          V v_xs_2422 = heff_field(v_x2_2420, 1);
          heff_take_n(v_x2_2420, 3ULL, 2);
          v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str8); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2420);
        }
        return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str9), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str10), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str11))));
      }
      default: return heff_nomatch(v_x214_247);
      }
    }
    case TAG_BadFieldDecl: {
      V v_e_2424 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2425 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2424}));
      V v_parts_2426 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
      V v_x2_2427 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str12), v_parts_2426));
      V v_t_2430;
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nil: {
        v_t_2430 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2428 = heff_field(v_x2_2427, 0);
        V v_xs_2429 = heff_field(v_x2_2427, 1);
        heff_take_n(v_x2_2427, 3ULL, 2);
        v_t_2430 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str14); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2427);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str15), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str16), heff_strAppend(v_t_2430, ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str17))));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2efieldDeclKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2efieldDeclKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str1, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str2, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str3, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str7, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str8, 7, "variant");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str9, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str13, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str14, 3, "bad");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str15, 1, ")");
Clo g_heff_2esyntax_2eformat_2evariantKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2evariantKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2evariantKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_TagVariant: {
      V v_t_244 = heff_field(v_x21_242, 0);
      V v_args_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_x2_247 = (g_list_2emap(heff_get_n(v_r_240, 0, 2), v_args_246));
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str1); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2411 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2evariantKey_str2), heff_strAppend(v_t_2410, ((V)&g_heff_2esyntax_2eformat_2evariantKey_str3)));
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_parts_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2412});
      V v_x2_2414 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2evariantKey_str4), v_parts_2413));
      V v_t_2417;
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_Nil: {
        v_t_2417 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_xs_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str6); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2414);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2evariantKey_str7), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2evariantKey_str8), heff_strAppend(v_t_2417, ((V)&g_heff_2esyntax_2eformat_2evariantKey_str9))));
    }
    case TAG_BadVariant: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2418}));
      V v_parts_2420 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
      V v_x2_2421 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2evariantKey_str10), v_parts_2420));
      V v_t_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str12); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2evariantKey_str13), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2evariantKey_str14), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2eformat_2evariantKey_str15))));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2evariantKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2evariantKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str3, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str4, 3, "set");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str9, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str10, 3, "bad");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str11, 1, ")");
Clo g_heff_2esyntax_2eformat_2efieldSetKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2efieldSetKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2efieldSetKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_e_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_246}));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_248});
      V v_x2_2410 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str0), v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str3), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str4), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str5))));
    }
    case TAG_BadFieldSet: {
      V v_e_2414 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2414}));
      V v_parts_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
      V v_x2_2417 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str6), v_parts_2416));
      V v_t_2420;
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_Nil: {
        v_t_2420 = ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2418 = heff_field(v_x2_2417, 0);
        V v_xs_2419 = heff_field(v_x2_2417, 1);
        heff_take_n(v_x2_2417, 3ULL, 2);
        v_t_2420 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str8); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2417);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str9), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str10), heff_strAppend(v_t_2420, ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str11))));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2efieldSetKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2efieldSetKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str3, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str4, 3, "alt");
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str5, 1, ")");
Clo g_heff_2esyntax_2eformat_2ealtKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ealtKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ealtKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24MkAlt = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_246 = (g_heff_2esyntax_2eformat_2epatKey(v_p_244));
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_245}));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag_at_n(v_ru_24x21_242_24MkAlt, TAG_Cons, 2, (V[]){v_t_246, v_t_248});
      V v_x2_2410 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ealtKey_str0), v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2esyntax_2eformat_2ealtKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ealtKey_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ealtKey_str3), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ealtKey_str4), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2eformat_2ealtKey_str5))));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2ealtKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2ealtKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str3, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str4, 4, "bind");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str9, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str10, 3, "let");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str15, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str16, 4, "expr");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str17, 1, ")");
Clo g_heff_2esyntax_2eformat_2estmtKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2estmtKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2estmtKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_StmtBind: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_e_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_246}));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_248});
      V v_x2_2410 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2estmtKey_str0), v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str3), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str4), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2eformat_2estmtKey_str5))));
    }
    case TAG_StmtLet: {
      V v_p_2414 = heff_field(v_x21_242, 0);
      V v_e_2415 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24StmtLet = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2416 = (g_heff_2esyntax_2eformat_2epatKey(v_p_2414));
      V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2415}));
      V v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      V v_parts_2419 = heff_tag_at_n(v_ru_24x21_242_24StmtLet, TAG_Cons, 2, (V[]){v_t_2416, v_t_2418});
      V v_x2_2420 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2estmtKey_str6), v_parts_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str8); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str9), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str10), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2eformat_2estmtKey_str11))));
    }
    case TAG_StmtExpr: {
      V v_e_2424 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2425 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2424}));
      V v_parts_2426 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
      V v_x2_2427 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2estmtKey_str12), v_parts_2426));
      V v_t_2430;
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nil: {
        v_t_2430 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2428 = heff_field(v_x2_2427, 0);
        V v_xs_2429 = heff_field(v_x2_2427, 1);
        heff_take_n(v_x2_2427, 3ULL, 2);
        v_t_2430 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str14); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2427);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str15), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str16), heff_strAppend(v_t_2430, ((V)&g_heff_2esyntax_2eformat_2estmtKey_str17))));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2estmtKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2estmtKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str1, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str2, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str3, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str7, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str8, 8, "equation");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str9, 1, ")");
Clo g_heff_2esyntax_2eformat_2eequationKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2eequationKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2eequationKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkEquation: {
      V v_g_244 = heff_field(v_x21_242, 0);
      V v_ps_246 = heff_field(v_x21_242, 2);
      V v_rhs_247 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 13ULL, 4);
      V v_x2_248 = (g_list_2emap_24s1561756891x1126436879(v_ps_246));
      V v_t_2411;
      switch (heff_tag_of(v_x2_248)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_heff_2esyntax_2eformat_2eequationKey_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_x2_248, 0);
        V v_xs_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 3ULL, 2);
        v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eequationKey_str1); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
        break;
      }
      default: heff_nomatch(v_x2_248);
      }
      V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eequationKey_str2), heff_strAppend(v_t_2411, ((V)&g_heff_2esyntax_2eformat_2eequationKey_str3)));
      V v_t_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_rhs_247}));
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
      V v_parts_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_g_244, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2414})});
      V v_x2_2416 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2eequationKey_str4), v_parts_2415));
      V v_t_2419;
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2esyntax_2eformat_2eequationKey_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_xs_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        v_t_2419 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eequationKey_str6); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2416);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eequationKey_str7), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eequationKey_str8), heff_strAppend(v_t_2419, ((V)&g_heff_2esyntax_2eformat_2eequationKey_str9))));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2eequationKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2eequationKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str3, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str4, 3, "var");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str5, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str9, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str10, 8, "implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str15, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str16, 3, "tag");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str17, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str21, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str22, 3, "int");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str23, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str25, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str27, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str28, 5, "float");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str29, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str31, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str32, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str33, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str34, 6, "string");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str35, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str37, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str38, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str39, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str40, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str41, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str42, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str43, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str44, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str45, 6, "String");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str46, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str47, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str48, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str49, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str50, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str51, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str52, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str53, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str54, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str55, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str56, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str57, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str58, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str59, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str60, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str61, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str62, 4, "word");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str63, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str64, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str65, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str66, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str67, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str68, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str69, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str70, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str71, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str72, 3, "app");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str73, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str75, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str76, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str77, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str78, 7, "project");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str79, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str80, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str81, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str82, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str83, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str84, 5, "named");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str85, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str86, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str87, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str88, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str89, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str90, 2, "pi");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str91, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str93, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str94, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str95, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str96, 3, "lam");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str97, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str98, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str99, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str100, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str101, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str102, 3, "ann");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str103, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str104, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str105, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str106, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str107, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str108, 4, "spec");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str109, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str110, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str111, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str112, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str113, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str114, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str115, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str116, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str117, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str118, 3, "sig");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str119, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str120, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str121, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str122, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str123, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str124, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str125, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str126, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str127, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str128, 3, "sum");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str129, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str130, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str131, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str132, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str133, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str134, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str135, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str136, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str137, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str138, 6, "struct");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str139, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str140, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str141, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str142, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str143, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str144, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str145, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str146, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str147, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str148, 5, "match");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str149, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str150, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str151, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str152, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str153, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str154, 3, "let");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str155, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str156, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str157, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str158, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str159, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str160, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str161, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str162, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str163, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str164, 2, "do");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str165, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str166, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str167, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str168, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str169, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str170, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str171, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str172, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str173, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str174, 5, "local");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str175, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str176, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str177, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str178, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str179, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str180, 7, "invalid");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str181, 1, ")");
Clo g_heff_2esyntax_2eformat_2ekeyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeyTermF_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ekeyTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
      V v_x2_246 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str0), v_t_245));
      V v_t_249;
      switch (heff_tag_of(v_x2_246)) {
      case TAG_Nil: {
        v_t_249 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x2_246, 0);
        V v_xs_248 = heff_field(v_x2_246, 1);
        heff_take_n(v_x2_246, 3ULL, 2);
        v_t_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
        break;
      }
      default: heff_nomatch(v_x2_246);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str3), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str4), heff_strAppend(v_t_249, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str5))));
    }
    case TAG_EImplicitVar: {
      V v_x_2410 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2411 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2410, NTAG(TAG_Nil)});
      V v_x2_2412 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str6), v_t_2411));
      V v_t_2415;
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nil: {
        v_t_2415 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        V v_xs_2414 = heff_field(v_x2_2412, 1);
        heff_take_n(v_x2_2412, 3ULL, 2);
        v_t_2415 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str8); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2412);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str9), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str10), heff_strAppend(v_t_2415, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str11))));
    }
    case TAG_ETag: {
      V v_x_2416 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2416, NTAG(TAG_Nil)});
      V v_x2_2418 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str12), v_t_2417));
      V v_t_2421;
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_Nil: {
        v_t_2421 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2419 = heff_field(v_x2_2418, 0);
        V v_xs_2420 = heff_field(v_x2_2418, 1);
        heff_take_n(v_x2_2418, 3ULL, 2);
        v_t_2421 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str14); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2418);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str15), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str16), heff_strAppend(v_t_2421, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str17))));
    }
    case TAG_EInt: {
      V v_i_2422 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2423 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_intShow(v_i_2422), NTAG(TAG_Nil)});
      V v_x2_2424 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str18), v_t_2423));
      V v_t_2427;
      switch (heff_tag_of(v_x2_2424)) {
      case TAG_Nil: {
        v_t_2427 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str19);
        break;
      }
      case TAG_Cons: {
        V v_x_2425 = heff_field(v_x2_2424, 0);
        V v_xs_2426 = heff_field(v_x2_2424, 1);
        heff_take_n(v_x2_2424, 3ULL, 2);
        v_t_2427 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str20); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2424);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str21), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str22), heff_strAppend(v_t_2427, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str23))));
    }
    case TAG_EFloat: {
      V v_x_2428 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_floatShow(v_x_2428), NTAG(TAG_Nil)});
      V v_x2_2430 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str24), v_t_2429));
      V v_t_2433;
      switch (heff_tag_of(v_x2_2430)) {
      case TAG_Nil: {
        v_t_2433 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str25);
        break;
      }
      case TAG_Cons: {
        V v_x_2431 = heff_field(v_x2_2430, 0);
        V v_xs_2432 = heff_field(v_x2_2430, 1);
        heff_take_n(v_x2_2430, 3ULL, 2);
        v_t_2433 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str26); V a_1 = v_x_2431; V a_2 = v_xs_2432; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2432); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2430);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str27), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str28), heff_strAppend(v_t_2433, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str29))));
    }
    case TAG_EString: {
      V v_x_2434 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2435 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2434, NTAG(TAG_Nil)});
      V v_x2_2436 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str30), v_t_2435));
      V v_t_2439;
      switch (heff_tag_of(v_x2_2436)) {
      case TAG_Nil: {
        v_t_2439 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str31);
        break;
      }
      case TAG_Cons: {
        V v_x_2437 = heff_field(v_x2_2436, 0);
        V v_xs_2438 = heff_field(v_x2_2436, 1);
        heff_take_n(v_x2_2436, 3ULL, 2);
        v_t_2439 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str32); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2436);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str33), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str34), heff_strAppend(v_t_2439, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str35))));
    }
    case TAG_ERune: {
      V v_c_2440 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2441 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_intShow(v_c_2440), NTAG(TAG_Nil)});
      V v_x2_2442 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str36), v_t_2441));
      V v_t_2445;
      switch (heff_tag_of(v_x2_2442)) {
      case TAG_Nil: {
        v_t_2445 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str37);
        break;
      }
      case TAG_Cons: {
        V v_x_2443 = heff_field(v_x2_2442, 0);
        V v_xs_2444 = heff_field(v_x2_2442, 1);
        heff_take_n(v_x2_2442, 3ULL, 2);
        v_t_2445 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str38); V a_1 = v_x_2443; V a_2 = v_xs_2444; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2444); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2442);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str39), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str40), heff_strAppend(v_t_2445, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str41))));
    }
    case TAG_EWord: {
      V v_w_2446 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2448;
      switch (heff_tag_of(v_w_2446)) {
      case TAG_TypeWord: {
        v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str42);
        break;
      }
      case TAG_IntWord: {
        v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str43);
        break;
      }
      case TAG_FloatWord: {
        v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str44);
        break;
      }
      case TAG_StringWord: {
        v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str45);
        break;
      }
      case TAG_RuneWord: {
        v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str46);
        break;
      }
      case TAG_ArrayWord: {
        v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str47);
        break;
      }
      case TAG_AbandonWord: {
        v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str48);
        break;
      }
      case TAG_FixedWord: {
        V v_w_2447 = heff_field(v_w_2446, 0);
        heff_take_n(v_w_2446, 1ULL, 1);
        switch (heff_tag_of(v_w_2447)) {
        case TAG_I8: {
          v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str49);
          break;
        }
        case TAG_I16: {
          v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str50);
          break;
        }
        case TAG_I32: {
          v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str51);
          break;
        }
        case TAG_I64: {
          v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str52);
          break;
        }
        case TAG_U8: {
          v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str53);
          break;
        }
        case TAG_U16: {
          v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str54);
          break;
        }
        case TAG_U32: {
          v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str55);
          break;
        }
        case TAG_U64: {
          v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str56);
          break;
        }
        case TAG_F32: {
          v_t_2448 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str57);
          break;
        }
        default: heff_nomatch(v_w_2447);
        }
        break;
      }
      default: heff_nomatch(v_w_2446);
      }
      V v_parts_2449 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2448, NTAG(TAG_Nil)});
      V v_x2_2450 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str58), v_parts_2449));
      V v_t_2453;
      switch (heff_tag_of(v_x2_2450)) {
      case TAG_Nil: {
        v_t_2453 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str59);
        break;
      }
      case TAG_Cons: {
        V v_x_2451 = heff_field(v_x2_2450, 0);
        V v_xs_2452 = heff_field(v_x2_2450, 1);
        heff_take_n(v_x2_2450, 3ULL, 2);
        v_t_2453 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str60); V a_1 = v_x_2451; V a_2 = v_xs_2452; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2452); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2450);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str61), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str62), heff_strAppend(v_t_2453, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str63))));
    }
    case TAG_EApp: {
      V v_h_2454 = heff_field(v_x21_242, 0);
      V v_args_2455 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2456 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_2454}));
      V v_x2_2457 = (g_list_2emap(heff_get_n(v_r_240, 0, 2), v_args_2455));
      V v_t_2460;
      switch (heff_tag_of(v_x2_2457)) {
      case TAG_Nil: {
        v_t_2460 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str64);
        break;
      }
      case TAG_Cons: {
        V v_x_2458 = heff_field(v_x2_2457, 0);
        V v_xs_2459 = heff_field(v_x2_2457, 1);
        heff_take_n(v_x2_2457, 3ULL, 2);
        v_t_2460 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str65); V a_1 = v_x_2458; V a_2 = v_xs_2459; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2459); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2457);
      }
      V v_t_2461 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str66), heff_strAppend(v_t_2460, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str67)));
      V v_t_2462 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
      V v_parts_2463 = heff_tag_at_n(v_ru_24x21_242_24EApp, TAG_Cons, 2, (V[]){v_t_2456, v_t_2462});
      V v_x2_2464 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str68), v_parts_2463));
      V v_t_2467;
      switch (heff_tag_of(v_x2_2464)) {
      case TAG_Nil: {
        v_t_2467 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str69);
        break;
      }
      case TAG_Cons: {
        V v_x_2465 = heff_field(v_x2_2464, 0);
        V v_xs_2466 = heff_field(v_x2_2464, 1);
        heff_take_n(v_x2_2464, 3ULL, 2);
        v_t_2467 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str70); V a_1 = v_x_2465; V a_2 = v_xs_2466; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2466); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2464);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str71), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str72), heff_strAppend(v_t_2467, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str73))));
    }
    case TAG_EProject: {
      V v_x_2468 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2469 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2468, NTAG(TAG_Nil)});
      V v_x2_2470 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str74), v_t_2469));
      V v_t_2473;
      switch (heff_tag_of(v_x2_2470)) {
      case TAG_Nil: {
        v_t_2473 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str75);
        break;
      }
      case TAG_Cons: {
        V v_x_2471 = heff_field(v_x2_2470, 0);
        V v_xs_2472 = heff_field(v_x2_2470, 1);
        heff_take_n(v_x2_2470, 3ULL, 2);
        v_t_2473 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str76); V a_1 = v_x_2471; V a_2 = v_xs_2472; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2472); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2470);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str77), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str78), heff_strAppend(v_t_2473, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str79))));
    }
    case TAG_ENamed: {
      V v_x_2474 = heff_field(v_x21_242, 0);
      V v_e_2475 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ENamed = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2476 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2475}));
      V v_t_2477 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2476, NTAG(TAG_Nil)});
      V v_parts_2478 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_Cons, 2, (V[]){v_x_2474, v_t_2477});
      V v_x2_2479 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str80), v_parts_2478));
      V v_t_2482;
      switch (heff_tag_of(v_x2_2479)) {
      case TAG_Nil: {
        v_t_2482 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str81);
        break;
      }
      case TAG_Cons: {
        V v_x_2480 = heff_field(v_x2_2479, 0);
        V v_xs_2481 = heff_field(v_x2_2479, 1);
        heff_take_n(v_x2_2479, 3ULL, 2);
        v_t_2482 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str82); V a_1 = v_x_2480; V a_2 = v_xs_2481; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2481); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2479);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str83), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str84), heff_strAppend(v_t_2482, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str85))));
    }
    case TAG_EPi: {
      V v_b_2483 = heff_field(v_x21_242, 0);
      V v_cod_2484 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2485 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_b_2483; V r_ = (g_heff_2esyntax_2eformat_2epiKey(a_0, a_1)); heff_drop(v_b_2483); r_; });
      V v_t_2486 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_cod_2484}));
      V v_t_2487 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2486, NTAG(TAG_Nil)});
      V v_parts_2488 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_Cons, 2, (V[]){v_t_2485, v_t_2487});
      V v_x2_2489 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str86), v_parts_2488));
      V v_t_2492;
      switch (heff_tag_of(v_x2_2489)) {
      case TAG_Nil: {
        v_t_2492 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str87);
        break;
      }
      case TAG_Cons: {
        V v_x_2490 = heff_field(v_x2_2489, 0);
        V v_xs_2491 = heff_field(v_x2_2489, 1);
        heff_take_n(v_x2_2489, 3ULL, 2);
        v_t_2492 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str88); V a_1 = v_x_2490; V a_2 = v_xs_2491; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2491); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2489);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str89), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str90), heff_strAppend(v_t_2492, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str91))));
    }
    case TAG_ELam: {
      V v_b_2493 = heff_field(v_x21_242, 0);
      V v_body_2494 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2495 = (g_heff_2esyntax_2eformat_2elamKey(heff_dup(v_r_240), v_b_2493));
      V v_t_2496 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2494}));
      V v_t_2497 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2496, NTAG(TAG_Nil)});
      V v_parts_2498 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_Cons, 2, (V[]){v_t_2495, v_t_2497});
      V v_x2_2499 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str92), v_parts_2498));
      V v_t_24102;
      switch (heff_tag_of(v_x2_2499)) {
      case TAG_Nil: {
        v_t_24102 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str93);
        break;
      }
      case TAG_Cons: {
        V v_x_24100 = heff_field(v_x2_2499, 0);
        V v_xs_24101 = heff_field(v_x2_2499, 1);
        heff_take_n(v_x2_2499, 3ULL, 2);
        v_t_24102 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str94); V a_1 = v_x_24100; V a_2 = v_xs_24101; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24101); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2499);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str95), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str96), heff_strAppend(v_t_24102, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str97))));
    }
    case TAG_EAnn: {
      V v_e_24103 = heff_field(v_x21_242, 0);
      V v_t_24104 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24105 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24103}));
      V v_t_24106 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_24104}));
      V v_t_24107 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24106, NTAG(TAG_Nil)});
      V v_parts_24108 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_Cons, 2, (V[]){v_t_24105, v_t_24107});
      V v_x2_24109 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str98), v_parts_24108));
      V v_t_24112;
      switch (heff_tag_of(v_x2_24109)) {
      case TAG_Nil: {
        v_t_24112 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str99);
        break;
      }
      case TAG_Cons: {
        V v_x_24110 = heff_field(v_x2_24109, 0);
        V v_xs_24111 = heff_field(v_x2_24109, 1);
        heff_take_n(v_x2_24109, 3ULL, 2);
        v_t_24112 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str100); V a_1 = v_x_24110; V a_2 = v_xs_24111; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24111); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24109);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str101), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str102), heff_strAppend(v_t_24112, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str103))));
    }
    case TAG_ESpec: {
      V v_acc_24113 = heff_field(v_x21_242, 0);
      V v_x_24114 = heff_field(v_x21_242, 1);
      V v_v_24116 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 11ULL, 4);
      V v_t_24117 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_acc_24113}));
      V v_t_24118 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_24116}));
      V v_t_24119 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24118, NTAG(TAG_Nil)});
      V v_parts_24120 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, heff_tag_n(TAG_Cons, 2, (V[]){v_x_24114, v_t_24119})});
      V v_x2_24121 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str104), v_parts_24120));
      V v_t_24124;
      switch (heff_tag_of(v_x2_24121)) {
      case TAG_Nil: {
        v_t_24124 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str105);
        break;
      }
      case TAG_Cons: {
        V v_x_24122 = heff_field(v_x2_24121, 0);
        V v_xs_24123 = heff_field(v_x2_24121, 1);
        heff_take_n(v_x2_24121, 3ULL, 2);
        v_t_24124 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str106); V a_1 = v_x_24122; V a_2 = v_xs_24123; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24123); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24121);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str107), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str108), heff_strAppend(v_t_24124, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str109))));
    }
    case TAG_ESig: {
      V v_fs_24125 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24126 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24127 = (g_list_2emap(v_t_24126, v_fs_24125));
      V v_t_24130;
      switch (heff_tag_of(v_x2_24127)) {
      case TAG_Nil: {
        v_t_24130 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str110);
        break;
      }
      case TAG_Cons: {
        V v_x_24128 = heff_field(v_x2_24127, 0);
        V v_xs_24129 = heff_field(v_x2_24127, 1);
        heff_take_n(v_x2_24127, 3ULL, 2);
        v_t_24130 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str111); V a_1 = v_x_24128; V a_2 = v_xs_24129; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24129); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24127);
      }
      V v_t_24131 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str112), heff_strAppend(v_t_24130, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str113)));
      V v_parts_24132 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24131, NTAG(TAG_Nil)});
      V v_x2_24133 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str114), v_parts_24132));
      V v_t_24136;
      switch (heff_tag_of(v_x2_24133)) {
      case TAG_Nil: {
        v_t_24136 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str115);
        break;
      }
      case TAG_Cons: {
        V v_x_24134 = heff_field(v_x2_24133, 0);
        V v_xs_24135 = heff_field(v_x2_24133, 1);
        heff_take_n(v_x2_24133, 3ULL, 2);
        v_t_24136 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str116); V a_1 = v_x_24134; V a_2 = v_xs_24135; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24135); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24133);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str117), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str118), heff_strAppend(v_t_24136, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str119))));
    }
    case TAG_ESum: {
      V v_vs_24137 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24138 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2evariantKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24139 = (g_list_2emap(v_t_24138, v_vs_24137));
      V v_t_24142;
      switch (heff_tag_of(v_x2_24139)) {
      case TAG_Nil: {
        v_t_24142 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str120);
        break;
      }
      case TAG_Cons: {
        V v_x_24140 = heff_field(v_x2_24139, 0);
        V v_xs_24141 = heff_field(v_x2_24139, 1);
        heff_take_n(v_x2_24139, 3ULL, 2);
        v_t_24142 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str121); V a_1 = v_x_24140; V a_2 = v_xs_24141; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24141); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24139);
      }
      V v_t_24143 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str122), heff_strAppend(v_t_24142, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str123)));
      V v_parts_24144 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24143, NTAG(TAG_Nil)});
      V v_x2_24145 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str124), v_parts_24144));
      V v_t_24148;
      switch (heff_tag_of(v_x2_24145)) {
      case TAG_Nil: {
        v_t_24148 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str125);
        break;
      }
      case TAG_Cons: {
        V v_x_24146 = heff_field(v_x2_24145, 0);
        V v_xs_24147 = heff_field(v_x2_24145, 1);
        heff_take_n(v_x2_24145, 3ULL, 2);
        v_t_24148 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str126); V a_1 = v_x_24146; V a_2 = v_xs_24147; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24147); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24145);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str127), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str128), heff_strAppend(v_t_24148, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str129))));
    }
    case TAG_EStruct: {
      V v_fs_24149 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24150 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24151 = (g_list_2emap(v_t_24150, v_fs_24149));
      V v_t_24154;
      switch (heff_tag_of(v_x2_24151)) {
      case TAG_Nil: {
        v_t_24154 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str130);
        break;
      }
      case TAG_Cons: {
        V v_x_24152 = heff_field(v_x2_24151, 0);
        V v_xs_24153 = heff_field(v_x2_24151, 1);
        heff_take_n(v_x2_24151, 3ULL, 2);
        v_t_24154 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str131); V a_1 = v_x_24152; V a_2 = v_xs_24153; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24153); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24151);
      }
      V v_t_24155 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str132), heff_strAppend(v_t_24154, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str133)));
      V v_parts_24156 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24155, NTAG(TAG_Nil)});
      V v_x2_24157 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str134), v_parts_24156));
      V v_t_24160;
      switch (heff_tag_of(v_x2_24157)) {
      case TAG_Nil: {
        v_t_24160 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str135);
        break;
      }
      case TAG_Cons: {
        V v_x_24158 = heff_field(v_x2_24157, 0);
        V v_xs_24159 = heff_field(v_x2_24157, 1);
        heff_take_n(v_x2_24157, 3ULL, 2);
        v_t_24160 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str136); V a_1 = v_x_24158; V a_2 = v_xs_24159; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24159); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24157);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str137), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str138), heff_strAppend(v_t_24160, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str139))));
    }
    case TAG_EMatch: {
      V v_s_24161 = heff_field(v_x21_242, 0);
      V v_alts_24162 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EMatch = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24163 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24161}));
      V v_t_24164 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2ealtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24165 = (g_list_2emap(v_t_24164, v_alts_24162));
      V v_t_24168;
      switch (heff_tag_of(v_x2_24165)) {
      case TAG_Nil: {
        v_t_24168 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str140);
        break;
      }
      case TAG_Cons: {
        V v_x_24166 = heff_field(v_x2_24165, 0);
        V v_xs_24167 = heff_field(v_x2_24165, 1);
        heff_take_n(v_x2_24165, 3ULL, 2);
        v_t_24168 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str141); V a_1 = v_x_24166; V a_2 = v_xs_24167; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24167); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24165);
      }
      V v_t_24169 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str142), heff_strAppend(v_t_24168, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str143)));
      V v_t_24170 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24169, NTAG(TAG_Nil)});
      V v_parts_24171 = heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_Cons, 2, (V[]){v_t_24163, v_t_24170});
      V v_x2_24172 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str144), v_parts_24171));
      V v_t_24175;
      switch (heff_tag_of(v_x2_24172)) {
      case TAG_Nil: {
        v_t_24175 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str145);
        break;
      }
      case TAG_Cons: {
        V v_x_24173 = heff_field(v_x2_24172, 0);
        V v_xs_24174 = heff_field(v_x2_24172, 1);
        heff_take_n(v_x2_24172, 3ULL, 2);
        v_t_24175 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str146); V a_1 = v_x_24173; V a_2 = v_xs_24174; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24174); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24172);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str147), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str148), heff_strAppend(v_t_24175, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str149))));
    }
    case TAG_ELetIn: {
      V v_rhs_24176 = heff_field(v_x21_242, 0);
      V v_x212_24177 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x212_24177)) {
      case TAG_At: {
        V v_x2121_24178 = heff_field(v_x212_24177, 0);
        heff_take_n(v_x212_24177, 1ULL, 2);
        switch (heff_tag_of(v_x2121_24178)) {
        case TAG_MkAlt: {
          V v_p_24180 = heff_field(v_x2121_24178, 0);
          V v_e_24181 = heff_field(v_x2121_24178, 1);
          heff_take_n(v_x2121_24178, 3ULL, 2);
          V v_t_24182 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_24176}));
          V v_t_24183 = (g_heff_2esyntax_2eformat_2epatKey(v_p_24180));
          V v_t_24184 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24181}));
          V v_t_24185 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24184, NTAG(TAG_Nil)});
          V v_parts_24186 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_Cons, 2, (V[]){v_t_24182, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24183, v_t_24185})});
          V v_x2_24187 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str150), v_parts_24186));
          V v_t_24190;
          switch (heff_tag_of(v_x2_24187)) {
          case TAG_Nil: {
            v_t_24190 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str151);
            break;
          }
          case TAG_Cons: {
            V v_x_24188 = heff_field(v_x2_24187, 0);
            V v_xs_24189 = heff_field(v_x2_24187, 1);
            heff_take_n(v_x2_24187, 3ULL, 2);
            v_t_24190 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str152); V a_1 = v_x_24188; V a_2 = v_xs_24189; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24189); r_; });
            break;
          }
          default: heff_nomatch(v_x2_24187);
          }
          return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str153), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str154), heff_strAppend(v_t_24190, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str155))));
        }
        default: return heff_nomatch(v_x2121_24178);
        }
      }
      default: return heff_nomatch(v_x212_24177);
      }
    }
    case TAG_EDo: {
      V v_stmts_24191 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24192 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24193 = (g_list_2emap(v_t_24192, v_stmts_24191));
      V v_t_24196;
      switch (heff_tag_of(v_x2_24193)) {
      case TAG_Nil: {
        v_t_24196 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str156);
        break;
      }
      case TAG_Cons: {
        V v_x_24194 = heff_field(v_x2_24193, 0);
        V v_xs_24195 = heff_field(v_x2_24193, 1);
        heff_take_n(v_x2_24193, 3ULL, 2);
        v_t_24196 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str157); V a_1 = v_x_24194; V a_2 = v_xs_24195; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24195); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24193);
      }
      V v_t_24197 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str158), heff_strAppend(v_t_24196, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str159)));
      V v_parts_24198 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24197, NTAG(TAG_Nil)});
      V v_x2_24199 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str160), v_parts_24198));
      V v_t_24202;
      switch (heff_tag_of(v_x2_24199)) {
      case TAG_Nil: {
        v_t_24202 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str161);
        break;
      }
      case TAG_Cons: {
        V v_x_24200 = heff_field(v_x2_24199, 0);
        V v_xs_24201 = heff_field(v_x2_24199, 1);
        heff_take_n(v_x2_24199, 3ULL, 2);
        v_t_24202 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str162); V a_1 = v_x_24200; V a_2 = v_xs_24201; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24201); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24199);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str163), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str164), heff_strAppend(v_t_24202, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str165))));
    }
    case TAG_ELocal: {
      V v_body_24203 = heff_field(v_x21_242, 0);
      V v_ds_24204 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24205 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 1, (V[]){v_body_24203}));
      V v_x2_24206 = (g_list_2emap(heff_get_n(v_r_240, 1, 2), v_ds_24204));
      V v_t_24209;
      switch (heff_tag_of(v_x2_24206)) {
      case TAG_Nil: {
        v_t_24209 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str166);
        break;
      }
      case TAG_Cons: {
        V v_x_24207 = heff_field(v_x2_24206, 0);
        V v_xs_24208 = heff_field(v_x2_24206, 1);
        heff_take_n(v_x2_24206, 3ULL, 2);
        v_t_24209 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str167); V a_1 = v_x_24207; V a_2 = v_xs_24208; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24208); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24206);
      }
      V v_t_24210 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str168), heff_strAppend(v_t_24209, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str169)));
      V v_t_24211 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24210, NTAG(TAG_Nil)});
      V v_parts_24212 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_Cons, 2, (V[]){v_t_24205, v_t_24211});
      V v_x2_24213 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str170), v_parts_24212));
      V v_t_24216;
      switch (heff_tag_of(v_x2_24213)) {
      case TAG_Nil: {
        v_t_24216 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str171);
        break;
      }
      case TAG_Cons: {
        V v_x_24214 = heff_field(v_x2_24213, 0);
        V v_xs_24215 = heff_field(v_x2_24213, 1);
        heff_take_n(v_x2_24213, 3ULL, 2);
        v_t_24216 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str172); V a_1 = v_x_24214; V a_2 = v_xs_24215; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24215); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24213);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str173), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str174), heff_strAppend(v_t_24216, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str175))));
    }
    case TAG_EInvalid: {
      V v_why_24217 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24218 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_why_24217, NTAG(TAG_Nil)});
      V v_x2_24219 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str176), v_t_24218));
      V v_t_24222;
      switch (heff_tag_of(v_x2_24219)) {
      case TAG_Nil: {
        v_t_24222 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str177);
        break;
      }
      case TAG_Cons: {
        V v_x_24220 = heff_field(v_x2_24219, 0);
        V v_xs_24221 = heff_field(v_x2_24219, 1);
        heff_take_n(v_x2_24219, 3ULL, 2);
        v_t_24222 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str178); V a_1 = v_x_24220; V a_2 = v_xs_24221; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24221); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24219);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str179), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str180), heff_strAppend(v_t_24222, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str181))));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2ekeyTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2ekeyTermF(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str0, 10, "definition");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str1, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str3, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str4, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str5, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str9, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str10, 9, "equations");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str13, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str14, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str15, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str18, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str19, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str20, 6, "define");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str21, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str22, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str23, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str24, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str25, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str27, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str28, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str29, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str30, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str31, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str33, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str34, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str35, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str36, 9, "primitive");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str37, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str39, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str40, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str41, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str42, 4, "test");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str43, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str45, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str46, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str47, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str48, 5, "watch");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str49, 1, ")");
Clo g_heff_2esyntax_2eformat_2ekeyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeyDeclF_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ekeyDeclF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_declared_246 = heff_field(v_x21_242, 2);
      V v_ty_247 = heff_field(v_x21_242, 3);
      V v_eqs_248 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 29ULL, 5);
      V v_t_249;
      switch (heff_tag_of(v_declared_246)) {
      case TAG_AsDefinition: {
        v_t_249 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str0);
        break;
      }
      case TAG_AsInstance: {
        v_t_249 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str1);
        break;
      }
      default: heff_nomatch(v_declared_246);
      }
      V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_247}));
      V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2eequationKey_clo), 1, (V[]){v_r_240}));
      V v_x2_2412 = (g_list_2emap(v_t_2411, v_eqs_248));
      V v_t_2415;
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nil: {
        v_t_2415 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        V v_xs_2414 = heff_field(v_x2_2412, 1);
        heff_take_n(v_x2_2412, 3ULL, 2);
        v_t_2415 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str3); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2412);
      }
      V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str4), heff_strAppend(v_t_2415, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str5)));
      V v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2417})});
      V v_parts_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_244, v_t_2418});
      V v_x2_2420 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str6), v_parts_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str8); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str9), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str10), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str11))));
    }
    case TAG_DeclDefine: {
      V v_x_2424 = heff_field(v_x21_242, 0);
      V v_ps_2426 = heff_field(v_x21_242, 2);
      V v_u_2427 = heff_field(v_x21_242, 3);
      V v_body_2428 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 29ULL, 5);
      V v_t_2429 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2eparamKey_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_x2_2430 = (g_list_2emap(v_t_2429, v_ps_2426));
      V v_t_2433;
      switch (heff_tag_of(v_x2_2430)) {
      case TAG_Nil: {
        v_t_2433 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2431 = heff_field(v_x2_2430, 0);
        V v_xs_2432 = heff_field(v_x2_2430, 1);
        heff_take_n(v_x2_2430, 3ULL, 2);
        v_t_2433 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str13); V a_1 = v_x_2431; V a_2 = v_xs_2432; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2432); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2430);
      }
      V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str14), heff_strAppend(v_t_2433, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str15)));
      V v_t_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_u_2427}));
      V v_t_2436 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2428}));
      V v_t_2437 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
      V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_t_2437})});
      V v_parts_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2424, v_t_2438});
      V v_x2_2440 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str16), v_parts_2439));
      V v_t_2443;
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_Nil: {
        v_t_2443 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str17);
        break;
      }
      case TAG_Cons: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_xs_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        v_t_2443 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str18); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2440);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str19), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str20), heff_strAppend(v_t_2443, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str21))));
    }
    case TAG_DeclTheory: {
      V v_x_2444 = heff_field(v_x21_242, 0);
      V v_ps_2446 = heff_field(v_x21_242, 2);
      V v_body_2447 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 13ULL, 4);
      V v_t_2448 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2eparamKey_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_x2_2449 = (g_list_2emap(v_t_2448, v_ps_2446));
      V v_t_2452;
      switch (heff_tag_of(v_x2_2449)) {
      case TAG_Nil: {
        v_t_2452 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str22);
        break;
      }
      case TAG_Cons: {
        V v_x_2450 = heff_field(v_x2_2449, 0);
        V v_xs_2451 = heff_field(v_x2_2449, 1);
        heff_take_n(v_x2_2449, 3ULL, 2);
        v_t_2452 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str23); V a_1 = v_x_2450; V a_2 = v_xs_2451; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2451); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2449);
      }
      V v_t_2453 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str24), heff_strAppend(v_t_2452, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str25)));
      V v_t_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2447}));
      V v_t_2455 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2454, NTAG(TAG_Nil)});
      V v_parts_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2444, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, v_t_2455})});
      V v_x2_2457 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str26), v_parts_2456));
      V v_t_2460;
      switch (heff_tag_of(v_x2_2457)) {
      case TAG_Nil: {
        v_t_2460 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str27);
        break;
      }
      case TAG_Cons: {
        V v_x_2458 = heff_field(v_x2_2457, 0);
        V v_xs_2459 = heff_field(v_x2_2457, 1);
        heff_take_n(v_x2_2457, 3ULL, 2);
        v_t_2460 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str28); V a_1 = v_x_2458; V a_2 = v_xs_2459; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2459); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2457);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str29), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str30), heff_strAppend(v_t_2460, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str31))));
    }
    case TAG_DeclPrimitive: {
      V v_x_2461 = heff_field(v_x21_242, 0);
      V v_t_2463 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2463}));
      V v_t_2465 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
      V v_parts_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2461, v_t_2465});
      V v_x2_2467 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str32), v_parts_2466));
      V v_t_2470;
      switch (heff_tag_of(v_x2_2467)) {
      case TAG_Nil: {
        v_t_2470 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str33);
        break;
      }
      case TAG_Cons: {
        V v_x_2468 = heff_field(v_x2_2467, 0);
        V v_xs_2469 = heff_field(v_x2_2467, 1);
        heff_take_n(v_x2_2467, 3ULL, 2);
        v_t_2470 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str34); V a_1 = v_x_2468; V a_2 = v_xs_2469; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2469); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2467);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str35), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str36), heff_strAppend(v_t_2470, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str37))));
    }
    case TAG_DeclTest: {
      V v_x_2471 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_2473 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2471, NTAG(TAG_Nil)});
      V v_x2_2474 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str38), v_t_2473));
      V v_t_2477;
      switch (heff_tag_of(v_x2_2474)) {
      case TAG_Nil: {
        v_t_2477 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str39);
        break;
      }
      case TAG_Cons: {
        V v_x_2475 = heff_field(v_x2_2474, 0);
        V v_xs_2476 = heff_field(v_x2_2474, 1);
        heff_take_n(v_x2_2474, 3ULL, 2);
        v_t_2477 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str40); V a_1 = v_x_2475; V a_2 = v_xs_2476; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2476); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2474);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str41), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str42), heff_strAppend(v_t_2477, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str43))));
    }
    case TAG_DeclWatch: {
      V v_e_2478 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2479 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2478}));
      V v_parts_2480 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2479, NTAG(TAG_Nil)});
      V v_x2_2481 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str44), v_parts_2480));
      V v_t_2484;
      switch (heff_tag_of(v_x2_2481)) {
      case TAG_Nil: {
        v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str45);
        break;
      }
      case TAG_Cons: {
        V v_x_2482 = heff_field(v_x2_2481, 0);
        V v_xs_2483 = heff_field(v_x2_2481, 1);
        heff_take_n(v_x2_2481, 3ULL, 2);
        v_t_2484 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str46); V a_1 = v_x_2482; V a_2 = v_xs_2483; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2483); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2481);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str47), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str48), heff_strAppend(v_t_2484, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str49))));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2ekeyDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2ekeyDeclF(a[0], a[1]);
}
V g_heff_2esyntax_2eformat_2ekeys_lam0(V self, V *args); static Clo g_heff_2esyntax_2eformat_2ekeys_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeys_lam0, 1, 0};
V g_heff_2esyntax_2eformat_2ekeys_lam1(V self, V *args); static Clo g_heff_2esyntax_2eformat_2ekeys_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeys_lam1, 1, 0};

static V g_heff_2esyntax_2eformat_2ekeys_val;
static HEFF_ONCE g_heff_2esyntax_2eformat_2ekeys_st;
static V g_heff_2esyntax_2eformat_2ekeys_init(void) {
  return heff_rec_n(2, shape_e__decl, (V[]){((V)&g_heff_2esyntax_2eformat_2ekeys_lam0_clo), ((V)&g_heff_2esyntax_2eformat_2ekeys_lam1_clo)});
}
V g_heff_2esyntax_2eformat_2ekeys_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2eformat_2ekeys_st)) return g_heff_2esyntax_2eformat_2ekeys_val;
  return heff_global(&g_heff_2esyntax_2eformat_2ekeys_val, &g_heff_2esyntax_2eformat_2ekeys_st, g_heff_2esyntax_2eformat_2ekeys_init);
}
V g_heff_2esyntax_2eformat_2ekeys_lam0(V self, V *args) {
  V v_n_240 = args[0];
  return (g_heff_2esyntax_2eformat_2ekeyTermF(heff_dup(g_heff_2esyntax_2eformat_2ekeys_get()), v_n_240));
}
V g_heff_2esyntax_2eformat_2ekeys_lam1(V self, V *args) {
  V v_d_241 = args[0];
  return (g_heff_2esyntax_2eformat_2ekeyDeclF(heff_dup(g_heff_2esyntax_2eformat_2ekeys_get()), v_d_241));
}
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaningFrom_str0, 0, "");
Clo g_heff_2esyntax_2eformat_2emeaningFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2emeaningFrom_entry, 1, 0};

V g_heff_2esyntax_2eformat_2emeaningFrom(V v_h_240) {
top: ;
  V v_text_241 = heff_take_field(v_h_240, 2);
  V v_t_242 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_243 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(v_text_241), v_t_242, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_r_244 = (g_heff_2esyntax_2esurface_2ereadLexed_24s1088510898x79166857(((V)&g_heff_2esyntax_2eformat_2emeaningFrom_str0), v_text_241, v_t_243));
  V v_t_245 = (g_list_2emap_24s424270175x1918189508(heff_get_n(v_h_240, 0, 3)));
  V v_t_246 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2esyntax_2eformat_2ekeys_get(), 1)), heff_take_field(v_r_244, 0)));
  V v_t_247 = (g_list_2emap_24s1602529591x1809288035(heff_get_n(v_r_244, 1, 4)));
  return heff_rec_n(3, shape_imports__decls__diags, (V[]){v_t_245, v_t_246, v_t_247});
}
V g_heff_2esyntax_2eformat_2emeaningFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2emeaningFrom(a[0]);
}
Clo g_heff_2esyntax_2eformat_2estrsEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2estrsEq_entry, 2, 0};

V g_heff_2esyntax_2eformat_2estrsEq(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c(heff_dup(v_a_244), heff_dup(v_b_246))) {
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2eformat_2estrsEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2eformat_2estrsEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2eformat_2esameMeaning_str0, 35, "formatting would change the imports");
HEFF_LIT(g_heff_2esyntax_2eformat_2esameMeaning_str1, 68, "formatting would change what the file means (a bug of the formatter)");
HEFF_LIT(g_heff_2esyntax_2eformat_2esameMeaning_str2, 76, "formatting would lose or move a comment across code (a bug of the formatter)");
Clo g_heff_2esyntax_2eformat_2esameMeaning_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2esameMeaning_entry, 4, 0};

V g_heff_2esyntax_2eformat_2esameMeaning(V v_src_240, V v_out_241, V v_a_242, V v_b_243) {
top: ;
  V v_x1_244 = (g_heff_2esyntax_2eformat_2estrsEq(heff_rfield(v_a_242, 0), heff_rfield(v_b_243, 0)));
  V v_t_245;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_True: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_src_240);
    heff_drop(v_out_241);
    heff_drop_rec(v_a_242, 3);
    heff_drop_rec(v_b_243, 3);
    return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2esyntax_2eformat_2esameMeaning_str0)});
  }
  case TAG_False: {
    V v_t_246 = (g_heff_2esyntax_2eformat_2estrsEq(heff_rfield(v_a_242, 1), heff_rfield(v_b_243, 1)));
    V v_x1_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      v_x1_247 = ({ V b_0 = heff_get_n(v_a_242, 2, 3); V b_1 = heff_get_n(v_b_243, 2, 3); V r_ = (g_heff_2esyntax_2eformat_2estrsEq(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
      break;
    }
    case TAG_False: {
      heff_drop_rec(v_a_242, 3);
      heff_drop_rec(v_b_243, 3);
      v_x1_247 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_248;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_True: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_248 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_src_240);
      heff_drop(v_out_241);
      return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2esyntax_2eformat_2esameMeaning_str1)});
    }
    case TAG_False: {
      V v_t_249 = (g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_src_2410 = heff_get_n(v_t_249, 2, 3);
      V v_t_2411 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      V v_t_2412 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_src_2410, v_t_2411, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2413 = (g_list_2emap_24s953916415x1126219438(MK_INT(0LL), heff_get_n(v_t_2412, 2, 3)));
      V v_t_2414 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_out_241), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_src_2415 = heff_get_n(v_t_2414, 2, 3);
      V v_t_2416 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      V v_t_2417 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_src_2415, v_t_2416, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2418 = (g_list_2emap_24s953916415x1126219438(MK_INT(0LL), heff_get_n(v_t_2417, 2, 3)));
      V v_x1_2419 = ({ V a_0 = v_t_2413; V a_1 = v_t_2418; V r_ = (g_heff_2esyntax_2eformat_2estrsEq(a_0, a_1)); heff_drop(v_t_2413); heff_drop(v_t_2418); r_; });
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_True: {
        return heff_tag_n(TAG_Right, 1, (V[]){v_out_241});
      }
      case TAG_False: {
        heff_drop(v_out_241);
        return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2esyntax_2eformat_2esameMeaning_str2)});
      }
      default: return heff_nomatch(v_x1_2419);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2esyntax_2eformat_2esameMeaning_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2esameMeaning(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2eformat_str0, 0, "");
Clo g_heff_2esyntax_2eformat_2eformat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2eformat_entry, 1, 0};

V g_heff_2esyntax_2eformat_2eformat(V v_src_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_240), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_src_242 = heff_get_n(v_t_241, 2, 3);
  V v_t_243 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_244 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_src_242, v_t_243, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_ts_245 = heff_arrayFromList(heff_get_n(v_t_244, 0, 3));
  V v_t_246 = (g_heff_2esyntax_2esurface_2efixDecls(v_ts_245, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_247 = (g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(((V)&g_heff_2esyntax_2eformat_2eformat_str0), v_t_246));
  V v_f_248 = heff_get_n(v_t_247, 0, 2);
  V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(v_f_248, heff_dup(v_src_240)));
  switch (heff_tag_of(v_t_249)) {
  case TAG_Left: {
    V v_why_2410 = heff_field(v_t_249, 0);
    V v_ru_24t_249_24Left = heff_take_reuse_n(v_t_249, 1ULL, 1);
    heff_drop(v_src_240);
    return heff_tag_at_n(v_ru_24t_249_24Left, TAG_Left, 1, (V[]){v_why_2410});
  }
  case TAG_Right: {
    V v_out_2411 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    V v_t_2412 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_240), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2413 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2412));
    V v_t_2414 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_out_2411), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2415 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2414));
    return (g_heff_2esyntax_2eformat_2esameMeaning(v_src_240, v_out_2411, v_t_2413, v_t_2415));
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2esyntax_2eformat_2eformat_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2eformat(a[0]);
}