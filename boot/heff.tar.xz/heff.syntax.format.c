// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ImplicitParam 51130
#define TAG_IntWord 51777
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_PatAs 19989
#define TAG_PatBytes 60255
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_RuneWord 42901
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StringWord 15530
#define TAG_TagVariant 25174
#define TAG_TypeWord 10401
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_cmt 308164
#define LBL_comments 142722952
#define LBL_decl 9574769
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_err 310239
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_i 323
#define LBL_imports 10411951
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tokens 1078955205
static uint32_t shape_e__decl[] = {LBL_e, LBL_decl};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_imports__decls__diags[] = {LBL_imports, LBL_decls, LBL_diags};
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_clo;
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2eformat_2ealtKey(V, V);
V g_heff_2esyntax_2eformat_2ealtKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ealtKey_clo;
V g_heff_2esyntax_2eformat_2eequationKey(V, V);
V g_heff_2esyntax_2eformat_2eequationKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eequationKey_clo;
V g_heff_2esyntax_2eformat_2efieldDeclKey(V, V);
V g_heff_2esyntax_2eformat_2efieldDeclKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2efieldDeclKey_clo;
V g_heff_2esyntax_2eformat_2efieldSetKey(V, V);
V g_heff_2esyntax_2eformat_2efieldSetKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2efieldSetKey_clo;
V g_heff_2esyntax_2eformat_2eformat(V);
V g_heff_2esyntax_2eformat_2eformat_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eformat_clo;
V g_heff_2esyntax_2eformat_2ekeyDeclF(V, V);
V g_heff_2esyntax_2eformat_2ekeyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyDeclF_clo;
V g_heff_2esyntax_2eformat_2ekeyTermF(V, V);
V g_heff_2esyntax_2eformat_2ekeyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyTermF_clo;
V g_heff_2esyntax_2eformat_2ekeys_get(void);
V g_heff_2esyntax_2eformat_2elamKey(V, V);
V g_heff_2esyntax_2eformat_2elamKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2elamKey_clo;
V g_heff_2esyntax_2eformat_2emeaningFrom(V);
V g_heff_2esyntax_2eformat_2emeaningFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2emeaningFrom_clo;
V g_heff_2esyntax_2eformat_2eparamKey(V, V);
V g_heff_2esyntax_2eformat_2eparamKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eparamKey_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2eformat_2epiKey(V, V);
V g_heff_2esyntax_2eformat_2epiKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epiKey_clo;
V g_heff_2esyntax_2eformat_2esameMeaning(V, V, V, V);
V g_heff_2esyntax_2eformat_2esameMeaning_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2esameMeaning_clo;
V g_heff_2esyntax_2eformat_2estmtKey(V, V);
V g_heff_2esyntax_2eformat_2estmtKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2estmtKey_clo;
V g_heff_2esyntax_2eformat_2estrsEq(V, V);
V g_heff_2esyntax_2eformat_2estrsEq_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2estrsEq_clo;
V g_heff_2esyntax_2eformat_2eupdateSetKey(V, V);
V g_heff_2esyntax_2eformat_2eupdateSetKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eupdateSetKey_clo;
V g_heff_2esyntax_2eformat_2evariantKey(V, V);
V g_heff_2esyntax_2eformat_2evariantKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2evariantKey_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_clo;
V g_heff_2esyntax_2esurface_2ereadLexed_24s1184711084x1445388714(V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_24s1184711084x1445388714_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_24s1184711084x1445388714_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1195846327x230486685(V, V, V, V, V, V, V);
V g_list_2emap_24s1195846327x230486685_entry(V self, V *a);
extern Clo g_list_2emap_24s1195846327x230486685_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_list_2emap_24s1561756891x1126436879(V);
V g_list_2emap_24s1561756891x1126436879_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_clo;
V g_list_2emap_24s179832492x431904054(V);
V g_list_2emap_24s179832492x431904054_entry(V self, V *a);
extern Clo g_list_2emap_24s179832492x431904054_clo;
V g_list_2emap_24s1816200867x1876638332(V);
V g_list_2emap_24s1816200867x1876638332_entry(V self, V *a);
extern Clo g_list_2emap_24s1816200867x1876638332_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s594167626x1954057348(V, V);
V g_list_2emap_24s594167626x1954057348_entry(V self, V *a);
extern Clo g_list_2emap_24s594167626x1954057348_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str3, 3, "var");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str7, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str8, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str9, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str13, 3, "tag");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str14, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str15, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str17, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str18, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str19, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str21, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str22, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str23, 2, "op");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str24, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str25, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str27, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str28, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str29, 3, "int");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str30, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str31, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str33, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str34, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str35, 5, "float");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str36, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str37, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str39, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str40, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str41, 6, "string");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str42, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str43, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str45, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str46, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str47, 5, "bytes");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str48, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str49, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str50, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str51, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str52, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str53, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str54, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str55, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str56, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str57, 5, "field");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str58, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str59, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str60, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str61, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str62, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str63, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str64, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str65, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str66, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str67, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str68, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str69, 6, "record");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str70, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str71, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str72, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str73, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str74, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str75, 6, "String");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str76, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str77, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str78, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str79, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str80, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str81, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str82, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str83, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str84, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str85, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str86, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str87, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str88, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str89, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str90, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str91, 4, "word");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str92, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str93, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str94, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str95, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str96, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str97, 2, "as");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str98, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str99, 1, "(");
Clo g_heff_2esyntax_2eformat_2epatKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2epatKey_entry, 1, 0};

V g_heff_2esyntax_2eformat_2epatKey(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      V v_x2_245 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str0), v_t_244));
      V v_t_248;
      switch (heff_tag_of(v_x2_245)) {
      case TAG_Nil: {
        v_t_248 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_246 = heff_field(v_x2_245, 0);
        V v_xs_247 = heff_field(v_x2_245, 1);
        heff_take_n(v_x2_245, 3ULL, 2);
        v_t_248 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
        break;
      }
      default: heff_nomatch(v_x2_245);
      }
      V v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str3), heff_strAppend(v_t_248, ((V)&g_heff_2esyntax_2eformat_2epatKey_str4)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str5), v_t_249);
    }
    case TAG_PatTag: {
      V v_t_2410 = heff_field(v_x11_241, 0);
      V v_ps_2412 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_x2_2413 = (g_list_2emap(((V)&g_heff_2esyntax_2eformat_2epatKey_clo), v_ps_2412));
      V v_t_2416;
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_Nil: {
        v_t_2416 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str6);
        break;
      }
      case TAG_Cons: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        V v_xs_2415 = heff_field(v_x2_2413, 1);
        heff_take_n(v_x2_2413, 3ULL, 2);
        v_t_2416 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str7); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2413);
      }
      V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str8), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2eformat_2epatKey_str9)));
      V v_t_2418 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      V v_parts_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2418});
      V v_x2_2420 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str10), v_parts_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str12); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      V v_t_2424 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str13), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2eformat_2epatKey_str14)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str15), v_t_2424);
    }
    case TAG_PatOp: {
      V v_x_2425 = heff_field(v_x11_241, 0);
      V v_ps_2427 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_x2_2428 = (g_list_2emap(((V)&g_heff_2esyntax_2eformat_2epatKey_clo), v_ps_2427));
      V v_t_2431;
      switch (heff_tag_of(v_x2_2428)) {
      case TAG_Nil: {
        v_t_2431 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str16);
        break;
      }
      case TAG_Cons: {
        V v_x_2429 = heff_field(v_x2_2428, 0);
        V v_xs_2430 = heff_field(v_x2_2428, 1);
        heff_take_n(v_x2_2428, 3ULL, 2);
        v_t_2431 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str17); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2428);
      }
      V v_t_2432 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str18), heff_strAppend(v_t_2431, ((V)&g_heff_2esyntax_2eformat_2epatKey_str19)));
      V v_t_2433 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
      V v_parts_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2425, v_t_2433});
      V v_x2_2435 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str20), v_parts_2434));
      V v_t_2438;
      switch (heff_tag_of(v_x2_2435)) {
      case TAG_Nil: {
        v_t_2438 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str21);
        break;
      }
      case TAG_Cons: {
        V v_x_2436 = heff_field(v_x2_2435, 0);
        V v_xs_2437 = heff_field(v_x2_2435, 1);
        heff_take_n(v_x2_2435, 3ULL, 2);
        v_t_2438 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str22); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2435);
      }
      V v_t_2439 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str23), heff_strAppend(v_t_2438, ((V)&g_heff_2esyntax_2eformat_2epatKey_str24)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str25), v_t_2439);
    }
    case TAG_PatInt: {
      V v_i_2440 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2441 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){heff_intShow(v_i_2440), NTAG(TAG_Nil)});
      V v_x2_2442 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str26), v_t_2441));
      V v_t_2445;
      switch (heff_tag_of(v_x2_2442)) {
      case TAG_Nil: {
        v_t_2445 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str27);
        break;
      }
      case TAG_Cons: {
        V v_x_2443 = heff_field(v_x2_2442, 0);
        V v_xs_2444 = heff_field(v_x2_2442, 1);
        heff_take_n(v_x2_2442, 3ULL, 2);
        v_t_2445 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str28); V a_1 = v_x_2443; V a_2 = v_xs_2444; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2444); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2442);
      }
      V v_t_2446 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str29), heff_strAppend(v_t_2445, ((V)&g_heff_2esyntax_2eformat_2epatKey_str30)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str31), v_t_2446);
    }
    case TAG_PatFloat: {
      V v_x_2447 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2448 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){heff_floatShow(v_x_2447), NTAG(TAG_Nil)});
      V v_x2_2449 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str32), v_t_2448));
      V v_t_2452;
      switch (heff_tag_of(v_x2_2449)) {
      case TAG_Nil: {
        v_t_2452 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str33);
        break;
      }
      case TAG_Cons: {
        V v_x_2450 = heff_field(v_x2_2449, 0);
        V v_xs_2451 = heff_field(v_x2_2449, 1);
        heff_take_n(v_x2_2449, 3ULL, 2);
        v_t_2452 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str34); V a_1 = v_x_2450; V a_2 = v_xs_2451; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2451); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2449);
      }
      V v_t_2453 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str35), heff_strAppend(v_t_2452, ((V)&g_heff_2esyntax_2eformat_2epatKey_str36)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str37), v_t_2453);
    }
    case TAG_PatString: {
      V v_x_2454 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2455 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2454, NTAG(TAG_Nil)});
      V v_x2_2456 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str38), v_t_2455));
      V v_t_2459;
      switch (heff_tag_of(v_x2_2456)) {
      case TAG_Nil: {
        v_t_2459 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str39);
        break;
      }
      case TAG_Cons: {
        V v_x_2457 = heff_field(v_x2_2456, 0);
        V v_xs_2458 = heff_field(v_x2_2456, 1);
        heff_take_n(v_x2_2456, 3ULL, 2);
        v_t_2459 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str40); V a_1 = v_x_2457; V a_2 = v_xs_2458; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2458); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2456);
      }
      V v_t_2460 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str41), heff_strAppend(v_t_2459, ((V)&g_heff_2esyntax_2eformat_2epatKey_str42)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str43), v_t_2460);
    }
    case TAG_PatBytes: {
      V v_x_2461 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2462 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2461, NTAG(TAG_Nil)});
      V v_x2_2463 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str44), v_t_2462));
      V v_t_2466;
      switch (heff_tag_of(v_x2_2463)) {
      case TAG_Nil: {
        v_t_2466 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str45);
        break;
      }
      case TAG_Cons: {
        V v_x_2464 = heff_field(v_x2_2463, 0);
        V v_xs_2465 = heff_field(v_x2_2463, 1);
        heff_take_n(v_x2_2463, 3ULL, 2);
        v_t_2466 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str46); V a_1 = v_x_2464; V a_2 = v_xs_2465; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2465); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2463);
      }
      V v_t_2467 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str47), heff_strAppend(v_t_2466, ((V)&g_heff_2esyntax_2eformat_2epatKey_str48)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str49), v_t_2467);
    }
    case TAG_PatRune: {
      V v_c_2468 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2469 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){heff_intShow(v_c_2468), NTAG(TAG_Nil)});
      V v_x2_2470 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str50), v_t_2469));
      V v_t_2473;
      switch (heff_tag_of(v_x2_2470)) {
      case TAG_Nil: {
        v_t_2473 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str51);
        break;
      }
      case TAG_Cons: {
        V v_x_2471 = heff_field(v_x2_2470, 0);
        V v_xs_2472 = heff_field(v_x2_2470, 1);
        heff_take_n(v_x2_2470, 3ULL, 2);
        v_t_2473 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str52); V a_1 = v_x_2471; V a_2 = v_xs_2472; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2472); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2470);
      }
      V v_t_2474 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str53), heff_strAppend(v_t_2473, ((V)&g_heff_2esyntax_2eformat_2epatKey_str54)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str55), v_t_2474);
    }
    case TAG_PatRecord: {
      V v_fs_2475 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_x2_2476 = (g_list_2emap_24s1195846327x230486685(((V)&g_heff_2esyntax_2eformat_2epatKey_str56), ((V)&g_heff_2esyntax_2eformat_2epatKey_str57), ((V)&g_heff_2esyntax_2eformat_2epatKey_str58), ((V)&g_heff_2esyntax_2eformat_2epatKey_str59), ((V)&g_heff_2esyntax_2eformat_2epatKey_str60), ((V)&g_heff_2esyntax_2eformat_2epatKey_str61), v_fs_2475));
      V v_t_2479;
      switch (heff_tag_of(v_x2_2476)) {
      case TAG_Nil: {
        v_t_2479 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str62);
        break;
      }
      case TAG_Cons: {
        V v_x_2477 = heff_field(v_x2_2476, 0);
        V v_xs_2478 = heff_field(v_x2_2476, 1);
        heff_take_n(v_x2_2476, 3ULL, 2);
        v_t_2479 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str63); V a_1 = v_x_2477; V a_2 = v_xs_2478; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2478); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2476);
      }
      V v_t_2480 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str64), heff_strAppend(v_t_2479, ((V)&g_heff_2esyntax_2eformat_2epatKey_str65)));
      V v_parts_2481 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2480, NTAG(TAG_Nil)});
      V v_x2_2482 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str66), v_parts_2481));
      V v_t_2485;
      switch (heff_tag_of(v_x2_2482)) {
      case TAG_Nil: {
        v_t_2485 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str67);
        break;
      }
      case TAG_Cons: {
        V v_x_2483 = heff_field(v_x2_2482, 0);
        V v_xs_2484 = heff_field(v_x2_2482, 1);
        heff_take_n(v_x2_2482, 3ULL, 2);
        v_t_2485 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str68); V a_1 = v_x_2483; V a_2 = v_xs_2484; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2484); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2482);
      }
      V v_t_2486 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str69), heff_strAppend(v_t_2485, ((V)&g_heff_2esyntax_2eformat_2epatKey_str70)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str71), v_t_2486);
    }
    case TAG_PatWord: {
      V v_w_2487 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2489;
      switch (heff_tag_of(v_w_2487)) {
      case TAG_TypeWord: {
        v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str72);
        break;
      }
      case TAG_IntWord: {
        v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str73);
        break;
      }
      case TAG_FloatWord: {
        v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str74);
        break;
      }
      case TAG_StringWord: {
        v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str75);
        break;
      }
      case TAG_RuneWord: {
        v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str76);
        break;
      }
      case TAG_ArrayWord: {
        v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str77);
        break;
      }
      case TAG_AbandonWord: {
        v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str78);
        break;
      }
      case TAG_FixedWord: {
        V v_w_2488 = heff_field(v_w_2487, 0);
        heff_take_n(v_w_2487, 1ULL, 1);
        switch (heff_tag_of(v_w_2488)) {
        case TAG_I8: {
          v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str79);
          break;
        }
        case TAG_I16: {
          v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str80);
          break;
        }
        case TAG_I32: {
          v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str81);
          break;
        }
        case TAG_I64: {
          v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str82);
          break;
        }
        case TAG_U8: {
          v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str83);
          break;
        }
        case TAG_U16: {
          v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str84);
          break;
        }
        case TAG_U32: {
          v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str85);
          break;
        }
        case TAG_U64: {
          v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str86);
          break;
        }
        case TAG_F32: {
          v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str87);
          break;
        }
        default: heff_nomatch(v_w_2488);
        }
        break;
      }
      default: heff_nomatch(v_w_2487);
      }
      V v_parts_2490 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2489, NTAG(TAG_Nil)});
      V v_x2_2491 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str88), v_parts_2490));
      V v_t_2494;
      switch (heff_tag_of(v_x2_2491)) {
      case TAG_Nil: {
        v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str89);
        break;
      }
      case TAG_Cons: {
        V v_x_2492 = heff_field(v_x2_2491, 0);
        V v_xs_2493 = heff_field(v_x2_2491, 1);
        heff_take_n(v_x2_2491, 3ULL, 2);
        v_t_2494 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str90); V a_1 = v_x_2492; V a_2 = v_xs_2493; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2493); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2491);
      }
      V v_t_2495 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str91), heff_strAppend(v_t_2494, ((V)&g_heff_2esyntax_2eformat_2epatKey_str92)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str93), v_t_2495);
    }
    case TAG_PatAs: {
      V v_x_2496 = heff_field(v_x11_241, 0);
      V v_q_2498 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_t_2499 = (g_heff_2esyntax_2eformat_2epatKey(v_q_2498));
      V v_t_24100 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2499, NTAG(TAG_Nil)});
      V v_parts_24101 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2496, v_t_24100});
      V v_x2_24102 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str94), v_parts_24101));
      V v_t_24105;
      switch (heff_tag_of(v_x2_24102)) {
      case TAG_Nil: {
        v_t_24105 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str95);
        break;
      }
      case TAG_Cons: {
        V v_x_24103 = heff_field(v_x2_24102, 0);
        V v_xs_24104 = heff_field(v_x2_24102, 1);
        heff_take_n(v_x2_24102, 3ULL, 2);
        v_t_24105 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str96); V a_1 = v_x_24103; V a_2 = v_xs_24104; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24104); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24102);
      }
      V v_t_24106 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str97), heff_strAppend(v_t_24105, ((V)&g_heff_2esyntax_2eformat_2epatKey_str98)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str99), v_t_24106);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2epatKey(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str3, 8, "explicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str9, 8, "implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2eparamKey_str11, 1, "(");
Clo g_heff_2esyntax_2eformat_2eparamKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2eparamKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2eparamKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_t_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_246}));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_248});
      V v_x2_2410 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2eparamKey_str0), v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str3), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2eformat_2eparamKey_str4)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str5), v_t_2414);
    }
    case TAG_ImplicitParam: {
      V v_x_2415 = heff_field(v_x21_242, 0);
      V v_t_2417 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2417}));
      V v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
      V v_parts_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_t_2419});
      V v_x2_2421 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2eparamKey_str6), v_parts_2420));
      V v_t_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str8); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str9), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2eformat_2eparamKey_str10)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str11), v_t_2425);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2eparamKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2eparamKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str3, 5, "named");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str9, 8, "implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str11, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str15, 8, "implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str16, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str17, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str21, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str22, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str23, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str25, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str27, 4, "anon");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str28, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epiKey_str29, 1, "(");
Clo g_heff_2esyntax_2eformat_2epiKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2epiKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2epiKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_244)}));
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_parts_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_242), v_t_246});
    V v_x2_248 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epiKey_str0), v_parts_247));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str2); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str3), heff_strAppend(v_t_2411, ((V)&g_heff_2esyntax_2eformat_2epiKey_str4)));
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str5), v_t_2412);
  }
  case TAG_PiImplicit: {
    V v_x_2413 = heff_field(v_x2_241, 0);
    V v_t_2416 = heff_field(v_x2_241, 3);
    V v_x25_2417 = heff_field(v_x2_241, 4);
    switch (heff_tag_of(v_x25_2417)) {
    case TAG_Nothing: {
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2416)}));
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
      V v_parts_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2413), v_t_2419});
      V v_x2_2421 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epiKey_str6), v_parts_2420));
      V v_t_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str8); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str9), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2eformat_2epiKey_str10)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str11), v_t_2425);
    }
    case TAG_Just: {
      V v_d_2426 = heff_field(v_x25_2417, 0);
      V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){heff_dup(v_t_2416)}));
      V v_t_2428 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_d_2426)}));
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
      V v_parts_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2413), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2429})});
      V v_x2_2431 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epiKey_str12), v_parts_2430));
      V v_t_2434;
      switch (heff_tag_of(v_x2_2431)) {
      case TAG_Nil: {
        v_t_2434 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2432 = heff_field(v_x2_2431, 0);
        V v_xs_2433 = heff_field(v_x2_2431, 1);
        heff_take_n(v_x2_2431, 3ULL, 2);
        v_t_2434 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str14); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2431);
      }
      V v_t_2435 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str15), heff_strAppend(v_t_2434, ((V)&g_heff_2esyntax_2eformat_2epiKey_str16)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str17), v_t_2435);
    }
    default: return heff_nomatch(v_x25_2417);
    }
  }
  case TAG_PiInstance: {
    V v_x_2436 = heff_field(v_x2_241, 0);
    V v_t_2439 = heff_field(v_x2_241, 3);
    V v_t_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2439)}));
    V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
    V v_parts_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2436), v_t_2441});
    V v_x2_2443 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epiKey_str18), v_parts_2442));
    V v_t_2446;
    switch (heff_tag_of(v_x2_2443)) {
    case TAG_Nil: {
      v_t_2446 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2444 = heff_field(v_x2_2443, 0);
      V v_xs_2445 = heff_field(v_x2_2443, 1);
      heff_take_n(v_x2_2443, 3ULL, 2);
      v_t_2446 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str20); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2443);
    }
    V v_t_2447 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str21), heff_strAppend(v_t_2446, ((V)&g_heff_2esyntax_2eformat_2epiKey_str22)));
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str23), v_t_2447);
  }
  case TAG_PiAnon: {
    V v_t_2448 = heff_field(v_x2_241, 0);
    V v_t_2449 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_t_2448)}));
    V v_parts_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
    V v_x2_2451 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epiKey_str24), v_parts_2450));
    V v_t_2454;
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_Nil: {
      v_t_2454 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str25);
      break;
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_xs_2453 = heff_field(v_x2_2451, 1);
      heff_take_n(v_x2_2451, 3ULL, 2);
      v_t_2454 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epiKey_str26); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2451);
    }
    V v_t_2455 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str27), heff_strAppend(v_t_2454, ((V)&g_heff_2esyntax_2eformat_2epiKey_str28)));
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epiKey_str29), v_t_2455);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2epiKey_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2eformat_2epiKey(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str3, 4, "name");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str9, 8, "implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str11, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str15, 3, "ann");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str16, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str17, 1, "(");
Clo g_heff_2esyntax_2eformat_2elamKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2elamKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2elamKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_LamName: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24LamName = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    heff_drop_rec(v_r_240, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x2_241_24LamName, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
    V v_x2_245 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2elamKey_str0), v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str3), heff_strAppend(v_t_248, ((V)&g_heff_2esyntax_2eformat_2elamKey_str4)));
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str5), v_t_249);
  }
  case TAG_LamImplicit: {
    V v_x_2410 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24LamImplicit = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    heff_drop_rec(v_r_240, 2);
    V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24LamImplicit, TAG_Cons, 2, (V[]){v_x_2410, NTAG(TAG_Nil)});
    V v_x2_2413 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2elamKey_str6), v_t_2412));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str8); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str9), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2eformat_2elamKey_str10)));
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str11), v_t_2417);
  }
  case TAG_LamAnn: {
    V v_x_2418 = heff_field(v_x2_241, 0);
    V v_t_2420 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    V v_t_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2420}));
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
    V v_parts_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2418, v_t_2422});
    V v_x2_2424 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2elamKey_str12), v_parts_2423));
    V v_t_2427;
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nil: {
      v_t_2427 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str13);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_xs_2426 = heff_field(v_x2_2424, 1);
      heff_take_n(v_x2_2424, 3ULL, 2);
      v_t_2427 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str14); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2424);
    }
    V v_t_2428 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str15), heff_strAppend(v_t_2427, ((V)&g_heff_2esyntax_2eformat_2elamKey_str16)));
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str17), v_t_2428);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2elamKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2elamKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str3, 5, "field");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str9, 5, "field");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str11, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str15, 3, "bad");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str16, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str17, 1, "(");
Clo g_heff_2esyntax_2eformat_2efieldDeclKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2efieldDeclKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2efieldDeclKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_x214_247 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 13ULL, 4);
      switch (heff_tag_of(v_x214_247)) {
      case TAG_Nothing: {
        V v_t_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_246}));
        V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
        V v_parts_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_249});
        V v_x2_2411 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str0), v_parts_2410));
        V v_t_2414;
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_Nil: {
          v_t_2414 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_x2_2411, 0);
          V v_xs_2413 = heff_field(v_x2_2411, 1);
          heff_take_n(v_x2_2411, 3ULL, 2);
          v_t_2414 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str2); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2411);
        }
        V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str3), heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str4)));
        return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str5), v_t_2415);
      }
      case TAG_Just: {
        V v_d_2416 = heff_field(v_x214_247, 0);
        heff_take_n(v_x214_247, 1ULL, 1);
        V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_246}));
        V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_2416}));
        V v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
        V v_parts_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2419})});
        V v_x2_2421 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str6), v_parts_2420));
        V v_t_2424;
        switch (heff_tag_of(v_x2_2421)) {
        case TAG_Nil: {
          v_t_2424 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str7);
          break;
        }
        case TAG_Cons: {
          V v_x_2422 = heff_field(v_x2_2421, 0);
          V v_xs_2423 = heff_field(v_x2_2421, 1);
          heff_take_n(v_x2_2421, 3ULL, 2);
          v_t_2424 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str8); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2421);
        }
        V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str9), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str10)));
        return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str11), v_t_2425);
      }
      default: return heff_nomatch(v_x214_247);
      }
    }
    case TAG_BadFieldDecl: {
      V v_e_2426 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2426}));
      V v_parts_2428 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
      V v_x2_2429 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str12), v_parts_2428));
      V v_t_2432;
      switch (heff_tag_of(v_x2_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_x2_2429, 0);
        V v_xs_2431 = heff_field(v_x2_2429, 1);
        heff_take_n(v_x2_2429, 3ULL, 2);
        v_t_2432 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str14); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2429);
      }
      V v_t_2433 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str15), heff_strAppend(v_t_2432, ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str16)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str17), v_t_2433);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2efieldDeclKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2efieldDeclKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str1, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str2, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str3, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str7, 7, "variant");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str9, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str13, 3, "bad");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str14, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2evariantKey_str15, 1, "(");
Clo g_heff_2esyntax_2eformat_2evariantKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2evariantKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2evariantKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_TagVariant: {
      V v_t_244 = heff_field(v_x21_242, 0);
      V v_args_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_x2_247 = (g_list_2emap(heff_get_n(v_r_240, 0, 2), v_args_246));
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str1); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2411 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2evariantKey_str2), heff_strAppend(v_t_2410, ((V)&g_heff_2esyntax_2eformat_2evariantKey_str3)));
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_parts_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2412});
      V v_x2_2414 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2evariantKey_str4), v_parts_2413));
      V v_t_2417;
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_Nil: {
        v_t_2417 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_xs_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str6); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2414);
      }
      V v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2evariantKey_str7), heff_strAppend(v_t_2417, ((V)&g_heff_2esyntax_2eformat_2evariantKey_str8)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2evariantKey_str9), v_t_2418);
    }
    case TAG_BadVariant: {
      V v_e_2419 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2419}));
      V v_parts_2421 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
      V v_x2_2422 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2evariantKey_str10), v_parts_2421));
      V v_t_2425;
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_Nil: {
        v_t_2425 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_xs_2424 = heff_field(v_x2_2422, 1);
        heff_take_n(v_x2_2422, 3ULL, 2);
        v_t_2425 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2evariantKey_str12); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2422);
      }
      V v_t_2426 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2evariantKey_str13), heff_strAppend(v_t_2425, ((V)&g_heff_2esyntax_2eformat_2evariantKey_str14)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2evariantKey_str15), v_t_2426);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2evariantKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2evariantKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str3, 3, "set");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str9, 3, "bad");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str11, 1, "(");
Clo g_heff_2esyntax_2eformat_2efieldSetKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2efieldSetKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2efieldSetKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_e_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_246}));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_248});
      V v_x2_2410 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str0), v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str3), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str4)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str5), v_t_2414);
    }
    case TAG_BadFieldSet: {
      V v_e_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2415}));
      V v_parts_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      V v_x2_2418 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str6), v_parts_2417));
      V v_t_2421;
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_Nil: {
        v_t_2421 = ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2419 = heff_field(v_x2_2418, 0);
        V v_xs_2420 = heff_field(v_x2_2418, 1);
        heff_take_n(v_x2_2418, 3ULL, 2);
        v_t_2421 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str8); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2418);
      }
      V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str9), heff_strAppend(v_t_2421, ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str10)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str11), v_t_2422);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2efieldSetKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2efieldSetKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str1, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str2, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str3, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str7, 4, "path");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2eupdateSetKey_str9, 1, "(");
Clo g_heff_2esyntax_2eformat_2eupdateSetKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2eupdateSetKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2eupdateSetKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetPath: {
      V v_path_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24SetPath = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x2_246 = (g_list_2emap_24s1816200867x1876638332(v_path_244));
      V v_t_249;
      switch (heff_tag_of(v_x2_246)) {
      case TAG_Nil: {
        v_t_249 = ((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x2_246, 0);
        V v_xs_248 = heff_field(v_x2_246, 1);
        heff_take_n(v_x2_246, 3ULL, 2);
        v_t_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str1); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
        break;
      }
      default: heff_nomatch(v_x2_246);
      }
      V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str2), heff_strAppend(v_t_249, ((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str3)));
      V v_t_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_245}));
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      V v_parts_2413 = heff_tag_at_n(v_ru_24x21_242_24SetPath, TAG_Cons, 2, (V[]){v_t_2410, v_t_2412});
      V v_x2_2414 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str4), v_parts_2413));
      V v_t_2417;
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_Nil: {
        v_t_2417 = ((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_xs_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        v_t_2417 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str6); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2414);
      }
      V v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str7), heff_strAppend(v_t_2417, ((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str8)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_str9), v_t_2418);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2eupdateSetKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2eupdateSetKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str3, 3, "alt");
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ealtKey_str5, 1, "(");
Clo g_heff_2esyntax_2eformat_2ealtKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ealtKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ealtKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_e_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24MkAlt = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_246 = (g_heff_2esyntax_2eformat_2epatKey(v_p_244));
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_245}));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag_at_n(v_ru_24x21_242_24MkAlt, TAG_Cons, 2, (V[]){v_t_246, v_t_248});
      V v_x2_2410 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ealtKey_str0), v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2esyntax_2eformat_2ealtKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ealtKey_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ealtKey_str3), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2eformat_2ealtKey_str4)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ealtKey_str5), v_t_2414);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2ealtKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2ealtKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str3, 4, "bind");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str9, 3, "let");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str11, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str15, 4, "expr");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str16, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str17, 1, "(");
Clo g_heff_2esyntax_2eformat_2estmtKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2estmtKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2estmtKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_StmtBind: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_e_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_246}));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_248});
      V v_x2_2410 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2estmtKey_str0), v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str3), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2eformat_2estmtKey_str4)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str5), v_t_2414);
    }
    case TAG_StmtLet: {
      V v_p_2415 = heff_field(v_x21_242, 0);
      V v_e_2416 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24StmtLet = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2417 = (g_heff_2esyntax_2eformat_2epatKey(v_p_2415));
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2416}));
      V v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
      V v_parts_2420 = heff_tag_at_n(v_ru_24x21_242_24StmtLet, TAG_Cons, 2, (V[]){v_t_2417, v_t_2419});
      V v_x2_2421 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2estmtKey_str6), v_parts_2420));
      V v_t_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str8); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str9), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2eformat_2estmtKey_str10)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str11), v_t_2425);
    }
    case TAG_StmtExpr: {
      V v_e_2426 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2426}));
      V v_parts_2428 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
      V v_x2_2429 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2estmtKey_str12), v_parts_2428));
      V v_t_2432;
      switch (heff_tag_of(v_x2_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_x2_2429, 0);
        V v_xs_2431 = heff_field(v_x2_2429, 1);
        heff_take_n(v_x2_2429, 3ULL, 2);
        v_t_2432 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str14); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2429);
      }
      V v_t_2433 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str15), heff_strAppend(v_t_2432, ((V)&g_heff_2esyntax_2eformat_2estmtKey_str16)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str17), v_t_2433);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2estmtKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2estmtKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str1, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str2, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str3, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str7, 8, "equation");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str9, 1, "(");
Clo g_heff_2esyntax_2eformat_2eequationKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2eequationKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2eequationKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkEquation: {
      V v_g_244 = heff_field(v_x21_242, 0);
      V v_ps_246 = heff_field(v_x21_242, 2);
      V v_rhs_247 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 13ULL, 4);
      V v_x2_248 = (g_list_2emap_24s1561756891x1126436879(v_ps_246));
      V v_t_2411;
      switch (heff_tag_of(v_x2_248)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_heff_2esyntax_2eformat_2eequationKey_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_x2_248, 0);
        V v_xs_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 3ULL, 2);
        v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eequationKey_str1); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
        break;
      }
      default: heff_nomatch(v_x2_248);
      }
      V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eequationKey_str2), heff_strAppend(v_t_2411, ((V)&g_heff_2esyntax_2eformat_2eequationKey_str3)));
      V v_t_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_rhs_247}));
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
      V v_parts_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_g_244, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2414})});
      V v_x2_2416 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2eequationKey_str4), v_parts_2415));
      V v_t_2419;
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2esyntax_2eformat_2eequationKey_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_xs_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        v_t_2419 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eequationKey_str6); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2416);
      }
      V v_t_2420 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eequationKey_str7), heff_strAppend(v_t_2419, ((V)&g_heff_2esyntax_2eformat_2eequationKey_str8)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eequationKey_str9), v_t_2420);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2eequationKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2eequationKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str3, 3, "var");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str9, 8, "implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str11, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str15, 3, "tag");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str16, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str17, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str21, 3, "int");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str22, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str23, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str24, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str25, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str26, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str27, 5, "float");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str28, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str29, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str30, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str31, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str32, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str33, 6, "string");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str34, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str35, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str37, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str38, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str39, 5, "bytes");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str40, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str41, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str42, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str43, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str44, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str45, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str46, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str47, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str48, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str49, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str50, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str51, 6, "String");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str52, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str53, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str54, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str55, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str56, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str57, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str58, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str59, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str60, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str61, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str62, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str63, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str64, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str65, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str66, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str67, 4, "word");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str68, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str69, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str70, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str71, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str72, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str73, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str74, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str75, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str76, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str77, 3, "app");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str78, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str79, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str80, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str81, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str82, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str83, 7, "project");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str84, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str85, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str86, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str87, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str88, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str89, 5, "named");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str90, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str91, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str93, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str94, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str95, 2, "pi");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str96, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str97, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str98, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str99, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str100, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str101, 3, "lam");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str102, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str103, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str104, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str105, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str106, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str107, 3, "ann");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str108, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str109, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str110, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str111, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str112, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str113, 4, "spec");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str114, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str115, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str116, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str117, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str118, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str119, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str120, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str121, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str122, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str123, 3, "sig");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str124, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str125, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str126, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str127, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str128, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str129, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str130, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str131, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str132, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str133, 3, "sum");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str134, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str135, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str136, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str137, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str138, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str139, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str140, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str141, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str142, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str143, 6, "struct");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str144, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str145, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str146, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str147, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str148, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str149, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str150, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str151, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str152, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str153, 6, "update");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str154, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str155, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str156, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str157, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str158, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str159, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str160, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str161, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str162, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str163, 5, "match");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str164, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str165, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str166, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str167, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str168, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str169, 3, "let");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str170, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str171, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str172, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str173, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str174, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str175, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str176, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str177, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str178, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str179, 2, "do");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str180, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str181, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str182, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str183, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str184, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str185, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str186, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str187, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str188, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str189, 5, "local");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str190, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str191, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str192, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str193, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str194, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str195, 7, "invalid");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str196, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyTermF_str197, 1, "(");
Clo g_heff_2esyntax_2eformat_2ekeyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeyTermF_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ekeyTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
      V v_x2_246 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str0), v_t_245));
      V v_t_249;
      switch (heff_tag_of(v_x2_246)) {
      case TAG_Nil: {
        v_t_249 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x2_246, 0);
        V v_xs_248 = heff_field(v_x2_246, 1);
        heff_take_n(v_x2_246, 3ULL, 2);
        v_t_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
        break;
      }
      default: heff_nomatch(v_x2_246);
      }
      V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str3), heff_strAppend(v_t_249, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str4)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str5), v_t_2410);
    }
    case TAG_EImplicitVar: {
      V v_x_2411 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2411, NTAG(TAG_Nil)});
      V v_x2_2413 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str6), v_t_2412));
      V v_t_2416;
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_Nil: {
        v_t_2416 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        V v_xs_2415 = heff_field(v_x2_2413, 1);
        heff_take_n(v_x2_2413, 3ULL, 2);
        v_t_2416 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str8); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2413);
      }
      V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str9), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str10)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str11), v_t_2417);
    }
    case TAG_ETag: {
      V v_x_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2418, NTAG(TAG_Nil)});
      V v_x2_2420 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str12), v_t_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str14); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      V v_t_2424 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str15), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str16)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str17), v_t_2424);
    }
    case TAG_EInt: {
      V v_i_2425 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2426 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_intShow(v_i_2425), NTAG(TAG_Nil)});
      V v_x2_2427 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str18), v_t_2426));
      V v_t_2430;
      switch (heff_tag_of(v_x2_2427)) {
      case TAG_Nil: {
        v_t_2430 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str19);
        break;
      }
      case TAG_Cons: {
        V v_x_2428 = heff_field(v_x2_2427, 0);
        V v_xs_2429 = heff_field(v_x2_2427, 1);
        heff_take_n(v_x2_2427, 3ULL, 2);
        v_t_2430 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str20); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2427);
      }
      V v_t_2431 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str21), heff_strAppend(v_t_2430, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str22)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str23), v_t_2431);
    }
    case TAG_EFloat: {
      V v_x_2432 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2433 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_floatShow(v_x_2432), NTAG(TAG_Nil)});
      V v_x2_2434 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str24), v_t_2433));
      V v_t_2437;
      switch (heff_tag_of(v_x2_2434)) {
      case TAG_Nil: {
        v_t_2437 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str25);
        break;
      }
      case TAG_Cons: {
        V v_x_2435 = heff_field(v_x2_2434, 0);
        V v_xs_2436 = heff_field(v_x2_2434, 1);
        heff_take_n(v_x2_2434, 3ULL, 2);
        v_t_2437 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str26); V a_1 = v_x_2435; V a_2 = v_xs_2436; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2436); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2434);
      }
      V v_t_2438 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str27), heff_strAppend(v_t_2437, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str28)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str29), v_t_2438);
    }
    case TAG_EString: {
      V v_x_2439 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2440 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2439, NTAG(TAG_Nil)});
      V v_x2_2441 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str30), v_t_2440));
      V v_t_2444;
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_Nil: {
        v_t_2444 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str31);
        break;
      }
      case TAG_Cons: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_xs_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        v_t_2444 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str32); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2441);
      }
      V v_t_2445 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str33), heff_strAppend(v_t_2444, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str34)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str35), v_t_2445);
    }
    case TAG_EBytes: {
      V v_x_2446 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2447 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2446, NTAG(TAG_Nil)});
      V v_x2_2448 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str36), v_t_2447));
      V v_t_2451;
      switch (heff_tag_of(v_x2_2448)) {
      case TAG_Nil: {
        v_t_2451 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str37);
        break;
      }
      case TAG_Cons: {
        V v_x_2449 = heff_field(v_x2_2448, 0);
        V v_xs_2450 = heff_field(v_x2_2448, 1);
        heff_take_n(v_x2_2448, 3ULL, 2);
        v_t_2451 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str38); V a_1 = v_x_2449; V a_2 = v_xs_2450; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2450); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2448);
      }
      V v_t_2452 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str39), heff_strAppend(v_t_2451, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str40)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str41), v_t_2452);
    }
    case TAG_ERune: {
      V v_c_2453 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2454 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){heff_intShow(v_c_2453), NTAG(TAG_Nil)});
      V v_x2_2455 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str42), v_t_2454));
      V v_t_2458;
      switch (heff_tag_of(v_x2_2455)) {
      case TAG_Nil: {
        v_t_2458 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str43);
        break;
      }
      case TAG_Cons: {
        V v_x_2456 = heff_field(v_x2_2455, 0);
        V v_xs_2457 = heff_field(v_x2_2455, 1);
        heff_take_n(v_x2_2455, 3ULL, 2);
        v_t_2458 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str44); V a_1 = v_x_2456; V a_2 = v_xs_2457; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2457); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2455);
      }
      V v_t_2459 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str45), heff_strAppend(v_t_2458, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str46)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str47), v_t_2459);
    }
    case TAG_EWord: {
      V v_w_2460 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2462;
      switch (heff_tag_of(v_w_2460)) {
      case TAG_TypeWord: {
        v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str48);
        break;
      }
      case TAG_IntWord: {
        v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str49);
        break;
      }
      case TAG_FloatWord: {
        v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str50);
        break;
      }
      case TAG_StringWord: {
        v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str51);
        break;
      }
      case TAG_RuneWord: {
        v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str52);
        break;
      }
      case TAG_ArrayWord: {
        v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str53);
        break;
      }
      case TAG_AbandonWord: {
        v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str54);
        break;
      }
      case TAG_FixedWord: {
        V v_w_2461 = heff_field(v_w_2460, 0);
        heff_take_n(v_w_2460, 1ULL, 1);
        switch (heff_tag_of(v_w_2461)) {
        case TAG_I8: {
          v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str55);
          break;
        }
        case TAG_I16: {
          v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str56);
          break;
        }
        case TAG_I32: {
          v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str57);
          break;
        }
        case TAG_I64: {
          v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str58);
          break;
        }
        case TAG_U8: {
          v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str59);
          break;
        }
        case TAG_U16: {
          v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str60);
          break;
        }
        case TAG_U32: {
          v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str61);
          break;
        }
        case TAG_U64: {
          v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str62);
          break;
        }
        case TAG_F32: {
          v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str63);
          break;
        }
        default: heff_nomatch(v_w_2461);
        }
        break;
      }
      default: heff_nomatch(v_w_2460);
      }
      V v_parts_2463 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
      V v_x2_2464 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str64), v_parts_2463));
      V v_t_2467;
      switch (heff_tag_of(v_x2_2464)) {
      case TAG_Nil: {
        v_t_2467 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str65);
        break;
      }
      case TAG_Cons: {
        V v_x_2465 = heff_field(v_x2_2464, 0);
        V v_xs_2466 = heff_field(v_x2_2464, 1);
        heff_take_n(v_x2_2464, 3ULL, 2);
        v_t_2467 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str66); V a_1 = v_x_2465; V a_2 = v_xs_2466; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2466); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2464);
      }
      V v_t_2468 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str67), heff_strAppend(v_t_2467, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str68)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str69), v_t_2468);
    }
    case TAG_EApp: {
      V v_h_2469 = heff_field(v_x21_242, 0);
      V v_args_2470 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EApp = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2471 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_2469}));
      V v_x2_2472 = (g_list_2emap(heff_get_n(v_r_240, 0, 2), v_args_2470));
      V v_t_2475;
      switch (heff_tag_of(v_x2_2472)) {
      case TAG_Nil: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str70);
        break;
      }
      case TAG_Cons: {
        V v_x_2473 = heff_field(v_x2_2472, 0);
        V v_xs_2474 = heff_field(v_x2_2472, 1);
        heff_take_n(v_x2_2472, 3ULL, 2);
        v_t_2475 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str71); V a_1 = v_x_2473; V a_2 = v_xs_2474; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2474); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2472);
      }
      V v_t_2476 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str72), heff_strAppend(v_t_2475, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str73)));
      V v_t_2477 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2476, NTAG(TAG_Nil)});
      V v_parts_2478 = heff_tag_at_n(v_ru_24x21_242_24EApp, TAG_Cons, 2, (V[]){v_t_2471, v_t_2477});
      V v_x2_2479 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str74), v_parts_2478));
      V v_t_2482;
      switch (heff_tag_of(v_x2_2479)) {
      case TAG_Nil: {
        v_t_2482 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str75);
        break;
      }
      case TAG_Cons: {
        V v_x_2480 = heff_field(v_x2_2479, 0);
        V v_xs_2481 = heff_field(v_x2_2479, 1);
        heff_take_n(v_x2_2479, 3ULL, 2);
        v_t_2482 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str76); V a_1 = v_x_2480; V a_2 = v_xs_2481; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2481); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2479);
      }
      V v_t_2483 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str77), heff_strAppend(v_t_2482, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str78)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str79), v_t_2483);
    }
    case TAG_EProject: {
      V v_x_2484 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2485 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2484, NTAG(TAG_Nil)});
      V v_x2_2486 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str80), v_t_2485));
      V v_t_2489;
      switch (heff_tag_of(v_x2_2486)) {
      case TAG_Nil: {
        v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str81);
        break;
      }
      case TAG_Cons: {
        V v_x_2487 = heff_field(v_x2_2486, 0);
        V v_xs_2488 = heff_field(v_x2_2486, 1);
        heff_take_n(v_x2_2486, 3ULL, 2);
        v_t_2489 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str82); V a_1 = v_x_2487; V a_2 = v_xs_2488; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2488); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2486);
      }
      V v_t_2490 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str83), heff_strAppend(v_t_2489, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str84)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str85), v_t_2490);
    }
    case TAG_ENamed: {
      V v_x_2491 = heff_field(v_x21_242, 0);
      V v_e_2492 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ENamed = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2493 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2492}));
      V v_t_2494 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2493, NTAG(TAG_Nil)});
      V v_parts_2495 = heff_tag_at_n(v_ru_24x21_242_24ENamed, TAG_Cons, 2, (V[]){v_x_2491, v_t_2494});
      V v_x2_2496 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str86), v_parts_2495));
      V v_t_2499;
      switch (heff_tag_of(v_x2_2496)) {
      case TAG_Nil: {
        v_t_2499 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str87);
        break;
      }
      case TAG_Cons: {
        V v_x_2497 = heff_field(v_x2_2496, 0);
        V v_xs_2498 = heff_field(v_x2_2496, 1);
        heff_take_n(v_x2_2496, 3ULL, 2);
        v_t_2499 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str88); V a_1 = v_x_2497; V a_2 = v_xs_2498; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2498); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2496);
      }
      V v_t_24100 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str89), heff_strAppend(v_t_2499, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str90)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str91), v_t_24100);
    }
    case TAG_EPi: {
      V v_b_24101 = heff_field(v_x21_242, 0);
      V v_cod_24102 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24103 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_b_24101; V r_ = (g_heff_2esyntax_2eformat_2epiKey(a_0, a_1)); heff_drop(v_b_24101); r_; });
      V v_t_24104 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_cod_24102}));
      V v_t_24105 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24104, NTAG(TAG_Nil)});
      V v_parts_24106 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_Cons, 2, (V[]){v_t_24103, v_t_24105});
      V v_x2_24107 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str92), v_parts_24106));
      V v_t_24110;
      switch (heff_tag_of(v_x2_24107)) {
      case TAG_Nil: {
        v_t_24110 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str93);
        break;
      }
      case TAG_Cons: {
        V v_x_24108 = heff_field(v_x2_24107, 0);
        V v_xs_24109 = heff_field(v_x2_24107, 1);
        heff_take_n(v_x2_24107, 3ULL, 2);
        v_t_24110 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str94); V a_1 = v_x_24108; V a_2 = v_xs_24109; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24109); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24107);
      }
      V v_t_24111 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str95), heff_strAppend(v_t_24110, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str96)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str97), v_t_24111);
    }
    case TAG_ELam: {
      V v_b_24112 = heff_field(v_x21_242, 0);
      V v_body_24113 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24114 = (g_heff_2esyntax_2eformat_2elamKey(heff_dup(v_r_240), v_b_24112));
      V v_t_24115 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_24113}));
      V v_t_24116 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24115, NTAG(TAG_Nil)});
      V v_parts_24117 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_Cons, 2, (V[]){v_t_24114, v_t_24116});
      V v_x2_24118 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str98), v_parts_24117));
      V v_t_24121;
      switch (heff_tag_of(v_x2_24118)) {
      case TAG_Nil: {
        v_t_24121 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str99);
        break;
      }
      case TAG_Cons: {
        V v_x_24119 = heff_field(v_x2_24118, 0);
        V v_xs_24120 = heff_field(v_x2_24118, 1);
        heff_take_n(v_x2_24118, 3ULL, 2);
        v_t_24121 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str100); V a_1 = v_x_24119; V a_2 = v_xs_24120; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24120); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24118);
      }
      V v_t_24122 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str101), heff_strAppend(v_t_24121, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str102)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str103), v_t_24122);
    }
    case TAG_EAnn: {
      V v_e_24123 = heff_field(v_x21_242, 0);
      V v_t_24124 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24125 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24123}));
      V v_t_24126 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_24124}));
      V v_t_24127 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24126, NTAG(TAG_Nil)});
      V v_parts_24128 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_Cons, 2, (V[]){v_t_24125, v_t_24127});
      V v_x2_24129 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str104), v_parts_24128));
      V v_t_24132;
      switch (heff_tag_of(v_x2_24129)) {
      case TAG_Nil: {
        v_t_24132 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str105);
        break;
      }
      case TAG_Cons: {
        V v_x_24130 = heff_field(v_x2_24129, 0);
        V v_xs_24131 = heff_field(v_x2_24129, 1);
        heff_take_n(v_x2_24129, 3ULL, 2);
        v_t_24132 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str106); V a_1 = v_x_24130; V a_2 = v_xs_24131; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24131); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24129);
      }
      V v_t_24133 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str107), heff_strAppend(v_t_24132, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str108)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str109), v_t_24133);
    }
    case TAG_ESpec: {
      V v_acc_24134 = heff_field(v_x21_242, 0);
      V v_x_24135 = heff_field(v_x21_242, 1);
      V v_v_24137 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 11ULL, 4);
      V v_t_24138 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_acc_24134}));
      V v_t_24139 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_24137}));
      V v_t_24140 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24139, NTAG(TAG_Nil)});
      V v_parts_24141 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24138, heff_tag_n(TAG_Cons, 2, (V[]){v_x_24135, v_t_24140})});
      V v_x2_24142 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str110), v_parts_24141));
      V v_t_24145;
      switch (heff_tag_of(v_x2_24142)) {
      case TAG_Nil: {
        v_t_24145 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str111);
        break;
      }
      case TAG_Cons: {
        V v_x_24143 = heff_field(v_x2_24142, 0);
        V v_xs_24144 = heff_field(v_x2_24142, 1);
        heff_take_n(v_x2_24142, 3ULL, 2);
        v_t_24145 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str112); V a_1 = v_x_24143; V a_2 = v_xs_24144; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24144); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24142);
      }
      V v_t_24146 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str113), heff_strAppend(v_t_24145, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str114)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str115), v_t_24146);
    }
    case TAG_ESig: {
      V v_fs_24147 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24148 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24149 = (g_list_2emap(v_t_24148, v_fs_24147));
      V v_t_24152;
      switch (heff_tag_of(v_x2_24149)) {
      case TAG_Nil: {
        v_t_24152 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str116);
        break;
      }
      case TAG_Cons: {
        V v_x_24150 = heff_field(v_x2_24149, 0);
        V v_xs_24151 = heff_field(v_x2_24149, 1);
        heff_take_n(v_x2_24149, 3ULL, 2);
        v_t_24152 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str117); V a_1 = v_x_24150; V a_2 = v_xs_24151; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24151); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24149);
      }
      V v_t_24153 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str118), heff_strAppend(v_t_24152, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str119)));
      V v_parts_24154 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24153, NTAG(TAG_Nil)});
      V v_x2_24155 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str120), v_parts_24154));
      V v_t_24158;
      switch (heff_tag_of(v_x2_24155)) {
      case TAG_Nil: {
        v_t_24158 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str121);
        break;
      }
      case TAG_Cons: {
        V v_x_24156 = heff_field(v_x2_24155, 0);
        V v_xs_24157 = heff_field(v_x2_24155, 1);
        heff_take_n(v_x2_24155, 3ULL, 2);
        v_t_24158 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str122); V a_1 = v_x_24156; V a_2 = v_xs_24157; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24157); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24155);
      }
      V v_t_24159 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str123), heff_strAppend(v_t_24158, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str124)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str125), v_t_24159);
    }
    case TAG_ESum: {
      V v_vs_24160 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24161 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2evariantKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24162 = (g_list_2emap(v_t_24161, v_vs_24160));
      V v_t_24165;
      switch (heff_tag_of(v_x2_24162)) {
      case TAG_Nil: {
        v_t_24165 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str126);
        break;
      }
      case TAG_Cons: {
        V v_x_24163 = heff_field(v_x2_24162, 0);
        V v_xs_24164 = heff_field(v_x2_24162, 1);
        heff_take_n(v_x2_24162, 3ULL, 2);
        v_t_24165 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str127); V a_1 = v_x_24163; V a_2 = v_xs_24164; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24164); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24162);
      }
      V v_t_24166 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str128), heff_strAppend(v_t_24165, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str129)));
      V v_parts_24167 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24166, NTAG(TAG_Nil)});
      V v_x2_24168 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str130), v_parts_24167));
      V v_t_24171;
      switch (heff_tag_of(v_x2_24168)) {
      case TAG_Nil: {
        v_t_24171 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str131);
        break;
      }
      case TAG_Cons: {
        V v_x_24169 = heff_field(v_x2_24168, 0);
        V v_xs_24170 = heff_field(v_x2_24168, 1);
        heff_take_n(v_x2_24168, 3ULL, 2);
        v_t_24171 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str132); V a_1 = v_x_24169; V a_2 = v_xs_24170; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24170); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24168);
      }
      V v_t_24172 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str133), heff_strAppend(v_t_24171, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str134)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str135), v_t_24172);
    }
    case TAG_EStruct: {
      V v_fs_24173 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24174 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24175 = (g_list_2emap(v_t_24174, v_fs_24173));
      V v_t_24178;
      switch (heff_tag_of(v_x2_24175)) {
      case TAG_Nil: {
        v_t_24178 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str136);
        break;
      }
      case TAG_Cons: {
        V v_x_24176 = heff_field(v_x2_24175, 0);
        V v_xs_24177 = heff_field(v_x2_24175, 1);
        heff_take_n(v_x2_24175, 3ULL, 2);
        v_t_24178 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str137); V a_1 = v_x_24176; V a_2 = v_xs_24177; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24177); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24175);
      }
      V v_t_24179 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str138), heff_strAppend(v_t_24178, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str139)));
      V v_parts_24180 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24179, NTAG(TAG_Nil)});
      V v_x2_24181 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str140), v_parts_24180));
      V v_t_24184;
      switch (heff_tag_of(v_x2_24181)) {
      case TAG_Nil: {
        v_t_24184 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str141);
        break;
      }
      case TAG_Cons: {
        V v_x_24182 = heff_field(v_x2_24181, 0);
        V v_xs_24183 = heff_field(v_x2_24181, 1);
        heff_take_n(v_x2_24181, 3ULL, 2);
        v_t_24184 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str142); V a_1 = v_x_24182; V a_2 = v_xs_24183; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24183); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24181);
      }
      V v_t_24185 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str143), heff_strAppend(v_t_24184, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str144)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str145), v_t_24185);
    }
    case TAG_EUpdate: {
      V v_a_24186 = heff_field(v_x21_242, 0);
      V v_fs_24187 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EUpdate = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24188 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24186}));
      V v_t_24189 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2eupdateSetKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24190 = (g_list_2emap(v_t_24189, v_fs_24187));
      V v_t_24193;
      switch (heff_tag_of(v_x2_24190)) {
      case TAG_Nil: {
        v_t_24193 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str146);
        break;
      }
      case TAG_Cons: {
        V v_x_24191 = heff_field(v_x2_24190, 0);
        V v_xs_24192 = heff_field(v_x2_24190, 1);
        heff_take_n(v_x2_24190, 3ULL, 2);
        v_t_24193 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str147); V a_1 = v_x_24191; V a_2 = v_xs_24192; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24192); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24190);
      }
      V v_t_24194 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str148), heff_strAppend(v_t_24193, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str149)));
      V v_t_24195 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24194, NTAG(TAG_Nil)});
      V v_parts_24196 = heff_tag_at_n(v_ru_24x21_242_24EUpdate, TAG_Cons, 2, (V[]){v_t_24188, v_t_24195});
      V v_x2_24197 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str150), v_parts_24196));
      V v_t_24200;
      switch (heff_tag_of(v_x2_24197)) {
      case TAG_Nil: {
        v_t_24200 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str151);
        break;
      }
      case TAG_Cons: {
        V v_x_24198 = heff_field(v_x2_24197, 0);
        V v_xs_24199 = heff_field(v_x2_24197, 1);
        heff_take_n(v_x2_24197, 3ULL, 2);
        v_t_24200 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str152); V a_1 = v_x_24198; V a_2 = v_xs_24199; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24199); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24197);
      }
      V v_t_24201 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str153), heff_strAppend(v_t_24200, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str154)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str155), v_t_24201);
    }
    case TAG_EMatch: {
      V v_s_24202 = heff_field(v_x21_242, 0);
      V v_alts_24203 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EMatch = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24204 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24202}));
      V v_t_24205 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2ealtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24206 = (g_list_2emap(v_t_24205, v_alts_24203));
      V v_t_24209;
      switch (heff_tag_of(v_x2_24206)) {
      case TAG_Nil: {
        v_t_24209 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str156);
        break;
      }
      case TAG_Cons: {
        V v_x_24207 = heff_field(v_x2_24206, 0);
        V v_xs_24208 = heff_field(v_x2_24206, 1);
        heff_take_n(v_x2_24206, 3ULL, 2);
        v_t_24209 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str157); V a_1 = v_x_24207; V a_2 = v_xs_24208; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24208); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24206);
      }
      V v_t_24210 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str158), heff_strAppend(v_t_24209, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str159)));
      V v_t_24211 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24210, NTAG(TAG_Nil)});
      V v_parts_24212 = heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_Cons, 2, (V[]){v_t_24204, v_t_24211});
      V v_x2_24213 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str160), v_parts_24212));
      V v_t_24216;
      switch (heff_tag_of(v_x2_24213)) {
      case TAG_Nil: {
        v_t_24216 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str161);
        break;
      }
      case TAG_Cons: {
        V v_x_24214 = heff_field(v_x2_24213, 0);
        V v_xs_24215 = heff_field(v_x2_24213, 1);
        heff_take_n(v_x2_24213, 3ULL, 2);
        v_t_24216 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str162); V a_1 = v_x_24214; V a_2 = v_xs_24215; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24215); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24213);
      }
      V v_t_24217 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str163), heff_strAppend(v_t_24216, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str164)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str165), v_t_24217);
    }
    case TAG_ELetIn: {
      V v_rhs_24218 = heff_field(v_x21_242, 0);
      V v_x212_24219 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x212_24219)) {
      case TAG_At: {
        V v_x2121_24220 = heff_field(v_x212_24219, 0);
        heff_take_n(v_x212_24219, 1ULL, 2);
        switch (heff_tag_of(v_x2121_24220)) {
        case TAG_MkAlt: {
          V v_p_24222 = heff_field(v_x2121_24220, 0);
          V v_e_24223 = heff_field(v_x2121_24220, 1);
          heff_take_n(v_x2121_24220, 3ULL, 2);
          V v_t_24224 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_24218}));
          V v_t_24225 = (g_heff_2esyntax_2eformat_2epatKey(v_p_24222));
          V v_t_24226 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24223}));
          V v_t_24227 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24226, NTAG(TAG_Nil)});
          V v_parts_24228 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_Cons, 2, (V[]){v_t_24224, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24225, v_t_24227})});
          V v_x2_24229 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str166), v_parts_24228));
          V v_t_24232;
          switch (heff_tag_of(v_x2_24229)) {
          case TAG_Nil: {
            v_t_24232 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str167);
            break;
          }
          case TAG_Cons: {
            V v_x_24230 = heff_field(v_x2_24229, 0);
            V v_xs_24231 = heff_field(v_x2_24229, 1);
            heff_take_n(v_x2_24229, 3ULL, 2);
            v_t_24232 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str168); V a_1 = v_x_24230; V a_2 = v_xs_24231; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24231); r_; });
            break;
          }
          default: heff_nomatch(v_x2_24229);
          }
          V v_t_24233 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str169), heff_strAppend(v_t_24232, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str170)));
          return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str171), v_t_24233);
        }
        default: return heff_nomatch(v_x2121_24220);
        }
      }
      default: return heff_nomatch(v_x212_24219);
      }
    }
    case TAG_EDo: {
      V v_stmts_24234 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_24235 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2estmtKey_clo), 1, (V[]){v_r_240}));
      V v_x2_24236 = (g_list_2emap(v_t_24235, v_stmts_24234));
      V v_t_24239;
      switch (heff_tag_of(v_x2_24236)) {
      case TAG_Nil: {
        v_t_24239 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str172);
        break;
      }
      case TAG_Cons: {
        V v_x_24237 = heff_field(v_x2_24236, 0);
        V v_xs_24238 = heff_field(v_x2_24236, 1);
        heff_take_n(v_x2_24236, 3ULL, 2);
        v_t_24239 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str173); V a_1 = v_x_24237; V a_2 = v_xs_24238; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24238); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24236);
      }
      V v_t_24240 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str174), heff_strAppend(v_t_24239, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str175)));
      V v_parts_24241 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24240, NTAG(TAG_Nil)});
      V v_x2_24242 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str176), v_parts_24241));
      V v_t_24245;
      switch (heff_tag_of(v_x2_24242)) {
      case TAG_Nil: {
        v_t_24245 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str177);
        break;
      }
      case TAG_Cons: {
        V v_x_24243 = heff_field(v_x2_24242, 0);
        V v_xs_24244 = heff_field(v_x2_24242, 1);
        heff_take_n(v_x2_24242, 3ULL, 2);
        v_t_24245 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str178); V a_1 = v_x_24243; V a_2 = v_xs_24244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24244); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24242);
      }
      V v_t_24246 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str179), heff_strAppend(v_t_24245, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str180)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str181), v_t_24246);
    }
    case TAG_ELocal: {
      V v_body_24247 = heff_field(v_x21_242, 0);
      V v_ds_24248 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24249 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 1, (V[]){v_body_24247}));
      V v_x2_24250 = (g_list_2emap(heff_get_n(v_r_240, 1, 2), v_ds_24248));
      V v_t_24253;
      switch (heff_tag_of(v_x2_24250)) {
      case TAG_Nil: {
        v_t_24253 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str182);
        break;
      }
      case TAG_Cons: {
        V v_x_24251 = heff_field(v_x2_24250, 0);
        V v_xs_24252 = heff_field(v_x2_24250, 1);
        heff_take_n(v_x2_24250, 3ULL, 2);
        v_t_24253 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str183); V a_1 = v_x_24251; V a_2 = v_xs_24252; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24252); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24250);
      }
      V v_t_24254 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str184), heff_strAppend(v_t_24253, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str185)));
      V v_t_24255 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_24254, NTAG(TAG_Nil)});
      V v_parts_24256 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_Cons, 2, (V[]){v_t_24249, v_t_24255});
      V v_x2_24257 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str186), v_parts_24256));
      V v_t_24260;
      switch (heff_tag_of(v_x2_24257)) {
      case TAG_Nil: {
        v_t_24260 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str187);
        break;
      }
      case TAG_Cons: {
        V v_x_24258 = heff_field(v_x2_24257, 0);
        V v_xs_24259 = heff_field(v_x2_24257, 1);
        heff_take_n(v_x2_24257, 3ULL, 2);
        v_t_24260 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str188); V a_1 = v_x_24258; V a_2 = v_xs_24259; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24259); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24257);
      }
      V v_t_24261 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str189), heff_strAppend(v_t_24260, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str190)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str191), v_t_24261);
    }
    case TAG_EInvalid: {
      V v_why_24262 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24263 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_why_24262, NTAG(TAG_Nil)});
      V v_x2_24264 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str192), v_t_24263));
      V v_t_24267;
      switch (heff_tag_of(v_x2_24264)) {
      case TAG_Nil: {
        v_t_24267 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str193);
        break;
      }
      case TAG_Cons: {
        V v_x_24265 = heff_field(v_x2_24264, 0);
        V v_xs_24266 = heff_field(v_x2_24264, 1);
        heff_take_n(v_x2_24264, 3ULL, 2);
        v_t_24267 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str194); V a_1 = v_x_24265; V a_2 = v_xs_24266; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24266); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24264);
      }
      V v_t_24268 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str195), heff_strAppend(v_t_24267, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str196)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str197), v_t_24268);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2ekeyTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2ekeyTermF(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str0, 10, "definition");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str1, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str3, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str4, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str5, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str9, 9, "equations");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str11, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str13, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str14, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str15, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str16, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str18, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str19, 6, "define");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str20, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str21, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str22, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str23, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str24, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str25, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str27, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str28, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str29, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str30, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str31, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str33, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str34, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str35, 9, "primitive");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str36, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str37, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str39, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str40, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str41, 4, "test");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str42, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str43, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str45, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str46, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str47, 5, "watch");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str48, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ekeyDeclF_str49, 1, "(");
Clo g_heff_2esyntax_2eformat_2ekeyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeyDeclF_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ekeyDeclF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_declared_246 = heff_field(v_x21_242, 2);
      V v_ty_247 = heff_field(v_x21_242, 3);
      V v_eqs_248 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 29ULL, 5);
      V v_t_249;
      switch (heff_tag_of(v_declared_246)) {
      case TAG_AsDefinition: {
        v_t_249 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str0);
        break;
      }
      case TAG_AsInstance: {
        v_t_249 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str1);
        break;
      }
      default: heff_nomatch(v_declared_246);
      }
      V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_247}));
      V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2eequationKey_clo), 1, (V[]){v_r_240}));
      V v_x2_2412 = (g_list_2emap(v_t_2411, v_eqs_248));
      V v_t_2415;
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nil: {
        v_t_2415 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        V v_xs_2414 = heff_field(v_x2_2412, 1);
        heff_take_n(v_x2_2412, 3ULL, 2);
        v_t_2415 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str3); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2412);
      }
      V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str4), heff_strAppend(v_t_2415, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str5)));
      V v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2417})});
      V v_parts_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_244, v_t_2418});
      V v_x2_2420 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str6), v_parts_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str8); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      V v_t_2424 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str9), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str10)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str11), v_t_2424);
    }
    case TAG_DeclDefine: {
      V v_x_2425 = heff_field(v_x21_242, 0);
      V v_ps_2427 = heff_field(v_x21_242, 2);
      V v_u_2428 = heff_field(v_x21_242, 3);
      V v_body_2429 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 29ULL, 5);
      V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2eparamKey_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_x2_2431 = (g_list_2emap(v_t_2430, v_ps_2427));
      V v_t_2434;
      switch (heff_tag_of(v_x2_2431)) {
      case TAG_Nil: {
        v_t_2434 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2432 = heff_field(v_x2_2431, 0);
        V v_xs_2433 = heff_field(v_x2_2431, 1);
        heff_take_n(v_x2_2431, 3ULL, 2);
        v_t_2434 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str13); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2431);
      }
      V v_t_2435 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str14), heff_strAppend(v_t_2434, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str15)));
      V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_u_2428}));
      V v_t_2437 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2429}));
      V v_t_2438 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
      V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_t_2438})});
      V v_parts_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2425, v_t_2439});
      V v_x2_2441 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str16), v_parts_2440));
      V v_t_2444;
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_Nil: {
        v_t_2444 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str17);
        break;
      }
      case TAG_Cons: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_xs_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        v_t_2444 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str18); V a_1 = v_x_2442; V a_2 = v_xs_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2443); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2441);
      }
      V v_t_2445 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str19), heff_strAppend(v_t_2444, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str20)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str21), v_t_2445);
    }
    case TAG_DeclTheory: {
      V v_x_2446 = heff_field(v_x21_242, 0);
      V v_ps_2448 = heff_field(v_x21_242, 2);
      V v_body_2449 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 13ULL, 4);
      V v_t_2450 = heff_tr(heff_call(((V)&g_heff_2esyntax_2eformat_2eparamKey_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_x2_2451 = (g_list_2emap(v_t_2450, v_ps_2448));
      V v_t_2454;
      switch (heff_tag_of(v_x2_2451)) {
      case TAG_Nil: {
        v_t_2454 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str22);
        break;
      }
      case TAG_Cons: {
        V v_x_2452 = heff_field(v_x2_2451, 0);
        V v_xs_2453 = heff_field(v_x2_2451, 1);
        heff_take_n(v_x2_2451, 3ULL, 2);
        v_t_2454 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str23); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2451);
      }
      V v_t_2455 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str24), heff_strAppend(v_t_2454, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str25)));
      V v_t_2456 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2449}));
      V v_t_2457 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2456, NTAG(TAG_Nil)});
      V v_parts_2458 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2446, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_t_2457})});
      V v_x2_2459 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str26), v_parts_2458));
      V v_t_2462;
      switch (heff_tag_of(v_x2_2459)) {
      case TAG_Nil: {
        v_t_2462 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str27);
        break;
      }
      case TAG_Cons: {
        V v_x_2460 = heff_field(v_x2_2459, 0);
        V v_xs_2461 = heff_field(v_x2_2459, 1);
        heff_take_n(v_x2_2459, 3ULL, 2);
        v_t_2462 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str28); V a_1 = v_x_2460; V a_2 = v_xs_2461; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2461); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2459);
      }
      V v_t_2463 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str29), heff_strAppend(v_t_2462, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str30)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str31), v_t_2463);
    }
    case TAG_DeclPrimitive: {
      V v_x_2464 = heff_field(v_x21_242, 0);
      V v_t_2466 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_2467 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2466}));
      V v_t_2468 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
      V v_parts_2469 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2464, v_t_2468});
      V v_x2_2470 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str32), v_parts_2469));
      V v_t_2473;
      switch (heff_tag_of(v_x2_2470)) {
      case TAG_Nil: {
        v_t_2473 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str33);
        break;
      }
      case TAG_Cons: {
        V v_x_2471 = heff_field(v_x2_2470, 0);
        V v_xs_2472 = heff_field(v_x2_2470, 1);
        heff_take_n(v_x2_2470, 3ULL, 2);
        v_t_2473 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str34); V a_1 = v_x_2471; V a_2 = v_xs_2472; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2472); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2470);
      }
      V v_t_2474 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str35), heff_strAppend(v_t_2473, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str36)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str37), v_t_2474);
    }
    case TAG_DeclTest: {
      V v_x_2475 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_2477 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2475, NTAG(TAG_Nil)});
      V v_x2_2478 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str38), v_t_2477));
      V v_t_2481;
      switch (heff_tag_of(v_x2_2478)) {
      case TAG_Nil: {
        v_t_2481 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str39);
        break;
      }
      case TAG_Cons: {
        V v_x_2479 = heff_field(v_x2_2478, 0);
        V v_xs_2480 = heff_field(v_x2_2478, 1);
        heff_take_n(v_x2_2478, 3ULL, 2);
        v_t_2481 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str40); V a_1 = v_x_2479; V a_2 = v_xs_2480; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2480); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2478);
      }
      V v_t_2482 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str41), heff_strAppend(v_t_2481, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str42)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str43), v_t_2482);
    }
    case TAG_DeclWatch: {
      V v_e_2483 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2484 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2483}));
      V v_parts_2485 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
      V v_x2_2486 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str44), v_parts_2485));
      V v_t_2489;
      switch (heff_tag_of(v_x2_2486)) {
      case TAG_Nil: {
        v_t_2489 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str45);
        break;
      }
      case TAG_Cons: {
        V v_x_2487 = heff_field(v_x2_2486, 0);
        V v_xs_2488 = heff_field(v_x2_2486, 1);
        heff_take_n(v_x2_2486, 3ULL, 2);
        v_t_2489 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str46); V a_1 = v_x_2487; V a_2 = v_xs_2488; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2488); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2486);
      }
      V v_t_2490 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str47), heff_strAppend(v_t_2489, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str48)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str49), v_t_2490);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2ekeyDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2ekeyDeclF(a[0], a[1]);
}
V g_heff_2esyntax_2eformat_2ekeys_lam0(V self, V *args); static Clo g_heff_2esyntax_2eformat_2ekeys_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeys_lam0, 1, 0};
V g_heff_2esyntax_2eformat_2ekeys_lam1(V self, V *args); static Clo g_heff_2esyntax_2eformat_2ekeys_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeys_lam1, 1, 0};

static V g_heff_2esyntax_2eformat_2ekeys_val;
static HEFF_ONCE g_heff_2esyntax_2eformat_2ekeys_st;
static V g_heff_2esyntax_2eformat_2ekeys_init(void) {
  return heff_rec_n(2, shape_e__decl, (V[]){((V)&g_heff_2esyntax_2eformat_2ekeys_lam0_clo), ((V)&g_heff_2esyntax_2eformat_2ekeys_lam1_clo)});
}
V g_heff_2esyntax_2eformat_2ekeys_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2eformat_2ekeys_st)) return g_heff_2esyntax_2eformat_2ekeys_val;
  return heff_global(&g_heff_2esyntax_2eformat_2ekeys_val, &g_heff_2esyntax_2eformat_2ekeys_st, g_heff_2esyntax_2eformat_2ekeys_init);
}
V g_heff_2esyntax_2eformat_2ekeys_lam0(V self, V *args) {
  V v_n_240 = args[0];
  return (g_heff_2esyntax_2eformat_2ekeyTermF(heff_dup(g_heff_2esyntax_2eformat_2ekeys_get()), v_n_240));
}
V g_heff_2esyntax_2eformat_2ekeys_lam1(V self, V *args) {
  V v_d_241 = args[0];
  return (g_heff_2esyntax_2eformat_2ekeyDeclF(heff_dup(g_heff_2esyntax_2eformat_2ekeys_get()), v_d_241));
}
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaningFrom_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2emeaningFrom_str1, 0, "");
Clo g_heff_2esyntax_2eformat_2emeaningFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2emeaningFrom_entry, 1, 0};

V g_heff_2esyntax_2eformat_2emeaningFrom(V v_h_240) {
top: ;
  V v_text_241 = heff_take_field(v_h_240, 2);
  V v_t_242 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_243 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(v_text_241), v_t_242, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_r_244 = (g_heff_2esyntax_2esurface_2ereadLexed_24s1184711084x1445388714(((V)&g_heff_2esyntax_2eformat_2emeaningFrom_str0), ((V)&g_heff_2esyntax_2eformat_2emeaningFrom_str1), v_text_241, v_t_243));
  V v_t_245 = (g_list_2emap_24s1817208647x1282894070(heff_get_n(v_h_240, 0, 3)));
  V v_t_246 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2esyntax_2eformat_2ekeys_get(), 1)), heff_take_field(v_r_244, 0)));
  V v_t_247 = (g_list_2emap_24s179832492x431904054(heff_get_n(v_r_244, 1, 4)));
  return heff_rec_n(3, shape_imports__decls__diags, (V[]){v_t_245, v_t_246, v_t_247});
}
V g_heff_2esyntax_2eformat_2emeaningFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2emeaningFrom(a[0]);
}
Clo g_heff_2esyntax_2eformat_2estrsEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2estrsEq_entry, 2, 0};

V g_heff_2esyntax_2eformat_2estrsEq(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c(heff_dup(v_a_244), heff_dup(v_b_246))) {
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2eformat_2estrsEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2eformat_2estrsEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2eformat_2esameMeaning_str0, 35, "formatting would change the imports");
HEFF_LIT(g_heff_2esyntax_2eformat_2esameMeaning_str1, 68, "formatting would change what the file means (a bug of the formatter)");
HEFF_LIT(g_heff_2esyntax_2eformat_2esameMeaning_str2, 76, "formatting would lose or move a comment across code (a bug of the formatter)");
Clo g_heff_2esyntax_2eformat_2esameMeaning_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2esameMeaning_entry, 4, 0};

V g_heff_2esyntax_2eformat_2esameMeaning(V v_src_240, V v_out_241, V v_a_242, V v_b_243) {
top: ;
  V v_x1_244 = (g_heff_2esyntax_2eformat_2estrsEq(heff_rfield(v_a_242, 0), heff_rfield(v_b_243, 0)));
  V v_t_245 = heff_bool(!(heff_dup(v_x1_244) == NTAG(TAG_True)));
  heff_drop(v_x1_244);
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_src_240);
    heff_drop(v_out_241);
    heff_drop_rec(v_a_242, 3);
    heff_drop_rec(v_b_243, 3);
    heff_drop(v_t_245);
    return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2esyntax_2eformat_2esameMeaning_str0)});
  } else {
    heff_drop(v_t_245);
    V v_t_246 = (g_heff_2esyntax_2eformat_2estrsEq(heff_rfield(v_a_242, 1), heff_rfield(v_b_243, 1)));
    V v_x1_247;
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      v_x1_247 = ({ V b_0 = heff_get_n(v_a_242, 2, 3); V b_1 = heff_get_n(v_b_243, 2, 3); V r_ = (g_heff_2esyntax_2eformat_2estrsEq(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
    } else {
      heff_drop_rec(v_a_242, 3);
      heff_drop_rec(v_b_243, 3);
      heff_drop(v_t_246);
      v_x1_247 = NTAG(TAG_False);
    }
    V v_t_248 = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
    heff_drop(v_x1_247);
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_src_240);
      heff_drop(v_out_241);
      heff_drop(v_t_248);
      return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2esyntax_2eformat_2esameMeaning_str1)});
    } else {
      heff_drop(v_t_248);
      V v_t_249 = (g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_src_2410 = heff_get_n(v_t_249, 2, 3);
      V v_t_2411 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      V v_t_2412 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_src_2410, v_t_2411, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2413 = (g_list_2emap_24s594167626x1954057348(MK_INT(0LL), heff_get_n(v_t_2412, 2, 3)));
      V v_t_2414 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_out_241), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_src_2415 = heff_get_n(v_t_2414, 2, 3);
      V v_t_2416 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      V v_t_2417 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_src_2415, v_t_2416, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2418 = (g_list_2emap_24s594167626x1954057348(MK_INT(0LL), heff_get_n(v_t_2417, 2, 3)));
      V v_x1_2419 = ({ V a_0 = v_t_2413; V a_1 = v_t_2418; V r_ = (g_heff_2esyntax_2eformat_2estrsEq(a_0, a_1)); heff_drop(v_t_2413); heff_drop(v_t_2418); r_; });
      if ((heff_dup(v_x1_2419) == NTAG(TAG_True))) {
        heff_drop(v_x1_2419);
        return heff_tag_n(TAG_Right, 1, (V[]){v_out_241});
      } else {
        heff_drop(v_out_241);
        heff_drop(v_x1_2419);
        return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2esyntax_2eformat_2esameMeaning_str2)});
      }
    }
  }
}
V g_heff_2esyntax_2eformat_2esameMeaning_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2esameMeaning(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2eformat_str0, 0, "");
Clo g_heff_2esyntax_2eformat_2eformat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2eformat_entry, 1, 0};

V g_heff_2esyntax_2eformat_2eformat(V v_src_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_240), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_src_242 = heff_get_n(v_t_241, 2, 3);
  V v_t_243 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_244 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_src_242, v_t_243, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_ts_245 = heff_arrayFromList(heff_get_n(v_t_244, 0, 3));
  V v_t_246 = (g_heff_2esyntax_2esurface_2efixDecls(v_ts_245, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_247 = (g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(((V)&g_heff_2esyntax_2eformat_2eformat_str0), v_t_246));
  V v_f_248 = heff_get_n(v_t_247, 0, 2);
  V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(v_f_248, heff_dup(v_src_240)));
  switch (heff_tag_of(v_t_249)) {
  case TAG_Left: {
    V v_why_2410 = heff_field(v_t_249, 0);
    V v_ru_24t_249_24Left = heff_take_reuse_n(v_t_249, 1ULL, 1);
    heff_drop(v_src_240);
    return heff_tag_at_n(v_ru_24t_249_24Left, TAG_Left, 1, (V[]){v_why_2410});
  }
  case TAG_Right: {
    V v_out_2411 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    V v_t_2412 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_240), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2413 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2412));
    V v_t_2414 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_out_2411), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2415 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2414));
    return (g_heff_2esyntax_2eformat_2esameMeaning(v_src_240, v_out_2411, v_t_2413, v_t_2415));
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2esyntax_2eformat_2eformat_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2eformat(a[0]);
}