// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ImplicitParam 51130
#define TAG_IntWord 51777
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_PatAs 19989
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_RuneWord 42901
#define TAG_SetField 47531
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StringWord 15530
#define TAG_TagVariant 25174
#define TAG_TypeWord 10401
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_cmt 308164
#define LBL_comments 142722952
#define LBL_decl 9574769
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_err 310239
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_i 323
#define LBL_imports 10411951
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_text 10052084
#define LBL_tok 324554
#define LBL_tokens 1078955205
static uint32_t shape_e__decl[] = {LBL_e, LBL_decl};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_imports__decls__diags[] = {LBL_imports, LBL_decls, LBL_diags};
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn_clo;
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2eformat_2eformat(V);
V g_heff_2esyntax_2eformat_2eformat_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eformat_clo;
V g_heff_2esyntax_2eformat_2ekeyDeclF(V, V);
V g_heff_2esyntax_2eformat_2ekeyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyDeclF_clo;
V g_heff_2esyntax_2eformat_2ekeyTermF(V, V);
V g_heff_2esyntax_2eformat_2ekeyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyTermF_clo;
V g_heff_2esyntax_2eformat_2ekeys_get(void);
V g_heff_2esyntax_2eformat_2emeaningFrom(V);
V g_heff_2esyntax_2eformat_2emeaningFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2emeaningFrom_clo;
V g_heff_2esyntax_2eformat_2eparamKey(V, V);
V g_heff_2esyntax_2eformat_2eparamKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eparamKey_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2eformat_2esameMeaning(V, V, V, V);
V g_heff_2esyntax_2eformat_2esameMeaning_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2esameMeaning_clo;
V g_heff_2esyntax_2eformat_2estrsEq(V, V);
V g_heff_2esyntax_2eformat_2estrsEq_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2estrsEq_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_clo;
V g_heff_2esyntax_2esurface_2ereadLexed_24s1088510898x79166857(V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_24s1088510898x79166857_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_24s1088510898x79166857_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1195846327x230486685(V, V, V, V, V, V, V);
V g_list_2emap_24s1195846327x230486685_entry(V self, V *a);
extern Clo g_list_2emap_24s1195846327x230486685_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_list_2emap_24s1561756891x1126436879(V);
V g_list_2emap_24s1561756891x1126436879_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_clo;
V g_list_2emap_24s1602529591x1809288035(V);
V g_list_2emap_24s1602529591x1809288035_entry(V self, V *a);
extern Clo g_list_2emap_24s1602529591x1809288035_clo;
V g_list_2emap_24s424270175x1918189508(V);
V g_list_2emap_24s424270175x1918189508_entry(V self, V *a);
extern Clo g_list_2emap_24s424270175x1918189508_clo;
V g_list_2emap_24s953916415x1126219438(V, V);
V g_list_2emap_24s953916415x1126219438_entry(V self, V *a);
extern Clo g_list_2emap_24s953916415x1126219438_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str0, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str1, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str2, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str3, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str4, 3, (118, 97, 114));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str5, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str6, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str7, 2, (44, 32));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str8, 1, (91));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str9, 1, (93));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str10, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str11, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str12, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str13, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str14, 3, (116, 97, 103));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str15, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str16, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str17, 2, (44, 32));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str18, 1, (91));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str19, 1, (93));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str20, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str21, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str22, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str23, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str24, 2, (111, 112));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str25, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str26, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str27, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str28, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str29, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str30, 3, (105, 110, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str31, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str32, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str33, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str34, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str35, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str36, 5, (102, 108, 111, 97, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str37, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str38, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str39, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str40, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str41, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str42, 6, (115, 116, 114, 105, 110, 103));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str43, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str44, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str45, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str46, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str47, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str48, 4, (114, 117, 110, 101));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str49, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str50, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str51, 5, (102, 105, 101, 108, 100));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str52, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str53, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str54, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str55, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str56, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str57, 2, (44, 32));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str58, 1, (91));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str59, 1, (93));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str60, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str61, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str62, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str63, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str64, 6, (114, 101, 99, 111, 114, 100));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str65, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str66, 4, (84, 121, 112, 101));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str67, 3, (73, 110, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str68, 5, (70, 108, 111, 97, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str69, 6, (83, 116, 114, 105, 110, 103));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str70, 4, (82, 117, 110, 101));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str71, 5, (65, 114, 114, 97, 121));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str72, 7, (97, 98, 97, 110, 100, 111, 110));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str73, 4, (73, 110, 116, 56));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str74, 5, (73, 110, 116, 49, 54));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str75, 5, (73, 110, 116, 51, 50));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str76, 5, (73, 110, 116, 54, 52));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str77, 5, (85, 73, 110, 116, 56));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str78, 6, (85, 73, 110, 116, 49, 54));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str79, 6, (85, 73, 110, 116, 51, 50));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str80, 6, (85, 73, 110, 116, 54, 52));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str81, 7, (70, 108, 111, 97, 116, 51, 50));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str82, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str83, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str84, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str85, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str86, 4, (119, 111, 114, 100));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str87, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str88, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str89, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str90, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str91, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str92, 2, (97, 115));
HEFF_STRA(g_heff_2esyntax_2eformat_2epatKey_str93, 1, (41));
Clo g_heff_2esyntax_2eformat_2epatKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2epatKey_entry, 1, 0};

V g_heff_2esyntax_2eformat_2epatKey(V v_p_240) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_x_241 = heff_field(v_p_240, 0);
    heff_take_n(v_p_240, 1ULL, 2);
    v_t_243 = v_x_241;
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_PatVar: {
    V v_x_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
    V v_x2_246 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str0), v_t_245));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str3), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str4), heff_strAppend(v_t_249, ((V)&g_heff_2esyntax_2eformat_2epatKey_str5))));
  }
  case TAG_PatTag: {
    V v_t_2410 = heff_field(v_t_243, 0);
    V v_ps_2412 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    V v_x2_2413 = (g_list_2emap(((V)&g_heff_2esyntax_2eformat_2epatKey_clo), v_ps_2412));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str7); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str8), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2eformat_2epatKey_str9)));
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_parts_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2418});
    V v_x2_2420 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str10), v_parts_2419));
    V v_t_2423;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nil: {
      v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str11);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_xs_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str12); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str13), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str14), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2eformat_2epatKey_str15))));
  }
  case TAG_PatOp: {
    V v_x_2424 = heff_field(v_t_243, 0);
    V v_ps_2426 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    V v_x2_2427 = (g_list_2emap(((V)&g_heff_2esyntax_2eformat_2epatKey_clo), v_ps_2426));
    V v_t_2430;
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nil: {
      v_t_2430 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      V v_xs_2429 = heff_field(v_x2_2427, 1);
      heff_take_n(v_x2_2427, 3ULL, 2);
      v_t_2430 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str17); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2427);
    }
    V v_t_2431 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str18), heff_strAppend(v_t_2430, ((V)&g_heff_2esyntax_2eformat_2epatKey_str19)));
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
    V v_parts_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2424, v_t_2432});
    V v_x2_2434 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str20), v_parts_2433));
    V v_t_2437;
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_Nil: {
      v_t_2437 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str21);
      break;
    }
    case TAG_Cons: {
      V v_x_2435 = heff_field(v_x2_2434, 0);
      V v_xs_2436 = heff_field(v_x2_2434, 1);
      heff_take_n(v_x2_2434, 3ULL, 2);
      v_t_2437 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str22); V a_1 = v_x_2435; V a_2 = v_xs_2436; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2436); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2434);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str23), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str24), heff_strAppend(v_t_2437, ((V)&g_heff_2esyntax_2eformat_2epatKey_str25))));
  }
  case TAG_PatInt: {
    V v_i_2438 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2438), NTAG(TAG_Nil)});
    V v_x2_2440 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str26), v_t_2439));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str27);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str28); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str29), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str30), heff_strAppend(v_t_2443, ((V)&g_heff_2esyntax_2eformat_2epatKey_str31))));
  }
  case TAG_PatFloat: {
    V v_x_2444 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_floatShow(v_x_2444), NTAG(TAG_Nil)});
    V v_x2_2446 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str32), v_t_2445));
    V v_t_2449;
    switch (heff_tag_of(v_x2_2446)) {
    case TAG_Nil: {
      v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str33);
      break;
    }
    case TAG_Cons: {
      V v_x_2447 = heff_field(v_x2_2446, 0);
      V v_xs_2448 = heff_field(v_x2_2446, 1);
      heff_take_n(v_x2_2446, 3ULL, 2);
      v_t_2449 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str34); V a_1 = v_x_2447; V a_2 = v_xs_2448; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2448); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2446);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str35), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str36), heff_strAppend(v_t_2449, ((V)&g_heff_2esyntax_2eformat_2epatKey_str37))));
  }
  case TAG_PatString: {
    V v_x_2450 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2450, NTAG(TAG_Nil)});
    V v_x2_2452 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str38), v_t_2451));
    V v_t_2455;
    switch (heff_tag_of(v_x2_2452)) {
    case TAG_Nil: {
      v_t_2455 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str39);
      break;
    }
    case TAG_Cons: {
      V v_x_2453 = heff_field(v_x2_2452, 0);
      V v_xs_2454 = heff_field(v_x2_2452, 1);
      heff_take_n(v_x2_2452, 3ULL, 2);
      v_t_2455 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str40); V a_1 = v_x_2453; V a_2 = v_xs_2454; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2454); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2452);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str41), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str42), heff_strAppend(v_t_2455, ((V)&g_heff_2esyntax_2eformat_2epatKey_str43))));
  }
  case TAG_PatRune: {
    V v_c_2456 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_c_2456), NTAG(TAG_Nil)});
    V v_x2_2458 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str44), v_t_2457));
    V v_t_2461;
    switch (heff_tag_of(v_x2_2458)) {
    case TAG_Nil: {
      v_t_2461 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str45);
      break;
    }
    case TAG_Cons: {
      V v_x_2459 = heff_field(v_x2_2458, 0);
      V v_xs_2460 = heff_field(v_x2_2458, 1);
      heff_take_n(v_x2_2458, 3ULL, 2);
      v_t_2461 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str46); V a_1 = v_x_2459; V a_2 = v_xs_2460; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2460); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2458);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str47), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str48), heff_strAppend(v_t_2461, ((V)&g_heff_2esyntax_2eformat_2epatKey_str49))));
  }
  case TAG_PatRecord: {
    V v_fs_2462 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_x2_2463 = (g_list_2emap_24s1195846327x230486685(((V)&g_heff_2esyntax_2eformat_2epatKey_str50), ((V)&g_heff_2esyntax_2eformat_2epatKey_str51), ((V)&g_heff_2esyntax_2eformat_2epatKey_str52), ((V)&g_heff_2esyntax_2eformat_2epatKey_str53), ((V)&g_heff_2esyntax_2eformat_2epatKey_str54), ((V)&g_heff_2esyntax_2eformat_2epatKey_str55), v_fs_2462));
    V v_t_2466;
    switch (heff_tag_of(v_x2_2463)) {
    case TAG_Nil: {
      v_t_2466 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str56);
      break;
    }
    case TAG_Cons: {
      V v_x_2464 = heff_field(v_x2_2463, 0);
      V v_xs_2465 = heff_field(v_x2_2463, 1);
      heff_take_n(v_x2_2463, 3ULL, 2);
      v_t_2466 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str57); V a_1 = v_x_2464; V a_2 = v_xs_2465; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2465); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2463);
    }
    V v_t_2467 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str58), heff_strAppend(v_t_2466, ((V)&g_heff_2esyntax_2eformat_2epatKey_str59)));
    V v_parts_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
    V v_x2_2469 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str60), v_parts_2468));
    V v_t_2472;
    switch (heff_tag_of(v_x2_2469)) {
    case TAG_Nil: {
      v_t_2472 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str61);
      break;
    }
    case TAG_Cons: {
      V v_x_2470 = heff_field(v_x2_2469, 0);
      V v_xs_2471 = heff_field(v_x2_2469, 1);
      heff_take_n(v_x2_2469, 3ULL, 2);
      v_t_2472 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str62); V a_1 = v_x_2470; V a_2 = v_xs_2471; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2471); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2469);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str63), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str64), heff_strAppend(v_t_2472, ((V)&g_heff_2esyntax_2eformat_2epatKey_str65))));
  }
  case TAG_PatWord: {
    V v_w_2473 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_2475;
    switch (heff_tag_of(v_w_2473)) {
    case TAG_TypeWord: {
      v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str66);
      break;
    }
    case TAG_IntWord: {
      v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str67);
      break;
    }
    case TAG_FloatWord: {
      v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str68);
      break;
    }
    case TAG_StringWord: {
      v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str69);
      break;
    }
    case TAG_RuneWord: {
      v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str70);
      break;
    }
    case TAG_ArrayWord: {
      v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str71);
      break;
    }
    case TAG_AbandonWord: {
      v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str72);
      break;
    }
    case TAG_FixedWord: {
      V v_w_2474 = heff_field(v_w_2473, 0);
      heff_take_n(v_w_2473, 1ULL, 1);
      switch (heff_tag_of(v_w_2474)) {
      case TAG_I8: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str73);
        break;
      }
      case TAG_I16: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str74);
        break;
      }
      case TAG_I32: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str75);
        break;
      }
      case TAG_I64: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str76);
        break;
      }
      case TAG_U8: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str77);
        break;
      }
      case TAG_U16: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str78);
        break;
      }
      case TAG_U32: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str79);
        break;
      }
      case TAG_U64: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str80);
        break;
      }
      case TAG_F32: {
        v_t_2475 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str81);
        break;
      }
      default: heff_nomatch(v_w_2474);
      }
      break;
    }
    default: heff_nomatch(v_w_2473);
    }
    V v_parts_2476 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2475, NTAG(TAG_Nil)});
    V v_x2_2477 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str82), v_parts_2476));
    V v_t_2480;
    switch (heff_tag_of(v_x2_2477)) {
    case TAG_Nil: {
      v_t_2480 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str83);
      break;
    }
    case TAG_Cons: {
      V v_x_2478 = heff_field(v_x2_2477, 0);
      V v_xs_2479 = heff_field(v_x2_2477, 1);
      heff_take_n(v_x2_2477, 3ULL, 2);
      v_t_2480 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str84); V a_1 = v_x_2478; V a_2 = v_xs_2479; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2479); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2477);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str85), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str86), heff_strAppend(v_t_2480, ((V)&g_heff_2esyntax_2eformat_2epatKey_str87))));
  }
  case TAG_PatAs: {
    V v_x_2481 = heff_field(v_t_243, 0);
    V v_q_2483 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 5ULL, 3);
    V v_t_2484 = (g_heff_2esyntax_2eformat_2epatKey(v_q_2483));
    V v_t_2485 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
    V v_parts_2486 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2481, v_t_2485});
    V v_x2_2487 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2epatKey_str88), v_parts_2486));
    V v_t_2490;
    switch (heff_tag_of(v_x2_2487)) {
    case TAG_Nil: {
      v_t_2490 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str89);
      break;
    }
    case TAG_Cons: {
      V v_x_2488 = heff_field(v_x2_2487, 0);
      V v_xs_2489 = heff_field(v_x2_2487, 1);
      heff_take_n(v_x2_2487, 3ULL, 2);
      v_t_2490 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str90); V a_1 = v_x_2488; V a_2 = v_xs_2489; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2489); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2487);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str91), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str92), heff_strAppend(v_t_2490, ((V)&g_heff_2esyntax_2eformat_2epatKey_str93))));
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2epatKey(a[0]);
}
HEFF_STRA(g_heff_2esyntax_2eformat_2eparamKey_str0, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2eparamKey_str1, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2eparamKey_str2, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2eparamKey_str3, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2eparamKey_str4, 8, (101, 120, 112, 108, 105, 99, 105, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2eparamKey_str5, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2eparamKey_str6, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2eparamKey_str7, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2eparamKey_str8, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2eparamKey_str9, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2eparamKey_str10, 8, (105, 109, 112, 108, 105, 99, 105, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2eparamKey_str11, 1, (41));
Clo g_heff_2esyntax_2eformat_2eparamKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2eparamKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2eparamKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_t_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_247 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_246}));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_248});
      V v_x2_2410 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2eparamKey_str0), v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str3), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str4), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2eformat_2eparamKey_str5))));
    }
    case TAG_ImplicitParam: {
      V v_x_2414 = heff_field(v_x21_242, 0);
      V v_t_2416 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_2417 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2416}));
      V v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      V v_parts_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2414, v_t_2418});
      V v_x2_2420 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2eparamKey_str6), v_parts_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eparamKey_str8); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str9), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eparamKey_str10), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2eformat_2eparamKey_str11))));
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2eparamKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2eparamKey(a[0], a[1]);
}
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str0, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str1, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str2, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str3, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str4, 3, (118, 97, 114));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str5, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str6, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str7, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str8, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str9, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str10, 8, (105, 109, 112, 108, 105, 99, 105, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str11, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str12, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str13, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str14, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str15, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str16, 3, (116, 97, 103));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str17, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str18, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str19, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str20, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str21, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str22, 3, (105, 110, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str23, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str24, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str25, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str26, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str27, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str28, 5, (102, 108, 111, 97, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str29, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str30, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str31, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str32, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str33, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str34, 6, (115, 116, 114, 105, 110, 103));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str35, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str36, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str37, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str38, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str39, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str40, 4, (114, 117, 110, 101));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str41, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str42, 4, (84, 121, 112, 101));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str43, 3, (73, 110, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str44, 5, (70, 108, 111, 97, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str45, 6, (83, 116, 114, 105, 110, 103));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str46, 4, (82, 117, 110, 101));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str47, 5, (65, 114, 114, 97, 121));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str48, 7, (97, 98, 97, 110, 100, 111, 110));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str49, 4, (73, 110, 116, 56));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str50, 5, (73, 110, 116, 49, 54));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str51, 5, (73, 110, 116, 51, 50));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str52, 5, (73, 110, 116, 54, 52));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str53, 5, (85, 73, 110, 116, 56));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str54, 6, (85, 73, 110, 116, 49, 54));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str55, 6, (85, 73, 110, 116, 51, 50));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str56, 6, (85, 73, 110, 116, 54, 52));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str57, 7, (70, 108, 111, 97, 116, 51, 50));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str58, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str59, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str60, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str61, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str62, 4, (119, 111, 114, 100));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str63, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str64, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str65, 2, (44, 32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str66, 1, (91));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str67, 1, (93));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str68, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str69, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str70, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str71, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str72, 3, (97, 112, 112));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str73, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str74, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str75, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str76, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str77, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str78, 7, (112, 114, 111, 106, 101, 99, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str79, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str80, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str81, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str82, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str83, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str84, 5, (110, 97, 109, 101, 100));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str85, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str86, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str87, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str88, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str89, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str90, 5, (110, 97, 109, 101, 100));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str91, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str92, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str93, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str94, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str95, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str96, 8, (105, 109, 112, 108, 105, 99, 105, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str97, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str98, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str99, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str100, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str101, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str102, 8, (105, 109, 112, 108, 105, 99, 105, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str103, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str104, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str105, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str106, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str107, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str108, 8, (105, 110, 115, 116, 97, 110, 99, 101));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str109, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str110, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str111, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str112, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str113, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str114, 4, (97, 110, 111, 110));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str115, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str116, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str117, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str118, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str119, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str120, 2, (112, 105));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str121, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str122, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str123, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str124, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str125, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str126, 4, (110, 97, 109, 101));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str127, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str128, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str129, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str130, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str131, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str132, 8, (105, 109, 112, 108, 105, 99, 105, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str133, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str134, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str135, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str136, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str137, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str138, 3, (97, 110, 110));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str139, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str140, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str141, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str142, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str143, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str144, 3, (108, 97, 109));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str145, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str146, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str147, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str148, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str149, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str150, 3, (97, 110, 110));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str151, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str152, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str153, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str154, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str155, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str156, 4, (115, 112, 101, 99));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str157, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str158, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str159, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str160, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str161, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str162, 5, (102, 105, 101, 108, 100));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str163, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str164, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str165, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str166, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str167, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str168, 5, (102, 105, 101, 108, 100));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str169, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str170, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str171, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str172, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str173, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str174, 3, (98, 97, 100));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str175, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str176, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str177, 2, (44, 32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str178, 1, (91));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str179, 1, (93));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str180, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str181, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str182, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str183, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str184, 3, (115, 105, 103));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str185, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str186, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str187, 2, (44, 32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str188, 1, (91));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str189, 1, (93));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str190, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str191, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str192, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str193, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str194, 7, (118, 97, 114, 105, 97, 110, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str195, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str196, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str197, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str198, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str199, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str200, 3, (98, 97, 100));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str201, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str202, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str203, 2, (44, 32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str204, 1, (91));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str205, 1, (93));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str206, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str207, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str208, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str209, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str210, 3, (115, 117, 109));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str211, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str212, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str213, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str214, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str215, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str216, 3, (115, 101, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str217, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str218, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str219, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str220, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str221, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str222, 3, (98, 97, 100));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str223, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str224, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str225, 2, (44, 32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str226, 1, (91));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str227, 1, (93));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str228, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str229, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str230, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str231, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str232, 6, (115, 116, 114, 117, 99, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str233, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str234, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str235, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str236, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str237, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str238, 3, (97, 108, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str239, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str240, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str241, 2, (44, 32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str242, 1, (91));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str243, 1, (93));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str244, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str245, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str246, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str247, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str248, 5, (109, 97, 116, 99, 104));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str249, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str250, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str251, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str252, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str253, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str254, 3, (108, 101, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str255, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str256, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str257, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str258, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str259, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str260, 4, (98, 105, 110, 100));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str261, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str262, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str263, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str264, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str265, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str266, 3, (108, 101, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str267, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str268, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str269, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str270, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str271, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str272, 4, (101, 120, 112, 114));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str273, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str274, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str275, 2, (44, 32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str276, 1, (91));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str277, 1, (93));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str278, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str279, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str280, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str281, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str282, 2, (100, 111));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str283, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str284, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str285, 2, (44, 32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str286, 1, (91));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str287, 1, (93));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str288, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str289, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str290, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str291, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str292, 5, (108, 111, 99, 97, 108));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str293, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str294, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str295, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str296, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str297, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str298, 7, (105, 110, 118, 97, 108, 105, 100));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyTermF_str299, 1, (41));
V g_heff_2esyntax_2eformat_2ekeyTermF_lam0(V self, V *args);
V g_heff_2esyntax_2eformat_2ekeyTermF_lam1(V self, V *args);
V g_heff_2esyntax_2eformat_2ekeyTermF_lam2(V self, V *args);
V g_heff_2esyntax_2eformat_2ekeyTermF_lam3(V self, V *args);
V g_heff_2esyntax_2eformat_2ekeyTermF_lam4(V self, V *args);
Clo g_heff_2esyntax_2eformat_2ekeyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeyTermF_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ekeyTermF(V v_r_240, V v_n_241) {
top: ;
  V v_it_244;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_n_241, 0);
    v_it_244 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_it_244)) {
  case TAG_EVar: {
    V v_x_245 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, NTAG(TAG_Nil)});
    V v_x2_247 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str0), v_t_246));
    V v_t_2410;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nil: {
      v_t_2410 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_xs_249 = heff_field(v_x2_247, 1);
      heff_take_n(v_x2_247, 3ULL, 2);
      v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str3), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str4), heff_strAppend(v_t_2410, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str5))));
  }
  case TAG_EImplicitVar: {
    V v_x_2411 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, NTAG(TAG_Nil)});
    V v_x2_2413 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str6), v_t_2412));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str8); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str9), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str10), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str11))));
  }
  case TAG_ETag: {
    V v_x_2417 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2417, NTAG(TAG_Nil)});
    V v_x2_2419 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str12), v_t_2418));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str13);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str14); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str15), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str16), heff_strAppend(v_t_2422, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str17))));
  }
  case TAG_EInt: {
    V v_i_2423 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_i_2423), NTAG(TAG_Nil)});
    V v_x2_2425 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str18), v_t_2424));
    V v_t_2428;
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nil: {
      v_t_2428 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_xs_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      v_t_2428 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str20); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str21), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str22), heff_strAppend(v_t_2428, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str23))));
  }
  case TAG_EFloat: {
    V v_x_2429 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_floatShow(v_x_2429), NTAG(TAG_Nil)});
    V v_x2_2431 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str24), v_t_2430));
    V v_t_2434;
    switch (heff_tag_of(v_x2_2431)) {
    case TAG_Nil: {
      v_t_2434 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str25);
      break;
    }
    case TAG_Cons: {
      V v_x_2432 = heff_field(v_x2_2431, 0);
      V v_xs_2433 = heff_field(v_x2_2431, 1);
      heff_take_n(v_x2_2431, 3ULL, 2);
      v_t_2434 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str26); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2431);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str27), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str28), heff_strAppend(v_t_2434, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str29))));
  }
  case TAG_EString: {
    V v_x_2435 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2435, NTAG(TAG_Nil)});
    V v_x2_2437 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str30), v_t_2436));
    V v_t_2440;
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_Nil: {
      v_t_2440 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str31);
      break;
    }
    case TAG_Cons: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_xs_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      v_t_2440 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str32); V a_1 = v_x_2438; V a_2 = v_xs_2439; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2439); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2437);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str33), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str34), heff_strAppend(v_t_2440, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str35))));
  }
  case TAG_ERune: {
    V v_c_2441 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_c_2441), NTAG(TAG_Nil)});
    V v_x2_2443 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str36), v_t_2442));
    V v_t_2446;
    switch (heff_tag_of(v_x2_2443)) {
    case TAG_Nil: {
      v_t_2446 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str37);
      break;
    }
    case TAG_Cons: {
      V v_x_2444 = heff_field(v_x2_2443, 0);
      V v_xs_2445 = heff_field(v_x2_2443, 1);
      heff_take_n(v_x2_2443, 3ULL, 2);
      v_t_2446 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str38); V a_1 = v_x_2444; V a_2 = v_xs_2445; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2445); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2443);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str39), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str40), heff_strAppend(v_t_2446, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str41))));
  }
  case TAG_EWord: {
    V v_w_2447 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    V v_t_2449;
    switch (heff_tag_of(v_w_2447)) {
    case TAG_TypeWord: {
      v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str42);
      break;
    }
    case TAG_IntWord: {
      v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str43);
      break;
    }
    case TAG_FloatWord: {
      v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str44);
      break;
    }
    case TAG_StringWord: {
      v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str45);
      break;
    }
    case TAG_RuneWord: {
      v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str46);
      break;
    }
    case TAG_ArrayWord: {
      v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str47);
      break;
    }
    case TAG_AbandonWord: {
      v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str48);
      break;
    }
    case TAG_FixedWord: {
      V v_w_2448 = heff_field(v_w_2447, 0);
      heff_take_n(v_w_2447, 1ULL, 1);
      switch (heff_tag_of(v_w_2448)) {
      case TAG_I8: {
        v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str49);
        break;
      }
      case TAG_I16: {
        v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str50);
        break;
      }
      case TAG_I32: {
        v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str51);
        break;
      }
      case TAG_I64: {
        v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str52);
        break;
      }
      case TAG_U8: {
        v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str53);
        break;
      }
      case TAG_U16: {
        v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str54);
        break;
      }
      case TAG_U32: {
        v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str55);
        break;
      }
      case TAG_U64: {
        v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str56);
        break;
      }
      case TAG_F32: {
        v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str57);
        break;
      }
      default: heff_nomatch(v_w_2448);
      }
      break;
    }
    default: heff_nomatch(v_w_2447);
    }
    V v_parts_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
    V v_x2_2451 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str58), v_parts_2450));
    V v_t_2454;
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_Nil: {
      v_t_2454 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str59);
      break;
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_xs_2453 = heff_field(v_x2_2451, 1);
      heff_take_n(v_x2_2451, 3ULL, 2);
      v_t_2454 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str60); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2451);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str61), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str62), heff_strAppend(v_t_2454, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str63))));
  }
  case TAG_EApp: {
    V v_h_2455 = heff_field(v_it_244, 0);
    V v_args_2456 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24EApp = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_2457 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_2455}));
    V v_x2_2458 = (g_list_2emap(heff_get_n(v_r_240, 0, 2), v_args_2456));
    V v_t_2461;
    switch (heff_tag_of(v_x2_2458)) {
    case TAG_Nil: {
      v_t_2461 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str64);
      break;
    }
    case TAG_Cons: {
      V v_x_2459 = heff_field(v_x2_2458, 0);
      V v_xs_2460 = heff_field(v_x2_2458, 1);
      heff_take_n(v_x2_2458, 3ULL, 2);
      v_t_2461 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str65); V a_1 = v_x_2459; V a_2 = v_xs_2460; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2460); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2458);
    }
    V v_t_2462 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str66), heff_strAppend(v_t_2461, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str67)));
    V v_t_2463 = heff_tag_at_n(v_ru_24it_244_24EApp, TAG_Cons, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
    V v_parts_2464 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, v_t_2463});
    V v_x2_2465 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str68), v_parts_2464));
    V v_t_2468;
    switch (heff_tag_of(v_x2_2465)) {
    case TAG_Nil: {
      v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str69);
      break;
    }
    case TAG_Cons: {
      V v_x_2466 = heff_field(v_x2_2465, 0);
      V v_xs_2467 = heff_field(v_x2_2465, 1);
      heff_take_n(v_x2_2465, 3ULL, 2);
      v_t_2468 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str70); V a_1 = v_x_2466; V a_2 = v_xs_2467; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2467); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2465);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str71), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str72), heff_strAppend(v_t_2468, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str73))));
  }
  case TAG_EProject: {
    V v_x_2469 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2469, NTAG(TAG_Nil)});
    V v_x2_2471 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str74), v_t_2470));
    V v_t_2474;
    switch (heff_tag_of(v_x2_2471)) {
    case TAG_Nil: {
      v_t_2474 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str75);
      break;
    }
    case TAG_Cons: {
      V v_x_2472 = heff_field(v_x2_2471, 0);
      V v_xs_2473 = heff_field(v_x2_2471, 1);
      heff_take_n(v_x2_2471, 3ULL, 2);
      v_t_2474 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str76); V a_1 = v_x_2472; V a_2 = v_xs_2473; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2473); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2471);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str77), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str78), heff_strAppend(v_t_2474, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str79))));
  }
  case TAG_ENamed: {
    V v_x_2475 = heff_field(v_it_244, 0);
    V v_e_2476 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24ENamed = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_2477 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2476}));
    V v_t_2478 = heff_tag_at_n(v_ru_24it_244_24ENamed, TAG_Cons, 2, (V[]){v_t_2477, NTAG(TAG_Nil)});
    V v_parts_2479 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2475, v_t_2478});
    V v_x2_2480 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str80), v_parts_2479));
    V v_t_2483;
    switch (heff_tag_of(v_x2_2480)) {
    case TAG_Nil: {
      v_t_2483 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str81);
      break;
    }
    case TAG_Cons: {
      V v_x_2481 = heff_field(v_x2_2480, 0);
      V v_xs_2482 = heff_field(v_x2_2480, 1);
      heff_take_n(v_x2_2480, 3ULL, 2);
      v_t_2483 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str82); V a_1 = v_x_2481; V a_2 = v_xs_2482; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2482); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2480);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str83), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str84), heff_strAppend(v_t_2483, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str85))));
  }
  case TAG_EPi: {
    V v_b_2484 = heff_field(v_it_244, 0);
    V v_cod_2485 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24EPi = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_24135;
    switch (heff_tag_of(v_b_2484)) {
    case TAG_PiNamed: {
      V v_x_2486 = heff_field(v_b_2484, 0);
      V v_t_2488 = heff_field(v_b_2484, 2);
      heff_take_n(v_b_2484, 5ULL, 3);
      V v_t_2489 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2488}));
      V v_t_2490 = heff_tag_at_n(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_2489, NTAG(TAG_Nil)});
      V v_parts_2491 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2486, v_t_2490});
      V v_x2_2492 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str86), v_parts_2491));
      V v_t_2495;
      switch (heff_tag_of(v_x2_2492)) {
      case TAG_Nil: {
        v_t_2495 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str87);
        break;
      }
      case TAG_Cons: {
        V v_x_2493 = heff_field(v_x2_2492, 0);
        V v_xs_2494 = heff_field(v_x2_2492, 1);
        heff_take_n(v_x2_2492, 3ULL, 2);
        v_t_2495 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str88); V a_1 = v_x_2493; V a_2 = v_xs_2494; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2494); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2492);
      }
      v_t_24135 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str89), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str90), heff_strAppend(v_t_2495, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str91))));
      break;
    }
    case TAG_PiImplicit: {
      V v_x_2496 = heff_field(v_b_2484, 0);
      V v_t_2499 = heff_field(v_b_2484, 3);
      V v_it5_24100 = heff_field(v_b_2484, 4);
      heff_take_n(v_b_2484, 25ULL, 5);
      switch (heff_tag_of(v_it5_24100)) {
      case TAG_Nothing: {
        V v_t_24101 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2499}));
        V v_t_24102 = heff_tag_at_n(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_24101, NTAG(TAG_Nil)});
        V v_parts_24103 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2496, v_t_24102});
        V v_x2_24104 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str92), v_parts_24103));
        V v_t_24107;
        switch (heff_tag_of(v_x2_24104)) {
        case TAG_Nil: {
          v_t_24107 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str93);
          break;
        }
        case TAG_Cons: {
          V v_x_24105 = heff_field(v_x2_24104, 0);
          V v_xs_24106 = heff_field(v_x2_24104, 1);
          heff_take_n(v_x2_24104, 3ULL, 2);
          v_t_24107 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str94); V a_1 = v_x_24105; V a_2 = v_xs_24106; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24106); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24104);
        }
        v_t_24135 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str95), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str96), heff_strAppend(v_t_24107, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str97))));
        break;
      }
      case TAG_Just: {
        V v_d_24108 = heff_field(v_it5_24100, 0);
        heff_take_n(v_it5_24100, 1ULL, 1);
        V v_t_24109 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2499}));
        V v_t_24110 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_d_24108}));
        V v_t_24111 = heff_tag_at_n(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_24110, NTAG(TAG_Nil)});
        V v_parts_24112 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2496, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24109, v_t_24111})});
        V v_x2_24113 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str98), v_parts_24112));
        V v_t_24116;
        switch (heff_tag_of(v_x2_24113)) {
        case TAG_Nil: {
          v_t_24116 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str99);
          break;
        }
        case TAG_Cons: {
          V v_x_24114 = heff_field(v_x2_24113, 0);
          V v_xs_24115 = heff_field(v_x2_24113, 1);
          heff_take_n(v_x2_24113, 3ULL, 2);
          v_t_24116 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str100); V a_1 = v_x_24114; V a_2 = v_xs_24115; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24115); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24113);
        }
        v_t_24135 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str101), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str102), heff_strAppend(v_t_24116, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str103))));
        break;
      }
      default: heff_nomatch(v_it5_24100);
      }
      break;
    }
    case TAG_PiInstance: {
      V v_x_24117 = heff_field(v_b_2484, 0);
      V v_t_24120 = heff_field(v_b_2484, 3);
      heff_take_n(v_b_2484, 9ULL, 4);
      V v_t_24121 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_24120}));
      V v_t_24122 = heff_tag_at_n(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_24121, NTAG(TAG_Nil)});
      V v_parts_24123 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24117, v_t_24122});
      V v_x2_24124 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str104), v_parts_24123));
      V v_t_24127;
      switch (heff_tag_of(v_x2_24124)) {
      case TAG_Nil: {
        v_t_24127 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str105);
        break;
      }
      case TAG_Cons: {
        V v_x_24125 = heff_field(v_x2_24124, 0);
        V v_xs_24126 = heff_field(v_x2_24124, 1);
        heff_take_n(v_x2_24124, 3ULL, 2);
        v_t_24127 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str106); V a_1 = v_x_24125; V a_2 = v_xs_24126; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24126); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24124);
      }
      v_t_24135 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str107), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str108), heff_strAppend(v_t_24127, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str109))));
      break;
    }
    case TAG_PiAnon: {
      V v_t_24128 = heff_field(v_b_2484, 0);
      heff_take_n(v_b_2484, 1ULL, 1);
      V v_t_24129 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_24128}));
      V v_parts_24130 = heff_tag_at_n(v_ru_24it_244_24EPi, TAG_Cons, 2, (V[]){v_t_24129, NTAG(TAG_Nil)});
      V v_x2_24131 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str110), v_parts_24130));
      V v_t_24134;
      switch (heff_tag_of(v_x2_24131)) {
      case TAG_Nil: {
        v_t_24134 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str111);
        break;
      }
      case TAG_Cons: {
        V v_x_24132 = heff_field(v_x2_24131, 0);
        V v_xs_24133 = heff_field(v_x2_24131, 1);
        heff_take_n(v_x2_24131, 3ULL, 2);
        v_t_24134 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str112); V a_1 = v_x_24132; V a_2 = v_xs_24133; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24133); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24131);
      }
      v_t_24135 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str113), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str114), heff_strAppend(v_t_24134, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str115))));
      break;
    }
    default: heff_nomatch(v_b_2484);
    }
    V v_t_24136 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_cod_2485}));
    V v_t_24137 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24136, NTAG(TAG_Nil)});
    V v_parts_24138 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24135, v_t_24137});
    V v_x2_24139 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str116), v_parts_24138));
    V v_t_24142;
    switch (heff_tag_of(v_x2_24139)) {
    case TAG_Nil: {
      v_t_24142 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str117);
      break;
    }
    case TAG_Cons: {
      V v_x_24140 = heff_field(v_x2_24139, 0);
      V v_xs_24141 = heff_field(v_x2_24139, 1);
      heff_take_n(v_x2_24139, 3ULL, 2);
      v_t_24142 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str118); V a_1 = v_x_24140; V a_2 = v_xs_24141; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24141); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24139);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str119), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str120), heff_strAppend(v_t_24142, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str121))));
  }
  case TAG_ELam: {
    V v_b_24143 = heff_field(v_it_244, 0);
    V v_body_24144 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24ELam = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_24169;
    switch (heff_tag_of(v_b_24143)) {
    case TAG_LamName: {
      V v_x_24145 = heff_field(v_b_24143, 0);
      heff_take_n(v_b_24143, 1ULL, 2);
      V v_t_24147 = heff_tag_at_n(v_ru_24it_244_24ELam, TAG_Cons, 2, (V[]){v_x_24145, NTAG(TAG_Nil)});
      V v_x2_24148 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str122), v_t_24147));
      V v_t_24151;
      switch (heff_tag_of(v_x2_24148)) {
      case TAG_Nil: {
        v_t_24151 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str123);
        break;
      }
      case TAG_Cons: {
        V v_x_24149 = heff_field(v_x2_24148, 0);
        V v_xs_24150 = heff_field(v_x2_24148, 1);
        heff_take_n(v_x2_24148, 3ULL, 2);
        v_t_24151 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str124); V a_1 = v_x_24149; V a_2 = v_xs_24150; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24150); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24148);
      }
      v_t_24169 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str125), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str126), heff_strAppend(v_t_24151, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str127))));
      break;
    }
    case TAG_LamImplicit: {
      V v_x_24152 = heff_field(v_b_24143, 0);
      heff_take_n(v_b_24143, 1ULL, 2);
      V v_t_24154 = heff_tag_at_n(v_ru_24it_244_24ELam, TAG_Cons, 2, (V[]){v_x_24152, NTAG(TAG_Nil)});
      V v_x2_24155 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str128), v_t_24154));
      V v_t_24158;
      switch (heff_tag_of(v_x2_24155)) {
      case TAG_Nil: {
        v_t_24158 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str129);
        break;
      }
      case TAG_Cons: {
        V v_x_24156 = heff_field(v_x2_24155, 0);
        V v_xs_24157 = heff_field(v_x2_24155, 1);
        heff_take_n(v_x2_24155, 3ULL, 2);
        v_t_24158 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str130); V a_1 = v_x_24156; V a_2 = v_xs_24157; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24157); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24155);
      }
      v_t_24169 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str131), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str132), heff_strAppend(v_t_24158, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str133))));
      break;
    }
    case TAG_LamAnn: {
      V v_x_24159 = heff_field(v_b_24143, 0);
      V v_t_24161 = heff_field(v_b_24143, 2);
      heff_take_n(v_b_24143, 5ULL, 3);
      V v_t_24162 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_24161}));
      V v_t_24163 = heff_tag_at_n(v_ru_24it_244_24ELam, TAG_Cons, 2, (V[]){v_t_24162, NTAG(TAG_Nil)});
      V v_parts_24164 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24159, v_t_24163});
      V v_x2_24165 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str134), v_parts_24164));
      V v_t_24168;
      switch (heff_tag_of(v_x2_24165)) {
      case TAG_Nil: {
        v_t_24168 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str135);
        break;
      }
      case TAG_Cons: {
        V v_x_24166 = heff_field(v_x2_24165, 0);
        V v_xs_24167 = heff_field(v_x2_24165, 1);
        heff_take_n(v_x2_24165, 3ULL, 2);
        v_t_24168 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str136); V a_1 = v_x_24166; V a_2 = v_xs_24167; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24167); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24165);
      }
      v_t_24169 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str137), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str138), heff_strAppend(v_t_24168, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str139))));
      break;
    }
    default: heff_nomatch(v_b_24143);
    }
    V v_t_24170 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_24144}));
    V v_t_24171 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24170, NTAG(TAG_Nil)});
    V v_parts_24172 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24169, v_t_24171});
    V v_x2_24173 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str140), v_parts_24172));
    V v_t_24176;
    switch (heff_tag_of(v_x2_24173)) {
    case TAG_Nil: {
      v_t_24176 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str141);
      break;
    }
    case TAG_Cons: {
      V v_x_24174 = heff_field(v_x2_24173, 0);
      V v_xs_24175 = heff_field(v_x2_24173, 1);
      heff_take_n(v_x2_24173, 3ULL, 2);
      v_t_24176 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str142); V a_1 = v_x_24174; V a_2 = v_xs_24175; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24175); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24173);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str143), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str144), heff_strAppend(v_t_24176, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str145))));
  }
  case TAG_EAnn: {
    V v_e_24177 = heff_field(v_it_244, 0);
    V v_t_24178 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24EAnn = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_24179 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24177}));
    V v_t_24180 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_24178}));
    V v_t_24181 = heff_tag_at_n(v_ru_24it_244_24EAnn, TAG_Cons, 2, (V[]){v_t_24180, NTAG(TAG_Nil)});
    V v_parts_24182 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24179, v_t_24181});
    V v_x2_24183 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str146), v_parts_24182));
    V v_t_24186;
    switch (heff_tag_of(v_x2_24183)) {
    case TAG_Nil: {
      v_t_24186 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str147);
      break;
    }
    case TAG_Cons: {
      V v_x_24184 = heff_field(v_x2_24183, 0);
      V v_xs_24185 = heff_field(v_x2_24183, 1);
      heff_take_n(v_x2_24183, 3ULL, 2);
      v_t_24186 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str148); V a_1 = v_x_24184; V a_2 = v_xs_24185; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24185); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24183);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str149), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str150), heff_strAppend(v_t_24186, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str151))));
  }
  case TAG_ESpec: {
    V v_acc_24187 = heff_field(v_it_244, 0);
    V v_x_24188 = heff_field(v_it_244, 1);
    V v_v_24190 = heff_field(v_it_244, 3);
    heff_take_n(v_it_244, 11ULL, 4);
    V v_t_24191 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_acc_24187}));
    V v_t_24192 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_24190}));
    V v_t_24193 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24192, NTAG(TAG_Nil)});
    V v_parts_24194 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24191, heff_tag_n(TAG_Cons, 2, (V[]){v_x_24188, v_t_24193})});
    V v_x2_24195 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str152), v_parts_24194));
    V v_t_24198;
    switch (heff_tag_of(v_x2_24195)) {
    case TAG_Nil: {
      v_t_24198 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str153);
      break;
    }
    case TAG_Cons: {
      V v_x_24196 = heff_field(v_x2_24195, 0);
      V v_xs_24197 = heff_field(v_x2_24195, 1);
      heff_take_n(v_x2_24195, 3ULL, 2);
      v_t_24198 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str154); V a_1 = v_x_24196; V a_2 = v_xs_24197; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24197); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24195);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str155), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str156), heff_strAppend(v_t_24198, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str157))));
  }
  case TAG_ESig: {
    V v_fs_24199 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    V v_x2_24230 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eformat_2ekeyTermF_lam0, 1, 1, (V[]){v_r_240}), v_fs_24199));
    V v_t_24233;
    switch (heff_tag_of(v_x2_24230)) {
    case TAG_Nil: {
      v_t_24233 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str176);
      break;
    }
    case TAG_Cons: {
      V v_x_24231 = heff_field(v_x2_24230, 0);
      V v_xs_24232 = heff_field(v_x2_24230, 1);
      heff_take_n(v_x2_24230, 3ULL, 2);
      v_t_24233 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str177); V a_1 = v_x_24231; V a_2 = v_xs_24232; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24232); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24230);
    }
    V v_t_24234 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str178), heff_strAppend(v_t_24233, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str179)));
    V v_parts_24235 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24234, NTAG(TAG_Nil)});
    V v_x2_24236 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str180), v_parts_24235));
    V v_t_24239;
    switch (heff_tag_of(v_x2_24236)) {
    case TAG_Nil: {
      v_t_24239 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str181);
      break;
    }
    case TAG_Cons: {
      V v_x_24237 = heff_field(v_x2_24236, 0);
      V v_xs_24238 = heff_field(v_x2_24236, 1);
      heff_take_n(v_x2_24236, 3ULL, 2);
      v_t_24239 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str182); V a_1 = v_x_24237; V a_2 = v_xs_24238; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24238); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24236);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str183), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str184), heff_strAppend(v_t_24239, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str185))));
  }
  case TAG_ESum: {
    V v_vs_24240 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    V v_x2_24265 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eformat_2ekeyTermF_lam1, 1, 1, (V[]){v_r_240}), v_vs_24240));
    V v_t_24268;
    switch (heff_tag_of(v_x2_24265)) {
    case TAG_Nil: {
      v_t_24268 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str202);
      break;
    }
    case TAG_Cons: {
      V v_x_24266 = heff_field(v_x2_24265, 0);
      V v_xs_24267 = heff_field(v_x2_24265, 1);
      heff_take_n(v_x2_24265, 3ULL, 2);
      v_t_24268 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str203); V a_1 = v_x_24266; V a_2 = v_xs_24267; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24267); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24265);
    }
    V v_t_24269 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str204), heff_strAppend(v_t_24268, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str205)));
    V v_parts_24270 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24269, NTAG(TAG_Nil)});
    V v_x2_24271 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str206), v_parts_24270));
    V v_t_24274;
    switch (heff_tag_of(v_x2_24271)) {
    case TAG_Nil: {
      v_t_24274 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str207);
      break;
    }
    case TAG_Cons: {
      V v_x_24272 = heff_field(v_x2_24271, 0);
      V v_xs_24273 = heff_field(v_x2_24271, 1);
      heff_take_n(v_x2_24271, 3ULL, 2);
      v_t_24274 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str208); V a_1 = v_x_24272; V a_2 = v_xs_24273; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24273); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24271);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str209), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str210), heff_strAppend(v_t_24274, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str211))));
  }
  case TAG_EStruct: {
    V v_fs_24275 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    V v_x2_24296 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eformat_2ekeyTermF_lam2, 1, 1, (V[]){v_r_240}), v_fs_24275));
    V v_t_24299;
    switch (heff_tag_of(v_x2_24296)) {
    case TAG_Nil: {
      v_t_24299 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str224);
      break;
    }
    case TAG_Cons: {
      V v_x_24297 = heff_field(v_x2_24296, 0);
      V v_xs_24298 = heff_field(v_x2_24296, 1);
      heff_take_n(v_x2_24296, 3ULL, 2);
      v_t_24299 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str225); V a_1 = v_x_24297; V a_2 = v_xs_24298; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24298); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24296);
    }
    V v_t_24300 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str226), heff_strAppend(v_t_24299, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str227)));
    V v_parts_24301 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24300, NTAG(TAG_Nil)});
    V v_x2_24302 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str228), v_parts_24301));
    V v_t_24305;
    switch (heff_tag_of(v_x2_24302)) {
    case TAG_Nil: {
      v_t_24305 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str229);
      break;
    }
    case TAG_Cons: {
      V v_x_24303 = heff_field(v_x2_24302, 0);
      V v_xs_24304 = heff_field(v_x2_24302, 1);
      heff_take_n(v_x2_24302, 3ULL, 2);
      v_t_24305 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str230); V a_1 = v_x_24303; V a_2 = v_xs_24304; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24304); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24302);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str231), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str232), heff_strAppend(v_t_24305, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str233))));
  }
  case TAG_EMatch: {
    V v_s_24306 = heff_field(v_it_244, 0);
    V v_alts_24307 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24EMatch = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_24308 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24306}));
    V v_x2_24322 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eformat_2ekeyTermF_lam3, 1, 1, (V[]){v_r_240}), v_alts_24307));
    V v_t_24325;
    switch (heff_tag_of(v_x2_24322)) {
    case TAG_Nil: {
      v_t_24325 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str240);
      break;
    }
    case TAG_Cons: {
      V v_x_24323 = heff_field(v_x2_24322, 0);
      V v_xs_24324 = heff_field(v_x2_24322, 1);
      heff_take_n(v_x2_24322, 3ULL, 2);
      v_t_24325 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str241); V a_1 = v_x_24323; V a_2 = v_xs_24324; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24324); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24322);
    }
    V v_t_24326 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str242), heff_strAppend(v_t_24325, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str243)));
    V v_t_24327 = heff_tag_at_n(v_ru_24it_244_24EMatch, TAG_Cons, 2, (V[]){v_t_24326, NTAG(TAG_Nil)});
    V v_parts_24328 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24308, v_t_24327});
    V v_x2_24329 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str244), v_parts_24328));
    V v_t_24332;
    switch (heff_tag_of(v_x2_24329)) {
    case TAG_Nil: {
      v_t_24332 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str245);
      break;
    }
    case TAG_Cons: {
      V v_x_24330 = heff_field(v_x2_24329, 0);
      V v_xs_24331 = heff_field(v_x2_24329, 1);
      heff_take_n(v_x2_24329, 3ULL, 2);
      v_t_24332 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str246); V a_1 = v_x_24330; V a_2 = v_xs_24331; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24331); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24329);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str247), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str248), heff_strAppend(v_t_24332, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str249))));
  }
  case TAG_ELetIn: {
    V v_rhs_24333 = heff_field(v_it_244, 0);
    V v_it2_24334 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24ELetIn = heff_take_reuse_n(v_it_244, 3ULL, 2);
    switch (heff_tag_of(v_it2_24334)) {
    case TAG_At: {
      V v_it21_24335 = heff_field(v_it2_24334, 0);
      V v_ru_24it2_24334_24At = heff_take_reuse_n(v_it2_24334, 1ULL, 2);
      switch (heff_tag_of(v_it21_24335)) {
      case TAG_MkAlt: {
        V v_p_24337 = heff_field(v_it21_24335, 0);
        V v_e_24338 = heff_field(v_it21_24335, 1);
        heff_take_n(v_it21_24335, 3ULL, 2);
        V v_t_24339 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_24333}));
        V v_t_24340 = (g_heff_2esyntax_2eformat_2epatKey(v_p_24337));
        V v_t_24341 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24338}));
        V v_t_24342 = heff_tag_at_n(v_ru_24it_244_24ELetIn, TAG_Cons, 2, (V[]){v_t_24341, NTAG(TAG_Nil)});
        V v_parts_24343 = heff_tag_at_n(v_ru_24it2_24334_24At, TAG_Cons, 2, (V[]){v_t_24339, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24340, v_t_24342})});
        V v_x2_24344 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str250), v_parts_24343));
        V v_t_24347;
        switch (heff_tag_of(v_x2_24344)) {
        case TAG_Nil: {
          v_t_24347 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str251);
          break;
        }
        case TAG_Cons: {
          V v_x_24345 = heff_field(v_x2_24344, 0);
          V v_xs_24346 = heff_field(v_x2_24344, 1);
          heff_take_n(v_x2_24344, 3ULL, 2);
          v_t_24347 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str252); V a_1 = v_x_24345; V a_2 = v_xs_24346; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24346); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24344);
        }
        return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str253), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str254), heff_strAppend(v_t_24347, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str255))));
      }
      default: return heff_nomatch(v_it21_24335);
      }
    }
    default: return heff_nomatch(v_it2_24334);
    }
  }
  case TAG_EDo: {
    V v_stmts_24348 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    V v_x2_24379 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eformat_2ekeyTermF_lam4, 1, 1, (V[]){v_r_240}), v_stmts_24348));
    V v_t_24382;
    switch (heff_tag_of(v_x2_24379)) {
    case TAG_Nil: {
      v_t_24382 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str274);
      break;
    }
    case TAG_Cons: {
      V v_x_24380 = heff_field(v_x2_24379, 0);
      V v_xs_24381 = heff_field(v_x2_24379, 1);
      heff_take_n(v_x2_24379, 3ULL, 2);
      v_t_24382 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str275); V a_1 = v_x_24380; V a_2 = v_xs_24381; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24381); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24379);
    }
    V v_t_24383 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str276), heff_strAppend(v_t_24382, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str277)));
    V v_parts_24384 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24383, NTAG(TAG_Nil)});
    V v_x2_24385 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str278), v_parts_24384));
    V v_t_24388;
    switch (heff_tag_of(v_x2_24385)) {
    case TAG_Nil: {
      v_t_24388 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str279);
      break;
    }
    case TAG_Cons: {
      V v_x_24386 = heff_field(v_x2_24385, 0);
      V v_xs_24387 = heff_field(v_x2_24385, 1);
      heff_take_n(v_x2_24385, 3ULL, 2);
      v_t_24388 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str280); V a_1 = v_x_24386; V a_2 = v_xs_24387; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24387); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24385);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str281), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str282), heff_strAppend(v_t_24388, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str283))));
  }
  case TAG_ELocal: {
    V v_body_24389 = heff_field(v_it_244, 0);
    V v_ds_24390 = heff_field(v_it_244, 1);
    V v_ru_24it_244_24ELocal = heff_take_reuse_n(v_it_244, 3ULL, 2);
    V v_t_24391 = heff_tr(heff_apply(heff_take_field(v_r_240, 0), 1, (V[]){v_body_24389}));
    V v_x2_24392 = (g_list_2emap(heff_get_n(v_r_240, 1, 2), v_ds_24390));
    V v_t_24395;
    switch (heff_tag_of(v_x2_24392)) {
    case TAG_Nil: {
      v_t_24395 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str284);
      break;
    }
    case TAG_Cons: {
      V v_x_24393 = heff_field(v_x2_24392, 0);
      V v_xs_24394 = heff_field(v_x2_24392, 1);
      heff_take_n(v_x2_24392, 3ULL, 2);
      v_t_24395 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str285); V a_1 = v_x_24393; V a_2 = v_xs_24394; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24394); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24392);
    }
    V v_t_24396 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str286), heff_strAppend(v_t_24395, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str287)));
    V v_t_24397 = heff_tag_at_n(v_ru_24it_244_24ELocal, TAG_Cons, 2, (V[]){v_t_24396, NTAG(TAG_Nil)});
    V v_parts_24398 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24391, v_t_24397});
    V v_x2_24399 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str288), v_parts_24398));
    V v_t_24402;
    switch (heff_tag_of(v_x2_24399)) {
    case TAG_Nil: {
      v_t_24402 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str289);
      break;
    }
    case TAG_Cons: {
      V v_x_24400 = heff_field(v_x2_24399, 0);
      V v_xs_24401 = heff_field(v_x2_24399, 1);
      heff_take_n(v_x2_24399, 3ULL, 2);
      v_t_24402 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str290); V a_1 = v_x_24400; V a_2 = v_xs_24401; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24401); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24399);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str291), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str292), heff_strAppend(v_t_24402, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str293))));
  }
  case TAG_EInvalid: {
    V v_why_24403 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    V v_t_24404 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_24403, NTAG(TAG_Nil)});
    V v_x2_24405 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str294), v_t_24404));
    V v_t_24408;
    switch (heff_tag_of(v_x2_24405)) {
    case TAG_Nil: {
      v_t_24408 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str295);
      break;
    }
    case TAG_Cons: {
      V v_x_24406 = heff_field(v_x2_24405, 0);
      V v_xs_24407 = heff_field(v_x2_24405, 1);
      heff_take_n(v_x2_24405, 3ULL, 2);
      v_t_24408 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str296); V a_1 = v_x_24406; V a_2 = v_xs_24407; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24407); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24405);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str297), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str298), heff_strAppend(v_t_24408, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str299))));
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2esyntax_2eformat_2ekeyTermF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2eformat_2ekeyTermF(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2esyntax_2eformat_2ekeyTermF_lam0(V self, V *args) {
  V v_f_24200 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_24200)) {
  case TAG_At: {
    V v_it1_24201 = heff_field(v_f_24200, 0);
    V v_ru_24f_24200_24At = heff_take_reuse_n(v_f_24200, 1ULL, 2);
    switch (heff_tag_of(v_it1_24201)) {
    case TAG_DeclareField: {
      V v_x_24203 = heff_field(v_it1_24201, 0);
      V v_t_24205 = heff_field(v_it1_24201, 2);
      V v_it14_24206 = heff_field(v_it1_24201, 3);
      heff_take_n(v_it1_24201, 13ULL, 4);
      switch (heff_tag_of(v_it14_24206)) {
      case TAG_Nothing: {
        V v_t_24207 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_24205}));
        V v_t_24208 = heff_tag_at_n(v_ru_24f_24200_24At, TAG_Cons, 2, (V[]){v_t_24207, NTAG(TAG_Nil)});
        V v_parts_24209 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24203, v_t_24208});
        V v_x2_24210 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str158), v_parts_24209));
        V v_t_24213;
        switch (heff_tag_of(v_x2_24210)) {
        case TAG_Nil: {
          v_t_24213 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str159);
          break;
        }
        case TAG_Cons: {
          V v_x_24211 = heff_field(v_x2_24210, 0);
          V v_xs_24212 = heff_field(v_x2_24210, 1);
          heff_take_n(v_x2_24210, 3ULL, 2);
          v_t_24213 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str160); V a_1 = v_x_24211; V a_2 = v_xs_24212; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24212); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24210);
        }
        return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str161), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str162), heff_strAppend(v_t_24213, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str163))));
      }
      case TAG_Just: {
        V v_d_24214 = heff_field(v_it14_24206, 0);
        heff_take_n(v_it14_24206, 1ULL, 1);
        V v_t_24215 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_24205}));
        V v_t_24216 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_24214}));
        V v_t_24217 = heff_tag_at_n(v_ru_24f_24200_24At, TAG_Cons, 2, (V[]){v_t_24216, NTAG(TAG_Nil)});
        V v_parts_24218 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24203, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24215, v_t_24217})});
        V v_x2_24219 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str164), v_parts_24218));
        V v_t_24222;
        switch (heff_tag_of(v_x2_24219)) {
        case TAG_Nil: {
          v_t_24222 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str165);
          break;
        }
        case TAG_Cons: {
          V v_x_24220 = heff_field(v_x2_24219, 0);
          V v_xs_24221 = heff_field(v_x2_24219, 1);
          heff_take_n(v_x2_24219, 3ULL, 2);
          v_t_24222 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str166); V a_1 = v_x_24220; V a_2 = v_xs_24221; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24221); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24219);
        }
        return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str167), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str168), heff_strAppend(v_t_24222, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str169))));
      }
      default: return heff_nomatch(v_it14_24206);
      }
    }
    case TAG_BadFieldDecl: {
      V v_e_24223 = heff_field(v_it1_24201, 0);
      heff_take_n(v_it1_24201, 1ULL, 1);
      V v_t_24224 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24223}));
      V v_parts_24225 = heff_tag_at_n(v_ru_24f_24200_24At, TAG_Cons, 2, (V[]){v_t_24224, NTAG(TAG_Nil)});
      V v_x2_24226 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str170), v_parts_24225));
      V v_t_24229;
      switch (heff_tag_of(v_x2_24226)) {
      case TAG_Nil: {
        v_t_24229 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str171);
        break;
      }
      case TAG_Cons: {
        V v_x_24227 = heff_field(v_x2_24226, 0);
        V v_xs_24228 = heff_field(v_x2_24226, 1);
        heff_take_n(v_x2_24226, 3ULL, 2);
        v_t_24229 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str172); V a_1 = v_x_24227; V a_2 = v_xs_24228; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24228); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24226);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str173), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str174), heff_strAppend(v_t_24229, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str175))));
    }
    default: return heff_nomatch(v_it1_24201);
    }
  }
  default: return heff_nomatch(v_f_24200);
  }
}
V g_heff_2esyntax_2eformat_2ekeyTermF_lam1(V self, V *args) {
  V v_v_24241 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_v_24241)) {
  case TAG_At: {
    V v_it1_24242 = heff_field(v_v_24241, 0);
    V v_ru_24v_24241_24At = heff_take_reuse_n(v_v_24241, 1ULL, 2);
    switch (heff_tag_of(v_it1_24242)) {
    case TAG_TagVariant: {
      V v_t_24244 = heff_field(v_it1_24242, 0);
      V v_args_24246 = heff_field(v_it1_24242, 2);
      heff_take_n(v_it1_24242, 5ULL, 3);
      V v_x2_24247 = (g_list_2emap(heff_get_n(v_r_240, 0, 2), v_args_24246));
      V v_t_24250;
      switch (heff_tag_of(v_x2_24247)) {
      case TAG_Nil: {
        v_t_24250 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str186);
        break;
      }
      case TAG_Cons: {
        V v_x_24248 = heff_field(v_x2_24247, 0);
        V v_xs_24249 = heff_field(v_x2_24247, 1);
        heff_take_n(v_x2_24247, 3ULL, 2);
        v_t_24250 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str187); V a_1 = v_x_24248; V a_2 = v_xs_24249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24247);
      }
      V v_t_24251 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str188), heff_strAppend(v_t_24250, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str189)));
      V v_t_24252 = heff_tag_at_n(v_ru_24v_24241_24At, TAG_Cons, 2, (V[]){v_t_24251, NTAG(TAG_Nil)});
      V v_parts_24253 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24244, v_t_24252});
      V v_x2_24254 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str190), v_parts_24253));
      V v_t_24257;
      switch (heff_tag_of(v_x2_24254)) {
      case TAG_Nil: {
        v_t_24257 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str191);
        break;
      }
      case TAG_Cons: {
        V v_x_24255 = heff_field(v_x2_24254, 0);
        V v_xs_24256 = heff_field(v_x2_24254, 1);
        heff_take_n(v_x2_24254, 3ULL, 2);
        v_t_24257 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str192); V a_1 = v_x_24255; V a_2 = v_xs_24256; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24256); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24254);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str193), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str194), heff_strAppend(v_t_24257, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str195))));
    }
    case TAG_BadVariant: {
      V v_e_24258 = heff_field(v_it1_24242, 0);
      heff_take_n(v_it1_24242, 1ULL, 1);
      V v_t_24259 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24258}));
      V v_parts_24260 = heff_tag_at_n(v_ru_24v_24241_24At, TAG_Cons, 2, (V[]){v_t_24259, NTAG(TAG_Nil)});
      V v_x2_24261 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str196), v_parts_24260));
      V v_t_24264;
      switch (heff_tag_of(v_x2_24261)) {
      case TAG_Nil: {
        v_t_24264 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str197);
        break;
      }
      case TAG_Cons: {
        V v_x_24262 = heff_field(v_x2_24261, 0);
        V v_xs_24263 = heff_field(v_x2_24261, 1);
        heff_take_n(v_x2_24261, 3ULL, 2);
        v_t_24264 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str198); V a_1 = v_x_24262; V a_2 = v_xs_24263; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24263); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24261);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str199), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str200), heff_strAppend(v_t_24264, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str201))));
    }
    default: return heff_nomatch(v_it1_24242);
    }
  }
  default: return heff_nomatch(v_v_24241);
  }
}
V g_heff_2esyntax_2eformat_2ekeyTermF_lam2(V self, V *args) {
  V v_f_24276 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_f_24276)) {
  case TAG_At: {
    V v_it1_24277 = heff_field(v_f_24276, 0);
    V v_ru_24f_24276_24At = heff_take_reuse_n(v_f_24276, 1ULL, 2);
    switch (heff_tag_of(v_it1_24277)) {
    case TAG_SetField: {
      V v_x_24279 = heff_field(v_it1_24277, 0);
      V v_e_24281 = heff_field(v_it1_24277, 2);
      heff_take_n(v_it1_24277, 5ULL, 3);
      V v_t_24282 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24281}));
      V v_t_24283 = heff_tag_at_n(v_ru_24f_24276_24At, TAG_Cons, 2, (V[]){v_t_24282, NTAG(TAG_Nil)});
      V v_parts_24284 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24279, v_t_24283});
      V v_x2_24285 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str212), v_parts_24284));
      V v_t_24288;
      switch (heff_tag_of(v_x2_24285)) {
      case TAG_Nil: {
        v_t_24288 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str213);
        break;
      }
      case TAG_Cons: {
        V v_x_24286 = heff_field(v_x2_24285, 0);
        V v_xs_24287 = heff_field(v_x2_24285, 1);
        heff_take_n(v_x2_24285, 3ULL, 2);
        v_t_24288 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str214); V a_1 = v_x_24286; V a_2 = v_xs_24287; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24287); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24285);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str215), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str216), heff_strAppend(v_t_24288, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str217))));
    }
    case TAG_BadFieldSet: {
      V v_e_24289 = heff_field(v_it1_24277, 0);
      heff_take_n(v_it1_24277, 1ULL, 1);
      V v_t_24290 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24289}));
      V v_parts_24291 = heff_tag_at_n(v_ru_24f_24276_24At, TAG_Cons, 2, (V[]){v_t_24290, NTAG(TAG_Nil)});
      V v_x2_24292 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str218), v_parts_24291));
      V v_t_24295;
      switch (heff_tag_of(v_x2_24292)) {
      case TAG_Nil: {
        v_t_24295 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str219);
        break;
      }
      case TAG_Cons: {
        V v_x_24293 = heff_field(v_x2_24292, 0);
        V v_xs_24294 = heff_field(v_x2_24292, 1);
        heff_take_n(v_x2_24292, 3ULL, 2);
        v_t_24295 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str220); V a_1 = v_x_24293; V a_2 = v_xs_24294; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24294); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24292);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str221), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str222), heff_strAppend(v_t_24295, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str223))));
    }
    default: return heff_nomatch(v_it1_24277);
    }
  }
  default: return heff_nomatch(v_f_24276);
  }
}
V g_heff_2esyntax_2eformat_2ekeyTermF_lam3(V self, V *args) {
  V v_a_24309 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24309)) {
  case TAG_At: {
    V v_it1_24310 = heff_field(v_a_24309, 0);
    V v_ru_24a_24309_24At = heff_take_reuse_n(v_a_24309, 1ULL, 2);
    switch (heff_tag_of(v_it1_24310)) {
    case TAG_MkAlt: {
      V v_p_24312 = heff_field(v_it1_24310, 0);
      V v_e_24313 = heff_field(v_it1_24310, 1);
      V v_ru_24it1_24310_24MkAlt = heff_take_reuse_n(v_it1_24310, 3ULL, 2);
      V v_t_24314 = (g_heff_2esyntax_2eformat_2epatKey(v_p_24312));
      V v_t_24315 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24313}));
      V v_t_24316 = heff_tag_at_n(v_ru_24a_24309_24At, TAG_Cons, 2, (V[]){v_t_24315, NTAG(TAG_Nil)});
      V v_parts_24317 = heff_tag_at_n(v_ru_24it1_24310_24MkAlt, TAG_Cons, 2, (V[]){v_t_24314, v_t_24316});
      V v_x2_24318 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str234), v_parts_24317));
      V v_t_24321;
      switch (heff_tag_of(v_x2_24318)) {
      case TAG_Nil: {
        v_t_24321 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str235);
        break;
      }
      case TAG_Cons: {
        V v_x_24319 = heff_field(v_x2_24318, 0);
        V v_xs_24320 = heff_field(v_x2_24318, 1);
        heff_take_n(v_x2_24318, 3ULL, 2);
        v_t_24321 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str236); V a_1 = v_x_24319; V a_2 = v_xs_24320; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24320); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24318);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str237), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str238), heff_strAppend(v_t_24321, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str239))));
    }
    default: return heff_nomatch(v_it1_24310);
    }
  }
  default: return heff_nomatch(v_a_24309);
  }
}
V g_heff_2esyntax_2eformat_2ekeyTermF_lam4(V self, V *args) {
  V v_m_24349 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_24349)) {
  case TAG_At: {
    V v_it1_24350 = heff_field(v_m_24349, 0);
    V v_ru_24m_24349_24At = heff_take_reuse_n(v_m_24349, 1ULL, 2);
    switch (heff_tag_of(v_it1_24350)) {
    case TAG_StmtBind: {
      V v_x_24352 = heff_field(v_it1_24350, 0);
      V v_e_24354 = heff_field(v_it1_24350, 2);
      heff_take_n(v_it1_24350, 5ULL, 3);
      V v_t_24355 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24354}));
      V v_t_24356 = heff_tag_at_n(v_ru_24m_24349_24At, TAG_Cons, 2, (V[]){v_t_24355, NTAG(TAG_Nil)});
      V v_parts_24357 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24352, v_t_24356});
      V v_x2_24358 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str256), v_parts_24357));
      V v_t_24361;
      switch (heff_tag_of(v_x2_24358)) {
      case TAG_Nil: {
        v_t_24361 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str257);
        break;
      }
      case TAG_Cons: {
        V v_x_24359 = heff_field(v_x2_24358, 0);
        V v_xs_24360 = heff_field(v_x2_24358, 1);
        heff_take_n(v_x2_24358, 3ULL, 2);
        v_t_24361 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str258); V a_1 = v_x_24359; V a_2 = v_xs_24360; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24360); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24358);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str259), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str260), heff_strAppend(v_t_24361, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str261))));
    }
    case TAG_StmtLet: {
      V v_p_24362 = heff_field(v_it1_24350, 0);
      V v_e_24363 = heff_field(v_it1_24350, 1);
      V v_ru_24it1_24350_24StmtLet = heff_take_reuse_n(v_it1_24350, 3ULL, 2);
      V v_t_24364 = (g_heff_2esyntax_2eformat_2epatKey(v_p_24362));
      V v_t_24365 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24363}));
      V v_t_24366 = heff_tag_at_n(v_ru_24m_24349_24At, TAG_Cons, 2, (V[]){v_t_24365, NTAG(TAG_Nil)});
      V v_parts_24367 = heff_tag_at_n(v_ru_24it1_24350_24StmtLet, TAG_Cons, 2, (V[]){v_t_24364, v_t_24366});
      V v_x2_24368 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str262), v_parts_24367));
      V v_t_24371;
      switch (heff_tag_of(v_x2_24368)) {
      case TAG_Nil: {
        v_t_24371 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str263);
        break;
      }
      case TAG_Cons: {
        V v_x_24369 = heff_field(v_x2_24368, 0);
        V v_xs_24370 = heff_field(v_x2_24368, 1);
        heff_take_n(v_x2_24368, 3ULL, 2);
        v_t_24371 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str264); V a_1 = v_x_24369; V a_2 = v_xs_24370; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24370); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24368);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str265), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str266), heff_strAppend(v_t_24371, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str267))));
    }
    case TAG_StmtExpr: {
      V v_e_24372 = heff_field(v_it1_24350, 0);
      heff_take_n(v_it1_24350, 1ULL, 1);
      V v_t_24373 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_24372}));
      V v_parts_24374 = heff_tag_at_n(v_ru_24m_24349_24At, TAG_Cons, 2, (V[]){v_t_24373, NTAG(TAG_Nil)});
      V v_x2_24375 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str268), v_parts_24374));
      V v_t_24378;
      switch (heff_tag_of(v_x2_24375)) {
      case TAG_Nil: {
        v_t_24378 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str269);
        break;
      }
      case TAG_Cons: {
        V v_x_24376 = heff_field(v_x2_24375, 0);
        V v_xs_24377 = heff_field(v_x2_24375, 1);
        heff_take_n(v_x2_24375, 3ULL, 2);
        v_t_24378 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str270); V a_1 = v_x_24376; V a_2 = v_xs_24377; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24377); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24375);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str271), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str272), heff_strAppend(v_t_24378, ((V)&g_heff_2esyntax_2eformat_2ekeyTermF_str273))));
    }
    default: return heff_nomatch(v_it1_24350);
    }
  }
  default: return heff_nomatch(v_m_24349);
  }
}
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str0, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str1, 2, (44, 32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str2, 1, (91));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str3, 1, (93));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str4, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str5, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str6, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str7, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str8, 8, (101, 113, 117, 97, 116, 105, 111, 110));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str9, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str10, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str11, 2, (44, 32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str12, 1, (91));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str13, 1, (93));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str14, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str15, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str16, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str17, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str18, 9, (101, 113, 117, 97, 116, 105, 111, 110, 115));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str19, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str20, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str21, 2, (44, 32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str22, 1, (91));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str23, 1, (93));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str24, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str25, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str26, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str27, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str28, 6, (100, 101, 102, 105, 110, 101));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str29, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str30, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str31, 2, (44, 32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str32, 1, (91));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str33, 1, (93));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str34, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str35, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str36, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str37, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str38, 6, (116, 104, 101, 111, 114, 121));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str39, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str40, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str41, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str42, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str43, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str44, 9, (112, 114, 105, 109, 105, 116, 105, 118, 101));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str45, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str46, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str47, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str48, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str49, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str50, 4, (116, 101, 115, 116));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str51, 1, (41));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str52, 1, (32));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str53, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str54, 0, (0));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str55, 1, (40));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str56, 5, (119, 97, 116, 99, 104));
HEFF_STRA(g_heff_2esyntax_2eformat_2ekeyDeclF_str57, 1, (41));
V g_heff_2esyntax_2eformat_2ekeyDeclF_lam0(V self, V *args);
Clo g_heff_2esyntax_2eformat_2ekeyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeyDeclF_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ekeyDeclF(V v_r_240, V v_d_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_d_241, 0);
    v_t_244 = heff_dup(v_x_242);
    break;
  }
  default: heff_nomatch(v_d_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_DeclEquations: {
    V v_f_245 = heff_field(v_t_244, 0);
    V v_ty_247 = heff_field(v_t_244, 2);
    V v_eqs_248 = heff_field(v_t_244, 3);
    heff_take_n(v_t_244, 13ULL, 4);
    V v_t_249 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_247}));
    V v_x2_2429 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2eformat_2ekeyDeclF_lam0, 1, 1, (V[]){v_r_240}), v_eqs_248));
    V v_t_2432;
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_Nil: {
      v_t_2432 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2430 = heff_field(v_x2_2429, 0);
      V v_xs_2431 = heff_field(v_x2_2429, 1);
      heff_take_n(v_x2_2429, 3ULL, 2);
      v_t_2432 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str11); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2429);
    }
    V v_t_2433 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str12), heff_strAppend(v_t_2432, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str13)));
    V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
    V v_parts_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2434})});
    V v_x2_2436 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str14), v_parts_2435));
    V v_t_2439;
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_Nil: {
      v_t_2439 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str15);
      break;
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_xs_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      v_t_2439 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str16); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2436);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str17), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str18), heff_strAppend(v_t_2439, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str19))));
  }
  case TAG_DeclDefine: {
    V v_x_2440 = heff_field(v_t_244, 0);
    V v_ps_2442 = heff_field(v_t_244, 2);
    V v_u_2443 = heff_field(v_t_244, 3);
    V v_body_2444 = heff_field(v_t_244, 4);
    heff_take_n(v_t_244, 29ULL, 5);
    V v_t_2445 = heff_tr(heff_apply(((V)&g_heff_2esyntax_2eformat_2eparamKey_clo), 1, (V[]){heff_dup(v_r_240)}));
    V v_x2_2446 = (g_list_2emap(v_t_2445, v_ps_2442));
    V v_t_2449;
    switch (heff_tag_of(v_x2_2446)) {
    case TAG_Nil: {
      v_t_2449 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str20);
      break;
    }
    case TAG_Cons: {
      V v_x_2447 = heff_field(v_x2_2446, 0);
      V v_xs_2448 = heff_field(v_x2_2446, 1);
      heff_take_n(v_x2_2446, 3ULL, 2);
      v_t_2449 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str21); V a_1 = v_x_2447; V a_2 = v_xs_2448; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2448); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2446);
    }
    V v_t_2450 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str22), heff_strAppend(v_t_2449, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str23)));
    V v_t_2451 = heff_tr(heff_apply(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_u_2443}));
    V v_t_2452 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2444}));
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
    V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, v_t_2453})});
    V v_parts_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2440, v_t_2454});
    V v_x2_2456 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str24), v_parts_2455));
    V v_t_2459;
    switch (heff_tag_of(v_x2_2456)) {
    case TAG_Nil: {
      v_t_2459 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str25);
      break;
    }
    case TAG_Cons: {
      V v_x_2457 = heff_field(v_x2_2456, 0);
      V v_xs_2458 = heff_field(v_x2_2456, 1);
      heff_take_n(v_x2_2456, 3ULL, 2);
      v_t_2459 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str26); V a_1 = v_x_2457; V a_2 = v_xs_2458; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2458); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2456);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str27), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str28), heff_strAppend(v_t_2459, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str29))));
  }
  case TAG_DeclTheory: {
    V v_x_2460 = heff_field(v_t_244, 0);
    V v_ps_2462 = heff_field(v_t_244, 2);
    V v_body_2463 = heff_field(v_t_244, 3);
    heff_take_n(v_t_244, 13ULL, 4);
    V v_t_2464 = heff_tr(heff_apply(((V)&g_heff_2esyntax_2eformat_2eparamKey_clo), 1, (V[]){heff_dup(v_r_240)}));
    V v_x2_2465 = (g_list_2emap(v_t_2464, v_ps_2462));
    V v_t_2468;
    switch (heff_tag_of(v_x2_2465)) {
    case TAG_Nil: {
      v_t_2468 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str30);
      break;
    }
    case TAG_Cons: {
      V v_x_2466 = heff_field(v_x2_2465, 0);
      V v_xs_2467 = heff_field(v_x2_2465, 1);
      heff_take_n(v_x2_2465, 3ULL, 2);
      v_t_2468 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str31); V a_1 = v_x_2466; V a_2 = v_xs_2467; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2467); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2465);
    }
    V v_t_2469 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str32), heff_strAppend(v_t_2468, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str33)));
    V v_t_2470 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2463}));
    V v_t_2471 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2470, NTAG(TAG_Nil)});
    V v_parts_2472 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2460, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2469, v_t_2471})});
    V v_x2_2473 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str34), v_parts_2472));
    V v_t_2476;
    switch (heff_tag_of(v_x2_2473)) {
    case TAG_Nil: {
      v_t_2476 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2474 = heff_field(v_x2_2473, 0);
      V v_xs_2475 = heff_field(v_x2_2473, 1);
      heff_take_n(v_x2_2473, 3ULL, 2);
      v_t_2476 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str36); V a_1 = v_x_2474; V a_2 = v_xs_2475; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2475); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2473);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str37), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str38), heff_strAppend(v_t_2476, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str39))));
  }
  case TAG_DeclPrimitive: {
    V v_x_2477 = heff_field(v_t_244, 0);
    V v_t_2479 = heff_field(v_t_244, 2);
    heff_take_n(v_t_244, 5ULL, 3);
    V v_t_2480 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2479}));
    V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2480, NTAG(TAG_Nil)});
    V v_parts_2482 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2477, v_t_2481});
    V v_x2_2483 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str40), v_parts_2482));
    V v_t_2486;
    switch (heff_tag_of(v_x2_2483)) {
    case TAG_Nil: {
      v_t_2486 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str41);
      break;
    }
    case TAG_Cons: {
      V v_x_2484 = heff_field(v_x2_2483, 0);
      V v_xs_2485 = heff_field(v_x2_2483, 1);
      heff_take_n(v_x2_2483, 3ULL, 2);
      v_t_2486 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str42); V a_1 = v_x_2484; V a_2 = v_xs_2485; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2485); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2483);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str43), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str44), heff_strAppend(v_t_2486, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str45))));
  }
  case TAG_DeclTest: {
    V v_x_2487 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24DeclTest = heff_take_reuse_n(v_t_244, 1ULL, 2);
    heff_drop_rec(v_r_240, 2);
    V v_t_2489 = heff_tag_at_n(v_ru_24t_244_24DeclTest, TAG_Cons, 2, (V[]){v_x_2487, NTAG(TAG_Nil)});
    V v_x2_2490 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str46), v_t_2489));
    V v_t_2493;
    switch (heff_tag_of(v_x2_2490)) {
    case TAG_Nil: {
      v_t_2493 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str47);
      break;
    }
    case TAG_Cons: {
      V v_x_2491 = heff_field(v_x2_2490, 0);
      V v_xs_2492 = heff_field(v_x2_2490, 1);
      heff_take_n(v_x2_2490, 3ULL, 2);
      v_t_2493 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str48); V a_1 = v_x_2491; V a_2 = v_xs_2492; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2492); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2490);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str49), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str50), heff_strAppend(v_t_2493, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str51))));
  }
  case TAG_DeclWatch: {
    V v_e_2494 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_t_2495 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2494}));
    V v_parts_2496 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2495, NTAG(TAG_Nil)});
    V v_x2_2497 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str52), v_parts_2496));
    V v_t_24100;
    switch (heff_tag_of(v_x2_2497)) {
    case TAG_Nil: {
      v_t_24100 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str53);
      break;
    }
    case TAG_Cons: {
      V v_x_2498 = heff_field(v_x2_2497, 0);
      V v_xs_2499 = heff_field(v_x2_2497, 1);
      heff_take_n(v_x2_2497, 3ULL, 2);
      v_t_24100 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str54); V a_1 = v_x_2498; V a_2 = v_xs_2499; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2499); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2497);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str55), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str56), heff_strAppend(v_t_24100, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str57))));
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2eformat_2ekeyDeclF_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2eformat_2ekeyDeclF(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2esyntax_2eformat_2ekeyDeclF_lam0(V self, V *args) {
  V v_eq_2410 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_eq_2410)) {
  case TAG_At: {
    V v_it1_2411 = heff_field(v_eq_2410, 0);
    V v_ru_24eq_2410_24At = heff_take_reuse_n(v_eq_2410, 1ULL, 2);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_MkEquation: {
      V v_g_2413 = heff_field(v_it1_2411, 0);
      V v_ps_2415 = heff_field(v_it1_2411, 2);
      V v_rhs_2416 = heff_field(v_it1_2411, 3);
      heff_take_n(v_it1_2411, 13ULL, 4);
      V v_x2_2417 = (g_list_2emap_24s1561756891x1126436879(v_ps_2415));
      V v_t_2420;
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_Nil: {
        v_t_2420 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2418 = heff_field(v_x2_2417, 0);
        V v_xs_2419 = heff_field(v_x2_2417, 1);
        heff_take_n(v_x2_2417, 3ULL, 2);
        v_t_2420 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str1); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2417);
      }
      V v_t_2421 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str2), heff_strAppend(v_t_2420, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str3)));
      V v_t_2422 = heff_tr(heff_apply(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_rhs_2416}));
      V v_t_2423 = heff_tag_at_n(v_ru_24eq_2410_24At, TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
      V v_parts_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_g_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_t_2423})});
      V v_x2_2425 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str4), v_parts_2424));
      V v_t_2428;
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_Nil: {
        v_t_2428 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_2426 = heff_field(v_x2_2425, 0);
        V v_xs_2427 = heff_field(v_x2_2425, 1);
        heff_take_n(v_x2_2425, 3ULL, 2);
        v_t_2428 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str6); V a_1 = v_x_2426; V a_2 = v_xs_2427; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2427); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2425);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str7), heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str8), heff_strAppend(v_t_2428, ((V)&g_heff_2esyntax_2eformat_2ekeyDeclF_str9))));
    }
    default: return heff_nomatch(v_it1_2411);
    }
  }
  default: return heff_nomatch(v_eq_2410);
  }
}
V g_heff_2esyntax_2eformat_2ekeys_lam0(V self, V *args); static Clo g_heff_2esyntax_2eformat_2ekeys_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeys_lam0, 1, 0};
V g_heff_2esyntax_2eformat_2ekeys_lam1(V self, V *args); static Clo g_heff_2esyntax_2eformat_2ekeys_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeys_lam1, 1, 0};

static V g_heff_2esyntax_2eformat_2ekeys_val;
static int g_heff_2esyntax_2eformat_2ekeys_st;
static V g_heff_2esyntax_2eformat_2ekeys_init(void) {
  return heff_rec_n(2, shape_e__decl, (V[]){((V)&g_heff_2esyntax_2eformat_2ekeys_lam0_clo), ((V)&g_heff_2esyntax_2eformat_2ekeys_lam1_clo)});
}
V g_heff_2esyntax_2eformat_2ekeys_get(void) {
  if (g_heff_2esyntax_2eformat_2ekeys_st == 2) return g_heff_2esyntax_2eformat_2ekeys_val;
  if (g_heff_2esyntax_2eformat_2ekeys_st == 1) heff_fail("defined by itself");
  g_heff_2esyntax_2eformat_2ekeys_st = 1;
  g_heff_2esyntax_2eformat_2ekeys_val = heff_tr(g_heff_2esyntax_2eformat_2ekeys_init());
  g_heff_2esyntax_2eformat_2ekeys_st = 2;
  return g_heff_2esyntax_2eformat_2ekeys_val;
}
V g_heff_2esyntax_2eformat_2ekeys_lam0(V self, V *args) {
  V v_n_240 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2esyntax_2eformat_2ekeys_get()); V a_1 = v_n_240; V r_ = (g_heff_2esyntax_2eformat_2ekeyTermF(a_0, a_1)); heff_drop(v_n_240); r_; });
}
V g_heff_2esyntax_2eformat_2ekeys_lam1(V self, V *args) {
  V v_d_241 = args[0];
  return ({ V a_0 = heff_dup(g_heff_2esyntax_2eformat_2ekeys_get()); V a_1 = v_d_241; V r_ = (g_heff_2esyntax_2eformat_2ekeyDeclF(a_0, a_1)); heff_drop(v_d_241); r_; });
}
HEFF_STRA(g_heff_2esyntax_2eformat_2emeaningFrom_str0, 0, (0));
Clo g_heff_2esyntax_2eformat_2emeaningFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2emeaningFrom_entry, 1, 0};

V g_heff_2esyntax_2eformat_2emeaningFrom(V v_h_240) {
top: ;
  V v_text_241 = heff_take_field(v_h_240, 2);
  V v_t_242 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_243 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(v_text_241), v_t_242, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_r_244 = (g_heff_2esyntax_2esurface_2ereadLexed_24s1088510898x79166857(((V)&g_heff_2esyntax_2eformat_2emeaningFrom_str0), v_text_241, v_t_243));
  V v_t_245 = (g_list_2emap_24s424270175x1918189508(heff_get_n(v_h_240, 0, 3)));
  V v_t_246 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2esyntax_2eformat_2ekeys_get(), 1)), heff_take_field(v_r_244, 0)));
  V v_t_247 = (g_list_2emap_24s1602529591x1809288035(heff_get_n(v_r_244, 1, 4)));
  return heff_rec_n(3, shape_imports__decls__diags, (V[]){v_t_245, v_t_246, v_t_247});
}
V g_heff_2esyntax_2eformat_2emeaningFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2emeaningFrom(a[0]);
}
Clo g_heff_2esyntax_2eformat_2estrsEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2estrsEq_entry, 2, 0};

V g_heff_2esyntax_2eformat_2estrsEq(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c(heff_dup(v_a_244), heff_dup(v_b_246))) {
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2eformat_2estrsEq_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esyntax_2eformat_2estrsEq(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
HEFF_STRA(g_heff_2esyntax_2eformat_2esameMeaning_str0, 35, (102, 111, 114, 109, 97, 116, 116, 105, 110, 103, 32, 119, 111, 117, 108, 100, 32, 99, 104, 97, 110, 103, 101, 32, 116, 104, 101, 32, 105, 109, 112, 111, 114, 116, 115));
HEFF_STRA(g_heff_2esyntax_2eformat_2esameMeaning_str1, 68, (102, 111, 114, 109, 97, 116, 116, 105, 110, 103, 32, 119, 111, 117, 108, 100, 32, 99, 104, 97, 110, 103, 101, 32, 119, 104, 97, 116, 32, 116, 104, 101, 32, 102, 105, 108, 101, 32, 109, 101, 97, 110, 115, 32, 40, 97, 32, 98, 117, 103, 32, 111, 102, 32, 116, 104, 101, 32, 102, 111, 114, 109, 97, 116, 116, 101, 114, 41));
HEFF_STRA(g_heff_2esyntax_2eformat_2esameMeaning_str2, 76, (102, 111, 114, 109, 97, 116, 116, 105, 110, 103, 32, 119, 111, 117, 108, 100, 32, 108, 111, 115, 101, 32, 111, 114, 32, 109, 111, 118, 101, 32, 97, 32, 99, 111, 109, 109, 101, 110, 116, 32, 97, 99, 114, 111, 115, 115, 32, 99, 111, 100, 101, 32, 40, 97, 32, 98, 117, 103, 32, 111, 102, 32, 116, 104, 101, 32, 102, 111, 114, 109, 97, 116, 116, 101, 114, 41));
Clo g_heff_2esyntax_2eformat_2esameMeaning_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2esameMeaning_entry, 4, 0};

V g_heff_2esyntax_2eformat_2esameMeaning(V v_src_240, V v_out_241, V v_a_242, V v_b_243) {
top: ;
  V v_x1_244 = (g_heff_2esyntax_2eformat_2estrsEq(heff_rfield(v_a_242, 0), heff_rfield(v_b_243, 0)));
  V v_t_245;
  switch (heff_tag_of(v_x1_244)) {
  case TAG_True: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_244);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_src_240);
    heff_drop(v_out_241);
    heff_drop_rec(v_a_242, 3);
    heff_drop_rec(v_b_243, 3);
    return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2esyntax_2eformat_2esameMeaning_str0)});
  }
  case TAG_False: {
    V v_t_246 = (g_heff_2esyntax_2eformat_2estrsEq(heff_rfield(v_a_242, 1), heff_rfield(v_b_243, 1)));
    V v_x1_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      v_x1_247 = ({ V b_0 = heff_get_n(v_a_242, 2, 3); V b_1 = heff_get_n(v_b_243, 2, 3); V r_ = (g_heff_2esyntax_2eformat_2estrsEq(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
      break;
    }
    case TAG_False: {
      heff_drop_rec(v_a_242, 3);
      heff_drop_rec(v_b_243, 3);
      v_x1_247 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_248;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_True: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_248 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_src_240);
      heff_drop(v_out_241);
      return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2esyntax_2eformat_2esameMeaning_str1)});
    }
    case TAG_False: {
      V v_t_249 = (g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nil)));
      V v_src_2410 = heff_get_n(v_t_249, 2, 3);
      V v_t_2411 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      V v_t_2412 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_src_2410, v_t_2411, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2413 = (g_list_2emap_24s953916415x1126219438(MK_INT(0LL), heff_get_n(v_t_2412, 2, 3)));
      V v_t_2414 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_out_241), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_src_2415 = heff_get_n(v_t_2414, 2, 3);
      V v_t_2416 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      V v_t_2417 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_src_2415, v_t_2416, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2418 = (g_list_2emap_24s953916415x1126219438(MK_INT(0LL), heff_get_n(v_t_2417, 2, 3)));
      V v_x1_2419 = ({ V a_0 = v_t_2413; V a_1 = v_t_2418; V r_ = (g_heff_2esyntax_2eformat_2estrsEq(a_0, a_1)); heff_drop(v_t_2413); heff_drop(v_t_2418); r_; });
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_True: {
        return heff_tag_n(TAG_Right, 1, (V[]){v_out_241});
      }
      case TAG_False: {
        heff_drop(v_out_241);
        return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2esyntax_2eformat_2esameMeaning_str2)});
      }
      default: return heff_nomatch(v_x1_2419);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2esyntax_2eformat_2esameMeaning_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2esameMeaning(a[0], a[1], a[2], a[3]);
}
HEFF_STRA(g_heff_2esyntax_2eformat_2eformat_str0, 0, (0));
Clo g_heff_2esyntax_2eformat_2eformat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2eformat_entry, 1, 0};

V g_heff_2esyntax_2eformat_2eformat(V v_src_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_240), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_src_242 = heff_get_n(v_t_241, 2, 3);
  V v_t_243 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_244 = (g_heff_2esyntax_2efmt_2elex_2elexGo(v_src_242, v_t_243, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_ts_245 = heff_arrayFromList(heff_get_n(v_t_244, 0, 3));
  V v_t_246 = (g_heff_2esyntax_2esurface_2efixDecls(v_ts_245, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_247 = (g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(((V)&g_heff_2esyntax_2eformat_2eformat_str0), v_t_246));
  V v_f_248 = heff_get_n(v_t_247, 0, 2);
  V v_t_249 = (g_heff_2esyntax_2efmt_2elayout_2eformatUncheckedIn(v_f_248, heff_dup(v_src_240)));
  switch (heff_tag_of(v_t_249)) {
  case TAG_Left: {
    V v_why_2410 = heff_field(v_t_249, 0);
    V v_ru_24t_249_24Left = heff_take_reuse_n(v_t_249, 1ULL, 1);
    heff_drop(v_src_240);
    return heff_tag_at_n(v_ru_24t_249_24Left, TAG_Left, 1, (V[]){v_why_2410});
  }
  case TAG_Right: {
    V v_out_2411 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    V v_t_2412 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_src_240), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2413 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2412));
    V v_t_2414 = (g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_out_2411), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2415 = (g_heff_2esyntax_2eformat_2emeaningFrom(v_t_2414));
    return (g_heff_2esyntax_2eformat_2esameMeaning(v_src_240, v_out_2411, v_t_2413, v_t_2415));
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2esyntax_2eformat_2eformat_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2eformat(a[0]);
}