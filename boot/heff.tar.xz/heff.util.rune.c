// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2eutil_2erune_2ebytesEsc(V, V, V);
V g_heff_2eutil_2erune_2ebytesEsc_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2ebytesEsc_clo;
V g_heff_2eutil_2erune_2ebytesEsc_24acc(V, V, V, V);
V g_heff_2eutil_2erune_2ebytesEsc_24acc_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2ebytesEsc_24acc_clo;
V g_heff_2eutil_2erune_2ehexWith(V, V);
V g_heff_2eutil_2erune_2ehexWith_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2ehexWith_clo;
V g_heff_2eutil_2erune_2epadTo4(V);
V g_heff_2eutil_2erune_2epadTo4_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2epadTo4_clo;
V g_heff_2eutil_2erune_2equoteBytesGo(V, V, V, V);
V g_heff_2eutil_2erune_2equoteBytesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteBytesGo_clo;
V g_heff_2eutil_2erune_2equoteGo(V, V, V);
V g_heff_2eutil_2erune_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteGo_clo;
V g_heff_2eutil_2erune_2equoted(V);
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoted_clo;
V g_heff_2eutil_2erune_2eruneEsc(V, V, V);
V g_heff_2eutil_2erune_2eruneEsc_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2eruneEsc_clo;
V g_heff_2eutil_2erune_2eruneStartGo(V, V, V);
V g_heff_2eutil_2erune_2eruneStartGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2eruneStartGo_clo;
V g_heff_2eutil_2erune_2erunesGo(V, V, V, V);
V g_heff_2eutil_2erune_2erunesGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2erunesGo_clo;
Clo g_heff_2eutil_2erune_2ehexWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2ehexWith_entry, 2, 0};

V g_heff_2eutil_2erune_2ehexWith(V v_digits_240, V v_n_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_n_241), MK_INT(16LL))) {
    return heff_strSlice(v_digits_240, heff_dup(v_n_241), heff_intAdd(v_n_241, MK_INT(1LL)));
  } else {
    V v_t_243 = (g_heff_2eutil_2erune_2ehexWith(heff_dup(v_digits_240), heff_intDiv(heff_dup(v_n_241), MK_INT(16LL))));
    V v_t_244 = heff_intAdd(heff_intMod(heff_dup(v_n_241), MK_INT(16LL)), MK_INT(1LL));
    V v_t_245 = heff_strSlice(v_digits_240, heff_intMod(v_n_241, MK_INT(16LL)), v_t_244);
    return heff_strAppend(v_t_243, v_t_245);
  }
}
V g_heff_2eutil_2erune_2ehexWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2ehexWith(a[0], a[1]);
}
HEFF_LIT(g_heff_2eutil_2erune_2epadTo4_str0, 1, "0");
Clo g_heff_2eutil_2erune_2epadTo4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2epadTo4_entry, 1, 0};

V g_heff_2eutil_2erune_2epadTo4(V v_s_240) {
top: ;
  if (heff_intLe_c(MK_INT(4LL), heff_strLength_lent(v_s_240, 0))) {
    return v_s_240;
  } else {
    V t_0 = heff_strAppend(((V)&g_heff_2eutil_2erune_2epadTo4_str0), v_s_240);
    v_s_240 = t_0;
    goto top;
  }
}
V g_heff_2eutil_2erune_2epadTo4_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2epadTo4(a[0]);
}
Clo g_heff_2eutil_2erune_2erunesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2erunesGo_entry, 4, 0};

V g_heff_2eutil_2erune_2erunesGo(V v_s_240, V v_i_241, V v_j_242, V v_n_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_j_242), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_j_242);
    return v_n_243;
  } else {
    if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      heff_drop(v_j_242);
      return v_n_243;
    } else {
      if (heff_intLt_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(128LL))) {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_j_242;
        V t_3 = heff_intAdd(v_n_243, MK_INT(1LL));
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_j_242 = t_2;
        v_n_243 = t_3;
        goto top;
      } else {
        V v_w_247 = heff_strRuneWidth_lent(v_s_240, v_i_241, 0);
        if (heff_intLt_c(heff_dup(v_j_242), heff_intAdd(heff_dup(v_i_241), heff_dup(v_w_247)))) {
          heff_drop(v_s_240);
          heff_drop(v_i_241);
          heff_drop(v_j_242);
          heff_drop(v_w_247);
          return v_n_243;
        } else {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, v_w_247);
          V t_2 = v_j_242;
          V t_3 = heff_intAdd(v_n_243, MK_INT(1LL));
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_j_242 = t_2;
          v_n_243 = t_3;
          goto top;
        }
      }
    }
  }
}
V g_heff_2eutil_2erune_2erunesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2erunesGo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eutil_2erune_2eruneStartGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2eruneStartGo_entry, 3, 0};

V g_heff_2eutil_2erune_2eruneStartGo(V v_s_240, V v_i_241, V v_k_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_k_242);
    return v_i_241;
  } else {
    V v_w_244 = heff_strRuneWidth_lent(v_s_240, v_i_241, 0);
    if (heff_intLt_c(heff_dup(v_k_242), heff_intAdd(heff_dup(v_i_241), heff_dup(v_w_244)))) {
      heff_drop(v_s_240);
      heff_drop(v_k_242);
      heff_drop(v_w_244);
      return v_i_241;
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, v_w_244);
      V t_2 = v_k_242;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_k_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2eutil_2erune_2eruneStartGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2eruneStartGo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str0, 2, "\\'");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str1, 2, "\\\\");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str2, 2, "\\n");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str3, 2, "\\t");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str4, 2, "\\r");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str5, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str6, 3, "\\u{");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str7, 1, "}");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str8, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str9, 3, "\\u{");
HEFF_LIT(g_heff_2eutil_2erune_2equoted_str10, 1, "}");
Clo g_heff_2eutil_2erune_2equoted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2equoted_entry, 1, 0};

V g_heff_2eutil_2erune_2equoted(V v_c_240) {
top: ;
  if (heff_intEq_c(heff_dup(v_c_240), MK_INT(39LL))) {
    heff_drop(v_c_240);
    return ((V)&g_heff_2eutil_2erune_2equoted_str0);
  } else {
    if (heff_intEq_c(heff_dup(v_c_240), MK_INT(92LL))) {
      heff_drop(v_c_240);
      return ((V)&g_heff_2eutil_2erune_2equoted_str1);
    } else {
      if (heff_intEq_c(heff_dup(v_c_240), MK_INT(10LL))) {
        heff_drop(v_c_240);
        return ((V)&g_heff_2eutil_2erune_2equoted_str2);
      } else {
        if (heff_intEq_c(heff_dup(v_c_240), MK_INT(9LL))) {
          heff_drop(v_c_240);
          return ((V)&g_heff_2eutil_2erune_2equoted_str3);
        } else {
          if (heff_intEq_c(heff_dup(v_c_240), MK_INT(13LL))) {
            heff_drop(v_c_240);
            return ((V)&g_heff_2eutil_2erune_2equoted_str4);
          } else {
            V v_t_2410 = heff_bool((heff_intLe_c(MK_INT(0LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(1114111LL)) ? (heff_intLe_c(MK_INT(55296LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57343LL))) : 1) : 1));
            if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
              heff_drop(v_c_240);
              heff_drop(v_t_2410);
              V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(MK_INT(65533LL)), NTAG(TAG_Nil)});
              return heff_strOfRunes(v_t_2411);
            } else {
              heff_drop(v_t_2410);
              if (heff_intLt_c(heff_dup(v_c_240), MK_INT(32LL))) {
                V v_t_2413 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2eutil_2erune_2equoted_str5), v_c_240));
                return heff_strAppend(((V)&g_heff_2eutil_2erune_2equoted_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2eutil_2erune_2equoted_str7)));
              } else {
                if (heff_intLe_c(MK_INT(127LL), heff_dup(v_c_240))) {
                  if (heff_intLt_c(heff_dup(v_c_240), MK_INT(160LL))) {
                    V v_t_2416 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2eutil_2erune_2equoted_str8), v_c_240));
                    return heff_strAppend(((V)&g_heff_2eutil_2erune_2equoted_str9), heff_strAppend(v_t_2416, ((V)&g_heff_2eutil_2erune_2equoted_str10)));
                  } else {
                    V v_t_2421;
                    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_c_240))) {
                      if (heff_intLe_c(heff_dup(v_c_240), MK_INT(1114111LL))) {
                        if (heff_intLe_c(MK_INT(55296LL), heff_dup(v_c_240))) {
                          if (heff_intLe_c(heff_dup(v_c_240), MK_INT(57343LL))) {
                            heff_drop(v_c_240);
                            v_t_2421 = MK_INT(65533LL);
                          } else {
                            v_t_2421 = v_c_240;
                          }
                        } else {
                          v_t_2421 = v_c_240;
                        }
                      } else {
                        heff_drop(v_c_240);
                        v_t_2421 = MK_INT(65533LL);
                      }
                    } else {
                      heff_drop(v_c_240);
                      v_t_2421 = MK_INT(65533LL);
                    }
                    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_t_2421), NTAG(TAG_Nil)});
                    return heff_strOfRunes(v_t_2422);
                  }
                } else {
                  V v_t_2427;
                  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_c_240))) {
                    if (heff_intLe_c(heff_dup(v_c_240), MK_INT(1114111LL))) {
                      if (heff_intLe_c(MK_INT(55296LL), heff_dup(v_c_240))) {
                        if (heff_intLe_c(heff_dup(v_c_240), MK_INT(57343LL))) {
                          heff_drop(v_c_240);
                          v_t_2427 = MK_INT(65533LL);
                        } else {
                          v_t_2427 = v_c_240;
                        }
                      } else {
                        v_t_2427 = v_c_240;
                      }
                    } else {
                      heff_drop(v_c_240);
                      v_t_2427 = MK_INT(65533LL);
                    }
                  } else {
                    heff_drop(v_c_240);
                    v_t_2427 = MK_INT(65533LL);
                  }
                  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(v_t_2427), NTAG(TAG_Nil)});
                  return heff_strOfRunes(v_t_2428);
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2equoted(a[0]);
}
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_str0, 0, "");
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_str1, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_str2, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_str3, 2, "\\x");
Clo g_heff_2eutil_2erune_2ebytesEsc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2ebytesEsc_entry, 3, 0};

V g_heff_2eutil_2erune_2ebytesEsc(V v_s_240, V v_i_241, V v_w_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_w_242), MK_INT(0LL))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_w_242);
    return ((V)&g_heff_2eutil_2erune_2ebytesEsc_str0);
  } else {
    V v_b_244 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
    V v_t_245 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2eutil_2erune_2ebytesEsc_str1), heff_intDiv(heff_dup(v_b_244), MK_INT(16LL))));
    V v_t_246 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2eutil_2erune_2ebytesEsc_str2), heff_intMod(v_b_244, MK_INT(16LL))));
    V v_s_247 = heff_strAppend(((V)&g_heff_2eutil_2erune_2ebytesEsc_str3), heff_strAppend(v_t_245, v_t_246));
    return (g_heff_2eutil_2erune_2ebytesEsc_24acc(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)), heff_intSub(v_w_242, MK_INT(1LL)), v_s_247));
  }
}
V g_heff_2eutil_2erune_2ebytesEsc_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2ebytesEsc(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_24acc_str0, 0, "");
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_24acc_str1, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_24acc_str2, 16, "0123456789abcdef");
HEFF_LIT(g_heff_2eutil_2erune_2ebytesEsc_24acc_str3, 2, "\\x");
Clo g_heff_2eutil_2erune_2ebytesEsc_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2ebytesEsc_24acc_entry, 4, 0};

V g_heff_2eutil_2erune_2ebytesEsc_24acc(V v_s_240, V v_i_241, V v_w_242, V v_acc_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_w_242), MK_INT(0LL))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_w_242);
    return heff_strAppend(v_acc_243, ((V)&g_heff_2eutil_2erune_2ebytesEsc_24acc_str0));
  } else {
    V v_b_245 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
    V v_t_246 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2eutil_2erune_2ebytesEsc_24acc_str1), heff_intDiv(heff_dup(v_b_245), MK_INT(16LL))));
    V v_t_247 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2eutil_2erune_2ebytesEsc_24acc_str2), heff_intMod(v_b_245, MK_INT(16LL))));
    V v_t_248 = heff_strAppend(((V)&g_heff_2eutil_2erune_2ebytesEsc_24acc_str3), heff_strAppend(v_t_246, v_t_247));
    V v_s_249 = heff_strAppend(v_acc_243, v_t_248);
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = heff_intSub(v_w_242, MK_INT(1LL));
    V t_3 = v_s_249;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_w_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
}
V g_heff_2eutil_2erune_2ebytesEsc_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2ebytesEsc_24acc(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eutil_2erune_2eruneEsc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2eruneEsc_entry, 3, 0};

V g_heff_2eutil_2erune_2eruneEsc(V v_s_240, V v_i_241, V v_w_242) {
top: ;
  V v_t_243 = heff_runeToInt(heff_strRuneAt_lent(v_s_240, v_i_241, 0));
  if (heff_intEq_c(v_t_243, MK_INT(65533LL))) {
    V v_t_245 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), heff_dup(v_w_242)));
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_runeFromInt(MK_INT(65533LL)), NTAG(TAG_Nil)});
    if (heff_strEq_c(v_t_245, heff_strOfRunes(v_t_246))) {
      return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, v_w_242));
    } else {
      HEFF_LAST return g_heff_2eutil_2erune_2ebytesEsc(v_s_240, v_i_241, v_w_242);
    }
  } else {
    return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, v_w_242));
  }
}
V g_heff_2eutil_2erune_2eruneEsc_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2eruneEsc(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eutil_2erune_2equoteGo_str0, 2, "\\\"");
HEFF_LIT(g_heff_2eutil_2erune_2equoteGo_str1, 2, "\\\\");
HEFF_LIT(g_heff_2eutil_2erune_2equoteGo_str2, 2, "\\n");
HEFF_LIT(g_heff_2eutil_2erune_2equoteGo_str3, 2, "\\r");
HEFF_LIT(g_heff_2eutil_2erune_2equoteGo_str4, 2, "\\t");
Clo g_heff_2eutil_2erune_2equoteGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2equoteGo_entry, 3, 0};

V g_heff_2eutil_2erune_2equoteGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(34LL))) {
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_strAppend(v_acc_242, ((V)&g_heff_2eutil_2erune_2equoteGo_str0));
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    } else {
      if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(92LL))) {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = heff_strAppend(v_acc_242, ((V)&g_heff_2eutil_2erune_2equoteGo_str1));
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_acc_242 = t_2;
        goto top;
      } else {
        if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(10LL))) {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = heff_strAppend(v_acc_242, ((V)&g_heff_2eutil_2erune_2equoteGo_str2));
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_acc_242 = t_2;
          goto top;
        } else {
          if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(13LL))) {
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
            V t_2 = heff_strAppend(v_acc_242, ((V)&g_heff_2eutil_2erune_2equoteGo_str3));
            v_s_240 = t_0;
            v_i_241 = t_1;
            v_acc_242 = t_2;
            goto top;
          } else {
            if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(9LL))) {
              V t_0 = v_s_240;
              V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
              V t_2 = heff_strAppend(v_acc_242, ((V)&g_heff_2eutil_2erune_2equoteGo_str4));
              v_s_240 = t_0;
              v_i_241 = t_1;
              v_acc_242 = t_2;
              goto top;
            } else {
              if (heff_intLt_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(128LL))) {
                V v_t_2410 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
                V t_0 = v_s_240;
                V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
                V t_2 = heff_strAppend(v_acc_242, v_t_2410);
                v_s_240 = t_0;
                v_i_241 = t_1;
                v_acc_242 = t_2;
                goto top;
              } else {
                V v_t_2411 = heff_intAdd(heff_dup(v_i_241), heff_strRuneWidth_lent(v_s_240, v_i_241, 0));
                V v_t_2412 = (g_heff_2eutil_2erune_2eruneEsc(heff_dup(v_s_240), heff_dup(v_i_241), heff_strRuneWidth_lent(v_s_240, v_i_241, 2)));
                V t_0 = v_s_240;
                V t_1 = v_t_2411;
                V t_2 = heff_strAppend(v_acc_242, v_t_2412);
                v_s_240 = t_0;
                v_i_241 = t_1;
                v_acc_242 = t_2;
                goto top;
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2eutil_2erune_2equoteGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2equoteGo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str0, 0, "");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str1, 1, "\"");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str2, 1, "\"");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str3, 0, "");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str4, 2, ", ");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str5, 2, "\\\"");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str6, 2, "\\\\");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str7, 0, "");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str8, 1, "\"");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str9, 1, "\"");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str10, 0, "");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str11, 2, ", ");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str12, 0, "");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str13, 2, ", ");
HEFF_LIT(g_heff_2eutil_2erune_2equoteBytesGo_str14, 0, "");
Clo g_heff_2eutil_2erune_2equoteBytesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2equoteBytesGo_entry, 4, 0};

V g_heff_2eutil_2erune_2equoteBytesGo(V v_s_240, V v_i_241, V v_run_242, V v_acc_243) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    if (heff_strEq_c_lent(v_run_242, ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str0), 2)) {
      heff_drop(v_run_242);
      return v_acc_243;
    } else {
      V v_p_246 = heff_strAppend(((V)&g_heff_2eutil_2erune_2equoteBytesGo_str1), heff_strAppend(v_run_242, ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str2)));
      if (heff_strEq_c_lent(v_acc_243, ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str3), 2)) {
        heff_drop(v_acc_243);
        return v_p_246;
      } else {
        return heff_strAppend(v_acc_243, heff_strAppend(((V)&g_heff_2eutil_2erune_2equoteBytesGo_str4), v_p_246));
      }
    }
  } else {
    V v_t_249 = heff_bool((heff_intLe_c(MK_INT(32LL), heff_strByteAt_lent(v_s_240, v_i_241, 0)) && heff_intLt_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(127LL))));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_b_2410 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
      V v_t_2413;
      if (heff_intEq_c(heff_dup(v_b_2410), MK_INT(34LL))) {
        heff_drop(v_b_2410);
        v_t_2413 = ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str5);
      } else {
        if (heff_intEq_c(heff_dup(v_b_2410), MK_INT(92LL))) {
          heff_drop(v_b_2410);
          v_t_2413 = ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str6);
        } else {
          v_t_2413 = heff_strFromByte(heff_box_u8(heff_from_int_u8(v_b_2410)));
        }
      }
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_strAppend(v_run_242, v_t_2413);
      V t_3 = v_acc_243;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_run_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_249);
      V v_acc_2417;
      if (heff_strEq_c_lent(v_run_242, ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str7), 2)) {
        heff_drop(v_run_242);
        v_acc_2417 = v_acc_243;
      } else {
        V v_p_2415 = heff_strAppend(((V)&g_heff_2eutil_2erune_2equoteBytesGo_str8), heff_strAppend(v_run_242, ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str9)));
        if (heff_strEq_c_lent(v_acc_243, ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str10), 2)) {
          heff_drop(v_acc_243);
          v_acc_2417 = v_p_2415;
        } else {
          v_acc_2417 = heff_strAppend(v_acc_243, heff_strAppend(((V)&g_heff_2eutil_2erune_2equoteBytesGo_str11), v_p_2415));
        }
      }
      V v_p_2418 = heff_intShow(heff_strByteAt_lent(v_s_240, v_i_241, 0));
      V v_t_2420;
      if (heff_strEq_c_lent(v_acc_2417, ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str12), 2)) {
        heff_drop(v_acc_2417);
        v_t_2420 = v_p_2418;
      } else {
        v_t_2420 = heff_strAppend(v_acc_2417, heff_strAppend(((V)&g_heff_2eutil_2erune_2equoteBytesGo_str13), v_p_2418));
      }
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = ((V)&g_heff_2eutil_2erune_2equoteBytesGo_str14);
      V t_3 = v_t_2420;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_run_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2eutil_2erune_2equoteBytesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2equoteBytesGo(a[0], a[1], a[2], a[3]);
}