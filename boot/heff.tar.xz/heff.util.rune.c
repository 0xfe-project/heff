// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2eutil_2erune_2ecodeAt(V, V);
V g_heff_2eutil_2erune_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2ecodeAt_clo;
V g_heff_2eutil_2erune_2edecodeFrom(V, V, V);
V g_heff_2eutil_2erune_2edecodeFrom_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2edecodeFrom_clo;
V g_heff_2eutil_2erune_2eencode(V);
V g_heff_2eutil_2erune_2eencode_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2eencode_clo;
V g_heff_2eutil_2erune_2ehexWith(V, V);
V g_heff_2eutil_2erune_2ehexWith_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2ehexWith_clo;
V g_heff_2eutil_2erune_2epadTo4(V);
V g_heff_2eutil_2erune_2epadTo4_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2epadTo4_clo;
V g_heff_2eutil_2erune_2equoted(V);
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoted_clo;
V g_heff_2eutil_2erune_2ereplacement_get(void);
V g_heff_2eutil_2erune_2ewidthAt(V, V);
V g_heff_2eutil_2erune_2ewidthAt_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2ewidthAt_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;

static V g_heff_2eutil_2erune_2ereplacement_val;
static int g_heff_2eutil_2erune_2ereplacement_st;
static V g_heff_2eutil_2erune_2ereplacement_init(void) {
  return MK_INT(65533LL);
}
V g_heff_2eutil_2erune_2ereplacement_get(void) {
  if (g_heff_2eutil_2erune_2ereplacement_st == 2) return g_heff_2eutil_2erune_2ereplacement_val;
  if (g_heff_2eutil_2erune_2ereplacement_st == 1) heff_fail("defined by itself");
  g_heff_2eutil_2erune_2ereplacement_st = 1;
  g_heff_2eutil_2erune_2ereplacement_val = heff_tr(g_heff_2eutil_2erune_2ereplacement_init());
  g_heff_2eutil_2erune_2ereplacement_st = 2;
  return g_heff_2eutil_2erune_2ereplacement_val;
}
Clo g_heff_2eutil_2erune_2ehexWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2ehexWith_entry, 2, 0};

V g_heff_2eutil_2erune_2ehexWith(V v_digits_240, V v_n_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_n_241), MK_INT(16LL))) {
    return heff_strSlice(v_digits_240, heff_dup(v_n_241), heff_intAdd(v_n_241, MK_INT(1LL)));
  } else {
    V v_t_243 = heff_intDiv(heff_dup(v_n_241), MK_INT(16LL));
    V v_t_244 = (g_heff_2eutil_2erune_2ehexWith(heff_dup(v_digits_240), v_t_243));
    V v_t_245 = heff_intMod(heff_dup(v_n_241), MK_INT(16LL));
    V v_t_246 = heff_intMod(v_n_241, MK_INT(16LL));
    V v_t_247 = heff_strSlice(v_digits_240, v_t_245, heff_intAdd(v_t_246, MK_INT(1LL)));
    return heff_strAppend(v_t_244, v_t_247);
  }
}
V g_heff_2eutil_2erune_2ehexWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2ehexWith(a[0], a[1]);
}
HEFF_STRA(g_heff_2eutil_2erune_2epadTo4_str0, 1, (48));
Clo g_heff_2eutil_2erune_2epadTo4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2epadTo4_entry, 1, 0};

V g_heff_2eutil_2erune_2epadTo4(V v_s_240) {
top: ;
  if (heff_intLe_c(MK_INT(4LL), heff_strLength(heff_dup(v_s_240)))) {
    return v_s_240;
  } else {
    V t_0 = heff_strAppend(((V)&g_heff_2eutil_2erune_2epadTo4_str0), v_s_240);
    v_s_240 = t_0;
    goto top;
  }
}
V g_heff_2eutil_2erune_2epadTo4_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2epadTo4(a[0]);
}
Clo g_heff_2eutil_2erune_2eencode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2eencode_entry, 1, 0};

V g_heff_2eutil_2erune_2eencode(V v_c_240) {
top: ;
  V v_x1_245;
  if (heff_intLe_c(MK_INT(0LL), heff_dup(v_c_240))) {
    if (heff_intLe_c(heff_dup(v_c_240), MK_INT(1114111LL))) {
      V v_x1_244;
      if (heff_intLe_c(MK_INT(55296LL), heff_dup(v_c_240))) {
        v_x1_244 = heff_intLe(heff_dup(v_c_240), MK_INT(57343LL));
      } else {
        v_x1_244 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_x1_244)) {
      case TAG_True: {
        v_x1_245 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_x1_245 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x1_244);
      }
    } else {
      v_x1_245 = NTAG(TAG_False);
    }
  } else {
    v_x1_245 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_x1_245)) {
  case TAG_True: {
    if (heff_intLt_c(heff_dup(v_c_240), MK_INT(65536LL))) {
      return heff_strFromCharCode(v_c_240);
    } else {
      V v_t_247 = heff_intDiv(heff_intSub(heff_dup(v_c_240), MK_INT(65536LL)), MK_INT(1024LL));
      V v_t_248 = heff_strFromCharCode(heff_intAdd(MK_INT(55296LL), v_t_247));
      V v_t_249 = heff_intMod(heff_intSub(v_c_240, MK_INT(65536LL)), MK_INT(1024LL));
      V v_t_2410 = heff_strFromCharCode(heff_intAdd(MK_INT(56320LL), v_t_249));
      return heff_strAppend(v_t_248, v_t_2410);
    }
  }
  case TAG_False: {
    heff_drop(v_c_240);
    return heff_strFromCharCode(heff_dup(g_heff_2eutil_2erune_2ereplacement_get()));
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eutil_2erune_2eencode_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2eencode(a[0]);
}
Clo g_heff_2eutil_2erune_2ecodeAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2ecodeAt_entry, 2, 0};

V g_heff_2eutil_2erune_2ecodeAt(V v_s_240, V v_i_241) {
top: ;
  V v_c_242 = heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241));
  V v_t_247;
  if (heff_intLe_c(MK_INT(55296LL), heff_dup(v_c_242))) {
    if (heff_intLe_c(v_c_242, MK_INT(56319LL))) {
      V v_c_245 = heff_strCharCode(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
      if (heff_intLe_c(MK_INT(56320LL), heff_dup(v_c_245))) {
        v_t_247 = heff_intLe(v_c_245, MK_INT(57343LL));
      } else {
        heff_drop(v_c_245);
        v_t_247 = NTAG(TAG_False);
      }
    } else {
      v_t_247 = NTAG(TAG_False);
    }
  } else {
    heff_drop(v_c_242);
    v_t_247 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    V v_t_248 = heff_intSub(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(55296LL));
    V v_t_249 = heff_intAdd(MK_INT(65536LL), heff_intMul(v_t_248, MK_INT(1024LL)));
    V v_t_2410 = heff_strCharCode(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)));
    return heff_intAdd(v_t_249, heff_intSub(v_t_2410, MK_INT(56320LL)));
  }
  case TAG_False: {
    V v_c_2411 = heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241));
    V v_t_2418;
    if (heff_intLe_c(MK_INT(55296LL), heff_dup(v_c_2411))) {
      if (heff_intLe_c(v_c_2411, MK_INT(56319LL))) {
        v_t_2418 = NTAG(TAG_True);
      } else {
        V v_c_2414 = heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241));
        if (heff_intLe_c(MK_INT(56320LL), heff_dup(v_c_2414))) {
          v_t_2418 = heff_intLe(v_c_2414, MK_INT(57343LL));
        } else {
          heff_drop(v_c_2414);
          v_t_2418 = NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_c_2411);
      V v_c_2416 = heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241));
      if (heff_intLe_c(MK_INT(56320LL), heff_dup(v_c_2416))) {
        v_t_2418 = heff_intLe(v_c_2416, MK_INT(57343LL));
      } else {
        heff_drop(v_c_2416);
        v_t_2418 = NTAG(TAG_False);
      }
    }
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return heff_dup(g_heff_2eutil_2erune_2ereplacement_get());
    }
    case TAG_False: {
      return heff_strCharCode(v_s_240, v_i_241);
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eutil_2erune_2ecodeAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2ecodeAt(a[0], a[1]);
}
Clo g_heff_2eutil_2erune_2ewidthAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2ewidthAt_entry, 2, 0};

V g_heff_2eutil_2erune_2ewidthAt(V v_s_240, V v_i_241) {
top: ;
  V v_c_242 = heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241));
  if (heff_intLe_c(MK_INT(55296LL), heff_dup(v_c_242))) {
    if (heff_intLe_c(v_c_242, MK_INT(56319LL))) {
      V v_c_245 = heff_strCharCode(v_s_240, heff_intAdd(v_i_241, MK_INT(1LL)));
      if (heff_intLe_c(MK_INT(56320LL), heff_dup(v_c_245))) {
        if (heff_intLe_c(v_c_245, MK_INT(57343LL))) {
          return MK_INT(2LL);
        } else {
          return MK_INT(1LL);
        }
      } else {
        heff_drop(v_c_245);
        return MK_INT(1LL);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return MK_INT(1LL);
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    heff_drop(v_c_242);
    return MK_INT(1LL);
  }
}
V g_heff_2eutil_2erune_2ewidthAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2ewidthAt(a[0], a[1]);
}
Clo g_heff_2eutil_2erune_2edecodeFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2edecodeFrom_entry, 3, 0};

V g_heff_2eutil_2erune_2edecodeFrom(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  } else {
    V v_t_244 = (g_heff_2eutil_2erune_2ewidthAt(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_245 = (g_heff_2eutil_2erune_2ecodeAt(heff_dup(v_s_240), heff_dup(v_i_241)));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, v_t_244);
    V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_acc_242});
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2eutil_2erune_2edecodeFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2edecodeFrom(a[0], a[1], a[2]);
}
HEFF_STRA(g_heff_2eutil_2erune_2equoted_str0, 2, (92, 39));
HEFF_STRA(g_heff_2eutil_2erune_2equoted_str1, 2, (92, 92));
HEFF_STRA(g_heff_2eutil_2erune_2equoted_str2, 2, (92, 110));
HEFF_STRA(g_heff_2eutil_2erune_2equoted_str3, 2, (92, 116));
HEFF_STRA(g_heff_2eutil_2erune_2equoted_str4, 2, (92, 114));
HEFF_STRA(g_heff_2eutil_2erune_2equoted_str5, 16, (48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102));
HEFF_STRA(g_heff_2eutil_2erune_2equoted_str6, 3, (92, 117, 123));
HEFF_STRA(g_heff_2eutil_2erune_2equoted_str7, 1, (125));
HEFF_STRA(g_heff_2eutil_2erune_2equoted_str8, 16, (48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102));
HEFF_STRA(g_heff_2eutil_2erune_2equoted_str9, 3, (92, 117, 123));
HEFF_STRA(g_heff_2eutil_2erune_2equoted_str10, 1, (125));
Clo g_heff_2eutil_2erune_2equoted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2erune_2equoted_entry, 1, 0};

V g_heff_2eutil_2erune_2equoted(V v_c_240) {
top: ;
  if (heff_intEq_c(heff_dup(v_c_240), MK_INT(39LL))) {
    heff_drop(v_c_240);
    return ((V)&g_heff_2eutil_2erune_2equoted_str0);
  } else {
    if (heff_intEq_c(heff_dup(v_c_240), MK_INT(92LL))) {
      heff_drop(v_c_240);
      return ((V)&g_heff_2eutil_2erune_2equoted_str1);
    } else {
      if (heff_intEq_c(heff_dup(v_c_240), MK_INT(10LL))) {
        heff_drop(v_c_240);
        return ((V)&g_heff_2eutil_2erune_2equoted_str2);
      } else {
        if (heff_intEq_c(heff_dup(v_c_240), MK_INT(9LL))) {
          heff_drop(v_c_240);
          return ((V)&g_heff_2eutil_2erune_2equoted_str3);
        } else {
          if (heff_intEq_c(heff_dup(v_c_240), MK_INT(13LL))) {
            heff_drop(v_c_240);
            return ((V)&g_heff_2eutil_2erune_2equoted_str4);
          } else {
            V v_x1_2410;
            if (heff_intLe_c(MK_INT(0LL), heff_dup(v_c_240))) {
              if (heff_intLe_c(heff_dup(v_c_240), MK_INT(1114111LL))) {
                V v_x1_249;
                if (heff_intLe_c(MK_INT(55296LL), heff_dup(v_c_240))) {
                  v_x1_249 = heff_intLe(heff_dup(v_c_240), MK_INT(57343LL));
                } else {
                  v_x1_249 = NTAG(TAG_False);
                }
                switch (heff_tag_of(v_x1_249)) {
                case TAG_True: {
                  v_x1_2410 = NTAG(TAG_False);
                  break;
                }
                case TAG_False: {
                  v_x1_2410 = NTAG(TAG_True);
                  break;
                }
                default: heff_nomatch(v_x1_249);
                }
              } else {
                v_x1_2410 = NTAG(TAG_False);
              }
            } else {
              v_x1_2410 = NTAG(TAG_False);
            }
            switch (heff_tag_of(v_x1_2410)) {
            case TAG_True: {
              if (heff_intLt_c(heff_dup(v_c_240), MK_INT(32LL))) {
                V v_t_2412 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2eutil_2erune_2equoted_str5), v_c_240));
                return heff_strAppend(((V)&g_heff_2eutil_2erune_2equoted_str6), heff_strAppend(v_t_2412, ((V)&g_heff_2eutil_2erune_2equoted_str7)));
              } else {
                if (heff_intLe_c(MK_INT(127LL), heff_dup(v_c_240))) {
                  if (heff_intLt_c(heff_dup(v_c_240), MK_INT(160LL))) {
                    V v_t_2415 = (g_heff_2eutil_2erune_2ehexWith(((V)&g_heff_2eutil_2erune_2equoted_str8), v_c_240));
                    return heff_strAppend(((V)&g_heff_2eutil_2erune_2equoted_str9), heff_strAppend(v_t_2415, ((V)&g_heff_2eutil_2erune_2equoted_str10)));
                  } else {
                    HEFF_LAST return g_heff_2eutil_2erune_2eencode(v_c_240);
                  }
                } else {
                  HEFF_LAST return g_heff_2eutil_2erune_2eencode(v_c_240);
                }
              }
            }
            case TAG_False: {
              heff_drop(v_c_240);
              HEFF_LAST return g_heff_2eutil_2erune_2eencode(heff_dup(g_heff_2eutil_2erune_2ereplacement_get()));
            }
            default: return heff_nomatch(v_x1_2410);
            }
          }
        }
      }
    }
  }
}
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2erune_2equoted(a[0]);
}