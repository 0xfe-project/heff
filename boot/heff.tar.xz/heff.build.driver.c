// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_AbsConst 8406
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Div 16157
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_HLocal 25864
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Ok 9325
#define TAG_RAbandoned 16367
#define TAG_RDiverged 61572
#define TAG_RSucceeded 21638
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_Small 51389
#define TAG_SmallU 20221
#define TAG_SpId 35501
#define TAG_TopL 65516
#define TAG_VArr 15466
#define TAG_VCons 11629
#define TAG_VErased 42634
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VOpaque 37311
#define TAG_VPrimInt 4244
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_above 293969847
#define LBL_again 294104954
#define LBL_alias 294261354
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_assoc 294479919
#define LBL_broken 566525696
#define LBL_by 9918
#define LBL_byName 571997869
#define LBL_cached 579094605
#define LBL_cmt 308164
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_defs 9574869
#define LBL_deps 9575179
#define LBL_diags 296935042
#define LBL_discarded 1490202606
#define LBL_doc 309170
#define LBL_effect 641056956
#define LBL_el 9998
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_err 310239
#define LBL_expectFrom 460383968
#define LBL_expectTo 956903013
#define LBL_expected 956903529
#define LBL_expr 9623228
#define LBL_failure 1292767177
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_groups 709681407
#define LBL_holds 300818350
#define LBL_i 323
#define LBL_id 10114
#define LBL_implicit 319715269
#define LBL_imports 10411951
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_known 303562589
#define LBL_labels 836724522
#define LBL_lenient 294367673
#define LBL_level 304224158
#define LBL_library 398066429
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_lines 304335641
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_multi 305615187
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_opens 307306371
#define LBL_ops 319788
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_own 320000
#define LBL_owner 307523277
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_places 961367927
#define LBL_property 1899481104
#define LBL_renames 1324191545
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_severity 75955546
#define LBL_shown 310772011
#define LBL_shrinks 154032591
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stop 10036425
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_to 10466
#define LBL_tok 324554
#define LBL_top 324559
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watch 314261737
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_decls__diags__fixities__broken[] = {LBL_decls, LBL_diags, LBL_fixities, LBL_broken};
static uint32_t shape_expected__from__to[] = {LBL_expected, LBL_from, LBL_to};
static uint32_t shape_first__again[] = {LBL_first, LBL_again};
static uint32_t shape_from__to__expr__ty__value__expected__holds__expectFrom__expectTo__doc[] = {LBL_from, LBL_to, LBL_expr, LBL_ty, LBL_value, LBL_expected, LBL_holds, LBL_expectFrom, LBL_expectTo, LBL_doc};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_key__by__span[] = {LBL_key, LBL_by, LBL_span};
static uint32_t shape_key__effect[] = {LBL_key, LBL_effect};
static uint32_t shape_key__module[] = {LBL_key, LBL_module};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_known__fixities__lenient__place[] = {LBL_known, LBL_fixities, LBL_lenient, LBL_place};
static uint32_t shape_lines__stop[] = {LBL_lines, LBL_stop};
static uint32_t shape_module__alias[] = {LBL_module, LBL_alias};
static uint32_t shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached[] = {LBL_module, LBL_path, LBL_shown, LBL_source, LBL_decls, LBL_top, LBL_diags, LBL_own, LBL_deps, LBL_opens, LBL_aliases, LBL_fixities, LBL_cached};
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_name__key__module[] = {LBL_name, LBL_key, LBL_module};
static uint32_t shape_name__key__ty__level[] = {LBL_name, LBL_key, LBL_ty, LBL_level};
static uint32_t shape_name__ok__property__runs__discarded__shrinks__labels__notes__failure__seed[] = {LBL_name, LBL_ok, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed};
static uint32_t shape_name__value[] = {LBL_name, LBL_value};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_instances};
static uint32_t shape_out__multi__first[] = {LBL_out, LBL_multi, LBL_first};
static uint32_t shape_owner__line__watch[] = {LBL_owner, LBL_line, LBL_watch};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
static uint32_t shape_ty__el[] = {LBL_ty, LBL_el};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2edriver_2eaddTests(V, V, V, V);
V g_heff_2ebuild_2edriver_2eaddTests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eaddTests_clo;
V g_heff_2ebuild_2edriver_2eagainGo(V, V, V);
V g_heff_2ebuild_2edriver_2eagainGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eagainGo_clo;
V g_heff_2ebuild_2edriver_2ealiasModule(V, V);
V g_heff_2ebuild_2edriver_2ealiasModule_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasModule_clo;
V g_heff_2ebuild_2edriver_2ealiasOpen(V, V, V, V);
V g_heff_2ebuild_2edriver_2ealiasOpen_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasOpen_clo;
V g_heff_2ebuild_2edriver_2ealiasPairs(V);
V g_heff_2ebuild_2edriver_2ealiasPairs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasPairs_clo;
V g_heff_2ebuild_2edriver_2ealiasQOne(V, V, V);
V g_heff_2ebuild_2edriver_2ealiasQOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasQOne_clo;
V g_heff_2ebuild_2edriver_2ealiasQualified(V, V, V);
V g_heff_2ebuild_2edriver_2ealiasQualified_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ealiasQualified_clo;
V g_heff_2ebuild_2edriver_2eanyD(V, V);
V g_heff_2ebuild_2edriver_2eanyD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_clo;
V g_heff_2ebuild_2edriver_2eappendD(V, V);
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendD_clo;
V g_heff_2ebuild_2edriver_2eappendLv(V, V);
V g_heff_2ebuild_2edriver_2eappendLv_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eappendLv_clo;
V g_heff_2ebuild_2edriver_2ebrokenIn(V);
V g_heff_2ebuild_2edriver_2ebrokenIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ebrokenIn_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2eckOf(V);
V g_heff_2ebuild_2edriver_2eckOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eckOf_clo;
V g_heff_2ebuild_2edriver_2eclashMap(V, V);
V g_heff_2ebuild_2edriver_2eclashMap_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclashMap_clo;
V g_heff_2ebuild_2edriver_2ecloseFieldsGo(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseFieldsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseFieldsGo_clo;
V g_heff_2ebuild_2edriver_2ecloseTermF(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTermF_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTermF_clo;
V g_heff_2ebuild_2edriver_2ecloseTypeF(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2ecloseTypeF_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecloseTypeF_clo;
V g_heff_2ebuild_2edriver_2eclosureGo(V, V, V);
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eclosureGo_clo;
V g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703(V);
V g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703_clo;
V g_heff_2ebuild_2edriver_2econcatMapD_24s1236007820x849009822(V);
V g_heff_2ebuild_2edriver_2econcatMapD_24s1236007820x849009822_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2econcatMapD_24s1236007820x849009822_clo;
V g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301(V);
V g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301_clo;
V g_heff_2ebuild_2edriver_2edefKind(V, V);
V g_heff_2ebuild_2edriver_2edefKind_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2edefKind_clo;
V g_heff_2ebuild_2edriver_2edefUnder(V, V, V);
V g_heff_2ebuild_2edriver_2edefUnder_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2edefUnder_clo;
V g_heff_2ebuild_2edriver_2edocExpect(V);
V g_heff_2ebuild_2edriver_2edocExpect_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2edocExpect_clo;
V g_heff_2ebuild_2edriver_2eearlierGo(V, V, V, V);
V g_heff_2ebuild_2edriver_2eearlierGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eearlierGo_clo;
V g_heff_2ebuild_2edriver_2eeffectOfKey(V, V);
V g_heff_2ebuild_2edriver_2eeffectOfKey_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eeffectOfKey_clo;
V g_heff_2ebuild_2edriver_2eelabAliased(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabAliased_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabAliased_clo;
V g_heff_2ebuild_2edriver_2eelabClashed(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabClashed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabClashed_clo;
V g_heff_2ebuild_2edriver_2eelabDecls(V, V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabDecls_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabDecls_clo;
V g_heff_2ebuild_2edriver_2eelabDirect(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabDirect_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabDirect_clo;
V g_heff_2ebuild_2edriver_2eelabEnv(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabEnv_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabEnv_clo;
V g_heff_2ebuild_2edriver_2eelabNeeding(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabNeeding_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNeeding_clo;
V g_heff_2ebuild_2edriver_2eelabNext(V, V, V);
V g_heff_2ebuild_2edriver_2eelabNext_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabNext_clo;
V g_heff_2ebuild_2edriver_2eelabRead(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabRead_clo;
V g_heff_2ebuild_2edriver_2eelabTop(V, V, V, V, V);
V g_heff_2ebuild_2edriver_2eelabTop_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eelabTop_clo;
V g_heff_2ebuild_2edriver_2eenvOne(V, V);
V g_heff_2ebuild_2edriver_2eenvOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eenvOne_clo;
V g_heff_2ebuild_2edriver_2eevalPick(V, V, V);
V g_heff_2ebuild_2edriver_2eevalPick_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevalPick_clo;
V g_heff_2ebuild_2edriver_2eevalWatch(V, V);
V g_heff_2ebuild_2edriver_2eevalWatch_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevalWatch_clo;
V g_heff_2ebuild_2edriver_2eevaluate(V);
V g_heff_2ebuild_2edriver_2eevaluate_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevaluate_clo;
V g_heff_2ebuild_2edriver_2eexpectAfter(V, V, V);
V g_heff_2ebuild_2edriver_2eexpectAfter_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexpectAfter_clo;
V g_heff_2ebuild_2edriver_2eexpectGo(V, V, V, V);
V g_heff_2ebuild_2edriver_2eexpectGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexpectGo_clo;
V g_heff_2ebuild_2edriver_2eexpectLine(V, V, V);
V g_heff_2ebuild_2edriver_2eexpectLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexpectLine_clo;
V g_heff_2ebuild_2edriver_2efailureOfV(V);
V g_heff_2ebuild_2edriver_2efailureOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efailureOfV_clo;
V g_heff_2ebuild_2edriver_2efieldV(V, V);
V g_heff_2ebuild_2edriver_2efieldV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efieldV_clo;
V g_heff_2ebuild_2edriver_2efindChecked(V, V);
V g_heff_2ebuild_2edriver_2efindChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efindChecked_clo;
V g_heff_2ebuild_2edriver_2efindFirst(V, V);
V g_heff_2ebuild_2edriver_2efindFirst_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efindFirst_clo;
V g_heff_2ebuild_2edriver_2efindRunnable(V, V, V);
V g_heff_2ebuild_2edriver_2efindRunnable_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efindRunnable_clo;
V g_heff_2ebuild_2edriver_2efits(V, V);
V g_heff_2ebuild_2edriver_2efits_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efits_clo;
V g_heff_2ebuild_2edriver_2efixOf(V, V);
V g_heff_2ebuild_2edriver_2efixOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixOf_clo;
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
V g_heff_2ebuild_2edriver_2efixityLine(V, V, V);
V g_heff_2ebuild_2edriver_2efixityLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixityLine_clo;
V g_heff_2ebuild_2edriver_2efixityLines(V, V, V);
V g_heff_2ebuild_2edriver_2efixityLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixityLines_clo;
V g_heff_2ebuild_2edriver_2egivesWay(V, V, V);
V g_heff_2ebuild_2edriver_2egivesWay_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2egivesWay_clo;
V g_heff_2ebuild_2edriver_2eglueOne(V, V);
V g_heff_2ebuild_2edriver_2eglueOne_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eglueOne_clo;
V g_heff_2ebuild_2edriver_2ehint(V);
V g_heff_2ebuild_2edriver_2ehint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ehint_clo;
V g_heff_2ebuild_2edriver_2eimportLines(V);
V g_heff_2ebuild_2edriver_2eimportLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eimportLines_clo;
V g_heff_2ebuild_2edriver_2eimportOfGo(V, V, V);
V g_heff_2ebuild_2edriver_2eimportOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eimportOfGo_clo;
V g_heff_2ebuild_2edriver_2eimportedAgain(V, V);
V g_heff_2ebuild_2edriver_2eimportedAgain_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eimportedAgain_clo;
V g_heff_2ebuild_2edriver_2eimportedFix(V, V);
V g_heff_2ebuild_2edriver_2eimportedFix_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eimportedFix_clo;
V g_heff_2ebuild_2edriver_2einterface(V);
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2einterface_clo;
V g_heff_2ebuild_2edriver_2eisTestEl(V);
V g_heff_2ebuild_2edriver_2eisTestEl_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisTestEl_clo;
V g_heff_2ebuild_2edriver_2eisTestOwn(V, V);
V g_heff_2ebuild_2edriver_2eisTestOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisTestOwn_clo;
V g_heff_2ebuild_2edriver_2elabelOfV(V);
V g_heff_2ebuild_2edriver_2elabelOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elabelOfV_clo;
V g_heff_2ebuild_2edriver_2elastChecked(V);
V g_heff_2ebuild_2edriver_2elastChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elastChecked_clo;
V g_heff_2ebuild_2edriver_2elean(V);
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elean_clo;
V g_heff_2ebuild_2edriver_2elistOfV(V);
V g_heff_2ebuild_2edriver_2elistOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elistOfV_clo;
V g_heff_2ebuild_2edriver_2emetIn(V, V, V, V);
V g_heff_2ebuild_2edriver_2emetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2emetIn_clo;
V g_heff_2ebuild_2edriver_2emkWatchInfo(V, V, V, V, V, V);
V g_heff_2ebuild_2edriver_2emkWatchInfo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2emkWatchInfo_clo;
V g_heff_2ebuild_2edriver_2emoduleStruct(V, V, V);
V g_heff_2ebuild_2edriver_2emoduleStruct_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2emoduleStruct_clo;
V g_heff_2ebuild_2edriver_2enubByName(V);
V g_heff_2ebuild_2edriver_2enubByName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubByName_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2eopenNames(V);
V g_heff_2ebuild_2edriver_2eopenNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eopenNames_clo;
V g_heff_2ebuild_2edriver_2eoutcomeOfV(V);
V g_heff_2ebuild_2edriver_2eoutcomeOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eoutcomeOfV_clo;
V g_heff_2ebuild_2edriver_2eoutcomesOf(V, V, V);
V g_heff_2ebuild_2edriver_2eoutcomesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eoutcomesOf_clo;
V g_heff_2ebuild_2edriver_2eownOf(V, V);
V g_heff_2ebuild_2edriver_2eownOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eownOf_clo;
V g_heff_2ebuild_2edriver_2eownerOf(V, V);
V g_heff_2ebuild_2edriver_2eownerOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eownerOf_clo;
V g_heff_2ebuild_2edriver_2epickOutcomes(V, V, V, V);
V g_heff_2ebuild_2edriver_2epickOutcomes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2epickOutcomes_clo;
V g_heff_2ebuild_2edriver_2eplaceAt(V, V);
V g_heff_2ebuild_2edriver_2eplaceAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eplaceAt_clo;
V g_heff_2ebuild_2edriver_2eprimDeclsGo(V, V, V);
V g_heff_2ebuild_2edriver_2eprimDeclsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eprimDeclsGo_clo;
V g_heff_2ebuild_2edriver_2epromoteAt(V, V, V, V);
V g_heff_2ebuild_2edriver_2epromoteAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2epromoteAt_clo;
V g_heff_2ebuild_2edriver_2ereadExpRead(V, V, V);
V g_heff_2ebuild_2edriver_2ereadExpRead_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ereadExpRead_clo;
V g_heff_2ebuild_2edriver_2ereadExpectation(V, V, V, V);
V g_heff_2ebuild_2edriver_2ereadExpectation_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ereadExpectation_clo;
V g_heff_2ebuild_2edriver_2erunTests(V, V);
V g_heff_2ebuild_2edriver_2erunTests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erunTests_clo;
V g_heff_2ebuild_2edriver_2eshowTySx(V, V);
V g_heff_2ebuild_2edriver_2eshowTySx_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eshowTySx_clo;
V g_heff_2ebuild_2edriver_2eshownGlobal(V, V, V);
V g_heff_2ebuild_2edriver_2eshownGlobal_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eshownGlobal_clo;
V g_heff_2ebuild_2edriver_2esigEntry(V, V, V);
V g_heff_2ebuild_2edriver_2esigEntry_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2esigEntry_clo;
V g_heff_2ebuild_2edriver_2espanOfName(V, V);
V g_heff_2ebuild_2edriver_2espanOfName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2espanOfName_clo;
V g_heff_2ebuild_2edriver_2estructAdd(V, V, V, V);
V g_heff_2ebuild_2edriver_2estructAdd_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructAdd_clo;
V g_heff_2ebuild_2edriver_2estructBody(V, V, V);
V g_heff_2ebuild_2edriver_2estructBody_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructBody_clo;
V g_heff_2ebuild_2edriver_2estructEntryOf(V, V);
V g_heff_2ebuild_2edriver_2estructEntryOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructEntryOf_clo;
V g_heff_2ebuild_2edriver_2estructFieldsGo(V, V, V);
V g_heff_2ebuild_2edriver_2estructFieldsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructFieldsGo_clo;
V g_heff_2ebuild_2edriver_2estructIdxGo(V, V, V);
V g_heff_2ebuild_2edriver_2estructIdxGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2estructIdxGo_clo;
V g_heff_2ebuild_2edriver_2etestOwner(V, V);
V g_heff_2ebuild_2edriver_2etestOwner_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestOwner_clo;
V g_heff_2ebuild_2edriver_2etestReportOf(V, V);
V g_heff_2ebuild_2edriver_2etestReportOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etestReportOf_clo;
V g_heff_2ebuild_2edriver_2ethawedChecked(V, V, V, V);
V g_heff_2ebuild_2edriver_2ethawedChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ethawedChecked_clo;
V g_heff_2ebuild_2edriver_2etraceless(V);
V g_heff_2ebuild_2edriver_2etraceless_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etraceless_clo;
V g_heff_2ebuild_2edriver_2etwiceDiag(V, V, V, V);
V g_heff_2ebuild_2edriver_2etwiceDiag_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etwiceDiag_clo;
V g_heff_2ebuild_2edriver_2etwicesGo(V, V);
V g_heff_2ebuild_2edriver_2etwicesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etwicesGo_clo;
V g_heff_2ebuild_2edriver_2etypeArgsOf(V, V);
V g_heff_2ebuild_2edriver_2etypeArgsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2etypeArgsOf_clo;
V g_heff_2ebuild_2edriver_2ewatchExpect(V);
V g_heff_2ebuild_2edriver_2ewatchExpect_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchExpect_clo;
V g_heff_2ebuild_2edriver_2ewatchInfo(V, V, V);
V g_heff_2ebuild_2edriver_2ewatchInfo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchInfo_clo;
V g_heff_2ebuild_2edriver_2ewatchesOf(V, V);
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo;
V g_heff_2ebuild_2edriver_2ewithDiags(V, V);
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithDiags_clo;
V g_heff_2ebuild_2edriver_2ewithEntry(V, V, V);
V g_heff_2ebuild_2edriver_2ewithEntry_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithEntry_clo;
V g_heff_2ebuild_2edriver_2ewithImportedInstances(V, V, V);
V g_heff_2ebuild_2edriver_2ewithImportedInstances_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithImportedInstances_clo;
V g_heff_2ebuild_2edriver_2ewithParseBroken(V, V, V);
V g_heff_2ebuild_2edriver_2ewithParseBroken_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithParseBroken_clo;
V g_heff_2ebuild_2edriver_2ewithPlace(V, V, V);
V g_heff_2ebuild_2edriver_2ewithPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithPlace_clo;
V g_heff_2ebuild_2edriver_2ewithTwice(V, V, V, V);
V g_heff_2ebuild_2edriver_2ewithTwice_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ewithTwice_clo;
V g_heff_2ecompile_2eerase_2eisType(V, V);
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eisType_clo;
V g_heff_2ecompile_2einterp_2eapplyErased(V, V);
V g_heff_2ecompile_2einterp_2eapplyErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eapplyErased_clo;
V g_heff_2ecompile_2einterp_2eevalGlobalsGo(V, V, V, V);
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_clo;
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1251174705x232593684(V, V, V, V, V, V);
V g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1251174705x232593684_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1251174705x232593684_clo;
V g_heff_2ecompile_2einterp_2efixThunk(V, V, V);
V g_heff_2ecompile_2einterp_2efixThunk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixThunk_clo;
V g_heff_2ecompile_2einterp_2eglobalEnvGo(V, V);
V g_heff_2ecompile_2einterp_2eglobalEnvGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eglobalEnvGo_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2eelab_2eeffect_2ecomputationEffect(V, V);
V g_heff_2eelab_2eeffect_2ecomputationEffect_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2ecomputationEffect_clo;
V g_heff_2eelab_2eeffect_2eleaves(V);
V g_heff_2eelab_2eeffect_2eleaves_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeffect_2eleaves_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
V g_heff_2eelab_2eglobals_2eaddAmbiguous(V, V, V);
V g_heff_2eelab_2eglobals_2eaddAmbiguous_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddAmbiguous_clo;
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2eglobals_2eemptyGlobals_get(void);
V g_heff_2eelab_2eglobals_2elookupName(V, V);
V g_heff_2eelab_2eglobals_2elookupName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2elookupName_clo;
V g_heff_2eelab_2eparams_2eeqLevel(V, V);
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2eeqLevel_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2etoplevel_2ethawDone(V);
V g_heff_2eelab_2etoplevel_2ethawDone_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawDone_clo;
V g_heff_2eelab_2etoplevel_2etopGo(V, V, V);
V g_heff_2eelab_2etoplevel_2etopGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_clo;
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(V, V);
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void);
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2esyntax_2eimport_2erenamed(V, V);
V g_heff_2esyntax_2eimport_2erenamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2erenamed_clo;
V g_heff_2esyntax_2epresyntax_2eclassify_get(void);
V g_heff_2esyntax_2epsurface_2eisOperator(V);
V g_heff_2esyntax_2epsurface_2eisOperator_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eisOperator_clo;
V g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761_clo;
V g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_clo;
V g_heff_2esyntax_2esurface_2efixitiesOfText(V, V);
V g_heff_2esyntax_2esurface_2efixitiesOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixitiesOfText_clo;
V g_heff_2esyntax_2esurface_2ereadLexed(V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_clo;
V g_heff_2eutil_2edict_2eempty_get(void);
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1725367856x1498536808(V);
V g_list_2efilter_24s1725367856x1498536808_entry(V self, V *a);
extern Clo g_list_2efilter_24s1725367856x1498536808_clo;
V g_list_2efilter_24s2048945121x1749617505(V, V);
V g_list_2efilter_24s2048945121x1749617505_entry(V self, V *a);
extern Clo g_list_2efilter_24s2048945121x1749617505_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1261443129x1682844402(V, V);
V g_list_2efoldl_24s1261443129x1682844402_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1261443129x1682844402_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1659066958x125973700(V, V);
V g_list_2efoldl_24s1659066958x125973700_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659066958x125973700_clo;
V g_list_2efoldl_24s1936649287x1723798793(V, V);
V g_list_2efoldl_24s1936649287x1723798793_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1936649287x1723798793_clo;
V g_list_2efoldl_24s337463599x663364213(V, V);
V g_list_2efoldl_24s337463599x663364213_entry(V self, V *a);
extern Clo g_list_2efoldl_24s337463599x663364213_clo;
V g_list_2efoldl_24s407249128x802036125(V, V);
V g_list_2efoldl_24s407249128x802036125_entry(V self, V *a);
extern Clo g_list_2efoldl_24s407249128x802036125_clo;
V g_list_2efoldl_24s767745157x1794017821(V, V);
V g_list_2efoldl_24s767745157x1794017821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s767745157x1794017821_clo;
V g_list_2efoldl_24s999799596x1949685079(V, V);
V g_list_2efoldl_24s999799596x1949685079_entry(V self, V *a);
extern Clo g_list_2efoldl_24s999799596x1949685079_clo;
V g_list_2elookupBy(V, V, V);
V g_list_2elookupBy_entry(V self, V *a);
extern Clo g_list_2elookupBy_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1534167768x1221742344(V);
V g_list_2emap_24s1534167768x1221742344_entry(V self, V *a);
extern Clo g_list_2emap_24s1534167768x1221742344_clo;
V g_list_2emap_24s1535007417x1587061701(V);
V g_list_2emap_24s1535007417x1587061701_entry(V self, V *a);
extern Clo g_list_2emap_24s1535007417x1587061701_clo;
V g_list_2emap_24s1895313378x47656836(V);
V g_list_2emap_24s1895313378x47656836_entry(V self, V *a);
extern Clo g_list_2emap_24s1895313378x47656836_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s214260857x938990544(V);
V g_list_2emap_24s214260857x938990544_entry(V self, V *a);
extern Clo g_list_2emap_24s214260857x938990544_clo;
V g_list_2emap_24s218655275x981659442(V);
V g_list_2emap_24s218655275x981659442_entry(V self, V *a);
extern Clo g_list_2emap_24s218655275x981659442_clo;
V g_list_2emap_24s268264395x330149387(V, V, V, V);
V g_list_2emap_24s268264395x330149387_entry(V self, V *a);
extern Clo g_list_2emap_24s268264395x330149387_clo;
V g_list_2emap_24s374365348x2042978339(V, V);
V g_list_2emap_24s374365348x2042978339_entry(V self, V *a);
extern Clo g_list_2emap_24s374365348x2042978339_clo;
V g_list_2emap_24s424270175x1918189508(V);
V g_list_2emap_24s424270175x1918189508_entry(V self, V *a);
extern Clo g_list_2emap_24s424270175x1918189508_clo;
V g_list_2emap_24s478220879x497030774(V);
V g_list_2emap_24s478220879x497030774_entry(V self, V *a);
extern Clo g_list_2emap_24s478220879x497030774_clo;
V g_list_2emap_24s499977176x606563528(V, V, V);
V g_list_2emap_24s499977176x606563528_entry(V self, V *a);
extern Clo g_list_2emap_24s499977176x606563528_clo;
V g_list_2emap_24s570961906x1112476114(V);
V g_list_2emap_24s570961906x1112476114_entry(V self, V *a);
extern Clo g_list_2emap_24s570961906x1112476114_clo;
V g_list_2emap_24s634984521x2042558081(V);
V g_list_2emap_24s634984521x2042558081_entry(V self, V *a);
extern Clo g_list_2emap_24s634984521x2042558081_clo;
V g_list_2emap_24s864521685x1610969087(V);
V g_list_2emap_24s864521685x1610969087_entry(V self, V *a);
extern Clo g_list_2emap_24s864521685x1610969087_clo;
V g_list_2emap_24s944722006x358970142(V);
V g_list_2emap_24s944722006x358970142_entry(V self, V *a);
extern Clo g_list_2emap_24s944722006x358970142_clo;
V g_list_2emap_24s979903333x2100209168(V);
V g_list_2emap_24s979903333x2100209168_entry(V self, V *a);
extern Clo g_list_2emap_24s979903333x2100209168_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_strEq_get(void);
Clo g_heff_2ebuild_2edriver_2eappendD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eappendD_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eappendD(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2ebuild_2edriver_2eappendD(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eappendD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eappendD(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2enubStrD_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2enubStrD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2enubStrD_entry, 1, 0};

V g_heff_2ebuild_2edriver_2enubStrD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2enubStrD_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2ebuild_2edriver_2enubStrD(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2enubStrD(a[0]);
}
V g_heff_2ebuild_2edriver_2enubStrD_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_strEq_c(v_y_243, v_x_241)) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
Clo g_heff_2ebuild_2edriver_2efindChecked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efindChecked_entry, 2, 0};

V g_heff_2ebuild_2edriver_2efindChecked(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_m_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_c_242, 0)), heff_dup(v_m_241))) {
      heff_drop(v_m_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_c_242)});
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_m_241;
      v_x1_240 = t_0;
      v_m_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2efindChecked_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2efindChecked(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2eclosureGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eclosureGo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eclosureGo(V v_done_240, V v_seen_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_seen_241;
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x3_242, 0);
    V v_ms_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_m_243)}));
    V v_t_246 = (g_list_2eany(v_t_245, v_seen_241));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_m_243);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_done_240;
      V t_1 = v_seen_241;
      V t_2 = v_ms_244;
      v_done_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_False: {
      V v_t_247 = (g_heff_2ebuild_2edriver_2efindChecked(v_done_240, heff_dup(v_m_243)));
      V v_t_249;
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        v_t_249 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_c_248 = heff_field(v_t_247, 0);
        heff_take_n(v_t_247, 1ULL, 1);
        v_t_249 = heff_get_n(v_c_248, 8, 13);
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      V v_t_2410 = (g_heff_2ebuild_2edriver_2eappendD(v_ms_244, v_t_249));
      V t_0 = v_done_240;
      V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_m_243, v_seen_241});
      V t_2 = v_t_2410;
      v_done_240 = t_0;
      v_seen_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2eclosureGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eclosureGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2ewithEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithEntry_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ewithEntry(V v_k_240, V v_c_241, V v_g_242) {
top: ;
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_240), heff_rfield(v_g_242, 1)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_g_244 = heff_get_n(heff_get_n(v_c_241, 5, 13), 0, 9);
    V v_t_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_240), heff_rfield(v_g_244, 1)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      V v_t_246 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_240), heff_rfield(v_g_244, 2)));
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        heff_drop(v_k_240);
        heff_drop_rec(v_g_244, 7);
        return v_g_242;
      }
      case TAG_Just: {
        V v_k2_247 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        V v_t_248 = ({ V a_0 = v_k2_247; V b_1 = heff_get_n(v_g_244, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
        switch (heff_tag_of(v_t_248)) {
        case TAG_Nothing: {
          heff_drop(v_k_240);
          return v_g_242;
        }
        case TAG_Just: {
          V v_e_249 = heff_field(v_t_248, 0);
          heff_take_n(v_t_248, 1ULL, 1);
          HEFF_LAST return g_heff_2eelab_2eglobals_2eaddEntry(v_k_240, v_e_249, v_g_242);
        }
        default: return heff_nomatch(v_t_248);
        }
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    case TAG_Just: {
      V v_e_2410 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      heff_drop_rec(v_g_244, 7);
      HEFF_LAST return g_heff_2eelab_2eglobals_2eaddEntry(v_k_240, v_e_2410, v_g_242);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_Just: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop(v_k_240);
    heff_drop_rec(v_c_241, 13);
    return v_g_242;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2edriver_2ewithEntry_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ewithEntry(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eenvOne_str0, 1, "#");
HEFF_LIT(g_heff_2ebuild_2edriver_2eenvOne_str1, 2, "#T");
V g_heff_2ebuild_2edriver_2eenvOne_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eenvOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eenvOne_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eenvOne(V v_c_240, V v_g_241) {
top: ;
  V v_t_242 = heff_strAppend(heff_dup(heff_rfield(v_c_240, 0)), ((V)&g_heff_2ebuild_2edriver_2eenvOne_str0));
  V v_t_243 = heff_strAppend(heff_dup(heff_rfield(v_c_240, 0)), ((V)&g_heff_2ebuild_2edriver_2eenvOne_str1));
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_245 = ({ V b_0 = heff_get_n(v_t_244, 3, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_246 = (g_list_2emap_24s1415906091x1371825187(v_t_245));
  V v_t_247 = ({ V a_0 = v_g_241; V a_1 = v_t_246; V r_ = (g_list_2efoldl_24s767745157x1794017821(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_t_2410 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edriver_2eenvOne_lam0, 2, 1, (V[]){heff_dup(v_c_240)}), v_t_247, heff_rfield(v_c_240, 7)));
  V v_t_2411 = (g_heff_2ebuild_2edriver_2ewithEntry(v_t_243, heff_dup(v_c_240), v_t_2410));
  return (g_heff_2ebuild_2edriver_2ewithEntry(v_t_242, v_c_240, v_t_2411));
}
V g_heff_2ebuild_2edriver_2eenvOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eenvOne(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2eenvOne_lam0(V self, V *args) {
  V v_g2_248 = args[0];
  V v_o_249 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2ewithEntry(heff_get_n(v_o_249, 1, 2), v_c_240, v_g2_248));
}
Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecatMaybesD_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ecatMaybesD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2ebuild_2edriver_2ecatMaybesD(v_xs_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ecatMaybesD(a[0]);
}
Clo g_heff_2ebuild_2edriver_2eanyD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eanyD_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eanyD(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2eanyD_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eanyD(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2egivesWay_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2egivesWay_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2egivesWay_entry, 3, 0};

V g_heff_2ebuild_2edriver_2egivesWay(V v_unwritten_240, V v_imported_241, V v_o_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_o_242, 2))}));
  V v_t_244 = (g_list_2eany(v_t_243, v_unwritten_240));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    return (g_heff_2ebuild_2edriver_2eanyD(heff_clo_n(g_heff_2ebuild_2edriver_2egivesWay_lam0, 1, 2, (V[]){v_o_242, heff_dup(v_unwritten_240)}), v_imported_241));
  }
  case TAG_False: {
    heff_drop_rec(v_o_242, 3);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ebuild_2edriver_2egivesWay_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2egivesWay(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2egivesWay_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_unwritten_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_p_245, 0)), heff_get_n(v_o_242, 0, 3))) {
    V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_p_245, 2, 3)}));
    V v_x1_248 = ({ V a_0 = v_t_247; V a_1 = v_unwritten_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_unwritten_240); r_; });
    switch (heff_tag_of(v_x1_248)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_248);
    }
  } else {
    heff_drop_rec(v_p_245, 3);
    heff_drop(v_unwritten_240);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edriver_2econcatMapD_24s1236007820x849009822_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2econcatMapD_24s1236007820x849009822_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2econcatMapD_24s1236007820x849009822_entry, 1, 0};

V g_heff_2ebuild_2edriver_2econcatMapD_24s1236007820x849009822(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2econcatMapD_24s1236007820x849009822_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), heff_dup(heff_rfield(v_x_241, 7))));
    V v_t_245 = (g_heff_2ebuild_2edriver_2econcatMapD_24s1236007820x849009822(v_xs_242));
    return (g_heff_2ebuild_2edriver_2eappendD(v_t_244, v_t_245));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2edriver_2econcatMapD_24s1236007820x849009822_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2econcatMapD_24s1236007820x849009822(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2econcatMapD_24s1236007820x849009822_lam0(V self, V *args) {
  V v_a_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_rec_n(3, shape_name__key__module, (V[]){heff_dup(heff_rfield(v_a_243, 0)), heff_get_n(v_a_243, 1, 2), heff_get_n(v_x_241, 0, 13)});
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ebrokenIn_str0, 1, ".");
V g_heff_2ebuild_2edriver_2ebrokenIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ebrokenIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ebrokenIn_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ebrokenIn(V v_c_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_242 = ({ V b_0 = heff_get_n(v_t_241, 3, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_243 = (g_list_2emap_24s1415906091x1371825187(v_t_242));
  V v_t_2411 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2ebrokenIn_lam0, 1, 1, (V[]){v_c_240}), v_t_243));
  HEFF_LAST return g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2411);
}
V g_heff_2ebuild_2edriver_2ebrokenIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ebrokenIn(a[0]);
}
V g_heff_2ebuild_2edriver_2ebrokenIn_lam0(V self, V *args) {
  V v_k_244 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_prefix_245 = heff_strAppend(heff_dup(heff_rfield(v_c_240, 0)), ((V)&g_heff_2ebuild_2edriver_2ebrokenIn_str0));
  V v_t_246 = heff_strSlice(heff_dup(v_k_244), MK_INT(0LL), heff_strLength(heff_dup(v_prefix_245)));
  if (heff_strEq_c(v_t_246, v_prefix_245)) {
    V v_t_248 = heff_strLength(heff_dup(heff_rfield(v_c_240, 0)));
    V v_t_249 = heff_strSlice(heff_dup(v_k_244), heff_intAdd(v_t_248, MK_INT(1LL)), heff_strLength(heff_dup(v_k_244)));
    V v_t_2410 = heff_rec_n(3, shape_name__key__module, (V[]){v_t_249, v_k_244, heff_get_n(v_c_240, 0, 13)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
  } else {
    heff_drop(v_k_244);
    heff_drop_rec(v_c_240, 13);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2edriver_2enubByName_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2enubByName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2enubByName_entry, 1, 0};

V g_heff_2ebuild_2edriver_2enubByName(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2enubByName_lam0, 1, 1, (V[]){heff_dup(v_o_241)}), v_rest_242));
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_o_241, (g_heff_2ebuild_2edriver_2enubByName(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2enubByName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2enubByName(a[0]);
}
V g_heff_2ebuild_2edriver_2enubByName_lam0(V self, V *args) {
  V v_p_243 = args[0];
  V v_o_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_strEq_c(heff_get_n(v_p_243, 0, 3), heff_get_n(v_o_241, 0, 3))) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
Clo g_heff_2ebuild_2edriver_2eclashMap_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eclashMap_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eclashMap(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_m_240;
  }
  case TAG_Cons: {
    V v_o_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_it_244 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_o_242, 0)), v_m_240));
    V v_t_2411;
    switch (heff_tag_of(v_it_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_o_242, 1)), NTAG(TAG_False)});
      v_t_2411 = (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_o_242, 0, 3), v_t_245, v_m_240));
      break;
    }
    case TAG_Just: {
      V v_it1_246 = heff_field(v_it_244, 0);
      heff_take_n(v_it_244, 1ULL, 1);
      switch (heff_tag_of(v_it1_246)) {
      case TAG_MkPair: {
        V v_k_247 = heff_field(v_it1_246, 0);
        V v_c_248 = heff_field(v_it1_246, 1);
        heff_take_n(v_it1_246, 3ULL, 2);
        switch (heff_tag_of(v_c_248)) {
        case TAG_True: {
          heff_drop_rec(v_o_242, 3);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_k_247);
          v_t_2411 = v_m_240;
          break;
        }
        case TAG_False: {
          if (heff_strEq_c(heff_dup(v_k_247), heff_dup(heff_rfield(v_o_242, 1)))) {
            heff_drop_rec(v_o_242, 3);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_k_247);
            v_t_2411 = v_m_240;
          } else {
            V v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_k_247, NTAG(TAG_True)});
            v_t_2411 = (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_o_242, 0, 3), v_t_2410, v_m_240));
          }
          break;
        }
        default: heff_nomatch(v_c_248);
        }
        break;
      }
      default: heff_nomatch(v_it1_246);
      }
      break;
    }
    default: heff_nomatch(v_it_244);
    }
    V t_0 = v_t_2411;
    V t_1 = v_rest_243;
    v_m_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2eclashMap_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eclashMap(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2espanOfName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2espanOfName_entry, 2, 0};

V g_heff_2ebuild_2edriver_2espanOfName(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x11_242, 0);
      V v_sp_245 = heff_field(v_x11_242, 1);
      if (heff_strEq_c(heff_dup(v_x_241), heff_dup(v_y_244))) {
        heff_drop(v_x_241);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_sp_245)});
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2espanOfName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2espanOfName(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eplaceAt_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eplaceAt_str1, 3, "by ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eplaceAt_str2, 5, ", at ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eplaceAt_str3, 1, ":");
Clo g_heff_2ebuild_2edriver_2eplaceAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eplaceAt_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eplaceAt(V v_c_240, V v_sp_241) {
top: ;
  V v_src_242 = heff_take_field(v_c_240, 3);
  V v_t_243 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2edriver_2eplaceAt_str0), heff_dup(v_src_242), MK_INT(0LL)));
  V v_t_244 = (g_heff_2elsp_2erender_2elineColAt(v_src_242, heff_get_n(v_sp_241, 0, 2), MK_INT(0LL), MK_INT(0LL), v_t_243));
  V v_t_245 = heff_intAdd(heff_get_n(v_t_244, 0, 3), MK_INT(1LL));
  return heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eplaceAt_str1), heff_strAppend(heff_dup(heff_rfield(v_c_240, 0)), heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eplaceAt_str2), heff_strAppend(heff_get_n(v_c_240, 2, 13), heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eplaceAt_str3), heff_intShow(v_t_245))))));
}
V g_heff_2ebuild_2edriver_2eplaceAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eplaceAt(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ewithPlace_str0, 3, "by ");
Clo g_heff_2ebuild_2edriver_2ewithPlace_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithPlace_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ewithPlace(V v_done_240, V v_o_241, V v_g_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2edriver_2efindChecked(v_done_240, heff_take_field(v_o_241, 2)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_241, 3);
    return v_g_242;
  }
  case TAG_Just: {
    V v_c_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_c_244, 5)), 6, 9);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_c_244, 5)), 3, 9);
    V v_t_247 = (g_heff_2ebuild_2edriver_2eappendD(v_t_245, v_t_246));
    V v_t_248 = ({ V a_0 = v_t_247; V a_1 = heff_take_field(v_o_241, 0); V r_ = (g_heff_2ebuild_2edriver_2espanOfName(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_place_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      v_place_2410 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2ewithPlace_str0), heff_get_n(v_c_244, 0, 13));
      break;
    }
    case TAG_Just: {
      V v_sp_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      v_place_2410 = (g_heff_2ebuild_2edriver_2eplaceAt(v_c_244, v_sp_249));
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2411 = (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_o_241, 1, 3), v_place_2410, heff_take_field(v_g_242, 5)));
    return ({ V rv_5 = v_t_2411; V rr_ = heff_rec_reuse_n(v_g_242, 95ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances); heff_rfield(rr_, 5) = rv_5; rr_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2edriver_2ewithPlace_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2ewithPlace(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2ealiasOpen_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ealiasOpen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ealiasOpen_entry, 4, 0};

V g_heff_2ebuild_2edriver_2ealiasOpen(V v_done_240, V v_clashes_241, V v_g_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    return v_g_242;
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_247 = (g_heff_2ebuild_2edriver_2eanyD(heff_clo_n(g_heff_2ebuild_2edriver_2ealiasOpen_lam0, 1, 1, (V[]){heff_dup(v_o_244)}), v_clashes_241));
    V v_t_2412;
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      V v_t_248 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_o_244, 1)), NTAG(TAG_Nil)});
      V v_t_249 = (g_heff_2eelab_2eglobals_2eaddAmbiguous(heff_dup(heff_rfield(v_o_244, 0)), v_t_248, v_g_242));
      v_t_2412 = (g_heff_2ebuild_2edriver_2ewithPlace(v_done_240, v_o_244, v_t_249));
      break;
    }
    case TAG_False: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      if (heff_strEq_c(heff_dup(heff_rfield(v_o_244, 1)), heff_dup(heff_rfield(v_o_244, 0)))) {
        heff_drop_rec(v_o_244, 3);
        v_t_2412 = v_g_242;
      } else {
        V v_t_2411 = (g_map_2einsert_24s1341440536x470972936(heff_take_field(v_o_244, 0), heff_get_n(v_o_244, 1, 3), heff_take_field(v_g_242, 2)));
        v_t_2412 = ({ V rv_2 = v_t_2411; V rr_ = heff_rec_reuse_n(v_g_242, 123ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances); heff_rfield(rr_, 2) = rv_2; rr_; });
      }
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V t_0 = v_done_240;
    V t_1 = v_clashes_241;
    V t_2 = v_t_2412;
    V t_3 = v_rest_245;
    v_done_240 = t_0;
    v_clashes_241 = t_1;
    v_g_242 = t_2;
    v_x4_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2edriver_2ealiasOpen_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2ealiasOpen(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2ealiasOpen_lam0(V self, V *args) {
  V v_cl_246 = args[0];
  V v_o_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_cl_246, 0, 3), heff_get_n(v_o_244, 0, 3));
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ealiasModule_str0, 1, "#");
Clo g_heff_2ebuild_2edriver_2ealiasModule_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ealiasModule_entry, 2, 0};

V g_heff_2ebuild_2edriver_2ealiasModule(V v_g_240, V v_q_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2eglobals_2elookupName(heff_dup(v_g_240), heff_dup(heff_rfield(v_q_241, 1))));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_243 = heff_strAppend(heff_take_field(v_q_241, 0), ((V)&g_heff_2ebuild_2edriver_2ealiasModule_str0));
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_q_241, 1, 2), v_t_243, heff_take_field(v_g_240, 2)));
    return ({ V rv_2 = v_t_244; V rr_ = heff_rec_reuse_n(v_g_240, 123ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances); heff_rfield(rr_, 2) = rv_2; rr_; });
  }
  case TAG_Just: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop_rec(v_q_241, 2);
    return v_g_240;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ebuild_2edriver_2ealiasModule_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ealiasModule(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ealiasQOne_str0, 1, ".");
V g_heff_2ebuild_2edriver_2ealiasQOne_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2ealiasQOne_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ealiasQOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ealiasQOne_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ealiasQOne(V v_done_240, V v_g_241, V v_q_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2edriver_2efindChecked(v_done_240, heff_dup(heff_rfield(v_q_242, 0))));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_q_242, 2);
    return v_g_241;
  }
  case TAG_Just: {
    V v_c_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    V v_t_245 = (g_heff_2ebuild_2edriver_2ealiasModule(v_g_241, heff_dup(v_q_242)));
    V v_t_247 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2ealiasQOne_lam0, 1, 1, (V[]){heff_dup(v_c_244)}), heff_dup(heff_rfield(v_c_244, 7))));
    V v_t_248 = (g_heff_2ebuild_2edriver_2ebrokenIn(v_c_244));
    V v_t_249 = (g_heff_2ebuild_2edriver_2eappendD(v_t_247, v_t_248));
    return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ealiasQOne_lam1, 2, 1, (V[]){v_q_242}); V a_1 = v_t_245; V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2edriver_2ealiasQOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2ealiasQOne(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2ealiasQOne_lam0(V self, V *args) {
  V v_o_246 = args[0];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_rec_n(3, shape_name__key__module, (V[]){heff_dup(heff_rfield(v_o_246, 0)), heff_get_n(v_o_246, 1, 2), heff_get_n(v_c_244, 0, 13)});
}
V g_heff_2ebuild_2edriver_2ealiasQOne_lam1(V self, V *args) {
  V v_g2_2410 = args[0];
  V v_o_2411 = args[1];
  V v_q_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_strAppend(heff_get_n(v_q_242, 1, 2), heff_strAppend(((V)&g_heff_2ebuild_2edriver_2ealiasQOne_str0), heff_dup(heff_rfield(v_o_2411, 0))));
  V v_t_2413 = (g_map_2einsert_24s1341440536x470972936(v_t_2412, heff_get_n(v_o_2411, 1, 3), heff_take_field(v_g2_2410, 2)));
  return ({ V rv_2 = v_t_2413; V rr_ = heff_rec_reuse_n(v_g2_2410, 123ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances); heff_rfield(rr_, 2) = rv_2; rr_; });
}
Clo g_heff_2ebuild_2edriver_2ealiasQualified_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ealiasQualified_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ealiasQualified(V v_done_240, V v_g_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_g_241;
  }
  case TAG_Cons: {
    V v_q_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2edriver_2ealiasQOne(v_done_240, v_g_241, heff_dup(v_q_243)));
    V t_0 = v_done_240;
    V t_1 = v_t_245;
    V t_2 = v_rest_244;
    v_done_240 = t_0;
    v_g_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2ealiasQualified_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2ealiasQualified(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam3(V self, V *args);
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam2(V self, V *args);
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ewithImportedInstances_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithImportedInstances_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ewithImportedInstances(V v_done_240, V v_modules_241, V v_g_242) {
top: ;
  HEFF_LAST return g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2edriver_2ewithImportedInstances_lam0, 2, 1, (V[]){heff_dup(v_done_240)}), v_g_242, v_modules_241);
}
V g_heff_2ebuild_2edriver_2ewithImportedInstances_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2ewithImportedInstances(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam1(V self, V *args) {
  V v_i_249 = args[0];
  V v_c_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_i_249, 1, 2), heff_get_n(v_c_246, 0, 13));
}
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam3(V self, V *args) {
  V v_i_2415 = args[0];
  V v_k_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_strEq_c(heff_get_n(v_i_2415, 0, 2), v_k_2413)) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam2(V self, V *args) {
  V v_g3_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_rec_n(2, shape_key__module, (V[]){heff_dup(v_k_2413), heff_get_n(v_c_246, 0, 13)});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2ewithImportedInstances_lam3, 1, 1, (V[]){v_k_2413}), heff_dup(heff_rfield(v_g3_2412, 6))))});
  return ({ V rv_6 = v_t_2417; V rr_ = heff_rec_reuse_n(v_g3_2412, 63ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances); heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2ebuild_2edriver_2ewithImportedInstances_lam0(V self, V *args) {
  V v_g2_243 = args[0];
  V v_m_244 = args[1];
  V v_done_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = ({ V a_0 = v_done_240; V a_1 = v_m_244; V r_ = (g_heff_2ebuild_2edriver_2efindChecked(a_0, a_1)); heff_drop(v_done_240); r_; });
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    return v_g2_243;
  }
  case TAG_Just: {
    V v_c_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_c_246, 5)), 0, 9);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_247, 6, 7)));
    V v_t_2410 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2ewithImportedInstances_lam1, 1, 1, (V[]){heff_dup(v_c_246)}), v_t_248));
    V v_t_2411 = (g_list_2emap_24s979903333x2100209168(v_t_2410));
    return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ewithImportedInstances_lam2, 2, 1, (V[]){v_c_246}); V a_1 = v_g2_243; V a_2 = v_t_2411; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
  }
  default: return heff_nomatch(v_t_245);
  }
}
Clo g_heff_2ebuild_2edriver_2ewithParseBroken_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithParseBroken_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ewithParseBroken(V v_key_240, V v_g_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_key_240);
    return v_g_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_k_245 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(v_x_243)}));
    V v_t_246 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(v_x_243)}));
    V v_g_247 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(v_x_243), v_t_246, v_g_241));
    V v_t_248 = (g_map_2einsert_24s1341440536x470972936(v_k_245, NTAG(TAG_MkUnit), heff_take_field(v_g_247, 3)));
    V v_t_249 = ({ V rv_3 = v_t_248; V rr_ = heff_rec_reuse_n(v_g_247, 119ULL, 7, shape_order__entries__aliases__broken__ambiguous__places__instances); heff_rfield(rr_, 3) = rv_3; rr_; });
    V t_0 = v_key_240;
    V t_1 = v_t_249;
    V t_2 = v_rest_244;
    v_key_240 = t_0;
    v_g_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2ewithParseBroken_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2ewithParseBroken(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eownOf_str0, 1, ".");
V g_heff_2ebuild_2edriver_2eownOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eownOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eownOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eownOf(V v_modName_240, V v_keys_241) {
top: ;
  HEFF_LAST return g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2eownOf_lam0, 1, 1, (V[]){v_modName_240}), v_keys_241);
}
V g_heff_2ebuild_2edriver_2eownOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eownOf(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2eownOf_lam0(V self, V *args) {
  V v_k_242 = args[0];
  V v_modName_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_prefix_243 = heff_strAppend(heff_dup(v_modName_240), ((V)&g_heff_2ebuild_2edriver_2eownOf_str0));
  V v_t_244 = heff_strSlice(heff_dup(v_k_242), MK_INT(0LL), heff_strLength(heff_dup(v_prefix_243)));
  if (heff_strEq_c(v_t_244, v_prefix_243)) {
    V v_t_246 = heff_intAdd(heff_strLength(v_modName_240), MK_INT(1LL));
    V v_t_247 = heff_strSlice(heff_dup(v_k_242), v_t_246, heff_strLength(heff_dup(v_k_242)));
    return heff_rec_n(2, shape_name__key, (V[]){v_t_247, v_k_242});
  } else {
    heff_drop(v_modName_240);
    return heff_rec_n(2, shape_name__key, (V[]){heff_dup(v_k_242), v_k_242});
  }
}
Clo g_heff_2ebuild_2edriver_2eopenNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eopenNames_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eopenNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = heff_take_field(v_i_241, 1);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_i_241, 0, 3), (g_heff_2ebuild_2edriver_2eopenNames(v_rest_242))});
    }
    case TAG_Just: {
      heff_take_n(v_t_243, 0ULL, 1);
      heff_drop_rec(v_i_241, 3);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eopenNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eopenNames(a[0]);
}
Clo g_heff_2ebuild_2edriver_2ealiasPairs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ealiasPairs_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ealiasPairs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_i_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = heff_take_field(v_i_241, 1);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      heff_drop_rec(v_i_241, 3);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_a_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      V v_t_245 = heff_rec_n(2, shape_module__alias, (V[]){heff_get_n(v_i_241, 0, 3), v_a_244});
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_heff_2ebuild_2edriver_2ealiasPairs(v_rest_242))});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2ealiasPairs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ealiasPairs(a[0]);
}
Clo g_heff_2ebuild_2edriver_2estructEntryOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2estructEntryOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2estructEntryOf(V v_g_240, V v_o_241) {
top: ;
  V v_k_242 = heff_dup(heff_rfield(v_o_241, 1));
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_242), heff_rfield(v_g_240, 1)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(v_k_242, heff_rfield(v_g_240, 2)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_g_240, 7);
      heff_drop_rec(v_o_241, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_k2_245 = heff_field(v_t_244, 0);
      V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
      V v_t_246 = ({ V a_0 = v_k2_245; V b_1 = heff_get_n(v_g_240, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        heff_drop_rec(v_o_241, 2);
        heff_drop_cell(v_ru_24t_244_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_e_247 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        V v_t_248 = (g_heff_2eelab_2evalue_2elevelOf(heff_rfield(v_e_247, 3)));
        V v_t_249 = heff_rec_n(4, shape_name__key__ty__level, (V[]){heff_take_field(v_o_241, 0), heff_get_n(v_o_241, 1, 2), heff_get_n(v_e_247, 1, 4), v_t_248});
        return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){v_t_249});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_e_2410 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_g_240, 7);
    heff_drop(v_k_242);
    V v_t_2411 = (g_heff_2eelab_2evalue_2elevelOf(heff_rfield(v_e_2410, 3)));
    V v_t_2412 = heff_rec_n(4, shape_name__key__ty__level, (V[]){heff_take_field(v_o_241, 0), heff_get_n(v_o_241, 1, 2), heff_get_n(v_e_2410, 1, 4), v_t_2411});
    return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){v_t_2412});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2edriver_2estructEntryOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2estructEntryOf(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2estructIdxGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2estructIdxGo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2estructIdxGo(V v_i_240, V v_x2_241, V v_m_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return v_m_242;
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_r_243, 1)), heff_dup(v_i_240), v_m_242));
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_rest_244;
    V t_2 = v_t_245;
    v_i_240 = t_0;
    v_x2_241 = t_1;
    v_m_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2estructIdxGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2estructIdxGo(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2edriver_2ecloseFieldsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseFieldsGo_entry, 5, 0};

V g_heff_2ebuild_2edriver_2ecloseFieldsGo(V v_r_240, V v_i_241, V v_depth_242, V v_j_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_241);
    heff_drop(v_depth_242);
    heff_drop(v_j_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x51_245, 0);
      V v_t_248 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 3ULL, 2);
      V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 3, (V[]){heff_dup(v_i_241), heff_intAdd(heff_dup(v_depth_242), heff_dup(v_j_243)), v_t_248}));
      return heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_t_249}), (g_heff_2ebuild_2edriver_2ecloseFieldsGo(v_r_240, v_i_241, v_depth_242, heff_intAdd(v_j_243, MK_INT(1LL)), v_rest_246))});
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2edriver_2ecloseFieldsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ecloseFieldsGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2ecloseTypeF_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ecloseTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTypeF_entry, 5, 0};

V g_heff_2ebuild_2edriver_2ecloseTypeF(V v_r_240, V v_idx_241, V v_i_242, V v_depth_243, V v_t_244) {
top: ;
  switch (heff_tag_of(v_t_244)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SDecode: {
    V v_e_246 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SDecode = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_e_246}));
    return heff_tag_at_n(v_ru_24t_244_24SDecode, TAG_SDecode, 1, (V[]){v_t_247});
  }
  case TAG_SFunction: {
    V v_level_248 = heff_field(v_t_244, 0);
    V v_dom_249 = heff_field(v_t_244, 1);
    V v_cod_2410 = heff_field(v_t_244, 2);
    V v_implicit_2411 = heff_field(v_t_244, 3);
    V v_dflt_2412 = heff_field(v_t_244, 4);
    V v_ru_24t_244_24SFunction = heff_take_reuse_n(v_t_244, 31ULL, 5);
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_dom_249}));
    V v_t_2419;
    switch (heff_tag_of(v_cod_2410)) {
    case TAG_MkAbs: {
      V v_x_2414 = heff_field(v_cod_2410, 0);
      V v_t_2415 = heff_field(v_cod_2410, 1);
      V v_ru_24cod_2410_24MkAbs = heff_take_reuse_n(v_cod_2410, 3ULL, 2);
      V v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, heff_intAdd(v_depth_243, MK_INT(1LL)), v_t_2415}));
      v_t_2419 = heff_tag_at_n(v_ru_24cod_2410_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2414, v_t_2416});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2417 = heff_field(v_cod_2410, 0);
      V v_ru_24cod_2410_24AbsConst = heff_take_reuse_n(v_cod_2410, 1ULL, 1);
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, v_depth_243, v_t_2417}));
      v_t_2419 = heff_tag_at_n(v_ru_24cod_2410_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2418});
      break;
    }
    default: heff_nomatch(v_cod_2410);
    }
    return heff_tag_at_n(v_ru_24t_244_24SFunction, TAG_SFunction, 5, (V[]){v_level_248, v_t_2413, v_t_2419, v_implicit_2411, v_dflt_2412});
  }
  case TAG_SRecord: {
    V v_level_2420 = heff_field(v_t_244, 0);
    V v_fs_2421 = heff_field(v_t_244, 1);
    V v_ds_2422 = heff_field(v_t_244, 2);
    V v_ru_24t_244_24SRecord = heff_take_reuse_n(v_t_244, 7ULL, 3);
    V v_t_2423 = heff_arrayToList(heff_take_field(v_fs_2421, 0));
    V v_t_2424 = heff_arrayToList(heff_get_n(v_fs_2421, 2, 3));
    V v_t_2425 = (g_heff_2eutil_2edict_2ezipKV(v_t_2423, v_t_2424));
    V v_pairs_2426 = (g_heff_2ebuild_2edriver_2ecloseFieldsGo(v_r_240, v_i_242, v_depth_243, MK_INT(0LL), v_t_2425));
    V v_t_2427 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_2426)));
    V v_t_2428 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2426));
    V v_t_2429 = (g_list_2emap_24s1173914895x100384474(v_pairs_2426));
    V v_t_2430 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2427), v_t_2428, heff_arrayFromList(v_t_2429)});
    return heff_tag_at_n(v_ru_24t_244_24SRecord, TAG_SRecord, 3, (V[]){v_level_2420, v_t_2430, v_ds_2422});
  }
  case TAG_SSum: {
    V v_vs_2431 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SSum = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_xs_2432 = heff_take_field(v_vs_2431, 2);
    V v_t_2437 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2432)), heff_clo_n(g_heff_2ebuild_2edriver_2ecloseTypeF_lam0, 1, 4, (V[]){v_xs_2432, v_r_240, v_i_242, v_depth_243}));
    V v_t_2438 = ({ V rv_2 = v_t_2437; V rr_ = heff_rec_reuse_n(v_vs_2431, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_244_24SSum, TAG_SSum, 1, (V[]){v_t_2438});
  }
  case TAG_SIsTy: {
    V v_t2_2439 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SIsTy = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, v_depth_243, v_t2_2439}));
    return heff_tag_at_n(v_ru_24t_244_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2440});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  case TAG_SPrimArray: {
    V v_t2_2441 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24SPrimArray = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_2442 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, v_depth_243, v_t2_2441}));
    return heff_tag_at_n(v_ru_24t_244_24SPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2442});
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_t_244;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2ecloseTypeF(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_lam1(V self, V *args) {
  V v_i_2435 = args[0];
  V v_xs_2434 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_i_242 = heff_env(self)[2];
  V v_depth_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t2_2436 = heff_arrayIndex(v_xs_2434, v_i_2435);
  V f_ = heff_get_n(v_r_240, 0, 2);
  heff_room[0] = v_i_242;
  heff_room[1] = v_depth_243;
  heff_room[2] = v_t2_2436;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edriver_2ecloseTypeF_lam0(V self, V *args) {
  V v_i_2433 = args[0];
  V v_xs_2432 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_i_242 = heff_env(self)[2];
  V v_depth_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_xs_2434 = heff_arrayIndex(v_xs_2432, v_i_2433);
  return heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2434)), heff_clo_n(g_heff_2ebuild_2edriver_2ecloseTypeF_lam1, 1, 4, (V[]){v_xs_2434, v_r_240, v_i_242, v_depth_243}));
}
V g_heff_2ebuild_2edriver_2ecloseTermF_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2ecloseTermF_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2ecloseTermF_lam2(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ecloseTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecloseTermF_entry, 5, 0};

V g_heff_2ebuild_2edriver_2ecloseTermF(V v_r_240, V v_idx_241, V v_i_242, V v_depth_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_SLocal: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SGlobal: {
    V v_k_246 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SGlobal = heff_take_reuse_n(v_e_244, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    V v_t_247 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_246), v_idx_241));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop(v_i_242);
      heff_drop(v_depth_243);
      return heff_tag_at_n(v_ru_24e_244_24SGlobal, TAG_SGlobal, 1, (V[]){v_k_246});
    }
    case TAG_Just: {
      V v_j_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      if (heff_intLt_c(heff_dup(v_j_248), heff_dup(v_i_242))) {
        heff_drop(v_k_246);
        V v_t_2410 = heff_intSub(heff_intSub(v_i_242, MK_INT(1LL)), v_j_248);
        return heff_tag_at_n(v_ru_24e_244_24SGlobal, TAG_SLocal, 1, (V[]){heff_intAdd(v_depth_243, v_t_2410)});
      } else {
        heff_drop(v_i_242);
        heff_drop(v_depth_243);
        heff_drop(v_j_248);
        return heff_tag_at_n(v_ru_24e_244_24SGlobal, TAG_SGlobal, 1, (V[]){v_k_246});
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_SCode: {
    V v_t_2411 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SCode = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, v_depth_243, v_t_2411}));
    return heff_tag_at_n(v_ru_24e_244_24SCode, TAG_SCode, 1, (V[]){v_t_2412});
  }
  case TAG_SApp: {
    V v_f_2413 = heff_field(v_e_244, 0);
    V v_a2_2414 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SApp = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_f_2413}));
    V v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_a2_2414}));
    return heff_tag_at_n(v_ru_24e_244_24SApp, TAG_SApp, 2, (V[]){v_t_2415, v_t_2416});
  }
  case TAG_SLam: {
    V v_t_2417 = heff_field(v_e_244, 0);
    V v_b_2418 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SLam = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2419 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_t_2417}));
    V v_t_2425;
    switch (heff_tag_of(v_b_2418)) {
    case TAG_MkAbs: {
      V v_x_2420 = heff_field(v_b_2418, 0);
      V v_t_2421 = heff_field(v_b_2418, 1);
      heff_take_n(v_b_2418, 3ULL, 2);
      V v_t_2422 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, heff_intAdd(v_depth_243, MK_INT(1LL)), v_t_2421}));
      v_t_2425 = heff_tag_at_n(v_ru_24e_244_24SLam, TAG_MkAbs, 2, (V[]){v_x_2420, v_t_2422});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2423 = heff_field(v_b_2418, 0);
      V v_ru_24b_2418_24AbsConst = heff_take_reuse_n(v_b_2418, 1ULL, 1);
      heff_drop_cell(v_ru_24e_244_24SLam, 2);
      V v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_t_2423}));
      v_t_2425 = heff_tag_at_n(v_ru_24b_2418_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2424});
      break;
    }
    default: heff_nomatch(v_b_2418);
    }
    return heff_tag_n(TAG_SLam, 2, (V[]){v_t_2419, v_t_2425});
  }
  case TAG_SCons: {
    V v_d_2426 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SCons = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_xs_2427 = heff_take_field(v_d_2426, 2);
    V v_t_2430 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2427)), heff_clo_n(g_heff_2ebuild_2edriver_2ecloseTermF_lam0, 1, 4, (V[]){v_xs_2427, v_r_240, v_i_242, v_depth_243}));
    V v_t_2431 = ({ V rv_2 = v_t_2430; V rr_ = heff_rec_reuse_n(v_d_2426, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24e_244_24SCons, TAG_SCons, 1, (V[]){v_t_2431});
  }
  case TAG_SProj: {
    V v_e2_2432 = heff_field(v_e_244, 0);
    V v_l_2433 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SProj = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2434 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_e2_2432}));
    return heff_tag_at_n(v_ru_24e_244_24SProj, TAG_SProj, 2, (V[]){v_t_2434, v_l_2433});
  }
  case TAG_STag: {
    V v_t_2435 = heff_field(v_e_244, 0);
    V v_as_2436 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24STag = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2438 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2ecloseTermF_lam1, 1, 3, (V[]){v_r_240, v_i_242, v_depth_243}), heff_arrayToList(v_as_2436)));
    return heff_tag_at_n(v_ru_24e_244_24STag, TAG_STag, 2, (V[]){v_t_2435, heff_arrayFromList(v_t_2438)});
  }
  case TAG_SMatch: {
    V v_e2_2439 = heff_field(v_e_244, 0);
    V v_cs_2440 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SMatch = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2441 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_e2_2439}));
    V v_xs_2442 = heff_take_field(v_cs_2440, 2);
    V v_t_2449 = heff_arrayGenerate(heff_arrayLength(heff_dup(v_xs_2442)), heff_clo_n(g_heff_2ebuild_2edriver_2ecloseTermF_lam2, 1, 4, (V[]){v_xs_2442, v_r_240, v_i_242, v_depth_243}));
    V v_t_2450 = ({ V rv_2 = v_t_2449; V rr_ = heff_rec_reuse_n(v_cs_2440, 3ULL, 3, shape_keys__byName__values); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24e_244_24SMatch, TAG_SMatch, 2, (V[]){v_t_2441, v_t_2450});
  }
  case TAG_SSpecialize: {
    V v_e2_2451 = heff_field(v_e_244, 0);
    V v_l_2452 = heff_field(v_e_244, 1);
    V v_v_2453 = heff_field(v_e_244, 2);
    V v_ru_24e_244_24SSpecialize = heff_take_reuse_n(v_e_244, 7ULL, 3);
    V v_t_2454 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_e2_2451}));
    V v_t_2455 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_v_2453}));
    return heff_tag_at_n(v_ru_24e_244_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2454, v_l_2452, v_t_2455});
  }
  case TAG_SIs: {
    V v_e2_2456 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SIs = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_t_2457 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_e2_2456}));
    return heff_tag_at_n(v_ru_24e_244_24SIs, TAG_SIs, 1, (V[]){v_t_2457});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SRec: {
    V v_e2_2458 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24SRec = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_t_2459 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_e2_2458}));
    return heff_tag_at_n(v_ru_24e_244_24SRec, TAG_SRec, 1, (V[]){v_t_2459});
  }
  case TAG_SFix: {
    V v_t_2460 = heff_field(v_e_244, 0);
    V v_b_2461 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SFix = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2462 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 3, (V[]){heff_dup(v_i_242), heff_dup(v_depth_243), v_t_2460}));
    V v_t_2468;
    switch (heff_tag_of(v_b_2461)) {
    case TAG_MkAbs: {
      V v_x_2463 = heff_field(v_b_2461, 0);
      V v_t_2464 = heff_field(v_b_2461, 1);
      heff_take_n(v_b_2461, 3ULL, 2);
      V v_t_2465 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, heff_intAdd(v_depth_243, MK_INT(1LL)), v_t_2464}));
      v_t_2468 = heff_tag_at_n(v_ru_24e_244_24SFix, TAG_MkAbs, 2, (V[]){v_x_2463, v_t_2465});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2466 = heff_field(v_b_2461, 0);
      V v_ru_24b_2461_24AbsConst = heff_take_reuse_n(v_b_2461, 1ULL, 1);
      heff_drop_cell(v_ru_24e_244_24SFix, 2);
      V v_t_2467 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_t_2466}));
      v_t_2468 = heff_tag_at_n(v_ru_24b_2461_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2467});
      break;
    }
    default: heff_nomatch(v_b_2461);
    }
    return heff_tag_n(TAG_SFix, 2, (V[]){v_t_2462, v_t_2468});
  }
  case TAG_SImplicit: {
    V v_x_2469 = heff_field(v_e_244, 0);
    V v_e2_2470 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24SImplicit = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2471 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, v_depth_243, v_e2_2470}));
    return heff_tag_at_n(v_ru_24e_244_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2469, v_t_2471});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SMetaApp: {
    V v_m_2473 = heff_field(v_e_244, 0);
    V v_xs_2474 = heff_field(v_e_244, 1);
    V v_t_2475 = heff_field(v_e_244, 2);
    V v_ru_24e_244_24SMetaApp = heff_take_reuse_n(v_e_244, 7ULL, 3);
    V v_t_2476 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 3, (V[]){v_i_242, v_depth_243, v_t_2475}));
    return heff_tag_at_n(v_ru_24e_244_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2473, v_xs_2474, v_t_2476});
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_242);
    heff_drop(v_depth_243);
    return v_e_244;
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2ebuild_2edriver_2ecloseTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2ecloseTermF(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2ecloseTermF_lam0(V self, V *args) {
  V v_i_2428 = args[0];
  V v_xs_2427 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_i_242 = heff_env(self)[2];
  V v_depth_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_e2_2429 = heff_arrayIndex(v_xs_2427, v_i_2428);
  V f_ = heff_get_n(v_r_240, 1, 2);
  heff_room[0] = v_i_242;
  heff_room[1] = v_depth_243;
  heff_room[2] = v_e2_2429;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edriver_2ecloseTermF_lam1(V self, V *args) {
  V v_e2_2437 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_i_242 = heff_env(self)[1];
  V v_depth_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_get_n(v_r_240, 1, 2);
  heff_room[0] = v_i_242;
  heff_room[1] = v_depth_243;
  heff_room[2] = v_e2_2437;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2edriver_2ecloseTermF_lam2(V self, V *args) {
  V v_i_2443 = args[0];
  V v_xs_2442 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_i_242 = heff_env(self)[2];
  V v_depth_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_p_2444 = heff_arrayIndex(v_xs_2442, v_i_2443);
  switch (heff_tag_of(v_p_2444)) {
  case TAG_MkPair: {
    V v_xs_2445 = heff_field(v_p_2444, 0);
    V v_b_2446 = heff_field(v_p_2444, 1);
    V v_ru_24p_2444_24MkPair = heff_take_reuse_n(v_p_2444, 3ULL, 2);
    V v_t_2447 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_xs_2445)); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2448 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 3, (V[]){v_i_242, heff_intAdd(v_depth_243, v_t_2447), v_b_2446}));
    return heff_tag_at_n(v_ru_24p_2444_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2445, v_t_2448});
  }
  default: return heff_nomatch(v_p_2444);
  }
}
V g_heff_2ebuild_2edriver_2eckOf_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2eckOf_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eckOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eckOf_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eckOf(V v_idx_240) {
top: ;
  return heff_rec_n(2, shape_ty__el, (V[]){heff_clo_n(g_heff_2ebuild_2edriver_2eckOf_lam0, 3, 1, (V[]){heff_dup(v_idx_240)}), heff_clo_n(g_heff_2ebuild_2edriver_2eckOf_lam1, 3, 1, (V[]){heff_dup(v_idx_240)})});
}
V g_heff_2ebuild_2edriver_2eckOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eckOf(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2eckOf_lam0(V self, V *args) {
  V v_i_241 = args[0];
  V v_depth_242 = args[1];
  V v_t_243 = args[2];
  V v_idx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2ebuild_2edriver_2eckOf(v_idx_240));
  return ({ V a_0 = v_t_244; V a_1 = v_idx_240; V a_2 = v_i_241; V a_3 = v_depth_242; V a_4 = v_t_243; V r_ = (g_heff_2ebuild_2edriver_2ecloseTypeF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_idx_240); r_; });
}
V g_heff_2ebuild_2edriver_2eckOf_lam1(V self, V *args) {
  V v_i_245 = args[0];
  V v_depth_246 = args[1];
  V v_e_247 = args[2];
  V v_idx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2ebuild_2edriver_2eckOf(v_idx_240));
  return ({ V a_0 = v_t_248; V a_1 = v_idx_240; V a_2 = v_i_245; V a_3 = v_depth_246; V a_4 = v_e_247; V r_ = (g_heff_2ebuild_2edriver_2ecloseTermF(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_idx_240); r_; });
}
Clo g_heff_2ebuild_2edriver_2estructFieldsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2estructFieldsGo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2estructFieldsGo(V v_idx_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ebuild_2edriver_2eckOf(v_idx_240));
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_t_245, 0, 2), 3, (V[]){heff_dup(v_i_241), MK_INT(0LL), heff_take_field(v_r_243, 2)}));
    V v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_r_243, 0, 4), v_t_246});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, (g_heff_2ebuild_2edriver_2estructFieldsGo(v_idx_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_rest_244))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2estructFieldsGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2estructFieldsGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2estructBody_str0, 1, "#");
HEFF_LIT(g_heff_2ebuild_2edriver_2estructBody_str1, 2, "#T");
Clo g_heff_2ebuild_2edriver_2estructBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2estructBody_entry, 3, 0};

V g_heff_2ebuild_2edriver_2estructBody(V v_mkey_240, V v_es_241, V v_g_27_242) {
top: ;
  V v_k_243 = heff_strAppend(heff_dup(v_mkey_240), ((V)&g_heff_2ebuild_2edriver_2estructBody_str0));
  V v_t_244 = heff_tag_n(TAG_SGlobal, 1, (V[]){heff_strAppend(v_mkey_240, ((V)&g_heff_2ebuild_2edriver_2estructBody_str1))});
  V v_tyStx_245 = heff_tag_n(TAG_SDecode, 1, (V[]){v_t_244});
  V v_pairs_246 = (g_list_2emap_24s478220879x497030774(v_es_241));
  V v_t_247 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_246)));
  V v_t_248 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_246));
  V v_t_249 = (g_list_2emap_24s1173914895x100384474(v_pairs_246));
  V v_t_2410 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_247), v_t_248, heff_arrayFromList(v_t_249)});
  V v_bodyStx_2411 = heff_tag_n(TAG_SCons, 1, (V[]){v_t_2410});
  V v_t_2412 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_27_242), heff_dup(v_k_243), heff_dup(v_tyStx_245), heff_dup(v_bodyStx_2411)));
  V v_x1_2413 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(heff_dup(v_g_27_242), NTAG(TAG_N), heff_dup(v_tyStx_245), NTAG(TAG_LNil)));
  V v_t_2417;
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_Nom: {
    V v_x_2414 = heff_field(v_x1_2413, 0);
    heff_take_n(v_x1_2413, 1ULL, 1);
    v_t_2417 = v_x_2414;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2413, 0ULL, 1);
    v_t_2417 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2416 = heff_field(v_x1_2413, 0);
    heff_take_n(v_x1_2413, 1ULL, 1);
    v_t_2417 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_x1_2413);
  }
  HEFF_LAST return g_heff_2eelab_2eglobals_2eaddEntry(v_k_243, heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_2411, v_tyStx_245, v_t_2412, v_t_2417}), v_g_27_242);
}
V g_heff_2ebuild_2edriver_2estructBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2estructBody(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2estructAdd_str0, 2, "#T");
Clo g_heff_2ebuild_2edriver_2estructAdd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2estructAdd_entry, 4, 0};

V g_heff_2ebuild_2edriver_2estructAdd(V v_mkey_240, V v_g_241, V v_es_242, V v_idx_243) {
top: ;
  V v_k_244 = heff_strAppend(heff_dup(v_mkey_240), ((V)&g_heff_2ebuild_2edriver_2estructAdd_str0));
  V v_t_245 = (g_list_2efoldl_24s999799596x1949685079(NTAG(TAG_Small), v_es_242));
  V v_t_246 = ({ V a_0 = v_t_245; V b_1 = NTAG(TAG_Large); V r_ = (g_heff_2eelab_2eparams_2eeqLevel(a_0, b_1)); heff_drop(v_t_245); heff_drop(b_1); r_; });
  V v_t_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    v_t_247 = NTAG(TAG_LargeU);
    break;
  }
  case TAG_False: {
    v_t_247 = NTAG(TAG_SmallU);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_tyStx_248 = heff_tag_n(TAG_SU, 1, (V[]){v_t_247});
  V v_t_249 = (g_list_2efoldl_24s999799596x1949685079(NTAG(TAG_Small), v_es_242));
  V v_pairs_2410 = (g_heff_2ebuild_2edriver_2estructFieldsGo(v_idx_243, MK_INT(0LL), heff_dup(v_es_242)));
  V v_t_2411 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_2410)));
  V v_t_2412 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2410));
  V v_t_2413 = (g_list_2emap_24s1173914895x100384474(v_pairs_2410));
  V v_t_2414 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2411), v_t_2412, heff_arrayFromList(v_t_2413)});
  V v_bodyStx_2415 = heff_tag_n(TAG_SCode, 1, (V[]){heff_tag_n(TAG_SRecord, 3, (V[]){v_t_249, v_t_2414, heff_dup(g_heff_2eutil_2edict_2eempty_get())})});
  V v_t_2416 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_241), heff_dup(v_k_244), heff_dup(v_tyStx_248), heff_dup(v_bodyStx_2415)));
  V v_x1_2417 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(heff_dup(v_g_241), NTAG(TAG_N), heff_dup(v_tyStx_248), NTAG(TAG_LNil)));
  V v_t_2421;
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nom: {
    V v_x_2418 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2418;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    v_t_2421 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2420 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x1_2417);
  }
  V v_t_2422 = (g_heff_2eelab_2eglobals_2eaddEntry(v_k_244, heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_2415, v_tyStx_248, v_t_2416, v_t_2421}), v_g_241));
  return (g_heff_2ebuild_2edriver_2estructBody(v_mkey_240, v_es_242, v_t_2422));
}
V g_heff_2ebuild_2edriver_2estructAdd_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2estructAdd(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ebuild_2edriver_2emoduleStruct_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2emoduleStruct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2emoduleStruct_entry, 3, 0};

V g_heff_2ebuild_2edriver_2emoduleStruct(V v_mkey_240, V v_own_241, V v_g_242) {
top: ;
  V v_t_244 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2emoduleStruct_lam0, 1, 1, (V[]){heff_dup(v_g_242)}), v_own_241));
  V v_es_245 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_244));
  switch (heff_tag_of(v_es_245)) {
  case TAG_Nil: {
    heff_drop(v_mkey_240);
    return v_g_242;
  }
  case TAG_Cons: {
    V v_t_248 = (g_list_2efoldl_24s999799596x1949685079(NTAG(TAG_Small), v_es_245));
    V v_t_249 = ({ V a_0 = v_t_248; V b_1 = NTAG(TAG_TopL); V r_ = (g_heff_2eelab_2eparams_2eeqLevel(a_0, b_1)); heff_drop(v_t_248); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_mkey_240);
      heff_drop_tag(v_es_245, 2);
      return v_g_242;
    }
    case TAG_False: {
      V v_t_2410 = (g_heff_2ebuild_2edriver_2estructIdxGo(MK_INT(0LL), v_es_245, heff_dup(g_map_2eempty_get())));
      return ({ V a_0 = v_mkey_240; V a_1 = v_g_242; V a_2 = v_es_245; V a_3 = v_t_2410; V r_ = (g_heff_2ebuild_2edriver_2estructAdd(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_es_245);
  }
}
V g_heff_2ebuild_2edriver_2emoduleStruct_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2emoduleStruct(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edriver_2emoduleStruct_lam0(V self, V *args) {
  V v_o_243 = args[0];
  V v_g_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2estructEntryOf(v_g_242, v_o_243));
}
Clo g_heff_2ebuild_2edriver_2efixOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efixOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2efixOf(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_m_241);
    return heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get());
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x11_242, 0);
      V v_f_245 = heff_field(v_x11_242, 1);
      if (heff_strEq_c(heff_dup(v_n_244), heff_dup(v_m_241))) {
        heff_drop(v_m_241);
        return heff_dup(v_f_245);
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_m_241;
        v_x1_240 = t_0;
        v_m_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2efixOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2efixOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2eimportedFix_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eimportedFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eimportedFix_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eimportedFix(V v_done_240, V v_imps_241) {
top: ;
  return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2eimportedFix_lam0, 2, 1, (V[]){heff_dup(v_done_240)}); V a_1 = heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get()); V b_2 = heff_get_n(v_imps_241, 0, 3); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2edriver_2eimportedFix_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eimportedFix(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2eimportedFix_lam0(V self, V *args) {
  V v_f_242 = args[0];
  V v_i_243 = args[1];
  V v_done_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_244 = ({ V a_0 = v_done_240; V a_1 = heff_get_n(v_i_243, 0, 3); V r_ = (g_heff_2ebuild_2edriver_2efixOf(a_0, a_1)); heff_drop(v_done_240); r_; });
  V v_t_245 = (g_heff_2esyntax_2efixity_2eappendF(heff_take_field(v_f_242, 0), heff_take_field(v_b_244, 0)));
  V v_t_246 = (g_heff_2esyntax_2efixity_2enubByG(v_t_245));
  V v_t_247 = (g_heff_2esyntax_2efixity_2eappendF(heff_get_n(v_f_242, 1, 2), heff_get_n(v_b_244, 1, 2)));
  V v_t_248 = (g_heff_2esyntax_2efixity_2enubByE(v_t_247));
  return heff_rec_n(2, shape_groups__above, (V[]){v_t_246, v_t_248});
}
Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efixitiesGo_entry, 2, 0};

V g_heff_2ebuild_2edriver_2efixitiesGo(V v_done_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_done_240);
    return heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get());
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_244 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_s_242, 5)), heff_dup(heff_rfield(v_s_242, 3))));
      V v_t_245 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_s_242, 4), v_t_244));
      V v_a_246 = (g_heff_2ebuild_2edriver_2eimportedFix(v_done_240, v_t_245));
      V v_t_247 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_take_field(v_s_242, 5), heff_take_field(v_s_242, 3)));
      V v_imps_248 = ({ V b_0 = heff_get_n(v_s_242, 4, 7); V a_1 = v_t_247; V r_ = (g_heff_2esyntax_2eimport_2erenamed(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_249 = ({ V a_0 = v_done_240; V a_1 = heff_dup(v_imps_248); V r_ = (g_heff_2ebuild_2edriver_2eimportedFix(a_0, a_1)); heff_drop(v_done_240); r_; });
      V v_b_2410 = (g_heff_2esyntax_2esurface_2efixitiesOfText(v_t_249, heff_get_n(v_imps_248, 2, 3)));
      V v_t_2411 = (g_heff_2esyntax_2efixity_2eappendF(heff_take_field(v_a_246, 0), heff_take_field(v_b_2410, 0)));
      V v_t_2412 = (g_heff_2esyntax_2efixity_2enubByG(v_t_2411));
      V v_t_2413 = (g_heff_2esyntax_2efixity_2eappendF(heff_get_n(v_a_246, 1, 2), heff_get_n(v_b_2410, 1, 2)));
      V v_t_2414 = (g_heff_2esyntax_2efixity_2enubByE(v_t_2413));
      return heff_rec_n(2, shape_groups__above, (V[]){v_t_2412, v_t_2414});
    }
    case TAG_Cons: {
      V v_t_2417 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_take_field(v_s_242, 5), heff_take_field(v_s_242, 3)));
      V v_imps_2418 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_s_242, 4), v_t_2417));
      V v_t_2419 = (g_heff_2ebuild_2edriver_2eimportedFix(v_done_240, heff_dup(v_imps_2418)));
      V v_t_2420 = (g_heff_2esyntax_2esurface_2efixitiesOfText(v_t_2419, heff_get_n(v_imps_2418, 2, 3)));
      V v_t_2421 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_s_242, 0, 7), v_t_2420});
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_done_240});
      V t_1 = v_x22_243;
      v_done_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2efixitiesGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ehint_str0, 62, "if this is a recursive call, guard the whole call: rec (f ...)");
HEFF_LIT(g_heff_2ebuild_2edriver_2ehint_str1, 115, "name the type: `type T = ...` at top level, or a type field of the struct it is in (`t = { ... }`, then `m.t` here)");
Clo g_heff_2ebuild_2edriver_2ehint_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ehint_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ehint(V v_d_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_d_240, 4));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Nothing: {
    if (heff_intEq_c(heff_dup(heff_rfield(v_d_240, 0)), MK_INT(319LL))) {
      return ({ V rv_4 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2edriver_2ehint_str0)}); V rr_ = heff_rec_reuse_n(v_d_240, 15ULL, 5, shape_code__severity__msg__span__note); heff_rfield(rr_, 4) = rv_4; rr_; });
    } else {
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_240, 0)), MK_INT(204LL))) {
        return ({ V rv_4 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2edriver_2ehint_str1)}); V rr_ = heff_rec_reuse_n(v_d_240, 15ULL, 5, shape_code__severity__msg__span__note); heff_rfield(rr_, 4) = rv_4; rr_; });
      } else {
        return v_d_240;
      }
    }
  }
  case TAG_Just: {
    heff_take_n(v_t_241, 0ULL, 1);
    return v_d_240;
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ebuild_2edriver_2ehint_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ehint(a[0]);
}
Clo g_heff_2ebuild_2edriver_2ethawedChecked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ethawedChecked_entry, 4, 0};

V g_heff_2ebuild_2edriver_2ethawedChecked(V v_s_240, V v_imps_241, V v_th_242, V v_t_243) {
top: ;
  V v_own_244 = (g_heff_2ebuild_2edriver_2eownOf(heff_dup(heff_rfield(v_s_240, 0)), heff_dup(heff_rfield(v_t_243, 2))));
  V v_globals_245 = (g_heff_2ebuild_2edriver_2emoduleStruct(heff_dup(heff_rfield(v_s_240, 0)), v_own_244, heff_take_field(v_t_243, 0)));
  V v_own_246 = (g_heff_2ebuild_2edriver_2eownOf(heff_dup(heff_rfield(v_s_240, 0)), heff_dup(heff_rfield(v_t_243, 2))));
  V v_t_247 = (g_list_2emap_24s424270175x1918189508(heff_dup(heff_rfield(v_imps_241, 0))));
  V v_deps_248 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_247));
  V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_imps_241, 1)));
  V v_t_2410 = (g_list_2edrop(v_t_249, heff_dup(heff_rfield(v_imps_241, 0))));
  V v_opens_2411 = (g_heff_2ebuild_2edriver_2eopenNames(v_t_2410));
  V v_t_2412 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_imps_241, 1)));
  V v_t_2413 = (g_list_2edrop(v_t_2412, heff_get_n(v_imps_241, 0, 3)));
  V v_aliases_2414 = (g_heff_2ebuild_2edriver_2ealiasPairs(v_t_2413));
  V v_t_2415 = ({ V rv_0 = v_globals_245; V rr_ = heff_rec_reuse_n(v_t_243, 510ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 0) = rv_0; rr_; });
  return heff_rec_n(13, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached, (V[]){heff_dup(heff_rfield(v_s_240, 0)), heff_dup(heff_rfield(v_s_240, 1)), heff_dup(heff_rfield(v_s_240, 2)), heff_get_n(v_s_240, 3, 7), NTAG(TAG_Nil), v_t_2415, NTAG(TAG_Nil), v_own_246, v_deps_248, v_opens_2411, v_aliases_2414, heff_get_n(v_th_242, 0, 3), NTAG(TAG_True)});
}
V g_heff_2ebuild_2edriver_2ethawedChecked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ethawedChecked(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportedAgain_str0, 23, ", without being written");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportedAgain_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportedAgain_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportedAgain_str3, 21, "` is imported already");
V g_heff_2ebuild_2edriver_2eimportedAgain_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eimportedAgain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eimportedAgain_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eimportedAgain(V v_implicit_240, V v_i_241) {
top: ;
  V v_t_249 = (g_list_2eany(heff_clo_n(g_heff_2ebuild_2edriver_2eimportedAgain_lam0, 1, 1, (V[]){heff_dup(v_i_241)}), v_implicit_240));
  V v_t_2410;
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    v_t_2410 = ((V)&g_heff_2ebuild_2edriver_2eimportedAgain_str0);
    break;
  }
  case TAG_False: {
    v_t_2410 = ((V)&g_heff_2ebuild_2edriver_2eimportedAgain_str1);
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eimportedAgain_str2), heff_strAppend(heff_dup(heff_rfield(v_i_241, 0)), heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eimportedAgain_str3), v_t_2410)));
  return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(334LL), NTAG(TAG_SError), v_t_2411, heff_get_n(v_i_241, 2, 3), NTAG(TAG_Nothing)});
}
V g_heff_2ebuild_2edriver_2eimportedAgain_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eimportedAgain(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2eimportedAgain_lam0(V self, V *args) {
  V v_j_242 = args[0];
  V v_i_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_strEq_c(heff_dup(heff_rfield(v_i_241, 0)), heff_dup(heff_rfield(v_j_242, 0)))) {
    V v_x2_244 = heff_get_n(v_j_242, 1, 3);
    V v_t_245 = heff_get_n(v_i_241, 1, 3);
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Nothing: {
        return NTAG(TAG_True);
      }
      case TAG_Just: {
        heff_take_n(v_x2_244, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x2_244);
      }
    }
    case TAG_Just: {
      V v_a_247 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Nothing: {
        heff_drop(v_a_247);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_b_248 = heff_field(v_x2_244, 0);
        heff_take_n(v_x2_244, 1ULL, 1);
        return heff_strEq(v_a_247, v_b_248);
      }
      default: return heff_nomatch(v_x2_244);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  } else {
    heff_drop_rec(v_j_242, 3);
    heff_drop_rec(v_i_241, 3);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edriver_2eagainGo_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eagainGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eagainGo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eagainGo(V v_implicit_240, V v_had_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_had_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_i_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2412 = (g_list_2eany(heff_clo_n(g_heff_2ebuild_2edriver_2eagainGo_lam0, 1, 1, (V[]){heff_dup(v_i_243)}), v_had_241));
    V v_t_2414;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      V v_t_2413 = (g_heff_2ebuild_2edriver_2eimportedAgain(v_implicit_240, heff_dup(v_i_243)));
      v_t_2414 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
      break;
    }
    case TAG_False: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_t_2415 = (g_heff_2ebuild_2edriver_2eagainGo(v_implicit_240, heff_tag_n(TAG_Cons, 2, (V[]){v_i_243, v_had_241}), v_rest_244));
    return (g_heff_2ebuild_2edriver_2eappendD(v_t_2414, v_t_2415));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2eagainGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eagainGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2eagainGo_lam0(V self, V *args) {
  V v_j_245 = args[0];
  V v_i_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_strEq_c(heff_dup(heff_rfield(v_i_243, 0)), heff_dup(heff_rfield(v_j_245, 0)))) {
    V v_x2_247 = heff_get_n(v_j_245, 1, 3);
    V v_t_248 = heff_get_n(v_i_243, 1, 3);
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        return NTAG(TAG_True);
      }
      case TAG_Just: {
        heff_take_n(v_x2_247, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x2_247);
      }
    }
    case TAG_Just: {
      V v_a_2410 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        heff_drop(v_a_2410);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_b_2411 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        return heff_strEq(v_a_2410, v_b_2411);
      }
      default: return heff_nomatch(v_x2_247);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  } else {
    heff_drop_rec(v_j_245, 3);
    heff_drop_rec(v_i_243, 3);
    return NTAG(TAG_False);
  }
}
Clo g_heff_2ebuild_2edriver_2eelabTop_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabTop_entry, 5, 0};

V g_heff_2ebuild_2edriver_2eelabTop(V v_s_240, V v_imps_241, V v_direct_242, V v_r_243, V v_t_244) {
top: ;
  V v_own_245 = (g_heff_2ebuild_2edriver_2eownOf(heff_dup(heff_rfield(v_s_240, 0)), heff_dup(heff_rfield(v_t_244, 2))));
  V v_globals_246 = (g_heff_2ebuild_2edriver_2emoduleStruct(heff_dup(heff_rfield(v_s_240, 0)), v_own_245, heff_take_field(v_t_244, 0)));
  V v_t_247 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_imps_241, 1)));
  V v_t_248 = (g_list_2edrop(v_t_247, heff_dup(heff_rfield(v_imps_241, 0))));
  V v_t_249 = (g_heff_2ebuild_2edriver_2eagainGo(heff_rfield(v_imps_241, 1), heff_dup(heff_rfield(v_imps_241, 1)), v_t_248));
  V v_t_2410 = (g_heff_2ebuild_2edriver_2eappendD(heff_take_field(v_r_243, 1), heff_dup(heff_rfield(v_t_244, 1))));
  V v_t_2411 = (g_list_2emap_24s864521685x1610969087(v_t_2410));
  V v_diags_2412 = (g_heff_2ebuild_2edriver_2eappendD(v_t_249, v_t_2411));
  V v_own_2413 = (g_heff_2ebuild_2edriver_2eownOf(heff_dup(heff_rfield(v_s_240, 0)), heff_dup(heff_rfield(v_t_244, 2))));
  V v_t_2414 = (g_list_2emap_24s424270175x1918189508(heff_dup(heff_rfield(v_imps_241, 0))));
  V v_deps_2415 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2414));
  V v_t_2416 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_imps_241, 1)));
  V v_t_2417 = (g_list_2edrop(v_t_2416, heff_dup(heff_rfield(v_imps_241, 0))));
  V v_opens_2418 = (g_heff_2ebuild_2edriver_2eopenNames(v_t_2417));
  V v_t_2419 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_imps_241, 1)));
  V v_t_2420 = (g_list_2edrop(v_t_2419, heff_get_n(v_imps_241, 0, 3)));
  V v_aliases_2421 = (g_heff_2ebuild_2edriver_2ealiasPairs(v_t_2420));
  V v_t_2422 = ({ V rv_0 = v_globals_246; V rr_ = heff_rec_reuse_n(v_t_244, 510ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace); heff_rfield(rr_, 0) = rv_0; rr_; });
  return heff_rec_n(13, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached, (V[]){heff_dup(heff_rfield(v_s_240, 0)), heff_dup(heff_rfield(v_s_240, 1)), heff_dup(heff_rfield(v_s_240, 2)), heff_get_n(v_s_240, 3, 7), heff_dup(heff_rfield(v_r_243, 0)), v_t_2422, v_diags_2412, v_own_2413, v_deps_2415, v_opens_2418, v_aliases_2421, heff_get_n(v_r_243, 2, 4), NTAG(TAG_False)});
}
V g_heff_2ebuild_2edriver_2eelabTop_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2eelabTop(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabDecls_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabDecls_str1, 1, ".");
V g_heff_2ebuild_2edriver_2eelabDecls_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2eelabDecls_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eelabDecls_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabDecls_entry, 7, 0};

V g_heff_2ebuild_2edriver_2eelabDecls(V v_done_240, V v_s_241, V v_imps_242, V v_direct_243, V v_g0_244, V v_r_245, V v_decls_246) {
top: ;
  V v_g0_248 = (g_heff_2ebuild_2edriver_2ewithParseBroken(heff_clo_n(g_heff_2ebuild_2edriver_2eelabDecls_lam0, 1, 1, (V[]){heff_dup(v_s_241)}), v_g0_244, heff_rfield(v_r_245, 3)));
  V v_t_249 = heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_g0_248, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V v_t_2410 = (g_list_2emap(heff_dup(g_heff_2esyntax_2epresyntax_2eclassify_get()), v_decls_246));
  V v_t_2412 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2eelabDecls_lam1, 1, 1, (V[]){heff_dup(v_s_241)}); V a_1 = v_t_249; V a_2 = v_t_2410; V r_ = (g_heff_2eelab_2etoplevel_2etopGo(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
  return (g_heff_2ebuild_2edriver_2eelabTop(v_s_241, v_imps_242, v_direct_243, v_r_245, v_t_2412));
}
V g_heff_2ebuild_2edriver_2eelabDecls_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2eelabDecls(a0, a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a3); return r;
}
V g_heff_2ebuild_2edriver_2eelabDecls_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strAppend(heff_get_n(v_s_241, 0, 7), heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eelabDecls_str0), v_x_247));
}
V g_heff_2ebuild_2edriver_2eelabDecls_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strAppend(heff_get_n(v_s_241, 0, 7), heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eelabDecls_str1), v_x_2411));
}
Clo g_heff_2ebuild_2edriver_2eelabRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabRead_entry, 6, 0};

V g_heff_2ebuild_2edriver_2eelabRead(V v_done_240, V v_s_241, V v_imps_242, V v_direct_243, V v_g0_244, V v_r_245) {
top: ;
  V v_t_246 = heff_dup(heff_rfield(v_s_241, 6));
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    return (g_heff_2ebuild_2edriver_2eelabDecls(v_done_240, v_s_241, v_imps_242, v_direct_243, v_g0_244, heff_dup(v_r_245), heff_get_n(v_r_245, 0, 4)));
  }
  case TAG_False: {
    V v_t_247 = (g_list_2emap_24s1535007417x1587061701(heff_dup(heff_rfield(v_r_245, 0))));
    V v_refused_248 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_247));
    V v_t_249 = (g_list_2emap_24s1534167768x1221742344(heff_dup(v_refused_248)));
    V v_t_2410 = (g_heff_2ebuild_2edriver_2eappendD(heff_take_field(v_r_245, 1), v_t_249));
    V v_t_2411 = (g_list_2emap_24s1937570095x2110149801(v_refused_248));
    V v_t_2412 = (g_heff_2ebuild_2edriver_2eappendD(heff_take_field(v_r_245, 3), v_t_2411));
    V v_t_2413 = heff_rec_n(4, shape_decls__diags__fixities__broken, (V[]){heff_dup(heff_rfield(v_r_245, 0)), v_t_2410, heff_take_field(v_r_245, 2), v_t_2412});
    V v_t_2414 = (g_list_2efilter_24s1725367856x1498536808(heff_get_n(v_r_245, 0, 4)));
    return (g_heff_2ebuild_2edriver_2eelabDecls(v_done_240, v_s_241, v_imps_242, v_direct_243, v_g0_244, v_t_2413, v_t_2414));
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ebuild_2edriver_2eelabRead_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2eelabRead(a0, a[1], a[2], a3, a[4], a[5]); heff_drop(a0); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabEnv_str0, 3, "by ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eelabEnv_str1, 5, ", at ");
V g_heff_2ebuild_2edriver_2eelabEnv_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eelabEnv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabEnv_entry, 5, 0};

V g_heff_2ebuild_2edriver_2eelabEnv(V v_done_240, V v_s_241, V v_imps_242, V v_direct_243, V v_g0_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s1659066958x125973700(heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get()), v_direct_243));
  V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eelabEnv_str0), heff_strAppend(heff_dup(heff_rfield(v_s_241, 0)), heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eelabEnv_str1), heff_dup(heff_rfield(v_s_241, 2)))));
  V v_o_2412 = heff_rec_n(4, shape_known__fixities__lenient__place, (V[]){heff_clo_n(g_heff_2ebuild_2edriver_2eelabEnv_lam0, 1, 1, (V[]){heff_dup(v_g0_244)}), v_t_245, NTAG(TAG_False), v_t_246});
  V v_src_2413 = heff_dup(heff_rfield(v_imps_242, 2));
  V v_t_2414 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_2415 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(v_src_2413), v_t_2414, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_2416 = (g_heff_2esyntax_2esurface_2ereadLexed(v_src_2413, v_o_2412, v_t_2415));
  return (g_heff_2ebuild_2edriver_2eelabRead(v_done_240, v_s_241, v_imps_242, v_direct_243, v_g0_244, v_t_2416));
}
V g_heff_2ebuild_2edriver_2eelabEnv_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2eelabEnv(a0, a[1], a[2], a3, a[4]); heff_drop(a0); heff_drop(a3); return r;
}
V g_heff_2ebuild_2edriver_2eelabEnv_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_g0_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2eelab_2eglobals_2elookupName(heff_dup(v_g0_244), heff_dup(v_x_247)));
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    V v_t_249 = ({ V a_0 = v_x_247; V b_1 = heff_get_n(v_g0_244, 4, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_t_249, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  case TAG_Just: {
    heff_take_n(v_t_248, 0ULL, 1);
    heff_drop(v_x_247);
    heff_drop_rec(v_g0_244, 7);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_248);
  }
}
Clo g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703_entry, 1, 0};

V g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ebuild_2edriver_2ebrokenIn(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703(v_xs_242));
    return (g_heff_2ebuild_2edriver_2eappendD(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2eelabClashed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabClashed_entry, 8, 0};

V g_heff_2ebuild_2edriver_2eelabClashed(V v_done_240, V v_s_241, V v_imps_242, V v_thaw_243, V v_direct_244, V v_needed_245, V v_imported_246, V v_clashes_247) {
top: ;
  V v_t_248 = (g_list_2emap_24s424270175x1918189508(heff_dup(heff_rfield(v_imps_242, 0))));
  V v_t_249 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_248));
  V v_t_2410 = (g_list_2efoldl_24s1261443129x1682844402(heff_dup(g_heff_2eelab_2eglobals_2eemptyGlobals_get()), v_needed_245));
  V v_t_2411 = (g_heff_2ebuild_2edriver_2ealiasOpen(v_done_240, v_clashes_247, v_t_2410, v_imported_246));
  V v_t_2412 = (g_heff_2ebuild_2edriver_2econcatMapD_24s1055690557x2063466703(v_direct_244));
  V v_t_2413 = (g_heff_2ebuild_2edriver_2ealiasOpen(v_done_240, v_clashes_247, v_t_2411, v_t_2412));
  V v_t_2414 = (g_heff_2ebuild_2edriver_2ealiasPairs(heff_dup(heff_rfield(v_imps_242, 0))));
  V v_t_2415 = ({ V a_0 = v_done_240; V a_1 = v_t_2413; V a_2 = v_t_2414; V r_ = (g_heff_2ebuild_2edriver_2ealiasQualified(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
  V v_g0_2416 = ({ V a_0 = v_done_240; V a_1 = v_t_249; V a_2 = v_t_2415; V r_ = (g_heff_2ebuild_2edriver_2ewithImportedInstances(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
  switch (heff_tag_of(v_thaw_243)) {
  case TAG_Nothing: {
    return (g_heff_2ebuild_2edriver_2eelabEnv(v_done_240, v_s_241, v_imps_242, v_direct_244, v_g0_2416));
  }
  case TAG_Just: {
    V v_th_2417 = heff_field(v_thaw_243, 0);
    V v_t_2418 = heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_g0_2416, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2419 = (g_list_2efoldl_24s337463599x663364213(v_t_2418, heff_rfield(v_th_2417, 1)));
    V v_t_2420 = (g_heff_2eelab_2etoplevel_2ethawDone(v_t_2419));
    return (g_heff_2ebuild_2edriver_2ethawedChecked(v_s_241, v_imps_242, heff_dup(v_th_2417), v_t_2420));
  }
  default: return heff_nomatch(v_thaw_243);
  }
}
V g_heff_2ebuild_2edriver_2eelabClashed_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V a7 = a[7]; V r = g_heff_2ebuild_2edriver_2eelabClashed(a0, a[1], a[2], a3, a4, a5, a[6], a7); heff_drop(a0); heff_drop(a3); heff_drop(a4); heff_drop(a5); heff_drop(a7); return r;
}
V g_heff_2ebuild_2edriver_2eelabAliased_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eelabAliased_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabAliased_entry, 7, 0};

V g_heff_2ebuild_2edriver_2eelabAliased(V v_done_240, V v_s_241, V v_imps_242, V v_thaw_243, V v_direct_244, V v_needed_245, V v_imported_246) {
top: ;
  V v_m_247 = (g_heff_2ebuild_2edriver_2eclashMap(heff_dup(g_map_2eempty_get()), heff_dup(v_imported_246)));
  V v_t_2413 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2eelabAliased_lam0, 1, 1, (V[]){v_m_247}), heff_dup(v_imported_246)));
  V v_t_2414 = (g_heff_2ebuild_2edriver_2enubByName(v_t_2413));
  return ({ V a_0 = v_done_240; V a_1 = v_s_241; V a_2 = v_imps_242; V a_3 = v_thaw_243; V a_4 = v_direct_244; V a_5 = v_needed_245; V a_6 = v_imported_246; V a_7 = v_t_2414; V r_ = (g_heff_2ebuild_2edriver_2eelabClashed(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2414); r_; });
}
V g_heff_2ebuild_2edriver_2eelabAliased_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V r = g_heff_2ebuild_2edriver_2eelabAliased(a0, a[1], a[2], a3, a4, a5, a[6]); heff_drop(a0); heff_drop(a3); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2ebuild_2edriver_2eelabAliased_lam0(V self, V *args) {
  V v_o_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_it_249 = ({ V a_0 = heff_get_n(v_o_248, 0, 3); V a_1 = v_m_247; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_247); r_; });
  switch (heff_tag_of(v_it_249)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_it1_2410 = heff_field(v_it_249, 0);
    heff_take_n(v_it_249, 1ULL, 1);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_MkPair: {
      V v_c_2412 = heff_field(v_it1_2410, 1);
      heff_take_n(v_it1_2410, 2ULL, 2);
      return v_c_2412;
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  default: return heff_nomatch(v_it_249);
  }
}
V g_heff_2ebuild_2edriver_2eelabDirect_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eelabDirect_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabDirect_entry, 6, 0};

V g_heff_2ebuild_2edriver_2eelabDirect(V v_done_240, V v_s_241, V v_imps_242, V v_thaw_243, V v_direct_244, V v_needed_245) {
top: ;
  V v_unwritten_246 = (g_list_2emap_24s424270175x1918189508(heff_dup(heff_rfield(v_imps_242, 1))));
  V v_all_247 = (g_heff_2ebuild_2edriver_2econcatMapD_24s1236007820x849009822(v_direct_244));
  V v_t_2410 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2eelabDirect_lam0, 1, 2, (V[]){v_unwritten_246, heff_dup(v_all_247)}), v_all_247));
  return (g_heff_2ebuild_2edriver_2eelabAliased(v_done_240, v_s_241, v_imps_242, v_thaw_243, v_direct_244, v_needed_245, v_t_2410));
}
V g_heff_2ebuild_2edriver_2eelabDirect_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V r = g_heff_2ebuild_2edriver_2eelabDirect(a0, a[1], a[2], a3, a4, a5); heff_drop(a0); heff_drop(a3); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2ebuild_2edriver_2eelabDirect_lam0(V self, V *args) {
  V v_o_248 = args[0];
  V v_unwritten_246 = heff_env(self)[0];
  V v_all_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_249 = ({ V a_0 = v_unwritten_246; V a_1 = v_all_247; V a_2 = v_o_248; V r_ = (g_heff_2ebuild_2edriver_2egivesWay(a_0, a_1, a_2)); heff_drop(v_unwritten_246); heff_drop(v_all_247); r_; });
  switch (heff_tag_of(v_x1_249)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_249);
  }
}
Clo g_heff_2ebuild_2edriver_2eprimDeclsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eprimDeclsGo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eprimDeclsGo(V v_c_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_243 = heff_field(v_x2_241, 0);
    V v_os_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_c_240);
      heff_drop_rec(v_o_243, 2);
      heff_drop(v_os_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x31_245 = heff_field(v_x3_242, 0);
      V v_sps_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_sp_248 = heff_field(v_x31_245, 1);
        heff_take_n(v_x31_245, 2ULL, 2);
        if (heff_strEq_c(heff_dup(heff_rfield(v_o_243, 0)), heff_dup(heff_rfield(v_o_243, 1)))) {
          V v_t_2410 = heff_rec_n(3, shape_key__by__span, (V[]){heff_get_n(v_o_243, 1, 2), heff_dup(v_c_240), v_sp_248});
          return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_heff_2ebuild_2edriver_2eprimDeclsGo(v_c_240, v_os_244, v_sps_246))});
        } else {
          heff_drop_rec(v_o_243, 2);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_sp_248);
          V t_0 = v_c_240;
          V t_1 = v_os_244;
          V t_2 = v_sps_246;
          v_c_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
      default: return heff_nomatch(v_x31_245);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2eprimDeclsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eprimDeclsGo(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edriver_2etwicesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etwicesGo_entry, 2, 0};

V g_heff_2ebuild_2edriver_2etwicesGo(V v_firsts_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_firsts_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_d_242, 0)), v_firsts_240));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_245 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_d_242, 0)), v_d_242, v_firsts_240));
      V t_0 = v_t_245;
      V t_1 = v_rest_243;
      v_firsts_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_f_246 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_first__again, (V[]){v_f_246, v_d_242}), (g_heff_2ebuild_2edriver_2etwicesGo(v_firsts_240, v_rest_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2etwicesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etwicesGo(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2emetIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2emetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2emetIn_entry, 4, 0};

V g_heff_2ebuild_2edriver_2emetIn(V v_done_240, V v_imps_241, V v_c_242, V v_t_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_t_243, 1)), 1, 3);
  if (heff_strEq_c(heff_get_n(v_t_244, 0, 13), heff_get_n(v_c_242, 0, 13))) {
    heff_drop_rec(v_imps_241, 3);
    heff_drop_rec(v_t_243, 2);
    return NTAG(TAG_True);
  } else {
    V v_x1_2416 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2emetIn_lam0, 1, 2, (V[]){heff_dup(v_done_240), v_t_243}); V b_1 = heff_get_n(v_imps_241, 0, 3); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_2416);
    }
  }
}
V g_heff_2ebuild_2edriver_2emetIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2emetIn(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2emetIn_lam0(V self, V *args) {
  V v_i_246 = args[0];
  V v_done_240 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_i_246, 0)), NTAG(TAG_Nil)});
  V v_xs_248 = (g_heff_2ebuild_2edriver_2eclosureGo(v_done_240, NTAG(TAG_Nil), v_t_247));
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_t_243, 0)), 1, 3);
  V v_t_2410 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_t_249, 0, 13)}));
  V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_xs_248; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_248); r_; });
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_i_246, 0, 3), NTAG(TAG_Nil)});
    V v_xs_2413 = ({ V a_0 = v_done_240; V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2412; V r_ = (g_heff_2ebuild_2edriver_2eclosureGo(a_0, a_1, a_2)); heff_drop(v_done_240); r_; });
    V v_t_2414 = heff_get_n(heff_get_n(v_t_243, 1, 2), 1, 3);
    V v_t_2415 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_t_2414, 0, 13)}));
    return ({ V a_0 = v_t_2415; V a_1 = v_xs_2413; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_2413); r_; });
  }
  case TAG_False: {
    heff_drop_rec(v_i_246, 3);
    heff_drop(v_done_240);
    heff_drop_rec(v_t_243, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_2411);
  }
}
Clo g_heff_2ebuild_2edriver_2eimportOfGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eimportOfGo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eimportOfGo(V v_done_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_m_241);
    return heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)});
  }
  case TAG_Cons: {
    V v_i_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_i_243, 0)), NTAG(TAG_Nil)});
    V v_xs_246 = (g_heff_2ebuild_2edriver_2eclosureGo(v_done_240, NTAG(TAG_Nil), v_t_245));
    V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_m_241)}));
    V v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_xs_246; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_246); r_; });
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_m_241);
      heff_drop(v_rest_244);
      return heff_get_n(v_i_243, 2, 3);
    }
    case TAG_False: {
      heff_drop_rec(v_i_243, 3);
      V t_0 = v_done_240;
      V t_1 = v_m_241;
      V t_2 = v_rest_244;
      v_done_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2eimportOfGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eimportOfGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2etwiceDiag_str0, 15, "the primitive `");
HEFF_LIT(g_heff_2ebuild_2edriver_2etwiceDiag_str1, 14, "` is declared ");
HEFF_LIT(g_heff_2ebuild_2edriver_2etwiceDiag_str2, 6, ", and ");
Clo g_heff_2ebuild_2edriver_2etwiceDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etwiceDiag_entry, 4, 0};

V g_heff_2ebuild_2edriver_2etwiceDiag(V v_done_240, V v_imps_241, V v_c_242, V v_t_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_t_243, 1)), 0, 3);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_t_243, 0)), 1, 3);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_t_243, 0)), 2, 3);
  V v_t_247 = (g_heff_2ebuild_2edriver_2eplaceAt(v_t_245, v_t_246));
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_t_243, 1)), 1, 3);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_t_243, 1)), 2, 3);
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2etwiceDiag_str0), heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ebuild_2edriver_2etwiceDiag_str1), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2edriver_2etwiceDiag_str2), (g_heff_2ebuild_2edriver_2eplaceAt(v_t_248, v_t_249)))))));
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_t_243, 1)), 1, 3);
  V v_t_2414;
  if (heff_strEq_c(heff_get_n(v_t_2411, 0, 13), heff_get_n(v_c_242, 0, 13))) {
    heff_drop_rec(v_imps_241, 3);
    v_t_2414 = heff_get_n(heff_get_n(v_t_243, 1, 2), 2, 3);
  } else {
    V v_t_2413 = heff_get_n(heff_get_n(v_t_243, 1, 2), 1, 3);
    v_t_2414 = (g_heff_2ebuild_2edriver_2eimportOfGo(v_done_240, heff_get_n(v_t_2413, 0, 13), heff_get_n(v_imps_241, 0, 3)));
  }
  return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(336LL), NTAG(TAG_SError), v_t_2410, v_t_2414, NTAG(TAG_Nothing)});
}
V g_heff_2ebuild_2edriver_2etwiceDiag_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2etwiceDiag(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2ewithDiags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithDiags_entry, 2, 0};

V g_heff_2ebuild_2edriver_2ewithDiags(V v_c_240, V v_ds_241) {
top: ;
  switch (heff_tag_of(v_ds_241)) {
  case TAG_Nil: {
    return v_c_240;
  }
  case TAG_Cons: {
    V v_diags_244 = (g_heff_2ebuild_2edriver_2eappendD(heff_take_field(v_c_240, 6), v_ds_241));
    return ({ V rv_6 = v_diags_244; V rr_ = heff_rec_reuse_n(v_c_240, 8127ULL, 13, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached); heff_rfield(rr_, 6) = rv_6; rr_; });
  }
  default: return heff_nomatch(v_ds_241);
  }
}
V g_heff_2ebuild_2edriver_2ewithDiags_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ewithDiags(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301_entry, 1, 0};

V g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_x_241, 5)), 6, 9);
    V v_t_244 = (g_heff_2ebuild_2edriver_2eprimDeclsGo(heff_dup(v_x_241), heff_dup(heff_rfield(v_x_241, 7)), v_t_243));
    V v_t_245 = (g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301(v_xs_242));
    return (g_heff_2ebuild_2edriver_2eappendD(v_t_244, v_t_245));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2ewithTwice_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewithTwice_entry, 4, 0};

V g_heff_2ebuild_2edriver_2ewithTwice(V v_done_240, V v_imps_241, V v_needed_242, V v_c_243) {
top: ;
  V v_t_244 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edriver_2etwiceDiag_clo), 3, (V[]){heff_dup(v_done_240), heff_dup(v_imps_241), heff_dup(v_c_243)}));
  V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edriver_2emetIn_clo), 3, (V[]){v_done_240, v_imps_241, heff_dup(v_c_243)}));
  V v_t_246 = (g_heff_2ebuild_2edriver_2econcatMapD_24s738666050x669843301(v_needed_242));
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_c_243, 5)), 6, 9);
  V v_t_248 = (g_heff_2ebuild_2edriver_2eprimDeclsGo(heff_dup(v_c_243), heff_dup(heff_rfield(v_c_243, 7)), v_t_247));
  V v_t_249 = (g_heff_2ebuild_2edriver_2eappendD(v_t_246, v_t_248));
  V v_t_2410 = (g_heff_2ebuild_2edriver_2etwicesGo(heff_dup(g_map_2eempty_get()), v_t_249));
  V v_t_2411 = (g_list_2efilter(v_t_245, v_t_2410));
  V v_t_2412 = (g_list_2emap(v_t_244, v_t_2411));
  return (g_heff_2ebuild_2edriver_2ewithDiags(v_c_243, v_t_2412));
}
V g_heff_2ebuild_2edriver_2ewithTwice_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2ewithTwice(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2edriver_2eelabNeeding_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2eelabNeeding_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eelabNeeding_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabNeeding_entry, 5, 0};

V g_heff_2ebuild_2edriver_2eelabNeeding(V v_done_240, V v_s_241, V v_imps_242, V v_thaw_243, V v_reached_244) {
top: ;
  V v_needed_247 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2eelabNeeding_lam0, 1, 1, (V[]){heff_dup(v_reached_244)}), heff_dup(v_done_240)));
  V v_t_2411 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2eelabNeeding_lam1, 1, 1, (V[]){heff_dup(v_imps_242)}), heff_dup(v_done_240)));
  V v_t_2412 = ({ V a_0 = v_done_240; V a_1 = v_s_241; V a_2 = heff_dup(v_imps_242); V a_3 = v_thaw_243; V a_4 = v_t_2411; V a_5 = v_needed_247; V r_ = (g_heff_2ebuild_2edriver_2eelabDirect(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2411); r_; });
  return ({ V a_0 = v_done_240; V a_1 = v_imps_242; V a_2 = v_needed_247; V a_3 = v_t_2412; V r_ = (g_heff_2ebuild_2edriver_2ewithTwice(a_0, a_1, a_2, a_3)); heff_drop(v_needed_247); r_; });
}
V g_heff_2ebuild_2edriver_2eelabNeeding_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ebuild_2edriver_2eelabNeeding(a[0], a[1], a[2], a3, a4); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2ebuild_2edriver_2eelabNeeding_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_reached_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_245, 0, 13)}));
  return ({ V a_0 = v_t_246; V a_1 = v_reached_244; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_reached_244); r_; });
}
V g_heff_2ebuild_2edriver_2eelabNeeding_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_imps_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_249 = (g_heff_2ebuild_2edriver_2eopenNames(heff_get_n(v_imps_242, 0, 3)));
  V v_t_2410 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_248, 0, 13)}));
  return ({ V a_0 = v_t_2410; V a_1 = v_xs_249; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_249); r_; });
}
Clo g_heff_2ebuild_2edriver_2eelabNext_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eelabNext_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eelabNext(V v_done_240, V v_s_241, V v_thaw_242) {
top: ;
  V v_t_243 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(heff_rfield(v_s_241, 5)), heff_dup(heff_rfield(v_s_241, 3))));
  V v_imps_244 = (g_heff_2esyntax_2eimport_2erenamed(heff_rfield(v_s_241, 4), v_t_243));
  V v_t_245 = (g_list_2emap_24s424270175x1918189508(heff_dup(heff_rfield(v_imps_244, 0))));
  V v_ms_246 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_245));
  V v_t_247 = (g_heff_2ebuild_2edriver_2eclosureGo(v_done_240, NTAG(TAG_Nil), v_ms_246));
  return ({ V a_0 = v_done_240; V a_1 = v_s_241; V a_2 = v_imps_244; V a_3 = v_thaw_242; V a_4 = v_t_247; V r_ = (g_heff_2ebuild_2edriver_2eelabNeeding(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_247); r_; });
}
V g_heff_2ebuild_2edriver_2eelabNext_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2eelabNext(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2edriver_2elean_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2elean_entry, 1, 0};

V g_heff_2ebuild_2edriver_2elean(V v_c_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 7, 9);
  V v_infos_242 = (g_list_2emap_24s214260857x938990544(v_t_241));
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 1, 9);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 2, 9);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 3, 9);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 4, 9);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 5, 9);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 9);
  V v_t_2410 = heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_t_248, v_t_249, v_infos_242, NTAG(TAG_Nil)});
  return ({ V rv_5 = v_t_2410; V rr_ = heff_rec_reuse_n(v_c_240, 8159ULL, 13, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2ebuild_2edriver_2elean_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2elean(a[0]);
}
Clo g_heff_2ebuild_2edriver_2etraceless_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etraceless_entry, 1, 0};

V g_heff_2ebuild_2edriver_2etraceless(V v_c_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 1, 9);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 2, 9);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 3, 9);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 4, 9);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 5, 9);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 9);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 7, 9);
  V v_t_249 = heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_t_241, v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_t_248, NTAG(TAG_Nil)});
  return ({ V rv_5 = v_t_249; V rr_ = heff_rec_reuse_n(v_c_240, 8159ULL, 13, shape_module__path__shown__source__decls__top__diags__own__deps__opens__aliases__fixities__cached); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2ebuild_2edriver_2etraceless_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etraceless(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str0, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str1, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str2, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str3, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str4, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str5, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str6, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str7, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str8, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str9, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str10, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str11, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str12, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str13, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str14, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str15, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str16, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str17, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str18, 4, "prim");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str19, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str20, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str21, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str22, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str23, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str24, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str25, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str26, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str27, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str28, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str29, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str30, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str31, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str32, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str33, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str34, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str35, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str36, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str37, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str38, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str39, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str40, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str41, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str42, 4, "prim");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str43, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str44, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str45, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str46, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str47, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str48, 5, "plain");
HEFF_LIT(g_heff_2ebuild_2edriver_2edefKind_str49, 5, "plain");
Clo g_heff_2ebuild_2edriver_2edefKind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2edefKind_entry, 2, 0};

V g_heff_2ebuild_2edriver_2edefKind(V v_c_240, V v_k_241) {
top: ;
  V v_g_242 = heff_get_n(heff_get_n(v_c_240, 5, 13), 0, 9);
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_241), heff_rfield(v_g_242, 1)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(v_k_241, heff_rfield(v_g_242, 2)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_g_242, 7);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str0);
    }
    case TAG_Just: {
      V v_k2_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_t_246 = ({ V a_0 = v_k2_245; V b_1 = heff_get_n(v_g_242, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        return ((V)&g_heff_2ebuild_2edriver_2edefKind_str1);
      }
      case TAG_Just: {
        V v_e_247 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        V v_t_248 = heff_get_n(v_e_247, 0, 4);
        switch (heff_tag_of(v_t_248)) {
        case TAG_SLocal: {
          heff_take_n(v_t_248, 0ULL, 1);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str2);
        }
        case TAG_SGlobal: {
          heff_take_n(v_t_248, 0ULL, 1);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str3);
        }
        case TAG_SCode: {
          heff_take_n(v_t_248, 0ULL, 1);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str4);
        }
        case TAG_SApp: {
          heff_take_n(v_t_248, 0ULL, 2);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str5);
        }
        case TAG_SLam: {
          heff_take_n(v_t_248, 0ULL, 2);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str6);
        }
        case TAG_SCons: {
          heff_take_n(v_t_248, 0ULL, 1);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str7);
        }
        case TAG_SProj: {
          heff_take_n(v_t_248, 0ULL, 2);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str8);
        }
        case TAG_STag: {
          heff_take_n(v_t_248, 0ULL, 2);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str9);
        }
        case TAG_SMatch: {
          heff_take_n(v_t_248, 0ULL, 2);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str10);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_t_248, 0ULL, 3);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str11);
        }
        case TAG_SIs: {
          heff_take_n(v_t_248, 0ULL, 1);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str12);
        }
        case TAG_SOpaque: {
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str13);
        }
        case TAG_SAbandon: {
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str14);
        }
        case TAG_SRec: {
          heff_take_n(v_t_248, 0ULL, 1);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str15);
        }
        case TAG_SFix: {
          heff_take_n(v_t_248, 0ULL, 2);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str16);
        }
        case TAG_SImplicit: {
          heff_take_n(v_t_248, 0ULL, 2);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str17);
        }
        case TAG_SPrim: {
          heff_take_n(v_t_248, 0ULL, 1);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str18);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_t_248, 0ULL, 3);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str19);
        }
        case TAG_SLitInt: {
          heff_take_n(v_t_248, 0ULL, 1);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str20);
        }
        case TAG_SLitFloat: {
          heff_take_n(v_t_248, 0ULL, 1);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str21);
        }
        case TAG_SLitString: {
          heff_take_n(v_t_248, 0ULL, 1);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str22);
        }
        case TAG_SLitRune: {
          heff_take_n(v_t_248, 0ULL, 1);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str23);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_t_248, 0ULL, 2);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str24);
        }
        case TAG_SLitFloat32: {
          heff_take_n(v_t_248, 0ULL, 1);
          return ((V)&g_heff_2ebuild_2edriver_2edefKind_str25);
        }
        default: return heff_nomatch(v_t_248);
        }
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_e_2443 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    heff_drop_rec(v_g_242, 7);
    V v_t_2444 = heff_get_n(v_e_2443, 0, 4);
    switch (heff_tag_of(v_t_2444)) {
    case TAG_SLocal: {
      heff_take_n(v_t_2444, 0ULL, 1);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str26);
    }
    case TAG_SGlobal: {
      heff_take_n(v_t_2444, 0ULL, 1);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str27);
    }
    case TAG_SCode: {
      heff_take_n(v_t_2444, 0ULL, 1);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str28);
    }
    case TAG_SApp: {
      heff_take_n(v_t_2444, 0ULL, 2);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str29);
    }
    case TAG_SLam: {
      heff_take_n(v_t_2444, 0ULL, 2);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str30);
    }
    case TAG_SCons: {
      heff_take_n(v_t_2444, 0ULL, 1);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str31);
    }
    case TAG_SProj: {
      heff_take_n(v_t_2444, 0ULL, 2);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str32);
    }
    case TAG_STag: {
      heff_take_n(v_t_2444, 0ULL, 2);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str33);
    }
    case TAG_SMatch: {
      heff_take_n(v_t_2444, 0ULL, 2);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str34);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_t_2444, 0ULL, 3);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str35);
    }
    case TAG_SIs: {
      heff_take_n(v_t_2444, 0ULL, 1);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str36);
    }
    case TAG_SOpaque: {
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str37);
    }
    case TAG_SAbandon: {
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str38);
    }
    case TAG_SRec: {
      heff_take_n(v_t_2444, 0ULL, 1);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str39);
    }
    case TAG_SFix: {
      heff_take_n(v_t_2444, 0ULL, 2);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str40);
    }
    case TAG_SImplicit: {
      heff_take_n(v_t_2444, 0ULL, 2);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str41);
    }
    case TAG_SPrim: {
      heff_take_n(v_t_2444, 0ULL, 1);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str42);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_t_2444, 0ULL, 3);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str43);
    }
    case TAG_SLitInt: {
      heff_take_n(v_t_2444, 0ULL, 1);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str44);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_t_2444, 0ULL, 1);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str45);
    }
    case TAG_SLitString: {
      heff_take_n(v_t_2444, 0ULL, 1);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str46);
    }
    case TAG_SLitRune: {
      heff_take_n(v_t_2444, 0ULL, 1);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str47);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_t_2444, 0ULL, 2);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str48);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_t_2444, 0ULL, 1);
      return ((V)&g_heff_2ebuild_2edriver_2edefKind_str49);
    }
    default: return heff_nomatch(v_t_2444);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2edriver_2edefKind_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2edefKind(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2elastChecked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2elastChecked_entry, 1, 0};

V g_heff_2ebuild_2edriver_2elastChecked(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_c_241)});
    }
    case TAG_Cons: {
      V t_0 = v_x12_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2elastChecked_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2elastChecked(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2eshowTySx_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eshowTySx_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eshowTySx_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eshowTySx(V v_g_240, V v_t_241) {
top: ;
  V v_t_242 = ({ V b_0 = heff_get_n(v_g_240, 2, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_m_243 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_242; V r_ = (g_list_2efoldl_24s407249128x802036125(a_0, a_1)); heff_drop(v_t_242); r_; });
  V v_t_248 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2ebuild_2edriver_2eshowTySx_lam0, 1, 1, (V[]){v_m_243})));
  V v_t_249 = heff_tr(heff_call(heff_get_n(v_t_248, 1, 2), 1, (V[]){v_t_241}));
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_249; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
}
V g_heff_2ebuild_2edriver_2eshowTySx_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eshowTySx(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2eshowTySx_lam0(V self, V *args) {
  V v_k_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_k_244)));
  V v_x2_246 = ({ V a_0 = v_k_244; V a_1 = v_m_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_243); r_; });
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nothing: {
    return v_d_245;
  }
  case TAG_Just: {
    V v_x_247 = heff_field(v_x2_246, 0);
    heff_take_n(v_x2_246, 1ULL, 1);
    heff_drop(v_d_245);
    return v_x_247;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ewatchExpect_str0, 2, "--");
HEFF_LIT(g_heff_2ebuild_2edriver_2ewatchExpect_str1, 6, "-- >>>");
HEFF_LIT(g_heff_2ebuild_2edriver_2ewatchExpect_str2, 4, "-- |");
HEFF_LIT(g_heff_2ebuild_2edriver_2ewatchExpect_str3, 0, "");
Clo g_heff_2ebuild_2edriver_2ewatchExpect_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewatchExpect_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ewatchExpect(V v_line_240) {
top: ;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_line_240), MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2ebuild_2edriver_2ewatchExpect_str0))) {
    V v_t_243;
    if (heff_strEq_c(heff_strSlice(heff_dup(v_line_240), MK_INT(0LL), MK_INT(6LL)), ((V)&g_heff_2ebuild_2edriver_2ewatchExpect_str1))) {
      v_t_243 = NTAG(TAG_False);
    } else {
      v_t_243 = NTAG(TAG_True);
    }
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      if (heff_strEq_c(heff_strSlice(heff_dup(v_line_240), MK_INT(0LL), MK_INT(4LL)), ((V)&g_heff_2ebuild_2edriver_2ewatchExpect_str2))) {
        heff_drop(v_line_240);
        return NTAG(TAG_Nothing);
      } else {
        V v_s_245 = heff_strSlice(heff_dup(v_line_240), MK_INT(2LL), heff_strLength(heff_dup(v_line_240)));
        V v_t_246 = (g_prelude_2eskipSpaces(heff_dup(v_s_245), MK_INT(0LL), MK_INT(1LL)));
        V v_t_247 = heff_intSub(heff_strLength(heff_dup(v_s_245)), MK_INT(1LL));
        V v_t_248 = (g_prelude_2eskipSpaces(heff_dup(v_s_245), v_t_247, MK_INT(-1LL)));
        V v_t_249 = heff_strSlice(v_s_245, v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
        if (heff_strEq_c(v_t_249, ((V)&g_heff_2ebuild_2edriver_2ewatchExpect_str3))) {
          heff_drop(v_line_240);
          return NTAG(TAG_Nothing);
        } else {
          V v_s_2411 = heff_strSlice(heff_dup(v_line_240), MK_INT(2LL), heff_strLength(v_line_240));
          V v_t_2412 = (g_prelude_2eskipSpaces(heff_dup(v_s_2411), MK_INT(0LL), MK_INT(1LL)));
          V v_t_2413 = heff_intSub(heff_strLength(heff_dup(v_s_2411)), MK_INT(1LL));
          V v_t_2414 = (g_prelude_2eskipSpaces(heff_dup(v_s_2411), v_t_2413, MK_INT(-1LL)));
          V v_t_2415 = heff_strSlice(v_s_2411, v_t_2412, heff_intAdd(v_t_2414, MK_INT(1LL)));
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2415});
        }
      }
    }
    case TAG_False: {
      heff_drop(v_line_240);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_243);
    }
  } else {
    heff_drop(v_line_240);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2edriver_2ewatchExpect_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ewatchExpect(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2edocExpect_str0, 4, "-- |");
HEFF_LIT(g_heff_2ebuild_2edriver_2edocExpect_str1, 8, "-- | >>>");
HEFF_LIT(g_heff_2ebuild_2edriver_2edocExpect_str2, 0, "");
Clo g_heff_2ebuild_2edriver_2edocExpect_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2edocExpect_entry, 1, 0};

V g_heff_2ebuild_2edriver_2edocExpect(V v_line_240) {
top: ;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_line_240), MK_INT(0LL), MK_INT(4LL)), ((V)&g_heff_2ebuild_2edriver_2edocExpect_str0))) {
    if (heff_strEq_c(heff_strSlice(heff_dup(v_line_240), MK_INT(0LL), MK_INT(8LL)), ((V)&g_heff_2ebuild_2edriver_2edocExpect_str1))) {
      heff_drop(v_line_240);
      return NTAG(TAG_Nothing);
    } else {
      V v_s_243 = heff_strSlice(heff_dup(v_line_240), MK_INT(4LL), heff_strLength(heff_dup(v_line_240)));
      V v_t_244 = (g_prelude_2eskipSpaces(heff_dup(v_s_243), MK_INT(0LL), MK_INT(1LL)));
      V v_t_245 = heff_intSub(heff_strLength(heff_dup(v_s_243)), MK_INT(1LL));
      V v_t_246 = (g_prelude_2eskipSpaces(heff_dup(v_s_243), v_t_245, MK_INT(-1LL)));
      V v_t_247 = heff_strSlice(v_s_243, v_t_244, heff_intAdd(v_t_246, MK_INT(1LL)));
      if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2edriver_2edocExpect_str2))) {
        heff_drop(v_line_240);
        return NTAG(TAG_Nothing);
      } else {
        V v_s_249 = heff_strSlice(heff_dup(v_line_240), MK_INT(4LL), heff_strLength(v_line_240));
        V v_t_2410 = (g_prelude_2eskipSpaces(heff_dup(v_s_249), MK_INT(0LL), MK_INT(1LL)));
        V v_t_2411 = heff_intSub(heff_strLength(heff_dup(v_s_249)), MK_INT(1LL));
        V v_t_2412 = (g_prelude_2eskipSpaces(heff_dup(v_s_249), v_t_2411, MK_INT(-1LL)));
        V v_t_2413 = heff_strSlice(v_s_249, v_t_2410, heff_intAdd(v_t_2412, MK_INT(1LL)));
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2413});
      }
    }
  } else {
    heff_drop(v_line_240);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2edriver_2edocExpect_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2edocExpect(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectLine_str0, 1, "\012");
Clo g_heff_2ebuild_2edriver_2eexpectLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eexpectLine_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eexpectLine(V v_doc_240, V v_src_241, V v_i_242) {
top: ;
  V v_t_243 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2edriver_2eexpectLine_str0), heff_dup(v_src_241), heff_dup(v_i_242)));
  V v_t_245;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    v_t_245 = heff_strLength(heff_dup(v_src_241));
    break;
  }
  case TAG_Just: {
    V v_j_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    v_t_245 = v_j_244;
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_s_246 = heff_strSlice(heff_dup(v_src_241), heff_dup(v_i_242), v_t_245);
  V v_t_247 = (g_prelude_2eskipSpaces(heff_dup(v_s_246), MK_INT(0LL), MK_INT(1LL)));
  V v_t_248 = heff_intSub(heff_strLength(heff_dup(v_s_246)), MK_INT(1LL));
  V v_t_249 = (g_prelude_2eskipSpaces(heff_dup(v_s_246), v_t_248, MK_INT(-1LL)));
  V v_line_2410 = heff_strSlice(v_s_246, v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
  if (heff_intLe_c(heff_strLength(v_src_241), v_i_242)) {
    heff_drop(v_line_2410);
    return NTAG(TAG_Nothing);
  } else {
    switch (heff_tag_of(v_doc_240)) {
    case TAG_True: {
      return (g_heff_2ebuild_2edriver_2edocExpect(v_line_2410));
    }
    case TAG_False: {
      return (g_heff_2ebuild_2edriver_2ewatchExpect(v_line_2410));
    }
    default: return heff_nomatch(v_doc_240);
    }
  }
}
V g_heff_2ebuild_2edriver_2eexpectLine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eexpectLine(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectGo_str0, 1, "\012");
Clo g_heff_2ebuild_2edriver_2eexpectGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eexpectGo_entry, 4, 0};

V g_heff_2ebuild_2edriver_2eexpectGo(V v_doc_240, V v_src_241, V v_i_242, V v_acc_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2edriver_2eexpectLine(v_doc_240, heff_dup(v_src_241), heff_dup(v_i_242)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_src_241);
    return heff_rec_n(2, shape_lines__stop, (V[]){v_acc_243, v_i_242});
  }
  case TAG_Just: {
    V v_l_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_a_246 = heff_strLength(heff_dup(v_src_241));
    V v_t_247 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2edriver_2eexpectGo_str0), heff_dup(v_src_241), v_i_242));
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_t_249 = heff_strLength(heff_dup(v_src_241));
      break;
    }
    case TAG_Just: {
      V v_j_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_249 = v_j_248;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_b_2410 = heff_intAdd(v_t_249, MK_INT(1LL));
    V v_t_2412;
    if (heff_intLe_c(heff_dup(v_a_246), heff_dup(v_b_2410))) {
      heff_drop(v_b_2410);
      v_t_2412 = v_a_246;
    } else {
      heff_drop(v_a_246);
      v_t_2412 = v_b_2410;
    }
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_l_245, NTAG(TAG_Nil)});
    V v_t_2414 = (g_prelude_2e_2b_2b(v_acc_243, v_t_2413));
    V t_0 = v_doc_240;
    V t_1 = v_src_241;
    V t_2 = v_t_2412;
    V t_3 = v_t_2414;
    v_doc_240 = t_0;
    v_src_241 = t_1;
    v_i_242 = t_2;
    v_acc_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ebuild_2edriver_2eexpectGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eexpectGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectAfter_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectAfter_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectAfter_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eexpectAfter_str3, 1, "\012");
Clo g_heff_2ebuild_2edriver_2eexpectAfter_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eexpectAfter_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eexpectAfter(V v_doc_240, V v_src_241, V v_end_242) {
top: ;
  V v_a_243 = heff_strLength(heff_dup(v_src_241));
  V v_t_244 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2edriver_2eexpectAfter_str0), heff_dup(v_src_241), heff_dup(v_end_242)));
  V v_t_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_t_246 = heff_strLength(heff_dup(v_src_241));
    break;
  }
  case TAG_Just: {
    V v_j_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_t_246 = v_j_245;
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_b_247 = heff_intAdd(v_t_246, MK_INT(1LL));
  V v_start_249;
  if (heff_intLe_c(heff_dup(v_a_243), heff_dup(v_b_247))) {
    heff_drop(v_b_247);
    v_start_249 = v_a_243;
  } else {
    heff_drop(v_a_243);
    v_start_249 = v_b_247;
  }
  V v_a_2410 = heff_strLength(heff_dup(v_src_241));
  V v_t_2411 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2edriver_2eexpectAfter_str1), heff_dup(v_src_241), v_end_242));
  V v_t_2413;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    v_t_2413 = heff_strLength(heff_dup(v_src_241));
    break;
  }
  case TAG_Just: {
    V v_j_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 1);
    v_t_2413 = v_j_2412;
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  V v_b_2414 = heff_intAdd(v_t_2413, MK_INT(1LL));
  V v_t_2416;
  if (heff_intLe_c(heff_dup(v_a_2410), heff_dup(v_b_2414))) {
    heff_drop(v_b_2414);
    v_t_2416 = v_a_2410;
  } else {
    heff_drop(v_a_2410);
    v_t_2416 = v_b_2414;
  }
  V v_r_2417 = (g_heff_2ebuild_2edriver_2eexpectGo(v_doc_240, v_src_241, v_t_2416, NTAG(TAG_Nil)));
  V v_t_2418 = heff_dup(heff_rfield(v_r_2417, 0));
  V v_t_2425;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_Nil: {
    v_t_2425 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_2418, 0ULL, 2);
    V v_t_2421 = heff_dup(heff_rfield(v_r_2417, 0));
    V v_t_2424;
    switch (heff_tag_of(v_t_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ebuild_2edriver_2eexpectAfter_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_t_2421, 0);
      V v_xs_2423 = heff_field(v_t_2421, 1);
      heff_take_n(v_t_2421, 3ULL, 2);
      v_t_2424 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2eexpectAfter_str3); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_t_2421);
    }
    v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2424});
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  return heff_rec_n(3, shape_expected__from__to, (V[]){v_t_2425, v_start_249, heff_get_n(v_r_2417, 1, 2)});
}
V g_heff_2ebuild_2edriver_2eexpectAfter_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eexpectAfter(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2etypeArgsOf_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2etypeArgsOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2etypeArgsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etypeArgsOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2etypeArgsOf(V v_lvl_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_LikeU: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeFunction: {
    V v_dom_244 = heff_field(v_x2_241, 1);
    V v_cod_245 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 4);
    V v_t_247 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(v_lvl_240), heff_dup(v_dom_244)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      V v_x1_2414;
      switch (heff_tag_of(v_cod_245)) {
      case TAG_MkClo: {
        V v_vs_249 = heff_field(v_cod_245, 1);
        V v_body_2410 = heff_field(v_cod_245, 2);
        heff_take_n(v_cod_245, 6ULL, 3);
        v_x1_2414 = heff_tr(heff_call(v_body_2410, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_249, heff_clo_n(g_heff_2ebuild_2edriver_2etypeArgsOf_lam0, 1, 2, (V[]){heff_dup(v_lvl_240), v_dom_244})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2413 = heff_field(v_cod_245, 0);
        heff_take_n(v_cod_245, 1ULL, 1);
        heff_drop(v_dom_244);
        v_x1_2414 = v_body_2413;
        break;
      }
      default: heff_nomatch(v_cod_245);
      }
      V v_t_2418;
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Nom: {
        V v_x_2415 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        v_t_2418 = v_x_2415;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2414, 0ULL, 1);
        v_t_2418 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2417 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        v_t_2418 = v_x_2417;
        break;
      }
      default: heff_nomatch(v_x1_2414);
      }
      V v_t_2419 = (g_heff_2eelab_2evalue_2ebehavior(v_t_2418));
      V v_t_2420 = (g_heff_2ebuild_2edriver_2etypeArgsOf(heff_intAdd(v_lvl_240, MK_INT(1LL)), v_t_2419));
      return heff_intAdd(MK_INT(1LL), v_t_2420);
    }
    case TAG_False: {
      heff_drop(v_lvl_240);
      heff_drop(v_dom_244);
      heff_drop(v_cod_245);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeSum: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeInt: {
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeFloat: {
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeString: {
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeRune: {
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeArray: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  case TAG_NoRules: {
    heff_drop(v_lvl_240);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2etypeArgsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etypeArgsOf(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2etypeArgsOf_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  V v_dom_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return v_dom_244;
}
V g_heff_2ebuild_2edriver_2etypeArgsOf_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_lvl_240 = heff_env(self)[0];
  V v_dom_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2411);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_lvl_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2ebuild_2edriver_2etypeArgsOf_lam1, 1, 1, (V[]){v_dom_244}), NTAG(TAG_Nothing)));
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalWatch_str0, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalWatch_str1, 10, "<diverged>");
Clo g_heff_2ebuild_2edriver_2eevalWatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eevalWatch_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eevalWatch(V v_ge_240, V v_entry_241) {
top: ;
  V v_x1_242 = heff_tr(g_heff_2ecompile_2einterp_2efixThunk(v_ge_240, heff_take_field(v_entry_241, 0), MK_INT(0LL)));
  V v_r_244;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Ok: {
    V v_v_243 = heff_field(v_x1_242, 0);
    V v_ru_24x1_242_24Ok = heff_take_reuse_n(v_x1_242, 1ULL, 1);
    v_r_244 = heff_tag_at_n(v_ru_24x1_242_24Ok, TAG_RSucceeded, 1, (V[]){v_v_243});
    break;
  }
  case TAG_Abn: {
    v_r_244 = NTAG(TAG_RAbandoned);
    break;
  }
  case TAG_Div: {
    v_r_244 = NTAG(TAG_RDiverged);
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  V v_t_245 = (g_heff_2eelab_2evalue_2ebehavior(heff_get_n(v_entry_241, 3, 4)));
  V v_t_246 = (g_heff_2ebuild_2edriver_2etypeArgsOf(MK_INT(0LL), v_t_245));
  V v_x1_247 = (g_heff_2ecompile_2einterp_2eapplyErased(v_t_246, v_r_244));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_RSucceeded: {
    V v_v_248 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 1);
    return ({ V b_0 = NTAG(TAG_False); V a_1 = v_v_248; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
  }
  case TAG_RAbandoned: {
    return ((V)&g_heff_2ebuild_2edriver_2eevalWatch_str0);
  }
  case TAG_RDiverged: {
    return ((V)&g_heff_2ebuild_2edriver_2eevalWatch_str1);
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2ebuild_2edriver_2eevalWatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eevalWatch(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2ereadExpRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ereadExpRead_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ereadExpRead(V v_ge_240, V v_g_241, V v_r_242) {
top: ;
  V v_t_243 = heff_take_field(v_r_242, 1);
  V v_x1_246;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    v_x1_246 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_243, 0ULL, 2);
    v_x1_246 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  switch (heff_tag_of(v_x1_246)) {
  case TAG_True: {
    V v_t_247 = heff_rec_n(9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, (V[]){v_g_241, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_248 = (g_list_2emap(heff_dup(g_heff_2esyntax_2epresyntax_2eclassify_get()), heff_get_n(v_r_242, 0, 4)));
    V v_t_249 = ({ V a_0 = v_t_247; V a_1 = v_t_248; V r_ = (g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(a_0, a_1)); heff_drop(v_t_248); r_; });
    V v_t_2410 = heff_take_field(v_t_249, 1);
    V v_x1_2413;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nil: {
      v_x1_2413 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_2410, 0ULL, 2);
      v_x1_2413 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_True: {
      V v_t_2414 = heff_get_n(v_t_249, 4, 9);
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nil: {
        heff_drop(v_ge_240);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_t_2414, 0);
        heff_take_n(v_t_2414, 1ULL, 2);
        return heff_tag_n(TAG_Just, 1, (V[]){(g_heff_2ebuild_2edriver_2eevalWatch(v_ge_240, heff_get_n(v_x_2415, 1, 2)))});
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    case TAG_False: {
      heff_drop(v_ge_240);
      heff_drop_rec(v_t_249, 9);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x1_2413);
    }
  }
  case TAG_False: {
    heff_drop(v_ge_240);
    heff_drop(v_g_241);
    heff_drop_rec(v_r_242, 4);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2ebuild_2edriver_2ereadExpRead_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ereadExpRead(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_str2, 3, "\012  ");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_str3, 8, "-- >>> (");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_str4, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_str5, 2, ")\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2ereadExpectation_str6, 0, "");
V g_heff_2ebuild_2edriver_2ereadExpectation_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ereadExpectation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ereadExpectation_entry, 4, 0};

V g_heff_2ebuild_2edriver_2ereadExpectation(V v_ge_240, V v_g_241, V v_ty_242, V v_e_243) {
top: ;
  V v_x2_244 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2edriver_2ereadExpectation_str0), v_e_243, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_src_248 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2ereadExpectation_str3), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2edriver_2ereadExpectation_str4), heff_strAppend(v_ty_242, ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_str5)))));
  V v_t_2412 = heff_rec_n(4, shape_known__fixities__lenient__place, (V[]){heff_clo_n(g_heff_2ebuild_2edriver_2ereadExpectation_lam0, 1, 1, (V[]){heff_dup(v_g_241)}), heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get()), NTAG(TAG_False), ((V)&g_heff_2ebuild_2edriver_2ereadExpectation_str6)});
  V v_t_2413 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  V v_t_2414 = (g_heff_2esyntax_2efmt_2elex_2elexGo(heff_dup(v_src_248), v_t_2413, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_2415 = (g_heff_2esyntax_2esurface_2ereadLexed(v_src_248, v_t_2412, v_t_2414));
  return (g_heff_2ebuild_2edriver_2ereadExpRead(v_ge_240, v_g_241, v_t_2415));
}
V g_heff_2ebuild_2edriver_2ereadExpectation_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ereadExpectation(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edriver_2ereadExpectation_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = (g_heff_2eelab_2eglobals_2elookupName(v_g_241, v_x_249));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_t_2410, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_t_2410);
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str0, 6, "-- >>>");
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str1, 8, "-- | >>>");
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2emkWatchInfo_str3, 8, "-- | >>>");
Clo g_heff_2ebuild_2edriver_2emkWatchInfo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2emkWatchInfo_entry, 6, 0};

V g_heff_2ebuild_2edriver_2emkWatchInfo(V v_c_240, V v_ge_241, V v_w_242, V v_value_243, V v_ex_244, V v_ty_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_w_242, 0)), 0, 2);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_w_242, 0)), 1, 2);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_w_242, 0)), 0, 2);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_w_242, 0)), 1, 2);
  V v_s_2410 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_248, v_t_249);
  V v_t_2411 = (g_prelude_2eskipSpaces(heff_dup(v_s_2410), MK_INT(0LL), MK_INT(1LL)));
  V v_t_2412 = heff_intSub(heff_strLength(heff_dup(v_s_2410)), MK_INT(1LL));
  V v_t_2413 = (g_prelude_2eskipSpaces(heff_dup(v_s_2410), v_t_2412, MK_INT(-1LL)));
  V v_s_2414 = heff_strSlice(v_s_2410, v_t_2411, heff_intAdd(v_t_2413, MK_INT(1LL)));
  V v_s_2417;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_s_2414), MK_INT(0LL), MK_INT(6LL)), ((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str0))) {
    v_s_2417 = heff_strSlice(heff_dup(v_s_2414), MK_INT(6LL), heff_strLength(v_s_2414));
  } else {
    if (heff_strEq_c(heff_strSlice(heff_dup(v_s_2414), MK_INT(0LL), MK_INT(8LL)), ((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str1))) {
      v_s_2417 = heff_strSlice(heff_dup(v_s_2414), MK_INT(8LL), heff_strLength(v_s_2414));
    } else {
      heff_drop(v_s_2414);
      v_s_2417 = ((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str2);
    }
  }
  V v_t_2418 = (g_prelude_2eskipSpaces(heff_dup(v_s_2417), MK_INT(0LL), MK_INT(1LL)));
  V v_t_2419 = heff_intSub(heff_strLength(heff_dup(v_s_2417)), MK_INT(1LL));
  V v_t_2420 = (g_prelude_2eskipSpaces(heff_dup(v_s_2417), v_t_2419, MK_INT(-1LL)));
  V v_t_2421 = heff_strSlice(v_s_2417, v_t_2418, heff_intAdd(v_t_2420, MK_INT(1LL)));
  V v_t_2422 = heff_dup(heff_rfield(v_ex_244, 0));
  V v_t_2428;
  switch (heff_tag_of(v_t_2422)) {
  case TAG_Nothing: {
    heff_drop(v_ge_241);
    v_t_2428 = NTAG(TAG_True);
    break;
  }
  case TAG_Just: {
    V v_e_2423 = heff_field(v_t_2422, 0);
    heff_take_n(v_t_2422, 1ULL, 1);
    if (heff_strEq_c(heff_dup(v_e_2423), heff_dup(v_value_243))) {
      heff_drop(v_ge_241);
      heff_drop(v_e_2423);
      v_t_2428 = NTAG(TAG_True);
    } else {
      V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
      V v_t_2426 = (g_heff_2ebuild_2edriver_2ereadExpectation(v_ge_241, v_t_2425, heff_dup(v_ty_245), v_e_2423));
      switch (heff_tag_of(v_t_2426)) {
      case TAG_Nothing: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        V v_v_2427 = heff_field(v_t_2426, 0);
        heff_take_n(v_t_2426, 1ULL, 1);
        v_t_2428 = heff_strEq(v_v_2427, heff_dup(v_value_243));
        break;
      }
      default: heff_nomatch(v_t_2426);
      }
    }
    break;
  }
  default: heff_nomatch(v_t_2422);
  }
  V v_start_2429 = heff_get_n(heff_get_n(v_w_242, 0, 2), 0, 2);
  V v_t_2430 = heff_strSlice(heff_get_n(v_c_240, 3, 13), heff_dup(v_start_2429), heff_intAdd(v_start_2429, MK_INT(8LL)));
  return heff_rec_n(10, shape_from__to__expr__ty__value__expected__holds__expectFrom__expectTo__doc, (V[]){v_t_246, v_t_247, v_t_2421, v_ty_245, v_value_243, heff_dup(heff_rfield(v_ex_244, 0)), v_t_2428, heff_dup(heff_rfield(v_ex_244, 1)), heff_get_n(v_ex_244, 2, 3), heff_strEq(v_t_2430, ((V)&g_heff_2ebuild_2edriver_2emkWatchInfo_str3))});
}
V g_heff_2ebuild_2edriver_2emkWatchInfo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2emkWatchInfo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2ewatchInfo_str0, 8, "-- | >>>");
Clo g_heff_2ebuild_2edriver_2ewatchInfo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewatchInfo_entry, 3, 0};

V g_heff_2ebuild_2edriver_2ewatchInfo(V v_c_240, V v_ge_241, V v_w_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2edriver_2eevalWatch(heff_dup(v_ge_241), heff_dup(heff_rfield(v_w_242, 1))));
  V v_src_244 = heff_dup(heff_rfield(v_c_240, 3));
  V v_sp_245 = heff_dup(heff_rfield(v_w_242, 0));
  V v_start_246 = heff_take_field(v_sp_245, 0);
  V v_t_247 = heff_strSlice(heff_dup(v_src_244), heff_dup(v_start_246), heff_intAdd(v_start_246, MK_INT(8LL)));
  V v_t_248 = ({ V b_0 = heff_strEq(v_t_247, ((V)&g_heff_2ebuild_2edriver_2ewatchInfo_str0)); V a_1 = v_src_244; V a_2 = heff_get_n(v_sp_245, 1, 2); V r_ = (g_heff_2ebuild_2edriver_2eexpectAfter(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_w_242, 1)), 3, 4);
  V v_t_2411 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), v_t_2410));
  V v_t_2412 = (g_heff_2ebuild_2edriver_2eshowTySx(v_t_249, v_t_2411));
  return (g_heff_2ebuild_2edriver_2emkWatchInfo(v_c_240, v_ge_241, v_w_242, v_t_243, v_t_248, v_t_2412));
}
V g_heff_2ebuild_2edriver_2ewatchInfo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ewatchInfo(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edriver_2ewatchesOf_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2ewatchesOf_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2ewatchesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ewatchesOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2ewatchesOf(V v_c_240, V v_ws_241) {
top: ;
  switch (heff_tag_of(v_ws_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 13);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_gs_244 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
    V v_t_249 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2ewatchesOf_lam0, 2, 1, (V[]){heff_dup(v_gs_244)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get_n(v_gs_244, 0, 7); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_ge_2410 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2einterp_2eglobalEnvGo(a_0, a_1)); heff_drop(v_t_249); r_; });
    HEFF_LAST return g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2ewatchesOf_lam1, 1, 2, (V[]){v_c_240, v_ge_2410}), v_ws_241);
  }
  default: return heff_nomatch(v_ws_241);
  }
}
V g_heff_2ebuild_2edriver_2ewatchesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2ewatchesOf(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2ewatchesOf_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_k_246 = args[1];
  V v_gs_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = ({ V a_0 = heff_dup(v_k_246); V b_1 = heff_get_n(v_gs_244, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_k_246);
    return v_acc_245;
  }
  case TAG_Just: {
    V v_e_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_246, v_e_248}), v_acc_245});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ebuild_2edriver_2ewatchesOf_lam1(V self, V *args) {
  V v_w_2411 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_ge_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2edriver_2ewatchInfo(v_c_240, v_ge_2410, v_w_2411));
}
V g_heff_2ebuild_2edriver_2etestOwner_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2etestOwner_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2etestOwner_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etestOwner_entry, 2, 0};

V g_heff_2ebuild_2edriver_2etestOwner(V v_c_240, V v_from_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 5, 9);
  V v_xs_2412 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2etestOwner_lam0, 1, 2, (V[]){v_from_241, v_c_240}), v_t_242));
  V v_x1_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2412));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x1_2413, 0);
    heff_take_n(v_x1_2413, 1ULL, 2);
    return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_2414, 0, 2)});
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
V g_heff_2ebuild_2edriver_2etestOwner_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etestOwner(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2etestOwner_lam1(V self, V *args) {
  V v_p_248 = args[0];
  V v_m_243 = heff_env(self)[0];
  V v_from_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_get_n(heff_get_n(v_m_243, 1, 2), 0, 2);
  if (heff_intLt_c(v_t_249, heff_dup(v_p_248))) {
    return heff_intLt(v_p_248, v_from_241);
  } else {
    heff_drop(v_p_248);
    heff_drop(v_from_241);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2edriver_2etestOwner_lam0(V self, V *args) {
  V v_m_243 = args[0];
  V v_from_241 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_m_243, 1)), 0, 2);
  if (heff_intLt_c(v_t_244, heff_dup(v_from_241))) {
    V v_t_246 = heff_get_n(heff_get_n(v_c_240, 5, 13), 6, 9);
    V v_t_247 = (g_list_2emap_24s944722006x358970142(v_t_246));
    V v_x1_2411 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2etestOwner_lam1, 1, 2, (V[]){v_m_243, v_from_241}); V a_1 = v_t_247; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_247); r_; });
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_2411);
    }
  } else {
    heff_drop_rec(v_m_243, 2);
    heff_drop(v_from_241);
    heff_drop_rec(v_c_240, 13);
    return NTAG(TAG_False);
  }
}
Clo g_heff_2ebuild_2edriver_2edefUnder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2edefUnder_entry, 3, 0};

V g_heff_2ebuild_2edriver_2edefUnder(V v_to_240, V v_x2_241, V v_b_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_t_245;
    switch (heff_tag_of(v_b_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_dup(heff_field(v_b_242, 1));
      v_t_245 = v_y_244;
      break;
    }
    default: heff_nomatch(v_b_242);
    }
    V v_a_246 = heff_get_n(v_t_245, 0, 2);
    if (heff_intLe_c(v_to_240, v_a_246)) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_b_242});
    } else {
      heff_drop(v_b_242);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_Just: {
    V v_a_248 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2411;
    switch (heff_tag_of(v_b_242)) {
    case TAG_MkPair: {
      V v_y_2410 = heff_dup(heff_field(v_b_242, 1));
      v_t_2411 = v_y_2410;
      break;
    }
    default: heff_nomatch(v_b_242);
    }
    V v_a_2412 = heff_get_n(v_t_2411, 0, 2);
    if (heff_intLe_c(v_to_240, v_a_2412)) {
      V v_t_2416;
      switch (heff_tag_of(v_b_242)) {
      case TAG_MkPair: {
        V v_y_2415 = heff_dup(heff_field(v_b_242, 1));
        v_t_2416 = v_y_2415;
        break;
      }
      default: heff_nomatch(v_b_242);
      }
      V v_t_2419;
      switch (heff_tag_of(v_a_248)) {
      case TAG_MkPair: {
        V v_y_2418 = heff_dup(heff_field(v_a_248, 1));
        v_t_2419 = v_y_2418;
        break;
      }
      default: heff_nomatch(v_a_248);
      }
      if (heff_intLt_c(heff_get_n(v_t_2416, 0, 2), heff_get_n(v_t_2419, 0, 2))) {
        heff_drop(v_a_248);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_b_242});
      } else {
        heff_drop(v_b_242);
        return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_a_248});
      }
    } else {
      heff_drop(v_b_242);
      return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_a_248});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edriver_2edefUnder_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2edefUnder(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eownerOf_str0, 1, "(");
HEFF_LIT(g_heff_2ebuild_2edriver_2eownerOf_str1, 1, ")");
Clo g_heff_2ebuild_2edriver_2eownerOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eownerOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eownerOf(V v_c_240, V v_w_241) {
top: ;
  V v_t_242 = heff_take_field(v_w_241, 9);
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = heff_tr(heff_call(((V)&g_heff_2ebuild_2edriver_2edefUnder_clo), 1, (V[]){heff_get_n(v_w_241, 1, 10)}));
    V v_t_244 = heff_get_n(heff_get_n(v_c_240, 5, 13), 6, 9);
    V v_t_245 = ({ V a_0 = v_t_243; V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_p_246 = heff_field(v_t_245, 0);
      V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
      V v_x_249;
      switch (heff_tag_of(v_p_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_p_246, 0);
        heff_take_n(v_p_246, 1ULL, 2);
        v_x_249 = v_x_247;
        break;
      }
      default: heff_nomatch(v_p_246);
      }
      V v_t_2410 = (g_heff_2esyntax_2epsurface_2eisOperator(heff_dup(v_x_249)));
      V v_t_2411;
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eownerOf_str0), heff_strAppend(v_x_249, ((V)&g_heff_2ebuild_2edriver_2eownerOf_str1)));
        break;
      }
      case TAG_False: {
        v_t_2411 = v_x_249;
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
      return heff_tag_at_n(v_ru_24t_245_24Just, TAG_Just, 1, (V[]){v_t_2411});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_False: {
    HEFF_LAST return g_heff_2ebuild_2edriver_2etestOwner(v_c_240, heff_get_n(v_w_241, 0, 10));
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ebuild_2edriver_2eownerOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eownerOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2etestReportOf_str0, 1, "\012");
Clo g_heff_2ebuild_2edriver_2etestReportOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2etestReportOf_entry, 2, 0};

V g_heff_2ebuild_2edriver_2etestReportOf(V v_c_240, V v_w_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_w_241, 5));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_c_240, 13);
    heff_drop_rec(v_w_241, 10);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 0ULL, 1);
    V v_t_244 = (g_heff_2ebuild_2edriver_2eownerOf(heff_dup(v_c_240), heff_dup(v_w_241)));
    V v_src_245 = heff_get_n(v_c_240, 3, 13);
    V v_t_246 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2edriver_2etestReportOf_str0), heff_dup(v_src_245), MK_INT(0LL)));
    V v_t_247 = (g_heff_2elsp_2erender_2elineColAt(v_src_245, heff_dup(heff_rfield(v_w_241, 0)), MK_INT(0LL), MK_INT(0LL), v_t_246));
    V v_t_248 = heff_intAdd(heff_get_n(v_t_247, 0, 3), MK_INT(1LL));
    return heff_tag_at_n(v_ru_24t_242_24Just, TAG_Just, 1, (V[]){heff_rec_n(3, shape_owner__line__watch, (V[]){v_t_244, v_t_248, v_w_241})});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ebuild_2edriver_2etestReportOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2etestReportOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eshownGlobal_str0, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eshownGlobal_str1, 10, "<diverged>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eshownGlobal_str2, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eshownGlobal_str3, 10, "<diverged>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eshownGlobal_str4, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eshownGlobal_str5, 10, "<diverged>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eshownGlobal_str6, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eshownGlobal_str7, 10, "<diverged>");
Clo g_heff_2ebuild_2edriver_2eshownGlobal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eshownGlobal_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eshownGlobal(V v_g_240, V v_k_241, V v_r_242) {
top: ;
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_241), heff_rfield(v_g_240, 1)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(v_k_241, heff_rfield(v_g_240, 2)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_g_240, 7);
      switch (heff_tag_of(v_r_242)) {
      case TAG_RSucceeded: {
        V v_v_245 = heff_field(v_r_242, 0);
        heff_take_n(v_r_242, 1ULL, 1);
        return ({ V b_0 = NTAG(TAG_False); V a_1 = v_v_245; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
      }
      case TAG_RAbandoned: {
        return ((V)&g_heff_2ebuild_2edriver_2eshownGlobal_str0);
      }
      case TAG_RDiverged: {
        return ((V)&g_heff_2ebuild_2edriver_2eshownGlobal_str1);
      }
      default: return heff_nomatch(v_r_242);
      }
    }
    case TAG_Just: {
      V v_k2_246 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_t_247 = ({ V a_0 = v_k2_246; V b_1 = heff_get_n(v_g_240, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_r_242)) {
        case TAG_RSucceeded: {
          V v_v_248 = heff_field(v_r_242, 0);
          heff_take_n(v_r_242, 1ULL, 1);
          return ({ V b_0 = NTAG(TAG_False); V a_1 = v_v_248; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
        }
        case TAG_RAbandoned: {
          return ((V)&g_heff_2ebuild_2edriver_2eshownGlobal_str2);
        }
        case TAG_RDiverged: {
          return ((V)&g_heff_2ebuild_2edriver_2eshownGlobal_str3);
        }
        default: return heff_nomatch(v_r_242);
        }
      }
      case TAG_Just: {
        V v_e_249 = heff_field(v_t_247, 0);
        heff_take_n(v_t_247, 1ULL, 1);
        V v_t_2410 = (g_heff_2eelab_2evalue_2ebehavior(heff_get_n(v_e_249, 3, 4)));
        V v_t_2411 = (g_heff_2ebuild_2edriver_2etypeArgsOf(MK_INT(0LL), v_t_2410));
        V v_x1_2412 = (g_heff_2ecompile_2einterp_2eapplyErased(v_t_2411, v_r_242));
        switch (heff_tag_of(v_x1_2412)) {
        case TAG_RSucceeded: {
          V v_v_2413 = heff_field(v_x1_2412, 0);
          heff_take_n(v_x1_2412, 1ULL, 1);
          return ({ V b_0 = NTAG(TAG_False); V a_1 = v_v_2413; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
        }
        case TAG_RAbandoned: {
          return ((V)&g_heff_2ebuild_2edriver_2eshownGlobal_str4);
        }
        case TAG_RDiverged: {
          return ((V)&g_heff_2ebuild_2edriver_2eshownGlobal_str5);
        }
        default: return heff_nomatch(v_x1_2412);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_e_2414 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop_rec(v_g_240, 7);
    heff_drop(v_k_241);
    V v_t_2415 = (g_heff_2eelab_2evalue_2ebehavior(heff_get_n(v_e_2414, 3, 4)));
    V v_t_2416 = (g_heff_2ebuild_2edriver_2etypeArgsOf(MK_INT(0LL), v_t_2415));
    V v_x1_2417 = (g_heff_2ecompile_2einterp_2eapplyErased(v_t_2416, v_r_242));
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_RSucceeded: {
      V v_v_2418 = heff_field(v_x1_2417, 0);
      heff_take_n(v_x1_2417, 1ULL, 1);
      return ({ V b_0 = NTAG(TAG_False); V a_1 = v_v_2418; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    }
    case TAG_RAbandoned: {
      return ((V)&g_heff_2ebuild_2edriver_2eshownGlobal_str6);
    }
    case TAG_RDiverged: {
      return ((V)&g_heff_2ebuild_2edriver_2eshownGlobal_str7);
    }
    default: return heff_nomatch(v_x1_2417);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2edriver_2eshownGlobal_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eshownGlobal(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalPick_str0, 1, "(");
HEFF_LIT(g_heff_2ebuild_2edriver_2eevalPick_str1, 1, ")");
Clo g_heff_2ebuild_2edriver_2eevalPick_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eevalPick_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eevalPick(V v_g_240, V v_results_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_list_2elookupBy(heff_dup(g_strEq_get()), heff_dup(heff_rfield(v_o_243, 1)), v_results_241));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      heff_drop_rec(v_o_243, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_g_240;
      V t_1 = v_results_241;
      V t_2 = v_rest_244;
      v_g_240 = t_0;
      v_results_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      V v_r_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V v_x_247 = heff_take_field(v_o_243, 0);
      V v_t_248 = (g_heff_2esyntax_2epsurface_2eisOperator(heff_dup(v_x_247)));
      V v_t_249;
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eevalPick_str0), heff_strAppend(v_x_247, ((V)&g_heff_2ebuild_2edriver_2eevalPick_str1)));
        break;
      }
      case TAG_False: {
        v_t_249 = v_x_247;
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      V v_t_2410 = (g_heff_2ebuild_2edriver_2eshownGlobal(heff_dup(v_g_240), heff_get_n(v_o_243, 1, 2), v_r_246));
      return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__value, (V[]){v_t_249, v_t_2410}), (g_heff_2ebuild_2edriver_2eevalPick(v_g_240, v_results_241, v_rest_244))});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2eevalPick_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2eevalPick(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2eevaluate_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2eevaluate_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2eevaluate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eevaluate_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eevaluate(V v_c_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_gs_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_247 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2eevaluate_lam0, 2, 1, (V[]){heff_dup(v_gs_242)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get_n(v_gs_242, 0, 7); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2411 = (g_heff_2ecompile_2einterp_2eevalGlobalsGo(heff_clo_n(g_heff_2ebuild_2edriver_2eevaluate_lam1, 1, 1, (V[]){heff_dup(v_c_240)}), heff_dup(g_map_2eempty_get()), v_t_247, NTAG(TAG_Nil)));
  return ({ V a_0 = v_t_241; V a_1 = v_t_2411; V a_2 = heff_get_n(v_c_240, 7, 13); V r_ = (g_heff_2ebuild_2edriver_2eevalPick(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
}
V g_heff_2ebuild_2edriver_2eevaluate_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eevaluate(a[0]);
}
V g_heff_2ebuild_2edriver_2eevaluate_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_k_244 = args[1];
  V v_gs_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = ({ V a_0 = heff_dup(v_k_244); V b_1 = heff_get_n(v_gs_242, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_k_244);
    return v_acc_243;
  }
  case TAG_Just: {
    V v_e_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_244, v_e_246}), v_acc_243});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ebuild_2edriver_2eevaluate_lam1(V self, V *args) {
  V v_k_248 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_249 = (g_list_2emap_24s634984521x2042558081(heff_get_n(v_c_240, 7, 13)));
  V v_t_2410 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_k_248}));
  return ({ V a_0 = v_t_2410; V a_1 = v_xs_249; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_249); r_; });
}
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2epromoteAt_str7, 0, "");
Clo g_heff_2ebuild_2edriver_2epromoteAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2epromoteAt_entry, 4, 0};

V g_heff_2ebuild_2edriver_2epromoteAt(V v_s_240, V v_from_241, V v_to_242, V v_lines_243) {
top: ;
  V v_t_247;
  if (heff_strEq_c(heff_strSlice(heff_dup(v_s_240), MK_INT(0LL), heff_dup(v_from_241)), ((V)&g_heff_2ebuild_2edriver_2epromoteAt_str0))) {
    v_t_247 = ((V)&g_heff_2ebuild_2edriver_2epromoteAt_str1);
  } else {
    V v_t_245 = heff_strSlice(heff_dup(v_s_240), heff_intSub(heff_dup(v_from_241), MK_INT(1LL)), heff_dup(v_from_241));
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2edriver_2epromoteAt_str2))) {
      v_t_247 = ((V)&g_heff_2ebuild_2edriver_2epromoteAt_str3);
    } else {
      v_t_247 = ((V)&g_heff_2ebuild_2edriver_2epromoteAt_str4);
    }
  }
  V v_x2_248 = (g_list_2emap_24s374365348x2042978339(((V)&g_heff_2ebuild_2edriver_2epromoteAt_str5), v_lines_243));
  V v_t_2411;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2epromoteAt_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    heff_take_n(v_x2_248, 3ULL, 2);
    v_t_2411 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2epromoteAt_str7); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  V v_t_2412 = heff_strSlice(heff_dup(v_s_240), v_to_242, heff_strLength(heff_dup(v_s_240)));
  return heff_strAppend(heff_strSlice(v_s_240, MK_INT(0LL), v_from_241), heff_strAppend(v_t_247, heff_strAppend(v_t_2411, v_t_2412)));
}
V g_heff_2ebuild_2edriver_2epromoteAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2epromoteAt(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eisTestEl_str0, 10, "check.Test");
Clo g_heff_2ebuild_2edriver_2eisTestEl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eisTestEl_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eisTestEl(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    V v_k_242 = heff_field(v_x1_240, 0);
    return heff_strEq(heff_dup(v_k_242), ((V)&g_heff_2ebuild_2edriver_2eisTestEl_str0));
  }
  case TAG_SCode: {
    return NTAG(TAG_False);
  }
  case TAG_SApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    return NTAG(TAG_False);
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eisTestEl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eisTestEl(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2edriver_2eisTestOwn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eisTestOwn_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eisTestOwn(V v_c_240, V v_o_241) {
top: ;
  V v_g_242 = heff_get_n(heff_get_n(v_c_240, 5, 13), 0, 9);
  V v_k_243 = heff_get_n(v_o_241, 1, 2);
  V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_243), heff_rfield(v_g_242, 1)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_map_2elookup_24s1546226666x2146984184(v_k_243, heff_rfield(v_g_242, 2)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      heff_drop_rec(v_g_242, 7);
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_k2_246 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V v_t_247 = ({ V a_0 = v_k2_246; V b_1 = heff_get_n(v_g_242, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_e_248 = heff_field(v_t_247, 0);
        heff_take_n(v_t_247, 1ULL, 1);
        V v_t_249 = heff_get_n(v_e_248, 1, 4);
        switch (heff_tag_of(v_t_249)) {
        case TAG_SU: {
          heff_take_n(v_t_249, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_SDecode: {
          V v_t_2411 = heff_field(v_t_249, 0);
          heff_take_n(v_t_249, 1ULL, 1);
          return ({ V a_0 = v_t_2411; V r_ = (g_heff_2ebuild_2edriver_2eisTestEl(a_0)); heff_drop(v_t_2411); r_; });
        }
        case TAG_SFunction: {
          heff_take_n(v_t_249, 0ULL, 5);
          return NTAG(TAG_False);
        }
        case TAG_SRecord: {
          heff_take_n(v_t_249, 0ULL, 3);
          return NTAG(TAG_False);
        }
        case TAG_SSum: {
          heff_take_n(v_t_249, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_SIsTy: {
          heff_take_n(v_t_249, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_SPrimInt: {
          return NTAG(TAG_False);
        }
        case TAG_SPrimFloat: {
          return NTAG(TAG_False);
        }
        case TAG_SPrimString: {
          return NTAG(TAG_False);
        }
        case TAG_SPrimRune: {
          return NTAG(TAG_False);
        }
        case TAG_SPrimArray: {
          heff_take_n(v_t_249, 0ULL, 1);
          return NTAG(TAG_False);
        }
        case TAG_SFixed: {
          heff_take_n(v_t_249, 0ULL, 1);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_Just: {
    V v_e_2424 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop_rec(v_g_242, 7);
    heff_drop(v_k_243);
    V v_t_2425 = heff_get_n(v_e_2424, 1, 4);
    switch (heff_tag_of(v_t_2425)) {
    case TAG_SU: {
      heff_take_n(v_t_2425, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_SDecode: {
      V v_t_2427 = heff_field(v_t_2425, 0);
      heff_take_n(v_t_2425, 1ULL, 1);
      return ({ V a_0 = v_t_2427; V r_ = (g_heff_2ebuild_2edriver_2eisTestEl(a_0)); heff_drop(v_t_2427); r_; });
    }
    case TAG_SFunction: {
      heff_take_n(v_t_2425, 0ULL, 5);
      return NTAG(TAG_False);
    }
    case TAG_SRecord: {
      heff_take_n(v_t_2425, 0ULL, 3);
      return NTAG(TAG_False);
    }
    case TAG_SSum: {
      heff_take_n(v_t_2425, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_SIsTy: {
      heff_take_n(v_t_2425, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_False);
    }
    case TAG_SPrimArray: {
      heff_take_n(v_t_2425, 0ULL, 1);
      return NTAG(TAG_False);
    }
    case TAG_SFixed: {
      heff_take_n(v_t_2425, 0ULL, 1);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ebuild_2edriver_2eisTestOwn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eisTestOwn(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2efieldV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efieldV_entry, 2, 0};

V g_heff_2ebuild_2edriver_2efieldV(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_VFun: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  case TAG_VCons: {
    V v_fs_243 = heff_field(v_x1_240, 0);
    V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(v_x_241, heff_rfield(v_fs_243, 1)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      return NTAG(TAG_VErased);
    }
    case TAG_Just: {
      V v_i_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_xs_246 = heff_dup(heff_rfield(v_fs_243, 2));
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_245))) {
        if (heff_intLt_c(heff_dup(v_i_245), heff_arrayLength(heff_dup(v_xs_246)))) {
          V v_v_249 = heff_arrayIndex(v_xs_246, v_i_245);
          return v_v_249;
        } else {
          heff_drop(v_i_245);
          heff_drop(v_xs_246);
          return NTAG(TAG_VErased);
        }
      } else {
        heff_drop(v_i_245);
        heff_drop(v_xs_246);
        return NTAG(TAG_VErased);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_VTag: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  case TAG_VInt: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  case TAG_VFloat: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  case TAG_VFloat32: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  case TAG_VStr: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  case TAG_VRune: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  case TAG_VArr: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  case TAG_VErased: {
    heff_drop(v_x_241);
    return NTAG(TAG_VErased);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2efieldV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2efieldV(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elistOfV_str9, 4, "Cons");
Clo g_heff_2ebuild_2edriver_2elistOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2elistOfV_entry, 1, 0};

V g_heff_2ebuild_2edriver_2elistOfV(V v_v_240) {
top: ;
  V v_t_2411;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str0);
    break;
  }
  case TAG_VCons: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str1);
    break;
  }
  case TAG_VTag: {
    V v_x_243 = heff_dup(heff_field(v_v_240, 0));
    v_t_2411 = v_x_243;
    break;
  }
  case TAG_VInt: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str2);
    break;
  }
  case TAG_VFloat: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str3);
    break;
  }
  case TAG_VFloat32: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str4);
    break;
  }
  case TAG_VStr: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str5);
    break;
  }
  case TAG_VRune: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str6);
    break;
  }
  case TAG_VArr: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str7);
    break;
  }
  case TAG_VErased: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2elistOfV_str8);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2edriver_2elistOfV_str9))) {
    V v_t_2423;
    switch (heff_tag_of(v_v_240)) {
    case TAG_VFun: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2416 = heff_dup(heff_field(v_v_240, 1));
      v_t_2423 = v_vs_2416;
      break;
    }
    case TAG_VInt: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_240);
    }
    V v_x1_2424 = (g_list_2edrop(MK_INT(0LL), v_t_2423));
    V v_x2_2427;
    switch (heff_tag_of(v_x1_2424)) {
    case TAG_Nil: {
      v_x2_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_x1_2424, 0);
      heff_take_n(v_x1_2424, 1ULL, 2);
      v_x2_2427 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2425});
      break;
    }
    default: heff_nomatch(v_x1_2424);
    }
    V v_t_2429;
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nothing: {
      v_t_2429 = NTAG(TAG_VErased);
      break;
    }
    case TAG_Just: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      heff_take_n(v_x2_2427, 1ULL, 1);
      v_t_2429 = v_x_2428;
      break;
    }
    default: heff_nomatch(v_x2_2427);
    }
    V v_t_2440;
    switch (heff_tag_of(v_v_240)) {
    case TAG_VFun: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2433 = heff_field(v_v_240, 1);
      heff_take_n(v_v_240, 2ULL, 2);
      v_t_2440 = v_vs_2433;
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_v_240, 0ULL, 1);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_240);
    }
    V v_x1_2441 = (g_list_2edrop(MK_INT(1LL), v_t_2440));
    V v_x2_2444;
    switch (heff_tag_of(v_x1_2441)) {
    case TAG_Nil: {
      v_x2_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2442 = heff_field(v_x1_2441, 0);
      heff_take_n(v_x1_2441, 1ULL, 2);
      v_x2_2444 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2442});
      break;
    }
    default: heff_nomatch(v_x1_2441);
    }
    V v_t_2446;
    switch (heff_tag_of(v_x2_2444)) {
    case TAG_Nothing: {
      v_t_2446 = NTAG(TAG_VErased);
      break;
    }
    case TAG_Just: {
      V v_x_2445 = heff_field(v_x2_2444, 0);
      heff_take_n(v_x2_2444, 1ULL, 1);
      v_t_2446 = v_x_2445;
      break;
    }
    default: heff_nomatch(v_x2_2444);
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, (g_heff_2ebuild_2edriver_2elistOfV(v_t_2446))});
  } else {
    heff_drop(v_v_240);
    return NTAG(TAG_Nil);
  }
}
V g_heff_2ebuild_2edriver_2elistOfV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2elistOfV(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2elabelOfV_str8, 0, "");
Clo g_heff_2ebuild_2edriver_2elabelOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2elabelOfV_entry, 1, 0};

V g_heff_2ebuild_2edriver_2elabelOfV(V v_v_240) {
top: ;
  V v_t_2411;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2411 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VCons: {
    v_t_2411 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VTag: {
    V v_vs_244 = heff_field(v_v_240, 1);
    v_t_2411 = heff_dup(v_vs_244);
    break;
  }
  case TAG_VInt: {
    v_t_2411 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat: {
    v_t_2411 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat32: {
    v_t_2411 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VStr: {
    v_t_2411 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VRune: {
    v_t_2411 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VArr: {
    v_t_2411 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VErased: {
    v_t_2411 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  V v_x1_2412 = (g_list_2edrop(MK_INT(0LL), v_t_2411));
  V v_x2_2415;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nil: {
    v_x2_2415 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 2);
    v_x2_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2413});
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  V v_x1_2417;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nothing: {
    v_x1_2417 = NTAG(TAG_VErased);
    break;
  }
  case TAG_Just: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    heff_take_n(v_x2_2415, 1ULL, 1);
    v_x1_2417 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_t_2428;
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    v_t_2428 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str0);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    v_t_2428 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str1);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_2417, 0ULL, 2);
    v_t_2428 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str2);
    break;
  }
  case TAG_VInt: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    v_t_2428 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str3);
    break;
  }
  case TAG_VFloat: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    v_t_2428 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str4);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    v_t_2428 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str5);
    break;
  }
  case TAG_VStr: {
    V v_s_2425 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    v_t_2428 = v_s_2425;
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    v_t_2428 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str6);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    v_t_2428 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str7);
    break;
  }
  case TAG_VErased: {
    v_t_2428 = ((V)&g_heff_2ebuild_2edriver_2elabelOfV_str8);
    break;
  }
  default: heff_nomatch(v_x1_2417);
  }
  V v_t_2439;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VCons: {
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VTag: {
    V v_vs_2432 = heff_field(v_v_240, 1);
    v_t_2439 = heff_dup(v_vs_2432);
    break;
  }
  case TAG_VInt: {
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat: {
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VFloat32: {
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VStr: {
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VRune: {
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VArr: {
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  case TAG_VErased: {
    v_t_2439 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  V v_x1_2440 = (g_list_2edrop(MK_INT(1LL), v_t_2439));
  V v_x2_2443;
  switch (heff_tag_of(v_x1_2440)) {
  case TAG_Nil: {
    v_x2_2443 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2441 = heff_field(v_x1_2440, 0);
    heff_take_n(v_x1_2440, 1ULL, 2);
    v_x2_2443 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2441});
    break;
  }
  default: heff_nomatch(v_x1_2440);
  }
  V v_x1_2445;
  switch (heff_tag_of(v_x2_2443)) {
  case TAG_Nothing: {
    v_x1_2445 = NTAG(TAG_VErased);
    break;
  }
  case TAG_Just: {
    V v_x_2444 = heff_field(v_x2_2443, 0);
    heff_take_n(v_x2_2443, 1ULL, 1);
    v_x1_2445 = v_x_2444;
    break;
  }
  default: heff_nomatch(v_x2_2443);
  }
  V v_t_2456;
  switch (heff_tag_of(v_x1_2445)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2445, 0ULL, 1);
    v_t_2456 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2445, 0ULL, 1);
    v_t_2456 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_2445, 0ULL, 2);
    v_t_2456 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_2450 = heff_field(v_x1_2445, 0);
    heff_take_n(v_x1_2445, 1ULL, 1);
    v_t_2456 = v_i_2450;
    break;
  }
  case TAG_VFloat: {
    heff_take_n(v_x1_2445, 0ULL, 1);
    v_t_2456 = MK_INT(0LL);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2445, 0ULL, 1);
    v_t_2456 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_2445, 0ULL, 1);
    v_t_2456 = MK_INT(0LL);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2445, 0ULL, 1);
    v_t_2456 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2445, 0ULL, 1);
    v_t_2456 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    v_t_2456 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_2445);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2428, v_t_2456});
}
V g_heff_2ebuild_2edriver_2elabelOfV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2elabelOfV(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str9, 4, "Just");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str19, 6, "Differ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str24, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str25, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str27, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str28, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str29, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str30, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str31, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str32, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str33, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str34, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str35, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str36, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str37, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str38, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str39, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str40, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str41, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str42, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str43, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str44, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str45, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efailureOfV_str46, 0, "");
Clo g_heff_2ebuild_2edriver_2efailureOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efailureOfV_entry, 1, 0};

V g_heff_2ebuild_2edriver_2efailureOfV(V v_v_240) {
top: ;
  V v_t_2411;
  switch (heff_tag_of(v_v_240)) {
  case TAG_VFun: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str0);
    break;
  }
  case TAG_VCons: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str1);
    break;
  }
  case TAG_VTag: {
    V v_x_243 = heff_field(v_v_240, 0);
    v_t_2411 = heff_dup(v_x_243);
    break;
  }
  case TAG_VInt: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str2);
    break;
  }
  case TAG_VFloat: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str3);
    break;
  }
  case TAG_VFloat32: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str4);
    break;
  }
  case TAG_VStr: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str5);
    break;
  }
  case TAG_VRune: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str6);
    break;
  }
  case TAG_VArr: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str7);
    break;
  }
  case TAG_VErased: {
    v_t_2411 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str8);
    break;
  }
  default: heff_nomatch(v_v_240);
  }
  if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str9))) {
    V v_t_2423;
    switch (heff_tag_of(v_v_240)) {
    case TAG_VFun: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2416 = heff_field(v_v_240, 1);
      v_t_2423 = heff_dup(v_vs_2416);
      break;
    }
    case TAG_VInt: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2423 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_240);
    }
    V v_x1_2424 = (g_list_2edrop(MK_INT(0LL), v_t_2423));
    V v_x2_2427;
    switch (heff_tag_of(v_x1_2424)) {
    case TAG_Nil: {
      v_x2_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_x1_2424, 0);
      heff_take_n(v_x1_2424, 1ULL, 2);
      v_x2_2427 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2425});
      break;
    }
    default: heff_nomatch(v_x1_2424);
    }
    V v_x1_2429;
    switch (heff_tag_of(v_x2_2427)) {
    case TAG_Nothing: {
      v_x1_2429 = NTAG(TAG_VErased);
      break;
    }
    case TAG_Just: {
      V v_x_2428 = heff_field(v_x2_2427, 0);
      heff_take_n(v_x2_2427, 1ULL, 1);
      v_x1_2429 = v_x_2428;
      break;
    }
    default: heff_nomatch(v_x2_2427);
    }
    V v_t_2440;
    switch (heff_tag_of(v_x1_2429)) {
    case TAG_VFun: {
      heff_take_n(v_x1_2429, 0ULL, 1);
      v_t_2440 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str10);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_x1_2429, 0ULL, 1);
      v_t_2440 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str11);
      break;
    }
    case TAG_VTag: {
      V v_x_2432 = heff_field(v_x1_2429, 0);
      heff_take_n(v_x1_2429, 1ULL, 2);
      v_t_2440 = v_x_2432;
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_x1_2429, 0ULL, 1);
      v_t_2440 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str12);
      break;
    }
    case TAG_VFloat: {
      heff_take_n(v_x1_2429, 0ULL, 1);
      v_t_2440 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str13);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x1_2429, 0ULL, 1);
      v_t_2440 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str14);
      break;
    }
    case TAG_VStr: {
      heff_take_n(v_x1_2429, 0ULL, 1);
      v_t_2440 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str15);
      break;
    }
    case TAG_VRune: {
      heff_take_n(v_x1_2429, 0ULL, 1);
      v_t_2440 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str16);
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_x1_2429, 0ULL, 1);
      v_t_2440 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str17);
      break;
    }
    case TAG_VErased: {
      v_t_2440 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str18);
      break;
    }
    default: heff_nomatch(v_x1_2429);
    }
    if (heff_strEq_c(v_t_2440, ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str19))) {
      V v_t_2452;
      switch (heff_tag_of(v_v_240)) {
      case TAG_VFun: {
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_2445 = heff_field(v_v_240, 1);
        v_t_2452 = heff_dup(v_vs_2445);
        break;
      }
      case TAG_VInt: {
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_2452 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_240);
      }
      V v_x1_2453 = (g_list_2edrop(MK_INT(0LL), v_t_2452));
      V v_x2_2456;
      switch (heff_tag_of(v_x1_2453)) {
      case TAG_Nil: {
        v_x2_2456 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2454 = heff_field(v_x1_2453, 0);
        heff_take_n(v_x1_2453, 1ULL, 2);
        v_x2_2456 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2454});
        break;
      }
      default: heff_nomatch(v_x1_2453);
      }
      V v_v_2458;
      switch (heff_tag_of(v_x2_2456)) {
      case TAG_Nothing: {
        v_v_2458 = NTAG(TAG_VErased);
        break;
      }
      case TAG_Just: {
        V v_x_2457 = heff_field(v_x2_2456, 0);
        heff_take_n(v_x2_2456, 1ULL, 1);
        v_v_2458 = v_x_2457;
        break;
      }
      default: heff_nomatch(v_x2_2456);
      }
      V v_t_2469;
      switch (heff_tag_of(v_v_2458)) {
      case TAG_VFun: {
        heff_take_n(v_v_2458, 0ULL, 1);
        v_t_2469 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_v_2458, 0ULL, 1);
        v_t_2469 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_2462 = heff_field(v_v_2458, 1);
        heff_take_n(v_v_2458, 2ULL, 2);
        v_t_2469 = v_vs_2462;
        break;
      }
      case TAG_VInt: {
        heff_take_n(v_v_2458, 0ULL, 1);
        v_t_2469 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        heff_take_n(v_v_2458, 0ULL, 1);
        v_t_2469 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_2458, 0ULL, 1);
        v_t_2469 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        heff_take_n(v_v_2458, 0ULL, 1);
        v_t_2469 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        heff_take_n(v_v_2458, 0ULL, 1);
        v_t_2469 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        heff_take_n(v_v_2458, 0ULL, 1);
        v_t_2469 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_2469 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_2458);
      }
      V v_x1_2470 = (g_list_2edrop(MK_INT(0LL), v_t_2469));
      V v_x2_2473;
      switch (heff_tag_of(v_x1_2470)) {
      case TAG_Nil: {
        v_x2_2473 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2471 = heff_field(v_x1_2470, 0);
        heff_take_n(v_x1_2470, 1ULL, 2);
        v_x2_2473 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2471});
        break;
      }
      default: heff_nomatch(v_x1_2470);
      }
      V v_x1_2475;
      switch (heff_tag_of(v_x2_2473)) {
      case TAG_Nothing: {
        v_x1_2475 = NTAG(TAG_VErased);
        break;
      }
      case TAG_Just: {
        V v_x_2474 = heff_field(v_x2_2473, 0);
        heff_take_n(v_x2_2473, 1ULL, 1);
        v_x1_2475 = v_x_2474;
        break;
      }
      default: heff_nomatch(v_x2_2473);
      }
      V v_t_2486;
      switch (heff_tag_of(v_x1_2475)) {
      case TAG_VFun: {
        heff_take_n(v_x1_2475, 0ULL, 1);
        v_t_2486 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str20);
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_x1_2475, 0ULL, 1);
        v_t_2486 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str21);
        break;
      }
      case TAG_VTag: {
        heff_take_n(v_x1_2475, 0ULL, 2);
        v_t_2486 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str22);
        break;
      }
      case TAG_VInt: {
        heff_take_n(v_x1_2475, 0ULL, 1);
        v_t_2486 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str23);
        break;
      }
      case TAG_VFloat: {
        heff_take_n(v_x1_2475, 0ULL, 1);
        v_t_2486 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str24);
        break;
      }
      case TAG_VFloat32: {
        heff_take_n(v_x1_2475, 0ULL, 1);
        v_t_2486 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str25);
        break;
      }
      case TAG_VStr: {
        V v_s_2483 = heff_field(v_x1_2475, 0);
        heff_take_n(v_x1_2475, 1ULL, 1);
        v_t_2486 = v_s_2483;
        break;
      }
      case TAG_VRune: {
        heff_take_n(v_x1_2475, 0ULL, 1);
        v_t_2486 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str26);
        break;
      }
      case TAG_VArr: {
        heff_take_n(v_x1_2475, 0ULL, 1);
        v_t_2486 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str27);
        break;
      }
      case TAG_VErased: {
        v_t_2486 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str28);
        break;
      }
      default: heff_nomatch(v_x1_2475);
      }
      V v_t_2497;
      switch (heff_tag_of(v_v_240)) {
      case TAG_VFun: {
        v_t_2497 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        v_t_2497 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_2490 = heff_field(v_v_240, 1);
        v_t_2497 = heff_dup(v_vs_2490);
        break;
      }
      case TAG_VInt: {
        v_t_2497 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        v_t_2497 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        v_t_2497 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        v_t_2497 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        v_t_2497 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        v_t_2497 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_2497 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_240);
      }
      V v_x1_2498 = (g_list_2edrop(MK_INT(0LL), v_t_2497));
      V v_x2_24101;
      switch (heff_tag_of(v_x1_2498)) {
      case TAG_Nil: {
        v_x2_24101 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2499 = heff_field(v_x1_2498, 0);
        heff_take_n(v_x1_2498, 1ULL, 2);
        v_x2_24101 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2499});
        break;
      }
      default: heff_nomatch(v_x1_2498);
      }
      V v_v_24103;
      switch (heff_tag_of(v_x2_24101)) {
      case TAG_Nothing: {
        v_v_24103 = NTAG(TAG_VErased);
        break;
      }
      case TAG_Just: {
        V v_x_24102 = heff_field(v_x2_24101, 0);
        heff_take_n(v_x2_24101, 1ULL, 1);
        v_v_24103 = v_x_24102;
        break;
      }
      default: heff_nomatch(v_x2_24101);
      }
      V v_t_24114;
      switch (heff_tag_of(v_v_24103)) {
      case TAG_VFun: {
        heff_take_n(v_v_24103, 0ULL, 1);
        v_t_24114 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_v_24103, 0ULL, 1);
        v_t_24114 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_24107 = heff_field(v_v_24103, 1);
        heff_take_n(v_v_24103, 2ULL, 2);
        v_t_24114 = v_vs_24107;
        break;
      }
      case TAG_VInt: {
        heff_take_n(v_v_24103, 0ULL, 1);
        v_t_24114 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        heff_take_n(v_v_24103, 0ULL, 1);
        v_t_24114 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_24103, 0ULL, 1);
        v_t_24114 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        heff_take_n(v_v_24103, 0ULL, 1);
        v_t_24114 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        heff_take_n(v_v_24103, 0ULL, 1);
        v_t_24114 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        heff_take_n(v_v_24103, 0ULL, 1);
        v_t_24114 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_24114 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_24103);
      }
      V v_x1_24115 = (g_list_2edrop(MK_INT(1LL), v_t_24114));
      V v_x2_24118;
      switch (heff_tag_of(v_x1_24115)) {
      case TAG_Nil: {
        v_x2_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_24116 = heff_field(v_x1_24115, 0);
        heff_take_n(v_x1_24115, 1ULL, 2);
        v_x2_24118 = heff_tag_n(TAG_Just, 1, (V[]){v_x_24116});
        break;
      }
      default: heff_nomatch(v_x1_24115);
      }
      V v_x1_24120;
      switch (heff_tag_of(v_x2_24118)) {
      case TAG_Nothing: {
        v_x1_24120 = NTAG(TAG_VErased);
        break;
      }
      case TAG_Just: {
        V v_x_24119 = heff_field(v_x2_24118, 0);
        heff_take_n(v_x2_24118, 1ULL, 1);
        v_x1_24120 = v_x_24119;
        break;
      }
      default: heff_nomatch(v_x2_24118);
      }
      V v_t_24131;
      switch (heff_tag_of(v_x1_24120)) {
      case TAG_VFun: {
        heff_take_n(v_x1_24120, 0ULL, 1);
        v_t_24131 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str29);
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_x1_24120, 0ULL, 1);
        v_t_24131 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str30);
        break;
      }
      case TAG_VTag: {
        heff_take_n(v_x1_24120, 0ULL, 2);
        v_t_24131 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str31);
        break;
      }
      case TAG_VInt: {
        heff_take_n(v_x1_24120, 0ULL, 1);
        v_t_24131 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str32);
        break;
      }
      case TAG_VFloat: {
        heff_take_n(v_x1_24120, 0ULL, 1);
        v_t_24131 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str33);
        break;
      }
      case TAG_VFloat32: {
        heff_take_n(v_x1_24120, 0ULL, 1);
        v_t_24131 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str34);
        break;
      }
      case TAG_VStr: {
        V v_s_24128 = heff_field(v_x1_24120, 0);
        heff_take_n(v_x1_24120, 1ULL, 1);
        v_t_24131 = v_s_24128;
        break;
      }
      case TAG_VRune: {
        heff_take_n(v_x1_24120, 0ULL, 1);
        v_t_24131 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str35);
        break;
      }
      case TAG_VArr: {
        heff_take_n(v_x1_24120, 0ULL, 1);
        v_t_24131 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str36);
        break;
      }
      case TAG_VErased: {
        v_t_24131 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str37);
        break;
      }
      default: heff_nomatch(v_x1_24120);
      }
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailDiffer, 2, (V[]){v_t_2486, v_t_24131})});
    } else {
      V v_t_24142;
      switch (heff_tag_of(v_v_240)) {
      case TAG_VFun: {
        v_t_24142 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        v_t_24142 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_24135 = heff_field(v_v_240, 1);
        v_t_24142 = heff_dup(v_vs_24135);
        break;
      }
      case TAG_VInt: {
        v_t_24142 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        v_t_24142 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        v_t_24142 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        v_t_24142 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        v_t_24142 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        v_t_24142 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_24142 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_240);
      }
      V v_x1_24143 = (g_list_2edrop(MK_INT(0LL), v_t_24142));
      V v_x2_24146;
      switch (heff_tag_of(v_x1_24143)) {
      case TAG_Nil: {
        v_x2_24146 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_24144 = heff_field(v_x1_24143, 0);
        heff_take_n(v_x1_24143, 1ULL, 2);
        v_x2_24146 = heff_tag_n(TAG_Just, 1, (V[]){v_x_24144});
        break;
      }
      default: heff_nomatch(v_x1_24143);
      }
      V v_v_24148;
      switch (heff_tag_of(v_x2_24146)) {
      case TAG_Nothing: {
        v_v_24148 = NTAG(TAG_VErased);
        break;
      }
      case TAG_Just: {
        V v_x_24147 = heff_field(v_x2_24146, 0);
        heff_take_n(v_x2_24146, 1ULL, 1);
        v_v_24148 = v_x_24147;
        break;
      }
      default: heff_nomatch(v_x2_24146);
      }
      V v_t_24159;
      switch (heff_tag_of(v_v_24148)) {
      case TAG_VFun: {
        heff_take_n(v_v_24148, 0ULL, 1);
        v_t_24159 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_v_24148, 0ULL, 1);
        v_t_24159 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VTag: {
        V v_vs_24152 = heff_field(v_v_24148, 1);
        heff_take_n(v_v_24148, 2ULL, 2);
        v_t_24159 = v_vs_24152;
        break;
      }
      case TAG_VInt: {
        heff_take_n(v_v_24148, 0ULL, 1);
        v_t_24159 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat: {
        heff_take_n(v_v_24148, 0ULL, 1);
        v_t_24159 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_24148, 0ULL, 1);
        v_t_24159 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VStr: {
        heff_take_n(v_v_24148, 0ULL, 1);
        v_t_24159 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VRune: {
        heff_take_n(v_v_24148, 0ULL, 1);
        v_t_24159 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VArr: {
        heff_take_n(v_v_24148, 0ULL, 1);
        v_t_24159 = NTAG(TAG_Nil);
        break;
      }
      case TAG_VErased: {
        v_t_24159 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_v_24148);
      }
      V v_x1_24160 = (g_list_2edrop(MK_INT(0LL), v_t_24159));
      V v_x2_24163;
      switch (heff_tag_of(v_x1_24160)) {
      case TAG_Nil: {
        v_x2_24163 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_24161 = heff_field(v_x1_24160, 0);
        heff_take_n(v_x1_24160, 1ULL, 2);
        v_x2_24163 = heff_tag_n(TAG_Just, 1, (V[]){v_x_24161});
        break;
      }
      default: heff_nomatch(v_x1_24160);
      }
      V v_x1_24165;
      switch (heff_tag_of(v_x2_24163)) {
      case TAG_Nothing: {
        v_x1_24165 = NTAG(TAG_VErased);
        break;
      }
      case TAG_Just: {
        V v_x_24164 = heff_field(v_x2_24163, 0);
        heff_take_n(v_x2_24163, 1ULL, 1);
        v_x1_24165 = v_x_24164;
        break;
      }
      default: heff_nomatch(v_x2_24163);
      }
      V v_t_24176;
      switch (heff_tag_of(v_x1_24165)) {
      case TAG_VFun: {
        heff_take_n(v_x1_24165, 0ULL, 1);
        v_t_24176 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str38);
        break;
      }
      case TAG_VCons: {
        heff_take_n(v_x1_24165, 0ULL, 1);
        v_t_24176 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str39);
        break;
      }
      case TAG_VTag: {
        heff_take_n(v_x1_24165, 0ULL, 2);
        v_t_24176 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str40);
        break;
      }
      case TAG_VInt: {
        heff_take_n(v_x1_24165, 0ULL, 1);
        v_t_24176 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str41);
        break;
      }
      case TAG_VFloat: {
        heff_take_n(v_x1_24165, 0ULL, 1);
        v_t_24176 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str42);
        break;
      }
      case TAG_VFloat32: {
        heff_take_n(v_x1_24165, 0ULL, 1);
        v_t_24176 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str43);
        break;
      }
      case TAG_VStr: {
        V v_s_24173 = heff_field(v_x1_24165, 0);
        heff_take_n(v_x1_24165, 1ULL, 1);
        v_t_24176 = v_s_24173;
        break;
      }
      case TAG_VRune: {
        heff_take_n(v_x1_24165, 0ULL, 1);
        v_t_24176 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str44);
        break;
      }
      case TAG_VArr: {
        heff_take_n(v_x1_24165, 0ULL, 1);
        v_t_24176 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str45);
        break;
      }
      case TAG_VErased: {
        v_t_24176 = ((V)&g_heff_2ebuild_2edriver_2efailureOfV_str46);
        break;
      }
      default: heff_nomatch(v_x1_24165);
      }
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_t_24176})});
    }
  } else {
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2edriver_2efailureOfV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2efailureOfV(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str0, 4, "name");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str10, 2, "ok");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str15, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str17, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str18, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str19, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str20, 8, "property");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str21, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str22, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str23, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str24, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str25, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str26, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str27, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str28, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str29, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str30, 4, "runs");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str31, 9, "discarded");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str32, 7, "shrinks");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str33, 6, "labels");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str34, 5, "notes");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str35, 7, "failure");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str36, 4, "seed");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str37, 4, "True");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomeOfV_str38, 4, "True");
Clo g_heff_2ebuild_2edriver_2eoutcomeOfV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eoutcomeOfV_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eoutcomeOfV(V v_v_240) {
top: ;
  V v_x1_241 = (g_heff_2ebuild_2edriver_2efieldV(v_v_240, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str0)));
  V v_t_2412;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_VFun: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2412 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str1);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2412 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str2);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_241, 0ULL, 2);
    v_t_2412 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str3);
    break;
  }
  case TAG_VInt: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2412 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str4);
    break;
  }
  case TAG_VFloat: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2412 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str5);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2412 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str6);
    break;
  }
  case TAG_VStr: {
    V v_s_249 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    v_t_2412 = v_s_249;
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2412 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str7);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_241, 0ULL, 1);
    v_t_2412 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str8);
    break;
  }
  case TAG_VErased: {
    v_t_2412 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str9);
    break;
  }
  default: heff_nomatch(v_x1_241);
  }
  V v_x1_2413 = (g_heff_2ebuild_2edriver_2efieldV(v_v_240, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str10)));
  V v_t_2424;
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2413, 0ULL, 1);
    v_t_2424 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str11);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2413, 0ULL, 1);
    v_t_2424 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str12);
    break;
  }
  case TAG_VTag: {
    V v_x_2416 = heff_field(v_x1_2413, 0);
    heff_take_n(v_x1_2413, 1ULL, 2);
    v_t_2424 = v_x_2416;
    break;
  }
  case TAG_VInt: {
    heff_take_n(v_x1_2413, 0ULL, 1);
    v_t_2424 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str13);
    break;
  }
  case TAG_VFloat: {
    heff_take_n(v_x1_2413, 0ULL, 1);
    v_t_2424 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str14);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2413, 0ULL, 1);
    v_t_2424 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str15);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_2413, 0ULL, 1);
    v_t_2424 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str16);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2413, 0ULL, 1);
    v_t_2424 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str17);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2413, 0ULL, 1);
    v_t_2424 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str18);
    break;
  }
  case TAG_VErased: {
    v_t_2424 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str19);
    break;
  }
  default: heff_nomatch(v_x1_2413);
  }
  V v_x1_2425 = (g_heff_2ebuild_2edriver_2efieldV(v_v_240, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str20)));
  V v_t_2436;
  switch (heff_tag_of(v_x1_2425)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2425, 0ULL, 1);
    v_t_2436 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str21);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2425, 0ULL, 1);
    v_t_2436 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str22);
    break;
  }
  case TAG_VTag: {
    V v_x_2428 = heff_field(v_x1_2425, 0);
    heff_take_n(v_x1_2425, 1ULL, 2);
    v_t_2436 = v_x_2428;
    break;
  }
  case TAG_VInt: {
    heff_take_n(v_x1_2425, 0ULL, 1);
    v_t_2436 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str23);
    break;
  }
  case TAG_VFloat: {
    heff_take_n(v_x1_2425, 0ULL, 1);
    v_t_2436 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str24);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2425, 0ULL, 1);
    v_t_2436 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str25);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_2425, 0ULL, 1);
    v_t_2436 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str26);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2425, 0ULL, 1);
    v_t_2436 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str27);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2425, 0ULL, 1);
    v_t_2436 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str28);
    break;
  }
  case TAG_VErased: {
    v_t_2436 = ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str29);
    break;
  }
  default: heff_nomatch(v_x1_2425);
  }
  V v_x1_2437 = (g_heff_2ebuild_2edriver_2efieldV(v_v_240, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str30)));
  V v_t_2448;
  switch (heff_tag_of(v_x1_2437)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2437, 0ULL, 1);
    v_t_2448 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2437, 0ULL, 1);
    v_t_2448 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_2437, 0ULL, 2);
    v_t_2448 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_2442 = heff_field(v_x1_2437, 0);
    heff_take_n(v_x1_2437, 1ULL, 1);
    v_t_2448 = v_i_2442;
    break;
  }
  case TAG_VFloat: {
    heff_take_n(v_x1_2437, 0ULL, 1);
    v_t_2448 = MK_INT(0LL);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2437, 0ULL, 1);
    v_t_2448 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_2437, 0ULL, 1);
    v_t_2448 = MK_INT(0LL);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2437, 0ULL, 1);
    v_t_2448 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2437, 0ULL, 1);
    v_t_2448 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    v_t_2448 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_2437);
  }
  V v_x1_2449 = (g_heff_2ebuild_2edriver_2efieldV(v_v_240, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str31)));
  V v_t_2460;
  switch (heff_tag_of(v_x1_2449)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2449, 0ULL, 1);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2449, 0ULL, 1);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_2449, 0ULL, 2);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_2454 = heff_field(v_x1_2449, 0);
    heff_take_n(v_x1_2449, 1ULL, 1);
    v_t_2460 = v_i_2454;
    break;
  }
  case TAG_VFloat: {
    heff_take_n(v_x1_2449, 0ULL, 1);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2449, 0ULL, 1);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_2449, 0ULL, 1);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2449, 0ULL, 1);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2449, 0ULL, 1);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    v_t_2460 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_2449);
  }
  V v_x1_2461 = (g_heff_2ebuild_2edriver_2efieldV(v_v_240, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str32)));
  V v_t_2472;
  switch (heff_tag_of(v_x1_2461)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2461, 0ULL, 1);
    v_t_2472 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2461, 0ULL, 1);
    v_t_2472 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_2461, 0ULL, 2);
    v_t_2472 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_2466 = heff_field(v_x1_2461, 0);
    heff_take_n(v_x1_2461, 1ULL, 1);
    v_t_2472 = v_i_2466;
    break;
  }
  case TAG_VFloat: {
    heff_take_n(v_x1_2461, 0ULL, 1);
    v_t_2472 = MK_INT(0LL);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2461, 0ULL, 1);
    v_t_2472 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_2461, 0ULL, 1);
    v_t_2472 = MK_INT(0LL);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2461, 0ULL, 1);
    v_t_2472 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2461, 0ULL, 1);
    v_t_2472 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    v_t_2472 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_2461);
  }
  V v_t_2473 = (g_heff_2ebuild_2edriver_2efieldV(v_v_240, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str33)));
  V v_t_2474 = (g_heff_2ebuild_2edriver_2elistOfV(v_t_2473));
  V v_t_2475 = (g_list_2emap_24s570961906x1112476114(v_t_2474));
  V v_t_2476 = (g_heff_2ebuild_2edriver_2efieldV(v_v_240, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str34)));
  V v_t_2477 = (g_heff_2ebuild_2edriver_2elistOfV(v_t_2476));
  V v_t_2478 = (g_list_2emap_24s218655275x981659442(v_t_2477));
  V v_t_2479 = (g_heff_2ebuild_2edriver_2efieldV(v_v_240, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str35)));
  V v_t_2480 = ({ V a_0 = v_t_2479; V r_ = (g_heff_2ebuild_2edriver_2efailureOfV(a_0)); heff_drop(v_t_2479); r_; });
  V v_x1_2481 = (g_heff_2ebuild_2edriver_2efieldV(v_v_240, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str36)));
  V v_t_2492;
  switch (heff_tag_of(v_x1_2481)) {
  case TAG_VFun: {
    heff_take_n(v_x1_2481, 0ULL, 1);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VCons: {
    heff_take_n(v_x1_2481, 0ULL, 1);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VTag: {
    heff_take_n(v_x1_2481, 0ULL, 2);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VInt: {
    V v_i_2486 = heff_field(v_x1_2481, 0);
    heff_take_n(v_x1_2481, 1ULL, 1);
    v_t_2492 = v_i_2486;
    break;
  }
  case TAG_VFloat: {
    heff_take_n(v_x1_2481, 0ULL, 1);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VFloat32: {
    heff_take_n(v_x1_2481, 0ULL, 1);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VStr: {
    heff_take_n(v_x1_2481, 0ULL, 1);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VRune: {
    heff_take_n(v_x1_2481, 0ULL, 1);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VArr: {
    heff_take_n(v_x1_2481, 0ULL, 1);
    v_t_2492 = MK_INT(0LL);
    break;
  }
  case TAG_VErased: {
    v_t_2492 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_x1_2481);
  }
  return heff_rec_n(10, shape_name__ok__property__runs__discarded__shrinks__labels__notes__failure__seed, (V[]){v_t_2412, heff_strEq(v_t_2424, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str37)), heff_strEq(v_t_2436, ((V)&g_heff_2ebuild_2edriver_2eoutcomeOfV_str38)), v_t_2448, v_t_2460, v_t_2472, v_t_2475, v_t_2478, v_t_2480, v_t_2492});
}
V g_heff_2ebuild_2edriver_2eoutcomeOfV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eoutcomeOfV(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str0, 1, "(");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str1, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str2, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str3, 10, "<diverged>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str4, 1, "(");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str5, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str6, 11, "<abandoned>");
HEFF_LIT(g_heff_2ebuild_2edriver_2eoutcomesOf_str7, 10, "<diverged>");
Clo g_heff_2ebuild_2edriver_2eoutcomesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eoutcomesOf_entry, 3, 0};

V g_heff_2ebuild_2edriver_2eoutcomesOf(V v_o_240, V v_seed_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_r_242)) {
  case TAG_RSucceeded: {
    V v_v_243 = heff_field(v_r_242, 0);
    heff_drop_rec(v_o_240, 2);
    heff_drop(v_seed_241);
    V v_t_244 = (g_heff_2ebuild_2edriver_2elistOfV(heff_dup(v_v_243)));
    return (g_list_2emap_24s1895313378x47656836(v_t_244));
  }
  case TAG_RAbandoned: {
    V v_x_245 = heff_get_n(v_o_240, 0, 2);
    V v_t_246 = (g_heff_2esyntax_2epsurface_2eisOperator(heff_dup(v_x_245)));
    V v_name_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      v_name_247 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str0), heff_strAppend(v_x_245, ((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str1)));
      break;
    }
    case TAG_False: {
      v_name_247 = v_x_245;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_why_249;
    switch (heff_tag_of(v_r_242)) {
    case TAG_RSucceeded: {
      V v_v_248 = heff_field(v_r_242, 0);
      v_why_249 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_v_248); V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
      break;
    }
    case TAG_RAbandoned: {
      v_why_249 = ((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str2);
      break;
    }
    case TAG_RDiverged: {
      v_why_249 = ((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str3);
      break;
    }
    default: heff_nomatch(v_r_242);
    }
    V v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_249})});
    V v_t_2411 = heff_rec_n(10, shape_name__ok__property__runs__discarded__shrinks__labels__notes__failure__seed, (V[]){v_name_247, NTAG(TAG_False), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2410, v_seed_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  }
  case TAG_RDiverged: {
    V v_x_2412 = heff_get_n(v_o_240, 0, 2);
    V v_t_2413 = (g_heff_2esyntax_2epsurface_2eisOperator(heff_dup(v_x_2412)));
    V v_name_2414;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      v_name_2414 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str4), heff_strAppend(v_x_2412, ((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str5)));
      break;
    }
    case TAG_False: {
      v_name_2414 = v_x_2412;
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    V v_why_2416;
    switch (heff_tag_of(v_r_242)) {
    case TAG_RSucceeded: {
      V v_v_2415 = heff_field(v_r_242, 0);
      v_why_2416 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_v_2415); V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
      break;
    }
    case TAG_RAbandoned: {
      v_why_2416 = ((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str6);
      break;
    }
    case TAG_RDiverged: {
      v_why_2416 = ((V)&g_heff_2ebuild_2edriver_2eoutcomesOf_str7);
      break;
    }
    default: heff_nomatch(v_r_242);
    }
    V v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2416})});
    V v_t_2418 = heff_rec_n(10, shape_name__ok__property__runs__discarded__shrinks__labels__notes__failure__seed, (V[]){v_name_2414, NTAG(TAG_False), NTAG(TAG_False), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2417, v_seed_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_r_242);
  }
}
V g_heff_2ebuild_2edriver_2eoutcomesOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2eoutcomesOf(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eaddTests_str0, 7, "> test ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eaddTests_str1, 13, "check.runTest");
Clo g_heff_2ebuild_2edriver_2eaddTests_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eaddTests_entry, 4, 0};

V g_heff_2ebuild_2edriver_2eaddTests(V v_seed_240, V v_i_241, V v_x3_242, V v_g_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_seed_240);
    heff_drop(v_i_241);
    return v_g_243;
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2eaddTests_str0), heff_intShow(heff_dup(v_i_241)));
    V v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_SApp, 2, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){((V)&g_heff_2ebuild_2edriver_2eaddTests_str1)}), heff_tag_n(TAG_SLitInt, 1, (V[]){heff_dup(v_seed_240)})});
    V v_t_248 = heff_tag_n(TAG_SGlobal, 1, (V[]){heff_get_n(v_o_244, 1, 2)});
    V v_t_249 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){heff_tag_n(TAG_SApp, 2, (V[]){v_t_247, v_t_248}), NTAG(TAG_SPrimInt), NTAG(TAG_VOpaque), NTAG(TAG_VPrimInt)});
    V v_t_2410 = (g_heff_2eelab_2eglobals_2eaddEntry(v_t_246, v_t_249, v_g_243));
    V t_0 = v_seed_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_rest_245;
    V t_3 = v_t_2410;
    v_seed_240 = t_0;
    v_i_241 = t_1;
    v_x3_242 = t_2;
    v_g_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2eaddTests_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eaddTests(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2epickOutcomes_str0, 7, "> test ");
Clo g_heff_2ebuild_2edriver_2epickOutcomes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2epickOutcomes_entry, 4, 0};

V g_heff_2ebuild_2edriver_2epickOutcomes(V v_seed_240, V v_rs_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_seed_240);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2epickOutcomes_str0), heff_intShow(heff_dup(v_i_242)));
    V v_t_247 = (g_list_2elookupBy(heff_dup(g_strEq_get()), v_t_246, v_rs_241));
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_t_249 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_r_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_249 = ({ V a_0 = heff_dup(v_o_244); V a_1 = heff_dup(v_seed_240); V a_2 = v_r_248; V r_ = (g_heff_2ebuild_2edriver_2eoutcomesOf(a_0, a_1, a_2)); heff_drop(v_r_248); r_; });
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2410 = (g_heff_2ebuild_2edriver_2epickOutcomes(v_seed_240, v_rs_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_rest_245));
    return (g_prelude_2e_2b_2b(v_t_249, v_t_2410));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2edriver_2epickOutcomes_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ebuild_2edriver_2epickOutcomes(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2erunTests_str0, 7, "> test ");
V g_heff_2ebuild_2edriver_2erunTests_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2erunTests_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2erunTests_lam2(V self, V *args);
V g_heff_2ebuild_2edriver_2erunTests_lam3(V self, V *args);
Clo g_heff_2ebuild_2edriver_2erunTests_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2erunTests_entry, 2, 0};

V g_heff_2ebuild_2edriver_2erunTests(V v_seed_240, V v_c_241) {
top: ;
  V v_x1_243 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2erunTests_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), heff_dup(heff_rfield(v_c_241, 7))));
  V v_t_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    v_t_246 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_243, 0ULL, 2);
    v_t_246 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_seed_240);
    heff_drop_rec(v_c_241, 13);
    return NTAG(TAG_Nil);
  }
  case TAG_False: {
    V v_t_248 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2erunTests_lam1, 1, 1, (V[]){heff_dup(v_c_241)}), heff_dup(heff_rfield(v_c_241, 7))));
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_c_241, 5)), 0, 9);
    V v_gs_2410 = (g_heff_2ebuild_2edriver_2eaddTests(heff_dup(v_seed_240), MK_INT(0LL), v_t_248, v_t_249));
    V v_t_2415 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2erunTests_lam2, 2, 1, (V[]){heff_dup(v_gs_2410)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get_n(v_gs_2410, 0, 7); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2416 = (g_heff_2ecompile_2einterp_2eevalGlobalsGo_24s1251174705x232593684(MK_INT(0LL), MK_INT(7LL), ((V)&g_heff_2ebuild_2edriver_2erunTests_str0), heff_dup(g_map_2eempty_get()), v_t_2415, NTAG(TAG_Nil)));
    V v_t_2418 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2erunTests_lam3, 1, 1, (V[]){heff_dup(v_c_241)}), heff_get_n(v_c_241, 7, 13)));
    return ({ V a_0 = v_seed_240; V a_1 = v_t_2416; V a_2 = MK_INT(0LL); V a_3 = v_t_2418; V r_ = (g_heff_2ebuild_2edriver_2epickOutcomes(a_0, a_1, a_2, a_3)); heff_drop(v_t_2416); heff_drop(v_t_2418); r_; });
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ebuild_2edriver_2erunTests_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2erunTests(a[0], a[1]);
}
V g_heff_2ebuild_2edriver_2erunTests_lam0(V self, V *args) {
  V v_o_242 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2eisTestOwn(v_c_241, v_o_242));
}
V g_heff_2ebuild_2edriver_2erunTests_lam1(V self, V *args) {
  V v_o_247 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2eisTestOwn(v_c_241, v_o_247));
}
V g_heff_2ebuild_2edriver_2erunTests_lam2(V self, V *args) {
  V v_acc_2411 = args[0];
  V v_k_2412 = args[1];
  V v_gs_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = ({ V a_0 = heff_dup(v_k_2412); V b_1 = heff_get_n(v_gs_2410, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    heff_drop(v_k_2412);
    return v_acc_2411;
  }
  case TAG_Just: {
    V v_e_2414 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2412, v_e_2414}), v_acc_2411});
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2ebuild_2edriver_2erunTests_lam3(V self, V *args) {
  V v_o_2417 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2eisTestOwn(v_c_241, v_o_2417));
}
Clo g_heff_2ebuild_2edriver_2eearlierGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eearlierGo_entry, 4, 0};

V g_heff_2ebuild_2edriver_2eearlierGo(V v_x1_240, V v_i_241, V v_x_242, V v_j_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_x_242);
    heff_drop(v_j_243);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_g_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_g_244, 0)), heff_dup(v_x_242))) {
      heff_drop(v_x_242);
      return heff_intLt(v_j_243, v_i_241);
    } else {
      V t_0 = v_rest_245;
      V t_1 = v_i_241;
      V t_2 = v_x_242;
      V t_3 = heff_intAdd(v_j_243, MK_INT(1LL));
      v_x1_240 = t_0;
      v_i_241 = t_1;
      v_x_242 = t_2;
      v_j_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eearlierGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2eearlierGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str0, 6, "infixl");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str1, 6, "infixr");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str2, 5, "infix");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str7, 1, " ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str8, 7, " above ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str11, 1, " ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str12, 7, " below ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str13, 6, " below");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str15, 1, " ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLine_str16, 1, "\012");
V g_heff_2ebuild_2edriver_2efixityLine_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2efixityLine_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2efixityLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efixityLine_entry, 3, 0};

V g_heff_2ebuild_2edriver_2efixityLine(V v_fx_240, V v_i_241, V v_g_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_g_242, 1));
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_AssocLeft: {
    v_t_244 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str0);
    break;
  }
  case TAG_AssocRight: {
    v_t_244 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str1);
    break;
  }
  case TAG_AssocNone: {
    v_t_244 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str2);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_dup(heff_rfield(v_g_242, 2));
  V v_t_248;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_t_245, 0);
    V v_xs_247 = heff_field(v_t_245, 1);
    heff_take_n(v_t_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str4); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_2412 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2efixityLine_lam0, 1, 3, (V[]){heff_dup(v_g_242), heff_dup(v_fx_240), heff_dup(v_i_241)}), heff_dup(heff_rfield(v_fx_240, 1))));
  V v_t_2413 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2412));
  V v_ops_2414 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2413));
  V v_t_2420;
  switch (heff_tag_of(v_ops_2414)) {
  case TAG_Nil: {
    v_t_2420 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str5);
    break;
  }
  case TAG_Cons: {
    V v_t_2419;
    switch (heff_tag_of(v_ops_2414)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_ops_2414, 0);
      V v_xs_2418 = heff_field(v_ops_2414, 1);
      heff_take_n(v_ops_2414, 3ULL, 2);
      v_t_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str7); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
      break;
    }
    default: heff_nomatch(v_ops_2414);
    }
    v_t_2420 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2efixityLine_str8), v_t_2419);
    break;
  }
  default: heff_nomatch(v_ops_2414);
  }
  V v_t_2424 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2efixityLine_lam1, 1, 3, (V[]){heff_dup(v_g_242), heff_dup(v_fx_240), v_i_241}), heff_get_n(v_fx_240, 1, 2)));
  V v_t_2425 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2424));
  V v_ops_2426 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2425));
  V v_t_2432;
  switch (heff_tag_of(v_ops_2426)) {
  case TAG_Nil: {
    v_t_2432 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str9);
    break;
  }
  case TAG_Cons: {
    V v_t_2431;
    switch (heff_tag_of(v_ops_2426)) {
    case TAG_Nil: {
      v_t_2431 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2429 = heff_field(v_ops_2426, 0);
      V v_xs_2430 = heff_field(v_ops_2426, 1);
      heff_take_n(v_ops_2426, 3ULL, 2);
      v_t_2431 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str11); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
      break;
    }
    default: heff_nomatch(v_ops_2426);
    }
    v_t_2432 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2efixityLine_str12), v_t_2431);
    break;
  }
  default: heff_nomatch(v_ops_2426);
  }
  V v_t_2433 = heff_get_n(v_g_242, 3, 5);
  V v_t_2434;
  switch (heff_tag_of(v_t_2433)) {
  case TAG_True: {
    v_t_2434 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str13);
    break;
  }
  case TAG_False: {
    v_t_2434 = ((V)&g_heff_2ebuild_2edriver_2efixityLine_str14);
    break;
  }
  default: heff_nomatch(v_t_2433);
  }
  return heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ebuild_2edriver_2efixityLine_str15), heff_strAppend(v_t_248, heff_strAppend(v_t_2420, heff_strAppend(v_t_2432, heff_strAppend(v_t_2434, ((V)&g_heff_2ebuild_2edriver_2efixityLine_str16)))))));
}
V g_heff_2ebuild_2edriver_2efixityLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2efixityLine(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edriver_2efixityLine_lam0(V self, V *args) {
  V v_e_249 = args[0];
  V v_g_242 = heff_env(self)[0];
  V v_fx_240 = heff_env(self)[1];
  V v_i_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_e_249, 0)), heff_get_n(v_g_242, 0, 5))) {
    V v_t_2411 = ({ V b_0 = heff_get_n(v_fx_240, 0, 2); V a_1 = v_i_241; V a_2 = heff_dup(heff_rfield(v_e_249, 1)); V a_3 = MK_INT(0LL); V r_ = (g_heff_2ebuild_2edriver_2eearlierGo(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_e_249, 1, 2)});
    }
    case TAG_False: {
      heff_drop_rec(v_e_249, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2411);
    }
  } else {
    heff_drop_rec(v_e_249, 2);
    heff_drop_rec(v_fx_240, 2);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2edriver_2efixityLine_lam1(V self, V *args) {
  V v_e_2421 = args[0];
  V v_g_242 = heff_env(self)[0];
  V v_fx_240 = heff_env(self)[1];
  V v_i_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_e_2421, 1)), heff_get_n(v_g_242, 0, 5))) {
    V v_t_2423 = ({ V b_0 = heff_get_n(v_fx_240, 0, 2); V a_1 = v_i_241; V a_2 = heff_dup(heff_rfield(v_e_2421, 0)); V a_3 = MK_INT(0LL); V r_ = (g_heff_2ebuild_2edriver_2eearlierGo(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_e_2421, 0, 2)});
    }
    case TAG_False: {
      heff_drop_rec(v_e_2421, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2423);
    }
  } else {
    heff_drop_rec(v_e_2421, 2);
    heff_drop_rec(v_fx_240, 2);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efixityLines_str0, 0, "");
Clo g_heff_2ebuild_2edriver_2efixityLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efixityLines_entry, 3, 0};

V g_heff_2ebuild_2edriver_2efixityLines(V v_fx_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_fx_240);
    heff_drop(v_i_241);
    return ((V)&g_heff_2ebuild_2edriver_2efixityLines_str0);
  }
  case TAG_Cons: {
    V v_g_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2edriver_2efixityLine(heff_dup(v_fx_240), heff_dup(v_i_241), heff_dup(v_g_243)));
    return heff_strAppend(v_t_245, (g_heff_2ebuild_2edriver_2efixityLines(v_fx_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_rest_244)));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2efixityLines_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2edriver_2efixityLines(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eglueOne_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eglueOne_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eglueOne_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eglueOne_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eglueOne_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eglueOne_str5, 1, "\012");
Clo g_heff_2ebuild_2edriver_2eglueOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eglueOne_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eglueOne(V v_acc_240, V v_d_241) {
top: ;
  V v_t_242 = heff_take_field(v_acc_240, 2);
  V v_t_247;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    v_t_247 = ((V)&g_heff_2ebuild_2edriver_2eglueOne_str0);
    break;
  }
  case TAG_False: {
    V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_d_241)), MK_INT(1LL));
    V v_x3_244 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2edriver_2eglueOne_str1), heff_strSlice(heff_dup(v_d_241), MK_INT(0LL), v_t_243), MK_INT(0LL)));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_dup(heff_rfield(v_acc_240, 1));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        v_t_247 = ((V)&g_heff_2ebuild_2edriver_2eglueOne_str2);
        break;
      }
      case TAG_False: {
        v_t_247 = ((V)&g_heff_2ebuild_2edriver_2eglueOne_str3);
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      v_t_247 = ((V)&g_heff_2ebuild_2edriver_2eglueOne_str4);
      break;
    }
    default: heff_nomatch(v_x3_244);
    }
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  V v_t_248 = heff_strAppend(heff_get_n(v_acc_240, 0, 3), heff_strAppend(v_t_247, heff_dup(v_d_241)));
  V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_d_241)), MK_INT(1LL));
  V v_x3_2410 = (g_prelude_2eindexFrom(((V)&g_heff_2ebuild_2edriver_2eglueOne_str5), heff_strSlice(v_d_241, MK_INT(0LL), v_t_249), MK_INT(0LL)));
  V v_t_2412;
  switch (heff_tag_of(v_x3_2410)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2410, 0ULL, 1);
    v_t_2412 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_2410);
  }
  return heff_rec_n(3, shape_out__multi__first, (V[]){v_t_248, v_t_2412, NTAG(TAG_False)});
}
V g_heff_2ebuild_2edriver_2eglueOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eglueOne(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str0, 1, "(");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str1, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str2, 9, "instance ");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str3, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str5, 1, "(");
HEFF_LIT(g_heff_2ebuild_2edriver_2esigEntry_str6, 1, ")");
V g_heff_2ebuild_2edriver_2esigEntry_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2esigEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2esigEntry_entry, 3, 0};

V g_heff_2ebuild_2edriver_2esigEntry(V v_c_240, V v_ln_241, V v_o_242) {
top: ;
  V v_g_243 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_k_244 = heff_dup(heff_rfield(v_o_242, 1));
  V v_t_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_244), heff_rfield(v_g_243, 1)));
  V v_t_249;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_t_246 = (g_map_2elookup_24s1546226666x2146984184(v_k_244, heff_rfield(v_g_243, 2)));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      heff_drop_rec(v_g_243, 7);
      v_t_249 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_k2_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      v_t_249 = ({ V a_0 = v_k2_247; V b_1 = heff_get_n(v_g_243, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    break;
  }
  case TAG_Just: {
    V v_e_248 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    heff_drop_rec(v_g_243, 7);
    heff_drop(v_k_244);
    v_t_249 = heff_tag_at_n(v_ru_24t_245_24Just, TAG_Just, 1, (V[]){v_e_248});
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    heff_drop_rec(v_c_240, 13);
    heff_drop(v_ln_241);
    heff_drop_rec(v_o_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_e_2410 = heff_field(v_t_249, 0);
    V v_ru_24t_249_24Just = heff_take_reuse_n(v_t_249, 1ULL, 1);
    V v_t_2411 = heff_get_n(heff_get_n(v_c_240, 5, 13), 0, 9);
    V v_t_2413 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2edriver_2esigEntry_lam0, 1, 1, (V[]){heff_dup(v_o_242)}); V b_1 = heff_get_n(v_t_2411, 6, 7); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2427;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      V v_x_2414 = heff_get_n(v_o_242, 0, 2);
      V v_t_2415 = (g_heff_2esyntax_2epsurface_2eisOperator(heff_dup(v_x_2414)));
      V v_shown_2416;
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        v_shown_2416 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2esigEntry_str0), heff_strAppend(v_x_2414, ((V)&g_heff_2ebuild_2edriver_2esigEntry_str1)));
        break;
      }
      case TAG_False: {
        v_shown_2416 = v_x_2414;
        break;
      }
      default: heff_nomatch(v_t_2415);
      }
      V v_t_2417 = (g_heff_2eelab_2erename_2erkOf(v_ln_241));
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_t_2417, 1, 2), 1, (V[]){heff_get_n(v_e_2410, 1, 4)}));
      V v_t_2419 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_2418; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); r_; });
      v_t_2427 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2esigEntry_str2), heff_strAppend(v_shown_2416, heff_strAppend(((V)&g_heff_2ebuild_2edriver_2esigEntry_str3), heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2edriver_2esigEntry_str4)))));
      break;
    }
    case TAG_False: {
      V v_x_2420 = heff_dup(heff_rfield(v_o_242, 0));
      V v_t_2421 = (g_heff_2esyntax_2epsurface_2eisOperator(heff_dup(v_x_2420)));
      V v_t_2422;
      switch (heff_tag_of(v_t_2421)) {
      case TAG_True: {
        v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2edriver_2esigEntry_str5), heff_strAppend(v_x_2420, ((V)&g_heff_2ebuild_2edriver_2esigEntry_str6)));
        break;
      }
      case TAG_False: {
        v_t_2422 = v_x_2420;
        break;
      }
      default: heff_nomatch(v_t_2421);
      }
      V v_t_2423 = (g_heff_2eelab_2erename_2erkOf(heff_dup(v_ln_241)));
      V v_t_2424 = heff_tr(heff_call(heff_get_n(v_t_2423, 1, 2), 1, (V[]){heff_take_field(v_e_2410, 1)}));
      V v_t_2425 = (g_heff_2eelab_2erename_2erkOf(v_ln_241));
      V v_t_2426 = heff_tr(heff_call(heff_get_n(v_t_2425, 0, 2), 1, (V[]){heff_get_n(v_e_2410, 0, 4)}));
      v_t_2427 = (g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761(heff_get_n(v_o_242, 0, 2), v_t_2422, v_t_2424, v_t_2426));
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    return heff_tag_at_n(v_ru_24t_249_24Just, TAG_Just, 1, (V[]){v_t_2427});
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2ebuild_2edriver_2esigEntry_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2esigEntry(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edriver_2esigEntry_lam0(V self, V *args) {
  V v_i_2412 = args[0];
  V v_o_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_i_2412, 0, 2), heff_get_n(v_o_242, 1, 2));
}
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str0, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str4, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str5, 4, " as ");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2eimportLines_str8, 0, "");
Clo g_heff_2ebuild_2edriver_2eimportLines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eimportLines_entry, 1, 0};

V g_heff_2ebuild_2edriver_2eimportLines(V v_c_240) {
top: ;
  V v_x2_241 = (g_list_2emap_24s499977176x606563528(((V)&g_heff_2ebuild_2edriver_2eimportLines_str0), ((V)&g_heff_2ebuild_2edriver_2eimportLines_str1), heff_take_field(v_c_240, 9)));
  V v_t_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_t_244 = ((V)&g_heff_2ebuild_2edriver_2eimportLines_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_t_244 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2eimportLines_str3); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_x2_245 = (g_list_2emap_24s268264395x330149387(((V)&g_heff_2ebuild_2edriver_2eimportLines_str4), ((V)&g_heff_2ebuild_2edriver_2eimportLines_str5), ((V)&g_heff_2ebuild_2edriver_2eimportLines_str6), heff_get_n(v_c_240, 10, 13)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ebuild_2edriver_2eimportLines_str7);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2eimportLines_str8); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return heff_strAppend(v_t_244, v_t_248);
}
V g_heff_2ebuild_2edriver_2eimportLines_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eimportLines(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2einterface_str3, 1, "\012");
V g_heff_2ebuild_2edriver_2einterface_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2einterface_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2einterface_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2einterface_entry, 1, 0};

V g_heff_2ebuild_2edriver_2einterface(V v_c_240) {
top: ;
  V v_t_241 = (g_heff_2ebuild_2edriver_2eimportLines(heff_dup(v_c_240)));
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 11)), 0, 2);
  V v_t_243 = ({ V a_0 = heff_dup(heff_rfield(v_c_240, 11)); V a_1 = MK_INT(0LL); V a_2 = v_t_242; V r_ = (g_heff_2ebuild_2edriver_2efixityLines(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
  V v_t_244 = heff_rec_n(3, shape_out__multi__first, (V[]){((V)&g_heff_2ebuild_2edriver_2einterface_str0), NTAG(TAG_False), NTAG(TAG_True)});
  V v_t_2413 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2einterface_lam0, 1, 1, (V[]){heff_dup(v_c_240)}), heff_get_n(v_c_240, 7, 13)));
  V v_t_2414 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2413));
  V v_t_2415 = ({ V a_0 = v_t_244; V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s1936649287x1723798793(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_t_2415, 0, 3), NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_2416})});
  V v_x2_2418 = (g_list_2efilter_24s2048945121x1749617505(((V)&g_heff_2ebuild_2edriver_2einterface_str1), v_t_2417));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2edriver_2einterface_str2);
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2einterface_str3); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2einterface(a[0]);
}
V g_heff_2ebuild_2edriver_2einterface_lam1(V self, V *args) {
  V v_k_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_2410 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_k_249)));
  V v_x2_2411 = ({ V a_0 = v_k_249; V a_1 = v_m_248; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_m_248); r_; });
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nothing: {
    return v_d_2410;
  }
  case TAG_Just: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    heff_take_n(v_x2_2411, 1ULL, 1);
    heff_drop(v_d_2410);
    return v_x_2412;
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2ebuild_2edriver_2einterface_lam0(V self, V *args) {
  V v_o_245 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_247 = ({ V b_0 = heff_get_n(v_t_246, 2, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_m_248 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s407249128x802036125(a_0, a_1)); heff_drop(v_t_247); r_; });
  return (g_heff_2ebuild_2edriver_2esigEntry(v_c_240, heff_clo_n(g_heff_2ebuild_2edriver_2einterface_lam1, 1, 1, (V[]){v_m_248}), v_o_245));
}
Clo g_heff_2ebuild_2edriver_2eeffectOfKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eeffectOfKey_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eeffectOfKey(V v_c_240, V v_k_241) {
top: ;
  V v_g_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_241), heff_rfield(v_g_242, 1)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(v_k_241, heff_rfield(v_g_242, 2)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_c_240, 13);
      heff_drop_rec(v_g_242, 7);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_k2_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_t_246 = ({ V a_0 = v_k2_245; V b_1 = heff_get_n(v_g_242, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        heff_drop_rec(v_c_240, 13);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_e_247 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        V v_t_248 = heff_get_n(heff_get_n(v_c_240, 5, 13), 0, 9);
        V v_t_249 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_247, 3, 4)));
        return ({ V a_0 = v_t_248; V a_1 = v_t_249; V r_ = (g_heff_2eelab_2eeffect_2ecomputationEffect(a_0, a_1)); heff_drop(v_t_249); r_; });
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_e_2410 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_241);
    heff_drop_rec(v_g_242, 7);
    V v_t_2411 = heff_get_n(heff_get_n(v_c_240, 5, 13), 0, 9);
    V v_t_2412 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2410, 3, 4)));
    return ({ V a_0 = v_t_2411; V a_1 = v_t_2412; V r_ = (g_heff_2eelab_2eeffect_2ecomputationEffect(a_0, a_1)); heff_drop(v_t_2412); r_; });
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2edriver_2eeffectOfKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eeffectOfKey(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2eappendLv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2eappendLv_entry, 2, 0};

V g_heff_2ebuild_2edriver_2eappendLv(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2ebuild_2edriver_2eappendLv(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2eappendLv_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edriver_2eappendLv(a[0], a[1]);
}
Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2ecandLeaves_entry, 1, 0};

V g_heff_2ebuild_2edriver_2ecandLeaves(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2eelab_2eeffect_2eleaves(heff_rfield(v_r_241, 2)));
    V v_t_244 = (g_heff_2ebuild_2edriver_2ecandLeaves(v_rest_242));
    return (g_heff_2ebuild_2edriver_2eappendLv(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2ecandLeaves(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efits_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edriver_2efits_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efits_str2, 16, " has the effect ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efits_str3, 142, ", which is not provided here (a module M provides its effect in M.provider.js, or M.provider.c for C, beside M.hf; `$host` says where it runs)");
V g_heff_2ebuild_2edriver_2efits_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2efits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efits_entry, 2, 0};

V g_heff_2ebuild_2edriver_2efits(V v_handled_240, V v_r_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2eeffect_2eleaves(heff_rfield(v_r_241, 2)));
  V v_t_246 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2efits_lam0, 1, 1, (V[]){heff_dup(v_handled_240)}), v_t_242));
  V v_ms_247 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_246));
  switch (heff_tag_of(v_ms_247)) {
  case TAG_Nil: {
    V v_t_248 = heff_rec_n(2, shape_key__effect, (V[]){heff_take_field(v_r_241, 1), heff_get_n(v_r_241, 2, 3)});
    return heff_tag_n(TAG_Right, 1, (V[]){v_t_248});
  }
  case TAG_Cons: {
    V v_t_2413;
    switch (heff_tag_of(v_ms_247)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ebuild_2edriver_2efits_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_ms_247, 0);
      V v_xs_2412 = heff_field(v_ms_247, 1);
      heff_take_n(v_ms_247, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2ebuild_2edriver_2efits_str1); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_ms_247);
    }
    V v_t_2414 = heff_strAppend(heff_get_n(v_r_241, 0, 3), heff_strAppend(((V)&g_heff_2ebuild_2edriver_2efits_str2), heff_strAppend(v_t_2413, ((V)&g_heff_2ebuild_2edriver_2efits_str3))));
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2414});
  }
  default: return heff_nomatch(v_ms_247);
  }
}
V g_heff_2ebuild_2edriver_2efits_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2efits(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2efits_lam0(V self, V *args) {
  V v_l_243 = args[0];
  V v_handled_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_l_243}));
  V v_x1_245 = ({ V a_0 = v_t_244; V a_1 = v_handled_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_handled_240); r_; });
  switch (heff_tag_of(v_x1_245)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_245);
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efindFirst_str0, 32, "no computation, `Co h a`, to run");
V g_heff_2ebuild_2edriver_2efindFirst_lam1(V self, V *args);
V g_heff_2ebuild_2edriver_2efindFirst_lam0(V self, V *args);
Clo g_heff_2ebuild_2edriver_2efindFirst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efindFirst_entry, 2, 0};

V g_heff_2ebuild_2edriver_2efindFirst(V v_handled_240, V v_cands_241) {
top: ;
  V v_t_2411 = (g_list_2efind(heff_clo_n(g_heff_2ebuild_2edriver_2efindFirst_lam0, 1, 1, (V[]){heff_dup(v_handled_240)}), v_cands_241));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_cands_241)) {
    case TAG_Nil: {
      return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ebuild_2edriver_2efindFirst_str0)});
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_cands_241, 0);
      HEFF_LAST return g_heff_2ebuild_2edriver_2efits(v_handled_240, heff_dup(v_x_2412));
    }
    default: return heff_nomatch(v_cands_241);
    }
  }
  case TAG_Just: {
    V v_r_2414 = heff_field(v_t_2411, 0);
    V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 1ULL, 1);
    V v_t_2415 = heff_rec_n(2, shape_key__effect, (V[]){heff_take_field(v_r_2414, 1), heff_get_n(v_r_2414, 2, 3)});
    return heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Right, 1, (V[]){v_t_2415});
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2ebuild_2edriver_2efindFirst_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2edriver_2efindFirst(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ebuild_2edriver_2efindFirst_lam1(V self, V *args) {
  V v_l_244 = args[0];
  V v_handled_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_l_244}));
  V v_x1_246 = ({ V a_0 = v_t_245; V a_1 = v_handled_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_handled_240); r_; });
  switch (heff_tag_of(v_x1_246)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2ebuild_2edriver_2efindFirst_lam0(V self, V *args) {
  V v_r_242 = args[0];
  V v_handled_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = ({ V b_0 = heff_get_n(v_r_242, 2, 3); V r_ = (g_heff_2eelab_2eeffect_2eleaves(b_0)); heff_drop(b_0); r_; });
  V v_t_247 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edriver_2efindFirst_lam1, 1, 1, (V[]){v_handled_240}), v_t_243));
  V v_x1_248 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_247));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    heff_take_n(v_x1_248, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_248);
  }
}
HEFF_LIT(g_heff_2ebuild_2edriver_2efindRunnable_str0, 14, "no definition ");
HEFF_LIT(g_heff_2ebuild_2edriver_2efindRunnable_str1, 31, " is not a computation, `Co h a`");
V g_heff_2ebuild_2edriver_2efindRunnable_lam0(V self, V *args);
V g_heff_2ebuild_2edriver_2efindRunnable_lam1(V self, V *args);
Clo g_heff_2ebuild_2edriver_2efindRunnable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edriver_2efindRunnable_entry, 3, 0};

V g_heff_2ebuild_2edriver_2efindRunnable(V v_handled_240, V v_c_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_247 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edriver_2efindRunnable_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), heff_get_n(v_c_241, 7, 13)));
    V v_t_248 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_247));
    return ({ V a_0 = v_handled_240; V a_1 = v_t_248; V r_ = (g_heff_2ebuild_2edriver_2efindFirst(a_0, a_1)); heff_drop(v_t_248); r_; });
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_2411 = (g_list_2efind(heff_clo_n(g_heff_2ebuild_2edriver_2efindRunnable_lam1, 1, 1, (V[]){heff_dup(v_x_249)}), heff_rfield(v_c_241, 7)));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nothing: {
      heff_drop_rec(v_c_241, 13);
      return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2edriver_2efindRunnable_str0), v_x_249)});
    }
    case TAG_Just: {
      V v_o_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      V v_t_2413 = (g_heff_2ebuild_2edriver_2eeffectOfKey(v_c_241, heff_dup(heff_rfield(v_o_2412, 1))));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        heff_drop_rec(v_o_2412, 2);
        return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Left, 1, (V[]){heff_strAppend(v_x_249, ((V)&g_heff_2ebuild_2edriver_2efindRunnable_str1))});
      }
      case TAG_Just: {
        V v_eff_2414 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        V v_t_2415 = heff_rec_n(3, shape_name__key__effect, (V[]){v_x_249, heff_get_n(v_o_2412, 1, 2), v_eff_2414});
        return (g_heff_2ebuild_2edriver_2efits(v_handled_240, v_t_2415));
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edriver_2efindRunnable_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edriver_2efindRunnable(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2edriver_2efindRunnable_lam0(V self, V *args) {
  V v_o_243 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2ebuild_2edriver_2eeffectOfKey(v_c_241, heff_dup(heff_rfield(v_o_243, 1))));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_243, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_eff_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_246 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_243, 0), heff_get_n(v_o_243, 1, 2), v_eff_245});
    return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){v_t_246});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ebuild_2edriver_2efindRunnable_lam1(V self, V *args) {
  V v_o_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(heff_get_n(v_o_2410, 0, 2), v_x_249);
}