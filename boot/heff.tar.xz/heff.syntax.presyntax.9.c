// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CAnnLam 19336
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndValue 24675
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkSegment 38079
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetPath 11095
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define LBL_args 9498020
#define LBL_depth 296830685
#define LBL_head 9693863
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_sp 10436
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_names__muts__loop__sp__depth[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s112965014x579570295_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s2006690287x151588326_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2eelseFalls_get(void);
V g_heff_2esyntax_2epresyntax_2eelseLeaving(V, V);
V g_heff_2esyntax_2epresyntax_2eelseLeaving_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eelseLeaving_clo;
V g_heff_2esyntax_2epresyntax_2ehasNest(V);
V g_heff_2esyntax_2epresyntax_2ehasNest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ehasNest_clo;
V g_heff_2esyntax_2epresyntax_2eidNames_get(void);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2erunArgs(V, V);
V g_heff_2esyntax_2epresyntax_2erunArgs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2erunArgs_clo;
V g_heff_2esyntax_2epresyntax_2esizeTerm(V, V, V);
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240(V);
V g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2eutf8Of(V);
V g_heff_2esyntax_2epresyntax_2eutf8Of_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eutf8Of_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatSpineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epatSpineOf(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_dup(heff_field(v_p_240, 0));
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatTag: {
      V v_t_244 = heff_field(v_p1_241, 0);
      V v_tsp_245 = heff_field(v_p1_241, 1);
      V v_ps_246 = heff_field(v_p1_241, 2);
      V v_ru_24p1_241_24PatTag = heff_take_reuse_n(v_p1_241, 7ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24p1_241_24PatTag, TAG_PatTag, 3, (V[]){v_t_244, heff_dup(v_tsp_245), NTAG(TAG_Nil)});
      return heff_rec_n(2, shape_head__args, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_tsp_245}), v_ps_246});
    }
    case TAG_PatOp: {
      V v_x_248 = heff_field(v_p1_241, 0);
      V v_xsp_249 = heff_field(v_p1_241, 1);
      V v_ps_2410 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 7ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_248}), v_xsp_249});
      return heff_rec_n(2, shape_head__args, (V[]){v_t_2411, v_ps_2410});
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatBinary: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatRecord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatAs: {
      heff_take_n(v_p1_241, 0ULL, 3);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatSpineOf(a[0]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s2006690287x151588326_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkSegment: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_a_2410 = heff_field(v_a_244, 4);
        heff_take_n(v_a_244, 31ULL, 5);
        V v_a_2411;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2411 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_2411 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_246)));
        }
        HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2eaccList_24s2006690287x151588326_24cpr(v_a_2411, v_xs_243));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v_x_2415 = v_field_2413;
          V v_y_2416 = v_field_2414;
          V v_t_2417 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkSegment, 5, (V[]){v_a_246, v_a_247, v_a_248, v_a_249, v_a_2410}), v_a_245});
          return ((HeffT2){{v_x_2415, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2417, v_y_2416})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s112965014x579570295_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        heff_take_n(v_a_244, 3ULL, 2);
        V v_a_248;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_248 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_248 = (g_heff_2esyntax_2epresyntax_2ehasNest(heff_dup(v_a_247)));
        }
        HeffT2 v_t_249 = (g_heff_2esyntax_2epresyntax_2eaccList_24s112965014x579570295_24cpr(v_a_248, v_xs_243));
        {
          V v_field_2410 = v_t_249.f[0];
          V v_field_2411 = v_t_249.f[1];
          V v_x_2412 = v_field_2410;
          V v_y_2413 = v_field_2411;
          V v_t_2414 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetPath, 2, (V[]){v_a_246, v_a_247}), v_a_245});
          return ((HeffT2){{v_x_2412, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2414, v_y_2413})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2eelseLeaving_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eelseLeaving_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eelseLeaving(V v_sp_240, V v_ss_241) {
top: ;
  V v_x1_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_241)));
  V v_t_2419;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    v_t_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    switch (heff_tag_of(v_x_243)) {
    case TAG_At: {
      V v_it11_245 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 2);
      switch (heff_tag_of(v_it11_245)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_245, 0ULL, 3);
        v_t_2419 = NTAG(TAG_False);
        break;
      }
      case TAG_StmtLet: {
        heff_take_n(v_it11_245, 0ULL, 2);
        v_t_2419 = NTAG(TAG_False);
        break;
      }
      case TAG_StmtExpr: {
        V v_e_2412 = heff_field(v_it11_245, 0);
        heff_take_n(v_it11_245, 1ULL, 1);
        v_t_2419 = (g_heff_2esyntax_2epresyntax_2estmtsLeave_2eleaves_240(v_e_2412));
        break;
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_245, 0ULL, 3);
        v_t_2419 = NTAG(TAG_False);
        break;
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_245, 0ULL, 3);
        v_t_2419 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_it11_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_sp_240);
    heff_drop(v_t_2419);
    return v_ss_241;
  } else {
    heff_drop(v_t_2419);
    V v_x1_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_241));
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Nil: {
      V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2eelseFalls_get())}), heff_dup(v_sp_240)});
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2421}), v_sp_240});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x1_2420, 0);
      V v_ru_24x1_2420_24Cons = heff_take_reuse_n(v_x1_2420, 1ULL, 2);
      heff_drop(v_sp_240);
      switch (heff_tag_of(v_x_2423)) {
      case TAG_At: {
        V v_esp_2426 = heff_field(v_x_2423, 1);
        V v_ru_24x_2423_24At = heff_take_reuse_n(v_x_2423, 2ULL, 2);
        V v_t_2427 = heff_tag_at_n(v_ru_24x_2423_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2eelseFalls_get())}), heff_dup(v_esp_2426)});
        V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2427}), v_esp_2426});
        return heff_tag_at_n(v_ru_24x1_2420_24Cons, TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_x_2423);
      }
    }
    default: return heff_nomatch(v_x1_2420);
    }
  }
}
V g_heff_2esyntax_2epresyntax_2eelseLeaving_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eelseLeaving(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str0, 3, "run");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str1, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str2, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str3, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str4, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2erunArgs_str5, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2erunArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2erunArgs_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2erunArgs(V v_h_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_At: {
    V v_h1_242 = heff_field(v_h_240, 0);
    V v_ru_24h_240_24At = heff_take_reuse_n(v_h_240, 1ULL, 2);
    switch (heff_tag_of(v_h1_242)) {
    case TAG_EVar: {
      V v_f_244 = heff_field(v_h1_242, 0);
      heff_take_n(v_h1_242, 1ULL, 1);
      switch (heff_tag_of(v_args_241)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24h_240_24At, 2);
        heff_drop(v_f_244);
        return v_args_241;
      }
      case TAG_Cons: {
        V v_args1_245 = heff_dup(heff_field(v_args_241, 0));
        V v_args2_246 = heff_dup(heff_field(v_args_241, 1));
        switch (heff_tag_of(v_args1_245)) {
        case TAG_At: {
          V v_args11_247 = heff_field(v_args1_245, 0);
          V v_dsp_248 = heff_field(v_args1_245, 1);
          V v_ru_24args1_245_24At = heff_take_reuse_n(v_args1_245, 3ULL, 2);
          switch (heff_tag_of(v_args11_247)) {
          case TAG_EVar: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EImplicitVar: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ETag: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EInt: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EFloat: {
            heff_take_na(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EString: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EBinary: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ERune: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EWord: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EApp: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EProject: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ENamed: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EPi: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ELam: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EAnn: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ESpec: {
            heff_take_n(v_args11_247, 0ULL, 4);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ESig: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ESum: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EStruct: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EUpdate: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EMatch: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ELetIn: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EDo: {
            V v_ss_2442 = heff_field(v_args11_247, 0);
            heff_take_n(v_args11_247, 1ULL, 1);
            switch (heff_tag_of(v_args2_246)) {
            case TAG_Nil: {
              heff_drop_tag(v_args_241, 2);
              if (heff_strEq_c(v_f_244, ((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str0))) {
                V v_x1_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_2442)));
                V v_t_2463;
                switch (heff_tag_of(v_x1_2444)) {
                case TAG_Nil: {
                  heff_drop(v_ss_2442);
                  v_t_2463 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str1)}), v_dsp_248});
                  break;
                }
                case TAG_Cons: {
                  V v_x_2445 = heff_field(v_x1_2444, 0);
                  heff_take_n(v_x1_2444, 1ULL, 2);
                  switch (heff_tag_of(v_x_2445)) {
                  case TAG_At: {
                    V v_it11_2447 = heff_field(v_x_2445, 0);
                    heff_take_n(v_x_2445, 1ULL, 2);
                    switch (heff_tag_of(v_it11_2447)) {
                    case TAG_StmtBind: {
                      heff_take_n(v_it11_2447, 0ULL, 3);
                      heff_drop(v_ss_2442);
                      v_t_2463 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str2)}), v_dsp_248});
                      break;
                    }
                    case TAG_StmtLet: {
                      heff_take_n(v_it11_2447, 0ULL, 2);
                      heff_drop(v_ss_2442);
                      v_t_2463 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str3)}), v_dsp_248});
                      break;
                    }
                    case TAG_StmtExpr: {
                      heff_take_n(v_it11_2447, 0ULL, 1);
                      heff_drop_cell(v_ru_24h_240_24At, 2);
                      V v_t_2455 = heff_rec_n(5, shape_names__muts__loop__sp__depth, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2eidNames_get()), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_dsp_248, MK_INT(0LL)});
                      V v_t_2456 = ({ V a_0 = v_t_2455; V a_1 = v_ss_2442; V a_2 = NTAG(TAG_EndValue); V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_ss_2442); r_; });
                      v_t_2463 = v_t_2456;
                      break;
                    }
                    case TAG_StmtLetMut: {
                      heff_take_n(v_it11_2447, 0ULL, 3);
                      heff_drop(v_ss_2442);
                      v_t_2463 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str4)}), v_dsp_248});
                      break;
                    }
                    case TAG_StmtLetElse: {
                      heff_take_n(v_it11_2447, 0ULL, 3);
                      heff_drop(v_ss_2442);
                      v_t_2463 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2erunArgs_str5)}), v_dsp_248});
                      break;
                    }
                    default: heff_nomatch(v_it11_2447);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x_2445);
                  }
                  break;
                }
                default: heff_nomatch(v_x1_2444);
                }
                return heff_tag_at_n(v_ru_24args1_245_24At, TAG_Cons, 2, (V[]){v_t_2463, NTAG(TAG_Nil)});
              } else {
                V v_t_2464 = heff_tag_at_n(v_ru_24h_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EDo, 1, (V[]){v_ss_2442}), v_dsp_248});
                return heff_tag_at_n(v_ru_24args1_245_24At, TAG_Cons, 2, (V[]){v_t_2464, NTAG(TAG_Nil)});
              }
            }
            case TAG_Cons: {
              heff_take_n(v_args2_246, 0ULL, 2);
              heff_drop_cell(v_ru_24h_240_24At, 2);
              heff_drop(v_f_244);
              heff_drop(v_dsp_248);
              heff_drop_cell(v_ru_24args1_245_24At, 2);
              heff_drop(v_ss_2442);
              return v_args_241;
            }
            default: return heff_nomatch(v_args2_246);
            }
          }
          case TAG_ELocal: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EInvalid: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EAssign: {
            heff_take_n(v_args11_247, 0ULL, 3);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EWhile: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EFor: {
            heff_take_n(v_args11_247, 0ULL, 3);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EIfThen: {
            heff_take_n(v_args11_247, 0ULL, 2);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EBreak: {
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EContinue: {
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EReturn: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ENest: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ELazy: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ETuple: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_ETry: {
            heff_take_n(v_args11_247, 0ULL, 1);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          case TAG_EWith: {
            heff_take_n(v_args11_247, 0ULL, 4);
            heff_drop_cell(v_ru_24h_240_24At, 2);
            heff_drop(v_f_244);
            heff_drop(v_args2_246);
            heff_drop(v_dsp_248);
            heff_drop_cell(v_ru_24args1_245_24At, 2);
            return v_args_241;
          }
          default: return heff_nomatch(v_args11_247);
          }
        }
        default: return heff_nomatch(v_args1_245);
        }
      }
      default: return heff_nomatch(v_args_241);
      }
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ETag: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EInt: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EFloat: {
      heff_take_na(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EString: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EBinary: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ERune: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EWord: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EApp: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EProject: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ENamed: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EPi: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELam: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EAnn: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ESpec: {
      heff_take_n(v_h1_242, 0ULL, 4);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ESig: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ESum: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EStruct: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EUpdate: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELetIn: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EDo: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELocal: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EInvalid: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EAssign: {
      heff_take_n(v_h1_242, 0ULL, 3);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EWhile: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EFor: {
      heff_take_n(v_h1_242, 0ULL, 3);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EIfThen: {
      heff_take_n(v_h1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EBreak: {
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EContinue: {
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EReturn: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ENest: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ELazy: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ETuple: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_ETry: {
      heff_take_n(v_h1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    case TAG_EWith: {
      heff_take_n(v_h1_242, 0ULL, 4);
      heff_drop_cell(v_ru_24h_240_24At, 2);
      return v_args_241;
    }
    default: return heff_nomatch(v_h1_242);
    }
  }
  default: return heff_nomatch(v_h_240);
  }
}
V g_heff_2esyntax_2epresyntax_2erunArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2erunArgs(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eannLamOf_24cpr(V v_x_240, V v_xsp_241, V v_t_242, V v_x4_243, V v_sp_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_IsInferable: {
    V v_b_245 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_b_245}), v_sp_244});
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_t_246}});
  }
  case TAG_IsCheckable: {
    V v_t_2417;
    switch (heff_tag_of(v_x4_243)) {
    case TAG_IsInferable: {
      V v_i_248 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsInferable = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_i_248)) {
      case TAG_At: {
        V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
        v_t_2411 = v_s_2410;
        break;
      }
      default: heff_nomatch(v_i_248);
      }
      v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2412 = heff_field(v_x4_243, 0);
      heff_take_n(v_x4_243, 1ULL, 1);
      v_t_2417 = v_c_2412;
      break;
    }
    case TAG_IsType: {
      V v_t_2413 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsType = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2416;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_At: {
        V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
        v_t_2416 = v_s_2415;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsType, TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
      break;
    }
    default: heff_nomatch(v_x4_243);
    }
    V v_f_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2417}), v_sp_244});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
  }
  case TAG_IsType: {
    V v_t_2429;
    switch (heff_tag_of(v_x4_243)) {
    case TAG_IsInferable: {
      V v_i_2420 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsInferable = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2423;
      switch (heff_tag_of(v_i_2420)) {
      case TAG_At: {
        V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
        v_t_2423 = v_s_2422;
        break;
      }
      default: heff_nomatch(v_i_2420);
      }
      v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2424 = heff_field(v_x4_243, 0);
      heff_take_n(v_x4_243, 1ULL, 1);
      v_t_2429 = v_c_2424;
      break;
    }
    case TAG_IsType: {
      V v_t_2425 = heff_field(v_x4_243, 0);
      V v_ru_24x4_243_24IsType = heff_take_reuse_n(v_x4_243, 1ULL, 1);
      V v_t_2428;
      switch (heff_tag_of(v_t_2425)) {
      case TAG_At: {
        V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
        v_t_2428 = v_s_2427;
        break;
      }
      default: heff_nomatch(v_t_2425);
      }
      v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_243_24IsType, TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
      break;
    }
    default: heff_nomatch(v_x4_243);
    }
    V v_f_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2429}), v_sp_244});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2430}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkSegment: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_size_243 = heff_field(v_x1_240, 2);
    V v_little_244 = heff_field(v_x1_240, 3);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_At: {
      V v_x111_246 = heff_field(v_x11_241, 0);
      switch (heff_tag_of(v_x111_246)) {
      case TAG_EVar: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EImplicitVar: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETag: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EInt: {
        V v_v_2411 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return (g_heff_2esyntax_2epresyntax_2ewholeInteger_24cpr(v_size_243, v_little_244, heff_dup(v_v_2411)));
        }
        case TAG_SegmentBinary: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBits: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentUtf: {
          V v_x121_2412 = heff_field(v_x12_242, 0);
          if (heff_intEq_c_lent(v_x121_2412, MK_INT(8LL), 2)) {
            V v_f_2414 = (g_heff_2esyntax_2epresyntax_2eutf8Of(heff_dup(v_v_2411)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
        }
      }
      case TAG_EFloat: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EString: {
        V v_s_2416 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBinary: {
          switch (heff_tag_of(v_size_243)) {
          case TAG_SizeDefault: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_s_2416)}});
          }
          case TAG_SizeNumber: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_SizeName: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_size_243)}});
          }
        }
        case TAG_SegmentBits: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentUtf: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
        }
      }
      case TAG_EBinary: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ERune: {
        V v_c_2423 = heff_field(v_x111_246, 0);
        switch (heff_tag_of(v_x12_242)) {
        case TAG_SegmentInteger: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBinary: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentBits: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentFloat: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_SegmentUtf: {
          V v_x121_2424 = heff_field(v_x12_242, 0);
          if (heff_intEq_c_lent(v_x121_2424, MK_INT(8LL), 2)) {
            V v_f_2426 = (g_heff_2esyntax_2epresyntax_2eutf8Of(heff_dup(v_c_2423)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2426}});
          } else {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
        }
      }
      case TAG_EWord: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EApp: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EProject: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ENamed: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EPi: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELam: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAnn: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESpec: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESig: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ESum: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EStruct: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EUpdate: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EMatch: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELetIn: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EDo: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELocal: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EInvalid: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EAssign: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EWhile: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EFor: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EIfThen: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EBreak: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EContinue: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EReturn: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ENest: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ELazy: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETuple: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_ETry: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_EWith: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x111_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2esizeTerm_str0, 6, "intMul");
Clo g_heff_2esyntax_2epresyntax_2esizeTerm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2esizeTerm_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2esizeTerm(V v_x1_240, V v_x2_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SizeDefault: {
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_x2_241}), heff_dup(v_sp_242)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_243}), v_sp_242});
  }
  case TAG_SizeNumber: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SizeNumber = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    heff_drop(v_x2_241);
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24SizeNumber, TAG_IInt, 1, (V[]){v_m_244}), heff_dup(v_sp_242)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_245}), v_sp_242});
  }
  case TAG_SizeName: {
    V v_x_246 = heff_field(v_x1_240, 0);
    V v_xsp_247 = heff_field(v_x1_240, 1);
    V v_x13_248 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    heff_drop(v_x2_241);
    if (heff_intEq_c_lent(v_x13_248, MK_INT(1LL), 2)) {
      heff_drop(v_sp_242);
      heff_drop(v_x13_248);
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2410}), v_xsp_247});
    } else {
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), heff_dup(v_xsp_247)});
      V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2411}), v_xsp_247});
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_x13_248}), heff_dup(v_sp_242)});
      V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2413}), heff_dup(v_sp_242)});
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      V v_t_2416 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_242), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2415})));
      V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2esizeTerm_str0)}), heff_dup(v_sp_242)});
      V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2417, v_t_2416}), heff_dup(v_sp_242)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2418}), v_sp_242});
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2esizeTerm_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2esizeTerm(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_IVar: {
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_244 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_243, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_240});
  }
  case TAG_IInt: {
    V v_t_246 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_247 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_IFloat: {
    V v_t_249 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2410 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_sp_240});
  }
  case TAG_IString: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2413 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_IBytes: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2416 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2415, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2416, v_sp_240});
  }
  case TAG_IPrim: {
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2419 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_IRune: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2422 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_sp_240});
  }
  case TAG_IApp: {
    V v_t_2425 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2426 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2425, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2426, v_sp_240});
  }
  case TAG_IAnn: {
    V v_c_2427 = heff_field(v_n_241, 0);
    V v_t_2428 = heff_field(v_n_241, 1);
    V v_ru_24n_241_24IAnn = heff_take_reuse_n(v_n_241, 3ULL, 2);
    V v_t_2431;
    switch (heff_tag_of(v_c_2427)) {
    case TAG_At: {
      V v_n_2429 = heff_field(v_c_2427, 0);
      V v_sp_2430 = heff_field(v_c_2427, 1);
      heff_take_n(v_c_2427, 3ULL, 2);
      v_t_2431 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2430, v_n_2429));
      break;
    }
    default: heff_nomatch(v_c_2427);
    }
    V v_t_2434;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_At: {
      V v_n_2432 = heff_field(v_t_2428, 0);
      V v_sp_2433 = heff_field(v_t_2428, 1);
      heff_take_n(v_t_2428, 3ULL, 2);
      v_t_2434 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2433, v_n_2432));
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24IAnn, TAG_IAnn, 2, (V[]){v_t_2431, v_t_2434}), v_sp_240});
  }
  case TAG_ISpec: {
    V v_t_2439 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2440 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2439, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_sp_240});
  }
  case TAG_IUpdate: {
    V v_t_2443 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2444 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2443, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2444, v_sp_240});
  }
  case TAG_IAnnLam: {
    V v_t_2449 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2450 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2449, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2450, v_sp_240});
  }
  case TAG_IInvalid: {
    V v_code_2451 = heff_field(v_n_241, 0);
    V v_why_2452 = heff_field(v_n_241, 1);
    V v_note_2453 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24IInvalid = heff_take_reuse_n(v_n_241, 7ULL, 3);
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24IInvalid, TAG_IInvalid, 3, (V[]){v_code_2451, v_why_2452, v_note_2453}), v_sp_240});
  }
  case TAG_INominal: {
    V v_t_2455 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2456 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2455, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2456, v_sp_240});
  }
  case TAG_ILitEq: {
    V v_t_2461 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2462 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2461, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2462, v_sp_240});
  }
  case TAG_ILazy: {
    V v_t_2464 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2465 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2464, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2465, v_sp_240});
  }
  case TAG_ITuple: {
    V v_t_2467 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2468 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2467, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2468, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(a[0], a[1]);
}