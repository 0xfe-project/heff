// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_BadFieldDecl 11244
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclTheory 39552
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_EUSet 22856
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_fixities 357800079
#define LBL_items 301884378
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_pat 320285
#define LBL_prims 308293287
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_decls__diags__fixities__broken[] = {LBL_decls, LBL_diags, LBL_fixities, LBL_broken};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24dps_clo;
V g_heff_2esyntax_2esurface_2eassembleDiagOne(V, V, V, V);
V g_heff_2esyntax_2esurface_2eassembleDiagOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleDiagOne_clo;
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
V g_heff_2esyntax_2esurface_2eatomOf(V);
V g_heff_2esyntax_2esurface_2eatomOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomOf_clo;
V g_heff_2esyntax_2esurface_2eblock_24s611148689x133456453(V, V);
V g_heff_2esyntax_2esurface_2eblock_24s611148689x133456453_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_24s611148689x133456453_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2edataParamL(V, V);
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_clo;
V g_heff_2esyntax_2esurface_2edataParamOf(V, V);
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2efieldDeclOf(V, V);
V g_heff_2esyntax_2esurface_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldDeclOf_clo;
V g_heff_2esyntax_2esurface_2efieldL(V, V);
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldL_clo;
V g_heff_2esyntax_2esurface_2eifE(V, V, V, V);
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifE_clo;
V g_heff_2esyntax_2esurface_2enameAnn(V);
V g_heff_2esyntax_2esurface_2enameAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameAnn_clo;
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2ereadPlaced(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadPlaced_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadPlaced_clo;
V g_heff_2esyntax_2esurface_2esettingsOf(V);
V g_heff_2esyntax_2esurface_2esettingsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingsOf_clo;
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2esplitExp(V, V);
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esplitExp_clo;
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_clo;
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(V);
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_map_2eempty_get(void);
Clo g_heff_2esyntax_2esurface_2eappendS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2esyntax_2esurface_2eappendS_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2esplitExp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esplitExp_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esplitExp(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return heff_strLength(v_s_240);
  } else {
    if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(101LL))) {
      heff_drop(v_s_240);
      return v_i_241;
    } else {
      if (heff_intEq_c(heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(69LL))) {
        heff_drop(v_s_240);
        return v_i_241;
      } else {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esplitExp(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2esettingsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esettingsOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2esettingsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EParen: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Named: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Tup: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Braces: {
    V v_x12_2415 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_2415)) {
    case TAG_Nil: {
      return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      V v_x121_2418 = heff_field(v_x12_2415, 0);
      switch (heff_tag_of(v_x121_2418)) {
      case TAG_Atom: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EParen: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Named: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Tup: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Braces: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Update: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EUSet: {
        return NTAG(TAG_Nothing);
      }
      case TAG_InstB: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EFSet: {
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x12_2415)});
      }
      case TAG_EFDefault: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Sum: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ECon: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EField: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ENeg: {
        return NTAG(TAG_Nothing);
      }
      case TAG_App: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Op: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Ops: {
        return NTAG(TAG_Nothing);
      }
      case TAG_OpRhs: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Ann: {
        return NTAG(TAG_Nothing);
      }
      case TAG_BVar: {
        return NTAG(TAG_Nothing);
      }
      case TAG_BImp: {
        return NTAG(TAG_Nothing);
      }
      case TAG_BAnn: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Lam: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Case: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EAlt: {
        return NTAG(TAG_Nothing);
      }
      case TAG_If: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Do: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ESBind: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ELet: {
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x121_2418);
      }
    }
    default: return heff_nomatch(v_x12_2415);
    }
  }
  case TAG_Update: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EUSet: {
    return NTAG(TAG_Nothing);
  }
  case TAG_InstB: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFSet: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Sum: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ECon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EField: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ENeg: {
    return NTAG(TAG_Nothing);
  }
  case TAG_App: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Op: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Ops: {
    return NTAG(TAG_Nothing);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Ann: {
    return NTAG(TAG_Nothing);
  }
  case TAG_BVar: {
    return NTAG(TAG_Nothing);
  }
  case TAG_BImp: {
    return NTAG(TAG_Nothing);
  }
  case TAG_BAnn: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Lam: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Case: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EAlt: {
    return NTAG(TAG_Nothing);
  }
  case TAG_If: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Do: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ESBind: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2esettingsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esettingsOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldL_str0, 1, "=");
V g_heff_2esyntax_2esurface_2efieldL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam28(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efieldL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efieldL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efieldL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    V v_m_243 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EParen: {
    V v_m_2414 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam1, 1, 1, (V[]){v_m_2414});
  }
  case TAG_Named: {
    V v_m_2427 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam2, 1, 1, (V[]){v_m_2427});
  }
  case TAG_Tup: {
    V v_m_2439 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam3, 1, 1, (V[]){v_m_2439});
  }
  case TAG_Braces: {
    V v_m_2451 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam4, 1, 1, (V[]){v_m_2451});
  }
  case TAG_Update: {
    V v_m_2465 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam5, 1, 1, (V[]){v_m_2465});
  }
  case TAG_EUSet: {
    V v_m_2476 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam6, 1, 1, (V[]){v_m_2476});
  }
  case TAG_InstB: {
    V v_m_2489 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam7, 1, 1, (V[]){v_m_2489});
  }
  case TAG_EFSet: {
    V v_m_24100 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam8, 1, 1, (V[]){v_m_24100});
  }
  case TAG_EFDefault: {
    V v_e1_24108 = heff_field(v_e_241, 0);
    V v_eq_24109 = heff_field(v_e_241, 1);
    V v_d_24110 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_24111 = (g_heff_2esyntax_2esurface_2edeclarationL(heff_dup(v_r_240), v_e1_24108));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam9, 1, 4, (V[]){v_m_24111, v_r_240, v_d_24110, v_eq_24109});
  }
  case TAG_Sum: {
    V v_m_24134 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam10, 1, 1, (V[]){v_m_24134});
  }
  case TAG_ECon: {
    V v_m_24144 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam11, 1, 1, (V[]){v_m_24144});
  }
  case TAG_EField: {
    V v_m_24154 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam12, 1, 1, (V[]){v_m_24154});
  }
  case TAG_ENeg: {
    V v_m_24164 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam13, 1, 1, (V[]){v_m_24164});
  }
  case TAG_App: {
    V v_m_24174 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam14, 1, 1, (V[]){v_m_24174});
  }
  case TAG_Op: {
    V v_m_24185 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam15, 1, 1, (V[]){v_m_24185});
  }
  case TAG_Ops: {
    V v_m_24195 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam16, 1, 1, (V[]){v_m_24195});
  }
  case TAG_OpRhs: {
    V v_m_24205 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam17, 1, 1, (V[]){v_m_24205});
  }
  case TAG_Ann: {
    V v_m_24216 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam18, 1, 1, (V[]){v_m_24216});
  }
  case TAG_BVar: {
    V v_m_24225 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam19, 1, 1, (V[]){v_m_24225});
  }
  case TAG_BImp: {
    V v_m_24236 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam20, 1, 1, (V[]){v_m_24236});
  }
  case TAG_BAnn: {
    V v_m_24249 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam21, 1, 1, (V[]){v_m_24249});
  }
  case TAG_Lam: {
    V v_m_24261 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam22, 1, 1, (V[]){v_m_24261});
  }
  case TAG_Case: {
    V v_m_24273 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam23, 1, 1, (V[]){v_m_24273});
  }
  case TAG_EAlt: {
    V v_m_24284 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam24, 1, 1, (V[]){v_m_24284});
  }
  case TAG_If: {
    V v_m_24298 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam25, 1, 1, (V[]){v_m_24298});
  }
  case TAG_Do: {
    V v_m_24308 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam26, 1, 1, (V[]){v_m_24308});
  }
  case TAG_ESBind: {
    V v_m_24319 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam27, 1, 1, (V[]){v_m_24319});
  }
  case TAG_ELet: {
    V v_m_24333 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam28, 1, 1, (V[]){v_m_24333});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efieldL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2efieldL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      V v_x_2410 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_249, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2410}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam1(V self, V *args) {
  V v_st_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_st_2415}));
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_MkPair: {
    V v_x11_2417 = heff_field(v_x1_2416, 0);
    V v_st_2418 = heff_field(v_x1_2416, 1);
    V v_ru_24x1_2416_24MkPair = heff_take_reuse_n(v_x1_2416, 3ULL, 2);
    switch (heff_tag_of(v_x11_2417)) {
    case TAG_Left: {
      V v_e_2419 = heff_field(v_x11_2417, 0);
      heff_take_n(v_x11_2417, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2419}), v_st_2418});
    }
    case TAG_Right: {
      V v_x_2420 = heff_field(v_x11_2417, 0);
      heff_take_n(v_x11_2417, 1ULL, 1);
      V v_x_2421 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2420, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2421}), v_st_2418});
    }
    default: return heff_nomatch(v_x11_2417);
    }
  }
  default: return heff_nomatch(v_x1_2416);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam2(V self, V *args) {
  V v_st_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_st_2428}));
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_MkPair: {
    V v_x11_2430 = heff_field(v_x1_2429, 0);
    V v_st_2431 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24MkPair = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_Left: {
      V v_e_2432 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2432}), v_st_2431});
    }
    case TAG_Right: {
      V v_x_2433 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      V v_x_2434 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2433, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2434}), v_st_2431});
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_2429);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam3(V self, V *args) {
  V v_st_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_st_2440}));
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_MkPair: {
    V v_x11_2442 = heff_field(v_x1_2441, 0);
    V v_st_2443 = heff_field(v_x1_2441, 1);
    V v_ru_24x1_2441_24MkPair = heff_take_reuse_n(v_x1_2441, 3ULL, 2);
    switch (heff_tag_of(v_x11_2442)) {
    case TAG_Left: {
      V v_e_2444 = heff_field(v_x11_2442, 0);
      heff_take_n(v_x11_2442, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2444}), v_st_2443});
    }
    case TAG_Right: {
      V v_x_2445 = heff_field(v_x11_2442, 0);
      heff_take_n(v_x11_2442, 1ULL, 1);
      V v_x_2446 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2445, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2446}), v_st_2443});
    }
    default: return heff_nomatch(v_x11_2442);
    }
  }
  default: return heff_nomatch(v_x1_2441);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam4(V self, V *args) {
  V v_st_2452 = args[0];
  V v_m_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2453 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_st_2452}));
  switch (heff_tag_of(v_x1_2453)) {
  case TAG_MkPair: {
    V v_x11_2454 = heff_field(v_x1_2453, 0);
    V v_st_2455 = heff_field(v_x1_2453, 1);
    V v_ru_24x1_2453_24MkPair = heff_take_reuse_n(v_x1_2453, 3ULL, 2);
    switch (heff_tag_of(v_x11_2454)) {
    case TAG_Left: {
      V v_e_2456 = heff_field(v_x11_2454, 0);
      heff_take_n(v_x11_2454, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2456}), v_st_2455});
    }
    case TAG_Right: {
      V v_x_2457 = heff_field(v_x11_2454, 0);
      heff_take_n(v_x11_2454, 1ULL, 1);
      V v_x_2458 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2457, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2458}), v_st_2455});
    }
    default: return heff_nomatch(v_x11_2454);
    }
  }
  default: return heff_nomatch(v_x1_2453);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam5(V self, V *args) {
  V v_st_2466 = args[0];
  V v_m_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2467 = heff_tr(heff_call(v_m_2465, 1, (V[]){v_st_2466}));
  switch (heff_tag_of(v_x1_2467)) {
  case TAG_MkPair: {
    V v_x11_2468 = heff_field(v_x1_2467, 0);
    V v_st_2469 = heff_field(v_x1_2467, 1);
    V v_ru_24x1_2467_24MkPair = heff_take_reuse_n(v_x1_2467, 3ULL, 2);
    switch (heff_tag_of(v_x11_2468)) {
    case TAG_Left: {
      V v_e_2470 = heff_field(v_x11_2468, 0);
      heff_take_n(v_x11_2468, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2470}), v_st_2469});
    }
    case TAG_Right: {
      V v_x_2471 = heff_field(v_x11_2468, 0);
      heff_take_n(v_x11_2468, 1ULL, 1);
      V v_x_2472 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2471, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2472}), v_st_2469});
    }
    default: return heff_nomatch(v_x11_2468);
    }
  }
  default: return heff_nomatch(v_x1_2467);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam6(V self, V *args) {
  V v_st_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2478 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_st_2477}));
  switch (heff_tag_of(v_x1_2478)) {
  case TAG_MkPair: {
    V v_x11_2479 = heff_field(v_x1_2478, 0);
    V v_st_2480 = heff_field(v_x1_2478, 1);
    V v_ru_24x1_2478_24MkPair = heff_take_reuse_n(v_x1_2478, 3ULL, 2);
    switch (heff_tag_of(v_x11_2479)) {
    case TAG_Left: {
      V v_e_2481 = heff_field(v_x11_2479, 0);
      heff_take_n(v_x11_2479, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2481}), v_st_2480});
    }
    case TAG_Right: {
      V v_x_2482 = heff_field(v_x11_2479, 0);
      heff_take_n(v_x11_2479, 1ULL, 1);
      V v_x_2483 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2482, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2483}), v_st_2480});
    }
    default: return heff_nomatch(v_x11_2479);
    }
  }
  default: return heff_nomatch(v_x1_2478);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam7(V self, V *args) {
  V v_st_2490 = args[0];
  V v_m_2489 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2491 = heff_tr(heff_call(v_m_2489, 1, (V[]){v_st_2490}));
  switch (heff_tag_of(v_x1_2491)) {
  case TAG_MkPair: {
    V v_x11_2492 = heff_field(v_x1_2491, 0);
    V v_st_2493 = heff_field(v_x1_2491, 1);
    V v_ru_24x1_2491_24MkPair = heff_take_reuse_n(v_x1_2491, 3ULL, 2);
    switch (heff_tag_of(v_x11_2492)) {
    case TAG_Left: {
      V v_e_2494 = heff_field(v_x11_2492, 0);
      heff_take_n(v_x11_2492, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2491_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2494}), v_st_2493});
    }
    case TAG_Right: {
      V v_x_2495 = heff_field(v_x11_2492, 0);
      heff_take_n(v_x11_2492, 1ULL, 1);
      V v_x_2496 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2495, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2491_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2496}), v_st_2493});
    }
    default: return heff_nomatch(v_x11_2492);
    }
  }
  default: return heff_nomatch(v_x1_2491);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam8(V self, V *args) {
  V v_st_24101 = args[0];
  V v_m_24100 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24102 = heff_tr(heff_call(v_m_24100, 1, (V[]){v_st_24101}));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_MkPair: {
    V v_x11_24103 = heff_field(v_x1_24102, 0);
    V v_st_24104 = heff_field(v_x1_24102, 1);
    V v_ru_24x1_24102_24MkPair = heff_take_reuse_n(v_x1_24102, 3ULL, 2);
    switch (heff_tag_of(v_x11_24103)) {
    case TAG_Left: {
      V v_e_24105 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24105}), v_st_24104});
    }
    case TAG_Right: {
      V v_x_24106 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      V v_x_24107 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24106, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24107}), v_st_24104});
    }
    default: return heff_nomatch(v_x11_24103);
    }
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam9(V self, V *args) {
  V v_st_24112 = args[0];
  V v_m_24111 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_d_24110 = heff_env(self)[2];
  V v_eq_24109 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24113 = heff_tr(heff_call(v_m_24111, 1, (V[]){v_st_24112}));
  switch (heff_tag_of(v_x1_24113)) {
  case TAG_MkPair: {
    V v_x11_24114 = heff_field(v_x1_24113, 0);
    V v_st_24115 = heff_field(v_x1_24113, 1);
    V v_ru_24x1_24113_24MkPair = heff_take_reuse_n(v_x1_24113, 3ULL, 2);
    switch (heff_tag_of(v_x11_24114)) {
    case TAG_Left: {
      V v_e_24116 = heff_field(v_x11_24114, 0);
      heff_take_n(v_x11_24114, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_24110);
      heff_drop_rec(v_eq_24109, 9);
      return heff_tag_at_n(v_ru_24x1_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24116}), v_st_24115});
    }
    case TAG_Right: {
      V v_x_24117 = heff_field(v_x11_24114, 0);
      V v_ru_24x11_24114_24Right = heff_take_reuse_n(v_x11_24114, 1ULL, 1);
      V v_m_24118 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_24110}));
      V v_x1_24119 = heff_tr(heff_call(v_m_24118, 1, (V[]){v_st_24115}));
      switch (heff_tag_of(v_x1_24119)) {
      case TAG_MkPair: {
        V v_x11_24120 = heff_field(v_x1_24119, 0);
        V v_st_24121 = heff_field(v_x1_24119, 1);
        V v_ru_24x1_24119_24MkPair = heff_take_reuse_n(v_x1_24119, 3ULL, 2);
        switch (heff_tag_of(v_x11_24120)) {
        case TAG_Left: {
          V v_e_24122 = heff_field(v_x11_24120, 0);
          heff_take_n(v_x11_24120, 1ULL, 1);
          heff_drop_rec(v_eq_24109, 9);
          heff_drop(v_x_24117);
          heff_drop_cell(v_ru_24x11_24114_24Right, 1);
          heff_drop_cell(v_ru_24x1_24119_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24122}), v_st_24121});
        }
        case TAG_Right: {
          V v_x_24123 = heff_field(v_x11_24120, 0);
          heff_take_n(v_x11_24120, 1ULL, 1);
          V v_x_24128;
          if (heff_strEq_c(heff_get_n(v_eq_24109, 1, 9), ((V)&g_heff_2esyntax_2esurface_2efieldL_str0))) {
            heff_drop_cell(v_ru_24x1_24113_24MkPair, 2);
            v_x_24128 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24117, heff_tag_at_n(v_ru_24x11_24114_24Right, TAG_Just, 1, (V[]){v_x_24123})));
          } else {
            heff_drop_cell(v_ru_24x11_24114_24Right, 1);
            heff_drop(v_x_24123);
            V v_t_24127;
            switch (heff_tag_of(v_x_24117)) {
            case TAG_At: {
              V v_s_24126 = heff_dup(heff_field(v_x_24117, 1));
              v_t_24127 = v_s_24126;
              break;
            }
            default: heff_nomatch(v_x_24117);
            }
            v_x_24128 = heff_tag_at_n(v_ru_24x1_24113_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_x_24117}), v_t_24127});
          }
          return heff_tag_at_n(v_ru_24x1_24119_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24128}), v_st_24121});
        }
        default: return heff_nomatch(v_x11_24120);
        }
      }
      default: return heff_nomatch(v_x1_24119);
      }
    }
    default: return heff_nomatch(v_x11_24114);
    }
  }
  default: return heff_nomatch(v_x1_24113);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam10(V self, V *args) {
  V v_st_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24136 = heff_tr(heff_call(v_m_24134, 1, (V[]){v_st_24135}));
  switch (heff_tag_of(v_x1_24136)) {
  case TAG_MkPair: {
    V v_x11_24137 = heff_field(v_x1_24136, 0);
    V v_st_24138 = heff_field(v_x1_24136, 1);
    V v_ru_24x1_24136_24MkPair = heff_take_reuse_n(v_x1_24136, 3ULL, 2);
    switch (heff_tag_of(v_x11_24137)) {
    case TAG_Left: {
      V v_e_24139 = heff_field(v_x11_24137, 0);
      heff_take_n(v_x11_24137, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24139}), v_st_24138});
    }
    case TAG_Right: {
      V v_x_24140 = heff_field(v_x11_24137, 0);
      heff_take_n(v_x11_24137, 1ULL, 1);
      V v_x_24141 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24140, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24141}), v_st_24138});
    }
    default: return heff_nomatch(v_x11_24137);
    }
  }
  default: return heff_nomatch(v_x1_24136);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam11(V self, V *args) {
  V v_st_24145 = args[0];
  V v_m_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24146 = heff_tr(heff_call(v_m_24144, 1, (V[]){v_st_24145}));
  switch (heff_tag_of(v_x1_24146)) {
  case TAG_MkPair: {
    V v_x11_24147 = heff_field(v_x1_24146, 0);
    V v_st_24148 = heff_field(v_x1_24146, 1);
    V v_ru_24x1_24146_24MkPair = heff_take_reuse_n(v_x1_24146, 3ULL, 2);
    switch (heff_tag_of(v_x11_24147)) {
    case TAG_Left: {
      V v_e_24149 = heff_field(v_x11_24147, 0);
      heff_take_n(v_x11_24147, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24149}), v_st_24148});
    }
    case TAG_Right: {
      V v_x_24150 = heff_field(v_x11_24147, 0);
      heff_take_n(v_x11_24147, 1ULL, 1);
      V v_x_24151 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24150, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24151}), v_st_24148});
    }
    default: return heff_nomatch(v_x11_24147);
    }
  }
  default: return heff_nomatch(v_x1_24146);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam12(V self, V *args) {
  V v_st_24155 = args[0];
  V v_m_24154 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24156 = heff_tr(heff_call(v_m_24154, 1, (V[]){v_st_24155}));
  switch (heff_tag_of(v_x1_24156)) {
  case TAG_MkPair: {
    V v_x11_24157 = heff_field(v_x1_24156, 0);
    V v_st_24158 = heff_field(v_x1_24156, 1);
    V v_ru_24x1_24156_24MkPair = heff_take_reuse_n(v_x1_24156, 3ULL, 2);
    switch (heff_tag_of(v_x11_24157)) {
    case TAG_Left: {
      V v_e_24159 = heff_field(v_x11_24157, 0);
      heff_take_n(v_x11_24157, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24156_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24159}), v_st_24158});
    }
    case TAG_Right: {
      V v_x_24160 = heff_field(v_x11_24157, 0);
      heff_take_n(v_x11_24157, 1ULL, 1);
      V v_x_24161 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24160, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24156_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24161}), v_st_24158});
    }
    default: return heff_nomatch(v_x11_24157);
    }
  }
  default: return heff_nomatch(v_x1_24156);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam13(V self, V *args) {
  V v_st_24165 = args[0];
  V v_m_24164 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24166 = heff_tr(heff_call(v_m_24164, 1, (V[]){v_st_24165}));
  switch (heff_tag_of(v_x1_24166)) {
  case TAG_MkPair: {
    V v_x11_24167 = heff_field(v_x1_24166, 0);
    V v_st_24168 = heff_field(v_x1_24166, 1);
    V v_ru_24x1_24166_24MkPair = heff_take_reuse_n(v_x1_24166, 3ULL, 2);
    switch (heff_tag_of(v_x11_24167)) {
    case TAG_Left: {
      V v_e_24169 = heff_field(v_x11_24167, 0);
      heff_take_n(v_x11_24167, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24166_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24169}), v_st_24168});
    }
    case TAG_Right: {
      V v_x_24170 = heff_field(v_x11_24167, 0);
      heff_take_n(v_x11_24167, 1ULL, 1);
      V v_x_24171 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24170, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24166_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24171}), v_st_24168});
    }
    default: return heff_nomatch(v_x11_24167);
    }
  }
  default: return heff_nomatch(v_x1_24166);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam14(V self, V *args) {
  V v_st_24175 = args[0];
  V v_m_24174 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24176 = heff_tr(heff_call(v_m_24174, 1, (V[]){v_st_24175}));
  switch (heff_tag_of(v_x1_24176)) {
  case TAG_MkPair: {
    V v_x11_24177 = heff_field(v_x1_24176, 0);
    V v_st_24178 = heff_field(v_x1_24176, 1);
    V v_ru_24x1_24176_24MkPair = heff_take_reuse_n(v_x1_24176, 3ULL, 2);
    switch (heff_tag_of(v_x11_24177)) {
    case TAG_Left: {
      V v_e_24179 = heff_field(v_x11_24177, 0);
      heff_take_n(v_x11_24177, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24176_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24179}), v_st_24178});
    }
    case TAG_Right: {
      V v_x_24180 = heff_field(v_x11_24177, 0);
      heff_take_n(v_x11_24177, 1ULL, 1);
      V v_x_24181 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24180, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24176_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24181}), v_st_24178});
    }
    default: return heff_nomatch(v_x11_24177);
    }
  }
  default: return heff_nomatch(v_x1_24176);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam15(V self, V *args) {
  V v_st_24186 = args[0];
  V v_m_24185 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24187 = heff_tr(heff_call(v_m_24185, 1, (V[]){v_st_24186}));
  switch (heff_tag_of(v_x1_24187)) {
  case TAG_MkPair: {
    V v_x11_24188 = heff_field(v_x1_24187, 0);
    V v_st_24189 = heff_field(v_x1_24187, 1);
    V v_ru_24x1_24187_24MkPair = heff_take_reuse_n(v_x1_24187, 3ULL, 2);
    switch (heff_tag_of(v_x11_24188)) {
    case TAG_Left: {
      V v_e_24190 = heff_field(v_x11_24188, 0);
      heff_take_n(v_x11_24188, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24187_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24190}), v_st_24189});
    }
    case TAG_Right: {
      V v_x_24191 = heff_field(v_x11_24188, 0);
      heff_take_n(v_x11_24188, 1ULL, 1);
      V v_x_24192 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24191, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24187_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24192}), v_st_24189});
    }
    default: return heff_nomatch(v_x11_24188);
    }
  }
  default: return heff_nomatch(v_x1_24187);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam16(V self, V *args) {
  V v_st_24196 = args[0];
  V v_m_24195 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24197 = heff_tr(heff_call(v_m_24195, 1, (V[]){v_st_24196}));
  switch (heff_tag_of(v_x1_24197)) {
  case TAG_MkPair: {
    V v_x11_24198 = heff_field(v_x1_24197, 0);
    V v_st_24199 = heff_field(v_x1_24197, 1);
    V v_ru_24x1_24197_24MkPair = heff_take_reuse_n(v_x1_24197, 3ULL, 2);
    switch (heff_tag_of(v_x11_24198)) {
    case TAG_Left: {
      V v_e_24200 = heff_field(v_x11_24198, 0);
      heff_take_n(v_x11_24198, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24197_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24200}), v_st_24199});
    }
    case TAG_Right: {
      V v_x_24201 = heff_field(v_x11_24198, 0);
      heff_take_n(v_x11_24198, 1ULL, 1);
      V v_x_24202 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24201, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24197_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24202}), v_st_24199});
    }
    default: return heff_nomatch(v_x11_24198);
    }
  }
  default: return heff_nomatch(v_x1_24197);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam17(V self, V *args) {
  V v_st_24206 = args[0];
  V v_m_24205 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24207 = heff_tr(heff_call(v_m_24205, 1, (V[]){v_st_24206}));
  switch (heff_tag_of(v_x1_24207)) {
  case TAG_MkPair: {
    V v_x11_24208 = heff_field(v_x1_24207, 0);
    V v_st_24209 = heff_field(v_x1_24207, 1);
    V v_ru_24x1_24207_24MkPair = heff_take_reuse_n(v_x1_24207, 3ULL, 2);
    switch (heff_tag_of(v_x11_24208)) {
    case TAG_Left: {
      V v_e_24210 = heff_field(v_x11_24208, 0);
      heff_take_n(v_x11_24208, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24210}), v_st_24209});
    }
    case TAG_Right: {
      V v_x_24211 = heff_field(v_x11_24208, 0);
      heff_take_n(v_x11_24208, 1ULL, 1);
      V v_x_24212 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24211, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24212}), v_st_24209});
    }
    default: return heff_nomatch(v_x11_24208);
    }
  }
  default: return heff_nomatch(v_x1_24207);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam18(V self, V *args) {
  V v_st_24217 = args[0];
  V v_m_24216 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24218 = heff_tr(heff_call(v_m_24216, 1, (V[]){v_st_24217}));
  switch (heff_tag_of(v_x1_24218)) {
  case TAG_MkPair: {
    V v_x11_24219 = heff_field(v_x1_24218, 0);
    V v_st_24220 = heff_field(v_x1_24218, 1);
    V v_ru_24x1_24218_24MkPair = heff_take_reuse_n(v_x1_24218, 3ULL, 2);
    switch (heff_tag_of(v_x11_24219)) {
    case TAG_Left: {
      V v_e_24221 = heff_field(v_x11_24219, 0);
      heff_take_n(v_x11_24219, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24218_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24221}), v_st_24220});
    }
    case TAG_Right: {
      V v_x_24222 = heff_field(v_x11_24219, 0);
      heff_take_n(v_x11_24219, 1ULL, 1);
      V v_x_24223 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24222, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24218_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24223}), v_st_24220});
    }
    default: return heff_nomatch(v_x11_24219);
    }
  }
  default: return heff_nomatch(v_x1_24218);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam19(V self, V *args) {
  V v_st_24226 = args[0];
  V v_m_24225 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24227 = heff_tr(heff_call(v_m_24225, 1, (V[]){v_st_24226}));
  switch (heff_tag_of(v_x1_24227)) {
  case TAG_MkPair: {
    V v_x11_24228 = heff_field(v_x1_24227, 0);
    V v_st_24229 = heff_field(v_x1_24227, 1);
    V v_ru_24x1_24227_24MkPair = heff_take_reuse_n(v_x1_24227, 3ULL, 2);
    switch (heff_tag_of(v_x11_24228)) {
    case TAG_Left: {
      V v_e_24230 = heff_field(v_x11_24228, 0);
      heff_take_n(v_x11_24228, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24227_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24230}), v_st_24229});
    }
    case TAG_Right: {
      V v_x_24231 = heff_field(v_x11_24228, 0);
      heff_take_n(v_x11_24228, 1ULL, 1);
      V v_x_24232 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24231, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24227_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24232}), v_st_24229});
    }
    default: return heff_nomatch(v_x11_24228);
    }
  }
  default: return heff_nomatch(v_x1_24227);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam20(V self, V *args) {
  V v_st_24237 = args[0];
  V v_m_24236 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24238 = heff_tr(heff_call(v_m_24236, 1, (V[]){v_st_24237}));
  switch (heff_tag_of(v_x1_24238)) {
  case TAG_MkPair: {
    V v_x11_24239 = heff_field(v_x1_24238, 0);
    V v_st_24240 = heff_field(v_x1_24238, 1);
    V v_ru_24x1_24238_24MkPair = heff_take_reuse_n(v_x1_24238, 3ULL, 2);
    switch (heff_tag_of(v_x11_24239)) {
    case TAG_Left: {
      V v_e_24241 = heff_field(v_x11_24239, 0);
      heff_take_n(v_x11_24239, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24241}), v_st_24240});
    }
    case TAG_Right: {
      V v_x_24242 = heff_field(v_x11_24239, 0);
      heff_take_n(v_x11_24239, 1ULL, 1);
      V v_x_24243 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24242, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24243}), v_st_24240});
    }
    default: return heff_nomatch(v_x11_24239);
    }
  }
  default: return heff_nomatch(v_x1_24238);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam21(V self, V *args) {
  V v_st_24250 = args[0];
  V v_m_24249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24251 = heff_tr(heff_call(v_m_24249, 1, (V[]){v_st_24250}));
  switch (heff_tag_of(v_x1_24251)) {
  case TAG_MkPair: {
    V v_x11_24252 = heff_field(v_x1_24251, 0);
    V v_st_24253 = heff_field(v_x1_24251, 1);
    V v_ru_24x1_24251_24MkPair = heff_take_reuse_n(v_x1_24251, 3ULL, 2);
    switch (heff_tag_of(v_x11_24252)) {
    case TAG_Left: {
      V v_e_24254 = heff_field(v_x11_24252, 0);
      heff_take_n(v_x11_24252, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24251_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24254}), v_st_24253});
    }
    case TAG_Right: {
      V v_x_24255 = heff_field(v_x11_24252, 0);
      heff_take_n(v_x11_24252, 1ULL, 1);
      V v_x_24256 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24255, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24251_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24256}), v_st_24253});
    }
    default: return heff_nomatch(v_x11_24252);
    }
  }
  default: return heff_nomatch(v_x1_24251);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam22(V self, V *args) {
  V v_st_24262 = args[0];
  V v_m_24261 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24263 = heff_tr(heff_call(v_m_24261, 1, (V[]){v_st_24262}));
  switch (heff_tag_of(v_x1_24263)) {
  case TAG_MkPair: {
    V v_x11_24264 = heff_field(v_x1_24263, 0);
    V v_st_24265 = heff_field(v_x1_24263, 1);
    V v_ru_24x1_24263_24MkPair = heff_take_reuse_n(v_x1_24263, 3ULL, 2);
    switch (heff_tag_of(v_x11_24264)) {
    case TAG_Left: {
      V v_e_24266 = heff_field(v_x11_24264, 0);
      heff_take_n(v_x11_24264, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24263_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24266}), v_st_24265});
    }
    case TAG_Right: {
      V v_x_24267 = heff_field(v_x11_24264, 0);
      heff_take_n(v_x11_24264, 1ULL, 1);
      V v_x_24268 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24267, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24263_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24268}), v_st_24265});
    }
    default: return heff_nomatch(v_x11_24264);
    }
  }
  default: return heff_nomatch(v_x1_24263);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam23(V self, V *args) {
  V v_st_24274 = args[0];
  V v_m_24273 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24275 = heff_tr(heff_call(v_m_24273, 1, (V[]){v_st_24274}));
  switch (heff_tag_of(v_x1_24275)) {
  case TAG_MkPair: {
    V v_x11_24276 = heff_field(v_x1_24275, 0);
    V v_st_24277 = heff_field(v_x1_24275, 1);
    V v_ru_24x1_24275_24MkPair = heff_take_reuse_n(v_x1_24275, 3ULL, 2);
    switch (heff_tag_of(v_x11_24276)) {
    case TAG_Left: {
      V v_e_24278 = heff_field(v_x11_24276, 0);
      heff_take_n(v_x11_24276, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24275_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24278}), v_st_24277});
    }
    case TAG_Right: {
      V v_x_24279 = heff_field(v_x11_24276, 0);
      heff_take_n(v_x11_24276, 1ULL, 1);
      V v_x_24280 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24279, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24275_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24280}), v_st_24277});
    }
    default: return heff_nomatch(v_x11_24276);
    }
  }
  default: return heff_nomatch(v_x1_24275);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam24(V self, V *args) {
  V v_st_24285 = args[0];
  V v_m_24284 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24286 = heff_tr(heff_call(v_m_24284, 1, (V[]){v_st_24285}));
  switch (heff_tag_of(v_x1_24286)) {
  case TAG_MkPair: {
    V v_x11_24287 = heff_field(v_x1_24286, 0);
    V v_st_24288 = heff_field(v_x1_24286, 1);
    V v_ru_24x1_24286_24MkPair = heff_take_reuse_n(v_x1_24286, 3ULL, 2);
    switch (heff_tag_of(v_x11_24287)) {
    case TAG_Left: {
      V v_e_24289 = heff_field(v_x11_24287, 0);
      heff_take_n(v_x11_24287, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24286_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24289}), v_st_24288});
    }
    case TAG_Right: {
      V v_x_24290 = heff_field(v_x11_24287, 0);
      heff_take_n(v_x11_24287, 1ULL, 1);
      V v_x_24291 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24290, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24286_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24291}), v_st_24288});
    }
    default: return heff_nomatch(v_x11_24287);
    }
  }
  default: return heff_nomatch(v_x1_24286);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam25(V self, V *args) {
  V v_st_24299 = args[0];
  V v_m_24298 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24300 = heff_tr(heff_call(v_m_24298, 1, (V[]){v_st_24299}));
  switch (heff_tag_of(v_x1_24300)) {
  case TAG_MkPair: {
    V v_x11_24301 = heff_field(v_x1_24300, 0);
    V v_st_24302 = heff_field(v_x1_24300, 1);
    V v_ru_24x1_24300_24MkPair = heff_take_reuse_n(v_x1_24300, 3ULL, 2);
    switch (heff_tag_of(v_x11_24301)) {
    case TAG_Left: {
      V v_e_24303 = heff_field(v_x11_24301, 0);
      heff_take_n(v_x11_24301, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24300_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24303}), v_st_24302});
    }
    case TAG_Right: {
      V v_x_24304 = heff_field(v_x11_24301, 0);
      heff_take_n(v_x11_24301, 1ULL, 1);
      V v_x_24305 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24304, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24300_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24305}), v_st_24302});
    }
    default: return heff_nomatch(v_x11_24301);
    }
  }
  default: return heff_nomatch(v_x1_24300);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam26(V self, V *args) {
  V v_st_24309 = args[0];
  V v_m_24308 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24310 = heff_tr(heff_call(v_m_24308, 1, (V[]){v_st_24309}));
  switch (heff_tag_of(v_x1_24310)) {
  case TAG_MkPair: {
    V v_x11_24311 = heff_field(v_x1_24310, 0);
    V v_st_24312 = heff_field(v_x1_24310, 1);
    V v_ru_24x1_24310_24MkPair = heff_take_reuse_n(v_x1_24310, 3ULL, 2);
    switch (heff_tag_of(v_x11_24311)) {
    case TAG_Left: {
      V v_e_24313 = heff_field(v_x11_24311, 0);
      heff_take_n(v_x11_24311, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24310_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24313}), v_st_24312});
    }
    case TAG_Right: {
      V v_x_24314 = heff_field(v_x11_24311, 0);
      heff_take_n(v_x11_24311, 1ULL, 1);
      V v_x_24315 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24314, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24310_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24315}), v_st_24312});
    }
    default: return heff_nomatch(v_x11_24311);
    }
  }
  default: return heff_nomatch(v_x1_24310);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam27(V self, V *args) {
  V v_st_24320 = args[0];
  V v_m_24319 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24321 = heff_tr(heff_call(v_m_24319, 1, (V[]){v_st_24320}));
  switch (heff_tag_of(v_x1_24321)) {
  case TAG_MkPair: {
    V v_x11_24322 = heff_field(v_x1_24321, 0);
    V v_st_24323 = heff_field(v_x1_24321, 1);
    V v_ru_24x1_24321_24MkPair = heff_take_reuse_n(v_x1_24321, 3ULL, 2);
    switch (heff_tag_of(v_x11_24322)) {
    case TAG_Left: {
      V v_e_24324 = heff_field(v_x11_24322, 0);
      heff_take_n(v_x11_24322, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24321_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24324}), v_st_24323});
    }
    case TAG_Right: {
      V v_x_24325 = heff_field(v_x11_24322, 0);
      heff_take_n(v_x11_24322, 1ULL, 1);
      V v_x_24326 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24325, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24321_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24326}), v_st_24323});
    }
    default: return heff_nomatch(v_x11_24322);
    }
  }
  default: return heff_nomatch(v_x1_24321);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam28(V self, V *args) {
  V v_st_24334 = args[0];
  V v_m_24333 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24335 = heff_tr(heff_call(v_m_24333, 1, (V[]){v_st_24334}));
  switch (heff_tag_of(v_x1_24335)) {
  case TAG_MkPair: {
    V v_x11_24336 = heff_field(v_x1_24335, 0);
    V v_st_24337 = heff_field(v_x1_24335, 1);
    V v_ru_24x1_24335_24MkPair = heff_take_reuse_n(v_x1_24335, 3ULL, 2);
    switch (heff_tag_of(v_x11_24336)) {
    case TAG_Left: {
      V v_e_24338 = heff_field(v_x11_24336, 0);
      heff_take_n(v_x11_24336, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24335_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24338}), v_st_24337});
    }
    case TAG_Right: {
      V v_x_24339 = heff_field(v_x11_24336, 0);
      heff_take_n(v_x11_24336, 1ULL, 1);
      V v_x_24340 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24339, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24335_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24340}), v_st_24337});
    }
    default: return heff_nomatch(v_x11_24336);
    }
  }
  default: return heff_nomatch(v_x1_24335);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str1, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str3, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str5, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str7, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str9, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str11, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str13, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str18, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str19, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str20, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str21, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str23, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str25, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str27, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str28, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str29, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str30, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str31, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str33, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str35, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str37, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str39, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str40, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str41, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str42, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str43, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str44, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str45, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str46, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str47, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str48, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str49, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str50, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str51, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str52, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str53, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str54, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str55, 12, "unexpected `");
V g_heff_2esyntax_2esurface_2ealtL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam29(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ealtL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ealtL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ealtL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    heff_drop_rec(v_r_240, 3);
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_244 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_245 = heff_strAppend(heff_get_n(v_t_244, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str0));
    V v_msg_246 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str1), v_t_245);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam0, 1, 2, (V[]){v_t_243, v_msg_246});
  }
  case TAG_EParen: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2413 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2414 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2415 = heff_strAppend(heff_get_n(v_t_2414, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str2));
    V v_msg_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str3), v_t_2415);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam1, 1, 2, (V[]){v_t_2413, v_msg_2416});
  }
  case TAG_Named: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2425 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2426 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_2427 = heff_strAppend(heff_get_n(v_t_2426, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str4));
    V v_msg_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str5), v_t_2427);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam2, 1, 2, (V[]){v_t_2425, v_msg_2428});
  }
  case TAG_Tup: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2436 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2437 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2438 = heff_strAppend(heff_get_n(v_t_2437, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str6));
    V v_msg_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str7), v_t_2438);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam3, 1, 2, (V[]){v_t_2436, v_msg_2439});
  }
  case TAG_Braces: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2447 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2448 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2449 = heff_strAppend(heff_get_n(v_t_2448, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str8));
    V v_msg_2450 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str9), v_t_2449);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam4, 1, 2, (V[]){v_t_2447, v_msg_2450});
  }
  case TAG_Update: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2460 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2461 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_2462 = heff_strAppend(heff_get_n(v_t_2461, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str10));
    V v_msg_2463 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str11), v_t_2462);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam5, 1, 2, (V[]){v_t_2460, v_msg_2463});
  }
  case TAG_EUSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2470 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2471 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2472 = heff_strAppend(heff_get_n(v_t_2471, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str12));
    V v_msg_2473 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str13), v_t_2472);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam6, 1, 2, (V[]){v_t_2470, v_msg_2473});
  }
  case TAG_InstB: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2482 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2483 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_2484 = heff_strAppend(heff_get_n(v_t_2483, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str14));
    V v_msg_2485 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str15), v_t_2484);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam7, 1, 2, (V[]){v_t_2482, v_msg_2485});
  }
  case TAG_EFSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2492 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2493 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2494 = heff_strAppend(heff_get_n(v_t_2493, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str16));
    V v_msg_2495 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str17), v_t_2494);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam8, 1, 2, (V[]){v_t_2492, v_msg_2495});
  }
  case TAG_EFDefault: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24102 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24103 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24104 = heff_strAppend(heff_get_n(v_t_24103, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str18));
    V v_msg_24105 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str19), v_t_24104);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam9, 1, 2, (V[]){v_t_24102, v_msg_24105});
  }
  case TAG_Sum: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24114 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24115 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_24116 = heff_strAppend(heff_get_n(v_t_24115, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str20));
    V v_msg_24117 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str21), v_t_24116);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam10, 1, 2, (V[]){v_t_24114, v_msg_24117});
  }
  case TAG_ECon: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24123 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24124 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24125 = heff_strAppend(heff_get_n(v_t_24124, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str22));
    V v_msg_24126 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str23), v_t_24125);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam11, 1, 2, (V[]){v_t_24123, v_msg_24126});
  }
  case TAG_EField: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24132 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24133 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24134 = heff_strAppend(heff_get_n(v_t_24133, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str24));
    V v_msg_24135 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str25), v_t_24134);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam12, 1, 2, (V[]){v_t_24132, v_msg_24135});
  }
  case TAG_ENeg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24141 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24142 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24143 = heff_strAppend(heff_get_n(v_t_24142, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str26));
    V v_msg_24144 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str27), v_t_24143);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam13, 1, 2, (V[]){v_t_24141, v_msg_24144});
  }
  case TAG_App: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24150 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24151 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24152 = heff_strAppend(heff_get_n(v_t_24151, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str28));
    V v_msg_24153 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str29), v_t_24152);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam14, 1, 2, (V[]){v_t_24150, v_msg_24153});
  }
  case TAG_Op: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24160 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24161 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24162 = heff_strAppend(heff_get_n(v_t_24161, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str30));
    V v_msg_24163 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str31), v_t_24162);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam15, 1, 2, (V[]){v_t_24160, v_msg_24163});
  }
  case TAG_Ops: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24169 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24170 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24171 = heff_strAppend(heff_get_n(v_t_24170, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str32));
    V v_msg_24172 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str33), v_t_24171);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam16, 1, 2, (V[]){v_t_24169, v_msg_24172});
  }
  case TAG_OpRhs: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24178 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24179 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24180 = heff_strAppend(heff_get_n(v_t_24179, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str34));
    V v_msg_24181 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str35), v_t_24180);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam17, 1, 2, (V[]){v_t_24178, v_msg_24181});
  }
  case TAG_Ann: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24188 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24189 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24190 = heff_strAppend(heff_get_n(v_t_24189, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str36));
    V v_msg_24191 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str37), v_t_24190);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam18, 1, 2, (V[]){v_t_24188, v_msg_24191});
  }
  case TAG_BVar: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24196 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24197 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_24198 = heff_strAppend(heff_get_n(v_t_24197, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str38));
    V v_msg_24199 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str39), v_t_24198);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam19, 1, 2, (V[]){v_t_24196, v_msg_24199});
  }
  case TAG_BImp: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24206 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24207 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24208 = heff_strAppend(heff_get_n(v_t_24207, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str40));
    V v_msg_24209 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str41), v_t_24208);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam20, 1, 2, (V[]){v_t_24206, v_msg_24209});
  }
  case TAG_BAnn: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24218 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24219 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_24220 = heff_strAppend(heff_get_n(v_t_24219, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str42));
    V v_msg_24221 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str43), v_t_24220);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam21, 1, 2, (V[]){v_t_24218, v_msg_24221});
  }
  case TAG_Lam: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24229 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24230 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24231 = heff_strAppend(heff_get_n(v_t_24230, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str44));
    V v_msg_24232 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str45), v_t_24231);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam22, 1, 2, (V[]){v_t_24229, v_msg_24232});
  }
  case TAG_Case: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24240 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24241 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24242 = heff_strAppend(heff_get_n(v_t_24241, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str46));
    V v_msg_24243 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str47), v_t_24242);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam23, 1, 2, (V[]){v_t_24240, v_msg_24243});
  }
  case TAG_EAlt: {
    V v_p_24247 = heff_field(v_e_241, 0);
    V v_e3_24249 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 5ULL, 3);
    V v_m_24250 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_p_24247)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam24, 1, 4, (V[]){v_m_24250, v_p_24247, v_r_240, v_e3_24249});
  }
  case TAG_If: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24279 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24280 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24281 = heff_strAppend(heff_get_n(v_t_24280, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str48));
    V v_msg_24282 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str49), v_t_24281);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam26, 1, 2, (V[]){v_t_24279, v_msg_24282});
  }
  case TAG_Do: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24288 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24289 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24290 = heff_strAppend(heff_get_n(v_t_24289, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str50));
    V v_msg_24291 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str51), v_t_24290);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam27, 1, 2, (V[]){v_t_24288, v_msg_24291});
  }
  case TAG_ESBind: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24298 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24299 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24300 = heff_strAppend(heff_get_n(v_t_24299, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str52));
    V v_msg_24301 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str53), v_t_24300);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam28, 1, 2, (V[]){v_t_24298, v_msg_24301});
  }
  case TAG_ELet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24311 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24312 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24313 = heff_strAppend(heff_get_n(v_t_24312, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str54));
    V v_msg_24314 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str55), v_t_24313);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam29, 1, 2, (V[]){v_t_24311, v_msg_24314});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ealtL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2ealtL_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_t_243 = heff_env(self)[0];
  V v_msg_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_243, 3), heff_get_n(v_t_243, 4, 9)});
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_246, v_t_248, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_249}), v_st_247});
}
V g_heff_2esyntax_2esurface_2ealtL_lam1(V self, V *args) {
  V v_st_2417 = args[0];
  V v_t_2413 = heff_env(self)[0];
  V v_msg_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2413, 3), heff_get_n(v_t_2413, 4, 9)});
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2416, v_t_2418, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2419}), v_st_2417});
}
V g_heff_2esyntax_2esurface_2ealtL_lam2(V self, V *args) {
  V v_st_2429 = args[0];
  V v_t_2425 = heff_env(self)[0];
  V v_msg_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2425, 3), heff_get_n(v_t_2425, 4, 9)});
  V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2428, v_t_2430, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2431}), v_st_2429});
}
V g_heff_2esyntax_2esurface_2ealtL_lam3(V self, V *args) {
  V v_st_2440 = args[0];
  V v_t_2436 = heff_env(self)[0];
  V v_msg_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2441 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2436, 3), heff_get_n(v_t_2436, 4, 9)});
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2439, v_t_2441, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2442}), v_st_2440});
}
V g_heff_2esyntax_2esurface_2ealtL_lam4(V self, V *args) {
  V v_st_2451 = args[0];
  V v_t_2447 = heff_env(self)[0];
  V v_msg_2450 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2452 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2447, 3), heff_get_n(v_t_2447, 4, 9)});
  V v_t_2453 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2450, v_t_2452, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2453}), v_st_2451});
}
V g_heff_2esyntax_2esurface_2ealtL_lam5(V self, V *args) {
  V v_st_2464 = args[0];
  V v_t_2460 = heff_env(self)[0];
  V v_msg_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2465 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2460, 3), heff_get_n(v_t_2460, 4, 9)});
  V v_t_2466 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2463, v_t_2465, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2466}), v_st_2464});
}
V g_heff_2esyntax_2esurface_2ealtL_lam6(V self, V *args) {
  V v_st_2474 = args[0];
  V v_t_2470 = heff_env(self)[0];
  V v_msg_2473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2475 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2470, 3), heff_get_n(v_t_2470, 4, 9)});
  V v_t_2476 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2473, v_t_2475, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2476}), v_st_2474});
}
V g_heff_2esyntax_2esurface_2ealtL_lam7(V self, V *args) {
  V v_st_2486 = args[0];
  V v_t_2482 = heff_env(self)[0];
  V v_msg_2485 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2487 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2482, 3), heff_get_n(v_t_2482, 4, 9)});
  V v_t_2488 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2485, v_t_2487, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2488}), v_st_2486});
}
V g_heff_2esyntax_2esurface_2ealtL_lam8(V self, V *args) {
  V v_st_2496 = args[0];
  V v_t_2492 = heff_env(self)[0];
  V v_msg_2495 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2497 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2492, 3), heff_get_n(v_t_2492, 4, 9)});
  V v_t_2498 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2495, v_t_2497, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2498}), v_st_2496});
}
V g_heff_2esyntax_2esurface_2ealtL_lam9(V self, V *args) {
  V v_st_24106 = args[0];
  V v_t_24102 = heff_env(self)[0];
  V v_msg_24105 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24107 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24102, 3), heff_get_n(v_t_24102, 4, 9)});
  V v_t_24108 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24105, v_t_24107, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24108}), v_st_24106});
}
V g_heff_2esyntax_2esurface_2ealtL_lam10(V self, V *args) {
  V v_st_24118 = args[0];
  V v_t_24114 = heff_env(self)[0];
  V v_msg_24117 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24119 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24114, 3), heff_get_n(v_t_24114, 4, 9)});
  V v_t_24120 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24117, v_t_24119, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24120}), v_st_24118});
}
V g_heff_2esyntax_2esurface_2ealtL_lam11(V self, V *args) {
  V v_st_24127 = args[0];
  V v_t_24123 = heff_env(self)[0];
  V v_msg_24126 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24128 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24123, 3), heff_get_n(v_t_24123, 4, 9)});
  V v_t_24129 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24126, v_t_24128, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24129}), v_st_24127});
}
V g_heff_2esyntax_2esurface_2ealtL_lam12(V self, V *args) {
  V v_st_24136 = args[0];
  V v_t_24132 = heff_env(self)[0];
  V v_msg_24135 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24137 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24132, 3), heff_get_n(v_t_24132, 4, 9)});
  V v_t_24138 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24135, v_t_24137, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24138}), v_st_24136});
}
V g_heff_2esyntax_2esurface_2ealtL_lam13(V self, V *args) {
  V v_st_24145 = args[0];
  V v_t_24141 = heff_env(self)[0];
  V v_msg_24144 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24146 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24141, 3), heff_get_n(v_t_24141, 4, 9)});
  V v_t_24147 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24144, v_t_24146, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24147}), v_st_24145});
}
V g_heff_2esyntax_2esurface_2ealtL_lam14(V self, V *args) {
  V v_st_24154 = args[0];
  V v_t_24150 = heff_env(self)[0];
  V v_msg_24153 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24155 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24150, 3), heff_get_n(v_t_24150, 4, 9)});
  V v_t_24156 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24153, v_t_24155, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24156}), v_st_24154});
}
V g_heff_2esyntax_2esurface_2ealtL_lam15(V self, V *args) {
  V v_st_24164 = args[0];
  V v_t_24160 = heff_env(self)[0];
  V v_msg_24163 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24165 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24160, 3), heff_get_n(v_t_24160, 4, 9)});
  V v_t_24166 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24163, v_t_24165, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24166}), v_st_24164});
}
V g_heff_2esyntax_2esurface_2ealtL_lam16(V self, V *args) {
  V v_st_24173 = args[0];
  V v_t_24169 = heff_env(self)[0];
  V v_msg_24172 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24174 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24169, 3), heff_get_n(v_t_24169, 4, 9)});
  V v_t_24175 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24172, v_t_24174, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24175}), v_st_24173});
}
V g_heff_2esyntax_2esurface_2ealtL_lam17(V self, V *args) {
  V v_st_24182 = args[0];
  V v_t_24178 = heff_env(self)[0];
  V v_msg_24181 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24183 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24178, 3), heff_get_n(v_t_24178, 4, 9)});
  V v_t_24184 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24181, v_t_24183, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24184}), v_st_24182});
}
V g_heff_2esyntax_2esurface_2ealtL_lam18(V self, V *args) {
  V v_st_24192 = args[0];
  V v_t_24188 = heff_env(self)[0];
  V v_msg_24191 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24193 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24188, 3), heff_get_n(v_t_24188, 4, 9)});
  V v_t_24194 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24191, v_t_24193, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24194}), v_st_24192});
}
V g_heff_2esyntax_2esurface_2ealtL_lam19(V self, V *args) {
  V v_st_24200 = args[0];
  V v_t_24196 = heff_env(self)[0];
  V v_msg_24199 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24201 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24196, 3), heff_get_n(v_t_24196, 4, 9)});
  V v_t_24202 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24199, v_t_24201, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24202}), v_st_24200});
}
V g_heff_2esyntax_2esurface_2ealtL_lam20(V self, V *args) {
  V v_st_24210 = args[0];
  V v_t_24206 = heff_env(self)[0];
  V v_msg_24209 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24211 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24206, 3), heff_get_n(v_t_24206, 4, 9)});
  V v_t_24212 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24209, v_t_24211, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24212}), v_st_24210});
}
V g_heff_2esyntax_2esurface_2ealtL_lam21(V self, V *args) {
  V v_st_24222 = args[0];
  V v_t_24218 = heff_env(self)[0];
  V v_msg_24221 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24223 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24218, 3), heff_get_n(v_t_24218, 4, 9)});
  V v_t_24224 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24221, v_t_24223, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24224}), v_st_24222});
}
V g_heff_2esyntax_2esurface_2ealtL_lam22(V self, V *args) {
  V v_st_24233 = args[0];
  V v_t_24229 = heff_env(self)[0];
  V v_msg_24232 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24234 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24229, 3), heff_get_n(v_t_24229, 4, 9)});
  V v_t_24235 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24232, v_t_24234, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24235}), v_st_24233});
}
V g_heff_2esyntax_2esurface_2ealtL_lam23(V self, V *args) {
  V v_st_24244 = args[0];
  V v_t_24240 = heff_env(self)[0];
  V v_msg_24243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24245 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24240, 3), heff_get_n(v_t_24240, 4, 9)});
  V v_t_24246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24243, v_t_24245, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24246}), v_st_24244});
}
V g_heff_2esyntax_2esurface_2ealtL_lam25(V self, V *args) {
  V v_st_24259 = args[0];
  V v_m_24258 = heff_env(self)[0];
  V v_x_24256 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24260 = heff_tr(heff_call(v_m_24258, 1, (V[]){v_st_24259}));
  switch (heff_tag_of(v_x1_24260)) {
  case TAG_MkPair: {
    V v_x11_24261 = heff_field(v_x1_24260, 0);
    V v_st_24262 = heff_field(v_x1_24260, 1);
    V v_ru_24x1_24260_24MkPair = heff_take_reuse_n(v_x1_24260, 3ULL, 2);
    switch (heff_tag_of(v_x11_24261)) {
    case TAG_Left: {
      V v_e_24263 = heff_field(v_x11_24261, 0);
      heff_take_n(v_x11_24261, 1ULL, 1);
      heff_drop(v_x_24256);
      return heff_tag_at_n(v_ru_24x1_24260_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24263}), v_st_24262});
    }
    case TAG_Right: {
      V v_x_24264 = heff_field(v_x11_24261, 0);
      V v_ru_24x11_24261_24Right = heff_take_reuse_n(v_x11_24261, 1ULL, 1);
      V v_a_24267;
      switch (heff_tag_of(v_x_24256)) {
      case TAG_At: {
        V v_s_24266 = heff_dup(heff_field(v_x_24256, 1));
        v_a_24267 = v_s_24266;
        break;
      }
      default: heff_nomatch(v_x_24256);
      }
      V v_b_24270;
      switch (heff_tag_of(v_x_24264)) {
      case TAG_At: {
        V v_s_24269 = heff_dup(heff_field(v_x_24264, 1));
        v_b_24270 = v_s_24269;
        break;
      }
      default: heff_nomatch(v_x_24264);
      }
      V v_t_24271 = ({ V rv_1 = heff_get_n(v_b_24270, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_24267, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_x_24272 = heff_tag_at_n(v_ru_24x1_24260_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24256, v_x_24264}), v_t_24271});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24261_24Right, TAG_Right, 1, (V[]){v_x_24272}), v_st_24262});
    }
    default: return heff_nomatch(v_x11_24261);
    }
  }
  default: return heff_nomatch(v_x1_24260);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_lam24(V self, V *args) {
  V v_st_24251 = args[0];
  V v_m_24250 = heff_env(self)[0];
  V v_p_24247 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_e3_24249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24252 = heff_tr(heff_call(v_m_24250, 1, (V[]){v_st_24251}));
  switch (heff_tag_of(v_x1_24252)) {
  case TAG_MkPair: {
    V v_x11_24253 = heff_field(v_x1_24252, 0);
    V v_st_24254 = heff_field(v_x1_24252, 1);
    V v_ru_24x1_24252_24MkPair = heff_take_reuse_n(v_x1_24252, 3ULL, 2);
    switch (heff_tag_of(v_x11_24253)) {
    case TAG_Left: {
      V v_e_24255 = heff_field(v_x11_24253, 0);
      heff_take_n(v_x11_24253, 1ULL, 1);
      heff_drop(v_p_24247);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_e3_24249);
      return heff_tag_at_n(v_ru_24x1_24252_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24255}), v_st_24254});
    }
    case TAG_Right: {
      V v_x_24256 = heff_field(v_x11_24253, 0);
      heff_take_n(v_x11_24253, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24252_24MkPair, 2);
      V v_t_24257 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_p_24247; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop(v_p_24247); r_; });
      V v_m_24258 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e3_24249}));
      return (g_heff_2esyntax_2esurface_2ewithScope(v_t_24257, heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam25, 1, 2, (V[]){v_m_24258, v_x_24256}), v_st_24254));
    }
    default: return heff_nomatch(v_x11_24253);
    }
  }
  default: return heff_nomatch(v_x1_24252);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_lam26(V self, V *args) {
  V v_st_24283 = args[0];
  V v_t_24279 = heff_env(self)[0];
  V v_msg_24282 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24284 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24279, 3), heff_get_n(v_t_24279, 4, 9)});
  V v_t_24285 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24282, v_t_24284, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24285}), v_st_24283});
}
V g_heff_2esyntax_2esurface_2ealtL_lam27(V self, V *args) {
  V v_st_24292 = args[0];
  V v_t_24288 = heff_env(self)[0];
  V v_msg_24291 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24293 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24288, 3), heff_get_n(v_t_24288, 4, 9)});
  V v_t_24294 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24291, v_t_24293, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24294}), v_st_24292});
}
V g_heff_2esyntax_2esurface_2ealtL_lam28(V self, V *args) {
  V v_st_24302 = args[0];
  V v_t_24298 = heff_env(self)[0];
  V v_msg_24301 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24303 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24298, 3), heff_get_n(v_t_24298, 4, 9)});
  V v_t_24304 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24301, v_t_24303, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24304}), v_st_24302});
}
V g_heff_2esyntax_2esurface_2ealtL_lam29(V self, V *args) {
  V v_st_24315 = args[0];
  V v_t_24311 = heff_env(self)[0];
  V v_msg_24314 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24316 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24311, 3), heff_get_n(v_t_24311, 4, 9)});
  V v_t_24317 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24314, v_t_24316, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24317}), v_st_24315});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str0, 4, "True");
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str1, 4, "True");
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str2, 5, "False");
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str3, 5, "False");
Clo g_heff_2esyntax_2esurface_2eifE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eifE_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eifE(V v_sp_240, V v_c_241, V v_a_242, V v_b_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str0), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str1)}), heff_dup(v_sp_240)});
  V v_x1_246 = ({ V a_0 = v_t_245; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_b_249;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_At: {
    V v_s_248 = heff_field(v_x1_246, 1);
    heff_take_n(v_x1_246, 2ULL, 2);
    v_b_249 = v_s_248;
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  V v_t_2410 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_b_249, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_p_2411 = heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_t_2410});
  V v_a_2414;
  switch (heff_tag_of(v_p_2411)) {
  case TAG_At: {
    V v_s_2413 = heff_dup(heff_field(v_p_2411, 1));
    v_a_2414 = v_s_2413;
    break;
  }
  default: heff_nomatch(v_p_2411);
  }
  V v_b_2417;
  switch (heff_tag_of(v_a_242)) {
  case TAG_At: {
    V v_s_2416 = heff_dup(heff_field(v_a_242, 1));
    v_b_2417 = v_s_2416;
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  V v_t_2418 = ({ V rv_1 = heff_get_n(v_b_2417, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_2414, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2411, v_a_242}), v_t_2418});
  V v_t_2420 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str2), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str3)}), heff_dup(v_sp_240)});
  V v_x1_2422 = ({ V a_0 = v_t_2421; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_b_2425;
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_At: {
    V v_s_2424 = heff_field(v_x1_2422, 1);
    heff_take_n(v_x1_2422, 2ULL, 2);
    v_b_2425 = v_s_2424;
    break;
  }
  default: heff_nomatch(v_x1_2422);
  }
  V v_t_2426 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_b_2425, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_p_2427 = heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_t_2426});
  V v_a_2430;
  switch (heff_tag_of(v_p_2427)) {
  case TAG_At: {
    V v_s_2429 = heff_dup(heff_field(v_p_2427, 1));
    v_a_2430 = v_s_2429;
    break;
  }
  default: heff_nomatch(v_p_2427);
  }
  V v_b_2433;
  switch (heff_tag_of(v_b_243)) {
  case TAG_At: {
    V v_s_2432 = heff_dup(heff_field(v_b_243, 1));
    v_b_2433 = v_s_2432;
    break;
  }
  default: heff_nomatch(v_b_243);
  }
  V v_t_2434 = ({ V rv_1 = heff_get_n(v_b_2433, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_2430, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2427, v_b_243}), v_t_2434});
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
  V v_t_2437 = heff_tag_n(TAG_EMatch, 2, (V[]){v_c_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2436})});
  return heff_tag_n(TAG_At, 2, (V[]){v_t_2437, v_sp_240});
}
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eifE(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eparamOf_str0, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
Clo g_heff_2esyntax_2esurface_2eparamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eparamOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eparamOf(V v_p_240, V v_z_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2esurface_2enameAnn(v_p_240));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_span_245;
    switch (heff_tag_of(v_p_240)) {
    case TAG_At: {
      V v_s_244 = heff_field(v_p_240, 1);
      v_span_245 = heff_dup(v_s_244);
      break;
    }
    default: heff_nomatch(v_p_240);
    }
    V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eparamOf_str0), v_span_245, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_246}), v_z_241});
  }
  case TAG_Just: {
    V v_q_247 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_248 = heff_tag_n(TAG_ExplicitParam, 3, (V[]){heff_take_field(v_q_247, 0), heff_dup(heff_rfield(v_q_247, 1)), heff_dup(heff_rfield(v_q_247, 2))});
    V v_t_249 = heff_take_field(v_q_247, 2);
    V v_b_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_At: {
      V v_s_2411 = heff_field(v_t_249, 1);
      heff_take_n(v_t_249, 2ULL, 2);
      v_b_2412 = v_s_2411;
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_t_2413 = heff_get_n(heff_get_n(v_q_247, 1, 3), 0, 2);
    V v_t_2414 = ({ V rv_0 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_b_2412, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_x_2415 = heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_t_2414});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_242_24Just, TAG_Right, 1, (V[]){v_x_2415}), v_z_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eparamOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2edataParamL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edataParamL(V v_r_240, V v_e_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2esurface_2eatomOf(heff_dup(v_e_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    HEFF_LAST return g_heff_2esyntax_2esurface_2edataParamOf(v_r_240, v_e_241);
  }
  case TAG_Just: {
    V v_x_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_e_241);
    return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamL_lam0, 1, 1, (V[]){v_x_243});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edataParamL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_243, 3)), heff_dup(heff_rfield(v_x_243, 4))});
  V v_t_246 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_243, 3)), heff_dup(heff_rfield(v_x_243, 4))});
  V v_t_248 = heff_tag_n(TAG_ExplicitParam, 3, (V[]){heff_take_field(v_x_243, 1), v_t_245, heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_t_247})});
  V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_243, 3), heff_get_n(v_x_243, 4, 9)});
  V v_t_2410 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_t_249})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_st_244});
}
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_entry, 6, 0};

V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426(V v_d_240, V v_kw_241, V v_name_242, V v_params_243, V v_fields_244, V v_z_245) {
top: ;
  V v_m_246 = (g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(v_params_243));
  V v_x1_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_245}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop_rec(v_name_242, 9);
      heff_drop(v_fields_244);
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_247_24MkPair, 2);
      V v_t_2412 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2411)));
      return (g_heff_2esyntax_2esurface_2ewithScope(v_t_2412, heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_lam0, 1, 5, (V[]){v_fields_244, v_name_242, v_d_240, v_kw_241, v_x_2411}), v_st_249));
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_lam0(V self, V *args) {
  V v_st_2413 = args[0];
  V v_fields_244 = heff_env(self)[0];
  V v_name_242 = heff_env(self)[1];
  V v_d_240 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2414 = (g_heff_2esyntax_2esurface_2eblock_24s611148689x133456453(v_fields_244, v_st_2413));
  switch (heff_tag_of(v_x1_2414)) {
  case TAG_MkPair: {
    V v_x11_2415 = heff_field(v_x1_2414, 0);
    V v_st_2416 = heff_field(v_x1_2414, 1);
    V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
    switch (heff_tag_of(v_x11_2415)) {
    case TAG_Left: {
      V v_e_2417 = heff_field(v_x11_2415, 0);
      heff_take_n(v_x11_2415, 1ULL, 1);
      heff_drop_rec(v_name_242, 9);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_x_2411);
      return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
    }
    case TAG_Right: {
      V v_x_2418 = heff_field(v_x11_2415, 0);
      V v_ru_24x11_2415_24Right = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
      V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_name_242, 3), heff_take_field(v_name_242, 4)});
      V v_t_2420 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_240)));
      V v_e_2421 = heff_get_n(v_t_2420, 4, 9);
      V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), v_e_2421});
      V v_t_2423 = heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_ESig, 1, (V[]){v_x_2418}), v_t_2422});
      V v_t_2424 = heff_tag_n(TAG_DeclTheory, 4, (V[]){heff_get_n(v_name_242, 1, 9), v_t_2419, v_x_2411, v_t_2423});
      V v_t_2425 = (g_heff_2esyntax_2ecst_2elastD(v_d_240));
      V v_e_2426 = heff_get_n(v_t_2425, 4, 9);
      V v_t_2427 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2426});
      V v_t_2428 = heff_tag_at_n(v_ru_24x11_2415_24Right, TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_t_2427})});
      V v_x_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2429}), v_st_2416});
    }
    default: return heff_nomatch(v_x11_2415);
    }
  }
  default: return heff_nomatch(v_x1_2414);
  }
}
V g_heff_2esyntax_2esurface_2ereadPlaced_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ereadPlaced_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadPlaced_entry, 5, 0};

V g_heff_2esyntax_2esurface_2ereadPlaced(V v_at_240, V v_lexDiags_241, V v_own_242, V v_r_243, V v_placed_244) {
top: ;
  V v_items_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_placed_244, 0)));
  V v_t_246 = (g_heff_2esyntax_2esurface_2enameSet(heff_rfield(v_r_243, 2)));
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = v_items_245; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2eassembleGo(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_placed_244, 2, 3)));
  V v_items_249 = heff_dup(heff_rfield(v_r_243, 0));
  V v_t_2410 = (g_heff_2esyntax_2esurface_2enameSet(heff_rfield(v_r_243, 2)));
  V v_t_2411 = (g_heff_2esyntax_2esurface_2esigNames(v_items_249));
  V v_t_2412 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_249));
  V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eassembleDiagOne_clo), 3, (V[]){v_t_2410, v_t_2411, v_t_2412}));
  V v_t_2414 = (g_list_2emap(v_t_2413, v_items_249));
  V v_t_2415 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2414));
  V v_t_2416 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
  V v_d_2420 = (g_list_2efoldl(heff_clo_n(g_heff_2esyntax_2esurface_2ereadPlaced_lam0, 2, 1, (V[]){v_at_240}), v_t_2416, heff_rfield(v_r_243, 0)));
  V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2420, 3, 4)));
  V v_t_2422 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2415, v_t_2421));
  V v_t_2423 = (g_heff_2esyntax_2esurface_2eappendS(v_t_248, v_t_2422));
  V v_t_2424 = (g_heff_2esyntax_2esurface_2eappendS(heff_take_field(v_r_243, 1), v_t_2423));
  V v_t_2425 = (g_heff_2esyntax_2esurface_2eappendS(heff_take_field(v_own_242, 1), v_t_2424));
  V v_t_2426 = (g_heff_2esyntax_2esurface_2eappendS(v_lexDiags_241, v_t_2425));
  return heff_rec_n(4, shape_decls__diags__fixities__broken, (V[]){v_t_247, v_t_2426, heff_get_n(v_own_242, 0, 2), heff_get_n(v_r_243, 2, 3)});
}
V g_heff_2esyntax_2esurface_2ereadPlaced_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereadPlaced(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2ereadPlaced_lam0(V self, V *args) {
  V v_d_2417 = args[0];
  V v_it_2418 = args[1];
  V v_at_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2417, 2)), v_it_2418));
  return ({ V a_0 = v_at_240; V a_1 = v_d_2417; V a_2 = v_t_2419; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
}