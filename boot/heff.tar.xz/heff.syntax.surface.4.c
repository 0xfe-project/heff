// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_BadFieldDecl 11244
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclareField 57313
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Update 40810
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_held 9694204
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_pat 320285
#define LBL_prims 308293287
#define LBL_rest 9992347
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_sigs 10025609
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_unit 10090059
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_decls__diags__fixities__broken[] = {LBL_decls, LBL_diags, LBL_fixities, LBL_broken};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_sigs__held__rest[] = {LBL_sigs, LBL_held, LBL_rest};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2epresyntax_2eboolOf(V);
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2edataParamL(V, V);
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_clo;
V g_heff_2esyntax_2esurface_2edataParamOf(V, V);
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2efieldDeclOf(V, V);
V g_heff_2esyntax_2esurface_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldDeclOf_clo;
V g_heff_2esyntax_2esurface_2efieldL(V, V);
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efirstSig_24cpr(V);
HeffT2 g_heff_2esyntax_2esurface_2efixDeclAt_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclOf(V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDeclOf_clo;
V g_heff_2esyntax_2esurface_2egroupFrom(V, V);
V g_heff_2esyntax_2esurface_2egroupFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2egroupFrom_clo;
HeffT3 g_heff_2esyntax_2esurface_2egroupFrom_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eifE(V, V, V, V);
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifE_clo;
V g_heff_2esyntax_2esurface_2eintegerChecks(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerChecks_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerChecks_clo;
V g_heff_2esyntax_2esurface_2emutualDefs(V);
V g_heff_2esyntax_2esurface_2emutualDefs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_clo;
HeffT2 g_heff_2esyntax_2esurface_2emutualItems_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2emutualL_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2emutualOut(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2emutualOut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualOut_clo;
HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V);
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2ereadPlaced(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadPlaced_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadPlaced_clo;
HeffT2 g_heff_2esyntax_2esurface_2erepeatedField_24cpr(V, V);
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2esplitExp(V, V);
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esplitExp_clo;
V g_heff_2esyntax_2esurface_2espreadGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2espreadGo_clo;
V g_heff_2esyntax_2esurface_2etypeChecks(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_clo;
V g_heff_2esyntax_2esurface_2eunitIn(V, V);
V g_heff_2esyntax_2esurface_2eunitIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunitIn_clo;
V g_heff_2esyntax_2esurface_2evalueOfE(V);
V g_heff_2esyntax_2esurface_2evalueOfE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evalueOfE_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
V g_heff_2esyntax_2esurface_2ewithScope_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_24tok2_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s2081681776x559624592(V);
V g_list_2emap_24s2081681776x559624592_entry(V self, V *a);
extern Clo g_list_2emap_24s2081681776x559624592_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_std_2emap_2eempty_get(void);
Clo g_heff_2esyntax_2esurface_2eappendS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2esyntax_2esurface_2eappendS_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2esplitExp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esplitExp_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esplitExp(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return heff_strLength_lent(v_s_240, 0);
  } else {
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)) == ((int64_t)101ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)) == ((int64_t)69ULL)))) {
      return heff_box_word(v_i_241);
    } else {
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esplitExp(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2egroupFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2egroupFrom_entry, 2, 0};

V g_heff_2esyntax_2esurface_2egroupFrom(V v_sp_240, V v_x2_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2esyntax_2esurface_2egroupFrom_24cpr(v_sp_240, v_x2_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    return heff_rec_n(3, shape_sigs__held__rest, (V[]){v_field_243, v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2esurface_2egroupFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2egroupFrom(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldL_str0, 1, "=");
V g_heff_2esyntax_2esurface_2efieldL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam43(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam44(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efieldL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efieldL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efieldL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Atom: {
    V v_m_243 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EParen: {
    V v_m_2414 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam1, 1, 1, (V[]){v_m_2414});
  }
  case TAG_Named: {
    V v_m_2427 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam2, 1, 1, (V[]){v_m_2427});
  }
  case TAG_Tup: {
    V v_m_2439 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam3, 1, 1, (V[]){v_m_2439});
  }
  case TAG_Seg: {
    V v_m_2450 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam4, 1, 1, (V[]){v_m_2450});
  }
  case TAG_Braces: {
    V v_m_2462 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam5, 1, 1, (V[]){v_m_2462});
  }
  case TAG_Update: {
    V v_m_2476 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam6, 1, 1, (V[]){v_m_2476});
  }
  case TAG_EUSet: {
    V v_m_2487 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam7, 1, 1, (V[]){v_m_2487});
  }
  case TAG_InstB: {
    V v_m_24100 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam8, 1, 1, (V[]){v_m_24100});
  }
  case TAG_EFSet: {
    V v_m_24111 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam9, 1, 1, (V[]){v_m_24111});
  }
  case TAG_EFDefault: {
    V v_e_24119 = heff_field(v_x2_241, 0);
    V v_eq_24120 = heff_field(v_x2_241, 1);
    V v_d_24121 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24122 = (g_heff_2esyntax_2esurface_2edeclarationL(heff_dup(v_r_240), v_e_24119));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam10, 1, 4, (V[]){v_m_24122, v_r_240, v_d_24121, v_eq_24120});
  }
  case TAG_Sum: {
    V v_m_24144 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam11, 1, 1, (V[]){v_m_24144});
  }
  case TAG_ECon: {
    V v_m_24154 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam12, 1, 1, (V[]){v_m_24154});
  }
  case TAG_EField: {
    V v_m_24164 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam13, 1, 1, (V[]){v_m_24164});
  }
  case TAG_ENeg: {
    V v_m_24174 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam14, 1, 1, (V[]){v_m_24174});
  }
  case TAG_ETilde: {
    V v_m_24184 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam15, 1, 1, (V[]){v_m_24184});
  }
  case TAG_App: {
    V v_m_24194 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam16, 1, 1, (V[]){v_m_24194});
  }
  case TAG_Op: {
    V v_m_24205 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam17, 1, 1, (V[]){v_m_24205});
  }
  case TAG_Ops: {
    V v_m_24215 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam18, 1, 1, (V[]){v_m_24215});
  }
  case TAG_OpRhs: {
    V v_m_24225 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam19, 1, 1, (V[]){v_m_24225});
  }
  case TAG_Ann: {
    V v_m_24236 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam20, 1, 1, (V[]){v_m_24236});
  }
  case TAG_BVar: {
    V v_m_24245 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam21, 1, 1, (V[]){v_m_24245});
  }
  case TAG_BImp: {
    V v_m_24256 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam22, 1, 1, (V[]){v_m_24256});
  }
  case TAG_BAnn: {
    V v_m_24269 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam23, 1, 1, (V[]){v_m_24269});
  }
  case TAG_BPat: {
    V v_m_24278 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam24, 1, 1, (V[]){v_m_24278});
  }
  case TAG_Lam: {
    V v_m_24290 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam25, 1, 1, (V[]){v_m_24290});
  }
  case TAG_Case: {
    V v_m_24302 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam26, 1, 1, (V[]){v_m_24302});
  }
  case TAG_EAlt: {
    V v_m_24313 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam27, 1, 1, (V[]){v_m_24313});
  }
  case TAG_If: {
    V v_m_24327 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam28, 1, 1, (V[]){v_m_24327});
  }
  case TAG_Do: {
    V v_m_24337 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam29, 1, 1, (V[]){v_m_24337});
  }
  case TAG_ESBind: {
    V v_m_24348 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam30, 1, 1, (V[]){v_m_24348});
  }
  case TAG_ELet: {
    V v_m_24362 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam31, 1, 1, (V[]){v_m_24362});
  }
  case TAG_ELetElse: {
    V v_m_24377 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam32, 1, 1, (V[]){v_m_24377});
  }
  case TAG_ELetMut: {
    V v_m_24391 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam33, 1, 1, (V[]){v_m_24391});
  }
  case TAG_EAssign: {
    V v_m_24402 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam34, 1, 1, (V[]){v_m_24402});
  }
  case TAG_EWhile: {
    V v_m_24414 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam35, 1, 1, (V[]){v_m_24414});
  }
  case TAG_EFor: {
    V v_m_24428 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam36, 1, 1, (V[]){v_m_24428});
  }
  case TAG_EJump: {
    V v_m_24437 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam37, 1, 1, (V[]){v_m_24437});
  }
  case TAG_EReturn: {
    V v_m_24447 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam38, 1, 1, (V[]){v_m_24447});
  }
  case TAG_ENest: {
    V v_m_24459 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam39, 1, 1, (V[]){v_m_24459});
  }
  case TAG_EArrow: {
    V v_m_24469 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam40, 1, 1, (V[]){v_m_24469});
  }
  case TAG_IfThen: {
    V v_m_24481 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam41, 1, 1, (V[]){v_m_24481});
  }
  case TAG_ETry: {
    V v_m_24493 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam42, 1, 1, (V[]){v_m_24493});
  }
  case TAG_ECatch: {
    V v_m_24505 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam43, 1, 1, (V[]){v_m_24505});
  }
  case TAG_EWith: {
    V v_m_24519 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam44, 1, 1, (V[]){v_m_24519});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efieldL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2efieldL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      V v_x_2410 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_249, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2410}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam1(V self, V *args) {
  V v_st_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_st_2415}));
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_MkPair: {
    V v_x11_2417 = heff_field(v_x1_2416, 0);
    V v_st_2418 = heff_field(v_x1_2416, 1);
    V v_ru_24x1_2416_24MkPair = heff_take_reuse_n(v_x1_2416, 3ULL, 2);
    switch (heff_tag_of(v_x11_2417)) {
    case TAG_Left: {
      V v_e_2419 = heff_field(v_x11_2417, 0);
      heff_take_n(v_x11_2417, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2419}), v_st_2418});
    }
    case TAG_Right: {
      V v_x_2420 = heff_field(v_x11_2417, 0);
      heff_take_n(v_x11_2417, 1ULL, 1);
      V v_x_2421 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2420, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2421}), v_st_2418});
    }
    default: return heff_nomatch(v_x11_2417);
    }
  }
  default: return heff_nomatch(v_x1_2416);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam2(V self, V *args) {
  V v_st_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_st_2428}));
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_MkPair: {
    V v_x11_2430 = heff_field(v_x1_2429, 0);
    V v_st_2431 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24MkPair = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_Left: {
      V v_e_2432 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2432}), v_st_2431});
    }
    case TAG_Right: {
      V v_x_2433 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      V v_x_2434 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2433, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2434}), v_st_2431});
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_2429);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam3(V self, V *args) {
  V v_st_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_st_2440}));
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_MkPair: {
    V v_x11_2442 = heff_field(v_x1_2441, 0);
    V v_st_2443 = heff_field(v_x1_2441, 1);
    V v_ru_24x1_2441_24MkPair = heff_take_reuse_n(v_x1_2441, 3ULL, 2);
    switch (heff_tag_of(v_x11_2442)) {
    case TAG_Left: {
      V v_e_2444 = heff_field(v_x11_2442, 0);
      heff_take_n(v_x11_2442, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2444}), v_st_2443});
    }
    case TAG_Right: {
      V v_x_2445 = heff_field(v_x11_2442, 0);
      heff_take_n(v_x11_2442, 1ULL, 1);
      V v_x_2446 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2445, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2446}), v_st_2443});
    }
    default: return heff_nomatch(v_x11_2442);
    }
  }
  default: return heff_nomatch(v_x1_2441);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam4(V self, V *args) {
  V v_st_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_st_2451}));
  switch (heff_tag_of(v_x1_2452)) {
  case TAG_MkPair: {
    V v_x11_2453 = heff_field(v_x1_2452, 0);
    V v_st_2454 = heff_field(v_x1_2452, 1);
    V v_ru_24x1_2452_24MkPair = heff_take_reuse_n(v_x1_2452, 3ULL, 2);
    switch (heff_tag_of(v_x11_2453)) {
    case TAG_Left: {
      V v_e_2455 = heff_field(v_x11_2453, 0);
      heff_take_n(v_x11_2453, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2455}), v_st_2454});
    }
    case TAG_Right: {
      V v_x_2456 = heff_field(v_x11_2453, 0);
      heff_take_n(v_x11_2453, 1ULL, 1);
      V v_x_2457 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2456, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2457}), v_st_2454});
    }
    default: return heff_nomatch(v_x11_2453);
    }
  }
  default: return heff_nomatch(v_x1_2452);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam5(V self, V *args) {
  V v_st_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2464 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_st_2463}));
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_MkPair: {
    V v_x11_2465 = heff_field(v_x1_2464, 0);
    V v_st_2466 = heff_field(v_x1_2464, 1);
    V v_ru_24x1_2464_24MkPair = heff_take_reuse_n(v_x1_2464, 3ULL, 2);
    switch (heff_tag_of(v_x11_2465)) {
    case TAG_Left: {
      V v_e_2467 = heff_field(v_x11_2465, 0);
      heff_take_n(v_x11_2465, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2467}), v_st_2466});
    }
    case TAG_Right: {
      V v_x_2468 = heff_field(v_x11_2465, 0);
      heff_take_n(v_x11_2465, 1ULL, 1);
      V v_x_2469 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2468, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2469}), v_st_2466});
    }
    default: return heff_nomatch(v_x11_2465);
    }
  }
  default: return heff_nomatch(v_x1_2464);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam6(V self, V *args) {
  V v_st_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2478 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_st_2477}));
  switch (heff_tag_of(v_x1_2478)) {
  case TAG_MkPair: {
    V v_x11_2479 = heff_field(v_x1_2478, 0);
    V v_st_2480 = heff_field(v_x1_2478, 1);
    V v_ru_24x1_2478_24MkPair = heff_take_reuse_n(v_x1_2478, 3ULL, 2);
    switch (heff_tag_of(v_x11_2479)) {
    case TAG_Left: {
      V v_e_2481 = heff_field(v_x11_2479, 0);
      heff_take_n(v_x11_2479, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2481}), v_st_2480});
    }
    case TAG_Right: {
      V v_x_2482 = heff_field(v_x11_2479, 0);
      heff_take_n(v_x11_2479, 1ULL, 1);
      V v_x_2483 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2482, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2483}), v_st_2480});
    }
    default: return heff_nomatch(v_x11_2479);
    }
  }
  default: return heff_nomatch(v_x1_2478);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam7(V self, V *args) {
  V v_st_2488 = args[0];
  V v_m_2487 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2489 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_st_2488}));
  switch (heff_tag_of(v_x1_2489)) {
  case TAG_MkPair: {
    V v_x11_2490 = heff_field(v_x1_2489, 0);
    V v_st_2491 = heff_field(v_x1_2489, 1);
    V v_ru_24x1_2489_24MkPair = heff_take_reuse_n(v_x1_2489, 3ULL, 2);
    switch (heff_tag_of(v_x11_2490)) {
    case TAG_Left: {
      V v_e_2492 = heff_field(v_x11_2490, 0);
      heff_take_n(v_x11_2490, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2492}), v_st_2491});
    }
    case TAG_Right: {
      V v_x_2493 = heff_field(v_x11_2490, 0);
      heff_take_n(v_x11_2490, 1ULL, 1);
      V v_x_2494 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2493, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2494}), v_st_2491});
    }
    default: return heff_nomatch(v_x11_2490);
    }
  }
  default: return heff_nomatch(v_x1_2489);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam8(V self, V *args) {
  V v_st_24101 = args[0];
  V v_m_24100 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24102 = heff_tr(heff_call(v_m_24100, 1, (V[]){v_st_24101}));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_MkPair: {
    V v_x11_24103 = heff_field(v_x1_24102, 0);
    V v_st_24104 = heff_field(v_x1_24102, 1);
    V v_ru_24x1_24102_24MkPair = heff_take_reuse_n(v_x1_24102, 3ULL, 2);
    switch (heff_tag_of(v_x11_24103)) {
    case TAG_Left: {
      V v_e_24105 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24105}), v_st_24104});
    }
    case TAG_Right: {
      V v_x_24106 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      V v_x_24107 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24106, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24107}), v_st_24104});
    }
    default: return heff_nomatch(v_x11_24103);
    }
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam9(V self, V *args) {
  V v_st_24112 = args[0];
  V v_m_24111 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24113 = heff_tr(heff_call(v_m_24111, 1, (V[]){v_st_24112}));
  switch (heff_tag_of(v_x1_24113)) {
  case TAG_MkPair: {
    V v_x11_24114 = heff_field(v_x1_24113, 0);
    V v_st_24115 = heff_field(v_x1_24113, 1);
    V v_ru_24x1_24113_24MkPair = heff_take_reuse_n(v_x1_24113, 3ULL, 2);
    switch (heff_tag_of(v_x11_24114)) {
    case TAG_Left: {
      V v_e_24116 = heff_field(v_x11_24114, 0);
      heff_take_n(v_x11_24114, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24116}), v_st_24115});
    }
    case TAG_Right: {
      V v_x_24117 = heff_field(v_x11_24114, 0);
      heff_take_n(v_x11_24114, 1ULL, 1);
      V v_x_24118 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24117, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24118}), v_st_24115});
    }
    default: return heff_nomatch(v_x11_24114);
    }
  }
  default: return heff_nomatch(v_x1_24113);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam10(V self, V *args) {
  V v_st_24123 = args[0];
  V v_m_24122 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_d_24121 = heff_env(self)[2];
  V v_eq_24120 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24124 = heff_tr(heff_call(v_m_24122, 1, (V[]){v_st_24123}));
  switch (heff_tag_of(v_x1_24124)) {
  case TAG_MkPair: {
    V v_x11_24125 = heff_field(v_x1_24124, 0);
    V v_st_24126 = heff_field(v_x1_24124, 1);
    V v_ru_24x1_24124_24MkPair = heff_take_reuse_n(v_x1_24124, 3ULL, 2);
    switch (heff_tag_of(v_x11_24125)) {
    case TAG_Left: {
      V v_e_24127 = heff_field(v_x11_24125, 0);
      heff_take_n(v_x11_24125, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_24121);
      heff_drop_rec(v_eq_24120, 9);
      return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24127}), v_st_24126});
    }
    case TAG_Right: {
      V v_x_24128 = heff_field(v_x11_24125, 0);
      V v_ru_24x11_24125_24Right = heff_take_reuse_n(v_x11_24125, 1ULL, 1);
      V v_m_24129 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_24121}));
      V v_x1_24130 = heff_tr(heff_call(v_m_24129, 1, (V[]){v_st_24126}));
      switch (heff_tag_of(v_x1_24130)) {
      case TAG_MkPair: {
        V v_x11_24131 = heff_field(v_x1_24130, 0);
        V v_st_24132 = heff_field(v_x1_24130, 1);
        V v_ru_24x1_24130_24MkPair = heff_take_reuse_n(v_x1_24130, 3ULL, 2);
        switch (heff_tag_of(v_x11_24131)) {
        case TAG_Left: {
          V v_e_24133 = heff_field(v_x11_24131, 0);
          heff_take_n(v_x11_24131, 1ULL, 1);
          heff_drop_rec(v_eq_24120, 9);
          heff_drop(v_x_24128);
          heff_drop_cell(v_ru_24x11_24125_24Right, 1);
          heff_drop_cell(v_ru_24x1_24130_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24133}), v_st_24132});
        }
        case TAG_Right: {
          V v_x_24134 = heff_field(v_x11_24131, 0);
          heff_take_n(v_x11_24131, 1ULL, 1);
          V v_x_24138;
          if (heff_strEq_c(heff_get_n(v_eq_24120, 1, 9), ((V)&g_heff_2esyntax_2esurface_2efieldL_str0))) {
            heff_drop_cell(v_ru_24x1_24130_24MkPair, 2);
            v_x_24138 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24128, heff_tag_at_n(v_ru_24x11_24125_24Right, TAG_Just, 1, (V[]){v_x_24134})));
          } else {
            heff_drop(v_x_24134);
            V v_t_24137;
            switch (heff_tag_of(v_x_24128)) {
            case TAG_At: {
              V v_s_24136 = heff_dup(heff_field(v_x_24128, 1));
              v_t_24137 = v_s_24136;
              break;
            }
            default: heff_nomatch(v_x_24128);
            }
            v_x_24138 = heff_tag_at_n(v_ru_24x1_24130_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24125_24Right, TAG_BadFieldDecl, 1, (V[]){v_x_24128}), v_t_24137});
          }
          return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24138}), v_st_24132});
        }
        default: return heff_nomatch(v_x11_24131);
        }
      }
      default: return heff_nomatch(v_x1_24130);
      }
    }
    default: return heff_nomatch(v_x11_24125);
    }
  }
  default: return heff_nomatch(v_x1_24124);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam11(V self, V *args) {
  V v_st_24145 = args[0];
  V v_m_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24146 = heff_tr(heff_call(v_m_24144, 1, (V[]){v_st_24145}));
  switch (heff_tag_of(v_x1_24146)) {
  case TAG_MkPair: {
    V v_x11_24147 = heff_field(v_x1_24146, 0);
    V v_st_24148 = heff_field(v_x1_24146, 1);
    V v_ru_24x1_24146_24MkPair = heff_take_reuse_n(v_x1_24146, 3ULL, 2);
    switch (heff_tag_of(v_x11_24147)) {
    case TAG_Left: {
      V v_e_24149 = heff_field(v_x11_24147, 0);
      heff_take_n(v_x11_24147, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24149}), v_st_24148});
    }
    case TAG_Right: {
      V v_x_24150 = heff_field(v_x11_24147, 0);
      heff_take_n(v_x11_24147, 1ULL, 1);
      V v_x_24151 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24150, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24151}), v_st_24148});
    }
    default: return heff_nomatch(v_x11_24147);
    }
  }
  default: return heff_nomatch(v_x1_24146);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam12(V self, V *args) {
  V v_st_24155 = args[0];
  V v_m_24154 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24156 = heff_tr(heff_call(v_m_24154, 1, (V[]){v_st_24155}));
  switch (heff_tag_of(v_x1_24156)) {
  case TAG_MkPair: {
    V v_x11_24157 = heff_field(v_x1_24156, 0);
    V v_st_24158 = heff_field(v_x1_24156, 1);
    V v_ru_24x1_24156_24MkPair = heff_take_reuse_n(v_x1_24156, 3ULL, 2);
    switch (heff_tag_of(v_x11_24157)) {
    case TAG_Left: {
      V v_e_24159 = heff_field(v_x11_24157, 0);
      heff_take_n(v_x11_24157, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24156_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24159}), v_st_24158});
    }
    case TAG_Right: {
      V v_x_24160 = heff_field(v_x11_24157, 0);
      heff_take_n(v_x11_24157, 1ULL, 1);
      V v_x_24161 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24160, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24156_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24161}), v_st_24158});
    }
    default: return heff_nomatch(v_x11_24157);
    }
  }
  default: return heff_nomatch(v_x1_24156);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam13(V self, V *args) {
  V v_st_24165 = args[0];
  V v_m_24164 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24166 = heff_tr(heff_call(v_m_24164, 1, (V[]){v_st_24165}));
  switch (heff_tag_of(v_x1_24166)) {
  case TAG_MkPair: {
    V v_x11_24167 = heff_field(v_x1_24166, 0);
    V v_st_24168 = heff_field(v_x1_24166, 1);
    V v_ru_24x1_24166_24MkPair = heff_take_reuse_n(v_x1_24166, 3ULL, 2);
    switch (heff_tag_of(v_x11_24167)) {
    case TAG_Left: {
      V v_e_24169 = heff_field(v_x11_24167, 0);
      heff_take_n(v_x11_24167, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24166_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24169}), v_st_24168});
    }
    case TAG_Right: {
      V v_x_24170 = heff_field(v_x11_24167, 0);
      heff_take_n(v_x11_24167, 1ULL, 1);
      V v_x_24171 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24170, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24166_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24171}), v_st_24168});
    }
    default: return heff_nomatch(v_x11_24167);
    }
  }
  default: return heff_nomatch(v_x1_24166);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam14(V self, V *args) {
  V v_st_24175 = args[0];
  V v_m_24174 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24176 = heff_tr(heff_call(v_m_24174, 1, (V[]){v_st_24175}));
  switch (heff_tag_of(v_x1_24176)) {
  case TAG_MkPair: {
    V v_x11_24177 = heff_field(v_x1_24176, 0);
    V v_st_24178 = heff_field(v_x1_24176, 1);
    V v_ru_24x1_24176_24MkPair = heff_take_reuse_n(v_x1_24176, 3ULL, 2);
    switch (heff_tag_of(v_x11_24177)) {
    case TAG_Left: {
      V v_e_24179 = heff_field(v_x11_24177, 0);
      heff_take_n(v_x11_24177, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24176_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24179}), v_st_24178});
    }
    case TAG_Right: {
      V v_x_24180 = heff_field(v_x11_24177, 0);
      heff_take_n(v_x11_24177, 1ULL, 1);
      V v_x_24181 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24180, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24176_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24181}), v_st_24178});
    }
    default: return heff_nomatch(v_x11_24177);
    }
  }
  default: return heff_nomatch(v_x1_24176);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam15(V self, V *args) {
  V v_st_24185 = args[0];
  V v_m_24184 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24186 = heff_tr(heff_call(v_m_24184, 1, (V[]){v_st_24185}));
  switch (heff_tag_of(v_x1_24186)) {
  case TAG_MkPair: {
    V v_x11_24187 = heff_field(v_x1_24186, 0);
    V v_st_24188 = heff_field(v_x1_24186, 1);
    V v_ru_24x1_24186_24MkPair = heff_take_reuse_n(v_x1_24186, 3ULL, 2);
    switch (heff_tag_of(v_x11_24187)) {
    case TAG_Left: {
      V v_e_24189 = heff_field(v_x11_24187, 0);
      heff_take_n(v_x11_24187, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24186_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24189}), v_st_24188});
    }
    case TAG_Right: {
      V v_x_24190 = heff_field(v_x11_24187, 0);
      heff_take_n(v_x11_24187, 1ULL, 1);
      V v_x_24191 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24190, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24186_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24191}), v_st_24188});
    }
    default: return heff_nomatch(v_x11_24187);
    }
  }
  default: return heff_nomatch(v_x1_24186);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam16(V self, V *args) {
  V v_st_24195 = args[0];
  V v_m_24194 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24196 = heff_tr(heff_call(v_m_24194, 1, (V[]){v_st_24195}));
  switch (heff_tag_of(v_x1_24196)) {
  case TAG_MkPair: {
    V v_x11_24197 = heff_field(v_x1_24196, 0);
    V v_st_24198 = heff_field(v_x1_24196, 1);
    V v_ru_24x1_24196_24MkPair = heff_take_reuse_n(v_x1_24196, 3ULL, 2);
    switch (heff_tag_of(v_x11_24197)) {
    case TAG_Left: {
      V v_e_24199 = heff_field(v_x11_24197, 0);
      heff_take_n(v_x11_24197, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24199}), v_st_24198});
    }
    case TAG_Right: {
      V v_x_24200 = heff_field(v_x11_24197, 0);
      heff_take_n(v_x11_24197, 1ULL, 1);
      V v_x_24201 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24200, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24201}), v_st_24198});
    }
    default: return heff_nomatch(v_x11_24197);
    }
  }
  default: return heff_nomatch(v_x1_24196);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam17(V self, V *args) {
  V v_st_24206 = args[0];
  V v_m_24205 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24207 = heff_tr(heff_call(v_m_24205, 1, (V[]){v_st_24206}));
  switch (heff_tag_of(v_x1_24207)) {
  case TAG_MkPair: {
    V v_x11_24208 = heff_field(v_x1_24207, 0);
    V v_st_24209 = heff_field(v_x1_24207, 1);
    V v_ru_24x1_24207_24MkPair = heff_take_reuse_n(v_x1_24207, 3ULL, 2);
    switch (heff_tag_of(v_x11_24208)) {
    case TAG_Left: {
      V v_e_24210 = heff_field(v_x11_24208, 0);
      heff_take_n(v_x11_24208, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24210}), v_st_24209});
    }
    case TAG_Right: {
      V v_x_24211 = heff_field(v_x11_24208, 0);
      heff_take_n(v_x11_24208, 1ULL, 1);
      V v_x_24212 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24211, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24212}), v_st_24209});
    }
    default: return heff_nomatch(v_x11_24208);
    }
  }
  default: return heff_nomatch(v_x1_24207);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam18(V self, V *args) {
  V v_st_24216 = args[0];
  V v_m_24215 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24217 = heff_tr(heff_call(v_m_24215, 1, (V[]){v_st_24216}));
  switch (heff_tag_of(v_x1_24217)) {
  case TAG_MkPair: {
    V v_x11_24218 = heff_field(v_x1_24217, 0);
    V v_st_24219 = heff_field(v_x1_24217, 1);
    V v_ru_24x1_24217_24MkPair = heff_take_reuse_n(v_x1_24217, 3ULL, 2);
    switch (heff_tag_of(v_x11_24218)) {
    case TAG_Left: {
      V v_e_24220 = heff_field(v_x11_24218, 0);
      heff_take_n(v_x11_24218, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24220}), v_st_24219});
    }
    case TAG_Right: {
      V v_x_24221 = heff_field(v_x11_24218, 0);
      heff_take_n(v_x11_24218, 1ULL, 1);
      V v_x_24222 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24221, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24222}), v_st_24219});
    }
    default: return heff_nomatch(v_x11_24218);
    }
  }
  default: return heff_nomatch(v_x1_24217);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam19(V self, V *args) {
  V v_st_24226 = args[0];
  V v_m_24225 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24227 = heff_tr(heff_call(v_m_24225, 1, (V[]){v_st_24226}));
  switch (heff_tag_of(v_x1_24227)) {
  case TAG_MkPair: {
    V v_x11_24228 = heff_field(v_x1_24227, 0);
    V v_st_24229 = heff_field(v_x1_24227, 1);
    V v_ru_24x1_24227_24MkPair = heff_take_reuse_n(v_x1_24227, 3ULL, 2);
    switch (heff_tag_of(v_x11_24228)) {
    case TAG_Left: {
      V v_e_24230 = heff_field(v_x11_24228, 0);
      heff_take_n(v_x11_24228, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24227_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24230}), v_st_24229});
    }
    case TAG_Right: {
      V v_x_24231 = heff_field(v_x11_24228, 0);
      heff_take_n(v_x11_24228, 1ULL, 1);
      V v_x_24232 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24231, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24227_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24232}), v_st_24229});
    }
    default: return heff_nomatch(v_x11_24228);
    }
  }
  default: return heff_nomatch(v_x1_24227);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam20(V self, V *args) {
  V v_st_24237 = args[0];
  V v_m_24236 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24238 = heff_tr(heff_call(v_m_24236, 1, (V[]){v_st_24237}));
  switch (heff_tag_of(v_x1_24238)) {
  case TAG_MkPair: {
    V v_x11_24239 = heff_field(v_x1_24238, 0);
    V v_st_24240 = heff_field(v_x1_24238, 1);
    V v_ru_24x1_24238_24MkPair = heff_take_reuse_n(v_x1_24238, 3ULL, 2);
    switch (heff_tag_of(v_x11_24239)) {
    case TAG_Left: {
      V v_e_24241 = heff_field(v_x11_24239, 0);
      heff_take_n(v_x11_24239, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24241}), v_st_24240});
    }
    case TAG_Right: {
      V v_x_24242 = heff_field(v_x11_24239, 0);
      heff_take_n(v_x11_24239, 1ULL, 1);
      V v_x_24243 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24242, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24243}), v_st_24240});
    }
    default: return heff_nomatch(v_x11_24239);
    }
  }
  default: return heff_nomatch(v_x1_24238);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam21(V self, V *args) {
  V v_st_24246 = args[0];
  V v_m_24245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24247 = heff_tr(heff_call(v_m_24245, 1, (V[]){v_st_24246}));
  switch (heff_tag_of(v_x1_24247)) {
  case TAG_MkPair: {
    V v_x11_24248 = heff_field(v_x1_24247, 0);
    V v_st_24249 = heff_field(v_x1_24247, 1);
    V v_ru_24x1_24247_24MkPair = heff_take_reuse_n(v_x1_24247, 3ULL, 2);
    switch (heff_tag_of(v_x11_24248)) {
    case TAG_Left: {
      V v_e_24250 = heff_field(v_x11_24248, 0);
      heff_take_n(v_x11_24248, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24250}), v_st_24249});
    }
    case TAG_Right: {
      V v_x_24251 = heff_field(v_x11_24248, 0);
      heff_take_n(v_x11_24248, 1ULL, 1);
      V v_x_24252 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24251, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24252}), v_st_24249});
    }
    default: return heff_nomatch(v_x11_24248);
    }
  }
  default: return heff_nomatch(v_x1_24247);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam22(V self, V *args) {
  V v_st_24257 = args[0];
  V v_m_24256 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24258 = heff_tr(heff_call(v_m_24256, 1, (V[]){v_st_24257}));
  switch (heff_tag_of(v_x1_24258)) {
  case TAG_MkPair: {
    V v_x11_24259 = heff_field(v_x1_24258, 0);
    V v_st_24260 = heff_field(v_x1_24258, 1);
    V v_ru_24x1_24258_24MkPair = heff_take_reuse_n(v_x1_24258, 3ULL, 2);
    switch (heff_tag_of(v_x11_24259)) {
    case TAG_Left: {
      V v_e_24261 = heff_field(v_x11_24259, 0);
      heff_take_n(v_x11_24259, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24258_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24261}), v_st_24260});
    }
    case TAG_Right: {
      V v_x_24262 = heff_field(v_x11_24259, 0);
      heff_take_n(v_x11_24259, 1ULL, 1);
      V v_x_24263 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24262, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24258_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24263}), v_st_24260});
    }
    default: return heff_nomatch(v_x11_24259);
    }
  }
  default: return heff_nomatch(v_x1_24258);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam23(V self, V *args) {
  V v_st_24270 = args[0];
  V v_m_24269 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24271 = heff_tr(heff_call(v_m_24269, 1, (V[]){v_st_24270}));
  switch (heff_tag_of(v_x1_24271)) {
  case TAG_MkPair: {
    V v_x11_24272 = heff_field(v_x1_24271, 0);
    V v_st_24273 = heff_field(v_x1_24271, 1);
    V v_ru_24x1_24271_24MkPair = heff_take_reuse_n(v_x1_24271, 3ULL, 2);
    switch (heff_tag_of(v_x11_24272)) {
    case TAG_Left: {
      V v_e_24274 = heff_field(v_x11_24272, 0);
      heff_take_n(v_x11_24272, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24271_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24274}), v_st_24273});
    }
    case TAG_Right: {
      V v_x_24275 = heff_field(v_x11_24272, 0);
      heff_take_n(v_x11_24272, 1ULL, 1);
      V v_x_24276 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24275, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24271_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24276}), v_st_24273});
    }
    default: return heff_nomatch(v_x11_24272);
    }
  }
  default: return heff_nomatch(v_x1_24271);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam24(V self, V *args) {
  V v_st_24279 = args[0];
  V v_m_24278 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24280 = heff_tr(heff_call(v_m_24278, 1, (V[]){v_st_24279}));
  switch (heff_tag_of(v_x1_24280)) {
  case TAG_MkPair: {
    V v_x11_24281 = heff_field(v_x1_24280, 0);
    V v_st_24282 = heff_field(v_x1_24280, 1);
    V v_ru_24x1_24280_24MkPair = heff_take_reuse_n(v_x1_24280, 3ULL, 2);
    switch (heff_tag_of(v_x11_24281)) {
    case TAG_Left: {
      V v_e_24283 = heff_field(v_x11_24281, 0);
      heff_take_n(v_x11_24281, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24280_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24283}), v_st_24282});
    }
    case TAG_Right: {
      V v_x_24284 = heff_field(v_x11_24281, 0);
      heff_take_n(v_x11_24281, 1ULL, 1);
      V v_x_24285 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24284, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24280_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24285}), v_st_24282});
    }
    default: return heff_nomatch(v_x11_24281);
    }
  }
  default: return heff_nomatch(v_x1_24280);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam25(V self, V *args) {
  V v_st_24291 = args[0];
  V v_m_24290 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24292 = heff_tr(heff_call(v_m_24290, 1, (V[]){v_st_24291}));
  switch (heff_tag_of(v_x1_24292)) {
  case TAG_MkPair: {
    V v_x11_24293 = heff_field(v_x1_24292, 0);
    V v_st_24294 = heff_field(v_x1_24292, 1);
    V v_ru_24x1_24292_24MkPair = heff_take_reuse_n(v_x1_24292, 3ULL, 2);
    switch (heff_tag_of(v_x11_24293)) {
    case TAG_Left: {
      V v_e_24295 = heff_field(v_x11_24293, 0);
      heff_take_n(v_x11_24293, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24292_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24295}), v_st_24294});
    }
    case TAG_Right: {
      V v_x_24296 = heff_field(v_x11_24293, 0);
      heff_take_n(v_x11_24293, 1ULL, 1);
      V v_x_24297 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24296, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24292_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24297}), v_st_24294});
    }
    default: return heff_nomatch(v_x11_24293);
    }
  }
  default: return heff_nomatch(v_x1_24292);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam26(V self, V *args) {
  V v_st_24303 = args[0];
  V v_m_24302 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24304 = heff_tr(heff_call(v_m_24302, 1, (V[]){v_st_24303}));
  switch (heff_tag_of(v_x1_24304)) {
  case TAG_MkPair: {
    V v_x11_24305 = heff_field(v_x1_24304, 0);
    V v_st_24306 = heff_field(v_x1_24304, 1);
    V v_ru_24x1_24304_24MkPair = heff_take_reuse_n(v_x1_24304, 3ULL, 2);
    switch (heff_tag_of(v_x11_24305)) {
    case TAG_Left: {
      V v_e_24307 = heff_field(v_x11_24305, 0);
      heff_take_n(v_x11_24305, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24304_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24307}), v_st_24306});
    }
    case TAG_Right: {
      V v_x_24308 = heff_field(v_x11_24305, 0);
      heff_take_n(v_x11_24305, 1ULL, 1);
      V v_x_24309 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24308, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24304_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24309}), v_st_24306});
    }
    default: return heff_nomatch(v_x11_24305);
    }
  }
  default: return heff_nomatch(v_x1_24304);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam27(V self, V *args) {
  V v_st_24314 = args[0];
  V v_m_24313 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24315 = heff_tr(heff_call(v_m_24313, 1, (V[]){v_st_24314}));
  switch (heff_tag_of(v_x1_24315)) {
  case TAG_MkPair: {
    V v_x11_24316 = heff_field(v_x1_24315, 0);
    V v_st_24317 = heff_field(v_x1_24315, 1);
    V v_ru_24x1_24315_24MkPair = heff_take_reuse_n(v_x1_24315, 3ULL, 2);
    switch (heff_tag_of(v_x11_24316)) {
    case TAG_Left: {
      V v_e_24318 = heff_field(v_x11_24316, 0);
      heff_take_n(v_x11_24316, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24315_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24318}), v_st_24317});
    }
    case TAG_Right: {
      V v_x_24319 = heff_field(v_x11_24316, 0);
      heff_take_n(v_x11_24316, 1ULL, 1);
      V v_x_24320 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24319, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24315_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24320}), v_st_24317});
    }
    default: return heff_nomatch(v_x11_24316);
    }
  }
  default: return heff_nomatch(v_x1_24315);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam28(V self, V *args) {
  V v_st_24328 = args[0];
  V v_m_24327 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24329 = heff_tr(heff_call(v_m_24327, 1, (V[]){v_st_24328}));
  switch (heff_tag_of(v_x1_24329)) {
  case TAG_MkPair: {
    V v_x11_24330 = heff_field(v_x1_24329, 0);
    V v_st_24331 = heff_field(v_x1_24329, 1);
    V v_ru_24x1_24329_24MkPair = heff_take_reuse_n(v_x1_24329, 3ULL, 2);
    switch (heff_tag_of(v_x11_24330)) {
    case TAG_Left: {
      V v_e_24332 = heff_field(v_x11_24330, 0);
      heff_take_n(v_x11_24330, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24329_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24332}), v_st_24331});
    }
    case TAG_Right: {
      V v_x_24333 = heff_field(v_x11_24330, 0);
      heff_take_n(v_x11_24330, 1ULL, 1);
      V v_x_24334 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24333, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24329_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24334}), v_st_24331});
    }
    default: return heff_nomatch(v_x11_24330);
    }
  }
  default: return heff_nomatch(v_x1_24329);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam29(V self, V *args) {
  V v_st_24338 = args[0];
  V v_m_24337 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24339 = heff_tr(heff_call(v_m_24337, 1, (V[]){v_st_24338}));
  switch (heff_tag_of(v_x1_24339)) {
  case TAG_MkPair: {
    V v_x11_24340 = heff_field(v_x1_24339, 0);
    V v_st_24341 = heff_field(v_x1_24339, 1);
    V v_ru_24x1_24339_24MkPair = heff_take_reuse_n(v_x1_24339, 3ULL, 2);
    switch (heff_tag_of(v_x11_24340)) {
    case TAG_Left: {
      V v_e_24342 = heff_field(v_x11_24340, 0);
      heff_take_n(v_x11_24340, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24339_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24342}), v_st_24341});
    }
    case TAG_Right: {
      V v_x_24343 = heff_field(v_x11_24340, 0);
      heff_take_n(v_x11_24340, 1ULL, 1);
      V v_x_24344 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24343, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24339_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24344}), v_st_24341});
    }
    default: return heff_nomatch(v_x11_24340);
    }
  }
  default: return heff_nomatch(v_x1_24339);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam30(V self, V *args) {
  V v_st_24349 = args[0];
  V v_m_24348 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24350 = heff_tr(heff_call(v_m_24348, 1, (V[]){v_st_24349}));
  switch (heff_tag_of(v_x1_24350)) {
  case TAG_MkPair: {
    V v_x11_24351 = heff_field(v_x1_24350, 0);
    V v_st_24352 = heff_field(v_x1_24350, 1);
    V v_ru_24x1_24350_24MkPair = heff_take_reuse_n(v_x1_24350, 3ULL, 2);
    switch (heff_tag_of(v_x11_24351)) {
    case TAG_Left: {
      V v_e_24353 = heff_field(v_x11_24351, 0);
      heff_take_n(v_x11_24351, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24350_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24353}), v_st_24352});
    }
    case TAG_Right: {
      V v_x_24354 = heff_field(v_x11_24351, 0);
      heff_take_n(v_x11_24351, 1ULL, 1);
      V v_x_24355 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24354, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24350_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24355}), v_st_24352});
    }
    default: return heff_nomatch(v_x11_24351);
    }
  }
  default: return heff_nomatch(v_x1_24350);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam31(V self, V *args) {
  V v_st_24363 = args[0];
  V v_m_24362 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24364 = heff_tr(heff_call(v_m_24362, 1, (V[]){v_st_24363}));
  switch (heff_tag_of(v_x1_24364)) {
  case TAG_MkPair: {
    V v_x11_24365 = heff_field(v_x1_24364, 0);
    V v_st_24366 = heff_field(v_x1_24364, 1);
    V v_ru_24x1_24364_24MkPair = heff_take_reuse_n(v_x1_24364, 3ULL, 2);
    switch (heff_tag_of(v_x11_24365)) {
    case TAG_Left: {
      V v_e_24367 = heff_field(v_x11_24365, 0);
      heff_take_n(v_x11_24365, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24364_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24367}), v_st_24366});
    }
    case TAG_Right: {
      V v_x_24368 = heff_field(v_x11_24365, 0);
      heff_take_n(v_x11_24365, 1ULL, 1);
      V v_x_24369 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24368, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24364_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24369}), v_st_24366});
    }
    default: return heff_nomatch(v_x11_24365);
    }
  }
  default: return heff_nomatch(v_x1_24364);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam32(V self, V *args) {
  V v_st_24378 = args[0];
  V v_m_24377 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24379 = heff_tr(heff_call(v_m_24377, 1, (V[]){v_st_24378}));
  switch (heff_tag_of(v_x1_24379)) {
  case TAG_MkPair: {
    V v_x11_24380 = heff_field(v_x1_24379, 0);
    V v_st_24381 = heff_field(v_x1_24379, 1);
    V v_ru_24x1_24379_24MkPair = heff_take_reuse_n(v_x1_24379, 3ULL, 2);
    switch (heff_tag_of(v_x11_24380)) {
    case TAG_Left: {
      V v_e_24382 = heff_field(v_x11_24380, 0);
      heff_take_n(v_x11_24380, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24379_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24382}), v_st_24381});
    }
    case TAG_Right: {
      V v_x_24383 = heff_field(v_x11_24380, 0);
      heff_take_n(v_x11_24380, 1ULL, 1);
      V v_x_24384 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24383, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24379_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24384}), v_st_24381});
    }
    default: return heff_nomatch(v_x11_24380);
    }
  }
  default: return heff_nomatch(v_x1_24379);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam33(V self, V *args) {
  V v_st_24392 = args[0];
  V v_m_24391 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24393 = heff_tr(heff_call(v_m_24391, 1, (V[]){v_st_24392}));
  switch (heff_tag_of(v_x1_24393)) {
  case TAG_MkPair: {
    V v_x11_24394 = heff_field(v_x1_24393, 0);
    V v_st_24395 = heff_field(v_x1_24393, 1);
    V v_ru_24x1_24393_24MkPair = heff_take_reuse_n(v_x1_24393, 3ULL, 2);
    switch (heff_tag_of(v_x11_24394)) {
    case TAG_Left: {
      V v_e_24396 = heff_field(v_x11_24394, 0);
      heff_take_n(v_x11_24394, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24393_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24396}), v_st_24395});
    }
    case TAG_Right: {
      V v_x_24397 = heff_field(v_x11_24394, 0);
      heff_take_n(v_x11_24394, 1ULL, 1);
      V v_x_24398 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24397, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24393_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24398}), v_st_24395});
    }
    default: return heff_nomatch(v_x11_24394);
    }
  }
  default: return heff_nomatch(v_x1_24393);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam34(V self, V *args) {
  V v_st_24403 = args[0];
  V v_m_24402 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24404 = heff_tr(heff_call(v_m_24402, 1, (V[]){v_st_24403}));
  switch (heff_tag_of(v_x1_24404)) {
  case TAG_MkPair: {
    V v_x11_24405 = heff_field(v_x1_24404, 0);
    V v_st_24406 = heff_field(v_x1_24404, 1);
    V v_ru_24x1_24404_24MkPair = heff_take_reuse_n(v_x1_24404, 3ULL, 2);
    switch (heff_tag_of(v_x11_24405)) {
    case TAG_Left: {
      V v_e_24407 = heff_field(v_x11_24405, 0);
      heff_take_n(v_x11_24405, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24404_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24407}), v_st_24406});
    }
    case TAG_Right: {
      V v_x_24408 = heff_field(v_x11_24405, 0);
      heff_take_n(v_x11_24405, 1ULL, 1);
      V v_x_24409 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24408, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24404_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24409}), v_st_24406});
    }
    default: return heff_nomatch(v_x11_24405);
    }
  }
  default: return heff_nomatch(v_x1_24404);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam35(V self, V *args) {
  V v_st_24415 = args[0];
  V v_m_24414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24416 = heff_tr(heff_call(v_m_24414, 1, (V[]){v_st_24415}));
  switch (heff_tag_of(v_x1_24416)) {
  case TAG_MkPair: {
    V v_x11_24417 = heff_field(v_x1_24416, 0);
    V v_st_24418 = heff_field(v_x1_24416, 1);
    V v_ru_24x1_24416_24MkPair = heff_take_reuse_n(v_x1_24416, 3ULL, 2);
    switch (heff_tag_of(v_x11_24417)) {
    case TAG_Left: {
      V v_e_24419 = heff_field(v_x11_24417, 0);
      heff_take_n(v_x11_24417, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24419}), v_st_24418});
    }
    case TAG_Right: {
      V v_x_24420 = heff_field(v_x11_24417, 0);
      heff_take_n(v_x11_24417, 1ULL, 1);
      V v_x_24421 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24420, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24421}), v_st_24418});
    }
    default: return heff_nomatch(v_x11_24417);
    }
  }
  default: return heff_nomatch(v_x1_24416);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam36(V self, V *args) {
  V v_st_24429 = args[0];
  V v_m_24428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24430 = heff_tr(heff_call(v_m_24428, 1, (V[]){v_st_24429}));
  switch (heff_tag_of(v_x1_24430)) {
  case TAG_MkPair: {
    V v_x11_24431 = heff_field(v_x1_24430, 0);
    V v_st_24432 = heff_field(v_x1_24430, 1);
    V v_ru_24x1_24430_24MkPair = heff_take_reuse_n(v_x1_24430, 3ULL, 2);
    switch (heff_tag_of(v_x11_24431)) {
    case TAG_Left: {
      V v_e_24433 = heff_field(v_x11_24431, 0);
      heff_take_n(v_x11_24431, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24433}), v_st_24432});
    }
    case TAG_Right: {
      V v_x_24434 = heff_field(v_x11_24431, 0);
      heff_take_n(v_x11_24431, 1ULL, 1);
      V v_x_24435 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24434, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24435}), v_st_24432});
    }
    default: return heff_nomatch(v_x11_24431);
    }
  }
  default: return heff_nomatch(v_x1_24430);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam37(V self, V *args) {
  V v_st_24438 = args[0];
  V v_m_24437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24439 = heff_tr(heff_call(v_m_24437, 1, (V[]){v_st_24438}));
  switch (heff_tag_of(v_x1_24439)) {
  case TAG_MkPair: {
    V v_x11_24440 = heff_field(v_x1_24439, 0);
    V v_st_24441 = heff_field(v_x1_24439, 1);
    V v_ru_24x1_24439_24MkPair = heff_take_reuse_n(v_x1_24439, 3ULL, 2);
    switch (heff_tag_of(v_x11_24440)) {
    case TAG_Left: {
      V v_e_24442 = heff_field(v_x11_24440, 0);
      heff_take_n(v_x11_24440, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24442}), v_st_24441});
    }
    case TAG_Right: {
      V v_x_24443 = heff_field(v_x11_24440, 0);
      heff_take_n(v_x11_24440, 1ULL, 1);
      V v_x_24444 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24443, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24444}), v_st_24441});
    }
    default: return heff_nomatch(v_x11_24440);
    }
  }
  default: return heff_nomatch(v_x1_24439);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam38(V self, V *args) {
  V v_st_24448 = args[0];
  V v_m_24447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24449 = heff_tr(heff_call(v_m_24447, 1, (V[]){v_st_24448}));
  switch (heff_tag_of(v_x1_24449)) {
  case TAG_MkPair: {
    V v_x11_24450 = heff_field(v_x1_24449, 0);
    V v_st_24451 = heff_field(v_x1_24449, 1);
    V v_ru_24x1_24449_24MkPair = heff_take_reuse_n(v_x1_24449, 3ULL, 2);
    switch (heff_tag_of(v_x11_24450)) {
    case TAG_Left: {
      V v_e_24452 = heff_field(v_x11_24450, 0);
      heff_take_n(v_x11_24450, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24449_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24452}), v_st_24451});
    }
    case TAG_Right: {
      V v_x_24453 = heff_field(v_x11_24450, 0);
      heff_take_n(v_x11_24450, 1ULL, 1);
      V v_x_24454 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24453, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24449_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24454}), v_st_24451});
    }
    default: return heff_nomatch(v_x11_24450);
    }
  }
  default: return heff_nomatch(v_x1_24449);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam39(V self, V *args) {
  V v_st_24460 = args[0];
  V v_m_24459 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24461 = heff_tr(heff_call(v_m_24459, 1, (V[]){v_st_24460}));
  switch (heff_tag_of(v_x1_24461)) {
  case TAG_MkPair: {
    V v_x11_24462 = heff_field(v_x1_24461, 0);
    V v_st_24463 = heff_field(v_x1_24461, 1);
    V v_ru_24x1_24461_24MkPair = heff_take_reuse_n(v_x1_24461, 3ULL, 2);
    switch (heff_tag_of(v_x11_24462)) {
    case TAG_Left: {
      V v_e_24464 = heff_field(v_x11_24462, 0);
      heff_take_n(v_x11_24462, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24464}), v_st_24463});
    }
    case TAG_Right: {
      V v_x_24465 = heff_field(v_x11_24462, 0);
      heff_take_n(v_x11_24462, 1ULL, 1);
      V v_x_24466 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24465, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24466}), v_st_24463});
    }
    default: return heff_nomatch(v_x11_24462);
    }
  }
  default: return heff_nomatch(v_x1_24461);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam40(V self, V *args) {
  V v_st_24470 = args[0];
  V v_m_24469 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24471 = heff_tr(heff_call(v_m_24469, 1, (V[]){v_st_24470}));
  switch (heff_tag_of(v_x1_24471)) {
  case TAG_MkPair: {
    V v_x11_24472 = heff_field(v_x1_24471, 0);
    V v_st_24473 = heff_field(v_x1_24471, 1);
    V v_ru_24x1_24471_24MkPair = heff_take_reuse_n(v_x1_24471, 3ULL, 2);
    switch (heff_tag_of(v_x11_24472)) {
    case TAG_Left: {
      V v_e_24474 = heff_field(v_x11_24472, 0);
      heff_take_n(v_x11_24472, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24474}), v_st_24473});
    }
    case TAG_Right: {
      V v_x_24475 = heff_field(v_x11_24472, 0);
      heff_take_n(v_x11_24472, 1ULL, 1);
      V v_x_24476 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24475, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24476}), v_st_24473});
    }
    default: return heff_nomatch(v_x11_24472);
    }
  }
  default: return heff_nomatch(v_x1_24471);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam41(V self, V *args) {
  V v_st_24482 = args[0];
  V v_m_24481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24483 = heff_tr(heff_call(v_m_24481, 1, (V[]){v_st_24482}));
  switch (heff_tag_of(v_x1_24483)) {
  case TAG_MkPair: {
    V v_x11_24484 = heff_field(v_x1_24483, 0);
    V v_st_24485 = heff_field(v_x1_24483, 1);
    V v_ru_24x1_24483_24MkPair = heff_take_reuse_n(v_x1_24483, 3ULL, 2);
    switch (heff_tag_of(v_x11_24484)) {
    case TAG_Left: {
      V v_e_24486 = heff_field(v_x11_24484, 0);
      heff_take_n(v_x11_24484, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24483_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24486}), v_st_24485});
    }
    case TAG_Right: {
      V v_x_24487 = heff_field(v_x11_24484, 0);
      heff_take_n(v_x11_24484, 1ULL, 1);
      V v_x_24488 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24487, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24483_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24488}), v_st_24485});
    }
    default: return heff_nomatch(v_x11_24484);
    }
  }
  default: return heff_nomatch(v_x1_24483);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam42(V self, V *args) {
  V v_st_24494 = args[0];
  V v_m_24493 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24495 = heff_tr(heff_call(v_m_24493, 1, (V[]){v_st_24494}));
  switch (heff_tag_of(v_x1_24495)) {
  case TAG_MkPair: {
    V v_x11_24496 = heff_field(v_x1_24495, 0);
    V v_st_24497 = heff_field(v_x1_24495, 1);
    V v_ru_24x1_24495_24MkPair = heff_take_reuse_n(v_x1_24495, 3ULL, 2);
    switch (heff_tag_of(v_x11_24496)) {
    case TAG_Left: {
      V v_e_24498 = heff_field(v_x11_24496, 0);
      heff_take_n(v_x11_24496, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24498}), v_st_24497});
    }
    case TAG_Right: {
      V v_x_24499 = heff_field(v_x11_24496, 0);
      heff_take_n(v_x11_24496, 1ULL, 1);
      V v_x_24500 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24499, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24500}), v_st_24497});
    }
    default: return heff_nomatch(v_x11_24496);
    }
  }
  default: return heff_nomatch(v_x1_24495);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam43(V self, V *args) {
  V v_st_24506 = args[0];
  V v_m_24505 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24507 = heff_tr(heff_call(v_m_24505, 1, (V[]){v_st_24506}));
  switch (heff_tag_of(v_x1_24507)) {
  case TAG_MkPair: {
    V v_x11_24508 = heff_field(v_x1_24507, 0);
    V v_st_24509 = heff_field(v_x1_24507, 1);
    V v_ru_24x1_24507_24MkPair = heff_take_reuse_n(v_x1_24507, 3ULL, 2);
    switch (heff_tag_of(v_x11_24508)) {
    case TAG_Left: {
      V v_e_24510 = heff_field(v_x11_24508, 0);
      heff_take_n(v_x11_24508, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24507_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24510}), v_st_24509});
    }
    case TAG_Right: {
      V v_x_24511 = heff_field(v_x11_24508, 0);
      heff_take_n(v_x11_24508, 1ULL, 1);
      V v_x_24512 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24511, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24507_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24512}), v_st_24509});
    }
    default: return heff_nomatch(v_x11_24508);
    }
  }
  default: return heff_nomatch(v_x1_24507);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam44(V self, V *args) {
  V v_st_24520 = args[0];
  V v_m_24519 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24521 = heff_tr(heff_call(v_m_24519, 1, (V[]){v_st_24520}));
  switch (heff_tag_of(v_x1_24521)) {
  case TAG_MkPair: {
    V v_x11_24522 = heff_field(v_x1_24521, 0);
    V v_st_24523 = heff_field(v_x1_24521, 1);
    V v_ru_24x1_24521_24MkPair = heff_take_reuse_n(v_x1_24521, 3ULL, 2);
    switch (heff_tag_of(v_x11_24522)) {
    case TAG_Left: {
      V v_e_24524 = heff_field(v_x11_24522, 0);
      heff_take_n(v_x11_24522, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24521_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24524}), v_st_24523});
    }
    case TAG_Right: {
      V v_x_24525 = heff_field(v_x11_24522, 0);
      heff_take_n(v_x11_24522, 1ULL, 1);
      V v_x_24526 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24525, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24521_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24526}), v_st_24523});
    }
    default: return heff_nomatch(v_x11_24522);
    }
  }
  default: return heff_nomatch(v_x1_24521);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str1, 33, "` is named twice in one signature");
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str3, 33, "` is named twice in one signature");

HeffT2 g_heff_2esyntax_2esurface_2erepeatedField_24cpr(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Left: {
      V v_x_244 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_text_245 = heff_take_field(v_x_244, 1);
      V v_start_246 = heff_take_field(v_x_244, 3);
      V v_end_247 = heff_get_n(v_x_244, 4, 9);
      V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_text_245)}));
      V v_t_249 = (g_list_2eany(v_t_248, v_seen_240));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_seen_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_249);
        V v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str0), heff_strAppend(v_text_245, ((V)&g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str1)));
        V v_f_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2410, heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247}), NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
      } else {
        heff_drop(v_start_246);
        heff_drop(v_end_247);
        heff_drop(v_t_249);
        V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_text_245, v_seen_240});
        V t_1 = v_rest_243;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_Right: {
      V v_x211_2412 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      switch (heff_tag_of(v_x211_2412)) {
      case TAG_At: {
        V v_x2111_2413 = heff_field(v_x211_2412, 0);
        heff_take_n(v_x211_2412, 1ULL, 2);
        switch (heff_tag_of(v_x2111_2413)) {
        case TAG_DeclareField: {
          V v_f_2415 = heff_field(v_x2111_2413, 0);
          V v_fsp_2416 = heff_field(v_x2111_2413, 1);
          heff_take_n(v_x2111_2413, 3ULL, 4);
          V v_t_2419 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_f_2415)}));
          V v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = v_seen_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_seen_240); r_; });
          if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
            heff_drop(v_rest_243);
            heff_drop(v_t_2420);
            V v_t_2421 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str2), heff_strAppend(v_f_2415, ((V)&g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str3)));
            V v_f_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2421, v_fsp_2416, NTAG(TAG_Nothing)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2422}});
          } else {
            heff_drop(v_f_2415);
            heff_drop(v_fsp_2416);
            heff_drop(v_t_2420);
            V t_0 = NTAG(TAG_Nil);
            V t_1 = v_rest_243;
            v_seen_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        }
        case TAG_BadFieldDecl: {
          heff_take_n(v_x2111_2413, 0ULL, 1);
          heff_drop(v_seen_240);
          V t_0 = NTAG(TAG_Nil);
          V t_1 = v_rest_243;
          v_seen_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_x2111_2413)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x211_2412)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str1, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str3, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str5, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str7, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str9, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str11, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str13, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str18, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str19, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str20, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str21, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str23, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str25, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str27, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str28, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str29, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str30, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str31, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str33, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str35, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str37, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str39, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str40, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str41, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str42, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str43, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str44, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str45, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str46, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str47, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str48, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str49, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str50, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str51, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str52, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str53, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str54, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str55, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str56, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str57, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str58, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str59, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str60, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str61, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str62, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str63, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str64, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str65, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str66, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str67, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str68, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str69, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str70, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str71, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str72, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str73, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str74, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str75, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str76, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str77, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str78, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str79, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str80, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str81, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str82, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str83, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str84, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str85, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str86, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str87, 12, "unexpected `");
V g_heff_2esyntax_2esurface_2ealtL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam43(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam44(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam45(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ealtL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ealtL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ealtL(V v_r_240, V v_x2_241) {
top: ;
  V v_pat_242 = heff_take_field(v_r_240, 1);
  V v_e_243 = heff_get_n(v_r_240, 0, 3);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Atom: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_245 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_246 = heff_take_field(v_t_245, 3);
    V v_end_247 = heff_get_n(v_t_245, 4, 9);
    V v_t_248 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 1); r_; });
    V v_t_249 = heff_strAppend(heff_get_n(v_t_248, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str0));
    V v_msg_2410 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str1), v_t_249);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam0, 1, 3, (V[]){v_msg_2410, v_start_246, v_end_247});
  }
  case TAG_EParen: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_2416 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2417 = heff_take_field(v_t_2416, 3);
    V v_end_2418 = heff_get_n(v_t_2416, 4, 9);
    V v_t_2419 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_2420 = heff_strAppend(heff_get_n(v_t_2419, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str2));
    V v_msg_2421 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str3), v_t_2420);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam1, 1, 3, (V[]){v_msg_2421, v_start_2417, v_end_2418});
  }
  case TAG_Named: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_2429 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2430 = heff_take_field(v_t_2429, 3);
    V v_end_2431 = heff_get_n(v_t_2429, 4, 9);
    V v_t_2432 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 5); r_; });
    V v_t_2433 = heff_strAppend(heff_get_n(v_t_2432, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str4));
    V v_msg_2434 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str5), v_t_2433);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam2, 1, 3, (V[]){v_msg_2434, v_start_2430, v_end_2431});
  }
  case TAG_Tup: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_2441 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2442 = heff_take_field(v_t_2441, 3);
    V v_end_2443 = heff_get_n(v_t_2441, 4, 9);
    V v_t_2444 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_2445 = heff_strAppend(heff_get_n(v_t_2444, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str6));
    V v_msg_2446 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str7), v_t_2445);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam3, 1, 3, (V[]){v_msg_2446, v_start_2442, v_end_2443});
  }
  case TAG_Seg: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_2452 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2453 = heff_take_field(v_t_2452, 3);
    V v_end_2454 = heff_get_n(v_t_2452, 4, 9);
    V v_t_2455 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_2456 = heff_strAppend(heff_get_n(v_t_2455, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str8));
    V v_msg_2457 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str9), v_t_2456);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam4, 1, 3, (V[]){v_msg_2457, v_start_2453, v_end_2454});
  }
  case TAG_Braces: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_2464 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2465 = heff_take_field(v_t_2464, 3);
    V v_end_2466 = heff_get_n(v_t_2464, 4, 9);
    V v_t_2467 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_2468 = heff_strAppend(heff_get_n(v_t_2467, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str10));
    V v_msg_2469 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str11), v_t_2468);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam5, 1, 3, (V[]){v_msg_2469, v_start_2465, v_end_2466});
  }
  case TAG_Update: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_2478 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2479 = heff_take_field(v_t_2478, 3);
    V v_end_2480 = heff_get_n(v_t_2478, 4, 9);
    V v_t_2481 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_2482 = heff_strAppend(heff_get_n(v_t_2481, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str12));
    V v_msg_2483 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str13), v_t_2482);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam6, 1, 3, (V[]){v_msg_2483, v_start_2479, v_end_2480});
  }
  case TAG_EUSet: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_2489 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2490 = heff_take_field(v_t_2489, 3);
    V v_end_2491 = heff_get_n(v_t_2489, 4, 9);
    V v_t_2492 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_2493 = heff_strAppend(heff_get_n(v_t_2492, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str14));
    V v_msg_2494 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str15), v_t_2493);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam7, 1, 3, (V[]){v_msg_2494, v_start_2490, v_end_2491});
  }
  case TAG_InstB: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24102 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24103 = heff_take_field(v_t_24102, 3);
    V v_end_24104 = heff_get_n(v_t_24102, 4, 9);
    V v_t_24105 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 5); r_; });
    V v_t_24106 = heff_strAppend(heff_get_n(v_t_24105, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str16));
    V v_msg_24107 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str17), v_t_24106);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam8, 1, 3, (V[]){v_msg_24107, v_start_24103, v_end_24104});
  }
  case TAG_EFSet: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24113 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24114 = heff_take_field(v_t_24113, 3);
    V v_end_24115 = heff_get_n(v_t_24113, 4, 9);
    V v_t_24116 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24117 = heff_strAppend(heff_get_n(v_t_24116, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str18));
    V v_msg_24118 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str19), v_t_24117);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam9, 1, 3, (V[]){v_msg_24118, v_start_24114, v_end_24115});
  }
  case TAG_EFDefault: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24124 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24125 = heff_take_field(v_t_24124, 3);
    V v_end_24126 = heff_get_n(v_t_24124, 4, 9);
    V v_t_24127 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24128 = heff_strAppend(heff_get_n(v_t_24127, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str20));
    V v_msg_24129 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str21), v_t_24128);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam10, 1, 3, (V[]){v_msg_24129, v_start_24125, v_end_24126});
  }
  case TAG_Sum: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24137 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24138 = heff_take_field(v_t_24137, 3);
    V v_end_24139 = heff_get_n(v_t_24137, 4, 9);
    V v_t_24140 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 5); r_; });
    V v_t_24141 = heff_strAppend(heff_get_n(v_t_24140, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str22));
    V v_msg_24142 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str23), v_t_24141);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam11, 1, 3, (V[]){v_msg_24142, v_start_24138, v_end_24139});
  }
  case TAG_ECon: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24147 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24148 = heff_take_field(v_t_24147, 3);
    V v_end_24149 = heff_get_n(v_t_24147, 4, 9);
    V v_t_24150 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24151 = heff_strAppend(heff_get_n(v_t_24150, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str24));
    V v_msg_24152 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str25), v_t_24151);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam12, 1, 3, (V[]){v_msg_24152, v_start_24148, v_end_24149});
  }
  case TAG_EField: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24157 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24158 = heff_take_field(v_t_24157, 3);
    V v_end_24159 = heff_get_n(v_t_24157, 4, 9);
    V v_t_24160 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24161 = heff_strAppend(heff_get_n(v_t_24160, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str26));
    V v_msg_24162 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str27), v_t_24161);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam13, 1, 3, (V[]){v_msg_24162, v_start_24158, v_end_24159});
  }
  case TAG_ENeg: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24167 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24168 = heff_take_field(v_t_24167, 3);
    V v_end_24169 = heff_get_n(v_t_24167, 4, 9);
    V v_t_24170 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24171 = heff_strAppend(heff_get_n(v_t_24170, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str28));
    V v_msg_24172 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str29), v_t_24171);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam14, 1, 3, (V[]){v_msg_24172, v_start_24168, v_end_24169});
  }
  case TAG_ETilde: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24177 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24178 = heff_take_field(v_t_24177, 3);
    V v_end_24179 = heff_get_n(v_t_24177, 4, 9);
    V v_t_24180 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24181 = heff_strAppend(heff_get_n(v_t_24180, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str30));
    V v_msg_24182 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str31), v_t_24181);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam15, 1, 3, (V[]){v_msg_24182, v_start_24178, v_end_24179});
  }
  case TAG_App: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24187 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24188 = heff_take_field(v_t_24187, 3);
    V v_end_24189 = heff_get_n(v_t_24187, 4, 9);
    V v_t_24190 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24191 = heff_strAppend(heff_get_n(v_t_24190, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str32));
    V v_msg_24192 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str33), v_t_24191);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam16, 1, 3, (V[]){v_msg_24192, v_start_24188, v_end_24189});
  }
  case TAG_Op: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24198 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24199 = heff_take_field(v_t_24198, 3);
    V v_end_24200 = heff_get_n(v_t_24198, 4, 9);
    V v_t_24201 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24202 = heff_strAppend(heff_get_n(v_t_24201, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str34));
    V v_msg_24203 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str35), v_t_24202);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam17, 1, 3, (V[]){v_msg_24203, v_start_24199, v_end_24200});
  }
  case TAG_Ops: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24208 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24209 = heff_take_field(v_t_24208, 3);
    V v_end_24210 = heff_get_n(v_t_24208, 4, 9);
    V v_t_24211 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24212 = heff_strAppend(heff_get_n(v_t_24211, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str36));
    V v_msg_24213 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str37), v_t_24212);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam18, 1, 3, (V[]){v_msg_24213, v_start_24209, v_end_24210});
  }
  case TAG_OpRhs: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24218 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24219 = heff_take_field(v_t_24218, 3);
    V v_end_24220 = heff_get_n(v_t_24218, 4, 9);
    V v_t_24221 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24222 = heff_strAppend(heff_get_n(v_t_24221, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str38));
    V v_msg_24223 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str39), v_t_24222);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam19, 1, 3, (V[]){v_msg_24223, v_start_24219, v_end_24220});
  }
  case TAG_Ann: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24229 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24230 = heff_take_field(v_t_24229, 3);
    V v_end_24231 = heff_get_n(v_t_24229, 4, 9);
    V v_t_24232 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24233 = heff_strAppend(heff_get_n(v_t_24232, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str40));
    V v_msg_24234 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str41), v_t_24233);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam20, 1, 3, (V[]){v_msg_24234, v_start_24230, v_end_24231});
  }
  case TAG_BVar: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24238 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24239 = heff_take_field(v_t_24238, 3);
    V v_end_24240 = heff_get_n(v_t_24238, 4, 9);
    V v_t_24241 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 1); r_; });
    V v_t_24242 = heff_strAppend(heff_get_n(v_t_24241, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str42));
    V v_msg_24243 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str43), v_t_24242);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam21, 1, 3, (V[]){v_msg_24243, v_start_24239, v_end_24240});
  }
  case TAG_BImp: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24249 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24250 = heff_take_field(v_t_24249, 3);
    V v_end_24251 = heff_get_n(v_t_24249, 4, 9);
    V v_t_24252 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24253 = heff_strAppend(heff_get_n(v_t_24252, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str44));
    V v_msg_24254 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str45), v_t_24253);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam22, 1, 3, (V[]){v_msg_24254, v_start_24250, v_end_24251});
  }
  case TAG_BAnn: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24262 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24263 = heff_take_field(v_t_24262, 3);
    V v_end_24264 = heff_get_n(v_t_24262, 4, 9);
    V v_t_24265 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 5); r_; });
    V v_t_24266 = heff_strAppend(heff_get_n(v_t_24265, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str46));
    V v_msg_24267 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str47), v_t_24266);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam23, 1, 3, (V[]){v_msg_24267, v_start_24263, v_end_24264});
  }
  case TAG_BPat: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24271 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24272 = heff_take_field(v_t_24271, 3);
    V v_end_24273 = heff_get_n(v_t_24271, 4, 9);
    V v_t_24274 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 1); r_; });
    V v_t_24275 = heff_strAppend(heff_get_n(v_t_24274, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str48));
    V v_msg_24276 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str49), v_t_24275);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam24, 1, 3, (V[]){v_msg_24276, v_start_24272, v_end_24273});
  }
  case TAG_Lam: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24283 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24284 = heff_take_field(v_t_24283, 3);
    V v_end_24285 = heff_get_n(v_t_24283, 4, 9);
    V v_t_24286 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24287 = heff_strAppend(heff_get_n(v_t_24286, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str50));
    V v_msg_24288 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str51), v_t_24287);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam25, 1, 3, (V[]){v_msg_24288, v_start_24284, v_end_24285});
  }
  case TAG_Case: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24295 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24296 = heff_take_field(v_t_24295, 3);
    V v_end_24297 = heff_get_n(v_t_24295, 4, 9);
    V v_t_24298 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24299 = heff_strAppend(heff_get_n(v_t_24298, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str52));
    V v_msg_24300 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str53), v_t_24299);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam26, 1, 3, (V[]){v_msg_24300, v_start_24296, v_end_24297});
  }
  case TAG_EAlt: {
    V v_p_24303 = heff_field(v_x2_241, 0);
    V v_e_24305 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    V v_m_24306 = heff_tr(heff_call(v_pat_242, 1, (V[]){heff_dup(v_p_24303)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam27, 1, 4, (V[]){v_m_24306, v_p_24303, v_e_243, v_e_24305});
  }
  case TAG_If: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24335 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24336 = heff_take_field(v_t_24335, 3);
    V v_end_24337 = heff_get_n(v_t_24335, 4, 9);
    V v_t_24338 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_24339 = heff_strAppend(heff_get_n(v_t_24338, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str54));
    V v_msg_24340 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str55), v_t_24339);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam29, 1, 3, (V[]){v_msg_24340, v_start_24336, v_end_24337});
  }
  case TAG_Do: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24345 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24346 = heff_take_field(v_t_24345, 3);
    V v_end_24347 = heff_get_n(v_t_24345, 4, 9);
    V v_t_24348 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24349 = heff_strAppend(heff_get_n(v_t_24348, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str56));
    V v_msg_24350 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str57), v_t_24349);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam30, 1, 3, (V[]){v_msg_24350, v_start_24346, v_end_24347});
  }
  case TAG_ESBind: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24356 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24357 = heff_take_field(v_t_24356, 3);
    V v_end_24358 = heff_get_n(v_t_24356, 4, 9);
    V v_t_24359 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24360 = heff_strAppend(heff_get_n(v_t_24359, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str58));
    V v_msg_24361 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str59), v_t_24360);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam31, 1, 3, (V[]){v_msg_24361, v_start_24357, v_end_24358});
  }
  case TAG_ELet: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24370 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24371 = heff_take_field(v_t_24370, 3);
    V v_end_24372 = heff_get_n(v_t_24370, 4, 9);
    V v_t_24373 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_24374 = heff_strAppend(heff_get_n(v_t_24373, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str60));
    V v_msg_24375 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str61), v_t_24374);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam32, 1, 3, (V[]){v_msg_24375, v_start_24371, v_end_24372});
  }
  case TAG_ELetElse: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24385 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24386 = heff_take_field(v_t_24385, 3);
    V v_end_24387 = heff_get_n(v_t_24385, 4, 9);
    V v_t_24388 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 7); r_; });
    V v_t_24389 = heff_strAppend(heff_get_n(v_t_24388, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str62));
    V v_msg_24390 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str63), v_t_24389);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam33, 1, 3, (V[]){v_msg_24390, v_start_24386, v_end_24387});
  }
  case TAG_ELetMut: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24399 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24400 = heff_take_field(v_t_24399, 3);
    V v_end_24401 = heff_get_n(v_t_24399, 4, 9);
    V v_t_24402 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_24403 = heff_strAppend(heff_get_n(v_t_24402, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str64));
    V v_msg_24404 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str65), v_t_24403);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam34, 1, 3, (V[]){v_msg_24404, v_start_24400, v_end_24401});
  }
  case TAG_EAssign: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24410 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24411 = heff_take_field(v_t_24410, 3);
    V v_end_24412 = heff_get_n(v_t_24410, 4, 9);
    V v_t_24413 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24414 = heff_strAppend(heff_get_n(v_t_24413, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str66));
    V v_msg_24415 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str67), v_t_24414);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam35, 1, 3, (V[]){v_msg_24415, v_start_24411, v_end_24412});
  }
  case TAG_EWhile: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24422 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24423 = heff_take_field(v_t_24422, 3);
    V v_end_24424 = heff_get_n(v_t_24422, 4, 9);
    V v_t_24425 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24426 = heff_strAppend(heff_get_n(v_t_24425, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str68));
    V v_msg_24427 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str69), v_t_24426);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam36, 1, 3, (V[]){v_msg_24427, v_start_24423, v_end_24424});
  }
  case TAG_EFor: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24436 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24437 = heff_take_field(v_t_24436, 3);
    V v_end_24438 = heff_get_n(v_t_24436, 4, 9);
    V v_t_24439 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_24440 = heff_strAppend(heff_get_n(v_t_24439, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str70));
    V v_msg_24441 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str71), v_t_24440);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam37, 1, 3, (V[]){v_msg_24441, v_start_24437, v_end_24438});
  }
  case TAG_EJump: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24445 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24446 = heff_take_field(v_t_24445, 3);
    V v_end_24447 = heff_get_n(v_t_24445, 4, 9);
    V v_t_24448 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 1); r_; });
    V v_t_24449 = heff_strAppend(heff_get_n(v_t_24448, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str72));
    V v_msg_24450 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str73), v_t_24449);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam38, 1, 3, (V[]){v_msg_24450, v_start_24446, v_end_24447});
  }
  case TAG_EReturn: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24455 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24456 = heff_take_field(v_t_24455, 3);
    V v_end_24457 = heff_get_n(v_t_24455, 4, 9);
    V v_t_24458 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24459 = heff_strAppend(heff_get_n(v_t_24458, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str74));
    V v_msg_24460 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str75), v_t_24459);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam39, 1, 3, (V[]){v_msg_24460, v_start_24456, v_end_24457});
  }
  case TAG_ENest: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24467 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24468 = heff_take_field(v_t_24467, 3);
    V v_end_24469 = heff_get_n(v_t_24467, 4, 9);
    V v_t_24470 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24471 = heff_strAppend(heff_get_n(v_t_24470, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str76));
    V v_msg_24472 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str77), v_t_24471);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam40, 1, 3, (V[]){v_msg_24472, v_start_24468, v_end_24469});
  }
  case TAG_EArrow: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24477 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24478 = heff_take_field(v_t_24477, 3);
    V v_end_24479 = heff_get_n(v_t_24477, 4, 9);
    V v_t_24480 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24481 = heff_strAppend(heff_get_n(v_t_24480, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str78));
    V v_msg_24482 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str79), v_t_24481);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam41, 1, 3, (V[]){v_msg_24482, v_start_24478, v_end_24479});
  }
  case TAG_IfThen: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24489 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24490 = heff_take_field(v_t_24489, 3);
    V v_end_24491 = heff_get_n(v_t_24489, 4, 9);
    V v_t_24492 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24493 = heff_strAppend(heff_get_n(v_t_24492, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str80));
    V v_msg_24494 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str81), v_t_24493);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam42, 1, 3, (V[]){v_msg_24494, v_start_24490, v_end_24491});
  }
  case TAG_ETry: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24501 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24502 = heff_take_field(v_t_24501, 3);
    V v_end_24503 = heff_get_n(v_t_24501, 4, 9);
    V v_t_24504 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24505 = heff_strAppend(heff_get_n(v_t_24504, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str82));
    V v_msg_24506 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str83), v_t_24505);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam43, 1, 3, (V[]){v_msg_24506, v_start_24502, v_end_24503});
  }
  case TAG_ECatch: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24513 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24514 = heff_take_field(v_t_24513, 3);
    V v_end_24515 = heff_get_n(v_t_24513, 4, 9);
    V v_t_24516 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24517 = heff_strAppend(heff_get_n(v_t_24516, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str84));
    V v_msg_24518 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str85), v_t_24517);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam44, 1, 3, (V[]){v_msg_24518, v_start_24514, v_end_24515});
  }
  case TAG_EWith: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_24527 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_24528 = heff_take_field(v_t_24527, 3);
    V v_end_24529 = heff_get_n(v_t_24527, 4, 9);
    V v_t_24530 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_24531 = heff_strAppend(heff_get_n(v_t_24530, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str86));
    V v_msg_24532 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str87), v_t_24531);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam45, 1, 3, (V[]){v_msg_24532, v_start_24528, v_end_24529});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ealtL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2ealtL_lam0(V self, V *args) {
  V v_st_2411 = args[0];
  V v_msg_2410 = heff_env(self)[0];
  V v_start_246 = heff_env(self)[1];
  V v_end_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2410, heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2412}), v_st_2411});
}
V g_heff_2esyntax_2esurface_2ealtL_lam1(V self, V *args) {
  V v_st_2422 = args[0];
  V v_msg_2421 = heff_env(self)[0];
  V v_start_2417 = heff_env(self)[1];
  V v_end_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2421, heff_rec_n(2, shape_start__end, (V[]){v_start_2417, v_end_2418}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2423}), v_st_2422});
}
V g_heff_2esyntax_2esurface_2ealtL_lam2(V self, V *args) {
  V v_st_2435 = args[0];
  V v_msg_2434 = heff_env(self)[0];
  V v_start_2430 = heff_env(self)[1];
  V v_end_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2436 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2434, heff_rec_n(2, shape_start__end, (V[]){v_start_2430, v_end_2431}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2436}), v_st_2435});
}
V g_heff_2esyntax_2esurface_2ealtL_lam3(V self, V *args) {
  V v_st_2447 = args[0];
  V v_msg_2446 = heff_env(self)[0];
  V v_start_2442 = heff_env(self)[1];
  V v_end_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2446, heff_rec_n(2, shape_start__end, (V[]){v_start_2442, v_end_2443}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2448}), v_st_2447});
}
V g_heff_2esyntax_2esurface_2ealtL_lam4(V self, V *args) {
  V v_st_2458 = args[0];
  V v_msg_2457 = heff_env(self)[0];
  V v_start_2453 = heff_env(self)[1];
  V v_end_2454 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2457, heff_rec_n(2, shape_start__end, (V[]){v_start_2453, v_end_2454}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2459}), v_st_2458});
}
V g_heff_2esyntax_2esurface_2ealtL_lam5(V self, V *args) {
  V v_st_2470 = args[0];
  V v_msg_2469 = heff_env(self)[0];
  V v_start_2465 = heff_env(self)[1];
  V v_end_2466 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2471 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2469, heff_rec_n(2, shape_start__end, (V[]){v_start_2465, v_end_2466}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2471}), v_st_2470});
}
V g_heff_2esyntax_2esurface_2ealtL_lam6(V self, V *args) {
  V v_st_2484 = args[0];
  V v_msg_2483 = heff_env(self)[0];
  V v_start_2479 = heff_env(self)[1];
  V v_end_2480 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2485 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2483, heff_rec_n(2, shape_start__end, (V[]){v_start_2479, v_end_2480}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2485}), v_st_2484});
}
V g_heff_2esyntax_2esurface_2ealtL_lam7(V self, V *args) {
  V v_st_2495 = args[0];
  V v_msg_2494 = heff_env(self)[0];
  V v_start_2490 = heff_env(self)[1];
  V v_end_2491 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2496 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2494, heff_rec_n(2, shape_start__end, (V[]){v_start_2490, v_end_2491}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2496}), v_st_2495});
}
V g_heff_2esyntax_2esurface_2ealtL_lam8(V self, V *args) {
  V v_st_24108 = args[0];
  V v_msg_24107 = heff_env(self)[0];
  V v_start_24103 = heff_env(self)[1];
  V v_end_24104 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24109 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24107, heff_rec_n(2, shape_start__end, (V[]){v_start_24103, v_end_24104}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24109}), v_st_24108});
}
V g_heff_2esyntax_2esurface_2ealtL_lam9(V self, V *args) {
  V v_st_24119 = args[0];
  V v_msg_24118 = heff_env(self)[0];
  V v_start_24114 = heff_env(self)[1];
  V v_end_24115 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24120 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24118, heff_rec_n(2, shape_start__end, (V[]){v_start_24114, v_end_24115}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24120}), v_st_24119});
}
V g_heff_2esyntax_2esurface_2ealtL_lam10(V self, V *args) {
  V v_st_24130 = args[0];
  V v_msg_24129 = heff_env(self)[0];
  V v_start_24125 = heff_env(self)[1];
  V v_end_24126 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24131 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24129, heff_rec_n(2, shape_start__end, (V[]){v_start_24125, v_end_24126}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24131}), v_st_24130});
}
V g_heff_2esyntax_2esurface_2ealtL_lam11(V self, V *args) {
  V v_st_24143 = args[0];
  V v_msg_24142 = heff_env(self)[0];
  V v_start_24138 = heff_env(self)[1];
  V v_end_24139 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24144 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24142, heff_rec_n(2, shape_start__end, (V[]){v_start_24138, v_end_24139}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24144}), v_st_24143});
}
V g_heff_2esyntax_2esurface_2ealtL_lam12(V self, V *args) {
  V v_st_24153 = args[0];
  V v_msg_24152 = heff_env(self)[0];
  V v_start_24148 = heff_env(self)[1];
  V v_end_24149 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24154 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24152, heff_rec_n(2, shape_start__end, (V[]){v_start_24148, v_end_24149}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24154}), v_st_24153});
}
V g_heff_2esyntax_2esurface_2ealtL_lam13(V self, V *args) {
  V v_st_24163 = args[0];
  V v_msg_24162 = heff_env(self)[0];
  V v_start_24158 = heff_env(self)[1];
  V v_end_24159 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24164 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24162, heff_rec_n(2, shape_start__end, (V[]){v_start_24158, v_end_24159}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24164}), v_st_24163});
}
V g_heff_2esyntax_2esurface_2ealtL_lam14(V self, V *args) {
  V v_st_24173 = args[0];
  V v_msg_24172 = heff_env(self)[0];
  V v_start_24168 = heff_env(self)[1];
  V v_end_24169 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24174 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24172, heff_rec_n(2, shape_start__end, (V[]){v_start_24168, v_end_24169}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24174}), v_st_24173});
}
V g_heff_2esyntax_2esurface_2ealtL_lam15(V self, V *args) {
  V v_st_24183 = args[0];
  V v_msg_24182 = heff_env(self)[0];
  V v_start_24178 = heff_env(self)[1];
  V v_end_24179 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24184 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24182, heff_rec_n(2, shape_start__end, (V[]){v_start_24178, v_end_24179}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24184}), v_st_24183});
}
V g_heff_2esyntax_2esurface_2ealtL_lam16(V self, V *args) {
  V v_st_24193 = args[0];
  V v_msg_24192 = heff_env(self)[0];
  V v_start_24188 = heff_env(self)[1];
  V v_end_24189 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24194 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24192, heff_rec_n(2, shape_start__end, (V[]){v_start_24188, v_end_24189}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24194}), v_st_24193});
}
V g_heff_2esyntax_2esurface_2ealtL_lam17(V self, V *args) {
  V v_st_24204 = args[0];
  V v_msg_24203 = heff_env(self)[0];
  V v_start_24199 = heff_env(self)[1];
  V v_end_24200 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24205 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24203, heff_rec_n(2, shape_start__end, (V[]){v_start_24199, v_end_24200}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24205}), v_st_24204});
}
V g_heff_2esyntax_2esurface_2ealtL_lam18(V self, V *args) {
  V v_st_24214 = args[0];
  V v_msg_24213 = heff_env(self)[0];
  V v_start_24209 = heff_env(self)[1];
  V v_end_24210 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24215 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24213, heff_rec_n(2, shape_start__end, (V[]){v_start_24209, v_end_24210}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24215}), v_st_24214});
}
V g_heff_2esyntax_2esurface_2ealtL_lam19(V self, V *args) {
  V v_st_24224 = args[0];
  V v_msg_24223 = heff_env(self)[0];
  V v_start_24219 = heff_env(self)[1];
  V v_end_24220 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24225 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24223, heff_rec_n(2, shape_start__end, (V[]){v_start_24219, v_end_24220}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24225}), v_st_24224});
}
V g_heff_2esyntax_2esurface_2ealtL_lam20(V self, V *args) {
  V v_st_24235 = args[0];
  V v_msg_24234 = heff_env(self)[0];
  V v_start_24230 = heff_env(self)[1];
  V v_end_24231 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24236 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24234, heff_rec_n(2, shape_start__end, (V[]){v_start_24230, v_end_24231}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24236}), v_st_24235});
}
V g_heff_2esyntax_2esurface_2ealtL_lam21(V self, V *args) {
  V v_st_24244 = args[0];
  V v_msg_24243 = heff_env(self)[0];
  V v_start_24239 = heff_env(self)[1];
  V v_end_24240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24243, heff_rec_n(2, shape_start__end, (V[]){v_start_24239, v_end_24240}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24245}), v_st_24244});
}
V g_heff_2esyntax_2esurface_2ealtL_lam22(V self, V *args) {
  V v_st_24255 = args[0];
  V v_msg_24254 = heff_env(self)[0];
  V v_start_24250 = heff_env(self)[1];
  V v_end_24251 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24256 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24254, heff_rec_n(2, shape_start__end, (V[]){v_start_24250, v_end_24251}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24256}), v_st_24255});
}
V g_heff_2esyntax_2esurface_2ealtL_lam23(V self, V *args) {
  V v_st_24268 = args[0];
  V v_msg_24267 = heff_env(self)[0];
  V v_start_24263 = heff_env(self)[1];
  V v_end_24264 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24269 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24267, heff_rec_n(2, shape_start__end, (V[]){v_start_24263, v_end_24264}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24269}), v_st_24268});
}
V g_heff_2esyntax_2esurface_2ealtL_lam24(V self, V *args) {
  V v_st_24277 = args[0];
  V v_msg_24276 = heff_env(self)[0];
  V v_start_24272 = heff_env(self)[1];
  V v_end_24273 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24278 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24276, heff_rec_n(2, shape_start__end, (V[]){v_start_24272, v_end_24273}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24278}), v_st_24277});
}
V g_heff_2esyntax_2esurface_2ealtL_lam25(V self, V *args) {
  V v_st_24289 = args[0];
  V v_msg_24288 = heff_env(self)[0];
  V v_start_24284 = heff_env(self)[1];
  V v_end_24285 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24290 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24288, heff_rec_n(2, shape_start__end, (V[]){v_start_24284, v_end_24285}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24290}), v_st_24289});
}
V g_heff_2esyntax_2esurface_2ealtL_lam26(V self, V *args) {
  V v_st_24301 = args[0];
  V v_msg_24300 = heff_env(self)[0];
  V v_start_24296 = heff_env(self)[1];
  V v_end_24297 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24302 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24300, heff_rec_n(2, shape_start__end, (V[]){v_start_24296, v_end_24297}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24302}), v_st_24301});
}
V g_heff_2esyntax_2esurface_2ealtL_lam28(V self, V *args) {
  V v_st_24315 = args[0];
  V v_m_24314 = heff_env(self)[0];
  V v_x_24312 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24316 = heff_tr(heff_call(v_m_24314, 1, (V[]){v_st_24315}));
  switch (heff_tag_of(v_x1_24316)) {
  case TAG_MkPair: {
    V v_x11_24317 = heff_field(v_x1_24316, 0);
    V v_st_24318 = heff_field(v_x1_24316, 1);
    V v_ru_24x1_24316_24MkPair = heff_take_reuse_n(v_x1_24316, 3ULL, 2);
    switch (heff_tag_of(v_x11_24317)) {
    case TAG_Left: {
      V v_e_24319 = heff_field(v_x11_24317, 0);
      heff_take_n(v_x11_24317, 1ULL, 1);
      heff_drop(v_x_24312);
      return heff_tag_at_n(v_ru_24x1_24316_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24319}), v_st_24318});
    }
    case TAG_Right: {
      V v_x_24320 = heff_field(v_x11_24317, 0);
      heff_take_n(v_x11_24317, 1ULL, 1);
      V v_t_24323;
      switch (heff_tag_of(v_x_24312)) {
      case TAG_At: {
        V v_s_24322 = heff_dup(heff_field(v_x_24312, 1));
        v_t_24323 = v_s_24322;
        break;
      }
      default: heff_nomatch(v_x_24312);
      }
      V v_t_24326;
      switch (heff_tag_of(v_x_24320)) {
      case TAG_At: {
        V v_s_24325 = heff_dup(heff_field(v_x_24320, 1));
        v_t_24326 = v_s_24325;
        break;
      }
      default: heff_nomatch(v_x_24320);
      }
      V v_t_24327 = ({ V rv_1 = heff_get_n(v_t_24326, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24323, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_24328 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24312, v_x_24320}), v_t_24327});
      return heff_tag_at_n(v_ru_24x1_24316_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24328}), v_st_24318});
    }
    default: return heff_nomatch(v_x11_24317);
    }
  }
  default: return heff_nomatch(v_x1_24316);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_lam27(V self, V *args) {
  V v_st_24307 = args[0];
  V v_m_24306 = heff_env(self)[0];
  V v_p_24303 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_e_24305 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24308 = heff_tr(heff_call(v_m_24306, 1, (V[]){v_st_24307}));
  switch (heff_tag_of(v_x1_24308)) {
  case TAG_MkPair: {
    V v_x11_24309 = heff_field(v_x1_24308, 0);
    V v_st_24310 = heff_field(v_x1_24308, 1);
    V v_ru_24x1_24308_24MkPair = heff_take_reuse_n(v_x1_24308, 3ULL, 2);
    switch (heff_tag_of(v_x11_24309)) {
    case TAG_Left: {
      V v_e_24311 = heff_field(v_x11_24309, 0);
      heff_take_n(v_x11_24309, 1ULL, 1);
      heff_drop(v_p_24303);
      heff_drop(v_e_243);
      heff_drop(v_e_24305);
      return heff_tag_at_n(v_ru_24x1_24308_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24311}), v_st_24310});
    }
    case TAG_Right: {
      V v_x_24312 = heff_field(v_x11_24309, 0);
      heff_take_n(v_x11_24309, 1ULL, 1);
      V v_t_24313 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_p_24303; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop(v_p_24303); r_; });
      V v_m_24314 = heff_tr(heff_call(v_e_243, 1, (V[]){v_e_24305}));
      return (g_heff_2esyntax_2esurface_2ewithScope_24tok2(v_ru_24x1_24308_24MkPair, v_t_24313, heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam28, 1, 2, (V[]){v_m_24314, v_x_24312}), v_st_24310));
    }
    default: return heff_nomatch(v_x11_24309);
    }
  }
  default: return heff_nomatch(v_x1_24308);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_lam29(V self, V *args) {
  V v_st_24341 = args[0];
  V v_msg_24340 = heff_env(self)[0];
  V v_start_24336 = heff_env(self)[1];
  V v_end_24337 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24342 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24340, heff_rec_n(2, shape_start__end, (V[]){v_start_24336, v_end_24337}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24342}), v_st_24341});
}
V g_heff_2esyntax_2esurface_2ealtL_lam30(V self, V *args) {
  V v_st_24351 = args[0];
  V v_msg_24350 = heff_env(self)[0];
  V v_start_24346 = heff_env(self)[1];
  V v_end_24347 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24352 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24350, heff_rec_n(2, shape_start__end, (V[]){v_start_24346, v_end_24347}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24352}), v_st_24351});
}
V g_heff_2esyntax_2esurface_2ealtL_lam31(V self, V *args) {
  V v_st_24362 = args[0];
  V v_msg_24361 = heff_env(self)[0];
  V v_start_24357 = heff_env(self)[1];
  V v_end_24358 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24363 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24361, heff_rec_n(2, shape_start__end, (V[]){v_start_24357, v_end_24358}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24363}), v_st_24362});
}
V g_heff_2esyntax_2esurface_2ealtL_lam32(V self, V *args) {
  V v_st_24376 = args[0];
  V v_msg_24375 = heff_env(self)[0];
  V v_start_24371 = heff_env(self)[1];
  V v_end_24372 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24377 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24375, heff_rec_n(2, shape_start__end, (V[]){v_start_24371, v_end_24372}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24377}), v_st_24376});
}
V g_heff_2esyntax_2esurface_2ealtL_lam33(V self, V *args) {
  V v_st_24391 = args[0];
  V v_msg_24390 = heff_env(self)[0];
  V v_start_24386 = heff_env(self)[1];
  V v_end_24387 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24392 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24390, heff_rec_n(2, shape_start__end, (V[]){v_start_24386, v_end_24387}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24392}), v_st_24391});
}
V g_heff_2esyntax_2esurface_2ealtL_lam34(V self, V *args) {
  V v_st_24405 = args[0];
  V v_msg_24404 = heff_env(self)[0];
  V v_start_24400 = heff_env(self)[1];
  V v_end_24401 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24406 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24404, heff_rec_n(2, shape_start__end, (V[]){v_start_24400, v_end_24401}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24406}), v_st_24405});
}
V g_heff_2esyntax_2esurface_2ealtL_lam35(V self, V *args) {
  V v_st_24416 = args[0];
  V v_msg_24415 = heff_env(self)[0];
  V v_start_24411 = heff_env(self)[1];
  V v_end_24412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24415, heff_rec_n(2, shape_start__end, (V[]){v_start_24411, v_end_24412}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24417}), v_st_24416});
}
V g_heff_2esyntax_2esurface_2ealtL_lam36(V self, V *args) {
  V v_st_24428 = args[0];
  V v_msg_24427 = heff_env(self)[0];
  V v_start_24423 = heff_env(self)[1];
  V v_end_24424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24427, heff_rec_n(2, shape_start__end, (V[]){v_start_24423, v_end_24424}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24429}), v_st_24428});
}
V g_heff_2esyntax_2esurface_2ealtL_lam37(V self, V *args) {
  V v_st_24442 = args[0];
  V v_msg_24441 = heff_env(self)[0];
  V v_start_24437 = heff_env(self)[1];
  V v_end_24438 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24443 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24441, heff_rec_n(2, shape_start__end, (V[]){v_start_24437, v_end_24438}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24443}), v_st_24442});
}
V g_heff_2esyntax_2esurface_2ealtL_lam38(V self, V *args) {
  V v_st_24451 = args[0];
  V v_msg_24450 = heff_env(self)[0];
  V v_start_24446 = heff_env(self)[1];
  V v_end_24447 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24452 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24450, heff_rec_n(2, shape_start__end, (V[]){v_start_24446, v_end_24447}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24452}), v_st_24451});
}
V g_heff_2esyntax_2esurface_2ealtL_lam39(V self, V *args) {
  V v_st_24461 = args[0];
  V v_msg_24460 = heff_env(self)[0];
  V v_start_24456 = heff_env(self)[1];
  V v_end_24457 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24462 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24460, heff_rec_n(2, shape_start__end, (V[]){v_start_24456, v_end_24457}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24462}), v_st_24461});
}
V g_heff_2esyntax_2esurface_2ealtL_lam40(V self, V *args) {
  V v_st_24473 = args[0];
  V v_msg_24472 = heff_env(self)[0];
  V v_start_24468 = heff_env(self)[1];
  V v_end_24469 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24474 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24472, heff_rec_n(2, shape_start__end, (V[]){v_start_24468, v_end_24469}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24474}), v_st_24473});
}
V g_heff_2esyntax_2esurface_2ealtL_lam41(V self, V *args) {
  V v_st_24483 = args[0];
  V v_msg_24482 = heff_env(self)[0];
  V v_start_24478 = heff_env(self)[1];
  V v_end_24479 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24484 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24482, heff_rec_n(2, shape_start__end, (V[]){v_start_24478, v_end_24479}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24484}), v_st_24483});
}
V g_heff_2esyntax_2esurface_2ealtL_lam42(V self, V *args) {
  V v_st_24495 = args[0];
  V v_msg_24494 = heff_env(self)[0];
  V v_start_24490 = heff_env(self)[1];
  V v_end_24491 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24496 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24494, heff_rec_n(2, shape_start__end, (V[]){v_start_24490, v_end_24491}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24496}), v_st_24495});
}
V g_heff_2esyntax_2esurface_2ealtL_lam43(V self, V *args) {
  V v_st_24507 = args[0];
  V v_msg_24506 = heff_env(self)[0];
  V v_start_24502 = heff_env(self)[1];
  V v_end_24503 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24508 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24506, heff_rec_n(2, shape_start__end, (V[]){v_start_24502, v_end_24503}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24508}), v_st_24507});
}
V g_heff_2esyntax_2esurface_2ealtL_lam44(V self, V *args) {
  V v_st_24519 = args[0];
  V v_msg_24518 = heff_env(self)[0];
  V v_start_24514 = heff_env(self)[1];
  V v_end_24515 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24520 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24518, heff_rec_n(2, shape_start__end, (V[]){v_start_24514, v_end_24515}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24520}), v_st_24519});
}
V g_heff_2esyntax_2esurface_2ealtL_lam45(V self, V *args) {
  V v_st_24533 = args[0];
  V v_msg_24532 = heff_env(self)[0];
  V v_start_24528 = heff_env(self)[1];
  V v_end_24529 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24534 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24532, heff_rec_n(2, shape_start__end, (V[]){v_start_24528, v_end_24529}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24534}), v_st_24533});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str0, 4, "True");
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str1, 4, "True");
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str2, 5, "False");
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str3, 5, "False");
Clo g_heff_2esyntax_2esurface_2eifE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eifE_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eifE(V v_sp_240, V v_c_241, V v_a_242, V v_b_243) {
top: ;
  V v_t_244 = (g_heff_2esyntax_2epresyntax_2eboolOf(v_c_241));
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str0)}), heff_dup(v_sp_240)});
  V v_x1_246 = ({ V a_0 = v_t_245; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_249;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_At: {
    V v_s_248 = heff_field(v_x1_246, 1);
    heff_take_n(v_x1_246, 2ULL, 2);
    v_t_249 = v_s_248;
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  V v_t_2410 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_249, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2411 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str1), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_dup(v_t_2410)}), heff_dup(v_a_242)});
  V v_t_2415;
  switch (heff_tag_of(v_a_242)) {
  case TAG_At: {
    V v_s_2414 = heff_field(v_a_242, 1);
    heff_take_n(v_a_242, 2ULL, 2);
    v_t_2415 = v_s_2414;
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  V v_t_2416 = ({ V rv_1 = heff_get_n(v_t_2415, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2410, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str2)}), heff_dup(v_sp_240)});
  V v_x1_2418 = ({ V a_0 = v_t_2417; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2421;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_At: {
    V v_s_2420 = heff_field(v_x1_2418, 1);
    heff_take_n(v_x1_2418, 2ULL, 2);
    v_t_2421 = v_s_2420;
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  V v_t_2422 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2421, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2423 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str3), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_2424 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, heff_dup(v_t_2422)}), heff_dup(v_b_243)});
  V v_t_2427;
  switch (heff_tag_of(v_b_243)) {
  case TAG_At: {
    V v_s_2426 = heff_field(v_b_243, 1);
    heff_take_n(v_b_243, 2ULL, 2);
    v_t_2427 = v_s_2426;
    break;
  }
  default: heff_nomatch(v_b_243);
  }
  V v_t_2428 = ({ V rv_1 = heff_get_n(v_t_2427, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2422, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_t_2428}), NTAG(TAG_Nil)});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_t_2416}), v_t_2429});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_t_244, v_t_2430}), v_sp_240});
}
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eifE(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2esurface_2eunitIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eunitIn_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eunitIn(V v_ty_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_ty_240)) {
    case TAG_SegmentInteger: {
      return MK_INT(1LL);
    }
    case TAG_SegmentBinary: {
      return MK_INT(8LL);
    }
    case TAG_SegmentBits: {
      return MK_INT(1LL);
    }
    case TAG_SegmentFloat: {
      return MK_INT(1LL);
    }
    case TAG_SegmentUtf: {
      return MK_INT(1LL);
    }
    default: return heff_nomatch(v_ty_240);
    }
  }
  case TAG_Just: {
    V v_u_243 = heff_field(v_x2_241, 0);
    return heff_dup(v_u_243);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eunitIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eunitIn(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str0, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str1, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str2, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str3, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str4, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str5, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str6, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str7, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str8, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str9, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str10, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str11, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str12, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str13, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str14, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str15, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str16, 64, "bits are of no endianness nor sign: `x::bits`, `x::bits-size(3)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str17, 64, "bits are of no endianness nor sign: `x::bits`, `x::bits-size(3)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str18, 43, "a float's segment is of 32 or 64 bits, not ");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str19, 51, "a float's size is a number, 32 or 64: `x::float-32`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str20, 55, "a float is of no sign: `x::float`, `x::float-32-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str21, 36, "UTF-8 is of no endianness: `c::utf8`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str23, 35, "a code point is of no sign: `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str25, 64, "` segment is as long as its code point: it says no size, `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str26, 6, "a `utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str27, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str28, 35, "a code point is of no sign: `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str29, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str30, 64, "` segment is as long as its code point: it says no size, `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str31, 6, "a `utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str33, 35, "a code point is of no sign: `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str35, 64, "` segment is as long as its code point: it says no size, `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str36, 6, "a `utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str37, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str38, 35, "a code point is of no sign: `c::utf");
V g_heff_2esyntax_2esurface_2etypeChecks_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam14(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam14, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam15(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam15, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam16(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam16, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam20(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam20, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam22(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam22, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam29(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etypeChecks_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_entry, 6, 0};

V g_heff_2esyntax_2esurface_2etypeChecks(V v_inPat_240, V v_sp_241, V v_v_242, V v_s_243, V v_x5_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_SegmentInteger: {
    V v_t_2410;
    switch (heff_tag_of(v_x6_245)) {
    case TAG_SizeDefault: {
      v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(8LL)});
      break;
    }
    case TAG_SizeNumber: {
      V v_n_246 = heff_field(v_x6_245, 0);
      V v_ru_24x6_245_24SizeNumber = heff_take_reuse_n(v_x6_245, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x6_245_24SizeNumber, TAG_Just, 1, (V[]){v_n_246});
      break;
    }
    case TAG_SizeName: {
      heff_take_n(v_x6_245, 0ULL, 3);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x6_245);
    }
    return (g_heff_2esyntax_2esurface_2eintegerChecks(v_inPat_240, v_sp_241, v_v_242, v_s_243, v_t_2410));
  }
  case TAG_SegmentBinary: {
    heff_drop(v_x6_245);
    switch (heff_tag_of(v_v_242)) {
    case TAG_StrValue: {
      V v_t_2411 = heff_take_field(v_s_243, 1);
      switch (heff_tag_of(v_t_2411)) {
      case TAG_SizeDefault: {
        V v_t_2412 = heff_take_field(v_s_243, 3);
        switch (heff_tag_of(v_t_2412)) {
        case TAG_Nothing: {
          V v_t_2413 = heff_get_n(v_s_243, 4, 5);
          switch (heff_tag_of(v_t_2413)) {
          case TAG_Nothing: {
            heff_drop(v_sp_241);
            return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam0_clo);
          }
          case TAG_Just: {
            heff_take_n(v_t_2413, 0ULL, 1);
            return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam1, 1, 1, (V[]){v_sp_241});
          }
          default: return heff_nomatch(v_t_2413);
          }
        }
        case TAG_Just: {
          heff_take_n(v_t_2412, 0ULL, 1);
          heff_drop_rec(v_s_243, 5);
          return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam2, 1, 1, (V[]){v_sp_241});
        }
        default: return heff_nomatch(v_t_2412);
        }
      }
      case TAG_SizeNumber: {
        heff_take_n(v_t_2411, 0ULL, 1);
        heff_drop_rec(v_s_243, 5);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam3, 1, 1, (V[]){v_sp_241});
      }
      case TAG_SizeName: {
        heff_take_n(v_t_2411, 0ULL, 3);
        heff_drop_rec(v_s_243, 5);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam4, 1, 1, (V[]){v_sp_241});
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    case TAG_IntValue: {
      heff_take_n(v_v_242, 0ULL, 1);
      V v_t_2431 = heff_dup(heff_rfield(v_s_243, 2));
      V v_t_2433;
      switch (heff_tag_of(v_t_2431)) {
      case TAG_Nothing: {
        v_t_2433 = MK_INT(8LL);
        break;
      }
      case TAG_Just: {
        V v_u_2432 = heff_field(v_t_2431, 0);
        heff_take_n(v_t_2431, 1ULL, 1);
        v_t_2433 = v_u_2432;
        break;
      }
      default: heff_nomatch(v_t_2431);
      }
      if (!(heff_unbox_word(heff_intMod(heff_dup(v_t_2433), MK_INT(8LL))) == ((int64_t)0ULL))) {
        heff_drop_rec(v_s_243, 5);
        heff_drop(v_t_2433);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam5, 1, 1, (V[]){v_sp_241});
      } else {
        heff_drop(v_t_2433);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam6, 1, 2, (V[]){v_s_243, v_sp_241});
      }
    }
    case TAG_FloatValue: {
      V v_t_2444 = heff_dup(heff_rfield(v_s_243, 2));
      V v_t_2446;
      switch (heff_tag_of(v_t_2444)) {
      case TAG_Nothing: {
        v_t_2446 = MK_INT(8LL);
        break;
      }
      case TAG_Just: {
        V v_u_2445 = heff_field(v_t_2444, 0);
        heff_take_n(v_t_2444, 1ULL, 1);
        v_t_2446 = v_u_2445;
        break;
      }
      default: heff_nomatch(v_t_2444);
      }
      if (!(heff_unbox_word(heff_intMod(heff_dup(v_t_2446), MK_INT(8LL))) == ((int64_t)0ULL))) {
        heff_drop_rec(v_s_243, 5);
        heff_drop(v_t_2446);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam7, 1, 1, (V[]){v_sp_241});
      } else {
        heff_drop(v_t_2446);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam8, 1, 2, (V[]){v_s_243, v_sp_241});
      }
    }
    case TAG_RuneValue: {
      V v_t_2457 = heff_dup(heff_rfield(v_s_243, 2));
      V v_t_2459;
      switch (heff_tag_of(v_t_2457)) {
      case TAG_Nothing: {
        v_t_2459 = MK_INT(8LL);
        break;
      }
      case TAG_Just: {
        V v_u_2458 = heff_field(v_t_2457, 0);
        heff_take_n(v_t_2457, 1ULL, 1);
        v_t_2459 = v_u_2458;
        break;
      }
      default: heff_nomatch(v_t_2457);
      }
      if (!(heff_unbox_word(heff_intMod(heff_dup(v_t_2459), MK_INT(8LL))) == ((int64_t)0ULL))) {
        heff_drop_rec(v_s_243, 5);
        heff_drop(v_t_2459);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam9, 1, 1, (V[]){v_sp_241});
      } else {
        heff_drop(v_t_2459);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam10, 1, 2, (V[]){v_s_243, v_sp_241});
      }
    }
    case TAG_OtherValue: {
      V v_t_2470 = heff_dup(heff_rfield(v_s_243, 2));
      V v_t_2472;
      switch (heff_tag_of(v_t_2470)) {
      case TAG_Nothing: {
        v_t_2472 = MK_INT(8LL);
        break;
      }
      case TAG_Just: {
        V v_u_2471 = heff_field(v_t_2470, 0);
        heff_take_n(v_t_2470, 1ULL, 1);
        v_t_2472 = v_u_2471;
        break;
      }
      default: heff_nomatch(v_t_2470);
      }
      if (!(heff_unbox_word(heff_intMod(heff_dup(v_t_2472), MK_INT(8LL))) == ((int64_t)0ULL))) {
        heff_drop_rec(v_s_243, 5);
        heff_drop(v_t_2472);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam11, 1, 1, (V[]){v_sp_241});
      } else {
        heff_drop(v_t_2472);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam12, 1, 2, (V[]){v_s_243, v_sp_241});
      }
    }
    default: return heff_nomatch(v_v_242);
    }
  }
  case TAG_SegmentBits: {
    heff_drop(v_v_242);
    heff_drop(v_x6_245);
    return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam13, 1, 2, (V[]){v_s_243, v_sp_241});
  }
  case TAG_SegmentFloat: {
    heff_drop(v_v_242);
    V v_t_2491 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2491)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x6_245)) {
      case TAG_SizeDefault: {
        heff_drop(v_sp_241);
        return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam14_clo);
      }
      case TAG_SizeNumber: {
        V v_x61_2494 = heff_field(v_x6_245, 0);
        heff_take_n(v_x6_245, 1ULL, 1);
        if (heff_intEq_c_lent(v_x61_2494, MK_INT(64LL), 2)) {
          heff_drop(v_sp_241);
          heff_drop(v_x61_2494);
          return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam15_clo);
        } else {
          if (heff_intEq_c_lent(v_x61_2494, MK_INT(32LL), 2)) {
            heff_drop(v_sp_241);
            heff_drop(v_x61_2494);
            return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam16_clo);
          } else {
            return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam17, 1, 2, (V[]){v_x61_2494, v_sp_241});
          }
        }
      }
      case TAG_SizeName: {
        heff_take_n(v_x6_245, 0ULL, 3);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam18, 1, 1, (V[]){v_sp_241});
      }
      default: return heff_nomatch(v_x6_245);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2491, 0ULL, 1);
      heff_drop(v_x6_245);
      return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam19, 1, 1, (V[]){v_sp_241});
    }
    default: return heff_nomatch(v_t_2491);
    }
  }
  case TAG_SegmentUtf: {
    V v_w_24110 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    heff_drop(v_v_242);
    heff_drop(v_x6_245);
    V v_signed_24111 = heff_take_field(v_s_243, 4);
    V v_t_24112 = heff_take_field(v_s_243, 1);
    switch (heff_tag_of(v_t_24112)) {
    case TAG_SizeDefault: {
      V v_t_24113 = heff_take_field(v_s_243, 2);
      switch (heff_tag_of(v_t_24113)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_signed_24111)) {
        case TAG_Nothing: {
          V v_t_24114 = heff_get_n(v_s_243, 3, 5);
          switch (heff_tag_of(v_t_24114)) {
          case TAG_Nothing: {
            heff_drop(v_sp_241);
            heff_drop(v_w_24110);
            return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam20_clo);
          }
          case TAG_Just: {
            heff_take_n(v_t_24114, 0ULL, 1);
            if (heff_intEq_c(v_w_24110, MK_INT(8LL))) {
              return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam21, 1, 1, (V[]){v_sp_241});
            } else {
              heff_drop(v_sp_241);
              return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam22_clo);
            }
          }
          default: return heff_nomatch(v_t_24114);
          }
        }
        case TAG_Just: {
          heff_take_n(v_signed_24111, 0ULL, 1);
          heff_drop_rec(v_s_243, 5);
          return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam23, 1, 2, (V[]){v_w_24110, v_sp_241});
        }
        default: return heff_nomatch(v_signed_24111);
        }
      }
      case TAG_Just: {
        heff_take_n(v_t_24113, 0ULL, 1);
        heff_drop_rec(v_s_243, 5);
        switch (heff_tag_of(v_signed_24111)) {
        case TAG_Nothing: {
          return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam24, 1, 2, (V[]){v_w_24110, v_sp_241});
        }
        case TAG_Just: {
          heff_take_n(v_signed_24111, 0ULL, 1);
          return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam25, 1, 2, (V[]){v_w_24110, v_sp_241});
        }
        default: return heff_nomatch(v_signed_24111);
        }
      }
      default: return heff_nomatch(v_t_24113);
      }
    }
    case TAG_SizeNumber: {
      heff_take_n(v_t_24112, 0ULL, 1);
      heff_drop_rec(v_s_243, 5);
      switch (heff_tag_of(v_signed_24111)) {
      case TAG_Nothing: {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam26, 1, 2, (V[]){v_w_24110, v_sp_241});
      }
      case TAG_Just: {
        heff_take_n(v_signed_24111, 0ULL, 1);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam27, 1, 2, (V[]){v_w_24110, v_sp_241});
      }
      default: return heff_nomatch(v_signed_24111);
      }
    }
    case TAG_SizeName: {
      heff_take_n(v_t_24112, 0ULL, 3);
      heff_drop_rec(v_s_243, 5);
      switch (heff_tag_of(v_signed_24111)) {
      case TAG_Nothing: {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam28, 1, 2, (V[]){v_w_24110, v_sp_241});
      }
      case TAG_Just: {
        heff_take_n(v_signed_24111, 0ULL, 1);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam29, 1, 2, (V[]){v_w_24110, v_sp_241});
      }
      default: return heff_nomatch(v_signed_24111);
      }
    }
    default: return heff_nomatch(v_t_24112);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2etypeChecks(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam0(V self, V *args) {
  V v_st_2414 = args[0];
  V v_t_2415 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_st_2414});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam1(V self, V *args) {
  V v_st_2417 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str0), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2418}), v_st_2417});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam2(V self, V *args) {
  V v_st_2420 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str1), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2421}), v_st_2420});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam3(V self, V *args) {
  V v_st_2423 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str2), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2424}), v_st_2423});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam4(V self, V *args) {
  V v_st_2428 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str3), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2429}), v_st_2428});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam5(V self, V *args) {
  V v_st_2434 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str4), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2435}), v_st_2434});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam6(V self, V *args) {
  V v_p_2436 = args[0];
  V v_s_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_take_field(v_s_243, 3);
  switch (heff_tag_of(v_t_2437)) {
  case TAG_Nothing: {
    V v_t_2438 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2438)) {
    case TAG_Nothing: {
      heff_drop(v_sp_241);
      V v_t_2439 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2439, v_p_2436});
    }
    case TAG_Just: {
      V v_ru_24t_2438_24Just = heff_take_reuse_n(v_t_2438, 0ULL, 1);
      V v_t_2441 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str5), v_sp_241, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2438_24Just, TAG_Left, 1, (V[]){v_t_2441}), v_p_2436});
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  case TAG_Just: {
    V v_ru_24t_2437_24Just = heff_take_reuse_n(v_t_2437, 0ULL, 1);
    heff_drop_rec(v_s_243, 5);
    V v_t_2443 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str6), v_sp_241, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2437_24Just, TAG_Left, 1, (V[]){v_t_2443}), v_p_2436});
  }
  default: return heff_nomatch(v_t_2437);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam7(V self, V *args) {
  V v_st_2447 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2448 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str7), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2448}), v_st_2447});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam8(V self, V *args) {
  V v_p_2449 = args[0];
  V v_s_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_take_field(v_s_243, 3);
  switch (heff_tag_of(v_t_2450)) {
  case TAG_Nothing: {
    V v_t_2451 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2451)) {
    case TAG_Nothing: {
      heff_drop(v_sp_241);
      V v_t_2452 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2452, v_p_2449});
    }
    case TAG_Just: {
      V v_ru_24t_2451_24Just = heff_take_reuse_n(v_t_2451, 0ULL, 1);
      V v_t_2454 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str8), v_sp_241, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2451_24Just, TAG_Left, 1, (V[]){v_t_2454}), v_p_2449});
    }
    default: return heff_nomatch(v_t_2451);
    }
  }
  case TAG_Just: {
    V v_ru_24t_2450_24Just = heff_take_reuse_n(v_t_2450, 0ULL, 1);
    heff_drop_rec(v_s_243, 5);
    V v_t_2456 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str9), v_sp_241, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2450_24Just, TAG_Left, 1, (V[]){v_t_2456}), v_p_2449});
  }
  default: return heff_nomatch(v_t_2450);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam9(V self, V *args) {
  V v_st_2460 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2461 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str10), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2461}), v_st_2460});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam10(V self, V *args) {
  V v_p_2462 = args[0];
  V v_s_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2463 = heff_take_field(v_s_243, 3);
  switch (heff_tag_of(v_t_2463)) {
  case TAG_Nothing: {
    V v_t_2464 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2464)) {
    case TAG_Nothing: {
      heff_drop(v_sp_241);
      V v_t_2465 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2465, v_p_2462});
    }
    case TAG_Just: {
      V v_ru_24t_2464_24Just = heff_take_reuse_n(v_t_2464, 0ULL, 1);
      V v_t_2467 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str11), v_sp_241, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2464_24Just, TAG_Left, 1, (V[]){v_t_2467}), v_p_2462});
    }
    default: return heff_nomatch(v_t_2464);
    }
  }
  case TAG_Just: {
    V v_ru_24t_2463_24Just = heff_take_reuse_n(v_t_2463, 0ULL, 1);
    heff_drop_rec(v_s_243, 5);
    V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str12), v_sp_241, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2463_24Just, TAG_Left, 1, (V[]){v_t_2469}), v_p_2462});
  }
  default: return heff_nomatch(v_t_2463);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam11(V self, V *args) {
  V v_st_2473 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2474 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str13), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2474}), v_st_2473});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam12(V self, V *args) {
  V v_p_2475 = args[0];
  V v_s_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2476 = heff_take_field(v_s_243, 3);
  switch (heff_tag_of(v_t_2476)) {
  case TAG_Nothing: {
    V v_t_2477 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2477)) {
    case TAG_Nothing: {
      heff_drop(v_sp_241);
      V v_t_2478 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2478, v_p_2475});
    }
    case TAG_Just: {
      V v_ru_24t_2477_24Just = heff_take_reuse_n(v_t_2477, 0ULL, 1);
      V v_t_2480 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str14), v_sp_241, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2477_24Just, TAG_Left, 1, (V[]){v_t_2480}), v_p_2475});
    }
    default: return heff_nomatch(v_t_2477);
    }
  }
  case TAG_Just: {
    V v_ru_24t_2476_24Just = heff_take_reuse_n(v_t_2476, 0ULL, 1);
    heff_drop_rec(v_s_243, 5);
    V v_t_2482 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str15), v_sp_241, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2476_24Just, TAG_Left, 1, (V[]){v_t_2482}), v_p_2475});
  }
  default: return heff_nomatch(v_t_2476);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam13(V self, V *args) {
  V v_p_2483 = args[0];
  V v_s_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2484 = heff_take_field(v_s_243, 3);
  switch (heff_tag_of(v_t_2484)) {
  case TAG_Nothing: {
    V v_t_2485 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2485)) {
    case TAG_Nothing: {
      heff_drop(v_sp_241);
      V v_t_2486 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2486, v_p_2483});
    }
    case TAG_Just: {
      V v_ru_24t_2485_24Just = heff_take_reuse_n(v_t_2485, 0ULL, 1);
      V v_t_2488 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str16), v_sp_241, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2485_24Just, TAG_Left, 1, (V[]){v_t_2488}), v_p_2483});
    }
    default: return heff_nomatch(v_t_2485);
    }
  }
  case TAG_Just: {
    V v_ru_24t_2484_24Just = heff_take_reuse_n(v_t_2484, 0ULL, 1);
    heff_drop_rec(v_s_243, 5);
    V v_t_2490 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str17), v_sp_241, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2484_24Just, TAG_Left, 1, (V[]){v_t_2490}), v_p_2483});
  }
  default: return heff_nomatch(v_t_2484);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam14(V self, V *args) {
  V v_st_2492 = args[0];
  V v_t_2493 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2493, v_st_2492});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam15(V self, V *args) {
  V v_st_2495 = args[0];
  V v_t_2496 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2496, v_st_2495});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam16(V self, V *args) {
  V v_st_2497 = args[0];
  V v_t_2498 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2498, v_st_2497});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam17(V self, V *args) {
  V v_st_2499 = args[0];
  V v_x61_2494 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24100 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str18), heff_intShow(v_x61_2494));
  V v_t_24101 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_24100, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24101}), v_st_2499});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam18(V self, V *args) {
  V v_st_24105 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24106 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str19), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24106}), v_st_24105});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam19(V self, V *args) {
  V v_st_24108 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24109 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str20), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24109}), v_st_24108});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam20(V self, V *args) {
  V v_st_24115 = args[0];
  V v_t_24116 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24116, v_st_24115});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam21(V self, V *args) {
  V v_st_24118 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24119 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str21), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24119}), v_st_24118});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam22(V self, V *args) {
  V v_st_24120 = args[0];
  V v_t_24121 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24121, v_st_24120});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam23(V self, V *args) {
  V v_st_24123 = args[0];
  V v_w_24110 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24124 = heff_strAppend(heff_intShow(v_w_24110), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str22));
  V v_t_24125 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str23), v_t_24124), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24125}), v_st_24123});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam24(V self, V *args) {
  V v_st_24127 = args[0];
  V v_w_24110 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24128 = heff_strAppend(heff_intShow(heff_dup(v_w_24110)), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str24));
  V v_t_24129 = heff_strAppend(heff_intShow(v_w_24110), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str25), v_t_24128));
  V v_t_24130 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str26), v_t_24129), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24130}), v_st_24127});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam25(V self, V *args) {
  V v_st_24132 = args[0];
  V v_w_24110 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24133 = heff_strAppend(heff_intShow(v_w_24110), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str27));
  V v_t_24134 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str28), v_t_24133), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24134}), v_st_24132});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam26(V self, V *args) {
  V v_st_24136 = args[0];
  V v_w_24110 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24137 = heff_strAppend(heff_intShow(heff_dup(v_w_24110)), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str29));
  V v_t_24138 = heff_strAppend(heff_intShow(v_w_24110), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str30), v_t_24137));
  V v_t_24139 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str31), v_t_24138), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24139}), v_st_24136});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam27(V self, V *args) {
  V v_st_24141 = args[0];
  V v_w_24110 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24142 = heff_strAppend(heff_intShow(v_w_24110), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str32));
  V v_t_24143 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str33), v_t_24142), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24143}), v_st_24141});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam28(V self, V *args) {
  V v_st_24147 = args[0];
  V v_w_24110 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24148 = heff_strAppend(heff_intShow(heff_dup(v_w_24110)), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str34));
  V v_t_24149 = heff_strAppend(heff_intShow(v_w_24110), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str35), v_t_24148));
  V v_t_24150 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str36), v_t_24149), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24150}), v_st_24147});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam29(V self, V *args) {
  V v_st_24152 = args[0];
  V v_w_24110 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24153 = heff_strAppend(heff_intShow(v_w_24110), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str37));
  V v_t_24154 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str38), v_t_24153), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24154}), v_st_24152});
}
Clo g_heff_2esyntax_2esurface_2evalueOfE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evalueOfE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2evalueOfE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ETag: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EInt: {
      V v_v_246 = heff_field(v_x11_241, 0);
      return heff_tag_n(TAG_IntValue, 1, (V[]){heff_dup(v_v_246)});
    }
    case TAG_EFloat: {
      return NTAG(TAG_FloatValue);
    }
    case TAG_EString: {
      return NTAG(TAG_StrValue);
    }
    case TAG_EBinary: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ERune: {
      return NTAG(TAG_RuneValue);
    }
    case TAG_EWord: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EApp: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EProject: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ENamed: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EPi: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELam: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EAnn: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ESpec: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ESig: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ESum: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EStruct: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EMatch: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EDo: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELocal: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EAssign: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EWhile: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EFor: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EBreak: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EContinue: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EReturn: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ENest: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELazy: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ETuple: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ETry: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EWith: {
      return NTAG(TAG_OtherValue);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2evalueOfE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2evalueOfE(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eparamOf_str0, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
Clo g_heff_2esyntax_2esurface_2eparamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eparamOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eparamOf(V v_p_240, V v_z_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2esurface_2enameAnn_24cpr(heff_dup(v_p_240)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop(v_p_240);
      V v_q_245 = v_field_244;
      V v_name_246 = heff_take_field(v_q_245, 0);
      V v_span_247 = heff_take_field(v_q_245, 1);
      V v_ty_248 = heff_get_n(v_q_245, 2, 3);
      V v_t_2411;
      switch (heff_tag_of(v_ty_248)) {
      case TAG_At: {
        V v_s_2410 = heff_dup(heff_field(v_ty_248, 1));
        v_t_2411 = v_s_2410;
        break;
      }
      default: heff_nomatch(v_ty_248);
      }
      V v_t_2412 = ({ V rv_0 = heff_dup(heff_rfield(v_span_247, 0)); V rr_ = heff_rec_reuse_nf(v_t_2411, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_name_246, v_span_247, v_ty_248}), v_t_2412});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_z_241});
    } else {
      heff_drop(v_field_244);
      V v_t_2416;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2415 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_t_2416 = v_s_2415;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eparamOf_str0), v_t_2416, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2417}), v_z_241});
    }
  }
}
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eparamOf(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edataParamL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edataParamL(V v_r_240, V v_e_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2esurface_2eatomOf_24cpr(heff_dup(v_e_241)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop(v_r_240);
      heff_drop(v_e_241);
      V v_x_245 = v_field_244;
      V v_text_246 = heff_take_field(v_x_245, 1);
      V v_start_247 = heff_take_field(v_x_245, 3);
      V v_end_248 = heff_get_n(v_x_245, 4, 9);
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamL_lam0, 1, 3, (V[]){v_start_247, v_end_248, v_text_246});
    } else {
      heff_drop(v_field_244);
      HEFF_LAST return g_heff_2esyntax_2esurface_2edataParamOf(v_r_240, v_e_241);
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edataParamL_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_start_247 = heff_env(self)[0];
  V v_end_248 = heff_env(self)[1];
  V v_text_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_247), heff_dup(v_end_248)})});
  V v_t_2412 = heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_text_246, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_247), heff_dup(v_end_248)}), v_t_2411});
  V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_st_249});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str0, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str1, 7, "Mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str2, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str3, 70, "a `mutual` block holds definitions, each a signature and its equations");

HeffT2 g_heff_2esyntax_2esurface_2emutualL_24cpr(V v_r_240, V v_kw_241, V v_ds_242, V v_z_243) {
top: ;
  V v_start_244 = heff_take_field(v_kw_241, 3);
  V v_end_245 = heff_get_n(v_kw_241, 4, 9);
  HeffT2 v_t_246 = (g_heff_2esyntax_2esurface_2efirstSig_24cpr(heff_dup(v_ds_242)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_f1_249 = v_field_248;
      HeffT2 v_t_2410 = (g_heff_2esyntax_2esurface_2emutualItems_24cpr(v_r_240, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str0), heff_dup(v_f1_249)), heff_dup(v_ds_242), v_z_243));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x11_2413 = v_field_2411;
        V v_st_2414 = v_field_2412;
        switch (heff_tag_of(v_x11_2413)) {
        case TAG_Left: {
          V v_e_2415 = heff_field(v_x11_2413, 0);
          V v_ru_24x11_2413_24Left = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
          heff_drop(v_ds_242);
          heff_drop(v_start_244);
          heff_drop(v_end_245);
          heff_drop(v_f1_249);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2413_24Left, TAG_Left, 1, (V[]){v_e_2415}), v_st_2414}});
        }
        case TAG_Right: {
          V v_x_2416 = heff_field(v_x11_2413, 0);
          V v_ru_24x11_2413_24Right = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
          V v_t_2417 = (g_heff_2esyntax_2esurface_2emutualDefs(heff_dup(v_x_2416)));
          V v_t_2418 = (g_list_2emap_24s2081681776x559624592(v_t_2417));
          V v_t_2419 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2418));
          switch (heff_tag_of(v_t_2419)) {
          case TAG_Nil: {
            V v_x1_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_242));
            V v_e_2424;
            switch (heff_tag_of(v_x1_2420)) {
            case TAG_Nil: {
              v_e_2424 = heff_dup(v_end_245);
              break;
            }
            case TAG_Cons: {
              V v_x_2421 = heff_field(v_x1_2420, 0);
              heff_take_n(v_x1_2420, 1ULL, 2);
              V v_t_2423 = (g_heff_2esyntax_2ecst_2elastD(v_x_2421));
              v_e_2424 = heff_get_n(v_t_2423, 4, 9);
              break;
            }
            default: heff_nomatch(v_x1_2420);
            }
            V v_t_2425 = (g_heff_2esyntax_2esurface_2emutualDefs(v_x_2416));
            V v_x_2426 = (g_heff_2esyntax_2esurface_2emutualOut(heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_244), v_end_245}), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_e_2424}), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str1), heff_dup(v_f1_249)), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str2), v_f1_249), v_t_2425));
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){v_x_2426}), v_st_2414}});
          }
          case TAG_Cons: {
            V v_d_2427 = heff_field(v_t_2419, 0);
            heff_take_n(v_t_2419, 1ULL, 2);
            heff_drop(v_ds_242);
            heff_drop(v_start_244);
            heff_drop(v_end_245);
            heff_drop(v_f1_249);
            heff_drop(v_x_2416);
            heff_drop_cell(v_ru_24x11_2413_24Right, 1);
            return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2427}), v_st_2414}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2419)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2413)}});
        }
      }
    } else {
      heff_drop(v_r_240);
      heff_drop(v_ds_242);
      heff_drop(v_field_248);
      V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str3), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
      V v_f_2430 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2429});
      return ((HeffT2){{v_f_2430, v_z_243}});
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str1, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str2, 6, "infixl");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str3, 6, "infixr");

HeffT2 g_heff_2esyntax_2esurface_2efixDeclAt_24cpr(V v_ts_240, V v_k_241, V v_t_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_t_242, 6));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_242, 5)), MK_INT(0LL))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str0))) {
        V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_242, 1))}));
        V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str1), NTAG(TAG_Nil)});
        V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str3), v_t_245})});
        V v_t_247 = ({ V a_0 = v_t_244; V a_1 = v_t_246; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_246, 2); r_; });
        if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
          heff_drop(v_t_247);
          V v_f_248 = (g_heff_2esyntax_2esurface_2efixDeclOf(v_ts_240, v_k_241, v_t_242));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
        } else {
          heff_drop(v_k_241);
          heff_drop_rec(v_t_242, 7);
          heff_drop(v_t_247);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop(v_k_241);
        heff_drop_rec(v_t_242, 7);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      heff_drop(v_k_241);
      heff_drop_rec(v_t_242, 7);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  } else {
    heff_drop(v_k_241);
    heff_drop_rec(v_t_242, 7);
    heff_drop(v_t_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
V g_heff_2esyntax_2esurface_2ereadPlaced_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ereadPlaced_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadPlaced_entry, 5, 0};

V g_heff_2esyntax_2esurface_2ereadPlaced(V v_at_240, V v_lexDiags_241, V v_own_242, V v_r_243, V v_placed_244) {
top: ;
  V v_items_245 = heff_take_field(v_placed_244, 0);
  V v_diags_246 = heff_get_n(v_placed_244, 2, 3);
  V v_broken_247 = heff_take_field(v_r_243, 2);
  V v_diags_248 = heff_take_field(v_r_243, 1);
  V v_items_249 = heff_get_n(v_r_243, 0, 3);
  V v_diags_2410 = heff_take_field(v_own_242, 1);
  V v_fixities_2411 = heff_get_n(v_own_242, 0, 2);
  V v_items_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_245));
  V v_items_2413 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2412, NTAG(TAG_Nil)));
  V v_t_2414 = (g_heff_2esyntax_2esurface_2enameSet(v_broken_247));
  V v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_items_2413; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2eassembleGo(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
  V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_diags_246));
  V v_items_2417 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), heff_dup(v_items_249), NTAG(TAG_Nil)));
  V v_t_2418 = (g_heff_2esyntax_2esurface_2enameSet(v_broken_247));
  V v_t_2419 = (g_heff_2esyntax_2esurface_2esigNames(v_items_2417));
  V v_t_2420 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_2417));
  V v_t_2421 = ({ V a_0 = v_t_2418; V a_1 = v_t_2419; V a_2 = v_t_2420; V a_3 = v_items_2417; V r_ = (g_list_2emap_24s2130193383x1335133353(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); heff_drop(v_t_2419); heff_drop(v_t_2420); r_; });
  V v_t_2422 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2421));
  V v_items_2423 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_249, NTAG(TAG_Nil)));
  V v_t_2424 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
  V v_d_2428 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2ereadPlaced_lam0, 2, 1, (V[]){v_at_240}); V a_1 = v_t_2424; V a_2 = v_items_2423; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_items_2423); r_; });
  V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2428, 3, 4)));
  V v_t_2430 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2422, v_t_2429));
  V v_t_2431 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2416, v_t_2430));
  V v_t_2432 = (g_heff_2esyntax_2esurface_2eappendS(v_diags_248, v_t_2431));
  V v_t_2433 = (g_heff_2esyntax_2esurface_2eappendS(v_diags_2410, v_t_2432));
  V v_t_2434 = (g_heff_2esyntax_2esurface_2eappendS(v_lexDiags_241, v_t_2433));
  return heff_rec_n(4, shape_decls__diags__fixities__broken, (V[]){v_t_2415, v_t_2434, v_fixities_2411, v_broken_247});
}
V g_heff_2esyntax_2esurface_2ereadPlaced_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereadPlaced(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2ereadPlaced_lam0(V self, V *args) {
  V v_d_2425 = args[0];
  V v_it_2426 = args[1];
  V v_at_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2425, 2)), v_it_2426));
  return ({ V a_0 = v_at_240; V a_1 = v_d_2425; V a_2 = v_t_2427; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2427); r_; });
}