// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_BadFieldDecl 11244
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfLet 62066
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetCond 24397
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Update 40810
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_first 298798794
#define LBL_fixities 357800079
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_pat 320285
#define LBL_prims 308293287
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_unit 10090059
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_decls__diags__fixities__broken[] = {LBL_decls, LBL_diags, LBL_fixities, LBL_broken};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2epresyntax_2eboolOf(V);
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24dps_clo;
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2edataParamL(V, V);
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_clo;
V g_heff_2esyntax_2esurface_2edataParamOf(V, V);
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2efieldDeclOf(V, V);
V g_heff_2esyntax_2esurface_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldDeclOf_clo;
V g_heff_2esyntax_2esurface_2efieldL(V, V);
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efirstSig_24cpr(V);
HeffT2 g_heff_2esyntax_2esurface_2efixDeclAt_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclOf(V, V, V);
V g_heff_2esyntax_2esurface_2efixDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDeclOf_clo;
V g_heff_2esyntax_2esurface_2eifE(V, V, V, V);
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifE_clo;
V g_heff_2esyntax_2esurface_2eintegerChecks(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerChecks_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerChecks_clo;
V g_heff_2esyntax_2esurface_2emutualDefs(V);
V g_heff_2esyntax_2esurface_2emutualDefs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_clo;
HeffT2 g_heff_2esyntax_2esurface_2emutualItems_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2emutualL_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2emutualOut(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2emutualOut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualOut_clo;
HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V);
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2ereadPlaced(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadPlaced_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadPlaced_clo;
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2esplitExp(V, V);
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esplitExp_clo;
V g_heff_2esyntax_2esurface_2etypeChecks(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_clo;
V g_heff_2esyntax_2esurface_2eunitIn(V, V);
V g_heff_2esyntax_2esurface_2eunitIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunitIn_clo;
V g_heff_2esyntax_2esurface_2evalueOfE(V);
V g_heff_2esyntax_2esurface_2evalueOfE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evalueOfE_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s2081681776x559624592(V);
V g_list_2emap_24s2081681776x559624592_entry(V self, V *a);
extern Clo g_list_2emap_24s2081681776x559624592_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_std_2emap_2eempty_get(void);
Clo g_heff_2esyntax_2esurface_2eappendS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2esyntax_2esurface_2eappendS_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2esplitExp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esplitExp_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esplitExp(V v_s_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return heff_strLength_lent(v_s_240, 0);
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)101ULL))) {
      return v_i_241;
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)69ULL))) {
        return v_i_241;
      } else {
        V t_0 = v_s_240;
        V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esplitExp(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldL_str0, 1, "=");
V g_heff_2esyntax_2esurface_2efieldL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam41(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efieldL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efieldL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efieldL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Atom: {
    V v_m_243 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EParen: {
    V v_m_2414 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam1, 1, 1, (V[]){v_m_2414});
  }
  case TAG_Named: {
    V v_m_2427 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam2, 1, 1, (V[]){v_m_2427});
  }
  case TAG_Tup: {
    V v_m_2439 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam3, 1, 1, (V[]){v_m_2439});
  }
  case TAG_Seg: {
    V v_m_2450 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam4, 1, 1, (V[]){v_m_2450});
  }
  case TAG_Braces: {
    V v_m_2462 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam5, 1, 1, (V[]){v_m_2462});
  }
  case TAG_Update: {
    V v_m_2476 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam6, 1, 1, (V[]){v_m_2476});
  }
  case TAG_EUSet: {
    V v_m_2487 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam7, 1, 1, (V[]){v_m_2487});
  }
  case TAG_InstB: {
    V v_m_24100 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam8, 1, 1, (V[]){v_m_24100});
  }
  case TAG_EFSet: {
    V v_m_24111 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam9, 1, 1, (V[]){v_m_24111});
  }
  case TAG_EFDefault: {
    V v_e_24119 = heff_field(v_x2_241, 0);
    V v_eq_24120 = heff_field(v_x2_241, 1);
    V v_d_24121 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_24122 = (g_heff_2esyntax_2esurface_2edeclarationL(heff_dup(v_r_240), v_e_24119));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam10, 1, 4, (V[]){v_m_24122, v_r_240, v_d_24121, v_eq_24120});
  }
  case TAG_Sum: {
    V v_m_24145 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam11, 1, 1, (V[]){v_m_24145});
  }
  case TAG_ECon: {
    V v_m_24155 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam12, 1, 1, (V[]){v_m_24155});
  }
  case TAG_EField: {
    V v_m_24165 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam13, 1, 1, (V[]){v_m_24165});
  }
  case TAG_ENeg: {
    V v_m_24175 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam14, 1, 1, (V[]){v_m_24175});
  }
  case TAG_App: {
    V v_m_24185 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam15, 1, 1, (V[]){v_m_24185});
  }
  case TAG_Op: {
    V v_m_24196 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam16, 1, 1, (V[]){v_m_24196});
  }
  case TAG_Ops: {
    V v_m_24206 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam17, 1, 1, (V[]){v_m_24206});
  }
  case TAG_OpRhs: {
    V v_m_24216 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam18, 1, 1, (V[]){v_m_24216});
  }
  case TAG_Ann: {
    V v_m_24227 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam19, 1, 1, (V[]){v_m_24227});
  }
  case TAG_BVar: {
    V v_m_24236 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam20, 1, 1, (V[]){v_m_24236});
  }
  case TAG_BImp: {
    V v_m_24247 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam21, 1, 1, (V[]){v_m_24247});
  }
  case TAG_BAnn: {
    V v_m_24260 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam22, 1, 1, (V[]){v_m_24260});
  }
  case TAG_Lam: {
    V v_m_24272 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam23, 1, 1, (V[]){v_m_24272});
  }
  case TAG_Case: {
    V v_m_24284 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam24, 1, 1, (V[]){v_m_24284});
  }
  case TAG_EAlt: {
    V v_m_24295 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam25, 1, 1, (V[]){v_m_24295});
  }
  case TAG_If: {
    V v_m_24309 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam26, 1, 1, (V[]){v_m_24309});
  }
  case TAG_Do: {
    V v_m_24319 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam27, 1, 1, (V[]){v_m_24319});
  }
  case TAG_ESBind: {
    V v_m_24330 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam28, 1, 1, (V[]){v_m_24330});
  }
  case TAG_ELet: {
    V v_m_24344 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam29, 1, 1, (V[]){v_m_24344});
  }
  case TAG_ELetMut: {
    V v_m_24358 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam30, 1, 1, (V[]){v_m_24358});
  }
  case TAG_EAssign: {
    V v_m_24369 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam31, 1, 1, (V[]){v_m_24369});
  }
  case TAG_EWhile: {
    V v_m_24381 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam32, 1, 1, (V[]){v_m_24381});
  }
  case TAG_EFor: {
    V v_m_24395 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam33, 1, 1, (V[]){v_m_24395});
  }
  case TAG_EJump: {
    V v_m_24404 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam34, 1, 1, (V[]){v_m_24404});
  }
  case TAG_EReturn: {
    V v_m_24414 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam35, 1, 1, (V[]){v_m_24414});
  }
  case TAG_ENest: {
    V v_m_24426 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam36, 1, 1, (V[]){v_m_24426});
  }
  case TAG_IfThen: {
    V v_m_24438 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam37, 1, 1, (V[]){v_m_24438});
  }
  case TAG_ELetCond: {
    V v_m_24450 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam38, 1, 1, (V[]){v_m_24450});
  }
  case TAG_ETry: {
    V v_m_24462 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam39, 1, 1, (V[]){v_m_24462});
  }
  case TAG_ECatch: {
    V v_m_24474 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam40, 1, 1, (V[]){v_m_24474});
  }
  case TAG_EWith: {
    V v_m_24488 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_x2_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam41, 1, 1, (V[]){v_m_24488});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efieldL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2efieldL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      V v_x_2410 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_249, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2410}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam1(V self, V *args) {
  V v_st_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_st_2415}));
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_MkPair: {
    V v_x11_2417 = heff_field(v_x1_2416, 0);
    V v_st_2418 = heff_field(v_x1_2416, 1);
    V v_ru_24x1_2416_24MkPair = heff_take_reuse_n(v_x1_2416, 3ULL, 2);
    switch (heff_tag_of(v_x11_2417)) {
    case TAG_Left: {
      V v_e_2419 = heff_field(v_x11_2417, 0);
      heff_take_n(v_x11_2417, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2419}), v_st_2418});
    }
    case TAG_Right: {
      V v_x_2420 = heff_field(v_x11_2417, 0);
      heff_take_n(v_x11_2417, 1ULL, 1);
      V v_x_2421 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2420, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2421}), v_st_2418});
    }
    default: return heff_nomatch(v_x11_2417);
    }
  }
  default: return heff_nomatch(v_x1_2416);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam2(V self, V *args) {
  V v_st_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_st_2428}));
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_MkPair: {
    V v_x11_2430 = heff_field(v_x1_2429, 0);
    V v_st_2431 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24MkPair = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_Left: {
      V v_e_2432 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2432}), v_st_2431});
    }
    case TAG_Right: {
      V v_x_2433 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      V v_x_2434 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2433, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2434}), v_st_2431});
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_2429);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam3(V self, V *args) {
  V v_st_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_st_2440}));
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_MkPair: {
    V v_x11_2442 = heff_field(v_x1_2441, 0);
    V v_st_2443 = heff_field(v_x1_2441, 1);
    V v_ru_24x1_2441_24MkPair = heff_take_reuse_n(v_x1_2441, 3ULL, 2);
    switch (heff_tag_of(v_x11_2442)) {
    case TAG_Left: {
      V v_e_2444 = heff_field(v_x11_2442, 0);
      heff_take_n(v_x11_2442, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2444}), v_st_2443});
    }
    case TAG_Right: {
      V v_x_2445 = heff_field(v_x11_2442, 0);
      heff_take_n(v_x11_2442, 1ULL, 1);
      V v_x_2446 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2445, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2446}), v_st_2443});
    }
    default: return heff_nomatch(v_x11_2442);
    }
  }
  default: return heff_nomatch(v_x1_2441);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam4(V self, V *args) {
  V v_st_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_st_2451}));
  switch (heff_tag_of(v_x1_2452)) {
  case TAG_MkPair: {
    V v_x11_2453 = heff_field(v_x1_2452, 0);
    V v_st_2454 = heff_field(v_x1_2452, 1);
    V v_ru_24x1_2452_24MkPair = heff_take_reuse_n(v_x1_2452, 3ULL, 2);
    switch (heff_tag_of(v_x11_2453)) {
    case TAG_Left: {
      V v_e_2455 = heff_field(v_x11_2453, 0);
      heff_take_n(v_x11_2453, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2455}), v_st_2454});
    }
    case TAG_Right: {
      V v_x_2456 = heff_field(v_x11_2453, 0);
      heff_take_n(v_x11_2453, 1ULL, 1);
      V v_x_2457 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2456, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2457}), v_st_2454});
    }
    default: return heff_nomatch(v_x11_2453);
    }
  }
  default: return heff_nomatch(v_x1_2452);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam5(V self, V *args) {
  V v_st_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2464 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_st_2463}));
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_MkPair: {
    V v_x11_2465 = heff_field(v_x1_2464, 0);
    V v_st_2466 = heff_field(v_x1_2464, 1);
    V v_ru_24x1_2464_24MkPair = heff_take_reuse_n(v_x1_2464, 3ULL, 2);
    switch (heff_tag_of(v_x11_2465)) {
    case TAG_Left: {
      V v_e_2467 = heff_field(v_x11_2465, 0);
      heff_take_n(v_x11_2465, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2467}), v_st_2466});
    }
    case TAG_Right: {
      V v_x_2468 = heff_field(v_x11_2465, 0);
      heff_take_n(v_x11_2465, 1ULL, 1);
      V v_x_2469 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2468, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2469}), v_st_2466});
    }
    default: return heff_nomatch(v_x11_2465);
    }
  }
  default: return heff_nomatch(v_x1_2464);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam6(V self, V *args) {
  V v_st_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2478 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_st_2477}));
  switch (heff_tag_of(v_x1_2478)) {
  case TAG_MkPair: {
    V v_x11_2479 = heff_field(v_x1_2478, 0);
    V v_st_2480 = heff_field(v_x1_2478, 1);
    V v_ru_24x1_2478_24MkPair = heff_take_reuse_n(v_x1_2478, 3ULL, 2);
    switch (heff_tag_of(v_x11_2479)) {
    case TAG_Left: {
      V v_e_2481 = heff_field(v_x11_2479, 0);
      heff_take_n(v_x11_2479, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2481}), v_st_2480});
    }
    case TAG_Right: {
      V v_x_2482 = heff_field(v_x11_2479, 0);
      heff_take_n(v_x11_2479, 1ULL, 1);
      V v_x_2483 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2482, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2483}), v_st_2480});
    }
    default: return heff_nomatch(v_x11_2479);
    }
  }
  default: return heff_nomatch(v_x1_2478);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam7(V self, V *args) {
  V v_st_2488 = args[0];
  V v_m_2487 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2489 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_st_2488}));
  switch (heff_tag_of(v_x1_2489)) {
  case TAG_MkPair: {
    V v_x11_2490 = heff_field(v_x1_2489, 0);
    V v_st_2491 = heff_field(v_x1_2489, 1);
    V v_ru_24x1_2489_24MkPair = heff_take_reuse_n(v_x1_2489, 3ULL, 2);
    switch (heff_tag_of(v_x11_2490)) {
    case TAG_Left: {
      V v_e_2492 = heff_field(v_x11_2490, 0);
      heff_take_n(v_x11_2490, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2492}), v_st_2491});
    }
    case TAG_Right: {
      V v_x_2493 = heff_field(v_x11_2490, 0);
      heff_take_n(v_x11_2490, 1ULL, 1);
      V v_x_2494 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2493, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2494}), v_st_2491});
    }
    default: return heff_nomatch(v_x11_2490);
    }
  }
  default: return heff_nomatch(v_x1_2489);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam8(V self, V *args) {
  V v_st_24101 = args[0];
  V v_m_24100 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24102 = heff_tr(heff_call(v_m_24100, 1, (V[]){v_st_24101}));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_MkPair: {
    V v_x11_24103 = heff_field(v_x1_24102, 0);
    V v_st_24104 = heff_field(v_x1_24102, 1);
    V v_ru_24x1_24102_24MkPair = heff_take_reuse_n(v_x1_24102, 3ULL, 2);
    switch (heff_tag_of(v_x11_24103)) {
    case TAG_Left: {
      V v_e_24105 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24105}), v_st_24104});
    }
    case TAG_Right: {
      V v_x_24106 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      V v_x_24107 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24106, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24107}), v_st_24104});
    }
    default: return heff_nomatch(v_x11_24103);
    }
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam9(V self, V *args) {
  V v_st_24112 = args[0];
  V v_m_24111 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24113 = heff_tr(heff_call(v_m_24111, 1, (V[]){v_st_24112}));
  switch (heff_tag_of(v_x1_24113)) {
  case TAG_MkPair: {
    V v_x11_24114 = heff_field(v_x1_24113, 0);
    V v_st_24115 = heff_field(v_x1_24113, 1);
    V v_ru_24x1_24113_24MkPair = heff_take_reuse_n(v_x1_24113, 3ULL, 2);
    switch (heff_tag_of(v_x11_24114)) {
    case TAG_Left: {
      V v_e_24116 = heff_field(v_x11_24114, 0);
      heff_take_n(v_x11_24114, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24116}), v_st_24115});
    }
    case TAG_Right: {
      V v_x_24117 = heff_field(v_x11_24114, 0);
      heff_take_n(v_x11_24114, 1ULL, 1);
      V v_x_24118 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24117, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24118}), v_st_24115});
    }
    default: return heff_nomatch(v_x11_24114);
    }
  }
  default: return heff_nomatch(v_x1_24113);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam10(V self, V *args) {
  V v_st_24123 = args[0];
  V v_m_24122 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_d_24121 = heff_env(self)[2];
  V v_eq_24120 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24124 = heff_tr(heff_call(v_m_24122, 1, (V[]){v_st_24123}));
  switch (heff_tag_of(v_x1_24124)) {
  case TAG_MkPair: {
    V v_x11_24125 = heff_field(v_x1_24124, 0);
    V v_st_24126 = heff_field(v_x1_24124, 1);
    V v_ru_24x1_24124_24MkPair = heff_take_reuse_n(v_x1_24124, 3ULL, 2);
    switch (heff_tag_of(v_x11_24125)) {
    case TAG_Left: {
      V v_e_24127 = heff_field(v_x11_24125, 0);
      heff_take_n(v_x11_24125, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_24121);
      heff_drop_rec(v_eq_24120, 9);
      return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24127}), v_st_24126});
    }
    case TAG_Right: {
      V v_x_24128 = heff_field(v_x11_24125, 0);
      V v_ru_24x11_24125_24Right = heff_take_reuse_n(v_x11_24125, 1ULL, 1);
      V v_m_24129 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_24121}));
      V v_x1_24130 = heff_tr(heff_call(v_m_24129, 1, (V[]){v_st_24126}));
      switch (heff_tag_of(v_x1_24130)) {
      case TAG_MkPair: {
        V v_x11_24131 = heff_field(v_x1_24130, 0);
        V v_st_24132 = heff_field(v_x1_24130, 1);
        V v_ru_24x1_24130_24MkPair = heff_take_reuse_n(v_x1_24130, 3ULL, 2);
        switch (heff_tag_of(v_x11_24131)) {
        case TAG_Left: {
          V v_e_24133 = heff_field(v_x11_24131, 0);
          heff_take_n(v_x11_24131, 1ULL, 1);
          heff_drop_rec(v_eq_24120, 9);
          heff_drop(v_x_24128);
          heff_drop_cell(v_ru_24x11_24125_24Right, 1);
          heff_drop_cell(v_ru_24x1_24130_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24133}), v_st_24132});
        }
        case TAG_Right: {
          V v_x_24134 = heff_field(v_x11_24131, 0);
          heff_take_n(v_x11_24131, 1ULL, 1);
          V v_x_24139;
          if (heff_strEq_c(heff_get_n(v_eq_24120, 1, 9), ((V)&g_heff_2esyntax_2esurface_2efieldL_str0))) {
            heff_drop_cell(v_ru_24x1_24130_24MkPair, 2);
            v_x_24139 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24128, heff_tag_at_n(v_ru_24x11_24125_24Right, TAG_Just, 1, (V[]){v_x_24134})));
          } else {
            heff_drop(v_x_24134);
            V v_t_24138;
            switch (heff_tag_of(v_x_24128)) {
            case TAG_At: {
              V v_s_24137 = heff_dup(heff_field(v_x_24128, 1));
              v_t_24138 = v_s_24137;
              break;
            }
            default: heff_nomatch(v_x_24128);
            }
            v_x_24139 = heff_tag_at_n(v_ru_24x1_24130_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24125_24Right, TAG_BadFieldDecl, 1, (V[]){v_x_24128}), v_t_24138});
          }
          return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24139}), v_st_24132});
        }
        default: return heff_nomatch(v_x11_24131);
        }
      }
      default: return heff_nomatch(v_x1_24130);
      }
    }
    default: return heff_nomatch(v_x11_24125);
    }
  }
  default: return heff_nomatch(v_x1_24124);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam11(V self, V *args) {
  V v_st_24146 = args[0];
  V v_m_24145 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24147 = heff_tr(heff_call(v_m_24145, 1, (V[]){v_st_24146}));
  switch (heff_tag_of(v_x1_24147)) {
  case TAG_MkPair: {
    V v_x11_24148 = heff_field(v_x1_24147, 0);
    V v_st_24149 = heff_field(v_x1_24147, 1);
    V v_ru_24x1_24147_24MkPair = heff_take_reuse_n(v_x1_24147, 3ULL, 2);
    switch (heff_tag_of(v_x11_24148)) {
    case TAG_Left: {
      V v_e_24150 = heff_field(v_x11_24148, 0);
      heff_take_n(v_x11_24148, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24150}), v_st_24149});
    }
    case TAG_Right: {
      V v_x_24151 = heff_field(v_x11_24148, 0);
      heff_take_n(v_x11_24148, 1ULL, 1);
      V v_x_24152 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24151, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24152}), v_st_24149});
    }
    default: return heff_nomatch(v_x11_24148);
    }
  }
  default: return heff_nomatch(v_x1_24147);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam12(V self, V *args) {
  V v_st_24156 = args[0];
  V v_m_24155 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24157 = heff_tr(heff_call(v_m_24155, 1, (V[]){v_st_24156}));
  switch (heff_tag_of(v_x1_24157)) {
  case TAG_MkPair: {
    V v_x11_24158 = heff_field(v_x1_24157, 0);
    V v_st_24159 = heff_field(v_x1_24157, 1);
    V v_ru_24x1_24157_24MkPair = heff_take_reuse_n(v_x1_24157, 3ULL, 2);
    switch (heff_tag_of(v_x11_24158)) {
    case TAG_Left: {
      V v_e_24160 = heff_field(v_x11_24158, 0);
      heff_take_n(v_x11_24158, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24157_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24160}), v_st_24159});
    }
    case TAG_Right: {
      V v_x_24161 = heff_field(v_x11_24158, 0);
      heff_take_n(v_x11_24158, 1ULL, 1);
      V v_x_24162 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24161, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24157_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24162}), v_st_24159});
    }
    default: return heff_nomatch(v_x11_24158);
    }
  }
  default: return heff_nomatch(v_x1_24157);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam13(V self, V *args) {
  V v_st_24166 = args[0];
  V v_m_24165 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24167 = heff_tr(heff_call(v_m_24165, 1, (V[]){v_st_24166}));
  switch (heff_tag_of(v_x1_24167)) {
  case TAG_MkPair: {
    V v_x11_24168 = heff_field(v_x1_24167, 0);
    V v_st_24169 = heff_field(v_x1_24167, 1);
    V v_ru_24x1_24167_24MkPair = heff_take_reuse_n(v_x1_24167, 3ULL, 2);
    switch (heff_tag_of(v_x11_24168)) {
    case TAG_Left: {
      V v_e_24170 = heff_field(v_x11_24168, 0);
      heff_take_n(v_x11_24168, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24167_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24170}), v_st_24169});
    }
    case TAG_Right: {
      V v_x_24171 = heff_field(v_x11_24168, 0);
      heff_take_n(v_x11_24168, 1ULL, 1);
      V v_x_24172 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24171, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24167_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24172}), v_st_24169});
    }
    default: return heff_nomatch(v_x11_24168);
    }
  }
  default: return heff_nomatch(v_x1_24167);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam14(V self, V *args) {
  V v_st_24176 = args[0];
  V v_m_24175 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24177 = heff_tr(heff_call(v_m_24175, 1, (V[]){v_st_24176}));
  switch (heff_tag_of(v_x1_24177)) {
  case TAG_MkPair: {
    V v_x11_24178 = heff_field(v_x1_24177, 0);
    V v_st_24179 = heff_field(v_x1_24177, 1);
    V v_ru_24x1_24177_24MkPair = heff_take_reuse_n(v_x1_24177, 3ULL, 2);
    switch (heff_tag_of(v_x11_24178)) {
    case TAG_Left: {
      V v_e_24180 = heff_field(v_x11_24178, 0);
      heff_take_n(v_x11_24178, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24177_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24180}), v_st_24179});
    }
    case TAG_Right: {
      V v_x_24181 = heff_field(v_x11_24178, 0);
      heff_take_n(v_x11_24178, 1ULL, 1);
      V v_x_24182 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24181, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24177_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24182}), v_st_24179});
    }
    default: return heff_nomatch(v_x11_24178);
    }
  }
  default: return heff_nomatch(v_x1_24177);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam15(V self, V *args) {
  V v_st_24186 = args[0];
  V v_m_24185 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24187 = heff_tr(heff_call(v_m_24185, 1, (V[]){v_st_24186}));
  switch (heff_tag_of(v_x1_24187)) {
  case TAG_MkPair: {
    V v_x11_24188 = heff_field(v_x1_24187, 0);
    V v_st_24189 = heff_field(v_x1_24187, 1);
    V v_ru_24x1_24187_24MkPair = heff_take_reuse_n(v_x1_24187, 3ULL, 2);
    switch (heff_tag_of(v_x11_24188)) {
    case TAG_Left: {
      V v_e_24190 = heff_field(v_x11_24188, 0);
      heff_take_n(v_x11_24188, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24187_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24190}), v_st_24189});
    }
    case TAG_Right: {
      V v_x_24191 = heff_field(v_x11_24188, 0);
      heff_take_n(v_x11_24188, 1ULL, 1);
      V v_x_24192 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24191, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24187_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24192}), v_st_24189});
    }
    default: return heff_nomatch(v_x11_24188);
    }
  }
  default: return heff_nomatch(v_x1_24187);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam16(V self, V *args) {
  V v_st_24197 = args[0];
  V v_m_24196 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24198 = heff_tr(heff_call(v_m_24196, 1, (V[]){v_st_24197}));
  switch (heff_tag_of(v_x1_24198)) {
  case TAG_MkPair: {
    V v_x11_24199 = heff_field(v_x1_24198, 0);
    V v_st_24200 = heff_field(v_x1_24198, 1);
    V v_ru_24x1_24198_24MkPair = heff_take_reuse_n(v_x1_24198, 3ULL, 2);
    switch (heff_tag_of(v_x11_24199)) {
    case TAG_Left: {
      V v_e_24201 = heff_field(v_x11_24199, 0);
      heff_take_n(v_x11_24199, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24198_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24201}), v_st_24200});
    }
    case TAG_Right: {
      V v_x_24202 = heff_field(v_x11_24199, 0);
      heff_take_n(v_x11_24199, 1ULL, 1);
      V v_x_24203 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24202, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24198_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24203}), v_st_24200});
    }
    default: return heff_nomatch(v_x11_24199);
    }
  }
  default: return heff_nomatch(v_x1_24198);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam17(V self, V *args) {
  V v_st_24207 = args[0];
  V v_m_24206 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24208 = heff_tr(heff_call(v_m_24206, 1, (V[]){v_st_24207}));
  switch (heff_tag_of(v_x1_24208)) {
  case TAG_MkPair: {
    V v_x11_24209 = heff_field(v_x1_24208, 0);
    V v_st_24210 = heff_field(v_x1_24208, 1);
    V v_ru_24x1_24208_24MkPair = heff_take_reuse_n(v_x1_24208, 3ULL, 2);
    switch (heff_tag_of(v_x11_24209)) {
    case TAG_Left: {
      V v_e_24211 = heff_field(v_x11_24209, 0);
      heff_take_n(v_x11_24209, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24211}), v_st_24210});
    }
    case TAG_Right: {
      V v_x_24212 = heff_field(v_x11_24209, 0);
      heff_take_n(v_x11_24209, 1ULL, 1);
      V v_x_24213 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24212, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24213}), v_st_24210});
    }
    default: return heff_nomatch(v_x11_24209);
    }
  }
  default: return heff_nomatch(v_x1_24208);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam18(V self, V *args) {
  V v_st_24217 = args[0];
  V v_m_24216 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24218 = heff_tr(heff_call(v_m_24216, 1, (V[]){v_st_24217}));
  switch (heff_tag_of(v_x1_24218)) {
  case TAG_MkPair: {
    V v_x11_24219 = heff_field(v_x1_24218, 0);
    V v_st_24220 = heff_field(v_x1_24218, 1);
    V v_ru_24x1_24218_24MkPair = heff_take_reuse_n(v_x1_24218, 3ULL, 2);
    switch (heff_tag_of(v_x11_24219)) {
    case TAG_Left: {
      V v_e_24221 = heff_field(v_x11_24219, 0);
      heff_take_n(v_x11_24219, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24218_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24221}), v_st_24220});
    }
    case TAG_Right: {
      V v_x_24222 = heff_field(v_x11_24219, 0);
      heff_take_n(v_x11_24219, 1ULL, 1);
      V v_x_24223 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24222, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24218_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24223}), v_st_24220});
    }
    default: return heff_nomatch(v_x11_24219);
    }
  }
  default: return heff_nomatch(v_x1_24218);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam19(V self, V *args) {
  V v_st_24228 = args[0];
  V v_m_24227 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24229 = heff_tr(heff_call(v_m_24227, 1, (V[]){v_st_24228}));
  switch (heff_tag_of(v_x1_24229)) {
  case TAG_MkPair: {
    V v_x11_24230 = heff_field(v_x1_24229, 0);
    V v_st_24231 = heff_field(v_x1_24229, 1);
    V v_ru_24x1_24229_24MkPair = heff_take_reuse_n(v_x1_24229, 3ULL, 2);
    switch (heff_tag_of(v_x11_24230)) {
    case TAG_Left: {
      V v_e_24232 = heff_field(v_x11_24230, 0);
      heff_take_n(v_x11_24230, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24229_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24232}), v_st_24231});
    }
    case TAG_Right: {
      V v_x_24233 = heff_field(v_x11_24230, 0);
      heff_take_n(v_x11_24230, 1ULL, 1);
      V v_x_24234 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24233, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24229_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24234}), v_st_24231});
    }
    default: return heff_nomatch(v_x11_24230);
    }
  }
  default: return heff_nomatch(v_x1_24229);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam20(V self, V *args) {
  V v_st_24237 = args[0];
  V v_m_24236 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24238 = heff_tr(heff_call(v_m_24236, 1, (V[]){v_st_24237}));
  switch (heff_tag_of(v_x1_24238)) {
  case TAG_MkPair: {
    V v_x11_24239 = heff_field(v_x1_24238, 0);
    V v_st_24240 = heff_field(v_x1_24238, 1);
    V v_ru_24x1_24238_24MkPair = heff_take_reuse_n(v_x1_24238, 3ULL, 2);
    switch (heff_tag_of(v_x11_24239)) {
    case TAG_Left: {
      V v_e_24241 = heff_field(v_x11_24239, 0);
      heff_take_n(v_x11_24239, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24241}), v_st_24240});
    }
    case TAG_Right: {
      V v_x_24242 = heff_field(v_x11_24239, 0);
      heff_take_n(v_x11_24239, 1ULL, 1);
      V v_x_24243 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24242, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24243}), v_st_24240});
    }
    default: return heff_nomatch(v_x11_24239);
    }
  }
  default: return heff_nomatch(v_x1_24238);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam21(V self, V *args) {
  V v_st_24248 = args[0];
  V v_m_24247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24249 = heff_tr(heff_call(v_m_24247, 1, (V[]){v_st_24248}));
  switch (heff_tag_of(v_x1_24249)) {
  case TAG_MkPair: {
    V v_x11_24250 = heff_field(v_x1_24249, 0);
    V v_st_24251 = heff_field(v_x1_24249, 1);
    V v_ru_24x1_24249_24MkPair = heff_take_reuse_n(v_x1_24249, 3ULL, 2);
    switch (heff_tag_of(v_x11_24250)) {
    case TAG_Left: {
      V v_e_24252 = heff_field(v_x11_24250, 0);
      heff_take_n(v_x11_24250, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24252}), v_st_24251});
    }
    case TAG_Right: {
      V v_x_24253 = heff_field(v_x11_24250, 0);
      heff_take_n(v_x11_24250, 1ULL, 1);
      V v_x_24254 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24253, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24254}), v_st_24251});
    }
    default: return heff_nomatch(v_x11_24250);
    }
  }
  default: return heff_nomatch(v_x1_24249);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam22(V self, V *args) {
  V v_st_24261 = args[0];
  V v_m_24260 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24262 = heff_tr(heff_call(v_m_24260, 1, (V[]){v_st_24261}));
  switch (heff_tag_of(v_x1_24262)) {
  case TAG_MkPair: {
    V v_x11_24263 = heff_field(v_x1_24262, 0);
    V v_st_24264 = heff_field(v_x1_24262, 1);
    V v_ru_24x1_24262_24MkPair = heff_take_reuse_n(v_x1_24262, 3ULL, 2);
    switch (heff_tag_of(v_x11_24263)) {
    case TAG_Left: {
      V v_e_24265 = heff_field(v_x11_24263, 0);
      heff_take_n(v_x11_24263, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24262_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24265}), v_st_24264});
    }
    case TAG_Right: {
      V v_x_24266 = heff_field(v_x11_24263, 0);
      heff_take_n(v_x11_24263, 1ULL, 1);
      V v_x_24267 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24266, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24262_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24267}), v_st_24264});
    }
    default: return heff_nomatch(v_x11_24263);
    }
  }
  default: return heff_nomatch(v_x1_24262);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam23(V self, V *args) {
  V v_st_24273 = args[0];
  V v_m_24272 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24274 = heff_tr(heff_call(v_m_24272, 1, (V[]){v_st_24273}));
  switch (heff_tag_of(v_x1_24274)) {
  case TAG_MkPair: {
    V v_x11_24275 = heff_field(v_x1_24274, 0);
    V v_st_24276 = heff_field(v_x1_24274, 1);
    V v_ru_24x1_24274_24MkPair = heff_take_reuse_n(v_x1_24274, 3ULL, 2);
    switch (heff_tag_of(v_x11_24275)) {
    case TAG_Left: {
      V v_e_24277 = heff_field(v_x11_24275, 0);
      heff_take_n(v_x11_24275, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24274_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24277}), v_st_24276});
    }
    case TAG_Right: {
      V v_x_24278 = heff_field(v_x11_24275, 0);
      heff_take_n(v_x11_24275, 1ULL, 1);
      V v_x_24279 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24278, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24274_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24279}), v_st_24276});
    }
    default: return heff_nomatch(v_x11_24275);
    }
  }
  default: return heff_nomatch(v_x1_24274);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam24(V self, V *args) {
  V v_st_24285 = args[0];
  V v_m_24284 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24286 = heff_tr(heff_call(v_m_24284, 1, (V[]){v_st_24285}));
  switch (heff_tag_of(v_x1_24286)) {
  case TAG_MkPair: {
    V v_x11_24287 = heff_field(v_x1_24286, 0);
    V v_st_24288 = heff_field(v_x1_24286, 1);
    V v_ru_24x1_24286_24MkPair = heff_take_reuse_n(v_x1_24286, 3ULL, 2);
    switch (heff_tag_of(v_x11_24287)) {
    case TAG_Left: {
      V v_e_24289 = heff_field(v_x11_24287, 0);
      heff_take_n(v_x11_24287, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24286_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24289}), v_st_24288});
    }
    case TAG_Right: {
      V v_x_24290 = heff_field(v_x11_24287, 0);
      heff_take_n(v_x11_24287, 1ULL, 1);
      V v_x_24291 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24290, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24286_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24291}), v_st_24288});
    }
    default: return heff_nomatch(v_x11_24287);
    }
  }
  default: return heff_nomatch(v_x1_24286);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam25(V self, V *args) {
  V v_st_24296 = args[0];
  V v_m_24295 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24297 = heff_tr(heff_call(v_m_24295, 1, (V[]){v_st_24296}));
  switch (heff_tag_of(v_x1_24297)) {
  case TAG_MkPair: {
    V v_x11_24298 = heff_field(v_x1_24297, 0);
    V v_st_24299 = heff_field(v_x1_24297, 1);
    V v_ru_24x1_24297_24MkPair = heff_take_reuse_n(v_x1_24297, 3ULL, 2);
    switch (heff_tag_of(v_x11_24298)) {
    case TAG_Left: {
      V v_e_24300 = heff_field(v_x11_24298, 0);
      heff_take_n(v_x11_24298, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24297_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24300}), v_st_24299});
    }
    case TAG_Right: {
      V v_x_24301 = heff_field(v_x11_24298, 0);
      heff_take_n(v_x11_24298, 1ULL, 1);
      V v_x_24302 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24301, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24297_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24302}), v_st_24299});
    }
    default: return heff_nomatch(v_x11_24298);
    }
  }
  default: return heff_nomatch(v_x1_24297);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam26(V self, V *args) {
  V v_st_24310 = args[0];
  V v_m_24309 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24311 = heff_tr(heff_call(v_m_24309, 1, (V[]){v_st_24310}));
  switch (heff_tag_of(v_x1_24311)) {
  case TAG_MkPair: {
    V v_x11_24312 = heff_field(v_x1_24311, 0);
    V v_st_24313 = heff_field(v_x1_24311, 1);
    V v_ru_24x1_24311_24MkPair = heff_take_reuse_n(v_x1_24311, 3ULL, 2);
    switch (heff_tag_of(v_x11_24312)) {
    case TAG_Left: {
      V v_e_24314 = heff_field(v_x11_24312, 0);
      heff_take_n(v_x11_24312, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24311_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24314}), v_st_24313});
    }
    case TAG_Right: {
      V v_x_24315 = heff_field(v_x11_24312, 0);
      heff_take_n(v_x11_24312, 1ULL, 1);
      V v_x_24316 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24315, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24311_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24316}), v_st_24313});
    }
    default: return heff_nomatch(v_x11_24312);
    }
  }
  default: return heff_nomatch(v_x1_24311);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam27(V self, V *args) {
  V v_st_24320 = args[0];
  V v_m_24319 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24321 = heff_tr(heff_call(v_m_24319, 1, (V[]){v_st_24320}));
  switch (heff_tag_of(v_x1_24321)) {
  case TAG_MkPair: {
    V v_x11_24322 = heff_field(v_x1_24321, 0);
    V v_st_24323 = heff_field(v_x1_24321, 1);
    V v_ru_24x1_24321_24MkPair = heff_take_reuse_n(v_x1_24321, 3ULL, 2);
    switch (heff_tag_of(v_x11_24322)) {
    case TAG_Left: {
      V v_e_24324 = heff_field(v_x11_24322, 0);
      heff_take_n(v_x11_24322, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24321_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24324}), v_st_24323});
    }
    case TAG_Right: {
      V v_x_24325 = heff_field(v_x11_24322, 0);
      heff_take_n(v_x11_24322, 1ULL, 1);
      V v_x_24326 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24325, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24321_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24326}), v_st_24323});
    }
    default: return heff_nomatch(v_x11_24322);
    }
  }
  default: return heff_nomatch(v_x1_24321);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam28(V self, V *args) {
  V v_st_24331 = args[0];
  V v_m_24330 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24332 = heff_tr(heff_call(v_m_24330, 1, (V[]){v_st_24331}));
  switch (heff_tag_of(v_x1_24332)) {
  case TAG_MkPair: {
    V v_x11_24333 = heff_field(v_x1_24332, 0);
    V v_st_24334 = heff_field(v_x1_24332, 1);
    V v_ru_24x1_24332_24MkPair = heff_take_reuse_n(v_x1_24332, 3ULL, 2);
    switch (heff_tag_of(v_x11_24333)) {
    case TAG_Left: {
      V v_e_24335 = heff_field(v_x11_24333, 0);
      heff_take_n(v_x11_24333, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24332_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24335}), v_st_24334});
    }
    case TAG_Right: {
      V v_x_24336 = heff_field(v_x11_24333, 0);
      heff_take_n(v_x11_24333, 1ULL, 1);
      V v_x_24337 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24336, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24332_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24337}), v_st_24334});
    }
    default: return heff_nomatch(v_x11_24333);
    }
  }
  default: return heff_nomatch(v_x1_24332);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam29(V self, V *args) {
  V v_st_24345 = args[0];
  V v_m_24344 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24346 = heff_tr(heff_call(v_m_24344, 1, (V[]){v_st_24345}));
  switch (heff_tag_of(v_x1_24346)) {
  case TAG_MkPair: {
    V v_x11_24347 = heff_field(v_x1_24346, 0);
    V v_st_24348 = heff_field(v_x1_24346, 1);
    V v_ru_24x1_24346_24MkPair = heff_take_reuse_n(v_x1_24346, 3ULL, 2);
    switch (heff_tag_of(v_x11_24347)) {
    case TAG_Left: {
      V v_e_24349 = heff_field(v_x11_24347, 0);
      heff_take_n(v_x11_24347, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24346_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24349}), v_st_24348});
    }
    case TAG_Right: {
      V v_x_24350 = heff_field(v_x11_24347, 0);
      heff_take_n(v_x11_24347, 1ULL, 1);
      V v_x_24351 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24350, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24346_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24351}), v_st_24348});
    }
    default: return heff_nomatch(v_x11_24347);
    }
  }
  default: return heff_nomatch(v_x1_24346);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam30(V self, V *args) {
  V v_st_24359 = args[0];
  V v_m_24358 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24360 = heff_tr(heff_call(v_m_24358, 1, (V[]){v_st_24359}));
  switch (heff_tag_of(v_x1_24360)) {
  case TAG_MkPair: {
    V v_x11_24361 = heff_field(v_x1_24360, 0);
    V v_st_24362 = heff_field(v_x1_24360, 1);
    V v_ru_24x1_24360_24MkPair = heff_take_reuse_n(v_x1_24360, 3ULL, 2);
    switch (heff_tag_of(v_x11_24361)) {
    case TAG_Left: {
      V v_e_24363 = heff_field(v_x11_24361, 0);
      heff_take_n(v_x11_24361, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24360_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24363}), v_st_24362});
    }
    case TAG_Right: {
      V v_x_24364 = heff_field(v_x11_24361, 0);
      heff_take_n(v_x11_24361, 1ULL, 1);
      V v_x_24365 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24364, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24360_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24365}), v_st_24362});
    }
    default: return heff_nomatch(v_x11_24361);
    }
  }
  default: return heff_nomatch(v_x1_24360);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam31(V self, V *args) {
  V v_st_24370 = args[0];
  V v_m_24369 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24371 = heff_tr(heff_call(v_m_24369, 1, (V[]){v_st_24370}));
  switch (heff_tag_of(v_x1_24371)) {
  case TAG_MkPair: {
    V v_x11_24372 = heff_field(v_x1_24371, 0);
    V v_st_24373 = heff_field(v_x1_24371, 1);
    V v_ru_24x1_24371_24MkPair = heff_take_reuse_n(v_x1_24371, 3ULL, 2);
    switch (heff_tag_of(v_x11_24372)) {
    case TAG_Left: {
      V v_e_24374 = heff_field(v_x11_24372, 0);
      heff_take_n(v_x11_24372, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24371_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24374}), v_st_24373});
    }
    case TAG_Right: {
      V v_x_24375 = heff_field(v_x11_24372, 0);
      heff_take_n(v_x11_24372, 1ULL, 1);
      V v_x_24376 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24375, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24371_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24376}), v_st_24373});
    }
    default: return heff_nomatch(v_x11_24372);
    }
  }
  default: return heff_nomatch(v_x1_24371);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam32(V self, V *args) {
  V v_st_24382 = args[0];
  V v_m_24381 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24383 = heff_tr(heff_call(v_m_24381, 1, (V[]){v_st_24382}));
  switch (heff_tag_of(v_x1_24383)) {
  case TAG_MkPair: {
    V v_x11_24384 = heff_field(v_x1_24383, 0);
    V v_st_24385 = heff_field(v_x1_24383, 1);
    V v_ru_24x1_24383_24MkPair = heff_take_reuse_n(v_x1_24383, 3ULL, 2);
    switch (heff_tag_of(v_x11_24384)) {
    case TAG_Left: {
      V v_e_24386 = heff_field(v_x11_24384, 0);
      heff_take_n(v_x11_24384, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24383_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24386}), v_st_24385});
    }
    case TAG_Right: {
      V v_x_24387 = heff_field(v_x11_24384, 0);
      heff_take_n(v_x11_24384, 1ULL, 1);
      V v_x_24388 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24387, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24383_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24388}), v_st_24385});
    }
    default: return heff_nomatch(v_x11_24384);
    }
  }
  default: return heff_nomatch(v_x1_24383);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam33(V self, V *args) {
  V v_st_24396 = args[0];
  V v_m_24395 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24397 = heff_tr(heff_call(v_m_24395, 1, (V[]){v_st_24396}));
  switch (heff_tag_of(v_x1_24397)) {
  case TAG_MkPair: {
    V v_x11_24398 = heff_field(v_x1_24397, 0);
    V v_st_24399 = heff_field(v_x1_24397, 1);
    V v_ru_24x1_24397_24MkPair = heff_take_reuse_n(v_x1_24397, 3ULL, 2);
    switch (heff_tag_of(v_x11_24398)) {
    case TAG_Left: {
      V v_e_24400 = heff_field(v_x11_24398, 0);
      heff_take_n(v_x11_24398, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24397_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24400}), v_st_24399});
    }
    case TAG_Right: {
      V v_x_24401 = heff_field(v_x11_24398, 0);
      heff_take_n(v_x11_24398, 1ULL, 1);
      V v_x_24402 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24401, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24397_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24402}), v_st_24399});
    }
    default: return heff_nomatch(v_x11_24398);
    }
  }
  default: return heff_nomatch(v_x1_24397);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam34(V self, V *args) {
  V v_st_24405 = args[0];
  V v_m_24404 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24406 = heff_tr(heff_call(v_m_24404, 1, (V[]){v_st_24405}));
  switch (heff_tag_of(v_x1_24406)) {
  case TAG_MkPair: {
    V v_x11_24407 = heff_field(v_x1_24406, 0);
    V v_st_24408 = heff_field(v_x1_24406, 1);
    V v_ru_24x1_24406_24MkPair = heff_take_reuse_n(v_x1_24406, 3ULL, 2);
    switch (heff_tag_of(v_x11_24407)) {
    case TAG_Left: {
      V v_e_24409 = heff_field(v_x11_24407, 0);
      heff_take_n(v_x11_24407, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24406_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24409}), v_st_24408});
    }
    case TAG_Right: {
      V v_x_24410 = heff_field(v_x11_24407, 0);
      heff_take_n(v_x11_24407, 1ULL, 1);
      V v_x_24411 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24410, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24406_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24411}), v_st_24408});
    }
    default: return heff_nomatch(v_x11_24407);
    }
  }
  default: return heff_nomatch(v_x1_24406);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam35(V self, V *args) {
  V v_st_24415 = args[0];
  V v_m_24414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24416 = heff_tr(heff_call(v_m_24414, 1, (V[]){v_st_24415}));
  switch (heff_tag_of(v_x1_24416)) {
  case TAG_MkPair: {
    V v_x11_24417 = heff_field(v_x1_24416, 0);
    V v_st_24418 = heff_field(v_x1_24416, 1);
    V v_ru_24x1_24416_24MkPair = heff_take_reuse_n(v_x1_24416, 3ULL, 2);
    switch (heff_tag_of(v_x11_24417)) {
    case TAG_Left: {
      V v_e_24419 = heff_field(v_x11_24417, 0);
      heff_take_n(v_x11_24417, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24419}), v_st_24418});
    }
    case TAG_Right: {
      V v_x_24420 = heff_field(v_x11_24417, 0);
      heff_take_n(v_x11_24417, 1ULL, 1);
      V v_x_24421 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24420, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24421}), v_st_24418});
    }
    default: return heff_nomatch(v_x11_24417);
    }
  }
  default: return heff_nomatch(v_x1_24416);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam36(V self, V *args) {
  V v_st_24427 = args[0];
  V v_m_24426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24428 = heff_tr(heff_call(v_m_24426, 1, (V[]){v_st_24427}));
  switch (heff_tag_of(v_x1_24428)) {
  case TAG_MkPair: {
    V v_x11_24429 = heff_field(v_x1_24428, 0);
    V v_st_24430 = heff_field(v_x1_24428, 1);
    V v_ru_24x1_24428_24MkPair = heff_take_reuse_n(v_x1_24428, 3ULL, 2);
    switch (heff_tag_of(v_x11_24429)) {
    case TAG_Left: {
      V v_e_24431 = heff_field(v_x11_24429, 0);
      heff_take_n(v_x11_24429, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24431}), v_st_24430});
    }
    case TAG_Right: {
      V v_x_24432 = heff_field(v_x11_24429, 0);
      heff_take_n(v_x11_24429, 1ULL, 1);
      V v_x_24433 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24432, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24433}), v_st_24430});
    }
    default: return heff_nomatch(v_x11_24429);
    }
  }
  default: return heff_nomatch(v_x1_24428);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam37(V self, V *args) {
  V v_st_24439 = args[0];
  V v_m_24438 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24440 = heff_tr(heff_call(v_m_24438, 1, (V[]){v_st_24439}));
  switch (heff_tag_of(v_x1_24440)) {
  case TAG_MkPair: {
    V v_x11_24441 = heff_field(v_x1_24440, 0);
    V v_st_24442 = heff_field(v_x1_24440, 1);
    V v_ru_24x1_24440_24MkPair = heff_take_reuse_n(v_x1_24440, 3ULL, 2);
    switch (heff_tag_of(v_x11_24441)) {
    case TAG_Left: {
      V v_e_24443 = heff_field(v_x11_24441, 0);
      heff_take_n(v_x11_24441, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24443}), v_st_24442});
    }
    case TAG_Right: {
      V v_x_24444 = heff_field(v_x11_24441, 0);
      heff_take_n(v_x11_24441, 1ULL, 1);
      V v_x_24445 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24444, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24445}), v_st_24442});
    }
    default: return heff_nomatch(v_x11_24441);
    }
  }
  default: return heff_nomatch(v_x1_24440);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam38(V self, V *args) {
  V v_st_24451 = args[0];
  V v_m_24450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24452 = heff_tr(heff_call(v_m_24450, 1, (V[]){v_st_24451}));
  switch (heff_tag_of(v_x1_24452)) {
  case TAG_MkPair: {
    V v_x11_24453 = heff_field(v_x1_24452, 0);
    V v_st_24454 = heff_field(v_x1_24452, 1);
    V v_ru_24x1_24452_24MkPair = heff_take_reuse_n(v_x1_24452, 3ULL, 2);
    switch (heff_tag_of(v_x11_24453)) {
    case TAG_Left: {
      V v_e_24455 = heff_field(v_x11_24453, 0);
      heff_take_n(v_x11_24453, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24455}), v_st_24454});
    }
    case TAG_Right: {
      V v_x_24456 = heff_field(v_x11_24453, 0);
      heff_take_n(v_x11_24453, 1ULL, 1);
      V v_x_24457 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24456, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24457}), v_st_24454});
    }
    default: return heff_nomatch(v_x11_24453);
    }
  }
  default: return heff_nomatch(v_x1_24452);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam39(V self, V *args) {
  V v_st_24463 = args[0];
  V v_m_24462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24464 = heff_tr(heff_call(v_m_24462, 1, (V[]){v_st_24463}));
  switch (heff_tag_of(v_x1_24464)) {
  case TAG_MkPair: {
    V v_x11_24465 = heff_field(v_x1_24464, 0);
    V v_st_24466 = heff_field(v_x1_24464, 1);
    V v_ru_24x1_24464_24MkPair = heff_take_reuse_n(v_x1_24464, 3ULL, 2);
    switch (heff_tag_of(v_x11_24465)) {
    case TAG_Left: {
      V v_e_24467 = heff_field(v_x11_24465, 0);
      heff_take_n(v_x11_24465, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24467}), v_st_24466});
    }
    case TAG_Right: {
      V v_x_24468 = heff_field(v_x11_24465, 0);
      heff_take_n(v_x11_24465, 1ULL, 1);
      V v_x_24469 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24468, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24469}), v_st_24466});
    }
    default: return heff_nomatch(v_x11_24465);
    }
  }
  default: return heff_nomatch(v_x1_24464);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam40(V self, V *args) {
  V v_st_24475 = args[0];
  V v_m_24474 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24476 = heff_tr(heff_call(v_m_24474, 1, (V[]){v_st_24475}));
  switch (heff_tag_of(v_x1_24476)) {
  case TAG_MkPair: {
    V v_x11_24477 = heff_field(v_x1_24476, 0);
    V v_st_24478 = heff_field(v_x1_24476, 1);
    V v_ru_24x1_24476_24MkPair = heff_take_reuse_n(v_x1_24476, 3ULL, 2);
    switch (heff_tag_of(v_x11_24477)) {
    case TAG_Left: {
      V v_e_24479 = heff_field(v_x11_24477, 0);
      heff_take_n(v_x11_24477, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24479}), v_st_24478});
    }
    case TAG_Right: {
      V v_x_24480 = heff_field(v_x11_24477, 0);
      heff_take_n(v_x11_24477, 1ULL, 1);
      V v_x_24481 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24480, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24481}), v_st_24478});
    }
    default: return heff_nomatch(v_x11_24477);
    }
  }
  default: return heff_nomatch(v_x1_24476);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam41(V self, V *args) {
  V v_st_24489 = args[0];
  V v_m_24488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24490 = heff_tr(heff_call(v_m_24488, 1, (V[]){v_st_24489}));
  switch (heff_tag_of(v_x1_24490)) {
  case TAG_MkPair: {
    V v_x11_24491 = heff_field(v_x1_24490, 0);
    V v_st_24492 = heff_field(v_x1_24490, 1);
    V v_ru_24x1_24490_24MkPair = heff_take_reuse_n(v_x1_24490, 3ULL, 2);
    switch (heff_tag_of(v_x11_24491)) {
    case TAG_Left: {
      V v_e_24493 = heff_field(v_x11_24491, 0);
      heff_take_n(v_x11_24491, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24493}), v_st_24492});
    }
    case TAG_Right: {
      V v_x_24494 = heff_field(v_x11_24491, 0);
      heff_take_n(v_x11_24491, 1ULL, 1);
      V v_x_24495 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24494, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24495}), v_st_24492});
    }
    default: return heff_nomatch(v_x11_24491);
    }
  }
  default: return heff_nomatch(v_x1_24490);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str1, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str3, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str5, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str7, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str9, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str11, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str13, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str18, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str19, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str20, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str21, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str23, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str25, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str27, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str28, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str29, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str30, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str31, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str33, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str35, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str37, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str39, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str40, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str41, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str42, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str43, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str44, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str45, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str46, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str47, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str48, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str49, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str50, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str51, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str52, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str53, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str54, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str55, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str56, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str57, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str58, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str59, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str60, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str61, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str62, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str63, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str64, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str65, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str66, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str67, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str68, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str69, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str70, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str71, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str72, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str73, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str74, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str75, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str76, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str77, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str78, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str79, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str80, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str81, 12, "unexpected `");
V g_heff_2esyntax_2esurface_2ealtL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam42(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ealtL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ealtL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ealtL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Atom: {
    heff_drop_rec(v_r_240, 3);
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_244 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 1); r_; });
    V v_t_245 = heff_strAppend(heff_get_n(v_t_244, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str0));
    V v_msg_246 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str1), v_t_245);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam0, 1, 2, (V[]){v_t_243, v_msg_246});
  }
  case TAG_EParen: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2413 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_2414 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_2415 = heff_strAppend(heff_get_n(v_t_2414, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str2));
    V v_msg_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str3), v_t_2415);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam1, 1, 2, (V[]){v_t_2413, v_msg_2416});
  }
  case TAG_Named: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2425 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_2426 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 5); r_; });
    V v_t_2427 = heff_strAppend(heff_get_n(v_t_2426, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str4));
    V v_msg_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str5), v_t_2427);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam2, 1, 2, (V[]){v_t_2425, v_msg_2428});
  }
  case TAG_Tup: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2436 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_2437 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_2438 = heff_strAppend(heff_get_n(v_t_2437, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str6));
    V v_msg_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str7), v_t_2438);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam3, 1, 2, (V[]){v_t_2436, v_msg_2439});
  }
  case TAG_Seg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2446 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_2447 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_2448 = heff_strAppend(heff_get_n(v_t_2447, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str8));
    V v_msg_2449 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str9), v_t_2448);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam4, 1, 2, (V[]){v_t_2446, v_msg_2449});
  }
  case TAG_Braces: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2457 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_2458 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_2459 = heff_strAppend(heff_get_n(v_t_2458, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str10));
    V v_msg_2460 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str11), v_t_2459);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam5, 1, 2, (V[]){v_t_2457, v_msg_2460});
  }
  case TAG_Update: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2470 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_2471 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_2472 = heff_strAppend(heff_get_n(v_t_2471, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str12));
    V v_msg_2473 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str13), v_t_2472);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam6, 1, 2, (V[]){v_t_2470, v_msg_2473});
  }
  case TAG_EUSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2480 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_2481 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_2482 = heff_strAppend(heff_get_n(v_t_2481, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str14));
    V v_msg_2483 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str15), v_t_2482);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam7, 1, 2, (V[]){v_t_2480, v_msg_2483});
  }
  case TAG_InstB: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2492 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_2493 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 5); r_; });
    V v_t_2494 = heff_strAppend(heff_get_n(v_t_2493, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str16));
    V v_msg_2495 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str17), v_t_2494);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam8, 1, 2, (V[]){v_t_2492, v_msg_2495});
  }
  case TAG_EFSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24102 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24103 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24104 = heff_strAppend(heff_get_n(v_t_24103, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str18));
    V v_msg_24105 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str19), v_t_24104);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam9, 1, 2, (V[]){v_t_24102, v_msg_24105});
  }
  case TAG_EFDefault: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24112 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24113 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24114 = heff_strAppend(heff_get_n(v_t_24113, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str20));
    V v_msg_24115 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str21), v_t_24114);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam10, 1, 2, (V[]){v_t_24112, v_msg_24115});
  }
  case TAG_Sum: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24124 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24125 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 5); r_; });
    V v_t_24126 = heff_strAppend(heff_get_n(v_t_24125, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str22));
    V v_msg_24127 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str23), v_t_24126);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam11, 1, 2, (V[]){v_t_24124, v_msg_24127});
  }
  case TAG_ECon: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24133 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24134 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24135 = heff_strAppend(heff_get_n(v_t_24134, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str24));
    V v_msg_24136 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str25), v_t_24135);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam12, 1, 2, (V[]){v_t_24133, v_msg_24136});
  }
  case TAG_EField: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24142 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24143 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24144 = heff_strAppend(heff_get_n(v_t_24143, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str26));
    V v_msg_24145 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str27), v_t_24144);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam13, 1, 2, (V[]){v_t_24142, v_msg_24145});
  }
  case TAG_ENeg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24151 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24152 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24153 = heff_strAppend(heff_get_n(v_t_24152, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str28));
    V v_msg_24154 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str29), v_t_24153);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam14, 1, 2, (V[]){v_t_24151, v_msg_24154});
  }
  case TAG_App: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24160 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24161 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24162 = heff_strAppend(heff_get_n(v_t_24161, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str30));
    V v_msg_24163 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str31), v_t_24162);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam15, 1, 2, (V[]){v_t_24160, v_msg_24163});
  }
  case TAG_Op: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24170 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24171 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24172 = heff_strAppend(heff_get_n(v_t_24171, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str32));
    V v_msg_24173 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str33), v_t_24172);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam16, 1, 2, (V[]){v_t_24170, v_msg_24173});
  }
  case TAG_Ops: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24179 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24180 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24181 = heff_strAppend(heff_get_n(v_t_24180, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str34));
    V v_msg_24182 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str35), v_t_24181);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam17, 1, 2, (V[]){v_t_24179, v_msg_24182});
  }
  case TAG_OpRhs: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24188 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24189 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24190 = heff_strAppend(heff_get_n(v_t_24189, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str36));
    V v_msg_24191 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str37), v_t_24190);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam18, 1, 2, (V[]){v_t_24188, v_msg_24191});
  }
  case TAG_Ann: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24198 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24199 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24200 = heff_strAppend(heff_get_n(v_t_24199, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str38));
    V v_msg_24201 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str39), v_t_24200);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam19, 1, 2, (V[]){v_t_24198, v_msg_24201});
  }
  case TAG_BVar: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24206 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24207 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 1); r_; });
    V v_t_24208 = heff_strAppend(heff_get_n(v_t_24207, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str40));
    V v_msg_24209 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str41), v_t_24208);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam20, 1, 2, (V[]){v_t_24206, v_msg_24209});
  }
  case TAG_BImp: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24216 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24217 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24218 = heff_strAppend(heff_get_n(v_t_24217, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str42));
    V v_msg_24219 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str43), v_t_24218);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam21, 1, 2, (V[]){v_t_24216, v_msg_24219});
  }
  case TAG_BAnn: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24228 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24229 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 5); r_; });
    V v_t_24230 = heff_strAppend(heff_get_n(v_t_24229, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str44));
    V v_msg_24231 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str45), v_t_24230);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam22, 1, 2, (V[]){v_t_24228, v_msg_24231});
  }
  case TAG_Lam: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24239 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24240 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24241 = heff_strAppend(heff_get_n(v_t_24240, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str46));
    V v_msg_24242 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str47), v_t_24241);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam23, 1, 2, (V[]){v_t_24239, v_msg_24242});
  }
  case TAG_Case: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24250 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24251 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24252 = heff_strAppend(heff_get_n(v_t_24251, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str48));
    V v_msg_24253 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str49), v_t_24252);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam24, 1, 2, (V[]){v_t_24250, v_msg_24253});
  }
  case TAG_EAlt: {
    V v_p_24257 = heff_field(v_x2_241, 0);
    V v_e_24259 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    V v_m_24260 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_p_24257)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam25, 1, 4, (V[]){v_m_24260, v_p_24257, v_r_240, v_e_24259});
  }
  case TAG_If: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24289 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24290 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_24291 = heff_strAppend(heff_get_n(v_t_24290, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str50));
    V v_msg_24292 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str51), v_t_24291);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam27, 1, 2, (V[]){v_t_24289, v_msg_24292});
  }
  case TAG_Do: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24298 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24299 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24300 = heff_strAppend(heff_get_n(v_t_24299, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str52));
    V v_msg_24301 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str53), v_t_24300);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam28, 1, 2, (V[]){v_t_24298, v_msg_24301});
  }
  case TAG_ESBind: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24308 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24309 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24310 = heff_strAppend(heff_get_n(v_t_24309, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str54));
    V v_msg_24311 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str55), v_t_24310);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam29, 1, 2, (V[]){v_t_24308, v_msg_24311});
  }
  case TAG_ELet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24321 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24322 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_24323 = heff_strAppend(heff_get_n(v_t_24322, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str56));
    V v_msg_24324 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str57), v_t_24323);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam30, 1, 2, (V[]){v_t_24321, v_msg_24324});
  }
  case TAG_ELetMut: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24334 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24335 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_24336 = heff_strAppend(heff_get_n(v_t_24335, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str58));
    V v_msg_24337 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str59), v_t_24336);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam31, 1, 2, (V[]){v_t_24334, v_msg_24337});
  }
  case TAG_EAssign: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24344 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24345 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 3); r_; });
    V v_t_24346 = heff_strAppend(heff_get_n(v_t_24345, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str60));
    V v_msg_24347 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str61), v_t_24346);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam32, 1, 2, (V[]){v_t_24344, v_msg_24347});
  }
  case TAG_EWhile: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24355 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24356 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24357 = heff_strAppend(heff_get_n(v_t_24356, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str62));
    V v_msg_24358 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str63), v_t_24357);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam33, 1, 2, (V[]){v_t_24355, v_msg_24358});
  }
  case TAG_EFor: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24368 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24369 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_24370 = heff_strAppend(heff_get_n(v_t_24369, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str64));
    V v_msg_24371 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str65), v_t_24370);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam34, 1, 2, (V[]){v_t_24368, v_msg_24371});
  }
  case TAG_EJump: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24376 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24377 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 1); r_; });
    V v_t_24378 = heff_strAppend(heff_get_n(v_t_24377, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str66));
    V v_msg_24379 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str67), v_t_24378);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam35, 1, 2, (V[]){v_t_24376, v_msg_24379});
  }
  case TAG_EReturn: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24385 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24386 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 2); r_; });
    V v_t_24387 = heff_strAppend(heff_get_n(v_t_24386, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str68));
    V v_msg_24388 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str69), v_t_24387);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam36, 1, 2, (V[]){v_t_24385, v_msg_24388});
  }
  case TAG_ENest: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24396 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24397 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24398 = heff_strAppend(heff_get_n(v_t_24397, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str70));
    V v_msg_24399 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str71), v_t_24398);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam37, 1, 2, (V[]){v_t_24396, v_msg_24399});
  }
  case TAG_IfThen: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24407 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24408 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24409 = heff_strAppend(heff_get_n(v_t_24408, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str72));
    V v_msg_24410 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str73), v_t_24409);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam38, 1, 2, (V[]){v_t_24407, v_msg_24410});
  }
  case TAG_ELetCond: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24418 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24419 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24420 = heff_strAppend(heff_get_n(v_t_24419, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str74));
    V v_msg_24421 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str75), v_t_24420);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam39, 1, 2, (V[]){v_t_24418, v_msg_24421});
  }
  case TAG_ETry: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24429 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24430 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24431 = heff_strAppend(heff_get_n(v_t_24430, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str76));
    V v_msg_24432 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str77), v_t_24431);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam40, 1, 2, (V[]){v_t_24429, v_msg_24432});
  }
  case TAG_ECatch: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24440 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24441 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 4); r_; });
    V v_t_24442 = heff_strAppend(heff_get_n(v_t_24441, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str78));
    V v_msg_24443 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str79), v_t_24442);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam41, 1, 2, (V[]){v_t_24440, v_msg_24443});
  }
  case TAG_EWith: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24453 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_24454 = ({ V a_0 = v_x2_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x2_241, 6); r_; });
    V v_t_24455 = heff_strAppend(heff_get_n(v_t_24454, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str80));
    V v_msg_24456 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str81), v_t_24455);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam42, 1, 2, (V[]){v_t_24453, v_msg_24456});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ealtL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2ealtL_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_t_243 = heff_env(self)[0];
  V v_msg_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_243, 3), heff_get_n(v_t_243, 4, 9)});
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_246, v_t_248, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_249}), v_st_247});
}
V g_heff_2esyntax_2esurface_2ealtL_lam1(V self, V *args) {
  V v_st_2417 = args[0];
  V v_t_2413 = heff_env(self)[0];
  V v_msg_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2413, 3), heff_get_n(v_t_2413, 4, 9)});
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2416, v_t_2418, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2419}), v_st_2417});
}
V g_heff_2esyntax_2esurface_2ealtL_lam2(V self, V *args) {
  V v_st_2429 = args[0];
  V v_t_2425 = heff_env(self)[0];
  V v_msg_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2425, 3), heff_get_n(v_t_2425, 4, 9)});
  V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2428, v_t_2430, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2431}), v_st_2429});
}
V g_heff_2esyntax_2esurface_2ealtL_lam3(V self, V *args) {
  V v_st_2440 = args[0];
  V v_t_2436 = heff_env(self)[0];
  V v_msg_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2441 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2436, 3), heff_get_n(v_t_2436, 4, 9)});
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2439, v_t_2441, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2442}), v_st_2440});
}
V g_heff_2esyntax_2esurface_2ealtL_lam4(V self, V *args) {
  V v_st_2450 = args[0];
  V v_t_2446 = heff_env(self)[0];
  V v_msg_2449 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2446, 3), heff_get_n(v_t_2446, 4, 9)});
  V v_t_2452 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2449, v_t_2451, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2452}), v_st_2450});
}
V g_heff_2esyntax_2esurface_2ealtL_lam5(V self, V *args) {
  V v_st_2461 = args[0];
  V v_t_2457 = heff_env(self)[0];
  V v_msg_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2462 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2457, 3), heff_get_n(v_t_2457, 4, 9)});
  V v_t_2463 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2460, v_t_2462, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2463}), v_st_2461});
}
V g_heff_2esyntax_2esurface_2ealtL_lam6(V self, V *args) {
  V v_st_2474 = args[0];
  V v_t_2470 = heff_env(self)[0];
  V v_msg_2473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2475 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2470, 3), heff_get_n(v_t_2470, 4, 9)});
  V v_t_2476 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2473, v_t_2475, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2476}), v_st_2474});
}
V g_heff_2esyntax_2esurface_2ealtL_lam7(V self, V *args) {
  V v_st_2484 = args[0];
  V v_t_2480 = heff_env(self)[0];
  V v_msg_2483 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2485 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2480, 3), heff_get_n(v_t_2480, 4, 9)});
  V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2483, v_t_2485, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2486}), v_st_2484});
}
V g_heff_2esyntax_2esurface_2ealtL_lam8(V self, V *args) {
  V v_st_2496 = args[0];
  V v_t_2492 = heff_env(self)[0];
  V v_msg_2495 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2497 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2492, 3), heff_get_n(v_t_2492, 4, 9)});
  V v_t_2498 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2495, v_t_2497, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2498}), v_st_2496});
}
V g_heff_2esyntax_2esurface_2ealtL_lam9(V self, V *args) {
  V v_st_24106 = args[0];
  V v_t_24102 = heff_env(self)[0];
  V v_msg_24105 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24107 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24102, 3), heff_get_n(v_t_24102, 4, 9)});
  V v_t_24108 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24105, v_t_24107, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24108}), v_st_24106});
}
V g_heff_2esyntax_2esurface_2ealtL_lam10(V self, V *args) {
  V v_st_24116 = args[0];
  V v_t_24112 = heff_env(self)[0];
  V v_msg_24115 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24117 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24112, 3), heff_get_n(v_t_24112, 4, 9)});
  V v_t_24118 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24115, v_t_24117, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24118}), v_st_24116});
}
V g_heff_2esyntax_2esurface_2ealtL_lam11(V self, V *args) {
  V v_st_24128 = args[0];
  V v_t_24124 = heff_env(self)[0];
  V v_msg_24127 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24129 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24124, 3), heff_get_n(v_t_24124, 4, 9)});
  V v_t_24130 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24127, v_t_24129, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24130}), v_st_24128});
}
V g_heff_2esyntax_2esurface_2ealtL_lam12(V self, V *args) {
  V v_st_24137 = args[0];
  V v_t_24133 = heff_env(self)[0];
  V v_msg_24136 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24138 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24133, 3), heff_get_n(v_t_24133, 4, 9)});
  V v_t_24139 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24136, v_t_24138, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24139}), v_st_24137});
}
V g_heff_2esyntax_2esurface_2ealtL_lam13(V self, V *args) {
  V v_st_24146 = args[0];
  V v_t_24142 = heff_env(self)[0];
  V v_msg_24145 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24147 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24142, 3), heff_get_n(v_t_24142, 4, 9)});
  V v_t_24148 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24145, v_t_24147, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24148}), v_st_24146});
}
V g_heff_2esyntax_2esurface_2ealtL_lam14(V self, V *args) {
  V v_st_24155 = args[0];
  V v_t_24151 = heff_env(self)[0];
  V v_msg_24154 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24156 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24151, 3), heff_get_n(v_t_24151, 4, 9)});
  V v_t_24157 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24154, v_t_24156, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24157}), v_st_24155});
}
V g_heff_2esyntax_2esurface_2ealtL_lam15(V self, V *args) {
  V v_st_24164 = args[0];
  V v_t_24160 = heff_env(self)[0];
  V v_msg_24163 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24165 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24160, 3), heff_get_n(v_t_24160, 4, 9)});
  V v_t_24166 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24163, v_t_24165, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24166}), v_st_24164});
}
V g_heff_2esyntax_2esurface_2ealtL_lam16(V self, V *args) {
  V v_st_24174 = args[0];
  V v_t_24170 = heff_env(self)[0];
  V v_msg_24173 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24175 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24170, 3), heff_get_n(v_t_24170, 4, 9)});
  V v_t_24176 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24173, v_t_24175, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24176}), v_st_24174});
}
V g_heff_2esyntax_2esurface_2ealtL_lam17(V self, V *args) {
  V v_st_24183 = args[0];
  V v_t_24179 = heff_env(self)[0];
  V v_msg_24182 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24184 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24179, 3), heff_get_n(v_t_24179, 4, 9)});
  V v_t_24185 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24182, v_t_24184, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24185}), v_st_24183});
}
V g_heff_2esyntax_2esurface_2ealtL_lam18(V self, V *args) {
  V v_st_24192 = args[0];
  V v_t_24188 = heff_env(self)[0];
  V v_msg_24191 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24193 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24188, 3), heff_get_n(v_t_24188, 4, 9)});
  V v_t_24194 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24191, v_t_24193, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24194}), v_st_24192});
}
V g_heff_2esyntax_2esurface_2ealtL_lam19(V self, V *args) {
  V v_st_24202 = args[0];
  V v_t_24198 = heff_env(self)[0];
  V v_msg_24201 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24203 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24198, 3), heff_get_n(v_t_24198, 4, 9)});
  V v_t_24204 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24201, v_t_24203, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24204}), v_st_24202});
}
V g_heff_2esyntax_2esurface_2ealtL_lam20(V self, V *args) {
  V v_st_24210 = args[0];
  V v_t_24206 = heff_env(self)[0];
  V v_msg_24209 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24211 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24206, 3), heff_get_n(v_t_24206, 4, 9)});
  V v_t_24212 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24209, v_t_24211, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24212}), v_st_24210});
}
V g_heff_2esyntax_2esurface_2ealtL_lam21(V self, V *args) {
  V v_st_24220 = args[0];
  V v_t_24216 = heff_env(self)[0];
  V v_msg_24219 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24221 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24216, 3), heff_get_n(v_t_24216, 4, 9)});
  V v_t_24222 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24219, v_t_24221, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24222}), v_st_24220});
}
V g_heff_2esyntax_2esurface_2ealtL_lam22(V self, V *args) {
  V v_st_24232 = args[0];
  V v_t_24228 = heff_env(self)[0];
  V v_msg_24231 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24233 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24228, 3), heff_get_n(v_t_24228, 4, 9)});
  V v_t_24234 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24231, v_t_24233, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24234}), v_st_24232});
}
V g_heff_2esyntax_2esurface_2ealtL_lam23(V self, V *args) {
  V v_st_24243 = args[0];
  V v_t_24239 = heff_env(self)[0];
  V v_msg_24242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24244 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24239, 3), heff_get_n(v_t_24239, 4, 9)});
  V v_t_24245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24242, v_t_24244, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24245}), v_st_24243});
}
V g_heff_2esyntax_2esurface_2ealtL_lam24(V self, V *args) {
  V v_st_24254 = args[0];
  V v_t_24250 = heff_env(self)[0];
  V v_msg_24253 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24255 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24250, 3), heff_get_n(v_t_24250, 4, 9)});
  V v_t_24256 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24253, v_t_24255, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24256}), v_st_24254});
}
V g_heff_2esyntax_2esurface_2ealtL_lam26(V self, V *args) {
  V v_st_24269 = args[0];
  V v_m_24268 = heff_env(self)[0];
  V v_x_24266 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24270 = heff_tr(heff_call(v_m_24268, 1, (V[]){v_st_24269}));
  switch (heff_tag_of(v_x1_24270)) {
  case TAG_MkPair: {
    V v_x11_24271 = heff_field(v_x1_24270, 0);
    V v_st_24272 = heff_field(v_x1_24270, 1);
    V v_ru_24x1_24270_24MkPair = heff_take_reuse_n(v_x1_24270, 3ULL, 2);
    switch (heff_tag_of(v_x11_24271)) {
    case TAG_Left: {
      V v_e_24273 = heff_field(v_x11_24271, 0);
      heff_take_n(v_x11_24271, 1ULL, 1);
      heff_drop(v_x_24266);
      return heff_tag_at_n(v_ru_24x1_24270_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24273}), v_st_24272});
    }
    case TAG_Right: {
      V v_x_24274 = heff_field(v_x11_24271, 0);
      heff_take_n(v_x11_24271, 1ULL, 1);
      V v_t_24277;
      switch (heff_tag_of(v_x_24266)) {
      case TAG_At: {
        V v_s_24276 = heff_dup(heff_field(v_x_24266, 1));
        v_t_24277 = v_s_24276;
        break;
      }
      default: heff_nomatch(v_x_24266);
      }
      V v_t_24280;
      switch (heff_tag_of(v_x_24274)) {
      case TAG_At: {
        V v_s_24279 = heff_dup(heff_field(v_x_24274, 1));
        v_t_24280 = v_s_24279;
        break;
      }
      default: heff_nomatch(v_x_24274);
      }
      V v_t_24281 = ({ V rv_1 = heff_get_n(v_t_24280, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24277, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_24282 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24266, v_x_24274}), v_t_24281});
      return heff_tag_at_n(v_ru_24x1_24270_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24282}), v_st_24272});
    }
    default: return heff_nomatch(v_x11_24271);
    }
  }
  default: return heff_nomatch(v_x1_24270);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_lam25(V self, V *args) {
  V v_st_24261 = args[0];
  V v_m_24260 = heff_env(self)[0];
  V v_p_24257 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_e_24259 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24262 = heff_tr(heff_call(v_m_24260, 1, (V[]){v_st_24261}));
  switch (heff_tag_of(v_x1_24262)) {
  case TAG_MkPair: {
    V v_x11_24263 = heff_field(v_x1_24262, 0);
    V v_st_24264 = heff_field(v_x1_24262, 1);
    V v_ru_24x1_24262_24MkPair = heff_take_reuse_n(v_x1_24262, 3ULL, 2);
    switch (heff_tag_of(v_x11_24263)) {
    case TAG_Left: {
      V v_e_24265 = heff_field(v_x11_24263, 0);
      heff_take_n(v_x11_24263, 1ULL, 1);
      heff_drop(v_p_24257);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_e_24259);
      return heff_tag_at_n(v_ru_24x1_24262_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24265}), v_st_24264});
    }
    case TAG_Right: {
      V v_x_24266 = heff_field(v_x11_24263, 0);
      heff_take_n(v_x11_24263, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24262_24MkPair, 2);
      V v_t_24267 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_p_24257; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop(v_p_24257); r_; });
      V v_m_24268 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24259}));
      return (g_heff_2esyntax_2esurface_2ewithScope(v_t_24267, heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam26, 1, 2, (V[]){v_m_24268, v_x_24266}), v_st_24264));
    }
    default: return heff_nomatch(v_x11_24263);
    }
  }
  default: return heff_nomatch(v_x1_24262);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_lam27(V self, V *args) {
  V v_st_24293 = args[0];
  V v_t_24289 = heff_env(self)[0];
  V v_msg_24292 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24294 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24289, 3), heff_get_n(v_t_24289, 4, 9)});
  V v_t_24295 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24292, v_t_24294, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24295}), v_st_24293});
}
V g_heff_2esyntax_2esurface_2ealtL_lam28(V self, V *args) {
  V v_st_24302 = args[0];
  V v_t_24298 = heff_env(self)[0];
  V v_msg_24301 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24303 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24298, 3), heff_get_n(v_t_24298, 4, 9)});
  V v_t_24304 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24301, v_t_24303, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24304}), v_st_24302});
}
V g_heff_2esyntax_2esurface_2ealtL_lam29(V self, V *args) {
  V v_st_24312 = args[0];
  V v_t_24308 = heff_env(self)[0];
  V v_msg_24311 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24313 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24308, 3), heff_get_n(v_t_24308, 4, 9)});
  V v_t_24314 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24311, v_t_24313, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24314}), v_st_24312});
}
V g_heff_2esyntax_2esurface_2ealtL_lam30(V self, V *args) {
  V v_st_24325 = args[0];
  V v_t_24321 = heff_env(self)[0];
  V v_msg_24324 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24326 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24321, 3), heff_get_n(v_t_24321, 4, 9)});
  V v_t_24327 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24324, v_t_24326, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24327}), v_st_24325});
}
V g_heff_2esyntax_2esurface_2ealtL_lam31(V self, V *args) {
  V v_st_24338 = args[0];
  V v_t_24334 = heff_env(self)[0];
  V v_msg_24337 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24339 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24334, 3), heff_get_n(v_t_24334, 4, 9)});
  V v_t_24340 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24337, v_t_24339, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24340}), v_st_24338});
}
V g_heff_2esyntax_2esurface_2ealtL_lam32(V self, V *args) {
  V v_st_24348 = args[0];
  V v_t_24344 = heff_env(self)[0];
  V v_msg_24347 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24349 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24344, 3), heff_get_n(v_t_24344, 4, 9)});
  V v_t_24350 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24347, v_t_24349, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24350}), v_st_24348});
}
V g_heff_2esyntax_2esurface_2ealtL_lam33(V self, V *args) {
  V v_st_24359 = args[0];
  V v_t_24355 = heff_env(self)[0];
  V v_msg_24358 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24360 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24355, 3), heff_get_n(v_t_24355, 4, 9)});
  V v_t_24361 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24358, v_t_24360, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24361}), v_st_24359});
}
V g_heff_2esyntax_2esurface_2ealtL_lam34(V self, V *args) {
  V v_st_24372 = args[0];
  V v_t_24368 = heff_env(self)[0];
  V v_msg_24371 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24373 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24368, 3), heff_get_n(v_t_24368, 4, 9)});
  V v_t_24374 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24371, v_t_24373, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24374}), v_st_24372});
}
V g_heff_2esyntax_2esurface_2ealtL_lam35(V self, V *args) {
  V v_st_24380 = args[0];
  V v_t_24376 = heff_env(self)[0];
  V v_msg_24379 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24381 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24376, 3), heff_get_n(v_t_24376, 4, 9)});
  V v_t_24382 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24379, v_t_24381, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24382}), v_st_24380});
}
V g_heff_2esyntax_2esurface_2ealtL_lam36(V self, V *args) {
  V v_st_24389 = args[0];
  V v_t_24385 = heff_env(self)[0];
  V v_msg_24388 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24390 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24385, 3), heff_get_n(v_t_24385, 4, 9)});
  V v_t_24391 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24388, v_t_24390, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24391}), v_st_24389});
}
V g_heff_2esyntax_2esurface_2ealtL_lam37(V self, V *args) {
  V v_st_24400 = args[0];
  V v_t_24396 = heff_env(self)[0];
  V v_msg_24399 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24401 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24396, 3), heff_get_n(v_t_24396, 4, 9)});
  V v_t_24402 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24399, v_t_24401, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24402}), v_st_24400});
}
V g_heff_2esyntax_2esurface_2ealtL_lam38(V self, V *args) {
  V v_st_24411 = args[0];
  V v_t_24407 = heff_env(self)[0];
  V v_msg_24410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24407, 3), heff_get_n(v_t_24407, 4, 9)});
  V v_t_24413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24410, v_t_24412, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24413}), v_st_24411});
}
V g_heff_2esyntax_2esurface_2ealtL_lam39(V self, V *args) {
  V v_st_24422 = args[0];
  V v_t_24418 = heff_env(self)[0];
  V v_msg_24421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24423 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24418, 3), heff_get_n(v_t_24418, 4, 9)});
  V v_t_24424 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24421, v_t_24423, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24424}), v_st_24422});
}
V g_heff_2esyntax_2esurface_2ealtL_lam40(V self, V *args) {
  V v_st_24433 = args[0];
  V v_t_24429 = heff_env(self)[0];
  V v_msg_24432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24434 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24429, 3), heff_get_n(v_t_24429, 4, 9)});
  V v_t_24435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24432, v_t_24434, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24435}), v_st_24433});
}
V g_heff_2esyntax_2esurface_2ealtL_lam41(V self, V *args) {
  V v_st_24444 = args[0];
  V v_t_24440 = heff_env(self)[0];
  V v_msg_24443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24445 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24440, 3), heff_get_n(v_t_24440, 4, 9)});
  V v_t_24446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24443, v_t_24445, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24446}), v_st_24444});
}
V g_heff_2esyntax_2esurface_2ealtL_lam42(V self, V *args) {
  V v_st_24457 = args[0];
  V v_t_24453 = heff_env(self)[0];
  V v_msg_24456 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24458 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24453, 3), heff_get_n(v_t_24453, 4, 9)});
  V v_t_24459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24456, v_t_24458, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24459}), v_st_24457});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str0, 4, "True");
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str1, 4, "True");
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str2, 5, "False");
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str3, 5, "False");
Clo g_heff_2esyntax_2esurface_2eifE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eifE_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eifE(V v_sp_240, V v_c_241, V v_a_242, V v_b_243) {
top: ;
  V v_t_244 = (g_heff_2esyntax_2epresyntax_2eboolOf(v_c_241));
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str0)}), heff_dup(v_sp_240)});
  V v_x1_246 = ({ V a_0 = v_t_245; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_249;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_At: {
    V v_s_248 = heff_field(v_x1_246, 1);
    heff_take_n(v_x1_246, 2ULL, 2);
    v_t_249 = v_s_248;
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  V v_t_2410 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_249, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2411 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str1), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_dup(v_t_2410)}), heff_dup(v_a_242)});
  V v_t_2415;
  switch (heff_tag_of(v_a_242)) {
  case TAG_At: {
    V v_s_2414 = heff_field(v_a_242, 1);
    heff_take_n(v_a_242, 2ULL, 2);
    v_t_2415 = v_s_2414;
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  V v_t_2416 = ({ V rv_1 = heff_get_n(v_t_2415, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2410, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str2)}), heff_dup(v_sp_240)});
  V v_x1_2418 = ({ V a_0 = v_t_2417; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2421;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_At: {
    V v_s_2420 = heff_field(v_x1_2418, 1);
    heff_take_n(v_x1_2418, 2ULL, 2);
    v_t_2421 = v_s_2420;
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  V v_t_2422 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2421, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2423 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str3), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_2424 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, heff_dup(v_t_2422)}), heff_dup(v_b_243)});
  V v_t_2427;
  switch (heff_tag_of(v_b_243)) {
  case TAG_At: {
    V v_s_2426 = heff_field(v_b_243, 1);
    heff_take_n(v_b_243, 2ULL, 2);
    v_t_2427 = v_s_2426;
    break;
  }
  default: heff_nomatch(v_b_243);
  }
  V v_t_2428 = ({ V rv_1 = heff_get_n(v_t_2427, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2422, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_t_2428}), NTAG(TAG_Nil)});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_t_2416}), v_t_2429});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_t_244, v_t_2430}), v_sp_240});
}
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eifE(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2esurface_2eunitIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eunitIn_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eunitIn(V v_ty_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_ty_240)) {
    case TAG_SegmentInteger: {
      return MK_INT(1LL);
    }
    case TAG_SegmentBinary: {
      return MK_INT(8LL);
    }
    case TAG_SegmentBits: {
      return MK_INT(1LL);
    }
    case TAG_SegmentFloat: {
      return MK_INT(1LL);
    }
    case TAG_SegmentUtf: {
      return MK_INT(1LL);
    }
    default: return heff_nomatch(v_ty_240);
    }
  }
  case TAG_Just: {
    V v_u_243 = heff_field(v_x2_241, 0);
    return heff_dup(v_u_243);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eunitIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eunitIn(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str0, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str1, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str2, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str3, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str4, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str5, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str6, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str7, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str8, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str9, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str10, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str11, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str12, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str13, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str14, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str15, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str16, 64, "bits are of no endianness nor sign: `x::bits`, `x::bits-size(3)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str17, 64, "bits are of no endianness nor sign: `x::bits`, `x::bits-size(3)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str18, 43, "a float's segment is of 32 or 64 bits, not ");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str19, 51, "a float's size is a number, 32 or 64: `x::float-32`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str20, 55, "a float is of no sign: `x::float`, `x::float-32-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str21, 36, "UTF-8 is of no endianness: `c::utf8`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str23, 35, "a code point is of no sign: `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str25, 64, "` segment is as long as its code point: it says no size, `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str26, 6, "a `utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str27, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str28, 35, "a code point is of no sign: `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str29, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str30, 64, "` segment is as long as its code point: it says no size, `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str31, 6, "a `utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str33, 35, "a code point is of no sign: `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str35, 64, "` segment is as long as its code point: it says no size, `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str36, 6, "a `utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str37, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str38, 35, "a code point is of no sign: `c::utf");
V g_heff_2esyntax_2esurface_2etypeChecks_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam14(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam14, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam15(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam15, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam16(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam16, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam20(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam20, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam22(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam22, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam29(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etypeChecks_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_entry, 6, 0};

V g_heff_2esyntax_2esurface_2etypeChecks(V v_inPat_240, V v_sp_241, V v_v_242, V v_s_243, V v_x5_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_SegmentInteger: {
    V v_t_2410;
    switch (heff_tag_of(v_x6_245)) {
    case TAG_SizeDefault: {
      v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(8LL)});
      break;
    }
    case TAG_SizeNumber: {
      V v_n_246 = heff_field(v_x6_245, 0);
      V v_ru_24x6_245_24SizeNumber = heff_take_reuse_n(v_x6_245, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x6_245_24SizeNumber, TAG_Just, 1, (V[]){v_n_246});
      break;
    }
    case TAG_SizeName: {
      heff_take_n(v_x6_245, 0ULL, 3);
      v_t_2410 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x6_245);
    }
    return (g_heff_2esyntax_2esurface_2eintegerChecks(v_inPat_240, v_sp_241, v_v_242, v_s_243, v_t_2410));
  }
  case TAG_SegmentBinary: {
    heff_drop(v_x6_245);
    switch (heff_tag_of(v_v_242)) {
    case TAG_StrValue: {
      V v_t_2411 = heff_take_field(v_s_243, 1);
      switch (heff_tag_of(v_t_2411)) {
      case TAG_SizeDefault: {
        V v_t_2412 = heff_take_field(v_s_243, 3);
        switch (heff_tag_of(v_t_2412)) {
        case TAG_Nothing: {
          V v_t_2413 = heff_get_n(v_s_243, 4, 5);
          switch (heff_tag_of(v_t_2413)) {
          case TAG_Nothing: {
            heff_drop(v_sp_241);
            return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam0_clo);
          }
          case TAG_Just: {
            heff_take_n(v_t_2413, 0ULL, 1);
            return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam1, 1, 1, (V[]){v_sp_241});
          }
          default: return heff_nomatch(v_t_2413);
          }
        }
        case TAG_Just: {
          heff_take_n(v_t_2412, 0ULL, 1);
          heff_drop_rec(v_s_243, 5);
          return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam2, 1, 1, (V[]){v_sp_241});
        }
        default: return heff_nomatch(v_t_2412);
        }
      }
      case TAG_SizeNumber: {
        heff_take_n(v_t_2411, 0ULL, 1);
        heff_drop_rec(v_s_243, 5);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam3, 1, 1, (V[]){v_sp_241});
      }
      case TAG_SizeName: {
        heff_take_n(v_t_2411, 0ULL, 3);
        heff_drop_rec(v_s_243, 5);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam4, 1, 1, (V[]){v_sp_241});
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    case TAG_IntValue: {
      heff_take_n(v_v_242, 0ULL, 1);
      V v_t_2431 = heff_dup(heff_rfield(v_s_243, 2));
      V v_t_2433;
      switch (heff_tag_of(v_t_2431)) {
      case TAG_Nothing: {
        v_t_2433 = MK_INT(8LL);
        break;
      }
      case TAG_Just: {
        V v_u_2432 = heff_field(v_t_2431, 0);
        heff_take_n(v_t_2431, 1ULL, 1);
        v_t_2433 = v_u_2432;
        break;
      }
      default: heff_nomatch(v_t_2431);
      }
      if ((heff_unbox_word(heff_intMod(v_t_2433, MK_INT(8LL))) == ((int64_t)0ULL))) {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam5, 1, 2, (V[]){v_s_243, v_sp_241});
      } else {
        heff_drop_rec(v_s_243, 5);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam6, 1, 1, (V[]){v_sp_241});
      }
    }
    case TAG_FloatValue: {
      V v_t_2445 = heff_dup(heff_rfield(v_s_243, 2));
      V v_t_2447;
      switch (heff_tag_of(v_t_2445)) {
      case TAG_Nothing: {
        v_t_2447 = MK_INT(8LL);
        break;
      }
      case TAG_Just: {
        V v_u_2446 = heff_field(v_t_2445, 0);
        heff_take_n(v_t_2445, 1ULL, 1);
        v_t_2447 = v_u_2446;
        break;
      }
      default: heff_nomatch(v_t_2445);
      }
      if ((heff_unbox_word(heff_intMod(v_t_2447, MK_INT(8LL))) == ((int64_t)0ULL))) {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam7, 1, 2, (V[]){v_s_243, v_sp_241});
      } else {
        heff_drop_rec(v_s_243, 5);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam8, 1, 1, (V[]){v_sp_241});
      }
    }
    case TAG_RuneValue: {
      V v_t_2459 = heff_dup(heff_rfield(v_s_243, 2));
      V v_t_2461;
      switch (heff_tag_of(v_t_2459)) {
      case TAG_Nothing: {
        v_t_2461 = MK_INT(8LL);
        break;
      }
      case TAG_Just: {
        V v_u_2460 = heff_field(v_t_2459, 0);
        heff_take_n(v_t_2459, 1ULL, 1);
        v_t_2461 = v_u_2460;
        break;
      }
      default: heff_nomatch(v_t_2459);
      }
      if ((heff_unbox_word(heff_intMod(v_t_2461, MK_INT(8LL))) == ((int64_t)0ULL))) {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam9, 1, 2, (V[]){v_s_243, v_sp_241});
      } else {
        heff_drop_rec(v_s_243, 5);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam10, 1, 1, (V[]){v_sp_241});
      }
    }
    case TAG_OtherValue: {
      V v_t_2473 = heff_dup(heff_rfield(v_s_243, 2));
      V v_t_2475;
      switch (heff_tag_of(v_t_2473)) {
      case TAG_Nothing: {
        v_t_2475 = MK_INT(8LL);
        break;
      }
      case TAG_Just: {
        V v_u_2474 = heff_field(v_t_2473, 0);
        heff_take_n(v_t_2473, 1ULL, 1);
        v_t_2475 = v_u_2474;
        break;
      }
      default: heff_nomatch(v_t_2473);
      }
      if ((heff_unbox_word(heff_intMod(v_t_2475, MK_INT(8LL))) == ((int64_t)0ULL))) {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam11, 1, 2, (V[]){v_s_243, v_sp_241});
      } else {
        heff_drop_rec(v_s_243, 5);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam12, 1, 1, (V[]){v_sp_241});
      }
    }
    default: return heff_nomatch(v_v_242);
    }
  }
  case TAG_SegmentBits: {
    heff_drop(v_v_242);
    heff_drop(v_x6_245);
    return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam13, 1, 2, (V[]){v_s_243, v_sp_241});
  }
  case TAG_SegmentFloat: {
    heff_drop(v_v_242);
    V v_t_2495 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2495)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x6_245)) {
      case TAG_SizeDefault: {
        heff_drop(v_sp_241);
        return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam14_clo);
      }
      case TAG_SizeNumber: {
        V v_x61_2498 = heff_field(v_x6_245, 0);
        heff_take_n(v_x6_245, 1ULL, 1);
        if (heff_intEq_c_lent(v_x61_2498, MK_INT(64LL), 2)) {
          heff_drop(v_sp_241);
          heff_drop(v_x61_2498);
          return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam15_clo);
        } else {
          if (heff_intEq_c_lent(v_x61_2498, MK_INT(32LL), 2)) {
            heff_drop(v_sp_241);
            heff_drop(v_x61_2498);
            return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam16_clo);
          } else {
            return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam17, 1, 2, (V[]){v_x61_2498, v_sp_241});
          }
        }
      }
      case TAG_SizeName: {
        heff_take_n(v_x6_245, 0ULL, 3);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam18, 1, 1, (V[]){v_sp_241});
      }
      default: return heff_nomatch(v_x6_245);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2495, 0ULL, 1);
      heff_drop(v_x6_245);
      return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam19, 1, 1, (V[]){v_sp_241});
    }
    default: return heff_nomatch(v_t_2495);
    }
  }
  case TAG_SegmentUtf: {
    V v_w_24116 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    heff_drop(v_v_242);
    heff_drop(v_x6_245);
    V v_signed_24117 = heff_take_field(v_s_243, 4);
    V v_t_24118 = heff_take_field(v_s_243, 1);
    switch (heff_tag_of(v_t_24118)) {
    case TAG_SizeDefault: {
      V v_t_24119 = heff_take_field(v_s_243, 2);
      switch (heff_tag_of(v_t_24119)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_signed_24117)) {
        case TAG_Nothing: {
          V v_t_24120 = heff_get_n(v_s_243, 3, 5);
          switch (heff_tag_of(v_t_24120)) {
          case TAG_Nothing: {
            heff_drop(v_sp_241);
            heff_drop(v_w_24116);
            return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam20_clo);
          }
          case TAG_Just: {
            heff_take_n(v_t_24120, 0ULL, 1);
            if (heff_intEq_c(v_w_24116, MK_INT(8LL))) {
              return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam21, 1, 1, (V[]){v_sp_241});
            } else {
              heff_drop(v_sp_241);
              return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam22_clo);
            }
          }
          default: return heff_nomatch(v_t_24120);
          }
        }
        case TAG_Just: {
          heff_take_n(v_signed_24117, 0ULL, 1);
          heff_drop_rec(v_s_243, 5);
          return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam23, 1, 2, (V[]){v_w_24116, v_sp_241});
        }
        default: return heff_nomatch(v_signed_24117);
        }
      }
      case TAG_Just: {
        heff_take_n(v_t_24119, 0ULL, 1);
        heff_drop_rec(v_s_243, 5);
        switch (heff_tag_of(v_signed_24117)) {
        case TAG_Nothing: {
          return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam24, 1, 2, (V[]){v_w_24116, v_sp_241});
        }
        case TAG_Just: {
          heff_take_n(v_signed_24117, 0ULL, 1);
          return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam25, 1, 2, (V[]){v_w_24116, v_sp_241});
        }
        default: return heff_nomatch(v_signed_24117);
        }
      }
      default: return heff_nomatch(v_t_24119);
      }
    }
    case TAG_SizeNumber: {
      heff_take_n(v_t_24118, 0ULL, 1);
      heff_drop_rec(v_s_243, 5);
      switch (heff_tag_of(v_signed_24117)) {
      case TAG_Nothing: {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam26, 1, 2, (V[]){v_w_24116, v_sp_241});
      }
      case TAG_Just: {
        heff_take_n(v_signed_24117, 0ULL, 1);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam27, 1, 2, (V[]){v_w_24116, v_sp_241});
      }
      default: return heff_nomatch(v_signed_24117);
      }
    }
    case TAG_SizeName: {
      heff_take_n(v_t_24118, 0ULL, 3);
      heff_drop_rec(v_s_243, 5);
      switch (heff_tag_of(v_signed_24117)) {
      case TAG_Nothing: {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam28, 1, 2, (V[]){v_w_24116, v_sp_241});
      }
      case TAG_Just: {
        heff_take_n(v_signed_24117, 0ULL, 1);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam29, 1, 2, (V[]){v_w_24116, v_sp_241});
      }
      default: return heff_nomatch(v_signed_24117);
      }
    }
    default: return heff_nomatch(v_t_24118);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2etypeChecks(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam0(V self, V *args) {
  V v_st_2414 = args[0];
  V v_t_2415 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_st_2414});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam1(V self, V *args) {
  V v_st_2417 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str0), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2418}), v_st_2417});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam2(V self, V *args) {
  V v_st_2420 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str1), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2421}), v_st_2420});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam3(V self, V *args) {
  V v_st_2423 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str2), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2424}), v_st_2423});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam4(V self, V *args) {
  V v_st_2428 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str3), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2429}), v_st_2428});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam5(V self, V *args) {
  V v_p_2435 = args[0];
  V v_s_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_take_field(v_s_243, 3);
  switch (heff_tag_of(v_t_2436)) {
  case TAG_Nothing: {
    V v_t_2437 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2437)) {
    case TAG_Nothing: {
      heff_drop(v_sp_241);
      V v_t_2438 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2438, v_p_2435});
    }
    case TAG_Just: {
      V v_ru_24t_2437_24Just = heff_take_reuse_n(v_t_2437, 0ULL, 1);
      V v_t_2440 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str4), v_sp_241, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2437_24Just, TAG_Left, 1, (V[]){v_t_2440}), v_p_2435});
    }
    default: return heff_nomatch(v_t_2437);
    }
  }
  case TAG_Just: {
    V v_ru_24t_2436_24Just = heff_take_reuse_n(v_t_2436, 0ULL, 1);
    heff_drop_rec(v_s_243, 5);
    V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str5), v_sp_241, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2436_24Just, TAG_Left, 1, (V[]){v_t_2442}), v_p_2435});
  }
  default: return heff_nomatch(v_t_2436);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam6(V self, V *args) {
  V v_st_2443 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str6), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2444}), v_st_2443});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam7(V self, V *args) {
  V v_p_2449 = args[0];
  V v_s_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_take_field(v_s_243, 3);
  switch (heff_tag_of(v_t_2450)) {
  case TAG_Nothing: {
    V v_t_2451 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2451)) {
    case TAG_Nothing: {
      heff_drop(v_sp_241);
      V v_t_2452 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2452, v_p_2449});
    }
    case TAG_Just: {
      V v_ru_24t_2451_24Just = heff_take_reuse_n(v_t_2451, 0ULL, 1);
      V v_t_2454 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str7), v_sp_241, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2451_24Just, TAG_Left, 1, (V[]){v_t_2454}), v_p_2449});
    }
    default: return heff_nomatch(v_t_2451);
    }
  }
  case TAG_Just: {
    V v_ru_24t_2450_24Just = heff_take_reuse_n(v_t_2450, 0ULL, 1);
    heff_drop_rec(v_s_243, 5);
    V v_t_2456 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str8), v_sp_241, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2450_24Just, TAG_Left, 1, (V[]){v_t_2456}), v_p_2449});
  }
  default: return heff_nomatch(v_t_2450);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam8(V self, V *args) {
  V v_st_2457 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str9), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2458}), v_st_2457});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam9(V self, V *args) {
  V v_p_2463 = args[0];
  V v_s_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2464 = heff_take_field(v_s_243, 3);
  switch (heff_tag_of(v_t_2464)) {
  case TAG_Nothing: {
    V v_t_2465 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2465)) {
    case TAG_Nothing: {
      heff_drop(v_sp_241);
      V v_t_2466 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2466, v_p_2463});
    }
    case TAG_Just: {
      V v_ru_24t_2465_24Just = heff_take_reuse_n(v_t_2465, 0ULL, 1);
      V v_t_2468 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str10), v_sp_241, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2465_24Just, TAG_Left, 1, (V[]){v_t_2468}), v_p_2463});
    }
    default: return heff_nomatch(v_t_2465);
    }
  }
  case TAG_Just: {
    V v_ru_24t_2464_24Just = heff_take_reuse_n(v_t_2464, 0ULL, 1);
    heff_drop_rec(v_s_243, 5);
    V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str11), v_sp_241, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2464_24Just, TAG_Left, 1, (V[]){v_t_2470}), v_p_2463});
  }
  default: return heff_nomatch(v_t_2464);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam10(V self, V *args) {
  V v_st_2471 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2472 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str12), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2472}), v_st_2471});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam11(V self, V *args) {
  V v_p_2477 = args[0];
  V v_s_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2478 = heff_take_field(v_s_243, 3);
  switch (heff_tag_of(v_t_2478)) {
  case TAG_Nothing: {
    V v_t_2479 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2479)) {
    case TAG_Nothing: {
      heff_drop(v_sp_241);
      V v_t_2480 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2480, v_p_2477});
    }
    case TAG_Just: {
      V v_ru_24t_2479_24Just = heff_take_reuse_n(v_t_2479, 0ULL, 1);
      V v_t_2482 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str13), v_sp_241, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2479_24Just, TAG_Left, 1, (V[]){v_t_2482}), v_p_2477});
    }
    default: return heff_nomatch(v_t_2479);
    }
  }
  case TAG_Just: {
    V v_ru_24t_2478_24Just = heff_take_reuse_n(v_t_2478, 0ULL, 1);
    heff_drop_rec(v_s_243, 5);
    V v_t_2484 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str14), v_sp_241, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2478_24Just, TAG_Left, 1, (V[]){v_t_2484}), v_p_2477});
  }
  default: return heff_nomatch(v_t_2478);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam12(V self, V *args) {
  V v_st_2485 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str15), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2486}), v_st_2485});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam13(V self, V *args) {
  V v_p_2487 = args[0];
  V v_s_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2488 = heff_take_field(v_s_243, 3);
  switch (heff_tag_of(v_t_2488)) {
  case TAG_Nothing: {
    V v_t_2489 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2489)) {
    case TAG_Nothing: {
      heff_drop(v_sp_241);
      V v_t_2490 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2490, v_p_2487});
    }
    case TAG_Just: {
      V v_ru_24t_2489_24Just = heff_take_reuse_n(v_t_2489, 0ULL, 1);
      V v_t_2492 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str16), v_sp_241, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2489_24Just, TAG_Left, 1, (V[]){v_t_2492}), v_p_2487});
    }
    default: return heff_nomatch(v_t_2489);
    }
  }
  case TAG_Just: {
    V v_ru_24t_2488_24Just = heff_take_reuse_n(v_t_2488, 0ULL, 1);
    heff_drop_rec(v_s_243, 5);
    V v_t_2494 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str17), v_sp_241, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2488_24Just, TAG_Left, 1, (V[]){v_t_2494}), v_p_2487});
  }
  default: return heff_nomatch(v_t_2488);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam14(V self, V *args) {
  V v_st_2496 = args[0];
  V v_t_2497 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2497, v_st_2496});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam15(V self, V *args) {
  V v_st_24100 = args[0];
  V v_t_24101 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24101, v_st_24100});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam16(V self, V *args) {
  V v_st_24103 = args[0];
  V v_t_24104 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24104, v_st_24103});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam17(V self, V *args) {
  V v_st_24105 = args[0];
  V v_x61_2498 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24106 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str18), heff_intShow(v_x61_2498));
  V v_t_24107 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_24106, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24107}), v_st_24105});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam18(V self, V *args) {
  V v_st_24111 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24112 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str19), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24112}), v_st_24111});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam19(V self, V *args) {
  V v_st_24114 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24115 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str20), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24115}), v_st_24114});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam20(V self, V *args) {
  V v_st_24121 = args[0];
  V v_t_24122 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24122, v_st_24121});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam21(V self, V *args) {
  V v_st_24125 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24126 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str21), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24126}), v_st_24125});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam22(V self, V *args) {
  V v_st_24127 = args[0];
  V v_t_24128 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24128, v_st_24127});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam23(V self, V *args) {
  V v_st_24130 = args[0];
  V v_w_24116 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24131 = heff_strAppend(heff_intShow(v_w_24116), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str22));
  V v_t_24132 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str23), v_t_24131), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24132}), v_st_24130});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam24(V self, V *args) {
  V v_st_24134 = args[0];
  V v_w_24116 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24135 = heff_strAppend(heff_intShow(heff_dup(v_w_24116)), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str24));
  V v_t_24136 = heff_strAppend(heff_intShow(v_w_24116), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str25), v_t_24135));
  V v_t_24137 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str26), v_t_24136), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24137}), v_st_24134});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam25(V self, V *args) {
  V v_st_24139 = args[0];
  V v_w_24116 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24140 = heff_strAppend(heff_intShow(v_w_24116), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str27));
  V v_t_24141 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str28), v_t_24140), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24141}), v_st_24139});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam26(V self, V *args) {
  V v_st_24143 = args[0];
  V v_w_24116 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24144 = heff_strAppend(heff_intShow(heff_dup(v_w_24116)), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str29));
  V v_t_24145 = heff_strAppend(heff_intShow(v_w_24116), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str30), v_t_24144));
  V v_t_24146 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str31), v_t_24145), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24146}), v_st_24143});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam27(V self, V *args) {
  V v_st_24148 = args[0];
  V v_w_24116 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24149 = heff_strAppend(heff_intShow(v_w_24116), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str32));
  V v_t_24150 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str33), v_t_24149), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24150}), v_st_24148});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam28(V self, V *args) {
  V v_st_24154 = args[0];
  V v_w_24116 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24155 = heff_strAppend(heff_intShow(heff_dup(v_w_24116)), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str34));
  V v_t_24156 = heff_strAppend(heff_intShow(v_w_24116), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str35), v_t_24155));
  V v_t_24157 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str36), v_t_24156), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24157}), v_st_24154});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam29(V self, V *args) {
  V v_st_24159 = args[0];
  V v_w_24116 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24160 = heff_strAppend(heff_intShow(v_w_24116), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str37));
  V v_t_24161 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str38), v_t_24160), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24161}), v_st_24159});
}
Clo g_heff_2esyntax_2esurface_2evalueOfE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evalueOfE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2evalueOfE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ETag: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EInt: {
      V v_v_246 = heff_field(v_x11_241, 0);
      return heff_tag_n(TAG_IntValue, 1, (V[]){heff_dup(v_v_246)});
    }
    case TAG_EFloat: {
      return NTAG(TAG_FloatValue);
    }
    case TAG_EString: {
      return NTAG(TAG_StrValue);
    }
    case TAG_EBinary: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ERune: {
      return NTAG(TAG_RuneValue);
    }
    case TAG_EWord: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EApp: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EProject: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ENamed: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EPi: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELam: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EAnn: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ESpec: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ESig: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ESum: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EStruct: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EMatch: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EDo: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELocal: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EAssign: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EWhile: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EFor: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EBreak: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EContinue: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EReturn: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ENest: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EIfLet: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ETry: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EWith: {
      return NTAG(TAG_OtherValue);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2evalueOfE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2evalueOfE(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eparamOf_str0, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
Clo g_heff_2esyntax_2esurface_2eparamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eparamOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eparamOf(V v_p_240, V v_z_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2esurface_2enameAnn_24cpr(heff_dup(v_p_240)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop(v_p_240);
      V v_q_246 = v_field_244;
      V v_t_247 = heff_tag_n(TAG_ExplicitParam, 3, (V[]){heff_take_field(v_q_246, 0), heff_dup(heff_rfield(v_q_246, 1)), heff_dup(heff_rfield(v_q_246, 2))});
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_q_246, 1)), 0, 2);
      V v_t_249 = heff_get_n(v_q_246, 2, 3);
      V v_t_2412;
      switch (heff_tag_of(v_t_249)) {
      case TAG_At: {
        V v_s_2411 = heff_field(v_t_249, 1);
        heff_take_n(v_t_249, 2ULL, 2);
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      V v_t_2413 = ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_nf(v_t_2412, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2414 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_t_2413})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_z_241});
    } else {
      heff_drop(v_field_244);
      V v_t_2417;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2416 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eparamOf_str0), v_t_2417, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2418}), v_z_241});
    }
  }
}
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eparamOf(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edataParamL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edataParamL(V v_r_240, V v_e_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2esurface_2eatomOf_24cpr(heff_dup(v_e_241)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop(v_r_240);
      heff_drop(v_e_241);
      V v_x_246 = v_field_244;
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamL_lam0, 1, 1, (V[]){v_x_246});
    } else {
      heff_drop(v_field_244);
      HEFF_LAST return g_heff_2esyntax_2esurface_2edataParamOf(v_r_240, v_e_241);
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edataParamL_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_246, 3)), heff_dup(heff_rfield(v_x_246, 4))});
  V v_t_249 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_2410 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_246, 3)), heff_dup(heff_rfield(v_x_246, 4))});
  V v_t_2411 = heff_tag_n(TAG_ExplicitParam, 3, (V[]){heff_take_field(v_x_246, 1), v_t_248, heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_t_2410})});
  V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_246, 3), heff_get_n(v_x_246, 4, 9)});
  V v_t_2413 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_t_2412})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_st_247});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str0, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str1, 7, "Mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str2, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str3, 70, "a `mutual` block holds definitions, each a signature and its equations");

HeffT2 g_heff_2esyntax_2esurface_2emutualL_24cpr(V v_r_240, V v_kw_241, V v_ds_242, V v_z_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2esyntax_2esurface_2efirstSig_24cpr(heff_dup(v_ds_242)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_f1_248 = v_field_246;
      HeffT2 v_t_249 = (g_heff_2esyntax_2esurface_2emutualItems_24cpr(v_r_240, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str0), heff_dup(v_f1_248)), heff_dup(v_ds_242), v_z_243));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x11_2412 = v_field_2410;
        V v_st_2413 = v_field_2411;
        switch (heff_tag_of(v_x11_2412)) {
        case TAG_Left: {
          V v_e_2414 = heff_field(v_x11_2412, 0);
          V v_ru_24x11_2412_24Left = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
          heff_drop_rec(v_kw_241, 9);
          heff_drop(v_ds_242);
          heff_drop(v_f1_248);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2412_24Left, TAG_Left, 1, (V[]){v_e_2414}), v_st_2413}});
        }
        case TAG_Right: {
          V v_x_2415 = heff_field(v_x11_2412, 0);
          V v_ru_24x11_2412_24Right = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
          V v_t_2416 = (g_heff_2esyntax_2esurface_2emutualDefs(heff_dup(v_x_2415)));
          V v_t_2417 = (g_list_2emap_24s2081681776x559624592(v_t_2416));
          V v_t_2418 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2417));
          switch (heff_tag_of(v_t_2418)) {
          case TAG_Nil: {
            V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), heff_dup(heff_rfield(v_kw_241, 4))});
            V v_x1_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_242));
            V v_e_2424;
            switch (heff_tag_of(v_x1_2420)) {
            case TAG_Nil: {
              v_e_2424 = heff_dup(heff_rfield(v_kw_241, 4));
              break;
            }
            case TAG_Cons: {
              V v_x_2421 = heff_field(v_x1_2420, 0);
              heff_take_n(v_x1_2420, 1ULL, 2);
              V v_t_2423 = (g_heff_2esyntax_2ecst_2elastD(v_x_2421));
              v_e_2424 = heff_get_n(v_t_2423, 4, 9);
              break;
            }
            default: heff_nomatch(v_x1_2420);
            }
            V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2424});
            V v_t_2426 = (g_heff_2esyntax_2esurface_2emutualDefs(v_x_2415));
            V v_x_2427 = (g_heff_2esyntax_2esurface_2emutualOut(v_t_2419, v_t_2425, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str1), heff_dup(v_f1_248)), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str2), v_f1_248), v_t_2426));
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2412_24Right, TAG_Right, 1, (V[]){v_x_2427}), v_st_2413}});
          }
          case TAG_Cons: {
            V v_d_2428 = heff_field(v_t_2418, 0);
            heff_take_n(v_t_2418, 1ULL, 2);
            heff_drop_rec(v_kw_241, 9);
            heff_drop(v_ds_242);
            heff_drop(v_f1_248);
            heff_drop(v_x_2415);
            heff_drop_cell(v_ru_24x11_2412_24Right, 1);
            return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2428}), v_st_2413}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2418)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2412)}});
        }
      }
    } else {
      heff_drop(v_r_240);
      heff_drop(v_ds_242);
      heff_drop(v_field_246);
      V v_t_2430 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_kw_241, 3), heff_get_n(v_kw_241, 4, 9)});
      V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str3), v_t_2430, NTAG(TAG_Nothing)});
      V v_f_2432 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2431});
      return ((HeffT2){{v_f_2432, v_z_243}});
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str1, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str2, 6, "infixl");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str3, 6, "infixr");

HeffT2 g_heff_2esyntax_2esurface_2efixDeclAt_24cpr(V v_ts_240, V v_k_241, V v_t_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_t_242, 6));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_242, 5)), MK_INT(0LL))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str0))) {
        V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_242, 1))}));
        V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str1), NTAG(TAG_Nil)});
        V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2efixDeclAt_24cpr_str3), v_t_247})});
        V v_t_249 = ({ V a_0 = v_t_246; V a_1 = v_t_248; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_248, 2); r_; });
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_t_249);
          V v_f_2410 = (g_heff_2esyntax_2esurface_2efixDeclOf(v_ts_240, v_k_241, v_t_242));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
        } else {
          heff_drop(v_k_241);
          heff_drop_rec(v_t_242, 7);
          heff_drop(v_t_249);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop(v_k_241);
        heff_drop_rec(v_t_242, 7);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      heff_drop(v_k_241);
      heff_drop_rec(v_t_242, 7);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  } else {
    heff_drop(v_k_241);
    heff_drop_rec(v_t_242, 7);
    heff_drop(v_t_243);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
V g_heff_2esyntax_2esurface_2ereadPlaced_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ereadPlaced_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadPlaced_entry, 5, 0};

V g_heff_2esyntax_2esurface_2ereadPlaced(V v_at_240, V v_lexDiags_241, V v_own_242, V v_r_243, V v_placed_244) {
top: ;
  V v_items_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_placed_244, 0)));
  V v_t_246 = (g_heff_2esyntax_2esurface_2enameSet(heff_rfield(v_r_243, 2)));
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = v_items_245; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2eassembleGo(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_placed_244, 2, 3)));
  V v_items_249 = heff_dup(heff_rfield(v_r_243, 0));
  V v_t_2410 = (g_heff_2esyntax_2esurface_2enameSet(heff_rfield(v_r_243, 2)));
  V v_t_2411 = (g_heff_2esyntax_2esurface_2esigNames(v_items_249));
  V v_t_2412 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_249));
  V v_t_2413 = ({ V a_0 = v_t_2410; V a_1 = v_t_2411; V a_2 = v_t_2412; V a_3 = v_items_249; V r_ = (g_list_2emap_24s2130193383x1335133353(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); heff_drop(v_t_2411); heff_drop(v_t_2412); r_; });
  V v_t_2414 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2413));
  V v_t_2415 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
  V v_d_2419 = (g_list_2efoldl(heff_clo_n(g_heff_2esyntax_2esurface_2ereadPlaced_lam0, 2, 1, (V[]){v_at_240}), v_t_2415, heff_rfield(v_r_243, 0)));
  V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2419, 3, 4)));
  V v_t_2421 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2414, v_t_2420));
  V v_t_2422 = (g_heff_2esyntax_2esurface_2eappendS(v_t_248, v_t_2421));
  V v_t_2423 = (g_heff_2esyntax_2esurface_2eappendS(heff_take_field(v_r_243, 1), v_t_2422));
  V v_t_2424 = (g_heff_2esyntax_2esurface_2eappendS(heff_take_field(v_own_242, 1), v_t_2423));
  V v_t_2425 = (g_heff_2esyntax_2esurface_2eappendS(v_lexDiags_241, v_t_2424));
  return heff_rec_n(4, shape_decls__diags__fixities__broken, (V[]){v_t_247, v_t_2425, heff_get_n(v_own_242, 0, 2), heff_get_n(v_r_243, 2, 3)});
}
V g_heff_2esyntax_2esurface_2ereadPlaced_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereadPlaced(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2ereadPlaced_lam0(V self, V *args) {
  V v_d_2416 = args[0];
  V v_it_2417 = args[1];
  V v_at_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2416, 2)), v_it_2417));
  return ({ V a_0 = v_at_240; V a_1 = v_d_2416; V a_2 = v_t_2418; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
}