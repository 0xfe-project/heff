// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_BadFieldDecl 11244
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclTheory 39552
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_ECon 35052
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_fixities 357800079
#define LBL_items 301884378
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_pat 320285
#define LBL_prims 308293287
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_decls__diags__fixities__broken[] = {LBL_decls, LBL_diags, LBL_fixities, LBL_broken};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24dps_clo;
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
V g_heff_2esyntax_2esurface_2eatomOf(V);
V g_heff_2esyntax_2esurface_2eatomOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomOf_clo;
V g_heff_2esyntax_2esurface_2eblock_24s611148689x133456453(V, V);
V g_heff_2esyntax_2esurface_2eblock_24s611148689x133456453_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_24s611148689x133456453_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2edataParamL(V, V);
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_clo;
V g_heff_2esyntax_2esurface_2edataParamOf(V, V);
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2efieldDeclOf(V, V);
V g_heff_2esyntax_2esurface_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldDeclOf_clo;
V g_heff_2esyntax_2esurface_2efieldL(V, V);
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldL_clo;
V g_heff_2esyntax_2esurface_2eifE(V, V, V, V);
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifE_clo;
V g_heff_2esyntax_2esurface_2enameAnn(V);
V g_heff_2esyntax_2esurface_2enameAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameAnn_clo;
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2ereadPlaced(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadPlaced_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadPlaced_clo;
V g_heff_2esyntax_2esurface_2esettingsOf(V);
V g_heff_2esyntax_2esurface_2esettingsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingsOf_clo;
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2esplitExp(V, V);
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esplitExp_clo;
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_clo;
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(V);
V g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389_clo;
V g_heff_2esyntax_2esurface_2evalueOfE(V);
V g_heff_2esyntax_2esurface_2evalueOfE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evalueOfE_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_map_2eempty_get(void);
Clo g_heff_2esyntax_2esurface_2eappendS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2esyntax_2esurface_2eappendS_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2esplitExp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esplitExp_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esplitExp(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return heff_strLength(v_s_240);
  } else {
    if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(101LL))) {
      heff_drop(v_s_240);
      return v_i_241;
    } else {
      if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(69LL))) {
        heff_drop(v_s_240);
        return v_i_241;
      } else {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esplitExp(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2esettingsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esettingsOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2esettingsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EParen: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Named: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Tup: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Seg: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Braces: {
    V v_x12_2418 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_2418)) {
    case TAG_Nil: {
      return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
    }
    case TAG_Cons: {
      V v_x121_2421 = heff_field(v_x12_2418, 0);
      switch (heff_tag_of(v_x121_2421)) {
      case TAG_Atom: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EParen: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Named: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Tup: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Seg: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Braces: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Update: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EUSet: {
        return NTAG(TAG_Nothing);
      }
      case TAG_InstB: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EFSet: {
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x12_2418)});
      }
      case TAG_EFDefault: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Sum: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ECon: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EField: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ENeg: {
        return NTAG(TAG_Nothing);
      }
      case TAG_App: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Op: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Ops: {
        return NTAG(TAG_Nothing);
      }
      case TAG_OpRhs: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Ann: {
        return NTAG(TAG_Nothing);
      }
      case TAG_BVar: {
        return NTAG(TAG_Nothing);
      }
      case TAG_BImp: {
        return NTAG(TAG_Nothing);
      }
      case TAG_BAnn: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Lam: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Case: {
        return NTAG(TAG_Nothing);
      }
      case TAG_EAlt: {
        return NTAG(TAG_Nothing);
      }
      case TAG_If: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Do: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ESBind: {
        return NTAG(TAG_Nothing);
      }
      case TAG_ELet: {
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x121_2421);
      }
    }
    default: return heff_nomatch(v_x12_2418);
    }
  }
  case TAG_Update: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EUSet: {
    return NTAG(TAG_Nothing);
  }
  case TAG_InstB: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFSet: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Sum: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ECon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EField: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ENeg: {
    return NTAG(TAG_Nothing);
  }
  case TAG_App: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Op: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Ops: {
    return NTAG(TAG_Nothing);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Ann: {
    return NTAG(TAG_Nothing);
  }
  case TAG_BVar: {
    return NTAG(TAG_Nothing);
  }
  case TAG_BImp: {
    return NTAG(TAG_Nothing);
  }
  case TAG_BAnn: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Lam: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Case: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EAlt: {
    return NTAG(TAG_Nothing);
  }
  case TAG_If: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Do: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ESBind: {
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2esettingsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esettingsOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldL_str0, 1, "=");
V g_heff_2esyntax_2esurface_2efieldL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam29(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efieldL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efieldL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efieldL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    V v_m_243 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EParen: {
    V v_m_2414 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam1, 1, 1, (V[]){v_m_2414});
  }
  case TAG_Named: {
    V v_m_2427 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam2, 1, 1, (V[]){v_m_2427});
  }
  case TAG_Tup: {
    V v_m_2439 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam3, 1, 1, (V[]){v_m_2439});
  }
  case TAG_Seg: {
    V v_m_2450 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam4, 1, 1, (V[]){v_m_2450});
  }
  case TAG_Braces: {
    V v_m_2462 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam5, 1, 1, (V[]){v_m_2462});
  }
  case TAG_Update: {
    V v_m_2476 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam6, 1, 1, (V[]){v_m_2476});
  }
  case TAG_EUSet: {
    V v_m_2487 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam7, 1, 1, (V[]){v_m_2487});
  }
  case TAG_InstB: {
    V v_m_24100 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam8, 1, 1, (V[]){v_m_24100});
  }
  case TAG_EFSet: {
    V v_m_24111 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam9, 1, 1, (V[]){v_m_24111});
  }
  case TAG_EFDefault: {
    V v_e1_24119 = heff_field(v_e_241, 0);
    V v_eq_24120 = heff_field(v_e_241, 1);
    V v_d_24121 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_24122 = (g_heff_2esyntax_2esurface_2edeclarationL(heff_dup(v_r_240), v_e1_24119));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam10, 1, 4, (V[]){v_m_24122, v_r_240, v_d_24121, v_eq_24120});
  }
  case TAG_Sum: {
    V v_m_24145 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam11, 1, 1, (V[]){v_m_24145});
  }
  case TAG_ECon: {
    V v_m_24155 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam12, 1, 1, (V[]){v_m_24155});
  }
  case TAG_EField: {
    V v_m_24165 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam13, 1, 1, (V[]){v_m_24165});
  }
  case TAG_ENeg: {
    V v_m_24175 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam14, 1, 1, (V[]){v_m_24175});
  }
  case TAG_App: {
    V v_m_24185 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam15, 1, 1, (V[]){v_m_24185});
  }
  case TAG_Op: {
    V v_m_24196 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam16, 1, 1, (V[]){v_m_24196});
  }
  case TAG_Ops: {
    V v_m_24206 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam17, 1, 1, (V[]){v_m_24206});
  }
  case TAG_OpRhs: {
    V v_m_24216 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam18, 1, 1, (V[]){v_m_24216});
  }
  case TAG_Ann: {
    V v_m_24227 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam19, 1, 1, (V[]){v_m_24227});
  }
  case TAG_BVar: {
    V v_m_24236 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam20, 1, 1, (V[]){v_m_24236});
  }
  case TAG_BImp: {
    V v_m_24247 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam21, 1, 1, (V[]){v_m_24247});
  }
  case TAG_BAnn: {
    V v_m_24260 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam22, 1, 1, (V[]){v_m_24260});
  }
  case TAG_Lam: {
    V v_m_24272 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam23, 1, 1, (V[]){v_m_24272});
  }
  case TAG_Case: {
    V v_m_24284 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam24, 1, 1, (V[]){v_m_24284});
  }
  case TAG_EAlt: {
    V v_m_24295 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam25, 1, 1, (V[]){v_m_24295});
  }
  case TAG_If: {
    V v_m_24309 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam26, 1, 1, (V[]){v_m_24309});
  }
  case TAG_Do: {
    V v_m_24319 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam27, 1, 1, (V[]){v_m_24319});
  }
  case TAG_ESBind: {
    V v_m_24330 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam28, 1, 1, (V[]){v_m_24330});
  }
  case TAG_ELet: {
    V v_m_24344 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam29, 1, 1, (V[]){v_m_24344});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efieldL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2efieldL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      V v_x_2410 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_249, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2410}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam1(V self, V *args) {
  V v_st_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_st_2415}));
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_MkPair: {
    V v_x11_2417 = heff_field(v_x1_2416, 0);
    V v_st_2418 = heff_field(v_x1_2416, 1);
    V v_ru_24x1_2416_24MkPair = heff_take_reuse_n(v_x1_2416, 3ULL, 2);
    switch (heff_tag_of(v_x11_2417)) {
    case TAG_Left: {
      V v_e_2419 = heff_field(v_x11_2417, 0);
      heff_take_n(v_x11_2417, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2419}), v_st_2418});
    }
    case TAG_Right: {
      V v_x_2420 = heff_field(v_x11_2417, 0);
      heff_take_n(v_x11_2417, 1ULL, 1);
      V v_x_2421 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2420, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2421}), v_st_2418});
    }
    default: return heff_nomatch(v_x11_2417);
    }
  }
  default: return heff_nomatch(v_x1_2416);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam2(V self, V *args) {
  V v_st_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_st_2428}));
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_MkPair: {
    V v_x11_2430 = heff_field(v_x1_2429, 0);
    V v_st_2431 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24MkPair = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_Left: {
      V v_e_2432 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2432}), v_st_2431});
    }
    case TAG_Right: {
      V v_x_2433 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      V v_x_2434 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2433, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2434}), v_st_2431});
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_2429);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam3(V self, V *args) {
  V v_st_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_st_2440}));
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_MkPair: {
    V v_x11_2442 = heff_field(v_x1_2441, 0);
    V v_st_2443 = heff_field(v_x1_2441, 1);
    V v_ru_24x1_2441_24MkPair = heff_take_reuse_n(v_x1_2441, 3ULL, 2);
    switch (heff_tag_of(v_x11_2442)) {
    case TAG_Left: {
      V v_e_2444 = heff_field(v_x11_2442, 0);
      heff_take_n(v_x11_2442, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2444}), v_st_2443});
    }
    case TAG_Right: {
      V v_x_2445 = heff_field(v_x11_2442, 0);
      heff_take_n(v_x11_2442, 1ULL, 1);
      V v_x_2446 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2445, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2446}), v_st_2443});
    }
    default: return heff_nomatch(v_x11_2442);
    }
  }
  default: return heff_nomatch(v_x1_2441);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam4(V self, V *args) {
  V v_st_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_st_2451}));
  switch (heff_tag_of(v_x1_2452)) {
  case TAG_MkPair: {
    V v_x11_2453 = heff_field(v_x1_2452, 0);
    V v_st_2454 = heff_field(v_x1_2452, 1);
    V v_ru_24x1_2452_24MkPair = heff_take_reuse_n(v_x1_2452, 3ULL, 2);
    switch (heff_tag_of(v_x11_2453)) {
    case TAG_Left: {
      V v_e_2455 = heff_field(v_x11_2453, 0);
      heff_take_n(v_x11_2453, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2455}), v_st_2454});
    }
    case TAG_Right: {
      V v_x_2456 = heff_field(v_x11_2453, 0);
      heff_take_n(v_x11_2453, 1ULL, 1);
      V v_x_2457 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2456, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2457}), v_st_2454});
    }
    default: return heff_nomatch(v_x11_2453);
    }
  }
  default: return heff_nomatch(v_x1_2452);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam5(V self, V *args) {
  V v_st_2463 = args[0];
  V v_m_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2464 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_st_2463}));
  switch (heff_tag_of(v_x1_2464)) {
  case TAG_MkPair: {
    V v_x11_2465 = heff_field(v_x1_2464, 0);
    V v_st_2466 = heff_field(v_x1_2464, 1);
    V v_ru_24x1_2464_24MkPair = heff_take_reuse_n(v_x1_2464, 3ULL, 2);
    switch (heff_tag_of(v_x11_2465)) {
    case TAG_Left: {
      V v_e_2467 = heff_field(v_x11_2465, 0);
      heff_take_n(v_x11_2465, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2467}), v_st_2466});
    }
    case TAG_Right: {
      V v_x_2468 = heff_field(v_x11_2465, 0);
      heff_take_n(v_x11_2465, 1ULL, 1);
      V v_x_2469 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2468, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2469}), v_st_2466});
    }
    default: return heff_nomatch(v_x11_2465);
    }
  }
  default: return heff_nomatch(v_x1_2464);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam6(V self, V *args) {
  V v_st_2477 = args[0];
  V v_m_2476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2478 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_st_2477}));
  switch (heff_tag_of(v_x1_2478)) {
  case TAG_MkPair: {
    V v_x11_2479 = heff_field(v_x1_2478, 0);
    V v_st_2480 = heff_field(v_x1_2478, 1);
    V v_ru_24x1_2478_24MkPair = heff_take_reuse_n(v_x1_2478, 3ULL, 2);
    switch (heff_tag_of(v_x11_2479)) {
    case TAG_Left: {
      V v_e_2481 = heff_field(v_x11_2479, 0);
      heff_take_n(v_x11_2479, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2481}), v_st_2480});
    }
    case TAG_Right: {
      V v_x_2482 = heff_field(v_x11_2479, 0);
      heff_take_n(v_x11_2479, 1ULL, 1);
      V v_x_2483 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2482, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2483}), v_st_2480});
    }
    default: return heff_nomatch(v_x11_2479);
    }
  }
  default: return heff_nomatch(v_x1_2478);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam7(V self, V *args) {
  V v_st_2488 = args[0];
  V v_m_2487 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2489 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_st_2488}));
  switch (heff_tag_of(v_x1_2489)) {
  case TAG_MkPair: {
    V v_x11_2490 = heff_field(v_x1_2489, 0);
    V v_st_2491 = heff_field(v_x1_2489, 1);
    V v_ru_24x1_2489_24MkPair = heff_take_reuse_n(v_x1_2489, 3ULL, 2);
    switch (heff_tag_of(v_x11_2490)) {
    case TAG_Left: {
      V v_e_2492 = heff_field(v_x11_2490, 0);
      heff_take_n(v_x11_2490, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2492}), v_st_2491});
    }
    case TAG_Right: {
      V v_x_2493 = heff_field(v_x11_2490, 0);
      heff_take_n(v_x11_2490, 1ULL, 1);
      V v_x_2494 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2493, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_2489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2494}), v_st_2491});
    }
    default: return heff_nomatch(v_x11_2490);
    }
  }
  default: return heff_nomatch(v_x1_2489);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam8(V self, V *args) {
  V v_st_24101 = args[0];
  V v_m_24100 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24102 = heff_tr(heff_call(v_m_24100, 1, (V[]){v_st_24101}));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_MkPair: {
    V v_x11_24103 = heff_field(v_x1_24102, 0);
    V v_st_24104 = heff_field(v_x1_24102, 1);
    V v_ru_24x1_24102_24MkPair = heff_take_reuse_n(v_x1_24102, 3ULL, 2);
    switch (heff_tag_of(v_x11_24103)) {
    case TAG_Left: {
      V v_e_24105 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24105}), v_st_24104});
    }
    case TAG_Right: {
      V v_x_24106 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      V v_x_24107 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24106, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24107}), v_st_24104});
    }
    default: return heff_nomatch(v_x11_24103);
    }
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam9(V self, V *args) {
  V v_st_24112 = args[0];
  V v_m_24111 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24113 = heff_tr(heff_call(v_m_24111, 1, (V[]){v_st_24112}));
  switch (heff_tag_of(v_x1_24113)) {
  case TAG_MkPair: {
    V v_x11_24114 = heff_field(v_x1_24113, 0);
    V v_st_24115 = heff_field(v_x1_24113, 1);
    V v_ru_24x1_24113_24MkPair = heff_take_reuse_n(v_x1_24113, 3ULL, 2);
    switch (heff_tag_of(v_x11_24114)) {
    case TAG_Left: {
      V v_e_24116 = heff_field(v_x11_24114, 0);
      heff_take_n(v_x11_24114, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24116}), v_st_24115});
    }
    case TAG_Right: {
      V v_x_24117 = heff_field(v_x11_24114, 0);
      heff_take_n(v_x11_24114, 1ULL, 1);
      V v_x_24118 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24117, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24118}), v_st_24115});
    }
    default: return heff_nomatch(v_x11_24114);
    }
  }
  default: return heff_nomatch(v_x1_24113);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam10(V self, V *args) {
  V v_st_24123 = args[0];
  V v_m_24122 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_d_24121 = heff_env(self)[2];
  V v_eq_24120 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24124 = heff_tr(heff_call(v_m_24122, 1, (V[]){v_st_24123}));
  switch (heff_tag_of(v_x1_24124)) {
  case TAG_MkPair: {
    V v_x11_24125 = heff_field(v_x1_24124, 0);
    V v_st_24126 = heff_field(v_x1_24124, 1);
    V v_ru_24x1_24124_24MkPair = heff_take_reuse_n(v_x1_24124, 3ULL, 2);
    switch (heff_tag_of(v_x11_24125)) {
    case TAG_Left: {
      V v_e_24127 = heff_field(v_x11_24125, 0);
      heff_take_n(v_x11_24125, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_24121);
      heff_drop_rec(v_eq_24120, 9);
      return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24127}), v_st_24126});
    }
    case TAG_Right: {
      V v_x_24128 = heff_field(v_x11_24125, 0);
      V v_ru_24x11_24125_24Right = heff_take_reuse_n(v_x11_24125, 1ULL, 1);
      V v_m_24129 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_24121}));
      V v_x1_24130 = heff_tr(heff_call(v_m_24129, 1, (V[]){v_st_24126}));
      switch (heff_tag_of(v_x1_24130)) {
      case TAG_MkPair: {
        V v_x11_24131 = heff_field(v_x1_24130, 0);
        V v_st_24132 = heff_field(v_x1_24130, 1);
        V v_ru_24x1_24130_24MkPair = heff_take_reuse_n(v_x1_24130, 3ULL, 2);
        switch (heff_tag_of(v_x11_24131)) {
        case TAG_Left: {
          V v_e_24133 = heff_field(v_x11_24131, 0);
          heff_take_n(v_x11_24131, 1ULL, 1);
          heff_drop_rec(v_eq_24120, 9);
          heff_drop(v_x_24128);
          heff_drop_cell(v_ru_24x11_24125_24Right, 1);
          heff_drop_cell(v_ru_24x1_24130_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24133}), v_st_24132});
        }
        case TAG_Right: {
          V v_x_24134 = heff_field(v_x11_24131, 0);
          heff_take_n(v_x11_24131, 1ULL, 1);
          V v_x_24139;
          if (heff_strEq_c(heff_get_n(v_eq_24120, 1, 9), ((V)&g_heff_2esyntax_2esurface_2efieldL_str0))) {
            heff_drop_cell(v_ru_24x1_24130_24MkPair, 2);
            v_x_24139 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24128, heff_tag_at_n(v_ru_24x11_24125_24Right, TAG_Just, 1, (V[]){v_x_24134})));
          } else {
            heff_drop(v_x_24134);
            V v_t_24138;
            switch (heff_tag_of(v_x_24128)) {
            case TAG_At: {
              V v_s_24137 = heff_dup(heff_field(v_x_24128, 1));
              v_t_24138 = v_s_24137;
              break;
            }
            default: heff_nomatch(v_x_24128);
            }
            v_x_24139 = heff_tag_at_n(v_ru_24x1_24130_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24125_24Right, TAG_BadFieldDecl, 1, (V[]){v_x_24128}), v_t_24138});
          }
          return heff_tag_at_n(v_ru_24x1_24124_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24139}), v_st_24132});
        }
        default: return heff_nomatch(v_x11_24131);
        }
      }
      default: return heff_nomatch(v_x1_24130);
      }
    }
    default: return heff_nomatch(v_x11_24125);
    }
  }
  default: return heff_nomatch(v_x1_24124);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam11(V self, V *args) {
  V v_st_24146 = args[0];
  V v_m_24145 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24147 = heff_tr(heff_call(v_m_24145, 1, (V[]){v_st_24146}));
  switch (heff_tag_of(v_x1_24147)) {
  case TAG_MkPair: {
    V v_x11_24148 = heff_field(v_x1_24147, 0);
    V v_st_24149 = heff_field(v_x1_24147, 1);
    V v_ru_24x1_24147_24MkPair = heff_take_reuse_n(v_x1_24147, 3ULL, 2);
    switch (heff_tag_of(v_x11_24148)) {
    case TAG_Left: {
      V v_e_24150 = heff_field(v_x11_24148, 0);
      heff_take_n(v_x11_24148, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24150}), v_st_24149});
    }
    case TAG_Right: {
      V v_x_24151 = heff_field(v_x11_24148, 0);
      heff_take_n(v_x11_24148, 1ULL, 1);
      V v_x_24152 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24151, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24152}), v_st_24149});
    }
    default: return heff_nomatch(v_x11_24148);
    }
  }
  default: return heff_nomatch(v_x1_24147);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam12(V self, V *args) {
  V v_st_24156 = args[0];
  V v_m_24155 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24157 = heff_tr(heff_call(v_m_24155, 1, (V[]){v_st_24156}));
  switch (heff_tag_of(v_x1_24157)) {
  case TAG_MkPair: {
    V v_x11_24158 = heff_field(v_x1_24157, 0);
    V v_st_24159 = heff_field(v_x1_24157, 1);
    V v_ru_24x1_24157_24MkPair = heff_take_reuse_n(v_x1_24157, 3ULL, 2);
    switch (heff_tag_of(v_x11_24158)) {
    case TAG_Left: {
      V v_e_24160 = heff_field(v_x11_24158, 0);
      heff_take_n(v_x11_24158, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24157_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24160}), v_st_24159});
    }
    case TAG_Right: {
      V v_x_24161 = heff_field(v_x11_24158, 0);
      heff_take_n(v_x11_24158, 1ULL, 1);
      V v_x_24162 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24161, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24157_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24162}), v_st_24159});
    }
    default: return heff_nomatch(v_x11_24158);
    }
  }
  default: return heff_nomatch(v_x1_24157);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam13(V self, V *args) {
  V v_st_24166 = args[0];
  V v_m_24165 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24167 = heff_tr(heff_call(v_m_24165, 1, (V[]){v_st_24166}));
  switch (heff_tag_of(v_x1_24167)) {
  case TAG_MkPair: {
    V v_x11_24168 = heff_field(v_x1_24167, 0);
    V v_st_24169 = heff_field(v_x1_24167, 1);
    V v_ru_24x1_24167_24MkPair = heff_take_reuse_n(v_x1_24167, 3ULL, 2);
    switch (heff_tag_of(v_x11_24168)) {
    case TAG_Left: {
      V v_e_24170 = heff_field(v_x11_24168, 0);
      heff_take_n(v_x11_24168, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24167_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24170}), v_st_24169});
    }
    case TAG_Right: {
      V v_x_24171 = heff_field(v_x11_24168, 0);
      heff_take_n(v_x11_24168, 1ULL, 1);
      V v_x_24172 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24171, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24167_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24172}), v_st_24169});
    }
    default: return heff_nomatch(v_x11_24168);
    }
  }
  default: return heff_nomatch(v_x1_24167);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam14(V self, V *args) {
  V v_st_24176 = args[0];
  V v_m_24175 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24177 = heff_tr(heff_call(v_m_24175, 1, (V[]){v_st_24176}));
  switch (heff_tag_of(v_x1_24177)) {
  case TAG_MkPair: {
    V v_x11_24178 = heff_field(v_x1_24177, 0);
    V v_st_24179 = heff_field(v_x1_24177, 1);
    V v_ru_24x1_24177_24MkPair = heff_take_reuse_n(v_x1_24177, 3ULL, 2);
    switch (heff_tag_of(v_x11_24178)) {
    case TAG_Left: {
      V v_e_24180 = heff_field(v_x11_24178, 0);
      heff_take_n(v_x11_24178, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24177_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24180}), v_st_24179});
    }
    case TAG_Right: {
      V v_x_24181 = heff_field(v_x11_24178, 0);
      heff_take_n(v_x11_24178, 1ULL, 1);
      V v_x_24182 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24181, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24177_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24182}), v_st_24179});
    }
    default: return heff_nomatch(v_x11_24178);
    }
  }
  default: return heff_nomatch(v_x1_24177);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam15(V self, V *args) {
  V v_st_24186 = args[0];
  V v_m_24185 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24187 = heff_tr(heff_call(v_m_24185, 1, (V[]){v_st_24186}));
  switch (heff_tag_of(v_x1_24187)) {
  case TAG_MkPair: {
    V v_x11_24188 = heff_field(v_x1_24187, 0);
    V v_st_24189 = heff_field(v_x1_24187, 1);
    V v_ru_24x1_24187_24MkPair = heff_take_reuse_n(v_x1_24187, 3ULL, 2);
    switch (heff_tag_of(v_x11_24188)) {
    case TAG_Left: {
      V v_e_24190 = heff_field(v_x11_24188, 0);
      heff_take_n(v_x11_24188, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24187_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24190}), v_st_24189});
    }
    case TAG_Right: {
      V v_x_24191 = heff_field(v_x11_24188, 0);
      heff_take_n(v_x11_24188, 1ULL, 1);
      V v_x_24192 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24191, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24187_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24192}), v_st_24189});
    }
    default: return heff_nomatch(v_x11_24188);
    }
  }
  default: return heff_nomatch(v_x1_24187);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam16(V self, V *args) {
  V v_st_24197 = args[0];
  V v_m_24196 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24198 = heff_tr(heff_call(v_m_24196, 1, (V[]){v_st_24197}));
  switch (heff_tag_of(v_x1_24198)) {
  case TAG_MkPair: {
    V v_x11_24199 = heff_field(v_x1_24198, 0);
    V v_st_24200 = heff_field(v_x1_24198, 1);
    V v_ru_24x1_24198_24MkPair = heff_take_reuse_n(v_x1_24198, 3ULL, 2);
    switch (heff_tag_of(v_x11_24199)) {
    case TAG_Left: {
      V v_e_24201 = heff_field(v_x11_24199, 0);
      heff_take_n(v_x11_24199, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24198_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24201}), v_st_24200});
    }
    case TAG_Right: {
      V v_x_24202 = heff_field(v_x11_24199, 0);
      heff_take_n(v_x11_24199, 1ULL, 1);
      V v_x_24203 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24202, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24198_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24203}), v_st_24200});
    }
    default: return heff_nomatch(v_x11_24199);
    }
  }
  default: return heff_nomatch(v_x1_24198);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam17(V self, V *args) {
  V v_st_24207 = args[0];
  V v_m_24206 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24208 = heff_tr(heff_call(v_m_24206, 1, (V[]){v_st_24207}));
  switch (heff_tag_of(v_x1_24208)) {
  case TAG_MkPair: {
    V v_x11_24209 = heff_field(v_x1_24208, 0);
    V v_st_24210 = heff_field(v_x1_24208, 1);
    V v_ru_24x1_24208_24MkPair = heff_take_reuse_n(v_x1_24208, 3ULL, 2);
    switch (heff_tag_of(v_x11_24209)) {
    case TAG_Left: {
      V v_e_24211 = heff_field(v_x11_24209, 0);
      heff_take_n(v_x11_24209, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24211}), v_st_24210});
    }
    case TAG_Right: {
      V v_x_24212 = heff_field(v_x11_24209, 0);
      heff_take_n(v_x11_24209, 1ULL, 1);
      V v_x_24213 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24212, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24208_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24213}), v_st_24210});
    }
    default: return heff_nomatch(v_x11_24209);
    }
  }
  default: return heff_nomatch(v_x1_24208);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam18(V self, V *args) {
  V v_st_24217 = args[0];
  V v_m_24216 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24218 = heff_tr(heff_call(v_m_24216, 1, (V[]){v_st_24217}));
  switch (heff_tag_of(v_x1_24218)) {
  case TAG_MkPair: {
    V v_x11_24219 = heff_field(v_x1_24218, 0);
    V v_st_24220 = heff_field(v_x1_24218, 1);
    V v_ru_24x1_24218_24MkPair = heff_take_reuse_n(v_x1_24218, 3ULL, 2);
    switch (heff_tag_of(v_x11_24219)) {
    case TAG_Left: {
      V v_e_24221 = heff_field(v_x11_24219, 0);
      heff_take_n(v_x11_24219, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24218_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24221}), v_st_24220});
    }
    case TAG_Right: {
      V v_x_24222 = heff_field(v_x11_24219, 0);
      heff_take_n(v_x11_24219, 1ULL, 1);
      V v_x_24223 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24222, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24218_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24223}), v_st_24220});
    }
    default: return heff_nomatch(v_x11_24219);
    }
  }
  default: return heff_nomatch(v_x1_24218);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam19(V self, V *args) {
  V v_st_24228 = args[0];
  V v_m_24227 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24229 = heff_tr(heff_call(v_m_24227, 1, (V[]){v_st_24228}));
  switch (heff_tag_of(v_x1_24229)) {
  case TAG_MkPair: {
    V v_x11_24230 = heff_field(v_x1_24229, 0);
    V v_st_24231 = heff_field(v_x1_24229, 1);
    V v_ru_24x1_24229_24MkPair = heff_take_reuse_n(v_x1_24229, 3ULL, 2);
    switch (heff_tag_of(v_x11_24230)) {
    case TAG_Left: {
      V v_e_24232 = heff_field(v_x11_24230, 0);
      heff_take_n(v_x11_24230, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24229_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24232}), v_st_24231});
    }
    case TAG_Right: {
      V v_x_24233 = heff_field(v_x11_24230, 0);
      heff_take_n(v_x11_24230, 1ULL, 1);
      V v_x_24234 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24233, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24229_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24234}), v_st_24231});
    }
    default: return heff_nomatch(v_x11_24230);
    }
  }
  default: return heff_nomatch(v_x1_24229);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam20(V self, V *args) {
  V v_st_24237 = args[0];
  V v_m_24236 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24238 = heff_tr(heff_call(v_m_24236, 1, (V[]){v_st_24237}));
  switch (heff_tag_of(v_x1_24238)) {
  case TAG_MkPair: {
    V v_x11_24239 = heff_field(v_x1_24238, 0);
    V v_st_24240 = heff_field(v_x1_24238, 1);
    V v_ru_24x1_24238_24MkPair = heff_take_reuse_n(v_x1_24238, 3ULL, 2);
    switch (heff_tag_of(v_x11_24239)) {
    case TAG_Left: {
      V v_e_24241 = heff_field(v_x11_24239, 0);
      heff_take_n(v_x11_24239, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24241}), v_st_24240});
    }
    case TAG_Right: {
      V v_x_24242 = heff_field(v_x11_24239, 0);
      heff_take_n(v_x11_24239, 1ULL, 1);
      V v_x_24243 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24242, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24238_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24243}), v_st_24240});
    }
    default: return heff_nomatch(v_x11_24239);
    }
  }
  default: return heff_nomatch(v_x1_24238);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam21(V self, V *args) {
  V v_st_24248 = args[0];
  V v_m_24247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24249 = heff_tr(heff_call(v_m_24247, 1, (V[]){v_st_24248}));
  switch (heff_tag_of(v_x1_24249)) {
  case TAG_MkPair: {
    V v_x11_24250 = heff_field(v_x1_24249, 0);
    V v_st_24251 = heff_field(v_x1_24249, 1);
    V v_ru_24x1_24249_24MkPair = heff_take_reuse_n(v_x1_24249, 3ULL, 2);
    switch (heff_tag_of(v_x11_24250)) {
    case TAG_Left: {
      V v_e_24252 = heff_field(v_x11_24250, 0);
      heff_take_n(v_x11_24250, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24252}), v_st_24251});
    }
    case TAG_Right: {
      V v_x_24253 = heff_field(v_x11_24250, 0);
      heff_take_n(v_x11_24250, 1ULL, 1);
      V v_x_24254 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24253, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24254}), v_st_24251});
    }
    default: return heff_nomatch(v_x11_24250);
    }
  }
  default: return heff_nomatch(v_x1_24249);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam22(V self, V *args) {
  V v_st_24261 = args[0];
  V v_m_24260 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24262 = heff_tr(heff_call(v_m_24260, 1, (V[]){v_st_24261}));
  switch (heff_tag_of(v_x1_24262)) {
  case TAG_MkPair: {
    V v_x11_24263 = heff_field(v_x1_24262, 0);
    V v_st_24264 = heff_field(v_x1_24262, 1);
    V v_ru_24x1_24262_24MkPair = heff_take_reuse_n(v_x1_24262, 3ULL, 2);
    switch (heff_tag_of(v_x11_24263)) {
    case TAG_Left: {
      V v_e_24265 = heff_field(v_x11_24263, 0);
      heff_take_n(v_x11_24263, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24262_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24265}), v_st_24264});
    }
    case TAG_Right: {
      V v_x_24266 = heff_field(v_x11_24263, 0);
      heff_take_n(v_x11_24263, 1ULL, 1);
      V v_x_24267 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24266, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24262_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24267}), v_st_24264});
    }
    default: return heff_nomatch(v_x11_24263);
    }
  }
  default: return heff_nomatch(v_x1_24262);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam23(V self, V *args) {
  V v_st_24273 = args[0];
  V v_m_24272 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24274 = heff_tr(heff_call(v_m_24272, 1, (V[]){v_st_24273}));
  switch (heff_tag_of(v_x1_24274)) {
  case TAG_MkPair: {
    V v_x11_24275 = heff_field(v_x1_24274, 0);
    V v_st_24276 = heff_field(v_x1_24274, 1);
    V v_ru_24x1_24274_24MkPair = heff_take_reuse_n(v_x1_24274, 3ULL, 2);
    switch (heff_tag_of(v_x11_24275)) {
    case TAG_Left: {
      V v_e_24277 = heff_field(v_x11_24275, 0);
      heff_take_n(v_x11_24275, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24274_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24277}), v_st_24276});
    }
    case TAG_Right: {
      V v_x_24278 = heff_field(v_x11_24275, 0);
      heff_take_n(v_x11_24275, 1ULL, 1);
      V v_x_24279 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24278, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24274_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24279}), v_st_24276});
    }
    default: return heff_nomatch(v_x11_24275);
    }
  }
  default: return heff_nomatch(v_x1_24274);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam24(V self, V *args) {
  V v_st_24285 = args[0];
  V v_m_24284 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24286 = heff_tr(heff_call(v_m_24284, 1, (V[]){v_st_24285}));
  switch (heff_tag_of(v_x1_24286)) {
  case TAG_MkPair: {
    V v_x11_24287 = heff_field(v_x1_24286, 0);
    V v_st_24288 = heff_field(v_x1_24286, 1);
    V v_ru_24x1_24286_24MkPair = heff_take_reuse_n(v_x1_24286, 3ULL, 2);
    switch (heff_tag_of(v_x11_24287)) {
    case TAG_Left: {
      V v_e_24289 = heff_field(v_x11_24287, 0);
      heff_take_n(v_x11_24287, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24286_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24289}), v_st_24288});
    }
    case TAG_Right: {
      V v_x_24290 = heff_field(v_x11_24287, 0);
      heff_take_n(v_x11_24287, 1ULL, 1);
      V v_x_24291 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24290, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24286_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24291}), v_st_24288});
    }
    default: return heff_nomatch(v_x11_24287);
    }
  }
  default: return heff_nomatch(v_x1_24286);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam25(V self, V *args) {
  V v_st_24296 = args[0];
  V v_m_24295 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24297 = heff_tr(heff_call(v_m_24295, 1, (V[]){v_st_24296}));
  switch (heff_tag_of(v_x1_24297)) {
  case TAG_MkPair: {
    V v_x11_24298 = heff_field(v_x1_24297, 0);
    V v_st_24299 = heff_field(v_x1_24297, 1);
    V v_ru_24x1_24297_24MkPair = heff_take_reuse_n(v_x1_24297, 3ULL, 2);
    switch (heff_tag_of(v_x11_24298)) {
    case TAG_Left: {
      V v_e_24300 = heff_field(v_x11_24298, 0);
      heff_take_n(v_x11_24298, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24297_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24300}), v_st_24299});
    }
    case TAG_Right: {
      V v_x_24301 = heff_field(v_x11_24298, 0);
      heff_take_n(v_x11_24298, 1ULL, 1);
      V v_x_24302 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24301, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24297_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24302}), v_st_24299});
    }
    default: return heff_nomatch(v_x11_24298);
    }
  }
  default: return heff_nomatch(v_x1_24297);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam26(V self, V *args) {
  V v_st_24310 = args[0];
  V v_m_24309 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24311 = heff_tr(heff_call(v_m_24309, 1, (V[]){v_st_24310}));
  switch (heff_tag_of(v_x1_24311)) {
  case TAG_MkPair: {
    V v_x11_24312 = heff_field(v_x1_24311, 0);
    V v_st_24313 = heff_field(v_x1_24311, 1);
    V v_ru_24x1_24311_24MkPair = heff_take_reuse_n(v_x1_24311, 3ULL, 2);
    switch (heff_tag_of(v_x11_24312)) {
    case TAG_Left: {
      V v_e_24314 = heff_field(v_x11_24312, 0);
      heff_take_n(v_x11_24312, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24311_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24314}), v_st_24313});
    }
    case TAG_Right: {
      V v_x_24315 = heff_field(v_x11_24312, 0);
      heff_take_n(v_x11_24312, 1ULL, 1);
      V v_x_24316 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24315, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24311_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24316}), v_st_24313});
    }
    default: return heff_nomatch(v_x11_24312);
    }
  }
  default: return heff_nomatch(v_x1_24311);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam27(V self, V *args) {
  V v_st_24320 = args[0];
  V v_m_24319 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24321 = heff_tr(heff_call(v_m_24319, 1, (V[]){v_st_24320}));
  switch (heff_tag_of(v_x1_24321)) {
  case TAG_MkPair: {
    V v_x11_24322 = heff_field(v_x1_24321, 0);
    V v_st_24323 = heff_field(v_x1_24321, 1);
    V v_ru_24x1_24321_24MkPair = heff_take_reuse_n(v_x1_24321, 3ULL, 2);
    switch (heff_tag_of(v_x11_24322)) {
    case TAG_Left: {
      V v_e_24324 = heff_field(v_x11_24322, 0);
      heff_take_n(v_x11_24322, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24321_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24324}), v_st_24323});
    }
    case TAG_Right: {
      V v_x_24325 = heff_field(v_x11_24322, 0);
      heff_take_n(v_x11_24322, 1ULL, 1);
      V v_x_24326 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24325, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24321_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24326}), v_st_24323});
    }
    default: return heff_nomatch(v_x11_24322);
    }
  }
  default: return heff_nomatch(v_x1_24321);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam28(V self, V *args) {
  V v_st_24331 = args[0];
  V v_m_24330 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24332 = heff_tr(heff_call(v_m_24330, 1, (V[]){v_st_24331}));
  switch (heff_tag_of(v_x1_24332)) {
  case TAG_MkPair: {
    V v_x11_24333 = heff_field(v_x1_24332, 0);
    V v_st_24334 = heff_field(v_x1_24332, 1);
    V v_ru_24x1_24332_24MkPair = heff_take_reuse_n(v_x1_24332, 3ULL, 2);
    switch (heff_tag_of(v_x11_24333)) {
    case TAG_Left: {
      V v_e_24335 = heff_field(v_x11_24333, 0);
      heff_take_n(v_x11_24333, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24332_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24335}), v_st_24334});
    }
    case TAG_Right: {
      V v_x_24336 = heff_field(v_x11_24333, 0);
      heff_take_n(v_x11_24333, 1ULL, 1);
      V v_x_24337 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24336, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24332_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24337}), v_st_24334});
    }
    default: return heff_nomatch(v_x11_24333);
    }
  }
  default: return heff_nomatch(v_x1_24332);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam29(V self, V *args) {
  V v_st_24345 = args[0];
  V v_m_24344 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24346 = heff_tr(heff_call(v_m_24344, 1, (V[]){v_st_24345}));
  switch (heff_tag_of(v_x1_24346)) {
  case TAG_MkPair: {
    V v_x11_24347 = heff_field(v_x1_24346, 0);
    V v_st_24348 = heff_field(v_x1_24346, 1);
    V v_ru_24x1_24346_24MkPair = heff_take_reuse_n(v_x1_24346, 3ULL, 2);
    switch (heff_tag_of(v_x11_24347)) {
    case TAG_Left: {
      V v_e_24349 = heff_field(v_x11_24347, 0);
      heff_take_n(v_x11_24347, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24346_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24349}), v_st_24348});
    }
    case TAG_Right: {
      V v_x_24350 = heff_field(v_x11_24347, 0);
      heff_take_n(v_x11_24347, 1ULL, 1);
      V v_x_24351 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_24350, NTAG(TAG_Nothing)));
      return heff_tag_at_n(v_ru_24x1_24346_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24351}), v_st_24348});
    }
    default: return heff_nomatch(v_x11_24347);
    }
  }
  default: return heff_nomatch(v_x1_24346);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str1, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str3, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str5, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str7, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str9, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str11, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str13, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str18, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str19, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str20, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str21, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str23, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str25, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str27, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str28, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str29, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str30, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str31, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str33, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str35, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str37, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str39, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str40, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str41, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str42, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str43, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str44, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str45, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str46, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str47, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str48, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str49, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str50, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str51, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str52, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str53, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str54, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str55, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str56, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str57, 12, "unexpected `");
V g_heff_2esyntax_2esurface_2ealtL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam30(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ealtL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ealtL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ealtL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    heff_drop_rec(v_r_240, 3);
    V v_t_243 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_244 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_245 = heff_strAppend(heff_get_n(v_t_244, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str0));
    V v_msg_246 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str1), v_t_245);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam0, 1, 2, (V[]){v_t_243, v_msg_246});
  }
  case TAG_EParen: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2413 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2414 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2415 = heff_strAppend(heff_get_n(v_t_2414, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str2));
    V v_msg_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str3), v_t_2415);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam1, 1, 2, (V[]){v_t_2413, v_msg_2416});
  }
  case TAG_Named: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2425 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2426 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_2427 = heff_strAppend(heff_get_n(v_t_2426, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str4));
    V v_msg_2428 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str5), v_t_2427);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam2, 1, 2, (V[]){v_t_2425, v_msg_2428});
  }
  case TAG_Tup: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2436 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2437 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2438 = heff_strAppend(heff_get_n(v_t_2437, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str6));
    V v_msg_2439 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str7), v_t_2438);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam3, 1, 2, (V[]){v_t_2436, v_msg_2439});
  }
  case TAG_Seg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2446 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2447 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2448 = heff_strAppend(heff_get_n(v_t_2447, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str8));
    V v_msg_2449 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str9), v_t_2448);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam4, 1, 2, (V[]){v_t_2446, v_msg_2449});
  }
  case TAG_Braces: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2457 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2458 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_2459 = heff_strAppend(heff_get_n(v_t_2458, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str10));
    V v_msg_2460 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str11), v_t_2459);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam5, 1, 2, (V[]){v_t_2457, v_msg_2460});
  }
  case TAG_Update: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2470 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2471 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_2472 = heff_strAppend(heff_get_n(v_t_2471, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str12));
    V v_msg_2473 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str13), v_t_2472);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam6, 1, 2, (V[]){v_t_2470, v_msg_2473});
  }
  case TAG_EUSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2480 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2481 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_2482 = heff_strAppend(heff_get_n(v_t_2481, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str14));
    V v_msg_2483 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str15), v_t_2482);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam7, 1, 2, (V[]){v_t_2480, v_msg_2483});
  }
  case TAG_InstB: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2492 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_2493 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_2494 = heff_strAppend(heff_get_n(v_t_2493, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str16));
    V v_msg_2495 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str17), v_t_2494);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam8, 1, 2, (V[]){v_t_2492, v_msg_2495});
  }
  case TAG_EFSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24102 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24103 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24104 = heff_strAppend(heff_get_n(v_t_24103, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str18));
    V v_msg_24105 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str19), v_t_24104);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam9, 1, 2, (V[]){v_t_24102, v_msg_24105});
  }
  case TAG_EFDefault: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24112 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24113 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24114 = heff_strAppend(heff_get_n(v_t_24113, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str20));
    V v_msg_24115 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str21), v_t_24114);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam10, 1, 2, (V[]){v_t_24112, v_msg_24115});
  }
  case TAG_Sum: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24124 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24125 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_24126 = heff_strAppend(heff_get_n(v_t_24125, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str22));
    V v_msg_24127 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str23), v_t_24126);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam11, 1, 2, (V[]){v_t_24124, v_msg_24127});
  }
  case TAG_ECon: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24133 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24134 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24135 = heff_strAppend(heff_get_n(v_t_24134, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str24));
    V v_msg_24136 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str25), v_t_24135);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam12, 1, 2, (V[]){v_t_24133, v_msg_24136});
  }
  case TAG_EField: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24142 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24143 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24144 = heff_strAppend(heff_get_n(v_t_24143, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str26));
    V v_msg_24145 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str27), v_t_24144);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam13, 1, 2, (V[]){v_t_24142, v_msg_24145});
  }
  case TAG_ENeg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24151 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24152 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24153 = heff_strAppend(heff_get_n(v_t_24152, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str28));
    V v_msg_24154 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str29), v_t_24153);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam14, 1, 2, (V[]){v_t_24151, v_msg_24154});
  }
  case TAG_App: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24160 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24161 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24162 = heff_strAppend(heff_get_n(v_t_24161, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str30));
    V v_msg_24163 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str31), v_t_24162);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam15, 1, 2, (V[]){v_t_24160, v_msg_24163});
  }
  case TAG_Op: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24170 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24171 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24172 = heff_strAppend(heff_get_n(v_t_24171, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str32));
    V v_msg_24173 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str33), v_t_24172);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam16, 1, 2, (V[]){v_t_24170, v_msg_24173});
  }
  case TAG_Ops: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24179 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24180 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24181 = heff_strAppend(heff_get_n(v_t_24180, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str34));
    V v_msg_24182 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str35), v_t_24181);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam17, 1, 2, (V[]){v_t_24179, v_msg_24182});
  }
  case TAG_OpRhs: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24188 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24189 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24190 = heff_strAppend(heff_get_n(v_t_24189, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str36));
    V v_msg_24191 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str37), v_t_24190);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam18, 1, 2, (V[]){v_t_24188, v_msg_24191});
  }
  case TAG_Ann: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24198 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24199 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24200 = heff_strAppend(heff_get_n(v_t_24199, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str38));
    V v_msg_24201 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str39), v_t_24200);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam19, 1, 2, (V[]){v_t_24198, v_msg_24201});
  }
  case TAG_BVar: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24206 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24207 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 1); r_; });
    V v_t_24208 = heff_strAppend(heff_get_n(v_t_24207, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str40));
    V v_msg_24209 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str41), v_t_24208);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam20, 1, 2, (V[]){v_t_24206, v_msg_24209});
  }
  case TAG_BImp: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24216 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24217 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24218 = heff_strAppend(heff_get_n(v_t_24217, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str42));
    V v_msg_24219 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str43), v_t_24218);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam21, 1, 2, (V[]){v_t_24216, v_msg_24219});
  }
  case TAG_BAnn: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24228 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24229 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 5); r_; });
    V v_t_24230 = heff_strAppend(heff_get_n(v_t_24229, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str44));
    V v_msg_24231 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str45), v_t_24230);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam22, 1, 2, (V[]){v_t_24228, v_msg_24231});
  }
  case TAG_Lam: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24239 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24240 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24241 = heff_strAppend(heff_get_n(v_t_24240, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str46));
    V v_msg_24242 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str47), v_t_24241);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam23, 1, 2, (V[]){v_t_24239, v_msg_24242});
  }
  case TAG_Case: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24250 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24251 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 4); r_; });
    V v_t_24252 = heff_strAppend(heff_get_n(v_t_24251, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str48));
    V v_msg_24253 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str49), v_t_24252);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam24, 1, 2, (V[]){v_t_24250, v_msg_24253});
  }
  case TAG_EAlt: {
    V v_p_24257 = heff_field(v_e_241, 0);
    V v_e3_24259 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 5ULL, 3);
    V v_m_24260 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_p_24257)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam25, 1, 4, (V[]){v_m_24260, v_p_24257, v_r_240, v_e3_24259});
  }
  case TAG_If: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24289 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24290 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24291 = heff_strAppend(heff_get_n(v_t_24290, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str50));
    V v_msg_24292 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str51), v_t_24291);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam27, 1, 2, (V[]){v_t_24289, v_msg_24292});
  }
  case TAG_Do: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24298 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24299 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 2); r_; });
    V v_t_24300 = heff_strAppend(heff_get_n(v_t_24299, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str52));
    V v_msg_24301 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str53), v_t_24300);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam28, 1, 2, (V[]){v_t_24298, v_msg_24301});
  }
  case TAG_ESBind: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24308 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24309 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 3); r_; });
    V v_t_24310 = heff_strAppend(heff_get_n(v_t_24309, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str54));
    V v_msg_24311 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str55), v_t_24310);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam29, 1, 2, (V[]){v_t_24308, v_msg_24311});
  }
  case TAG_ELet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24321 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_t_24322 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e_241, 6); r_; });
    V v_t_24323 = heff_strAppend(heff_get_n(v_t_24322, 1, 9), ((V)&g_heff_2esyntax_2esurface_2ealtL_str56));
    V v_msg_24324 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str57), v_t_24323);
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam30, 1, 2, (V[]){v_t_24321, v_msg_24324});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ealtL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2ealtL_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_t_243 = heff_env(self)[0];
  V v_msg_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_243, 3), heff_get_n(v_t_243, 4, 9)});
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_246, v_t_248, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_249}), v_st_247});
}
V g_heff_2esyntax_2esurface_2ealtL_lam1(V self, V *args) {
  V v_st_2417 = args[0];
  V v_t_2413 = heff_env(self)[0];
  V v_msg_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2413, 3), heff_get_n(v_t_2413, 4, 9)});
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2416, v_t_2418, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2419}), v_st_2417});
}
V g_heff_2esyntax_2esurface_2ealtL_lam2(V self, V *args) {
  V v_st_2429 = args[0];
  V v_t_2425 = heff_env(self)[0];
  V v_msg_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2425, 3), heff_get_n(v_t_2425, 4, 9)});
  V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2428, v_t_2430, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2431}), v_st_2429});
}
V g_heff_2esyntax_2esurface_2ealtL_lam3(V self, V *args) {
  V v_st_2440 = args[0];
  V v_t_2436 = heff_env(self)[0];
  V v_msg_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2441 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2436, 3), heff_get_n(v_t_2436, 4, 9)});
  V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2439, v_t_2441, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2442}), v_st_2440});
}
V g_heff_2esyntax_2esurface_2ealtL_lam4(V self, V *args) {
  V v_st_2450 = args[0];
  V v_t_2446 = heff_env(self)[0];
  V v_msg_2449 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2446, 3), heff_get_n(v_t_2446, 4, 9)});
  V v_t_2452 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2449, v_t_2451, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2452}), v_st_2450});
}
V g_heff_2esyntax_2esurface_2ealtL_lam5(V self, V *args) {
  V v_st_2461 = args[0];
  V v_t_2457 = heff_env(self)[0];
  V v_msg_2460 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2462 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2457, 3), heff_get_n(v_t_2457, 4, 9)});
  V v_t_2463 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2460, v_t_2462, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2463}), v_st_2461});
}
V g_heff_2esyntax_2esurface_2ealtL_lam6(V self, V *args) {
  V v_st_2474 = args[0];
  V v_t_2470 = heff_env(self)[0];
  V v_msg_2473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2475 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2470, 3), heff_get_n(v_t_2470, 4, 9)});
  V v_t_2476 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2473, v_t_2475, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2476}), v_st_2474});
}
V g_heff_2esyntax_2esurface_2ealtL_lam7(V self, V *args) {
  V v_st_2484 = args[0];
  V v_t_2480 = heff_env(self)[0];
  V v_msg_2483 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2485 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2480, 3), heff_get_n(v_t_2480, 4, 9)});
  V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2483, v_t_2485, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2486}), v_st_2484});
}
V g_heff_2esyntax_2esurface_2ealtL_lam8(V self, V *args) {
  V v_st_2496 = args[0];
  V v_t_2492 = heff_env(self)[0];
  V v_msg_2495 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2497 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2492, 3), heff_get_n(v_t_2492, 4, 9)});
  V v_t_2498 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2495, v_t_2497, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2498}), v_st_2496});
}
V g_heff_2esyntax_2esurface_2ealtL_lam9(V self, V *args) {
  V v_st_24106 = args[0];
  V v_t_24102 = heff_env(self)[0];
  V v_msg_24105 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24107 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24102, 3), heff_get_n(v_t_24102, 4, 9)});
  V v_t_24108 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24105, v_t_24107, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24108}), v_st_24106});
}
V g_heff_2esyntax_2esurface_2ealtL_lam10(V self, V *args) {
  V v_st_24116 = args[0];
  V v_t_24112 = heff_env(self)[0];
  V v_msg_24115 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24117 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24112, 3), heff_get_n(v_t_24112, 4, 9)});
  V v_t_24118 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24115, v_t_24117, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24118}), v_st_24116});
}
V g_heff_2esyntax_2esurface_2ealtL_lam11(V self, V *args) {
  V v_st_24128 = args[0];
  V v_t_24124 = heff_env(self)[0];
  V v_msg_24127 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24129 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24124, 3), heff_get_n(v_t_24124, 4, 9)});
  V v_t_24130 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24127, v_t_24129, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24130}), v_st_24128});
}
V g_heff_2esyntax_2esurface_2ealtL_lam12(V self, V *args) {
  V v_st_24137 = args[0];
  V v_t_24133 = heff_env(self)[0];
  V v_msg_24136 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24138 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24133, 3), heff_get_n(v_t_24133, 4, 9)});
  V v_t_24139 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24136, v_t_24138, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24139}), v_st_24137});
}
V g_heff_2esyntax_2esurface_2ealtL_lam13(V self, V *args) {
  V v_st_24146 = args[0];
  V v_t_24142 = heff_env(self)[0];
  V v_msg_24145 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24147 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24142, 3), heff_get_n(v_t_24142, 4, 9)});
  V v_t_24148 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24145, v_t_24147, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24148}), v_st_24146});
}
V g_heff_2esyntax_2esurface_2ealtL_lam14(V self, V *args) {
  V v_st_24155 = args[0];
  V v_t_24151 = heff_env(self)[0];
  V v_msg_24154 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24156 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24151, 3), heff_get_n(v_t_24151, 4, 9)});
  V v_t_24157 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24154, v_t_24156, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24157}), v_st_24155});
}
V g_heff_2esyntax_2esurface_2ealtL_lam15(V self, V *args) {
  V v_st_24164 = args[0];
  V v_t_24160 = heff_env(self)[0];
  V v_msg_24163 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24165 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24160, 3), heff_get_n(v_t_24160, 4, 9)});
  V v_t_24166 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24163, v_t_24165, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24166}), v_st_24164});
}
V g_heff_2esyntax_2esurface_2ealtL_lam16(V self, V *args) {
  V v_st_24174 = args[0];
  V v_t_24170 = heff_env(self)[0];
  V v_msg_24173 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24175 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24170, 3), heff_get_n(v_t_24170, 4, 9)});
  V v_t_24176 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24173, v_t_24175, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24176}), v_st_24174});
}
V g_heff_2esyntax_2esurface_2ealtL_lam17(V self, V *args) {
  V v_st_24183 = args[0];
  V v_t_24179 = heff_env(self)[0];
  V v_msg_24182 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24184 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24179, 3), heff_get_n(v_t_24179, 4, 9)});
  V v_t_24185 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24182, v_t_24184, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24185}), v_st_24183});
}
V g_heff_2esyntax_2esurface_2ealtL_lam18(V self, V *args) {
  V v_st_24192 = args[0];
  V v_t_24188 = heff_env(self)[0];
  V v_msg_24191 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24193 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24188, 3), heff_get_n(v_t_24188, 4, 9)});
  V v_t_24194 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24191, v_t_24193, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24194}), v_st_24192});
}
V g_heff_2esyntax_2esurface_2ealtL_lam19(V self, V *args) {
  V v_st_24202 = args[0];
  V v_t_24198 = heff_env(self)[0];
  V v_msg_24201 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24203 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24198, 3), heff_get_n(v_t_24198, 4, 9)});
  V v_t_24204 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24201, v_t_24203, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24204}), v_st_24202});
}
V g_heff_2esyntax_2esurface_2ealtL_lam20(V self, V *args) {
  V v_st_24210 = args[0];
  V v_t_24206 = heff_env(self)[0];
  V v_msg_24209 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24211 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24206, 3), heff_get_n(v_t_24206, 4, 9)});
  V v_t_24212 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24209, v_t_24211, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24212}), v_st_24210});
}
V g_heff_2esyntax_2esurface_2ealtL_lam21(V self, V *args) {
  V v_st_24220 = args[0];
  V v_t_24216 = heff_env(self)[0];
  V v_msg_24219 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24221 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24216, 3), heff_get_n(v_t_24216, 4, 9)});
  V v_t_24222 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24219, v_t_24221, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24222}), v_st_24220});
}
V g_heff_2esyntax_2esurface_2ealtL_lam22(V self, V *args) {
  V v_st_24232 = args[0];
  V v_t_24228 = heff_env(self)[0];
  V v_msg_24231 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24233 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24228, 3), heff_get_n(v_t_24228, 4, 9)});
  V v_t_24234 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24231, v_t_24233, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24234}), v_st_24232});
}
V g_heff_2esyntax_2esurface_2ealtL_lam23(V self, V *args) {
  V v_st_24243 = args[0];
  V v_t_24239 = heff_env(self)[0];
  V v_msg_24242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24244 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24239, 3), heff_get_n(v_t_24239, 4, 9)});
  V v_t_24245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24242, v_t_24244, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24245}), v_st_24243});
}
V g_heff_2esyntax_2esurface_2ealtL_lam24(V self, V *args) {
  V v_st_24254 = args[0];
  V v_t_24250 = heff_env(self)[0];
  V v_msg_24253 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24255 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24250, 3), heff_get_n(v_t_24250, 4, 9)});
  V v_t_24256 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24253, v_t_24255, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24256}), v_st_24254});
}
V g_heff_2esyntax_2esurface_2ealtL_lam26(V self, V *args) {
  V v_st_24269 = args[0];
  V v_m_24268 = heff_env(self)[0];
  V v_x_24266 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24270 = heff_tr(heff_call(v_m_24268, 1, (V[]){v_st_24269}));
  switch (heff_tag_of(v_x1_24270)) {
  case TAG_MkPair: {
    V v_x11_24271 = heff_field(v_x1_24270, 0);
    V v_st_24272 = heff_field(v_x1_24270, 1);
    V v_ru_24x1_24270_24MkPair = heff_take_reuse_n(v_x1_24270, 3ULL, 2);
    switch (heff_tag_of(v_x11_24271)) {
    case TAG_Left: {
      V v_e_24273 = heff_field(v_x11_24271, 0);
      heff_take_n(v_x11_24271, 1ULL, 1);
      heff_drop(v_x_24266);
      return heff_tag_at_n(v_ru_24x1_24270_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24273}), v_st_24272});
    }
    case TAG_Right: {
      V v_x_24274 = heff_field(v_x11_24271, 0);
      heff_take_n(v_x11_24271, 1ULL, 1);
      V v_t_24277;
      switch (heff_tag_of(v_x_24266)) {
      case TAG_At: {
        V v_s_24276 = heff_dup(heff_field(v_x_24266, 1));
        v_t_24277 = v_s_24276;
        break;
      }
      default: heff_nomatch(v_x_24266);
      }
      V v_t_24280;
      switch (heff_tag_of(v_x_24274)) {
      case TAG_At: {
        V v_s_24279 = heff_dup(heff_field(v_x_24274, 1));
        v_t_24280 = v_s_24279;
        break;
      }
      default: heff_nomatch(v_x_24274);
      }
      V v_t_24281 = ({ V rv_1 = heff_get_n(v_t_24280, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24277, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_24282 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_24266, v_x_24274}), v_t_24281});
      return heff_tag_at_n(v_ru_24x1_24270_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24282}), v_st_24272});
    }
    default: return heff_nomatch(v_x11_24271);
    }
  }
  default: return heff_nomatch(v_x1_24270);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_lam25(V self, V *args) {
  V v_st_24261 = args[0];
  V v_m_24260 = heff_env(self)[0];
  V v_p_24257 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_e3_24259 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24262 = heff_tr(heff_call(v_m_24260, 1, (V[]){v_st_24261}));
  switch (heff_tag_of(v_x1_24262)) {
  case TAG_MkPair: {
    V v_x11_24263 = heff_field(v_x1_24262, 0);
    V v_st_24264 = heff_field(v_x1_24262, 1);
    V v_ru_24x1_24262_24MkPair = heff_take_reuse_n(v_x1_24262, 3ULL, 2);
    switch (heff_tag_of(v_x11_24263)) {
    case TAG_Left: {
      V v_e_24265 = heff_field(v_x11_24263, 0);
      heff_take_n(v_x11_24263, 1ULL, 1);
      heff_drop(v_p_24257);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_e3_24259);
      return heff_tag_at_n(v_ru_24x1_24262_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24265}), v_st_24264});
    }
    case TAG_Right: {
      V v_x_24266 = heff_field(v_x11_24263, 0);
      heff_take_n(v_x11_24263, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_24262_24MkPair, 2);
      V v_t_24267 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_p_24257; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop(v_p_24257); r_; });
      V v_m_24268 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e3_24259}));
      return (g_heff_2esyntax_2esurface_2ewithScope(v_t_24267, heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam26, 1, 2, (V[]){v_m_24268, v_x_24266}), v_st_24264));
    }
    default: return heff_nomatch(v_x11_24263);
    }
  }
  default: return heff_nomatch(v_x1_24262);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_lam27(V self, V *args) {
  V v_st_24293 = args[0];
  V v_t_24289 = heff_env(self)[0];
  V v_msg_24292 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24294 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24289, 3), heff_get_n(v_t_24289, 4, 9)});
  V v_t_24295 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24292, v_t_24294, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24295}), v_st_24293});
}
V g_heff_2esyntax_2esurface_2ealtL_lam28(V self, V *args) {
  V v_st_24302 = args[0];
  V v_t_24298 = heff_env(self)[0];
  V v_msg_24301 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24303 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24298, 3), heff_get_n(v_t_24298, 4, 9)});
  V v_t_24304 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24301, v_t_24303, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24304}), v_st_24302});
}
V g_heff_2esyntax_2esurface_2ealtL_lam29(V self, V *args) {
  V v_st_24312 = args[0];
  V v_t_24308 = heff_env(self)[0];
  V v_msg_24311 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24313 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24308, 3), heff_get_n(v_t_24308, 4, 9)});
  V v_t_24314 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24311, v_t_24313, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24314}), v_st_24312});
}
V g_heff_2esyntax_2esurface_2ealtL_lam30(V self, V *args) {
  V v_st_24325 = args[0];
  V v_t_24321 = heff_env(self)[0];
  V v_msg_24324 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24326 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24321, 3), heff_get_n(v_t_24321, 4, 9)});
  V v_t_24327 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24324, v_t_24326, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24327}), v_st_24325});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str0, 4, "True");
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str1, 4, "True");
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str2, 5, "False");
HEFF_LIT(g_heff_2esyntax_2esurface_2eifE_str3, 5, "False");
Clo g_heff_2esyntax_2esurface_2eifE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eifE_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eifE(V v_sp_240, V v_c_241, V v_a_242, V v_b_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str0), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str1)}), heff_dup(v_sp_240)});
  V v_x1_246 = ({ V a_0 = v_t_245; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_249;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_At: {
    V v_s_248 = heff_field(v_x1_246, 1);
    heff_take_n(v_x1_246, 2ULL, 2);
    v_t_249 = v_s_248;
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  V v_t_2410 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_249, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_p_2411 = heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_t_2410});
  V v_t_2414;
  switch (heff_tag_of(v_p_2411)) {
  case TAG_At: {
    V v_s_2413 = heff_dup(heff_field(v_p_2411, 1));
    v_t_2414 = v_s_2413;
    break;
  }
  default: heff_nomatch(v_p_2411);
  }
  V v_t_2417;
  switch (heff_tag_of(v_a_242)) {
  case TAG_At: {
    V v_s_2416 = heff_dup(heff_field(v_a_242, 1));
    v_t_2417 = v_s_2416;
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  V v_t_2418 = ({ V rv_1 = heff_get_n(v_t_2417, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2414, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2411, v_a_242}), v_t_2418});
  V v_t_2420 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str2), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eifE_str3)}), heff_dup(v_sp_240)});
  V v_x1_2422 = ({ V a_0 = v_t_2421; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2425;
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_At: {
    V v_s_2424 = heff_field(v_x1_2422, 1);
    heff_take_n(v_x1_2422, 2ULL, 2);
    v_t_2425 = v_s_2424;
    break;
  }
  default: heff_nomatch(v_x1_2422);
  }
  V v_t_2426 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2425, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_p_2427 = heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_t_2426});
  V v_t_2430;
  switch (heff_tag_of(v_p_2427)) {
  case TAG_At: {
    V v_s_2429 = heff_dup(heff_field(v_p_2427, 1));
    v_t_2430 = v_s_2429;
    break;
  }
  default: heff_nomatch(v_p_2427);
  }
  V v_t_2433;
  switch (heff_tag_of(v_b_243)) {
  case TAG_At: {
    V v_s_2432 = heff_dup(heff_field(v_b_243, 1));
    v_t_2433 = v_s_2432;
    break;
  }
  default: heff_nomatch(v_b_243);
  }
  V v_t_2434 = ({ V rv_1 = heff_get_n(v_t_2433, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2430, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2427, v_b_243}), v_t_2434});
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
  V v_t_2437 = heff_tag_n(TAG_EMatch, 2, (V[]){v_c_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2436})});
  return heff_tag_n(TAG_At, 2, (V[]){v_t_2437, v_sp_240});
}
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eifE(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2esurface_2evalueOfE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evalueOfE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2evalueOfE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ETag: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EInt: {
      V v_v_246 = heff_field(v_x11_241, 0);
      return heff_tag_n(TAG_IntValue, 1, (V[]){heff_dup(v_v_246)});
    }
    case TAG_EFloat: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EString: {
      return NTAG(TAG_StrValue);
    }
    case TAG_EBinary: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ERune: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EWord: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EApp: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EProject: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ENamed: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EPi: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELam: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EAnn: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ESpec: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ESig: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ESum: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EStruct: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EMatch: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EDo: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELocal: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_OtherValue);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2evalueOfE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2evalueOfE(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eparamOf_str0, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
Clo g_heff_2esyntax_2esurface_2eparamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eparamOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eparamOf(V v_p_240, V v_z_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2esurface_2enameAnn(v_p_240));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_245;
    switch (heff_tag_of(v_p_240)) {
    case TAG_At: {
      V v_s_244 = heff_field(v_p_240, 1);
      v_t_245 = heff_dup(v_s_244);
      break;
    }
    default: heff_nomatch(v_p_240);
    }
    V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eparamOf_str0), v_t_245, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_246}), v_z_241});
  }
  case TAG_Just: {
    V v_q_247 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_248 = heff_tag_n(TAG_ExplicitParam, 3, (V[]){heff_take_field(v_q_247, 0), heff_dup(heff_rfield(v_q_247, 1)), heff_dup(heff_rfield(v_q_247, 2))});
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_q_247, 1)), 0, 2);
    V v_t_2410 = heff_get_n(v_q_247, 2, 3);
    V v_t_2413;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_At: {
      V v_s_2412 = heff_field(v_t_2410, 1);
      heff_take_n(v_t_2410, 2ULL, 2);
      v_t_2413 = v_s_2412;
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2414 = ({ V rv_0 = v_t_249; V rr_ = heff_rec_reuse_nf(v_t_2413, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2415 = heff_tag_at_n(v_ru_24t_242_24Just, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_t_2414})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_z_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eparamOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2edataParamL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edataParamL(V v_r_240, V v_e_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2esurface_2eatomOf(heff_dup(v_e_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    HEFF_LAST return g_heff_2esyntax_2esurface_2edataParamOf(v_r_240, v_e_241);
  }
  case TAG_Just: {
    V v_x_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    heff_drop(v_r_240);
    heff_drop(v_e_241);
    return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamL_lam0, 1, 1, (V[]){v_x_243});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edataParamL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_243, 3)), heff_dup(heff_rfield(v_x_243, 4))});
  V v_t_246 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_243, 3)), heff_dup(heff_rfield(v_x_243, 4))});
  V v_t_248 = heff_tag_n(TAG_ExplicitParam, 3, (V[]){heff_take_field(v_x_243, 1), v_t_245, heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_t_247})});
  V v_t_249 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_243, 3), heff_get_n(v_x_243, 4, 9)});
  V v_t_2410 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_t_249})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_st_244});
}
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_entry, 6, 0};

V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426(V v_d_240, V v_kw_241, V v_name_242, V v_params_243, V v_fields_244, V v_z_245) {
top: ;
  V v_m_246 = (g_heff_2esyntax_2esurface_2etraverseS_24s1708543947x2040787389(v_params_243));
  V v_x1_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_245}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop_rec(v_name_242, 9);
      heff_drop(v_fields_244);
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_247_24MkPair, 2);
      V v_t_2412 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2411)));
      return (g_heff_2esyntax_2esurface_2ewithScope(v_t_2412, heff_clo_n(g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_lam0, 1, 5, (V[]){v_fields_244, v_name_242, v_d_240, v_kw_241, v_x_2411}), v_st_249));
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2esurface_2etheoryL_24s393378062x2000841426_lam0(V self, V *args) {
  V v_st_2413 = args[0];
  V v_fields_244 = heff_env(self)[0];
  V v_name_242 = heff_env(self)[1];
  V v_d_240 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2414 = (g_heff_2esyntax_2esurface_2eblock_24s611148689x133456453(v_fields_244, v_st_2413));
  switch (heff_tag_of(v_x1_2414)) {
  case TAG_MkPair: {
    V v_x11_2415 = heff_field(v_x1_2414, 0);
    V v_st_2416 = heff_field(v_x1_2414, 1);
    V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
    switch (heff_tag_of(v_x11_2415)) {
    case TAG_Left: {
      V v_e_2417 = heff_field(v_x11_2415, 0);
      heff_take_n(v_x11_2415, 1ULL, 1);
      heff_drop_rec(v_name_242, 9);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_x_2411);
      return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
    }
    case TAG_Right: {
      V v_x_2418 = heff_field(v_x11_2415, 0);
      V v_ru_24x11_2415_24Right = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
      V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_name_242, 3), heff_take_field(v_name_242, 4)});
      V v_t_2420 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_240)));
      V v_e_2421 = heff_get_n(v_t_2420, 4, 9);
      V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), v_e_2421});
      V v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2415_24Right, TAG_ESig, 1, (V[]){v_x_2418}), v_t_2422});
      V v_t_2424 = heff_tag_n(TAG_DeclTheory, 4, (V[]){heff_get_n(v_name_242, 1, 9), v_t_2419, v_x_2411, v_t_2423});
      V v_t_2425 = (g_heff_2esyntax_2ecst_2elastD(v_d_240));
      V v_e_2426 = heff_get_n(v_t_2425, 4, 9);
      V v_t_2427 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2426});
      V v_t_2428 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_t_2427})});
      V v_x_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2429}), v_st_2416});
    }
    default: return heff_nomatch(v_x11_2415);
    }
  }
  default: return heff_nomatch(v_x1_2414);
  }
}
V g_heff_2esyntax_2esurface_2ereadPlaced_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ereadPlaced_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadPlaced_entry, 5, 0};

V g_heff_2esyntax_2esurface_2ereadPlaced(V v_at_240, V v_lexDiags_241, V v_own_242, V v_r_243, V v_placed_244) {
top: ;
  V v_items_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_placed_244, 0)));
  V v_t_246 = (g_heff_2esyntax_2esurface_2enameSet(heff_rfield(v_r_243, 2)));
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = v_items_245; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2eassembleGo(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_placed_244, 2, 3)));
  V v_items_249 = heff_dup(heff_rfield(v_r_243, 0));
  V v_t_2410 = (g_heff_2esyntax_2esurface_2enameSet(heff_rfield(v_r_243, 2)));
  V v_t_2411 = (g_heff_2esyntax_2esurface_2esigNames(v_items_249));
  V v_t_2412 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_249));
  V v_t_2413 = ({ V a_0 = v_t_2410; V a_1 = v_t_2411; V a_2 = v_t_2412; V a_3 = v_items_249; V r_ = (g_list_2emap_24s2130193383x1335133353(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); heff_drop(v_t_2411); heff_drop(v_t_2412); r_; });
  V v_t_2414 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2413));
  V v_t_2415 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
  V v_d_2419 = (g_list_2efoldl(heff_clo_n(g_heff_2esyntax_2esurface_2ereadPlaced_lam0, 2, 1, (V[]){v_at_240}), v_t_2415, heff_rfield(v_r_243, 0)));
  V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2419, 3, 4)));
  V v_t_2421 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2414, v_t_2420));
  V v_t_2422 = (g_heff_2esyntax_2esurface_2eappendS(v_t_248, v_t_2421));
  V v_t_2423 = (g_heff_2esyntax_2esurface_2eappendS(heff_take_field(v_r_243, 1), v_t_2422));
  V v_t_2424 = (g_heff_2esyntax_2esurface_2eappendS(heff_take_field(v_own_242, 1), v_t_2423));
  V v_t_2425 = (g_heff_2esyntax_2esurface_2eappendS(v_lexDiags_241, v_t_2424));
  return heff_rec_n(4, shape_decls__diags__fixities__broken, (V[]){v_t_247, v_t_2425, heff_get_n(v_own_242, 0, 2), heff_get_n(v_r_243, 2, 3)});
}
V g_heff_2esyntax_2esurface_2ereadPlaced_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereadPlaced(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2ereadPlaced_lam0(V self, V *args) {
  V v_d_2416 = args[0];
  V v_it_2417 = args[1];
  V v_at_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2416, 2)), v_it_2417));
  return ({ V a_0 = v_at_240; V a_1 = v_d_2416; V a_2 = v_t_2418; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
}