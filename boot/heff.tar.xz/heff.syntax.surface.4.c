// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_DeclareField 57313
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_ExplicitParam 63083
#define TAG_FloatValue 23118
#define TAG_IntValue 62477
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_Sig 30557
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StrValue 22621
#define TAG_TypeWord 10401
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_arms 9498206
#define LBL_at 9882
#define LBL_below 294979659
#define LBL_binders 123633223
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_decl 9574769
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_f 320
#define LBL_fixities 357800079
#define LBL_groups 709681407
#define LBL_held 9694204
#define LBL_id 10114
#define LBL_implicits 1321238867
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_little 844663329
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_ops 319788
#define LBL_pat 320285
#define LBL_prims 308293287
#define LBL_rest 9992347
#define LBL_scope 310622830
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_sigs 10025609
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_ty 10476
#define LBL_unit 10090059
#define LBL_whole 314465745
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_decls__diags__fixities__broken__arms[] = {LBL_decls, LBL_diags, LBL_fixities, LBL_broken, LBL_arms};
static uint32_t shape_f__names__implicits[] = {LBL_f, LBL_names, LBL_implicits};
static uint32_t shape_name__span__ty__eqns__whole[] = {LBL_name, LBL_span, LBL_ty, LBL_eqns, LBL_whole};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_sigs__held__rest[] = {LBL_sigs, LBL_held, LBL_rest};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_tighter__looser[] = {LBL_tighter, LBL_looser};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
HeffT2 g_heff_2esyntax_2efixity_2efindG_24cpr(V, V);
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2easBinderOn_24tok1(V, V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok1_clo;
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok2_clo;
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2eatomOf_24cpr(V);
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_clo;
HeffT2 g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok1_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2eboundBy_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_24dps_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(V, V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_24dps_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo;
V g_heff_2esyntax_2esurface_2edataParamL(V, V);
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_clo;
V g_heff_2esyntax_2esurface_2edataParamOf(V, V);
V g_heff_2esyntax_2esurface_2edataParamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamOf_clo;
HeffT3 g_heff_2esyntax_2esurface_2edecimalSplit_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2edotAt(V, V);
V g_heff_2esyntax_2esurface_2edotAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edotAt_clo;
V g_heff_2esyntax_2esurface_2eedgesOf(V, V);
V g_heff_2esyntax_2esurface_2eedgesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eedgesOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
HeffT2 g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(V, V);
V g_heff_2esyntax_2esurface_2efieldDeclOf(V, V);
V g_heff_2esyntax_2esurface_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldDeclOf_clo;
V g_heff_2esyntax_2esurface_2efieldL(V, V);
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V, V);
HeffT2 g_heff_2esyntax_2esurface_2efirstSig_24cpr(V);
V g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664(V, V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664_clo;
V g_heff_2esyntax_2esurface_2egroupFrom(V, V);
V g_heff_2esyntax_2esurface_2egroupFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2egroupFrom_clo;
HeffT3 g_heff_2esyntax_2esurface_2egroupFrom_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eknotOf(V, V);
V g_heff_2esyntax_2esurface_2eknotOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eknotOf_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2emutualDefs(V);
V g_heff_2esyntax_2esurface_2emutualDefs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_clo;
V g_heff_2esyntax_2esurface_2emutualDefs_24dps(V, V);
V g_heff_2esyntax_2esurface_2emutualDefs_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualDefs_24dps_clo;
HeffT2 g_heff_2esyntax_2esurface_2emutualItems_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2emutualL_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2emutualOut(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2emutualOut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualOut_clo;
HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2eparamOf(V, V);
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_clo;
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641(V, V, V, V);
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_clo;
V g_heff_2esyntax_2esurface_2epatTags(V, V);
V g_heff_2esyntax_2esurface_2epatTags_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatTags_clo;
V g_heff_2esyntax_2esurface_2epiBinders(V);
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiBinders_clo;
V g_heff_2esyntax_2esurface_2epiImplicits(V);
V g_heff_2esyntax_2esurface_2epiImplicits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_clo;
V g_heff_2esyntax_2esurface_2ereadPlaced(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadPlaced_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadPlaced_clo;
HeffT2 g_heff_2esyntax_2esurface_2erepeatedField_24cpr(V, V);
V g_heff_2esyntax_2esurface_2esegmentValue(V);
V g_heff_2esyntax_2esurface_2esegmentValue_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentValue_clo;
V g_heff_2esyntax_2esurface_2esetBinders(V, V);
V g_heff_2esyntax_2esurface_2esetBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetBinders_clo;
V g_heff_2esyntax_2esurface_2esetKnot(V, V);
V g_heff_2esyntax_2esurface_2esetKnot_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetKnot_clo;
V g_heff_2esyntax_2esurface_2esetPatVars(V, V);
V g_heff_2esyntax_2esurface_2esetPatVars_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetPatVars_clo;
V g_heff_2esyntax_2esurface_2esetScope(V, V);
V g_heff_2esyntax_2esurface_2esetScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetScope_clo;
V g_heff_2esyntax_2esurface_2esettingL(V, V);
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingL_clo;
V g_heff_2esyntax_2esurface_2esigBinders(V, V, V);
V g_heff_2esyntax_2esurface_2esigBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigBinders_clo;
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2esplitExp(V, V);
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esplitExp_clo;
V g_heff_2esyntax_2esurface_2espreadGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2espreadGo_clo;
V g_heff_2esyntax_2esurface_2etakesRest(V);
V g_heff_2esyntax_2esurface_2etakesRest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakesRest_clo;
V g_heff_2esyntax_2esurface_2etwoToS(V);
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etwoToS_clo;
V g_heff_2esyntax_2esurface_2etypeChecks(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_clo;
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_clo;
V g_heff_2esyntax_2esurface_2eunitIn(V, V);
V g_heff_2esyntax_2esurface_2eunitIn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunitIn_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2evalueOfE(V);
V g_heff_2esyntax_2esurface_2evalueOfE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evalueOfE_clo;
V g_heff_2esyntax_2esurface_2ewhereL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_24tok2_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1413159824x1120446397(V, V);
V g_list_2efoldl_24s1413159824x1120446397_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1413159824x1120446397_clo;
V g_list_2efoldl_24s415128528x640682339(V, V);
V g_list_2efoldl_24s415128528x640682339_entry(V self, V *a);
extern Clo g_list_2efoldl_24s415128528x640682339_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s2081681776x559624592(V);
V g_list_2emap_24s2081681776x559624592_entry(V self, V *a);
extern Clo g_list_2emap_24s2081681776x559624592_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2esyntax_2esurface_2eappendS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2esyntax_2esurface_2eappendS_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V v_xs_240, V v_p_241, V v_st_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_st_242, 1));
  V v_t_244 = (g_heff_2esyntax_2esurface_2eappendS(v_xs_240, heff_dup(heff_rfield(v_st_242, 1))));
  V v_st_245 = (g_heff_2esyntax_2esurface_2esetScope(v_t_244, v_st_242));
  V v_x1_246 = heff_tr(heff_call(v_p_241, 1, (V[]){v_st_245}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    heff_take_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Left = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      heff_drop(v_t_243);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_247_24Left, TAG_Left, 1, (V[]){v_e_249}), v_st_248}});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Right = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      V v_st_2411 = (g_heff_2esyntax_2esurface_2esetScope(v_t_243, v_st_248));
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_247_24Right, TAG_Right, 1, (V[]){v_x_2410}), v_st_2411}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_247)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_246)}});
  }
}
Clo g_heff_2esyntax_2esurface_2ewithScope_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewithScope_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ewithScope(V v_xs_240, V v_p_241, V v_st_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_xs_240, v_p_241, v_st_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ewithScope(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2eblock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eblock_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eblock(V v_f_240, V v_xs_241, V v_st_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_st_242, 1));
  V v_m_244 = (g_prelude_2etraverse_24s499544530x2060473942(v_f_240, v_xs_241));
  V v_x1_245 = heff_tr(heff_call(v_m_244, 1, (V[]){v_st_242}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Left = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      heff_drop(v_t_243);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_246_24Left, TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_st_2410 = (g_heff_2esyntax_2esurface_2esetScope(v_t_243, v_st_247));
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_246_24Right, TAG_Right, 1, (V[]){v_x_249}), v_st_2410});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eblock(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2esplitExp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esplitExp_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esplitExp(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return heff_strLength_lent(v_s_240, 0);
  } else {
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)) == ((int64_t)101ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)) == ((int64_t)69ULL)))) {
      return heff_box_word(v_i_241);
    } else {
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esplitExp(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edecimalSplit_24cpr_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2edecimalSplit_24cpr_str1, 1, "+");

HeffT3 g_heff_2esyntax_2esurface_2edecimalSplit_24cpr(V v_negative_240, V v_s_241, V v_eAt_242) {
top: ;
  V v_m_243 = heff_strSlice_lent(v_s_241, MK_INT(0LL), v_eAt_242, 2);
  V v_d_244 = ({ V b_0 = heff_strSlice_lent(v_s_241, MK_INT(0LL), v_eAt_242, 2); V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2edotAt(b_0, a_1)); heff_drop(b_0); r_; });
  V v_f_247;
  if (heff_intLe_c(heff_strLength_lent(v_m_243, 0), heff_dup(v_d_244))) {
    heff_drop(v_d_244);
    v_f_247 = ({ V a_0 = v_m_243; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_m_243); r_; });
  } else {
    V v_t_245 = heff_strSlice(heff_dup(v_m_243), heff_intAdd(heff_dup(v_d_244), MK_INT(1LL)), heff_strLength_lent(v_m_243, 0));
    V v_t_246 = heff_strAppend(heff_strSlice(v_m_243, MK_INT(0LL), v_d_244), v_t_245);
    v_f_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_t_246); r_; });
  }
  V v_t_2412;
  if (heff_intLe_c(heff_strLength_lent(v_s_241, 0), heff_dup(v_eAt_242))) {
    v_t_2412 = MK_INT(0LL);
  } else {
    V v_ex_248 = heff_strSlice(heff_dup(v_s_241), heff_intAdd(heff_dup(v_eAt_242), MK_INT(1LL)), heff_strLength_lent(v_s_241, 0));
    if (heff_strEq_c(heff_strSlice_lent(v_ex_248, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2edecimalSplit_24cpr_str0))) {
      V v_t_249 = heff_strSlice(heff_dup(v_ex_248), MK_INT(1LL), heff_strLength(v_ex_248));
      V v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_t_249); r_; });
      v_t_2412 = heff_intSub(MK_INT(0LL), v_t_2410);
    } else {
      if (heff_strEq_c(heff_strSlice_lent(v_ex_248, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2edecimalSplit_24cpr_str1))) {
        V v_t_2411 = heff_strSlice(heff_dup(v_ex_248), MK_INT(1LL), heff_strLength(v_ex_248));
        v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_t_2411); r_; });
      } else {
        v_t_2412 = ({ V a_0 = v_ex_248; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_ex_248); r_; });
      }
    }
  }
  V v_m_2413 = heff_strSlice_lent(v_s_241, MK_INT(0LL), v_eAt_242, 2);
  V v_d_2414 = ({ V b_0 = heff_strSlice_lent(v_s_241, MK_INT(0LL), v_eAt_242, 6); V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2edotAt(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2416;
  if (heff_intLe_c(heff_strLength_lent(v_m_2413, 0), heff_dup(v_d_2414))) {
    heff_drop(v_m_2413);
    heff_drop(v_d_2414);
    v_t_2416 = MK_INT(0LL);
  } else {
    V v_t_2415 = heff_intSub(heff_strLength(v_m_2413), v_d_2414);
    v_t_2416 = heff_intSub(v_t_2415, MK_INT(1LL));
  }
  V v_f_2417 = heff_intSub(v_t_2412, v_t_2416);
  return ((HeffT3){{v_negative_240, v_f_247, v_f_2417}});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2eboundBy_24dps_str2, 3, "con");
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eboundBy_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eboundBy_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eboundBy_24dps(V v_pv_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PCon: {
    V v_args_244 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_24dps_lam0, 1, 1, (V[]){heff_dup(v_pv_240)}), v_args_244));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_246);
  }
  case TAG_PAtom: {
    V v_t_247 = heff_field(v_x2_241, 0);
    V v_kind_248 = heff_dup(heff_rfield(v_t_247, 0));
    V v_text_249 = heff_dup(heff_rfield(v_t_247, 1));
    if ((heff_strEq_c_lent(v_kind_248, ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str0), 2) && !heff_strEq_c_lent(v_text_249, ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str1), 2))) {
      heff_drop(v_kind_248);
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_text_249, NTAG(TAG_Nil)});
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2410);
    } else {
      if (heff_strEq_c(v_kind_248, ((V)&g_heff_2esyntax_2esurface_2eboundBy_24dps_str2))) {
        V v_t_2411 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_text_249)}));
        V v_t_2412 = (g_list_2eany(v_t_2411, v_pv_240));
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop(v_t_2412);
          V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_text_249, NTAG(TAG_Nil)});
          return heff_setField(v_d_242, MK_INT(1LL), v_t_2413);
        } else {
          heff_drop(v_text_249);
          heff_drop(v_t_2412);
          return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
        }
      } else {
        heff_drop(v_text_249);
        return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
      }
    }
  }
  case TAG_PParen: {
    V v_q_2415 = heff_field(v_x2_241, 1);
    V t_0 = v_pv_240;
    V t_1 = v_q_2415;
    V t_2 = v_d_242;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_PList: {
    V v_ps_2418 = heff_field(v_x2_241, 1);
    V v_t_2422 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_24dps_lam1, 1, 1, (V[]){heff_dup(v_pv_240)}), v_ps_2418));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2422);
  }
  case TAG_POp: {
    V v_l_2423 = heff_field(v_x2_241, 0);
    V v_q_2425 = heff_field(v_x2_241, 2);
    V v_t_2426 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_l_2423));
    V v_t_2427 = (g_heff_2esyntax_2esurface_2eboundBy(v_pv_240, v_q_2425));
    V v_t_2428 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2426, v_t_2427));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2428);
  }
  case TAG_PRec: {
    V v_fs_2430 = heff_field(v_x2_241, 1);
    V v_t_2434 = (g_heff_2esyntax_2esurface_2econcatMapS(heff_clo_n(g_heff_2esyntax_2esurface_2eboundBy_24dps_lam2, 1, 1, (V[]){heff_dup(v_pv_240)}), v_fs_2430));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2434);
  }
  case TAG_PField: {
    V v_q_2437 = heff_field(v_x2_241, 2);
    V t_0 = v_pv_240;
    V t_1 = v_q_2437;
    V t_2 = v_d_242;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_PAs: {
    V v_x_2438 = heff_field(v_x2_241, 0);
    V v_q_2440 = heff_field(v_x2_241, 2);
    V v_cell_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_2438, 1)), heff_hole()});
    V v_u_2442 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2441));
    heff_drop(v_u_2442);
    V t_0 = v_pv_240;
    V t_1 = v_q_2440;
    V t_2 = v_cell_2441;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_PSeg: {
    V v_q_2443 = heff_field(v_x2_241, 0);
    V t_0 = v_pv_240;
    V t_1 = v_q_2443;
    V t_2 = v_d_242;
    v_pv_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eboundBy_24dps(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam0(V self, V *args) {
  V v_q_245 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_245; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_245); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam1(V self, V *args) {
  V v_q_2421 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2421; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2421); r_; });
}
V g_heff_2esyntax_2esurface_2eboundBy_24dps_lam2(V self, V *args) {
  V v_q_2433 = args[0];
  V v_pv_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_pv_240; V a_1 = v_q_2433; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_pv_240); heff_drop(v_q_2433); r_; });
}
Clo g_heff_2esyntax_2esurface_2easNameE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2easNameE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2easNameE(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ETag: {
      V v_x_245 = heff_field(v_e1_241, 0);
      V v_ru_24e1_241_24ETag = heff_take_reuse_n(v_e1_241, 1ULL, 1);
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_sp_247 = heff_field(v_e_240, 1);
        V v_ru_24e_240_24At = heff_take_reuse_n(v_e_240, 2ULL, 2);
        return heff_tag_at_n(v_ru_24e_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ETag, TAG_EVar, 1, (V[]){v_x_245}), v_sp_247});
      }
      default: return heff_nomatch(v_e_240);
      }
    }
    case TAG_EInt: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EFloat: {
      heff_take_nf(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EString: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ERune: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EWord: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EApp: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EProject: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EPi: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      return v_e_240;
    }
    case TAG_ESig: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ESum: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EDo: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_241, 0ULL, 3);
      return v_e_240;
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EFor: {
      heff_take_n(v_e1_241, 0ULL, 3);
      return v_e_240;
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return v_e_240;
    }
    case TAG_EBreak: {
      return v_e_240;
    }
    case TAG_EContinue: {
      return v_e_240;
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ENest: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ELazy: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ETuple: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_ETry: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return v_e_240;
    }
    case TAG_EWith: {
      heff_take_n(v_e1_241, 0ULL, 4);
      return v_e_240;
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2easNameE(a[0]);
}
Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecatMaybesS_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ecatMaybesS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2esyntax_2esurface_2ecatMaybesS_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecatMaybesS(a[0]);
}
Clo g_heff_2esyntax_2esurface_2egroupFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2egroupFrom_entry, 2, 0};

V g_heff_2esyntax_2esurface_2egroupFrom(V v_sp_240, V v_x2_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2esyntax_2esurface_2egroupFrom_24cpr(v_sp_240, v_x2_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    return heff_rec_n(3, shape_sigs__held__rest, (V[]){v_field_243, v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2esurface_2egroupFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2egroupFrom(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EField: {
    V v_e_242 = heff_field(v_x1_240, 0);
    V v_f_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EField = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V t_0 = v_e_242;
    V t_1 = heff_tag_at_n(v_ru_24x1_240_24EField, TAG_Cons, 2, (V[]){v_f_243, v_acc_241});
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: {
    return ((HeffT2){{v_x1_240, v_acc_241}});
  }
  }
}
Clo g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664_entry, 4, 0};

V g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop_rec(v_lit_241, 2);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_a_246 = (g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664(heff_dup(v_lit_240), heff_dup(v_lit_241), v_z_242, v_xs_245));
    V v_t_247 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_a_246), NTAG(TAG_Nil)});
    V v_t_248 = heff_tag_n(TAG_PatTag, 3, (V[]){v_lit_240, heff_dup(v_lit_241), heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_247})});
    V v_t_2411;
    switch (heff_tag_of(v_a_246)) {
    case TAG_At: {
      V v_a_2410 = heff_field(v_a_246, 1);
      heff_take_n(v_a_246, 2ULL, 2);
      v_t_2411 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_a_246);
    }
    V v_t_2412 = ({ V rv_1 = heff_get_n(v_t_2411, 1, 2); V rr_ = heff_rec_reuse_nf(v_lit_241, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    return heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_t_2412});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efoldr_24s668758492x783686664(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldL_str0, 24, "a field is `name : Type`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldL_str1, 1, "=");
HEFF_LIT(g_heff_2esyntax_2esurface_2efieldL_str2, 24, "a field is `name : Type`");
V g_heff_2esyntax_2esurface_2efieldL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2efieldL_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efieldL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efieldL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efieldL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EFDefault: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_eq_243 = heff_field(v_x2_241, 1);
    V v_d_244 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_242}));
    return heff_tail(((V)&g_heff_2esyntax_2esurface_2ebind_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam0, 1, 1, (V[]){v_m_245}), heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam1, 2, 3, (V[]){v_r_240, v_d_244, v_eq_243})});
  }
  default: {
    V v_m_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2efieldL_lam2, 1, 1, (V[]){v_m_2426});
  }
  }
}
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efieldL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2efieldL_lam0(V self, V *args) {
  V v_st_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_st_246}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Left = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_248_24Left, TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      V v_t_2412 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2411));
      V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2412}));
      return (g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(v_ru_24x1_247_24MkPair, MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2efieldL_str0), v_t_2413, v_st_249));
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam1(V self, V *args) {
  V v_e_27_2414 = args[0];
  V v_z_2415 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_d_244 = heff_env(self)[1];
  V v_eq_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_m_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_244}));
  V v_x1_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_z_2415}));
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_MkPair: {
    V v_x11_2418 = heff_field(v_x1_2417, 0);
    V v_st_2419 = heff_field(v_x1_2417, 1);
    V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
    switch (heff_tag_of(v_x11_2418)) {
    case TAG_Left: {
      V v_e_2420 = heff_field(v_x11_2418, 0);
      V v_ru_24x11_2418_24Left = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
      heff_drop(v_e_27_2414);
      heff_drop_rec(v_eq_243, 9);
      return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2418_24Left, TAG_Left, 1, (V[]){v_e_2420}), v_st_2419});
    }
    case TAG_Right: {
      V v_x_2421 = heff_field(v_x11_2418, 0);
      V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
      V v_x_2425;
      if (heff_strEq_c(heff_get_n(v_eq_243, 1, 9), ((V)&g_heff_2esyntax_2esurface_2efieldL_str1))) {
        v_x_2425 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_e_27_2414, heff_tag_n(TAG_Just, 1, (V[]){v_x_2421})));
      } else {
        heff_drop(v_x_2421);
        V v_t_2424;
        switch (heff_tag_of(v_e_27_2414)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_e_27_2414, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_e_27_2414);
        }
        v_x_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_27_2414}), v_t_2424});
      }
      return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_Right, 1, (V[]){v_x_2425}), v_st_2419});
    }
    default: return heff_nomatch(v_x11_2418);
    }
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
V g_heff_2esyntax_2esurface_2efieldL_lam2(V self, V *args) {
  V v_st_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_st_2427}));
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_MkPair: {
    V v_x11_2429 = heff_field(v_x1_2428, 0);
    V v_st_2430 = heff_field(v_x1_2428, 1);
    V v_ru_24x1_2428_24MkPair = heff_take_reuse_n(v_x1_2428, 3ULL, 2);
    switch (heff_tag_of(v_x11_2429)) {
    case TAG_Left: {
      V v_e_2431 = heff_field(v_x11_2429, 0);
      V v_ru_24x11_2429_24Left = heff_take_reuse_n(v_x11_2429, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2429_24Left, TAG_Left, 1, (V[]){v_e_2431}), v_st_2430});
    }
    case TAG_Right: {
      V v_x_2432 = heff_field(v_x11_2429, 0);
      V v_ru_24x11_2429_24Right = heff_take_reuse_n(v_x11_2429, 1ULL, 1);
      V v_t_2433 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2432));
      V v_t_2434 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_2433}));
      HeffT2 v_t_2435 = (g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24cpr(MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2efieldL_str2), v_t_2434, v_st_2430));
      {
        V v_field_2436 = v_t_2435.f[0];
        V v_field_2437 = v_t_2435.f[1];
        V v_x11_2438 = v_field_2436;
        V v_st_2439 = v_field_2437;
        switch (heff_tag_of(v_x11_2438)) {
        case TAG_Left: {
          V v_e_2440 = heff_field(v_x11_2438, 0);
          V v_ru_24x11_2438_24Left = heff_take_reuse_n(v_x11_2438, 1ULL, 1);
          heff_drop_cell(v_ru_24x11_2429_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2438_24Left, TAG_Left, 1, (V[]){v_e_2440}), v_st_2439});
        }
        case TAG_Right: {
          V v_x_2441 = heff_field(v_x11_2438, 0);
          heff_take_n(v_x11_2438, 1ULL, 1);
          V v_x_2442 = (g_heff_2esyntax_2esurface_2efieldDeclOf(v_x_2441, NTAG(TAG_Nothing)));
          return heff_tag_at_n(v_ru_24x1_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2429_24Right, TAG_Right, 1, (V[]){v_x_2442}), v_st_2439});
        }
        default: return heff_nomatch(v_x11_2438);
        }
      }
    }
    default: return heff_nomatch(v_x11_2429);
    }
  }
  default: return heff_nomatch(v_x1_2428);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2esettingL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2esettingL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esettingL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2esettingL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EFSet: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_e_244 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    V v_text_245 = heff_take_field(v_x_242, 1);
    V v_start_246 = heff_take_field(v_x_242, 3);
    V v_end_247 = heff_get_n(v_x_242, 4, 9);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_244}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam0, 1, 4, (V[]){v_m_248, v_text_245, v_start_246, v_end_247});
  }
  default: {
    V v_m_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2esettingL_lam1, 1, 1, (V[]){v_m_2421});
  }
  }
}
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esettingL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2esettingL_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_text_245 = heff_env(self)[1];
  V v_start_246 = heff_env(self)[2];
  V v_end_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_st_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Left = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_text_245);
      heff_drop(v_start_246);
      heff_drop(v_end_247);
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2411_24Left, TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Right = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      V v_t_2415 = heff_tag_n(TAG_SetField, 3, (V[]){v_text_245, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_246), v_end_247}), heff_dup(v_x_2414)});
      V v_t_2418;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_At: {
        V v_s_2417 = heff_field(v_x_2414, 1);
        heff_take_n(v_x_2414, 2ULL, 2);
        v_t_2418 = v_s_2417;
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2419 = ({ V rv_0 = v_start_246; V rr_ = heff_rec_reuse_nf(v_t_2418, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2420 = heff_tag_at_n(v_ru_24x11_2411_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_t_2419})});
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2420, v_st_2412});
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
V g_heff_2esyntax_2esurface_2esettingL_lam1(V self, V *args) {
  V v_st_2422 = args[0];
  V v_m_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2423 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_st_2422}));
  switch (heff_tag_of(v_x1_2423)) {
  case TAG_MkPair: {
    V v_x11_2424 = heff_field(v_x1_2423, 0);
    V v_st_2425 = heff_field(v_x1_2423, 1);
    V v_ru_24x1_2423_24MkPair = heff_take_reuse_n(v_x1_2423, 3ULL, 2);
    switch (heff_tag_of(v_x11_2424)) {
    case TAG_Left: {
      V v_e_2426 = heff_field(v_x11_2424, 0);
      V v_ru_24x11_2424_24Left = heff_take_reuse_n(v_x11_2424, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2424_24Left, TAG_Left, 1, (V[]){v_e_2426}), v_st_2425});
    }
    case TAG_Right: {
      V v_x_2427 = heff_field(v_x11_2424, 0);
      V v_ru_24x11_2424_24Right = heff_take_reuse_n(v_x11_2424, 1ULL, 1);
      V v_t_2430;
      switch (heff_tag_of(v_x_2427)) {
      case TAG_At: {
        V v_s_2429 = heff_dup(heff_field(v_x_2427, 1));
        v_t_2430 = v_s_2429;
        break;
      }
      default: heff_nomatch(v_x_2427);
      }
      V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_x_2427}), v_t_2430});
      return heff_tag_at_n(v_ru_24x1_2423_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2424_24Right, TAG_Right, 1, (V[]){v_t_2431}), v_st_2425});
    }
    default: return heff_nomatch(v_x11_2424);
    }
  }
  default: return heff_nomatch(v_x1_2423);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str1, 33, "` is named twice in one signature");
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str3, 33, "` is named twice in one signature");

HeffT2 g_heff_2esyntax_2esurface_2erepeatedField_24cpr(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_Left: {
      V v_x_244 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_text_245 = heff_take_field(v_x_244, 1);
      V v_start_246 = heff_take_field(v_x_244, 3);
      V v_end_247 = heff_get_n(v_x_244, 4, 9);
      V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_text_245)}));
      V v_t_249 = (g_list_2eany(v_t_248, v_seen_240));
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_seen_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_249);
        V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str0), v_text_245), ((V)&g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str1));
        V v_f_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2410, heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247}), NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
      } else {
        heff_drop(v_start_246);
        heff_drop(v_end_247);
        heff_drop(v_t_249);
        V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_text_245, v_seen_240});
        V t_1 = v_rest_243;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_Right: {
      V v_x211_2412 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      switch (heff_tag_of(v_x211_2412)) {
      case TAG_At: {
        V v_x2111_2413 = heff_field(v_x211_2412, 0);
        heff_take_n(v_x211_2412, 1ULL, 2);
        switch (heff_tag_of(v_x2111_2413)) {
        case TAG_DeclareField: {
          V v_f_2415 = heff_field(v_x2111_2413, 0);
          V v_fsp_2416 = heff_field(v_x2111_2413, 1);
          heff_take_n(v_x2111_2413, 3ULL, 4);
          V v_t_2419 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_f_2415)}));
          V v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = v_seen_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_seen_240); r_; });
          if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
            heff_drop(v_rest_243);
            heff_drop(v_t_2420);
            V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str2), v_f_2415), ((V)&g_heff_2esyntax_2esurface_2erepeatedField_24cpr_str3));
            V v_f_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2421, v_fsp_2416, NTAG(TAG_Nothing)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2422}});
          } else {
            heff_drop(v_f_2415);
            heff_drop(v_fsp_2416);
            heff_drop(v_t_2420);
            V t_0 = NTAG(TAG_Nil);
            V t_1 = v_rest_243;
            v_seen_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          }
        }
        case TAG_BadFieldDecl: {
          heff_take_n(v_x2111_2413, 0ULL, 1);
          heff_drop(v_seen_240);
          V t_0 = NTAG(TAG_Nil);
          V t_1 = v_rest_243;
          v_seen_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return ((HeffT2){{heff_nomatch(v_x2111_2413)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x211_2412)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2esyntax_2esurface_2epatTags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatTags_entry, 2, 0};

V g_heff_2esyntax_2esurface_2epatTags(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatTag: {
      V v_tsp_246 = heff_field(v_x11_242, 1);
      V v_ps_247 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 6ULL, 3);
      V v_t_248 = ({ V a_0 = v_acc_241; V a_1 = v_ps_247; V r_ = (g_list_2efoldl_24s1413159824x1120446397(a_0, a_1)); heff_drop(v_ps_247); r_; });
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_tsp_246, v_t_248});
    }
    case TAG_PatOp: {
      V v_xsp_2410 = heff_field(v_x11_242, 1);
      V v_ps_2411 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 6ULL, 3);
      V v_t_2412 = ({ V a_0 = v_acc_241; V a_1 = v_ps_2411; V r_ = (g_list_2efoldl_24s1413159824x1120446397(a_0, a_1)); heff_drop(v_ps_2411); r_; });
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_xsp_2410, v_t_2412});
    }
    case TAG_PatInt: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatFloat: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatString: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatBinary: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatRune: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatRecord: {
      V v_fs_2418 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return ({ V a_0 = v_acc_241; V a_1 = v_fs_2418; V r_ = (g_list_2efoldl_24s415128528x640682339(a_0, a_1)); heff_drop(v_fs_2418); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatAs: {
      V v_p_2422 = heff_field(v_x11_242, 2);
      heff_take_n(v_x11_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24At, 2);
      V t_0 = v_p_2422;
      V t_1 = v_acc_241;
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2epatTags_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epatTags(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str0, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ealtL_str1, 1, "`");
V g_heff_2esyntax_2esurface_2ealtL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ealtL_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ealtL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ealtL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ealtL(V v_r_240, V v_x2_241) {
top: ;
  V v_pat_242 = heff_take_field(v_r_240, 1);
  V v_e_243 = heff_get_n(v_r_240, 0, 3);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EAlt: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_e_246 = heff_field(v_x2_241, 2);
    V v_m_247 = heff_tr(heff_call(v_pat_242, 1, (V[]){heff_dup(v_p_244)}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam0, 1, 4, (V[]){v_m_247, heff_dup(v_p_244), v_e_243, heff_dup(v_e_246)});
  }
  default: {
    heff_drop(v_pat_242);
    heff_drop(v_e_243);
    V v_t_2430 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_start_2431 = heff_take_field(v_t_2430, 3);
    V v_end_2432 = heff_get_n(v_t_2430, 4, 9);
    V v_t_2433 = (g_heff_2esyntax_2ecst_2efirstE(v_x2_241));
    V v_t_2434 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ealtL_str0), heff_get_n(v_t_2433, 1, 9));
    V v_msg_2435 = heff_strAppend(v_t_2434, ((V)&g_heff_2esyntax_2esurface_2ealtL_str1));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam2, 1, 3, (V[]){v_msg_2435, v_start_2431, v_end_2432});
  }
  }
}
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2ealtL(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2ealtL_lam1(V self, V *args) {
  V v_st_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_st_2416}));
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_MkPair: {
    V v_x11_2418 = heff_field(v_x1_2417, 0);
    V v_st_2419 = heff_field(v_x1_2417, 1);
    V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
    switch (heff_tag_of(v_x11_2418)) {
    case TAG_Left: {
      V v_e_2420 = heff_field(v_x11_2418, 0);
      V v_ru_24x11_2418_24Left = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
      heff_drop(v_x_2413);
      return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2418_24Left, TAG_Left, 1, (V[]){v_e_2420}), v_st_2419});
    }
    case TAG_Right: {
      V v_x_2421 = heff_field(v_x11_2418, 0);
      V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 1ULL, 1);
      V v_t_2424;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_At: {
        V v_s_2423 = heff_dup(heff_field(v_x_2413, 1));
        v_t_2424 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      V v_t_2427;
      switch (heff_tag_of(v_x_2421)) {
      case TAG_At: {
        V v_s_2426 = heff_dup(heff_field(v_x_2421, 1));
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_x_2421);
      }
      V v_t_2428 = ({ V rv_1 = heff_get_n(v_t_2427, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2424, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_x_2413, v_x_2421}), v_t_2428});
      return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_Right, 1, (V[]){v_t_2429}), v_st_2419});
    }
    default: return heff_nomatch(v_x11_2418);
    }
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_lam0(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_e_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_p_244);
      heff_drop(v_e_243);
      heff_drop(v_e_246);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_p_244; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop(v_p_244); r_; });
      V v_m_2415 = heff_tr(heff_call(v_e_243, 1, (V[]){v_e_246}));
      return (g_heff_2esyntax_2esurface_2ewithScope_24tok2(v_ru_24x1_249_24MkPair, v_t_2414, heff_clo_n(g_heff_2esyntax_2esurface_2ealtL_lam1, 1, 2, (V[]){v_m_2415, v_x_2413}), v_st_2411));
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2esyntax_2esurface_2ealtL_lam2(V self, V *args) {
  V v_st_2436 = args[0];
  V v_msg_2435 = heff_env(self)[0];
  V v_start_2431 = heff_env(self)[1];
  V v_end_2432 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2435, heff_rec_n(2, shape_start__end, (V[]){v_start_2431, v_end_2432}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2437}), v_st_2436});
}
Clo g_heff_2esyntax_2esurface_2eunitIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eunitIn_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eunitIn(V v_ty_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_ty_240)) {
    case TAG_SegmentInteger: {
      return MK_INT(1LL);
    }
    case TAG_SegmentBinary: {
      return MK_INT(8LL);
    }
    case TAG_SegmentBits: {
      return MK_INT(1LL);
    }
    case TAG_SegmentFloat: {
      return MK_INT(1LL);
    }
    case TAG_SegmentUtf: {
      return MK_INT(1LL);
    }
    default: return heff_nomatch(v_ty_240);
    }
  }
  case TAG_Just: {
    V v_u_243 = heff_field(v_x2_241, 0);
    return heff_dup(v_u_243);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eunitIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eunitIn(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str0, 45, "an integer's segment is of 1 to 64 bits, not ");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str1, 17, " does not fit in ");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str3, 10, ", unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str4, 8, ", signed");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str5, 10, ", unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str6, 5, " bits");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str7, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str8, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str9, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str10, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str11, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str12, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str13, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str14, 64, "bits are of no endianness nor sign: `x::bits`, `x::bits-size(3)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str15, 64, "bits are of no endianness nor sign: `x::bits`, `x::bits-size(3)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str16, 43, "a float's segment is of 32 or 64 bits, not ");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str17, 51, "a float's size is a number, 32 or 64: `x::float-32`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str18, 55, "a float is of no sign: `x::float`, `x::float-32-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str19, 36, "UTF-8 is of no endianness: `c::utf8`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str20, 35, "a code point is of no sign: `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str21, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str22, 6, "a `utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str23, 64, "` segment is as long as its code point: it says no size, `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str25, 35, "a code point is of no sign: `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str27, 6, "a `utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str28, 64, "` segment is as long as its code point: it says no size, `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str29, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str30, 35, "a code point is of no sign: `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_str31, 1, "`");
V g_heff_2esyntax_2esurface_2etypeChecks_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam2(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam2, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam3(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam3, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam5(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam5, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam6(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam6, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam7(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam7, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam8(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam8, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam16(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam16, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam17(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam17, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam18(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam18, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam22(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam22, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam24(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etypeChecks_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_lam24, 1, 0};
V g_heff_2esyntax_2esurface_2etypeChecks_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2etypeChecks_lam29(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etypeChecks_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etypeChecks_entry, 6, 0};

V g_heff_2esyntax_2esurface_2etypeChecks(V v_inPat_240, V v_sp_241, V v_v_242, V v_s_243, V v_x5_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_SegmentInteger: {
    V v_inPat_246 = v_inPat_240;
    V v_sp_247 = v_sp_241;
    V v_v_248 = v_v_242;
    V v_s_249 = v_s_243;
    V v_x5_2414;
    switch (heff_tag_of(v_x6_245)) {
    case TAG_SizeDefault: {
      v_x5_2414 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(8LL)});
      break;
    }
    case TAG_SizeNumber: {
      V v_n_2410 = heff_field(v_x6_245, 0);
      V v_ru_24x6_245_24SizeNumber = heff_take_reuse_n(v_x6_245, 1ULL, 1);
      v_x5_2414 = heff_tag_at_n(v_ru_24x6_245_24SizeNumber, TAG_Just, 1, (V[]){v_n_2410});
      break;
    }
    case TAG_SizeName: {
      heff_take_n(v_x6_245, 0ULL, 3);
      v_x5_2414 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x6_245);
    }
    switch (heff_tag_of(v_x5_2414)) {
    case TAG_Nothing: {
      heff_drop(v_inPat_246);
      heff_drop(v_sp_247);
      heff_drop(v_v_248);
      heff_drop(v_s_249);
      return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam0_clo);
    }
    case TAG_Just: {
      V v_n_2417 = heff_field(v_x5_2414, 0);
      heff_take_n(v_x5_2414, 1ULL, 1);
      if ((heff_intLt_c_lent(v_n_2417, MK_INT(1LL), 2) || heff_intLt_c_lent(MK_INT(64LL), v_n_2417, 1))) {
        heff_drop(v_inPat_246);
        heff_drop(v_v_248);
        heff_drop(v_s_249);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam1, 1, 2, (V[]){v_n_2417, v_sp_247});
      } else {
        V v_inPat_2421 = v_inPat_246;
        V v_sp_2422 = v_sp_247;
        V v_x3_2423 = v_v_248;
        V v_s_2424 = v_s_249;
        V v_n_2425 = v_n_2417;
        switch (heff_tag_of(v_x3_2423)) {
        case TAG_StrValue: {
          heff_drop(v_inPat_2421);
          heff_drop(v_sp_2422);
          heff_drop_rec(v_s_2424, 5);
          heff_drop(v_n_2425);
          return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam2_clo);
        }
        case TAG_IntValue: {
          V v_v_2428 = heff_field(v_x3_2423, 0);
          heff_take_n(v_x3_2423, 1ULL, 1);
          V v_x1_2429 = heff_dup(v_inPat_2421);
          V v_t_2430 = heff_dup(heff_rfield(v_s_2424, 4));
          V v_signed_2432;
          switch (heff_tag_of(v_t_2430)) {
          case TAG_Nothing: {
            v_signed_2432 = NTAG(TAG_False);
            break;
          }
          case TAG_Just: {
            V v_b_2431 = heff_field(v_t_2430, 0);
            heff_take_n(v_t_2430, 1ULL, 1);
            v_signed_2432 = v_b_2431;
            break;
          }
          default: heff_nomatch(v_t_2430);
          }
          V v_n_2433 = heff_dup(v_n_2425);
          V v_v_2434 = heff_dup(v_v_2428);
          if (((heff_dup(v_x1_2429) == NTAG(TAG_True)) ? ((heff_dup(v_signed_2432) == NTAG(TAG_True)) ? ({ V v_t_2435 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((heff_peek_word(v_n_2433) - ((int64_t)1ULL))))); int c_ = ({ V v_t_24145 = heff_intSub(MK_INT(0LL), heff_dup(v_t_2435)); int c_ = (heff_intLe_c_lent(v_t_24145, v_v_2434, 0) && ({ V v_t_24146 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((heff_peek_word(v_n_2433) - ((int64_t)1ULL))))); int c_ = heff_intLt_c_lent(v_v_2434, v_t_24146, 0); heff_drop(v_t_24146); c_; })); heff_drop(v_t_24145); c_; }); heff_drop(v_t_2435); c_; }) : (heff_intLe_c_lent(MK_INT(0LL), v_v_2434, 1) && ({ V v_t_24147 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_2433))); int c_ = heff_intLt_c_lent(v_v_2434, v_t_24147, 0); heff_drop(v_t_24147); c_; }))) : ({ V v_t_2436 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((heff_peek_word(v_n_2433) - ((int64_t)1ULL))))); int c_ = ({ V v_t_24148 = heff_intSub(MK_INT(0LL), heff_dup(v_t_2436)); int c_ = (heff_intLe_c_lent(v_t_24148, v_v_2434, 0) && ({ V v_t_24149 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_2433))); int c_ = heff_intLt_c_lent(v_v_2434, v_t_24149, 0); heff_drop(v_t_24149); c_; })); heff_drop(v_t_24148); c_; }); heff_drop(v_t_2436); c_; }))) {
            heff_drop(v_inPat_2421);
            heff_drop(v_sp_2422);
            heff_drop_rec(v_s_2424, 5);
            heff_drop(v_n_2425);
            heff_drop(v_v_2428);
            heff_drop(v_x1_2429);
            heff_drop(v_signed_2432);
            heff_drop(v_n_2433);
            heff_drop(v_v_2434);
            return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam3_clo);
          } else {
            heff_drop(v_x1_2429);
            heff_drop(v_signed_2432);
            heff_drop(v_n_2433);
            heff_drop(v_v_2434);
            return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam4, 1, 5, (V[]){v_v_2428, v_n_2425, v_inPat_2421, v_s_2424, v_sp_2422});
          }
        }
        case TAG_FloatValue: {
          heff_drop(v_inPat_2421);
          heff_drop(v_sp_2422);
          heff_drop_rec(v_s_2424, 5);
          heff_drop(v_n_2425);
          return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam5_clo);
        }
        case TAG_RuneValue: {
          heff_drop(v_inPat_2421);
          heff_drop(v_sp_2422);
          heff_drop_rec(v_s_2424, 5);
          heff_drop(v_n_2425);
          return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam6_clo);
        }
        case TAG_OtherValue: {
          heff_drop(v_inPat_2421);
          heff_drop(v_sp_2422);
          heff_drop_rec(v_s_2424, 5);
          heff_drop(v_n_2425);
          return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam7_clo);
        }
        default: return heff_nomatch(v_x3_2423);
        }
      }
    }
    default: return heff_nomatch(v_x5_2414);
    }
  }
  case TAG_SegmentBinary: {
    heff_drop(v_inPat_240);
    heff_drop(v_x6_245);
    switch (heff_tag_of(v_v_242)) {
    case TAG_StrValue: {
      V v_t_2453 = heff_take_field(v_s_243, 1);
      switch (heff_tag_of(v_t_2453)) {
      case TAG_SizeDefault: {
        V v_t_2454 = heff_take_field(v_s_243, 3);
        switch (heff_tag_of(v_t_2454)) {
        case TAG_Nothing: {
          V v_t_2455 = heff_get_n(v_s_243, 4, 5);
          switch (heff_tag_of(v_t_2455)) {
          case TAG_Nothing: {
            heff_drop(v_sp_241);
            return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam8_clo);
          }
          case TAG_Just: {
            heff_take_n(v_t_2455, 0ULL, 1);
            return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam9, 1, 1, (V[]){v_sp_241});
          }
          default: return heff_nomatch(v_t_2455);
          }
        }
        case TAG_Just: {
          heff_take_n(v_t_2454, 0ULL, 1);
          heff_drop_rec(v_s_243, 5);
          return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam10, 1, 1, (V[]){v_sp_241});
        }
        default: return heff_nomatch(v_t_2454);
        }
      }
      case TAG_SizeNumber: {
        heff_take_n(v_t_2453, 0ULL, 1);
        heff_drop_rec(v_s_243, 5);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam11, 1, 1, (V[]){v_sp_241});
      }
      case TAG_SizeName: {
        heff_take_n(v_t_2453, 0ULL, 3);
        heff_drop_rec(v_s_243, 5);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam12, 1, 1, (V[]){v_sp_241});
      }
      default: return heff_nomatch(v_t_2453);
      }
    }
    default: {
      heff_drop(v_v_242);
      V v_t_2472 = heff_dup(heff_rfield(v_s_243, 2));
      V v_t_2474;
      switch (heff_tag_of(v_t_2472)) {
      case TAG_Nothing: {
        v_t_2474 = MK_INT(8LL);
        break;
      }
      case TAG_Just: {
        V v_u_2473 = heff_field(v_t_2472, 0);
        heff_take_n(v_t_2472, 1ULL, 1);
        v_t_2474 = v_u_2473;
        break;
      }
      default: heff_nomatch(v_t_2472);
      }
      if (!(heff_unbox_word(heff_intMod(heff_dup(v_t_2474), MK_INT(8LL))) == ((int64_t)0ULL))) {
        heff_drop_rec(v_s_243, 5);
        heff_drop(v_t_2474);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam13, 1, 1, (V[]){v_sp_241});
      } else {
        heff_drop(v_t_2474);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam14, 1, 2, (V[]){v_s_243, v_sp_241});
      }
    }
    }
  }
  case TAG_SegmentBits: {
    heff_drop(v_inPat_240);
    heff_drop(v_v_242);
    heff_drop(v_x6_245);
    return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam15, 1, 2, (V[]){v_s_243, v_sp_241});
  }
  case TAG_SegmentFloat: {
    heff_drop(v_inPat_240);
    heff_drop(v_v_242);
    V v_t_2493 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2493)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x6_245)) {
      case TAG_SizeDefault: {
        heff_drop(v_sp_241);
        return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam16_clo);
      }
      case TAG_SizeNumber: {
        V v_x61_2496 = heff_field(v_x6_245, 0);
        heff_take_n(v_x6_245, 1ULL, 1);
        if (heff_intEq_c_lent(v_x61_2496, MK_INT(64LL), 2)) {
          heff_drop(v_sp_241);
          heff_drop(v_x61_2496);
          return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam17_clo);
        } else {
          if (heff_intEq_c_lent(v_x61_2496, MK_INT(32LL), 2)) {
            heff_drop(v_sp_241);
            heff_drop(v_x61_2496);
            return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam18_clo);
          } else {
            return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam19, 1, 2, (V[]){v_x61_2496, v_sp_241});
          }
        }
      }
      case TAG_SizeName: {
        heff_take_n(v_x6_245, 0ULL, 3);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam20, 1, 1, (V[]){v_sp_241});
      }
      default: return heff_nomatch(v_x6_245);
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2493, 0ULL, 1);
      heff_drop(v_x6_245);
      return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam21, 1, 1, (V[]){v_sp_241});
    }
    default: return heff_nomatch(v_t_2493);
    }
  }
  case TAG_SegmentUtf: {
    V v_w_24112 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    heff_drop(v_inPat_240);
    heff_drop(v_v_242);
    heff_drop(v_x6_245);
    V v_signed_24113 = heff_take_field(v_s_243, 4);
    V v_t_24114 = heff_take_field(v_s_243, 1);
    switch (heff_tag_of(v_t_24114)) {
    case TAG_SizeDefault: {
      V v_t_24115 = heff_take_field(v_s_243, 2);
      switch (heff_tag_of(v_t_24115)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_signed_24113)) {
        case TAG_Nothing: {
          V v_t_24116 = heff_get_n(v_s_243, 3, 5);
          switch (heff_tag_of(v_t_24116)) {
          case TAG_Nothing: {
            heff_drop(v_sp_241);
            heff_drop(v_w_24112);
            return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam22_clo);
          }
          case TAG_Just: {
            heff_take_n(v_t_24116, 0ULL, 1);
            if (heff_intEq_c(v_w_24112, MK_INT(8LL))) {
              return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam23, 1, 1, (V[]){v_sp_241});
            } else {
              heff_drop(v_sp_241);
              return ((V)&g_heff_2esyntax_2esurface_2etypeChecks_lam24_clo);
            }
          }
          default: return heff_nomatch(v_t_24116);
          }
        }
        case TAG_Just: {
          heff_take_n(v_signed_24113, 0ULL, 1);
          heff_drop_rec(v_s_243, 5);
          return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam25, 1, 2, (V[]){v_w_24112, v_sp_241});
        }
        default: return heff_nomatch(v_signed_24113);
        }
      }
      case TAG_Just: {
        heff_take_n(v_t_24115, 0ULL, 1);
        heff_drop_rec(v_s_243, 5);
        switch (heff_tag_of(v_signed_24113)) {
        case TAG_Nothing: {
          return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam26, 1, 2, (V[]){v_w_24112, v_sp_241});
        }
        case TAG_Just: {
          heff_take_n(v_signed_24113, 0ULL, 1);
          return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam27, 1, 2, (V[]){v_w_24112, v_sp_241});
        }
        default: return heff_nomatch(v_signed_24113);
        }
      }
      default: return heff_nomatch(v_t_24115);
      }
    }
    default: {
      heff_drop_rec(v_s_243, 5);
      heff_drop(v_t_24114);
      switch (heff_tag_of(v_signed_24113)) {
      case TAG_Nothing: {
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam28, 1, 2, (V[]){v_w_24112, v_sp_241});
      }
      case TAG_Just: {
        heff_take_n(v_signed_24113, 0ULL, 1);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etypeChecks_lam29, 1, 2, (V[]){v_w_24112, v_sp_241});
      }
      default: return heff_nomatch(v_signed_24113);
      }
    }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etypeChecks(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam0(V self, V *args) {
  V v_st_2415 = args[0];
  V v_t_2416 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_st_2415});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam1(V self, V *args) {
  V v_st_2418 = args[0];
  V v_n_2417 = heff_env(self)[0];
  V v_sp_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str0), heff_intShow(v_n_2417));
  V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2419, v_sp_247, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2420}), v_st_2418});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam2(V self, V *args) {
  V v_st_2426 = args[0];
  V v_t_2427 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2427, v_st_2426});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam3(V self, V *args) {
  V v_st_2437 = args[0];
  V v_t_2438 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2438, v_st_2437});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam4(V self, V *args) {
  V v_st_2439 = args[0];
  V v_v_2428 = heff_env(self)[0];
  V v_n_2425 = heff_env(self)[1];
  V v_inPat_2421 = heff_env(self)[2];
  V v_s_2424 = heff_env(self)[3];
  V v_sp_2422 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2440 = heff_strAppend(heff_intShow(v_v_2428), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str1));
  V v_t_2441 = heff_strAppend(v_t_2440, heff_intShow(v_n_2425));
  V v_t_2444;
  if (!(heff_dup(v_inPat_2421) == NTAG(TAG_True))) {
    heff_drop(v_inPat_2421);
    heff_drop_rec(v_s_2424, 5);
    v_t_2444 = ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str2);
  } else {
    heff_drop(v_inPat_2421);
    V v_t_2442 = heff_get_n(v_s_2424, 4, 5);
    switch (heff_tag_of(v_t_2442)) {
    case TAG_Nothing: {
      v_t_2444 = ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str3);
      break;
    }
    case TAG_Just: {
      V v_b_2443 = heff_field(v_t_2442, 0);
      heff_take_n(v_t_2442, 1ULL, 1);
      if ((heff_dup(v_b_2443) == NTAG(TAG_True))) {
        heff_drop(v_b_2443);
        v_t_2444 = ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str4);
      } else {
        heff_drop(v_b_2443);
        v_t_2444 = ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str5);
      }
      break;
    }
    default: heff_nomatch(v_t_2442);
    }
  }
  V v_t_2445 = heff_strAppend(heff_strAppend(v_t_2441, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str6)), v_t_2444);
  V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2445, v_sp_2422, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2446}), v_st_2439});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam5(V self, V *args) {
  V v_st_2447 = args[0];
  V v_t_2448 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2448, v_st_2447});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam6(V self, V *args) {
  V v_st_2449 = args[0];
  V v_t_2450 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2450, v_st_2449});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam7(V self, V *args) {
  V v_st_2451 = args[0];
  V v_t_2452 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2452, v_st_2451});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam8(V self, V *args) {
  V v_st_2456 = args[0];
  V v_t_2457 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2457, v_st_2456});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam9(V self, V *args) {
  V v_st_2459 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2460 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str7), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2460}), v_st_2459});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam10(V self, V *args) {
  V v_st_2462 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2463 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str8), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2463}), v_st_2462});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam11(V self, V *args) {
  V v_st_2465 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str9), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2466}), v_st_2465});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam12(V self, V *args) {
  V v_st_2470 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2471 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str10), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2471}), v_st_2470});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam13(V self, V *args) {
  V v_st_2475 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2476 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str11), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2476}), v_st_2475});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam14(V self, V *args) {
  V v_p_2477 = args[0];
  V v_s_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2478 = heff_take_field(v_s_243, 3);
  switch (heff_tag_of(v_t_2478)) {
  case TAG_Nothing: {
    V v_t_2479 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2479)) {
    case TAG_Nothing: {
      heff_drop(v_sp_241);
      V v_t_2480 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2480, v_p_2477});
    }
    case TAG_Just: {
      V v_ru_24t_2479_24Just = heff_take_reuse_n(v_t_2479, 0ULL, 1);
      V v_t_2482 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str12), v_sp_241, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2479_24Just, TAG_Left, 1, (V[]){v_t_2482}), v_p_2477});
    }
    default: return heff_nomatch(v_t_2479);
    }
  }
  case TAG_Just: {
    V v_ru_24t_2478_24Just = heff_take_reuse_n(v_t_2478, 0ULL, 1);
    heff_drop_rec(v_s_243, 5);
    V v_t_2484 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str13), v_sp_241, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2478_24Just, TAG_Left, 1, (V[]){v_t_2484}), v_p_2477});
  }
  default: return heff_nomatch(v_t_2478);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam15(V self, V *args) {
  V v_p_2485 = args[0];
  V v_s_243 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2486 = heff_take_field(v_s_243, 3);
  switch (heff_tag_of(v_t_2486)) {
  case TAG_Nothing: {
    V v_t_2487 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2487)) {
    case TAG_Nothing: {
      heff_drop(v_sp_241);
      V v_t_2488 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2488, v_p_2485});
    }
    case TAG_Just: {
      V v_ru_24t_2487_24Just = heff_take_reuse_n(v_t_2487, 0ULL, 1);
      V v_t_2490 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str14), v_sp_241, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2487_24Just, TAG_Left, 1, (V[]){v_t_2490}), v_p_2485});
    }
    default: return heff_nomatch(v_t_2487);
    }
  }
  case TAG_Just: {
    V v_ru_24t_2486_24Just = heff_take_reuse_n(v_t_2486, 0ULL, 1);
    heff_drop_rec(v_s_243, 5);
    V v_t_2492 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str15), v_sp_241, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2486_24Just, TAG_Left, 1, (V[]){v_t_2492}), v_p_2485});
  }
  default: return heff_nomatch(v_t_2486);
  }
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam16(V self, V *args) {
  V v_st_2494 = args[0];
  V v_t_2495 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2495, v_st_2494});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam17(V self, V *args) {
  V v_st_2497 = args[0];
  V v_t_2498 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2498, v_st_2497});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam18(V self, V *args) {
  V v_st_2499 = args[0];
  V v_t_24100 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24100, v_st_2499});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam19(V self, V *args) {
  V v_st_24101 = args[0];
  V v_x61_2496 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24102 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str16), heff_intShow(v_x61_2496));
  V v_t_24103 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_24102, v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24103}), v_st_24101});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam20(V self, V *args) {
  V v_st_24107 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24108 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str17), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24108}), v_st_24107});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam21(V self, V *args) {
  V v_st_24110 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24111 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str18), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24111}), v_st_24110});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam22(V self, V *args) {
  V v_st_24117 = args[0];
  V v_t_24118 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24118, v_st_24117});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam23(V self, V *args) {
  V v_st_24120 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24121 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str19), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24121}), v_st_24120});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam24(V self, V *args) {
  V v_st_24122 = args[0];
  V v_t_24123 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24123, v_st_24122});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam25(V self, V *args) {
  V v_st_24125 = args[0];
  V v_w_24112 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24126 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str20), heff_intShow(v_w_24112));
  V v_t_24127 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_24126, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str21)), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24127}), v_st_24125});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam26(V self, V *args) {
  V v_st_24129 = args[0];
  V v_w_24112 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24130 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str22), heff_intShow(heff_dup(v_w_24112)));
  V v_t_24131 = heff_strAppend(heff_strAppend(v_t_24130, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str23)), heff_intShow(v_w_24112));
  V v_t_24132 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_24131, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str24)), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24132}), v_st_24129});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam27(V self, V *args) {
  V v_st_24134 = args[0];
  V v_w_24112 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24135 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str25), heff_intShow(v_w_24112));
  V v_t_24136 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_24135, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str26)), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24136}), v_st_24134});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam28(V self, V *args) {
  V v_st_24137 = args[0];
  V v_w_24112 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24138 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str27), heff_intShow(heff_dup(v_w_24112)));
  V v_t_24139 = heff_strAppend(heff_strAppend(v_t_24138, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str28)), heff_intShow(v_w_24112));
  V v_t_24140 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_24139, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str29)), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24140}), v_st_24137});
}
V g_heff_2esyntax_2esurface_2etypeChecks_lam29(V self, V *args) {
  V v_st_24142 = args[0];
  V v_w_24112 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24143 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_str30), heff_intShow(v_w_24112));
  V v_t_24144 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_24143, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_str31)), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24144}), v_st_24142});
}
Clo g_heff_2esyntax_2esurface_2evalueOfE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evalueOfE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2evalueOfE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ETag: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EInt: {
      V v_v_246 = heff_field(v_x11_241, 0);
      return heff_tag_n(TAG_IntValue, 1, (V[]){heff_dup(v_v_246)});
    }
    case TAG_EFloat: {
      return NTAG(TAG_FloatValue);
    }
    case TAG_EString: {
      return NTAG(TAG_StrValue);
    }
    case TAG_EBinary: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ERune: {
      return NTAG(TAG_RuneValue);
    }
    case TAG_EWord: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EApp: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EProject: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ENamed: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EPi: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELam: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EAnn: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ESpec: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ESig: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ESum: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EStruct: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EMatch: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EDo: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELocal: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EAssign: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EWhile: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EFor: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EBreak: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EContinue: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EReturn: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ENest: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ELazy: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ETuple: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_ETry: {
      return NTAG(TAG_OtherValue);
    }
    case TAG_EWith: {
      return NTAG(TAG_OtherValue);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2evalueOfE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2evalueOfE(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str0, 77, "a segment of a binary pattern holds a name, `_`, a number, a string or a rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str1, 101, "only the last segment takes what is left: say this one's size, `x::binary-size(n)`, `x::bits-size(n)`");
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641(V v_r_240, V v_last_241, V v_sp_242, V v_p_243) {
top: ;
  V v_x2_244 = heff_tr(g_heff_2esyntax_2esurface_2esegmentValue(v_p_243));
  return heff_tail(((V)&g_heff_2esyntax_2esurface_2ebind_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam0, 1, 2, (V[]){v_x2_244, heff_dup(v_sp_242)}), heff_clo_n(g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam1, 2, 4, (V[]){v_r_240, v_p_243, v_sp_242, heff_dup(v_last_241)})});
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_x2_244 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x2_244) == NTAG(TAG_True))) {
    heff_drop(v_x2_244);
    heff_drop(v_sp_242);
    V v_t_246 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_246, v_p_245});
  } else {
    heff_drop(v_x2_244);
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str0), v_sp_242, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_247}), v_p_245});
  }
}
V g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_z_249 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_last_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_248);
  V v_m_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 3), 1, (V[]){v_p_243}));
  V v_x1_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_z_249}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_MkPair: {
    V v_x11_2412 = heff_field(v_x1_2411, 0);
    V v_st_2413 = heff_field(v_x1_2411, 1);
    V v_ru_24x1_2411_24MkPair = heff_take_reuse_n(v_x1_2411, 3ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_Left: {
      V v_e_2414 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Left = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop(v_last_241);
      return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2412_24Left, TAG_Left, 1, (V[]){v_e_2414}), v_st_2413});
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Right = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      V v_inPat_2416 = NTAG(TAG_True);
      V v_sp_2417 = heff_dup(v_sp_242);
      V v_e_2418 = heff_dup(v_x_2415);
      V v_v_2438;
      switch (heff_tag_of(v_x_2415)) {
      case TAG_At: {
        V v_x11_2419 = heff_field(v_x_2415, 0);
        heff_take_n(v_x_2415, 1ULL, 2);
        switch (heff_tag_of(v_x11_2419)) {
        case TAG_PatVar: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          v_v_2438 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatTag: {
          heff_take_n(v_x11_2419, 0ULL, 3);
          v_v_2438 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatOp: {
          heff_take_n(v_x11_2419, 0ULL, 3);
          v_v_2438 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatInt: {
          V v_v_2428 = heff_field(v_x11_2419, 0);
          V v_ru_24x11_2419_24PatInt = heff_take_reuse_n(v_x11_2419, 1ULL, 1);
          v_v_2438 = heff_tag_at_n(v_ru_24x11_2419_24PatInt, TAG_IntValue, 1, (V[]){v_v_2428});
          break;
        }
        case TAG_PatFloat: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          v_v_2438 = NTAG(TAG_FloatValue);
          break;
        }
        case TAG_PatString: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          v_v_2438 = NTAG(TAG_StrValue);
          break;
        }
        case TAG_PatBinary: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          v_v_2438 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatRune: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          v_v_2438 = NTAG(TAG_RuneValue);
          break;
        }
        case TAG_PatRecord: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          v_v_2438 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatWord: {
          heff_take_n(v_x11_2419, 0ULL, 1);
          v_v_2438 = NTAG(TAG_OtherValue);
          break;
        }
        case TAG_PatAs: {
          heff_take_n(v_x11_2419, 0ULL, 3);
          v_v_2438 = NTAG(TAG_OtherValue);
          break;
        }
        default: heff_nomatch(v_x11_2419);
        }
        break;
      }
      default: heff_nomatch(v_x_2415);
      }
      V v_st_2439 = v_st_2413;
      V v_t_2441;
      switch (heff_tag_of(v_v_2438)) {
      case TAG_StrValue: {
        v_t_2441 = NTAG(TAG_SegmentBinary);
        break;
      }
      case TAG_IntValue: {
        v_t_2441 = NTAG(TAG_SegmentInteger);
        break;
      }
      case TAG_FloatValue: {
        v_t_2441 = NTAG(TAG_SegmentFloat);
        break;
      }
      case TAG_RuneValue: {
        v_t_2441 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
        break;
      }
      case TAG_OtherValue: {
        v_t_2441 = NTAG(TAG_SegmentInteger);
        break;
      }
      default: heff_nomatch(v_v_2438);
      }
      HeffT2 v_t_2442 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_2417), heff_dup(v_v_2438), v_t_2441, v_st_2439));
      V v_x1_2461;
      {
        V v_field_2443 = v_t_2442.f[0];
        V v_field_2444 = v_t_2442.f[1];
        V v_x11_2445 = v_field_2443;
        V v_st_2446 = v_field_2444;
        switch (heff_tag_of(v_x11_2445)) {
        case TAG_Left: {
          V v_e_2447 = heff_field(v_x11_2445, 0);
          V v_ru_24x11_2445_24Left = heff_take_reuse_n(v_x11_2445, 1ULL, 1);
          heff_drop_cell(v_ru_24x11_2412_24Right, 1);
          heff_drop(v_sp_2417);
          heff_drop(v_e_2418);
          heff_drop(v_v_2438);
          v_x1_2461 = heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2445_24Left, TAG_Left, 1, (V[]){v_e_2447}), v_st_2446});
          break;
        }
        case TAG_Right: {
          V v_ru_24x11_2445_24Right = heff_take_reuse_n(v_x11_2445, 0ULL, 1);
          V v_t_2450;
          switch (heff_tag_of(v_v_2438)) {
          case TAG_StrValue: {
            heff_drop_cell(v_ru_24x11_2445_24Right, 1);
            v_t_2450 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            heff_drop_cell(v_ru_24x11_2445_24Right, 1);
            v_t_2450 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            heff_drop_cell(v_ru_24x11_2445_24Right, 1);
            v_t_2450 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2450 = heff_tag_at_n(v_ru_24x11_2445_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            heff_drop_cell(v_ru_24x11_2445_24Right, 1);
            v_t_2450 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_2438);
          }
          V v_m_2451 = (g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(v_inPat_2416, heff_dup(v_sp_2417), heff_dup(v_v_2438), v_t_2450, NTAG(TAG_SizeDefault)));
          V v_x1_2452 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_st_2446}));
          switch (heff_tag_of(v_x1_2452)) {
          case TAG_MkPair: {
            V v_x11_2453 = heff_field(v_x1_2452, 0);
            V v_st_2454 = heff_field(v_x1_2452, 1);
            V v_ru_24x1_2452_24MkPair = heff_take_reuse_n(v_x1_2452, 3ULL, 2);
            switch (heff_tag_of(v_x11_2453)) {
            case TAG_Left: {
              V v_e_2455 = heff_field(v_x11_2453, 0);
              V v_ru_24x11_2453_24Left = heff_take_reuse_n(v_x11_2453, 1ULL, 1);
              heff_drop_cell(v_ru_24x11_2412_24Right, 1);
              heff_drop(v_sp_2417);
              heff_drop(v_e_2418);
              heff_drop(v_v_2438);
              heff_drop_cell(v_ru_24x1_2452_24MkPair, 2);
              v_x1_2461 = heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2453_24Left, TAG_Left, 1, (V[]){v_e_2455}), v_st_2454});
              break;
            }
            case TAG_Right: {
              V v_ru_24x11_2453_24Right = heff_take_reuse_n(v_x11_2453, 0ULL, 1);
              V v_t_2458;
              switch (heff_tag_of(v_v_2438)) {
              case TAG_StrValue: {
                heff_drop_cell(v_ru_24x11_2453_24Right, 1);
                v_t_2458 = NTAG(TAG_SegmentBinary);
                break;
              }
              case TAG_IntValue: {
                heff_take_n(v_v_2438, 0ULL, 1);
                heff_drop_cell(v_ru_24x11_2453_24Right, 1);
                v_t_2458 = NTAG(TAG_SegmentInteger);
                break;
              }
              case TAG_FloatValue: {
                heff_drop_cell(v_ru_24x11_2453_24Right, 1);
                v_t_2458 = NTAG(TAG_SegmentFloat);
                break;
              }
              case TAG_RuneValue: {
                v_t_2458 = heff_tag_at_n(v_ru_24x11_2453_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
                break;
              }
              case TAG_OtherValue: {
                heff_drop_cell(v_ru_24x11_2453_24Right, 1);
                v_t_2458 = NTAG(TAG_SegmentInteger);
                break;
              }
              default: heff_nomatch(v_v_2438);
              }
              V v_t_2459 = heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_2418, v_t_2458, NTAG(TAG_SizeDefault), NTAG(TAG_False), NTAG(TAG_False)});
              V v_t_2460 = heff_tag_at_n(v_ru_24x11_2412_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_2452_24MkPair, TAG_At, 2, (V[]){v_t_2459, v_sp_2417})});
              v_x1_2461 = heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2460, v_st_2454});
              break;
            }
            default: heff_nomatch(v_x11_2453);
            }
            break;
          }
          default: heff_nomatch(v_x1_2452);
          }
          break;
        }
        default: heff_nomatch(v_x11_2445);
        }
      }
      switch (heff_tag_of(v_x1_2461)) {
      case TAG_MkPair: {
        V v_x11_2462 = heff_field(v_x1_2461, 0);
        V v_st_2463 = heff_field(v_x1_2461, 1);
        V v_ru_24x1_2461_24MkPair = heff_take_reuse_n(v_x1_2461, 3ULL, 2);
        switch (heff_tag_of(v_x11_2462)) {
        case TAG_Left: {
          V v_e_2464 = heff_field(v_x11_2462, 0);
          V v_ru_24x11_2462_24Left = heff_take_reuse_n(v_x11_2462, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop(v_last_241);
          return heff_tag_at_n(v_ru_24x1_2461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2462_24Left, TAG_Left, 1, (V[]){v_e_2464}), v_st_2463});
        }
        case TAG_Right: {
          V v_x_2465 = heff_field(v_x11_2462, 0);
          V v_ru_24x11_2462_24Right = heff_take_reuse_n(v_x11_2462, 1ULL, 1);
          if (!(heff_dup(v_last_241) == NTAG(TAG_True))) {
            heff_drop(v_last_241);
            V v_t_2468;
            switch (heff_tag_of(v_x_2465)) {
            case TAG_At: {
              V v_x_2466 = heff_dup(heff_field(v_x_2465, 0));
              v_t_2468 = v_x_2466;
              break;
            }
            default: heff_nomatch(v_x_2465);
            }
            V v_t_2469 = ({ V a_0 = v_t_2468; V r_ = (g_heff_2esyntax_2esurface_2etakesRest(a_0)); heff_drop(v_t_2468); r_; });
            if ((heff_dup(v_t_2469) == NTAG(TAG_True))) {
              heff_drop(v_x_2465);
              heff_drop_cell(v_ru_24x11_2462_24Right, 1);
              heff_drop(v_t_2469);
              V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2epatSegmentWith_24s725013195x963975641_str1), v_sp_242, NTAG(TAG_Nothing)});
              return heff_tag_at_n(v_ru_24x1_2461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2470}), v_st_2463});
            } else {
              heff_drop(v_sp_242);
              heff_drop(v_t_2469);
              return heff_tag_at_n(v_ru_24x1_2461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2462_24Right, TAG_Right, 1, (V[]){v_x_2465}), v_st_2463});
            }
          } else {
            heff_drop(v_sp_242);
            heff_drop(v_last_241);
            return heff_tag_at_n(v_ru_24x1_2461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2462_24Right, TAG_Right, 1, (V[]){v_x_2465}), v_st_2463});
          }
        }
        default: return heff_nomatch(v_x11_2462);
        }
      }
      default: return heff_nomatch(v_x1_2461);
      }
    }
    default: return heff_nomatch(v_x11_2412);
    }
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
Clo g_heff_2esyntax_2esurface_2esigBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esigBinders_entry, 3, 0};

V g_heff_2esyntax_2esurface_2esigBinders(V v_ty_240, V v_s_241, V v_n_242) {
top: ;
  V v_names_243 = (g_heff_2esyntax_2esurface_2epiBinders(heff_dup(v_ty_240)));
  V v_implicits_244 = (g_heff_2esyntax_2esurface_2epiImplicits(v_ty_240));
  V v_b_245 = heff_rec_n(3, shape_f__names__implicits, (V[]){heff_get_n(v_n_242, 0, 2), v_names_243, v_implicits_244});
  HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_s_241, 3), heff_rfield(v_b_245, 0)));
  V v_t_2410;
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_248;
      v_t_2410 = v_x_249;
    } else {
      heff_drop(v_field_248);
      v_t_2410 = NTAG(TAG_Nil);
    }
  }
  V v_t_2411 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(heff_rfield(v_s_241, 3)), heff_dup(heff_rfield(v_b_245, 0)), heff_tag_n(TAG_Cons, 2, (V[]){v_b_245, v_t_2410})));
  return (g_heff_2esyntax_2esurface_2esetBinders(v_t_2411, v_s_241));
}
V g_heff_2esyntax_2esurface_2esigBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esigBinders(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry, 1, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(v_xs_242));
    return (g_heff_2esyntax_2esurface_2eappendS(heff_dup(heff_rfield(v_x_241, 2)), v_t_243));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eeqnL_24cpr(V v_r_240, V v_names_241, V v_pats_242, V v_rhs_243, V v_w_244, V v_st_245) {
top: ;
  V v_t_246 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_241));
  V v_f_247 = heff_get_n(v_t_246, 0, 2);
  HeffT2 v_t_248 = ({ V a_0 = heff_rfield(v_st_245, 3); V a_1 = v_f_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_f_247); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    V v_t_2412;
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_2410;
      v_t_2412 = v_x_2411;
    } else {
      heff_drop(v_field_2410);
      v_t_2412 = NTAG(TAG_Nil);
    }
    V v_t_2413 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2412));
    V v_st_2414 = (g_heff_2esyntax_2esurface_2esetPatVars(v_t_2413, v_st_245));
    V v_m_2415 = (g_prelude_2etraverse_24s499544530x2060473942(heff_dup(heff_rfield(v_r_240, 1)), heff_dup(v_pats_242)));
    V v_x1_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_st_2414}));
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_MkPair: {
      V v_x11_2417 = heff_field(v_x1_2416, 0);
      V v_st_2418 = heff_field(v_x1_2416, 1);
      V v_ru_24x1_2416_24MkPair = heff_take_reuse_n(v_x1_2416, 3ULL, 2);
      switch (heff_tag_of(v_x11_2417)) {
      case TAG_Left: {
        V v_e_2419 = heff_field(v_x11_2417, 0);
        V v_ru_24x11_2417_24Left = heff_take_reuse_n(v_x11_2417, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_pats_242);
        heff_drop(v_rhs_243);
        heff_drop(v_t_2412);
        heff_drop_cell(v_ru_24x1_2416_24MkPair, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2417_24Left, TAG_Left, 1, (V[]){v_e_2419}), v_st_2418}});
      }
      case TAG_Right: {
        V v_x_2420 = heff_field(v_x11_2417, 0);
        heff_take_n(v_x11_2417, 1ULL, 1);
        V v_st_2421 = (g_heff_2esyntax_2esurface_2esetPatVars(NTAG(TAG_Nil), v_st_2418));
        V v_t_2422 = (g_heff_2esyntax_2esurface_2econcatMapS_24s298511799x468703553(v_t_2412));
        V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eboundBy_clo), 1, (V[]){v_t_2422}));
        V v_t_2424 = ({ V a_0 = v_t_2423; V a_1 = v_pats_242; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS(a_0, a_1)); heff_drop(v_pats_242); r_; });
        V v_t_2425 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s57256023x1811795094(a_0)); heff_drop(v_t_2412); r_; });
        V v_t_2426 = (g_heff_2esyntax_2esurface_2eappendS_24tok2(v_ru_24x1_2416_24MkPair, v_t_2424, v_t_2425));
        V v_m_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_243}));
        return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2426, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam0, 1, 5, (V[]){v_m_2427, heff_dup(v_w_244), v_r_240, heff_dup(v_names_241), v_x_2420}), v_st_2421));
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2417)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2416)}});
    }
  }
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam1(V self, V *args) {
  V v_st_2434 = args[0];
  V v_x_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2433}), v_st_2434});
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam2(V self, V *args) {
  V v_rhs_27_2439 = args[0];
  V v_z_2440 = args[1];
  V v_names_241 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2441 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_241));
  V v_t_2442 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_241));
  V v_t_2443 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_241));
  V v_t_2444 = heff_tag_n(TAG_MkEquation, 4, (V[]){heff_get_n(v_t_2442, 0, 2), heff_get_n(v_t_2443, 1, 2), v_x_2420, heff_dup(v_rhs_27_2439)});
  V v_t_2447;
  switch (heff_tag_of(v_names_241)) {
  case TAG_Nil: {
    v_t_2447 = MK_INT(0LL);
    break;
  }
  case TAG_Cons: {
    V v_t_2445 = heff_dup(heff_field(v_names_241, 0));
    v_t_2447 = heff_get_n(v_t_2445, 3, 9);
    break;
  }
  default: heff_nomatch(v_names_241);
  }
  V v_t_2450;
  switch (heff_tag_of(v_rhs_27_2439)) {
  case TAG_At: {
    V v_s_2449 = heff_dup(heff_field(v_rhs_27_2439, 1));
    v_t_2450 = v_s_2449;
    break;
  }
  default: heff_nomatch(v_rhs_27_2439);
  }
  V v_t_2451 = ({ V rv_0 = v_t_2447; V rr_ = heff_rec_reuse_nf(v_t_2450, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2454;
  switch (heff_tag_of(v_names_241)) {
  case TAG_Nil: {
    v_t_2454 = MK_INT(0LL);
    break;
  }
  case TAG_Cons: {
    V v_t_2452 = heff_field(v_names_241, 0);
    heff_take_n(v_names_241, 1ULL, 2);
    v_t_2454 = heff_get_n(v_t_2452, 3, 9);
    break;
  }
  default: heff_nomatch(v_names_241);
  }
  V v_t_2457;
  switch (heff_tag_of(v_rhs_27_2439)) {
  case TAG_At: {
    V v_s_2456 = heff_field(v_rhs_27_2439, 1);
    heff_take_n(v_rhs_27_2439, 2ULL, 2);
    v_t_2457 = v_s_2456;
    break;
  }
  default: heff_nomatch(v_rhs_27_2439);
  }
  V v_t_2458 = ({ V rv_0 = v_t_2454; V rr_ = heff_rec_reuse_nf(v_t_2457, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2459 = heff_tag_n(TAG_Eqn, 3, (V[]){heff_get_n(v_t_2441, 0, 2), heff_tag_n(TAG_At, 2, (V[]){v_t_2444, v_t_2451}), v_t_2458});
  V v_x_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2460}), v_z_2440});
}
V g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam0(V self, V *args) {
  V v_st_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  V v_w_244 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_names_241 = heff_env(self)[3];
  V v_x_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_st_2428}));
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_MkPair: {
    V v_x11_2430 = heff_field(v_x1_2429, 0);
    V v_st_2431 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24MkPair = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_Left: {
      V v_e_2432 = heff_field(v_x11_2430, 0);
      V v_ru_24x11_2430_24Left = heff_take_reuse_n(v_x11_2430, 1ULL, 1);
      heff_drop(v_w_244);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_names_241);
      heff_drop(v_x_2420);
      return heff_tag_at_n(v_ru_24x1_2429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2430_24Left, TAG_Left, 1, (V[]){v_e_2432}), v_st_2431});
    }
    case TAG_Right: {
      V v_x_2433 = heff_field(v_x11_2430, 0);
      heff_take_n(v_x11_2430, 1ULL, 1);
      V v_t_2438;
      switch (heff_tag_of(v_w_244)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 3);
        v_t_2438 = heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam1, 1, 1, (V[]){v_x_2433});
        break;
      }
      case TAG_Just: {
        V v_it1_2435 = heff_field(v_w_244, 0);
        heff_take_n(v_w_244, 1ULL, 1);
        switch (heff_tag_of(v_it1_2435)) {
        case TAG_MkPair: {
          V v_kw_2436 = heff_field(v_it1_2435, 0);
          V v_ds_2437 = heff_field(v_it1_2435, 1);
          heff_take_n(v_it1_2435, 3ULL, 2);
          v_t_2438 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2ewhereL_clo), 4, (V[]){v_r_240, v_kw_2436, v_ds_2437, v_x_2433}));
          break;
        }
        default: heff_nomatch(v_it1_2435);
        }
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      return (g_heff_2esyntax_2esurface_2ebind_24tok2(v_ru_24x1_2429_24MkPair, v_t_2438, heff_clo_n(g_heff_2esyntax_2esurface_2eeqnL_24cpr_lam2, 2, 2, (V[]){v_names_241, v_x_2420}), v_st_2431));
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_2429);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eparamOf_str0, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
Clo g_heff_2esyntax_2esurface_2eparamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eparamOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eparamOf(V v_p_240, V v_z_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2esurface_2enameAnn_24cpr(v_p_240));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_q_245 = v_field_244;
      V v_name_246 = heff_take_field(v_q_245, 0);
      V v_span_247 = heff_take_field(v_q_245, 1);
      V v_ty_248 = heff_get_n(v_q_245, 2, 3);
      V v_t_2411;
      switch (heff_tag_of(v_ty_248)) {
      case TAG_At: {
        V v_s_2410 = heff_dup(heff_field(v_ty_248, 1));
        v_t_2411 = v_s_2410;
        break;
      }
      default: heff_nomatch(v_ty_248);
      }
      V v_t_2412 = ({ V rv_0 = heff_dup(heff_rfield(v_span_247, 0)); V rr_ = heff_rec_reuse_nf(v_t_2411, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_name_246, v_span_247, v_ty_248}), v_t_2412});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_z_241});
    } else {
      heff_drop(v_field_244);
      V v_t_2416;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2415 = heff_field(v_p_240, 1);
        v_t_2416 = heff_dup(v_s_2415);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eparamOf_str0), v_t_2416, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2417}), v_z_241});
    }
  }
}
V g_heff_2esyntax_2esurface_2eparamOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eparamOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2edataParamL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edataParamL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edataParamL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edataParamL(V v_r_240, V v_e_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2esyntax_2esurface_2eatomOf_24cpr(v_e_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      heff_drop(v_r_240);
      heff_drop(v_e_241);
      V v_x_245 = v_field_244;
      V v_text_246 = heff_take_field(v_x_245, 1);
      V v_start_247 = heff_take_field(v_x_245, 3);
      V v_end_248 = heff_get_n(v_x_245, 4, 9);
      return heff_clo_n(g_heff_2esyntax_2esurface_2edataParamL_lam0, 1, 3, (V[]){v_start_247, v_end_248, v_text_246});
    } else {
      heff_drop(v_field_244);
      HEFF_LAST return g_heff_2esyntax_2esurface_2edataParamOf(v_r_240, v_e_241);
    }
  }
}
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edataParamL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edataParamL_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_start_247 = heff_env(self)[0];
  V v_end_248 = heff_env(self)[1];
  V v_text_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_247), heff_dup(v_end_248)})});
  V v_t_2412 = heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_text_246, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_247), heff_dup(v_end_248)}), v_t_2411});
  V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_st_249});
}
Clo g_heff_2esyntax_2esurface_2emutualDefs_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2emutualDefs_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2emutualDefs_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Sig: {
      V v_f_245 = heff_field(v_x11_242, 1);
      V v_fsp_246 = heff_field(v_x11_242, 2);
      V v_ty_247 = heff_field(v_x11_242, 3);
      V v_sp_248 = heff_field(v_x11_242, 4);
      heff_take_n(v_x11_242, 30ULL, 5);
      V v_start_249 = heff_take_field(v_sp_248, 0);
      V v_end_2410 = heff_get_n(v_sp_248, 1, 2);
      HeffT2 v_t_2411 = (g_heff_2esyntax_2esurface_2eeqnsUnder_24cpr(v_f_245, heff_dup(v_rest_243)));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_es_2414 = v_field_2413;
          V v_eqns_2415 = heff_take_field(v_es_2414, 0);
          V v_end_2416 = heff_get_n(v_es_2414, 1, 2);
          V v_a_2417 = v_start_249;
          V v_a_2418 = v_end_2410;
          V v_b_2419 = v_end_2416;
          V v_t_2420;
          if (heff_intLt_c_lent(v_a_2418, v_b_2419, 0)) {
            heff_drop(v_a_2418);
            v_t_2420 = v_b_2419;
          } else {
            heff_drop(v_b_2419);
            v_t_2420 = v_a_2418;
          }
          V v_t_2421 = heff_rec_n(5, shape_name__span__ty__eqns__whole, (V[]){v_f_245, v_fsp_246, v_ty_247, v_eqns_2415, heff_rec_n(2, shape_start__end, (V[]){v_a_2417, v_t_2420})});
          V v_cell_2422 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2421}), heff_hole()});
          V v_u_2423 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2422));
          heff_drop(v_u_2423);
          V t_0 = v_rest_243;
          V t_1 = v_cell_2422;
          v_x1_240 = t_0;
          v_d_241 = t_1;
          goto top;
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_f_245);
          heff_drop(v_fsp_246);
          heff_drop(v_ty_247);
          heff_drop(v_start_249);
          heff_drop(v_end_2410);
          heff_drop(v_field_2413);
          V t_0 = v_rest_243;
          V t_1 = v_d_241;
          v_x1_240 = t_0;
          v_d_241 = t_1;
          goto top;
        }
      }
    }
    case TAG_Eqn: {
      heff_take_n(v_x11_242, 0ULL, 3);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Whole: {
      V v_cell_2428 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x11_242}), heff_hole()});
      V v_u_2429 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2428));
      heff_drop(v_u_2429);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2428;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Doc: {
      V v_cell_2431 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x11_242}), heff_hole()});
      V v_u_2432 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2431));
      heff_drop(v_u_2432);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2431;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2emutualDefs_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2emutualDefs_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str0, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str1, 7, "Mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str2, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24cpr_str3, 70, "a `mutual` block holds definitions, each a signature and its equations");

HeffT2 g_heff_2esyntax_2esurface_2emutualL_24cpr(V v_r_240, V v_kw_241, V v_ds_242, V v_z_243) {
top: ;
  V v_start_244 = heff_take_field(v_kw_241, 3);
  V v_end_245 = heff_get_n(v_kw_241, 4, 9);
  HeffT2 v_t_246 = (g_heff_2esyntax_2esurface_2efirstSig_24cpr(v_ds_242));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_f1_249 = v_field_248;
      HeffT2 v_t_2410 = (g_heff_2esyntax_2esurface_2emutualItems_24cpr(v_r_240, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str0), heff_dup(v_f1_249)), heff_dup(v_ds_242), v_z_243));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x11_2413 = v_field_2411;
        V v_st_2414 = v_field_2412;
        switch (heff_tag_of(v_x11_2413)) {
        case TAG_Left: {
          V v_e_2415 = heff_field(v_x11_2413, 0);
          V v_ru_24x11_2413_24Left = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
          heff_drop(v_ds_242);
          heff_drop(v_start_244);
          heff_drop(v_end_245);
          heff_drop(v_f1_249);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2413_24Left, TAG_Left, 1, (V[]){v_e_2415}), v_st_2414}});
        }
        case TAG_Right: {
          V v_x_2416 = heff_field(v_x11_2413, 0);
          V v_ru_24x11_2413_24Right = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
          V v_t_2417 = (g_heff_2esyntax_2esurface_2emutualDefs(heff_dup(v_x_2416)));
          V v_t_2418 = (g_list_2emap_24s2081681776x559624592(v_t_2417));
          V v_t_2419 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2418));
          switch (heff_tag_of(v_t_2419)) {
          case TAG_Nil: {
            V v_x1_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_242));
            V v_e_2424;
            switch (heff_tag_of(v_x1_2420)) {
            case TAG_Nil: {
              v_e_2424 = heff_dup(v_end_245);
              break;
            }
            case TAG_Cons: {
              V v_x_2421 = heff_field(v_x1_2420, 0);
              heff_take_n(v_x1_2420, 1ULL, 2);
              V v_t_2423 = (g_heff_2esyntax_2ecst_2elastD(v_x_2421));
              v_e_2424 = heff_get_n(v_t_2423, 4, 9);
              break;
            }
            default: heff_nomatch(v_x1_2420);
            }
            V v_t_2425 = (g_heff_2esyntax_2esurface_2emutualDefs(v_x_2416));
            V v_x_2426 = (g_heff_2esyntax_2esurface_2emutualOut(heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_244), v_end_245}), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_e_2424}), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str1), heff_dup(v_f1_249)), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str2), v_f1_249), v_t_2425));
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){v_x_2426}), v_st_2414}});
          }
          case TAG_Cons: {
            V v_d_2427 = heff_field(v_t_2419, 0);
            heff_take_n(v_t_2419, 1ULL, 2);
            heff_drop(v_ds_242);
            heff_drop(v_start_244);
            heff_drop(v_end_245);
            heff_drop(v_f1_249);
            heff_drop(v_x_2416);
            heff_drop_cell(v_ru_24x11_2413_24Right, 1);
            return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2427}), v_st_2414}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2419)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2413)}});
        }
      }
    } else {
      heff_drop(v_r_240);
      heff_drop(v_ds_242);
      heff_drop(v_field_248);
      V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2emutualL_24cpr_str3), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
      V v_f_2430 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2429});
      return ((HeffT2){{v_f_2430, v_z_243}});
    }
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eedgesOf_lam4(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eedgesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eedgesOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eedgesOf(V v_scope_240, V v_d_241) {
top: ;
  V v_ops_242 = heff_take_field(v_d_241, 1);
  V v_above_243 = heff_take_field(v_d_241, 2);
  V v_below_244 = heff_get_n(v_d_241, 3, 8);
  switch (heff_tag_of(v_ops_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_scope_240, 2);
    heff_drop(v_above_243);
    heff_drop(v_below_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_op_245 = heff_field(v_ops_242, 0);
    V v_ru_24ops_242_24Cons = heff_take_reuse_n(v_ops_242, 1ULL, 2);
    V v_t_2415 = (g_list_2emap_24tok2(v_ru_24ops_242_24Cons, heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam0, 1, 2, (V[]){heff_dup(v_scope_240), heff_dup(v_op_245)}), v_above_243));
    V v_t_2416 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2415));
    V v_t_2424 = (g_list_2ekeepIf(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam2, 1, 1, (V[]){heff_dup(v_scope_240)}), v_below_244));
    V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam4, 1, 2, (V[]){v_scope_240, v_op_245}), v_t_2424));
    V v_t_2434 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2433));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_2416, v_t_2434);
  }
  default: return heff_nomatch(v_ops_242);
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eedgesOf(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam1(V self, V *args) {
  V v_g_248 = args[0];
  V v_r_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_r_247, 1, 7)}));
  return ({ V a_0 = v_t_249; V b_1 = heff_get_n(v_g_248, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam0(V self, V *args) {
  V v_r_247 = args[0];
  V v_scope_240 = heff_env(self)[0];
  V v_op_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2410 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam1, 1, 1, (V[]){v_r_247}); V b_1 = heff_get_n(v_scope_240, 0, 2); HeffT2 r_ = (g_heff_2esyntax_2efixity_2efindG_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_g_2413 = v_field_2412;
      V v_t_2414 = heff_rec_n(2, shape_tighter__looser, (V[]){heff_get_n(v_op_245, 1, 7), heff_get_n(v_g_2413, 0, 5)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
    } else {
      heff_drop_rec(v_op_245, 7);
      heff_drop(v_field_2412);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam3(V self, V *args) {
  V v_g_2418 = args[0];
  V v_r_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_r_2417, 1, 7)}));
  return ({ V a_0 = v_t_2419; V b_1 = heff_get_n(v_g_2418, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam2(V self, V *args) {
  V v_r_2417 = args[0];
  V v_scope_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2420 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam3, 1, 1, (V[]){v_r_2417}); V b_1 = heff_get_n(v_scope_240, 0, 2); HeffT2 r_ = (g_heff_2esyntax_2efixity_2efindG_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
  {
    V v_field_2422 = v_t_2420.f[1];
    int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
    if ((v_tag_2421 == ((int64_t)0ULL))) {
      V v_g_2423 = v_field_2422;
      V v_ret_24bool = heff_bool(!(heff_dup(heff_rfield(v_g_2423, 3)) == NTAG(TAG_True)));
      heff_drop_rec(v_g_2423, 5);
      return v_ret_24bool;
    } else {
      heff_drop(v_field_2422);
      return NTAG(TAG_True);
    }
  }
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam5(V self, V *args) {
  V v_g_2426 = args[0];
  V v_r_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_r_2425, 1, 7)}));
  return ({ V a_0 = v_t_2427; V b_1 = heff_get_n(v_g_2426, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2eedgesOf_lam4(V self, V *args) {
  V v_r_2425 = args[0];
  V v_scope_240 = heff_env(self)[0];
  V v_op_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2428 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eedgesOf_lam5, 1, 1, (V[]){v_r_2425}); V b_1 = heff_get_n(v_scope_240, 0, 2); HeffT2 r_ = (g_heff_2esyntax_2efixity_2efindG_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
  {
    V v_field_2430 = v_t_2428.f[1];
    int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
    if ((v_tag_2429 == ((int64_t)0ULL))) {
      V v_g_2431 = v_field_2430;
      V v_t_2432 = heff_rec_n(2, shape_tighter__looser, (V[]){heff_get_n(v_g_2431, 0, 5), heff_get_n(v_op_245, 1, 7)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2432});
    } else {
      heff_drop_rec(v_op_245, 7);
      heff_drop(v_field_2430);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr(V v_k_240, V v_ds_241, V v_st_242) {
top: ;
  V v_t_243 = (g_heff_2esyntax_2esurface_2eknotOf(v_k_240, v_ds_241));
  V v_st_244 = (g_heff_2esyntax_2esurface_2esetKnot(v_t_243, v_st_242));
  V v_t_245 = heff_dup(heff_rfield(v_st_244, 1));
  V v_m_246 = (g_prelude_2etraverse_24s499544530x2060473942(heff_dup(heff_rfield(g_heff_2esyntax_2esurface_2elw_get(), 2)), v_ds_241));
  V v_x1_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_244}));
  V v_x11_2413;
  V v_st_2414;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    heff_take_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Left = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      heff_drop(v_t_245);
      v_x11_2413 = heff_tag_at_n(v_ru_24x11_248_24Left, TAG_Left, 1, (V[]){v_e_2410});
      v_st_2414 = v_st_249;
      break;
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x11_248, 0);
      V v_ru_24x11_248_24Right = heff_take_reuse_n(v_x11_248, 1ULL, 1);
      V v_st_2412 = (g_heff_2esyntax_2esurface_2esetScope(v_t_245, v_st_249));
      v_x11_2413 = heff_tag_at_n(v_ru_24x11_248_24Right, TAG_Right, 1, (V[]){v_x_2411});
      v_st_2414 = v_st_2412;
      break;
    }
    default: heff_nomatch(v_x11_248);
    }
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  switch (heff_tag_of(v_x11_2413)) {
  case TAG_Left: {
    V v_e_2415 = heff_field(v_x11_2413, 0);
    V v_ru_24x11_2413_24Left = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
    return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2413_24Left, TAG_Left, 1, (V[]){v_e_2415}), v_st_2414}});
  }
  case TAG_Right: {
    V v_x_2416 = heff_field(v_x11_2413, 0);
    V v_ru_24x11_2413_24Right = heff_take_reuse_n(v_x11_2413, 1ULL, 1);
    V v_st_2417 = (g_heff_2esyntax_2esurface_2esetKnot(heff_dup(g_std_2eordmap_2eempty_get()), v_st_2414));
    V v_t_2418 = heff_dup(heff_rfield(v_st_2417, 7));
    V v_items_2419 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2416));
    V v_items_2420 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2419, NTAG(TAG_Nil)));
    V v_t_2421 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    V v_d_2425 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr_lam0, 2, 1, (V[]){v_t_2418}); V a_1 = v_t_2421; V a_2 = v_items_2420; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_items_2420); r_; });
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2425, 3, 4)));
    V v_items_2427 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2416));
    V v_items_2428 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2427, NTAG(TAG_Nil)));
    V v_t_2429 = (g_heff_2esyntax_2esurface_2esigNames(v_items_2428));
    V v_t_2430 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_2428));
    V v_t_2431 = (g_list_2emap_24s2130193383x1335133353(heff_dup(g_std_2eordmap_2eempty_get()), v_t_2429, v_t_2430, v_items_2428));
    V v_t_2432 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2431));
    V v_t_2433 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2426, v_t_2432));
    switch (heff_tag_of(v_t_2433)) {
    case TAG_Nil: {
      V v_items_2434 = ({ V a_0 = v_x_2416; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_2416); r_; });
      V v_x_2435 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2434, NTAG(TAG_Nil)));
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2413_24Right, TAG_Right, 1, (V[]){v_x_2435}), v_st_2417}});
    }
    case TAG_Cons: {
      V v_d_2436 = heff_field(v_t_2433, 0);
      heff_take_n(v_t_2433, 1ULL, 2);
      heff_drop(v_x_2416);
      heff_drop_cell(v_ru_24x11_2413_24Right, 1);
      return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2436}), v_st_2417}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2433)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x11_2413)}});
  }
}
V g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr_lam0(V self, V *args) {
  V v_d_2422 = args[0];
  V v_it_2423 = args[1];
  V v_t_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2422, 2)), v_it_2423));
  return ({ V a_0 = v_t_2418; V a_1 = v_d_2422; V a_2 = v_t_2424; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
}
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str0, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str1, 7, "Mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str2, 7, "mutual#");
HEFF_LIT(g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str3, 70, "a `mutual` block holds definitions, each a signature and its equations");

HeffT2 g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr(V v_kw_240, V v_ds_241, V v_z_242) {
top: ;
  V v_start_243 = heff_take_field(v_kw_240, 3);
  V v_end_244 = heff_get_n(v_kw_240, 4, 9);
  HeffT2 v_t_245 = (g_heff_2esyntax_2esurface_2efirstSig_24cpr(v_ds_241));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_f1_248 = v_field_247;
      HeffT2 v_t_249 = (g_heff_2esyntax_2esurface_2emutualItems_24s787033473x912366254_24cpr(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str0), heff_dup(v_f1_248)), heff_dup(v_ds_241), v_z_242));
      {
        V v_field_2410 = v_t_249.f[0];
        V v_field_2411 = v_t_249.f[1];
        V v_x11_2412 = v_field_2410;
        V v_st_2413 = v_field_2411;
        switch (heff_tag_of(v_x11_2412)) {
        case TAG_Left: {
          V v_e_2414 = heff_field(v_x11_2412, 0);
          V v_ru_24x11_2412_24Left = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
          heff_drop(v_ds_241);
          heff_drop(v_start_243);
          heff_drop(v_end_244);
          heff_drop(v_f1_248);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2412_24Left, TAG_Left, 1, (V[]){v_e_2414}), v_st_2413}});
        }
        case TAG_Right: {
          V v_x_2415 = heff_field(v_x11_2412, 0);
          V v_ru_24x11_2412_24Right = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
          V v_t_2416 = (g_heff_2esyntax_2esurface_2emutualDefs(heff_dup(v_x_2415)));
          V v_t_2417 = (g_list_2emap_24s2081681776x559624592(v_t_2416));
          V v_t_2418 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2417));
          switch (heff_tag_of(v_t_2418)) {
          case TAG_Nil: {
            V v_x1_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_241));
            V v_e_2423;
            switch (heff_tag_of(v_x1_2419)) {
            case TAG_Nil: {
              v_e_2423 = heff_dup(v_end_244);
              break;
            }
            case TAG_Cons: {
              V v_x_2420 = heff_field(v_x1_2419, 0);
              heff_take_n(v_x1_2419, 1ULL, 2);
              V v_t_2422 = (g_heff_2esyntax_2ecst_2elastD(v_x_2420));
              v_e_2423 = heff_get_n(v_t_2422, 4, 9);
              break;
            }
            default: heff_nomatch(v_x1_2419);
            }
            V v_t_2424 = (g_heff_2esyntax_2esurface_2emutualDefs(v_x_2415));
            V v_x_2425 = (g_heff_2esyntax_2esurface_2emutualOut(heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_243), v_end_244}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_e_2423}), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str1), heff_dup(v_f1_248)), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str2), v_f1_248), v_t_2424));
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2412_24Right, TAG_Right, 1, (V[]){v_x_2425}), v_st_2413}});
          }
          case TAG_Cons: {
            V v_d_2426 = heff_field(v_t_2418, 0);
            heff_take_n(v_t_2418, 1ULL, 2);
            heff_drop(v_ds_241);
            heff_drop(v_start_243);
            heff_drop(v_end_244);
            heff_drop(v_f1_248);
            heff_drop(v_x_2415);
            heff_drop_cell(v_ru_24x11_2412_24Right, 1);
            return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_d_2426}), v_st_2413}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2418)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2412)}});
        }
      }
    } else {
      heff_drop(v_ds_241);
      heff_drop(v_field_247);
      V v_t_2428 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2emutualL_24s1329887344x1174811486_24cpr_str3), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244}), NTAG(TAG_Nothing)});
      V v_f_2429 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2428});
      return ((HeffT2){{v_f_2429, v_z_242}});
    }
  }
}
V g_heff_2esyntax_2esurface_2ereadPlaced_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ereadPlaced_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadPlaced_entry, 5, 0};

V g_heff_2esyntax_2esurface_2ereadPlaced(V v_at_240, V v_lexDiags_241, V v_own_242, V v_r_243, V v_placed_244) {
top: ;
  V v_items_245 = heff_take_field(v_placed_244, 0);
  V v_diags_246 = heff_get_n(v_placed_244, 2, 3);
  V v_broken_247 = heff_take_field(v_r_243, 2);
  V v_diags_248 = heff_take_field(v_r_243, 1);
  V v_items_249 = heff_take_field(v_r_243, 0);
  V v_arms_2410 = heff_get_n(v_r_243, 3, 4);
  V v_diags_2411 = heff_take_field(v_own_242, 1);
  V v_fixities_2412 = heff_get_n(v_own_242, 0, 2);
  V v_items_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_245));
  V v_items_2414 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2413, NTAG(TAG_Nil)));
  V v_t_2415 = (g_heff_2esyntax_2esurface_2enameSet(v_broken_247));
  V v_t_2416 = (g_heff_2esyntax_2esurface_2eassembleGo(v_t_2415, v_items_2414, NTAG(TAG_Nil)));
  V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_diags_246));
  V v_broken_2418 = heff_dup(v_broken_247);
  V v_items_2419 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), heff_dup(v_items_249), NTAG(TAG_Nil)));
  V v_t_2420 = ({ V a_0 = v_broken_2418; V r_ = (g_heff_2esyntax_2esurface_2enameSet(a_0)); heff_drop(v_broken_2418); r_; });
  V v_t_2421 = (g_heff_2esyntax_2esurface_2esigNames(v_items_2419));
  V v_t_2422 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_2419));
  V v_t_2423 = (g_list_2emap_24s2130193383x1335133353(v_t_2420, v_t_2421, v_t_2422, v_items_2419));
  V v_t_2424 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2423));
  V v_items_2425 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_249, NTAG(TAG_Nil)));
  V v_t_2426 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
  V v_d_2430 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2ereadPlaced_lam0, 2, 1, (V[]){v_at_240}); V a_1 = v_t_2426; V a_2 = v_items_2425; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_items_2425); r_; });
  V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2430, 3, 4)));
  V v_t_2432 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2424, v_t_2431));
  V v_t_2433 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2417, v_t_2432));
  V v_t_2434 = (g_heff_2esyntax_2esurface_2eappendS(v_diags_248, v_t_2433));
  V v_t_2435 = (g_heff_2esyntax_2esurface_2eappendS(v_diags_2411, v_t_2434));
  V v_t_2436 = (g_heff_2esyntax_2esurface_2eappendS(v_lexDiags_241, v_t_2435));
  return heff_rec_n(5, shape_decls__diags__fixities__broken__arms, (V[]){v_t_2416, v_t_2436, v_fixities_2412, v_broken_247, v_arms_2410});
}
V g_heff_2esyntax_2esurface_2ereadPlaced_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereadPlaced(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2ereadPlaced_lam0(V self, V *args) {
  V v_d_2427 = args[0];
  V v_it_2428 = args[1];
  V v_at_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2427, 2)), v_it_2428));
  return ({ V a_0 = v_at_240; V a_1 = v_d_2427; V a_2 = v_t_2429; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2429); r_; });
}
Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_tag_n(TAG_Whole, 1, (V[]){v_x_242});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
    V v_u_246 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str0, 137, "a doc test is of the definition right under its doc comment, no blank line between: there is none here, so it is checked here, as a watch");
HEFF_LIT(g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str1, 100, "write it as a watch, `-- >>> e`, or move it into the doc comment right above the definition it is of");
Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V v_ys_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_s_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_s_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_x_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(151LL), NTAG(TAG_SWarning), ((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str0), v_t_246, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_str1)})});
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
    V v_u_249 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_24dps(v_ys_240, v_xs_243, heff_dup(v_cell_248)));
    heff_drop(v_u_249);
    return v_cell_248;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(a[0], a[1]);
}