// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_AsDefinition 21504
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclEquations 25755
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_INotationVar 46285
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkBinding 51651
#define TAG_MkEquation 38417
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_SetField 47531
#define TAG_SetPath 11095
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TSig 38418
#define TAG_TSum 38796
#define LBL_bind 9519364
#define LBL_bound 295286168
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_end 310101
#define LBL_giveBack 2038160732
#define LBL_giving 701566649
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth__giving__bound[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving, LBL_bound};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1538437128x977115133_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1538437128x977115133_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s381243888x312298213_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s381243888x312298213_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s386636727x1203660589_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s386636727x1203660589_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s589295666x2074476083_24dps_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24dps_24cpr(V, V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ealtBy(V, V);
V g_heff_2esyntax_2epresyntax_2ealtBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtBy_clo;
V g_heff_2esyntax_2epresyntax_2ealtOf(V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(V, V);
V g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076(V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_clo;
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(V, V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2efirst_244(V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2eparams_245(V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_clo;
V g_heff_2esyntax_2epresyntax_2egathered(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egathered_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egathered_clo;
V g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(V);
V g_heff_2esyntax_2epresyntax_2egathered_2eacc_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egathered_2eacc_240_clo;
V g_heff_2esyntax_2epresyntax_2egathered_2eeach_241(V);
V g_heff_2esyntax_2epresyntax_2egathered_2eeach_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egathered_2eeach_241_clo;
V g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get(void);
V g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2einfSpineOf_24cpr(V);
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
V g_heff_2esyntax_2epresyntax_2ementions(V, V);
V g_heff_2esyntax_2epresyntax_2ementions_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ementions_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2epatSpineOf_24cpr(V);
HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s1724669254x444492892_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_clo;
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eany_24s2003678755x1820404042(V);
V g_list_2eany_24s2003678755x1820404042_entry(V self, V *a);
extern Clo g_list_2eany_24s2003678755x1820404042_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s958865698x1719976126(V, V, V);
V g_list_2efoldl_24s958865698x1719976126_entry(V self, V *a);
extern Clo g_list_2efoldl_24s958865698x1719976126_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;

HeffT2 g_heff_2esyntax_2epresyntax_2epatSpineOf_24cpr(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_dup(heff_field(v_p_240, 0));
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
    }
    case TAG_PatTag: {
      V v_t_244 = heff_field(v_p1_241, 0);
      V v_tsp_245 = heff_field(v_p1_241, 1);
      V v_ps_246 = heff_field(v_p1_241, 2);
      V v_ru_24p1_241_24PatTag = heff_take_reuse_n(v_p1_241, 7ULL, 3);
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 0ULL, 2);
        V v_t_249 = heff_tag_re_n(v_ru_24p1_241_24PatTag, TAG_PatTag, 3, 1ULL, (V[]){v_t_244, heff_dup(v_tsp_245), NTAG(TAG_Nil)});
        return ((HeffT2){{heff_tag_at_n(v_ru_24p_240_24At, TAG_At, 2, (V[]){v_t_249, v_tsp_245}), v_ps_246}});
      }
      default: return ((HeffT2){{heff_nomatch(v_p_240)}});
      }
    }
    case TAG_PatOp: {
      V v_x_2410 = heff_field(v_p1_241, 0);
      V v_xsp_2411 = heff_field(v_p1_241, 1);
      V v_ps_2412 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 7ULL, 3);
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 0ULL, 2);
        V v_t_2415 = heff_tag_at_n(v_ru_24p_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_2410}), v_xsp_2411});
        return ((HeffT2){{v_t_2415, v_ps_2412}});
      }
      default: return ((HeffT2){{heff_nomatch(v_p_240)}});
      }
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
    }
    case TAG_PatBinary: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
    }
    case TAG_PatRecord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
    }
    case TAG_PatAs: {
      heff_take_n(v_p1_241, 0ULL, 3);
      return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_p1_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_p_240)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2einfSpineOf_24cpr(V v_i_240) {
top: ;
  switch (heff_tag_of(v_i_240)) {
  case TAG_At: {
    V v_i1_241 = heff_dup(heff_field(v_i_240, 0));
    switch (heff_tag_of(v_i1_241)) {
    case TAG_IVar: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_INotationVar: {
      heff_take_n(v_i1_241, 0ULL, 3);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_IInt: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_IFloat: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_IString: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_IBytes: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_IPrim: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_IRune: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_IApp: {
      V v_h_2413 = heff_field(v_i1_241, 0);
      V v_xs_2414 = heff_field(v_i1_241, 1);
      heff_take_n(v_i1_241, 3ULL, 2);
      switch (heff_tag_of(v_i_240)) {
      case TAG_At: {
        heff_take_n(v_i_240, 0ULL, 2);
        return ((HeffT2){{v_h_2413, v_xs_2414}});
      }
      default: return ((HeffT2){{heff_nomatch(v_i_240)}});
      }
    }
    case TAG_IAnn: {
      heff_take_n(v_i1_241, 0ULL, 2);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_ISpec: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_IUpdate: {
      heff_take_n(v_i1_241, 0ULL, 2);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_IAnnLam: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_IInvalid: {
      heff_take_n(v_i1_241, 0ULL, 3);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_INominal: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_ILitEq: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_ILazy: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    case TAG_ITuple: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return ((HeffT2){{v_i_240, NTAG(TAG_Nil)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_i1_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_i_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elocalFun_str0, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elocalFun_str1, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elocalFun_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2elocalFun(V v_f_240, V v_sp_241, V v_ps_242, V v_body_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elocalFun_str0)}), heff_dup(v_sp_241)});
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elocalFun_str1)}), heff_dup(v_sp_241)});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_ty_247 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_244, v_t_246));
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_242)));
  V v_t_249 = (g_list_2efoldl_24s958865698x1719976126(heff_dup(v_sp_241), v_ty_247, v_t_248));
  V v_t_2410 = (g_list_2emap_24s1937570095x2110149801(v_ps_242));
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){heff_dup(v_f_240), heff_dup(v_sp_241), v_t_2410, v_body_243}), heff_dup(v_sp_241)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_DeclEquations, 5, (V[]){v_f_240, heff_dup(v_sp_241), NTAG(TAG_AsDefinition), v_t_249, v_t_2412});
  return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_241});
}
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elocalFun(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s729807325x778998636_24dps_24cpr(V v_lit_240, V v_st_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    V v_u_244 = heff_setFieldPeek(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_245 = heff_hole();
    return ((HeffT2){{v_st_241, v_f_245}});
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x3_242, 0);
    V v_xs_247 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_f_248 = heff_dup(v_lit_240);
    V v_st_249 = v_st_241;
    V v_x3_2410 = v_x_246;
    V v_x1_2425;
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_At: {
      V v_x31_2411 = heff_field(v_x3_2410, 0);
      V v_sp_2412 = heff_field(v_x3_2410, 1);
      V v_ru_24x3_2410_24At = heff_take_reuse_n(v_x3_2410, 3ULL, 2);
      switch (heff_tag_of(v_x31_2411)) {
      case TAG_SetField: {
        V v_x_2413 = heff_field(v_x31_2411, 0);
        V v_xsp_2414 = heff_field(v_x31_2411, 1);
        V v_e_2415 = heff_field(v_x31_2411, 2);
        V v_ru_24x31_2411_24SetField = heff_take_reuse_n(v_x31_2411, 7ULL, 3);
        V v_x1_2416 = heff_tr(heff_call(v_f_248, 2, (V[]){v_st_249, v_e_2415}));
        switch (heff_tag_of(v_x1_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x1_2416, 0);
          V v_y_2418 = heff_field(v_x1_2416, 1);
          V v_ru_24x1_2416_24MkPair = heff_take_reuse_n(v_x1_2416, 3ULL, 2);
          V v_t_2419 = heff_tag_re_n(v_ru_24x3_2410_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_2411_24SetField, TAG_SetField, 3, 3ULL, (V[]){v_x_2413, v_xsp_2414, v_y_2418}), v_sp_2412});
          v_x1_2425 = heff_tag_re_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_x_2417, v_t_2419});
          break;
        }
        default: heff_nomatch(v_x1_2416);
        }
        break;
      }
      case TAG_BadFieldSet: {
        V v_e_2420 = heff_field(v_x31_2411, 0);
        V v_ru_24x31_2411_24BadFieldSet = heff_take_reuse_n(v_x31_2411, 1ULL, 1);
        V v_x1_2421 = heff_tr(heff_call(v_f_248, 2, (V[]){v_st_249, v_e_2420}));
        switch (heff_tag_of(v_x1_2421)) {
        case TAG_MkPair: {
          V v_x_2422 = heff_field(v_x1_2421, 0);
          V v_y_2423 = heff_field(v_x1_2421, 1);
          V v_ru_24x1_2421_24MkPair = heff_take_reuse_n(v_x1_2421, 3ULL, 2);
          V v_t_2424 = heff_tag_re_n(v_ru_24x3_2410_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x31_2411_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_y_2423}), v_sp_2412});
          v_x1_2425 = heff_tag_re_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_x_2422, v_t_2424});
          break;
        }
        default: heff_nomatch(v_x1_2421);
        }
        break;
      }
      default: heff_nomatch(v_x31_2411);
      }
      break;
    }
    default: heff_nomatch(v_x3_2410);
    }
    switch (heff_tag_of(v_x1_2425)) {
    case TAG_MkPair: {
      V v_st_2426 = heff_field(v_x1_2425, 0);
      V v_y_2427 = heff_field(v_x1_2425, 1);
      heff_take_n(v_x1_2425, 3ULL, 2);
      V v_cell_2428 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_y_2427, heff_hole()});
      V v_u_2429 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2428);
      V t_0 = v_lit_240;
      V t_1 = v_st_2426;
      V t_2 = v_xs_247;
      V t_3 = v_u_2429;
      v_lit_240 = t_0;
      v_st_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_2425)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2ealtBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ealtBy_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ealtBy(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_b_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24MkAlt = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(v_f_240, 1, (V[]){v_b_245}));
      return heff_tag_re_n(v_ru_24x2_241_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x21_242_24MkAlt, TAG_MkAlt, 2, 1ULL, (V[]){v_p_244, v_t_246}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ealtBy_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ealtBy(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s589295666x2074476083_24dps_24cpr(V v_st_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_u_243 = heff_setFieldPeek(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    V v_f_244 = heff_hole();
    return ((HeffT2){{v_st_240, v_f_244}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x3_241, 0);
    V v_xs_246 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_245)) {
    case TAG_At: {
      V v_a_247 = heff_field(v_x_245, 0);
      V v_a_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24At = heff_take_reuse_n(v_x_245, 3ULL, 2);
      switch (heff_tag_of(v_a_247)) {
      case TAG_MkAlt: {
        V v_a_249 = heff_field(v_a_247, 0);
        V v_a_2410 = heff_field(v_a_247, 1);
        V v_ru_24a_247_24MkAlt = heff_take_reuse_n(v_a_247, 3ULL, 2);
        V v_a_2425;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_2425 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          switch (heff_tag_of(v_a_2410)) {
          case TAG_At: {
            V v_a_2411 = heff_dup(heff_field(v_a_2410, 0));
            switch (heff_tag_of(v_a_2411)) {
            case TAG_ELam: {
              heff_take_n(v_a_2411, 0ULL, 2);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2425 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            case TAG_EReturn: {
              heff_take_n(v_a_2411, 0ULL, 1);
              switch (heff_tag_of(v_a_2410)) {
              case TAG_At: {
                v_a_2425 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_a_2410);
              }
              break;
            }
            default: {
              heff_drop(v_a_2411);
              HeffT2 v_t_2420 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24s1270299031x2098851536_24cpr(NTAG(TAG_False), heff_dup(v_a_2410)));
              {
                V v_field_2421 = v_t_2420.f[0];
                V v_field_2422 = v_t_2420.f[1];
                V v_a_2423 = v_field_2421;
                V v_a_2424 = v_field_2422;
                heff_drop(v_a_2424);
                v_a_2425 = v_a_2423;
              }
              break;
            }
            }
            break;
          }
          default: heff_nomatch(v_a_2410);
          }
        }
        V v_t_2426 = heff_tag_re_n(v_ru_24x_245_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_247_24MkAlt, TAG_MkAlt, 2, 3ULL, (V[]){v_a_249, v_a_2410}), v_a_248});
        V v_cell_2427 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
        V v_u_2428 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_2427);
        V t_0 = v_a_2425;
        V t_1 = v_xs_246;
        V t_2 = v_u_2428;
        v_st_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return ((HeffT2){{heff_nomatch(v_a_247)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_245)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s386636727x1203660589_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x31_244 = heff_field(v_x_242, 0);
      V v_sp_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x31_244)) {
      case TAG_SetField: {
        V v_x_246 = heff_field(v_x31_244, 0);
        V v_xsp_247 = heff_field(v_x31_244, 1);
        V v_e_248 = heff_field(v_x31_244, 2);
        V v_ru_24x31_244_24SetField = heff_take_reuse_n(v_x31_244, 7ULL, 3);
        V v_x_249;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_249 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_249 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_248)));
        }
        V v_t_2410 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_244_24SetField, TAG_SetField, 3, 7ULL, (V[]){v_x_246, v_xsp_247, v_e_248}), v_sp_245});
        V v_cell_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
        HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2eaccList_24s386636727x1203660589_24dps_24cpr(v_x_249, v_xs_243, v_cell_2411));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v_x_2415 = v_field_2413;
          V v__5f_2416 = v_field_2414;
          heff_drop(v__5f_2416);
          return ((HeffT2){{v_x_2415, v_cell_2411}});
        }
      }
      case TAG_BadFieldSet: {
        V v_e_2417 = heff_field(v_x31_244, 0);
        V v_ru_24x31_244_24BadFieldSet = heff_take_reuse_n(v_x31_244, 1ULL, 1);
        V v_x_2418;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2418 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2418 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_2417)));
        }
        V v_t_2419 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x31_244_24BadFieldSet, TAG_BadFieldSet, 1, 1ULL, (V[]){v_e_2417}), v_sp_245});
        V v_cell_2420 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
        HeffT2 v_t_2421 = (g_heff_2esyntax_2epresyntax_2eaccList_24s386636727x1203660589_24dps_24cpr(v_x_2418, v_xs_243, v_cell_2420));
        {
          V v_field_2422 = v_t_2421.f[0];
          V v_field_2423 = v_t_2421.f[1];
          V v_x_2424 = v_field_2422;
          V v__5f_2425 = v_field_2423;
          heff_drop(v__5f_2425);
          return ((HeffT2){{v_x_2424, v_cell_2420}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s1724669254x444492892_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_StmtBind: {
      V v_x_244 = heff_field(v_x31_242, 0);
      V v_xsp_245 = heff_field(v_x31_242, 1);
      V v_e_246 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtBind = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_247;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_247 = NTAG(TAG_True);
      } else {
        v_x_247 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_246)));
      }
      return ((HeffT3){{v_x_247, heff_tag_re_n(v_ru_24x31_242_24StmtBind, TAG_StmtBind, 3, 7ULL, (V[]){v_x_244, v_xsp_245, v_e_246}), v_sp_243}});
    }
    case TAG_StmtLet: {
      V v_p_248 = heff_field(v_x31_242, 0);
      V v_e_249 = heff_field(v_x31_242, 1);
      heff_take_n(v_x31_242, 3ULL, 2);
      V v_x_2410;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2410 = NTAG(TAG_True);
      } else {
        v_x_2410 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_249)));
      }
      return ((HeffT3){{v_x_2410, heff_tag_at_n(v_ru_24x3_241_24At, TAG_StmtLet, 2, (V[]){v_p_248, v_e_249}), v_sp_243}});
    }
    case TAG_StmtExpr: {
      V v_e_2411 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24StmtExpr = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2412;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2412 = NTAG(TAG_True);
      } else {
        v_x_2412 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_2411)));
      }
      return ((HeffT3){{v_x_2412, heff_tag_re_n(v_ru_24x31_242_24StmtExpr, TAG_StmtExpr, 1, 1ULL, (V[]){v_e_2411}), v_sp_243}});
    }
    case TAG_StmtLetMut: {
      V v_x_2413 = heff_field(v_x31_242, 0);
      V v_xsp_2414 = heff_field(v_x31_242, 1);
      V v_e_2415 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtLetMut = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2416;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2416 = NTAG(TAG_True);
      } else {
        v_x_2416 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_2415)));
      }
      return ((HeffT3){{v_x_2416, heff_tag_re_n(v_ru_24x31_242_24StmtLetMut, TAG_StmtLetMut, 3, 7ULL, (V[]){v_x_2413, v_xsp_2414, v_e_2415}), v_sp_243}});
    }
    case TAG_StmtLetElse: {
      V v_p_2417 = heff_field(v_x31_242, 0);
      V v_e_2418 = heff_field(v_x31_242, 1);
      V v_ss_2419 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtLetElse = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2420;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2420 = NTAG(TAG_True);
      } else {
        v_x_2420 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_2418)));
      }
      HeffT2 v_t_2421 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_x_2420, v_ss_2419));
      {
        V v_field_2422 = v_t_2421.f[0];
        V v_field_2423 = v_t_2421.f[1];
        V v_x_2424 = v_field_2422;
        V v_y_2425 = v_field_2423;
        return ((HeffT3){{v_x_2424, heff_tag_re_n(v_ru_24x31_242_24StmtLetElse, TAG_StmtLetElse, 3, 3ULL, (V[]){v_p_2417, v_e_2418, v_y_2425}), v_sp_243}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x3_241)}});
  }
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s381243888x312298213_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkBinding: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_ru_24a_244_24MkBinding = heff_take_reuse_n(v_a_244, 7ULL, 3);
        V v_a_249;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_a_249 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_a_249 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_a_248)));
        }
        V v_t_2410 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_244_24MkBinding, TAG_MkBinding, 3, 7ULL, (V[]){v_a_246, v_a_247, v_a_248}), v_a_245});
        V v_cell_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
        HeffT2 v_t_2412 = (g_heff_2esyntax_2epresyntax_2eaccList_24s381243888x312298213_24dps_24cpr(v_a_249, v_xs_243, v_cell_2411));
        {
          V v_field_2413 = v_t_2412.f[0];
          V v_field_2414 = v_t_2412.f[1];
          V v_x_2415 = v_field_2413;
          V v__5f_2416 = v_field_2414;
          heff_drop(v__5f_2416);
          return ((HeffT2){{v_x_2415, v_cell_2411}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str0, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str1, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str2, 12, "builtin.List");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str3, 4, "Cons");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str4, 12, "list.reverse");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str5, 3, "Nil");
Clo g_heff_2esyntax_2epresyntax_2egathered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2egathered_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2egathered(V v_p_240, V v_sp_241, V v_q_242, V v_c_243, V v_body_244) {
top: ;
  V v_it_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_body_244));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    heff_drop(v_q_242);
    heff_drop(v_c_243);
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_sp_241)});
    V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_246}), v_sp_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_it1_248 = heff_field(v_it_245, 0);
    V v_before_249 = heff_field(v_it_245, 1);
    V v_ru_24it_245_24Cons = heff_take_reuse_n(v_it_245, 3ULL, 2);
    switch (heff_tag_of(v_it1_248)) {
    case TAG_At: {
      V v_it11_2410 = heff_field(v_it1_248, 0);
      V v_esp_2411 = heff_field(v_it1_248, 1);
      V v_ru_24it1_248_24At = heff_take_reuse_n(v_it1_248, 3ULL, 2);
      switch (heff_tag_of(v_it11_2410)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_2410, 0ULL, 3);
        heff_drop(v_p_240);
        heff_drop(v_q_242);
        heff_drop(v_c_243);
        heff_drop(v_before_249);
        heff_drop(v_esp_2411);
        V v_t_2415 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_sp_241)});
        V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2415}), v_sp_241});
        return heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      }
      case TAG_StmtLet: {
        V v_ru_24it11_2410_24StmtLet = heff_take_reuse_n(v_it11_2410, 0ULL, 2);
        heff_drop(v_p_240);
        heff_drop(v_q_242);
        heff_drop(v_c_243);
        heff_drop(v_before_249);
        heff_drop(v_esp_2411);
        V v_t_2419 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_sp_241)});
        V v_t_2420 = heff_tag_at_n(v_ru_24it11_2410_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2419}), v_sp_241});
        return heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
      }
      case TAG_StmtExpr: {
        V v_e_2421 = heff_field(v_it11_2410, 0);
        V v_ru_24it11_2410_24StmtExpr = heff_take_reuse_n(v_it11_2410, 1ULL, 1);
        V v_t_2422 = (g_heff_2esyntax_2epresyntax_2eisControl(v_e_2421));
        if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
          heff_drop(v_p_240);
          heff_drop_rec(v_sp_241, 2);
          heff_drop(v_q_242);
          heff_drop(v_c_243);
          heff_drop(v_before_249);
          heff_drop(v_e_2421);
          heff_drop(v_t_2422);
          V v_t_2423 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_esp_2411)});
          V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24it11_2410_24StmtExpr, TAG_StmtExpr, 1, (V[]){v_t_2423}), v_esp_2411});
          return heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
        } else {
          heff_drop(v_t_2422);
          V v_t_2425 = (g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(heff_dup(v_sp_241)));
          V v_t_2426 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str0)}), heff_dup(v_sp_241)});
          V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str1)}), heff_dup(v_sp_241)});
          V v_t_2428 = heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
          V v_t_2429 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2426, v_t_2428));
          V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str2)}), heff_dup(v_sp_241)});
          V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
          V v_t_2432 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2430, v_t_2431));
          V v_t_2435;
          switch (heff_tag_of(v_t_2432)) {
          case TAG_At: {
            V v_s_2434 = heff_dup(heff_field(v_t_2432, 1));
            v_t_2435 = v_s_2434;
            break;
          }
          default: heff_nomatch(v_t_2432);
          }
          V v_t_2436 = (g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(heff_dup(v_sp_241)));
          V v_t_2437 = (g_heff_2esyntax_2epresyntax_2egathered_2eeach_241(heff_dup(v_sp_241)));
          V v_t_2438 = (g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(heff_dup(v_sp_241)));
          V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str3)}), heff_dup(v_esp_2411)});
          V v_t_2440 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2437}), heff_dup(v_esp_2411)});
          V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2438}), heff_dup(v_esp_2411)});
          V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
          V v_t_2443 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2439, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, v_t_2442})));
          V v_t_2444 = (g_heff_2esyntax_2epresyntax_2egathered_2eeach_241(heff_dup(v_sp_241)));
          V v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAssign, 3, (V[]){v_t_2436, heff_dup(v_esp_2411), v_t_2443}), heff_dup(v_esp_2411)});
          V v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24it11_2410_24StmtExpr, TAG_StmtExpr, 1, (V[]){v_t_2445}), heff_dup(v_esp_2411)});
          V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtBind, 3, (V[]){v_t_2444, heff_dup(v_esp_2411), v_e_2421}), v_esp_2411});
          V v_xs_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, v_before_249})});
          V v_t_2449 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2448));
          V v_t_2450 = (g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(heff_dup(v_sp_241)));
          V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str4)}), heff_dup(v_sp_241)});
          V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2450}), heff_dup(v_sp_241)});
          V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
          V v_t_2454 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2451, v_t_2453));
          V v_t_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str5)}), heff_dup(v_sp_241)});
          V v_t_2456 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_241, 0)); V rr_ = heff_rec_reuse_nf(v_t_2435, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2457 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_t_2455, v_t_2432}), v_t_2456});
          V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLetMut, 3, (V[]){v_t_2425, heff_dup(v_sp_241), v_t_2457}), heff_dup(v_sp_241)});
          V v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EFor, 3, (V[]){v_q_242, v_c_243, v_t_2449}), heff_dup(v_sp_241)});
          V v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2459}), heff_dup(v_sp_241)});
          V v_t_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_p_240, v_t_2454}), v_sp_241});
          V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2460, v_t_2462})});
        }
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_2410, 0ULL, 3);
        heff_drop(v_p_240);
        heff_drop(v_q_242);
        heff_drop(v_c_243);
        heff_drop(v_before_249);
        heff_drop(v_esp_2411);
        V v_t_2466 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_sp_241)});
        V v_t_2467 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2466}), v_sp_241});
        return heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_2410, 0ULL, 3);
        heff_drop(v_p_240);
        heff_drop(v_q_242);
        heff_drop(v_c_243);
        heff_drop(v_before_249);
        heff_drop(v_esp_2411);
        V v_t_2471 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_sp_241)});
        V v_t_2472 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2471}), v_sp_241});
        return heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2472, NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_it11_2410);
      }
    }
    default: return heff_nomatch(v_it1_248);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2esyntax_2epresyntax_2egathered_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2egathered(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str0, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str1, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str2, 9, "iterateOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str3, 5, "coll#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str4, 4, "next");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str5, 6, "after#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str6, 6, "after#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str7, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str8, 5, "coll#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str9, 5, "next#");
V g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216(V v_cx_240, V v_sp_241, V v_p_242, V v_coll_243, V v_body_244, V v_rest_245, V v_end_246) {
top: ;
  V v_t_247 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
  HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_247}), NTAG(TAG_Nil), v_coll_243));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_x_2411 = v_field_249;
    V v_y_2412 = v_field_2410;
    V v_sp_2415;
    switch (heff_tag_of(v_y_2412)) {
    case TAG_At: {
      V v_s_2414 = heff_dup(heff_field(v_y_2412, 1));
      v_sp_2415 = v_s_2414;
      break;
    }
    default: heff_nomatch(v_y_2412);
    }
    V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str0)}), heff_dup(v_sp_2415)});
    V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str1)}), v_sp_2415});
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_t_2419 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2416, v_t_2418));
    V v_t_2422;
    switch (heff_tag_of(v_y_2412)) {
    case TAG_At: {
      V v_s_2421 = heff_dup(heff_field(v_y_2412, 1));
      v_t_2422 = v_s_2421;
      break;
    }
    default: heff_nomatch(v_y_2412);
    }
    V v_v_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_y_2412, v_t_2419}), v_t_2422});
    V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str2)}), heff_dup(v_sp_241)});
    V v_t_2425 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
    V v_t_2426 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str3), v_t_2425)});
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2426, heff_dup(v_sp_241)}), NTAG(TAG_Nil)});
    V v_t_2428 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2424, v_t_2427));
    V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EProject, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str4)}), heff_dup(v_sp_241)});
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    V v_v_2431 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2428, v_t_2430));
    V v_t_2432 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 2, 3);
    V v_body_2465;
    if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
      heff_drop(v_t_2432);
      V v_cx_2433 = heff_dup(v_cx_240);
      V v_sp_2434 = heff_dup(v_sp_241);
      V v_body_2435 = v_body_244;
      V v_p_2436 = v_p_242;
      V v_rest_2437 = v_rest_245;
      V v_end_2438 = v_end_246;
      V v_t_2439 = (g_list_2eany_24s2003678755x1820404042(heff_dup(v_body_2435)));
      V v_t_2440 = (g_heff_2esyntax_2epresyntax_2eforT_2efirst_244(heff_dup(v_sp_2434), heff_dup(v_cx_2433)));
      V v_t_2441 = (g_heff_2esyntax_2epresyntax_2eforT_2eparams_245(heff_dup(v_sp_2434), heff_dup(v_cx_2433)));
      v_body_2465 = ({ V a_0 = heff_dup(v_cx_2433); V a_1 = heff_dup(v_sp_2434); V a_2 = v_t_2439; V a_3 = v_t_2440; V a_4 = v_t_2441; V a_5 = heff_clo_n(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_lam0, 1, 4, (V[]){v_body_2435, v_cx_2433, v_sp_2434, v_p_2436}); V a_6 = v_rest_2437; V a_7 = v_end_2438; V r_ = (g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2439); heff_drop(v_rest_2437); r_; });
    } else {
      heff_drop(v_t_2432);
      V v_sp_2445 = heff_dup(v_sp_241);
      V v_cx_2446 = heff_dup(v_cx_240);
      V v_rest_2447 = v_rest_245;
      V v_end_2448 = v_end_246;
      V v_p_2449 = v_p_242;
      V v_body_2450 = v_body_244;
      V v_t_2451 = (g_heff_2esyntax_2epresyntax_2eforT_2efirst_244(heff_dup(v_sp_2445), heff_dup(v_cx_2446)));
      V v_t_2452 = ({ V a_0 = heff_dup(v_sp_2445); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_2446, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      V v_t_2453 = ({ V a_0 = heff_dup(v_cx_2446); V a_1 = v_rest_2447; V a_2 = v_end_2448; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_rest_2447); r_; });
      V v_t_2454 = heff_intShow(heff_dup(heff_rfield(v_sp_2445, 0)));
      V v_t_2455 = (g_heff_2esyntax_2epresyntax_2elocalFun(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str5), v_t_2454), heff_dup(v_sp_2445), v_t_2452, v_t_2453));
      V v_t_2456 = (g_heff_2esyntax_2epresyntax_2eforT_2eparams_245(heff_dup(v_sp_2445), heff_dup(v_cx_2446)));
      V v_t_2457 = heff_intShow(heff_dup(heff_rfield(v_sp_2445, 0)));
      V v_t_2458 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str6), v_t_2457)});
      V v_t_2459 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2458, heff_dup(v_sp_2445)}), heff_dup(heff_rfield(v_cx_2446, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_2446, 4))});
      V v_t_2460 = ({ V a_0 = heff_dup(v_sp_2445); V a_1 = v_p_2449; V a_2 = heff_dup(v_cx_2446); V a_3 = v_body_2450; V a_4 = v_t_2459; V a_5 = v_cx_2446; V r_ = (g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_body_2450); r_; });
      V v_t_2461 = heff_intShow(heff_dup(heff_rfield(v_sp_2445, 0)));
      V v_t_2462 = (g_heff_2esyntax_2epresyntax_2elocalFun(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str7), v_t_2461), heff_dup(v_sp_2445), v_t_2456, v_t_2460));
      V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
      V v_t_2464 = heff_tag_n(TAG_ELocal, 2, (V[]){v_t_2451, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_t_2463})});
      v_body_2465 = heff_tag_n(TAG_At, 2, (V[]){v_t_2464, v_sp_2445});
    }
    V v_t_2468;
    switch (heff_tag_of(v_body_2465)) {
    case TAG_At: {
      V v_s_2467 = heff_dup(heff_field(v_body_2465, 1));
      v_t_2468 = v_s_2467;
      break;
    }
    default: heff_nomatch(v_body_2465);
    }
    V v_t_2469 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_241, 0)); V rr_ = heff_rec_reuse_nf(v_t_2468, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2472;
    switch (heff_tag_of(v_body_2465)) {
    case TAG_At: {
      V v_s_2471 = heff_dup(heff_field(v_body_2465, 1));
      v_t_2472 = v_s_2471;
      break;
    }
    default: heff_nomatch(v_body_2465);
    }
    V v_t_2473 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_241, 0)); V rr_ = heff_rec_reuse_nf(v_t_2472, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2474 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
    V v_t_2475 = heff_tag_n(TAG_PatVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str8), v_t_2474)});
    V v_t_2476 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
    V v_t_2477 = heff_tag_n(TAG_PatVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str9), v_t_2476)});
    V v_t_2478 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2477, heff_dup(v_sp_241)}), v_body_2465});
    V v_t_2479 = heff_tag_n(TAG_ELetIn, 2, (V[]){v_v_2431, heff_tag_n(TAG_At, 2, (V[]){v_t_2478, v_t_2469})});
    V v_t_2480 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2475, heff_dup(v_sp_241)}), heff_tag_n(TAG_At, 2, (V[]){v_t_2479, heff_dup(v_t_2473)})});
    V v_t_2481 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_241, 0)), heff_dup(heff_rfield(v_t_2473, 1))});
    V v_t_2482 = heff_tag_n(TAG_ELetIn, 2, (V[]){v_v_2423, heff_tag_n(TAG_At, 2, (V[]){v_t_2480, v_t_2481})});
    V v_t_2483 = ({ V rv_1 = heff_get_n(v_t_2473, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_241, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    return ({ V a_0 = v_cx_240; V a_1 = v_x_2411; V a_2 = heff_tag_n(TAG_At, 2, (V[]){v_t_2482, v_t_2483}); V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
  }
}
V g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_lam0(V self, V *args) {
  V v_exitJ_2442 = args[0];
  V v_body_2435 = heff_env(self)[0];
  V v_cx_2433 = heff_env(self)[1];
  V v_sp_2434 = heff_env(self)[2];
  V v_p_2436 = heff_env(self)[3];
  V v_ret_2443 = (g_list_2eany_24s2003678755x1820404042(heff_dup(v_body_2435)));
  V v_t_2444 = heff_rec_n(7, shape_names__muts__loop__sp__depth__giving__bound, (V[]){heff_dup(heff_rfield(v_cx_2433, 0)), heff_dup(heff_rfield(v_cx_2433, 1)), heff_dup(heff_rfield(v_cx_2433, 2)), heff_dup(heff_rfield(v_cx_2433, 3)), heff_dup(heff_rfield(v_cx_2433, 4)), heff_tag_n(TAG_Just, 1, (V[]){v_ret_2443}), heff_dup(heff_rfield(v_cx_2433, 6))});
  heff_clo_take(self, 4);
  return ({ V a_0 = v_sp_2434; V a_1 = v_p_2436; V a_2 = v_cx_2433; V a_3 = v_body_2435; V a_4 = v_exitJ_2442; V a_5 = v_t_2444; V r_ = (g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_body_2435); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_str0, 10, "leaveScope");
Clo g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172(V v_cx_240, V v_sp_241, V v_w_242, V v_x_243, V v_xsp_244, V v_body_245, V v_end_246) {
top: ;
  V v_t_247 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
  HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_247}), NTAG(TAG_Nil), v_w_242));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_x_2411 = v_field_249;
    V v_y_2412 = v_field_2410;
    V v_t_2413 = heff_intAdd(heff_dup(heff_rfield(v_cx_240, 4)), MK_INT(1LL));
    V v_t_2414 = heff_rec_n(7, shape_names__muts__loop__sp__depth__giving__bound, (V[]){heff_dup(heff_rfield(v_cx_240, 0)), heff_dup(heff_rfield(v_cx_240, 1)), heff_dup(heff_rfield(v_cx_240, 2)), heff_dup(heff_rfield(v_cx_240, 3)), v_t_2413, heff_dup(heff_rfield(v_cx_240, 5)), heff_dup(heff_rfield(v_cx_240, 6))});
    V v_e_2415 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(v_t_2414, v_body_245, v_end_246));
    V v_t_2418;
    switch (heff_tag_of(v_e_2415)) {
    case TAG_At: {
      V v_s_2417 = heff_dup(heff_field(v_e_2415, 1));
      v_t_2418 = v_s_2417;
      break;
    }
    default: heff_nomatch(v_e_2415);
    }
    V v_t_2419 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_243, heff_dup(v_xsp_244)}), v_e_2415});
    V v_t_2420 = ({ V rv_1 = heff_get_n(v_t_2418, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_244, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_t_2420}), NTAG(TAG_Nil)});
    V v_t_2422 = (g_heff_2esyntax_2epresyntax_2eapp(v_y_2412, v_t_2421));
    V v_t_2423 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 0, 3);
    V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2423}), heff_dup(heff_rfield(v_cx_240, 3))});
    V v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_str0)}), v_sp_241});
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
    V v_t_2427 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2424, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2426})));
    return ({ V a_0 = v_cx_240; V a_1 = v_x_2411; V a_2 = v_t_2427; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
  }
}
V g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172(a[0], a[1], a[2], a[3], a[4], a5, a[6]); heff_drop(a5); return r;
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s1538437128x977115133_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_ru_24a_244_24SetPath = heff_take_reuse_n(v_a_244, 3ULL, 2);
        V v_a_248 = (g_heff_2esyntax_2epresyntax_2eassignedIn_2eassignsOf_240(heff_dup(v_a_247), v_st_240));
        V v_t_249 = heff_tag_re_n(v_ru_24x_242_24At, TAG_At, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24a_244_24SetPath, TAG_SetPath, 2, 3ULL, (V[]){v_a_246, v_a_247}), v_a_245});
        V v_cell_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
        HeffT2 v_t_2411 = (g_heff_2esyntax_2epresyntax_2eaccList_24s1538437128x977115133_24dps_24cpr(v_a_248, v_xs_243, v_cell_2410));
        {
          V v_field_2412 = v_t_2411.f[0];
          V v_field_2413 = v_t_2411.f[1];
          V v_x_2414 = v_field_2412;
          V v__5f_2415 = v_field_2413;
          heff_drop(v__5f_2415);
          return ((HeffT2){{v_x_2414, v_cell_2410}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_a_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}
V g_heff_2esyntax_2epresyntax_2ementions_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2ementions_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ementions_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ementions(V v_x_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_241, 0));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EVar: {
      V v_y_244 = heff_field(v_e1_242, 0);
      heff_take_n(v_e1_242, 1ULL, 1);
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        heff_take_n(v_e_241, 0ULL, 2);
        V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_244, 0));
        heff_drop(v_y_244);
        return v_ret_24bool;
      }
      default: return heff_nomatch(v_e_241);
      }
    }
    default: {
      heff_drop(v_e1_242);
      HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2echildrenAcc_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2ementions_lam0, 2, 1, (V[]){heff_dup(v_x_240)}), NTAG(TAG_False), v_e_241));
      {
        V v_field_2411 = v_t_2410.f[0];
        V v_field_2412 = v_t_2410.f[1];
        V v_x_2413 = v_field_2411;
        V v_y_2414 = v_field_2412;
        heff_drop(v_y_2414);
        return v_x_2413;
      }
    }
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ementions_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2ementions(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2epresyntax_2ementions_lam0(V self, V *args) {
  V v_b_247 = args[0];
  V v_c_248 = args[1];
  V v_x_240 = heff_env(self)[0];
  V v_t_249;
  heff_clo_take(self, 1);
  if ((heff_dup(v_b_247) == NTAG(TAG_True))) {
    heff_drop(v_b_247);
    heff_drop(v_x_240);
    v_t_249 = NTAG(TAG_True);
  } else {
    heff_drop(v_b_247);
    v_t_249 = ({ V a_0 = v_x_240; V a_1 = heff_dup(v_c_248); V r_ = (g_heff_2esyntax_2epresyntax_2ementions(a_0, a_1)); heff_drop(v_x_240); r_; });
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_c_248});
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str0, 13, "this notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str1, 13, "this notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str2, 8, "a lambda");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str3, 8, "a lambda");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str4, 8, "a lambda");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str5, 5, "a tag");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str6, 8, "a record");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str7, 8, "a `case`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str8, 29, "a `let` whose body is checked");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str9, 19, "a term with `where`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str10, 9, "`abandon`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str11, 13, "this notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str12, 64, " does not infer its type: it must be put where its type is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str13, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str14, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str15, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etoInferable_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etoInferable(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IsInferable: {
    V v_i_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_i_241;
  }
  case TAG_IsCheckable: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24IsCheckable = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_c_243 = heff_field(v_x11_242, 0);
      V v_sp_244 = heff_field(v_x11_242, 1);
      V v_ru_24x11_242_24At = heff_take_reuse_n(v_x11_242, 3ULL, 2);
      V v_t_2428;
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInf: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str0);
        break;
      }
      case TAG_CType: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str1);
        break;
      }
      case TAG_CLam: {
        heff_take_n(v_c_243, 0ULL, 3);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str2);
        break;
      }
      case TAG_CImplicitLam: {
        heff_take_n(v_c_243, 0ULL, 3);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str3);
        break;
      }
      case TAG_CAnnLam: {
        heff_take_n(v_c_243, 0ULL, 4);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str4);
        break;
      }
      case TAG_CTag: {
        heff_take_n(v_c_243, 0ULL, 3);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str5);
        break;
      }
      case TAG_CStruct: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str6);
        break;
      }
      case TAG_CMatch: {
        heff_take_n(v_c_243, 0ULL, 2);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str7);
        break;
      }
      case TAG_CLetIn: {
        heff_take_n(v_c_243, 0ULL, 2);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str8);
        break;
      }
      case TAG_CLocal: {
        heff_take_n(v_c_243, 0ULL, 2);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str9);
        break;
      }
      case TAG_CAbandon: {
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str10);
        break;
      }
      case TAG_CNominal: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str11);
        break;
      }
      default: heff_nomatch(v_c_243);
      }
      V v_t_2429 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), heff_strAppend(v_t_2428, ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str12)), heff_tag_at_n(v_ru_24x1_240_24IsCheckable, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
      return heff_tag_re_n(v_ru_24x11_242_24At, TAG_At, 2, 2ULL, (V[]){v_t_2429, v_sp_244});
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_IsType: {
    V v_x11_2430 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24IsType = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_At: {
      V v_x111_2431 = heff_dup(heff_field(v_x11_2430, 0));
      switch (heff_tag_of(v_x111_2431)) {
      case TAG_TSig: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24IsType, 1);
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_sp_2435 = heff_field(v_x11_2430, 1);
          V v_ru_24x11_2430_24At = heff_take_reuse_n(v_x11_2430, 2ULL, 2);
          V v_t_2436 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str13), NTAG(TAG_Nothing)});
          return heff_tag_re_n(v_ru_24x11_2430_24At, TAG_At, 2, 2ULL, (V[]){v_t_2436, v_sp_2435});
        }
        default: return heff_nomatch(v_x11_2430);
        }
      }
      case TAG_TSum: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24IsType, 1);
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_sp_2439 = heff_field(v_x11_2430, 1);
          V v_ru_24x11_2430_24At = heff_take_reuse_n(v_x11_2430, 2ULL, 2);
          V v_t_2440 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str14), NTAG(TAG_Nothing)});
          return heff_tag_re_n(v_ru_24x11_2430_24At, TAG_At, 2, 2ULL, (V[]){v_t_2440, v_sp_2439});
        }
        default: return heff_nomatch(v_x11_2430);
        }
      }
      default: {
        heff_drop(v_x111_2431);
        V v_t_2443;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2442 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2443 = v_s_2442;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        V v_t_2444 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str15), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2444, v_t_2443});
      }
      }
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etoInferable(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ealtOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ealtOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_b_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24MkAlt = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_245}));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        V v_ru_24x1_246_24IsInferable = heff_take_reuse_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_246_24IsInferable, TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        V v_ru_24x1_246_24IsType = heff_take_reuse_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_246_24IsType, TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_re_n(v_ru_24x21_242_24MkAlt, TAG_MkAlt, 2, 1ULL, (V[]){v_p_244, v_t_2416}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ealtOf(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EImplicitVar: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENotationVar: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EString: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBinary: {
    V v_segs_2410 = heff_field(v_x1_240, 0);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_segs_2410)}});
  }
  case TAG_ERune: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWord: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProject: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENamed: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPi: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAnn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESpec: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESig: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESum: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStruct: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUpdate: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetIn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EDo: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELocal: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInvalid: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EIfThen: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBreak: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EContinue: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELazy: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETuple: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETry: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWith: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWithBound: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178(V v_lit_240, V v_x2_241, V v_run_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_242)) {
    case TAG_Nothing: {
      heff_drop(v_lit_240);
      return v_acc_243;
    }
    case TAG_Just: {
      V v_x21_244 = heff_field(v_run_242, 0);
      V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_MkPair: {
        V v_s_245 = heff_field(v_x21_244, 0);
        V v_sp_246 = heff_field(v_x21_244, 1);
        V v_ru_24x21_244_24MkPair = heff_take_reuse_n(v_x21_244, 3ULL, 2);
        V v_t_247 = heff_tag_at_n(v_ru_24x21_244_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_242_24Just, TAG_IPrim, 1, (V[]){v_lit_240}), heff_dup(v_sp_246)});
        V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_245}), heff_dup(v_sp_246)});
        V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_248}), heff_dup(v_sp_246)});
        V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_249}), heff_dup(v_sp_246)});
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
        V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_247, v_t_2411}), heff_dup(v_sp_246)});
        V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2412}), v_sp_246});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_acc_243});
      }
      default: return heff_nomatch(v_x21_244);
      }
    }
    default: return heff_nomatch(v_run_242);
    }
  }
  case TAG_Cons: {
    V v_x21_2414 = heff_field(v_x2_241, 0);
    V v_rest_2415 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2414)) {
    case TAG_At: {
      V v_seg_2416 = heff_field(v_x21_2414, 0);
      V v_sp_2417 = heff_field(v_x21_2414, 1);
      V v_ru_24x21_2414_24At = heff_take_reuse_n(v_x21_2414, 3ULL, 2);
      HeffT2 v_t_2418 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_2416));
      {
        V v_field_2420 = v_t_2418.f[1];
        int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
        if ((v_tag_2419 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_seg_2416);
          heff_drop_cell(v_ru_24x21_2414_24At, 2);
          V v_s_2421 = v_field_2420;
          V v_t_2427;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            v_t_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_2421, v_sp_2417})});
            break;
          }
          case TAG_Just: {
            V v_x11_2422 = heff_field(v_run_242, 0);
            V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x11_2422)) {
            case TAG_MkPair: {
              V v_s0_2423 = heff_field(v_x11_2422, 0);
              V v_sp0_2424 = heff_field(v_x11_2422, 1);
              V v_ru_24x11_2422_24MkPair = heff_take_reuse_n(v_x11_2422, 3ULL, 2);
              V v_t_2425 = ({ V rv_1 = heff_get_n(v_sp_2417, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2424, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2426 = heff_tag_at_n(v_ru_24x11_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2423, v_s_2421), v_t_2425});
              v_t_2427 = heff_tag_at_n(v_ru_24run_242_24Just, TAG_Just, 1, (V[]){v_t_2426});
              break;
            }
            default: heff_nomatch(v_x11_2422);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_lit_240;
          V t_1 = v_rest_2415;
          V t_2 = v_t_2427;
          V t_3 = v_acc_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        } else {
          heff_drop(v_field_2420);
          V v_t_2428 = (g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076(heff_tag_re_n(v_ru_24x21_2414_24At, TAG_At, 2, 3ULL, (V[]){v_seg_2416, v_sp_2417})));
          V v_t_2439;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            v_t_2439 = v_acc_243;
            break;
          }
          case TAG_Just: {
            V v_x21_2429 = heff_field(v_run_242, 0);
            V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x21_2429)) {
            case TAG_MkPair: {
              V v_s_2430 = heff_field(v_x21_2429, 0);
              V v_sp_2431 = heff_field(v_x21_2429, 1);
              V v_ru_24x21_2429_24MkPair = heff_take_reuse_n(v_x21_2429, 3ULL, 2);
              V v_t_2432 = heff_tag_at_n(v_ru_24x21_2429_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_242_24Just, TAG_IPrim, 1, (V[]){heff_dup(v_lit_240)}), heff_dup(v_sp_2431)});
              V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_2430}), heff_dup(v_sp_2431)});
              V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2433}), heff_dup(v_sp_2431)});
              V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2434}), heff_dup(v_sp_2431)});
              V v_t_2436 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
              V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2432, v_t_2436}), heff_dup(v_sp_2431)});
              V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2437}), v_sp_2431});
              v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, v_acc_243});
              break;
            }
            default: heff_nomatch(v_x21_2429);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_lit_240;
          V t_1 = v_rest_2415;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2439});
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x21_2414);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178(a[0], a[1], a[2], a[3]);
}