// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AsDefinition 21504
#define TAG_At 8900
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclEquations 25755
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_IInvalid 29207
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_args 9498020
#define LBL_e 319
#define LBL_end 310101
#define LBL_head 9693863
#define LBL_start 311115900
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2epresyntax_2ealtBy(V, V);
V g_heff_2esyntax_2epresyntax_2ealtBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtBy_clo;
V g_heff_2esyntax_2epresyntax_2ealtOf(V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(V);
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void);
V g_heff_2esyntax_2epresyntax_2egathered(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egathered_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egathered_clo;
V g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(V);
V g_heff_2esyntax_2epresyntax_2egathered_2eacc_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egathered_2eacc_240_clo;
V g_heff_2esyntax_2epresyntax_2egathered_2eeach_241(V);
V g_heff_2esyntax_2epresyntax_2egathered_2eeach_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egathered_2eeach_241_clo;
V g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get(void);
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s958865698x1719976126(V, V, V);
V g_list_2efoldl_24s958865698x1719976126_entry(V self, V *a);
extern Clo g_list_2efoldl_24s958865698x1719976126_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
Clo g_heff_2esyntax_2epresyntax_2espineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2espineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2espineOf(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ETag: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EInt: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EString: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EBinary: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ERune: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EWord: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EApp: {
      V v_h_2412 = heff_field(v_e1_241, 0);
      V v_xs_2413 = heff_field(v_e1_241, 1);
      heff_take_n(v_e1_241, 3ULL, 2);
      heff_drop_tag(v_e_240, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_h_2412, v_xs_2413});
    }
    case TAG_EProject: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EPi: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ESig: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ESum: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EUpdate: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EDo: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_241, 0ULL, 3);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EWhile: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EFor: {
      heff_take_n(v_e1_241, 0ULL, 3);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EIfThen: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EBreak: {
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EContinue: {
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EReturn: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ENest: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELazy: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ETuple: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ETry: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EWith: {
      heff_take_n(v_e1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2espineOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elocalFun_str0, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elocalFun_str1, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elocalFun_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2elocalFun(V v_f_240, V v_sp_241, V v_ps_242, V v_body_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elocalFun_str0)}), heff_dup(v_sp_241)});
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elocalFun_str1)}), heff_dup(v_sp_241)});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_z_247 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_244, v_t_246));
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_242)));
  V v_t_249 = (g_list_2efoldl_24s958865698x1719976126(heff_dup(v_sp_241), v_z_247, v_t_248));
  V v_t_2410 = (g_list_2emap_24s1937570095x2110149801(v_ps_242));
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){heff_dup(v_f_240), heff_dup(v_sp_241), v_t_2410, v_body_243}), heff_dup(v_sp_241)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_DeclEquations, 5, (V[]){v_f_240, heff_dup(v_sp_241), NTAG(TAG_AsDefinition), v_t_249, v_t_2412});
  return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_241});
}
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elocalFun(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2epresyntax_2ealtBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ealtBy_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ealtBy(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_b_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(v_f_240, 1, (V[]){v_b_245}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_244, v_t_246}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ealtBy_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ealtBy(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str0, 12, "builtin.List");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str1, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str2, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str3, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str4, 4, "Cons");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str5, 12, "list.reverse");
Clo g_heff_2esyntax_2epresyntax_2egathered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2egathered_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2egathered(V v_p_240, V v_sp_241, V v_q_242, V v_c_243, V v_body_244) {
top: ;
  V v_it_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_body_244));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    heff_drop(v_q_242);
    heff_drop(v_c_243);
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_sp_241)});
    V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_246}), v_sp_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_it1_248 = heff_field(v_it_245, 0);
    V v_before_249 = heff_field(v_it_245, 1);
    V v_ru_24it_245_24Cons = heff_take_reuse_n(v_it_245, 3ULL, 2);
    switch (heff_tag_of(v_it1_248)) {
    case TAG_At: {
      V v_it11_2410 = heff_field(v_it1_248, 0);
      V v_esp_2411 = heff_field(v_it1_248, 1);
      V v_ru_24it1_248_24At = heff_take_reuse_n(v_it1_248, 3ULL, 2);
      switch (heff_tag_of(v_it11_2410)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_2410, 0ULL, 3);
        heff_drop(v_p_240);
        heff_drop(v_q_242);
        heff_drop(v_c_243);
        heff_drop(v_before_249);
        heff_drop(v_esp_2411);
        V v_t_2415 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_sp_241)});
        V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2415}), v_sp_241});
        return heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      }
      case TAG_StmtLet: {
        V v_ru_24it11_2410_24StmtLet = heff_take_reuse_n(v_it11_2410, 0ULL, 2);
        heff_drop(v_p_240);
        heff_drop(v_q_242);
        heff_drop(v_c_243);
        heff_drop(v_before_249);
        heff_drop(v_esp_2411);
        V v_t_2419 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_sp_241)});
        V v_t_2420 = heff_tag_at_n(v_ru_24it11_2410_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2419}), v_sp_241});
        return heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
      }
      case TAG_StmtExpr: {
        V v_e_2421 = heff_field(v_it11_2410, 0);
        V v_ru_24it11_2410_24StmtExpr = heff_take_reuse_n(v_it11_2410, 1ULL, 1);
        V v_t_2422 = (g_heff_2esyntax_2epresyntax_2eisControl(v_e_2421));
        if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
          heff_drop(v_p_240);
          heff_drop_rec(v_sp_241, 2);
          heff_drop(v_q_242);
          heff_drop(v_c_243);
          heff_drop(v_before_249);
          heff_drop(v_e_2421);
          heff_drop(v_t_2422);
          V v_t_2423 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_esp_2411)});
          V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24it11_2410_24StmtExpr, TAG_StmtExpr, 1, (V[]){v_t_2423}), v_esp_2411});
          return heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
        } else {
          heff_drop(v_t_2422);
          V v_t_2425 = (g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(heff_dup(v_sp_241)));
          V v_t_2426 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str0)}), heff_dup(v_sp_241)});
          V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str1)}), heff_dup(v_sp_241)});
          V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str2)}), heff_dup(v_sp_241)});
          V v_t_2429 = heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
          V v_t_2430 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2427, v_t_2429));
          V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
          V v_t_2432 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2426, v_t_2431));
          V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str3)}), heff_dup(v_sp_241)});
          V v_t_2436;
          switch (heff_tag_of(v_t_2432)) {
          case TAG_At: {
            V v_s_2435 = heff_dup(heff_field(v_t_2432, 1));
            v_t_2436 = v_s_2435;
            break;
          }
          default: heff_nomatch(v_t_2432);
          }
          V v_t_2437 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_241, 0)); V rr_ = heff_rec_reuse_nf(v_t_2436, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_t_2433, v_t_2432}), v_t_2437});
          V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLetMut, 3, (V[]){v_t_2425, heff_dup(v_sp_241), v_t_2438}), heff_dup(v_sp_241)});
          V v_t_2440 = (g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(heff_dup(v_sp_241)));
          V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str4)}), heff_dup(v_esp_2411)});
          V v_t_2442 = (g_heff_2esyntax_2epresyntax_2egathered_2eeach_241(heff_dup(v_sp_241)));
          V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2442}), heff_dup(v_esp_2411)});
          V v_t_2444 = (g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(heff_dup(v_sp_241)));
          V v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2444}), heff_dup(v_esp_2411)});
          V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
          V v_t_2447 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2441, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, v_t_2446})));
          V v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAssign, 3, (V[]){v_t_2440, heff_dup(v_esp_2411), v_t_2447}), heff_dup(v_esp_2411)});
          V v_t_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24it11_2410_24StmtExpr, TAG_StmtExpr, 1, (V[]){v_t_2448}), heff_dup(v_esp_2411)});
          V v_t_2450 = (g_heff_2esyntax_2epresyntax_2egathered_2eeach_241(heff_dup(v_sp_241)));
          V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtBind, 3, (V[]){v_t_2450, heff_dup(v_esp_2411), v_e_2421}), v_esp_2411});
          V v_xs_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, v_before_249})});
          V v_t_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2452));
          V v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EFor, 3, (V[]){v_q_242, v_c_243, v_t_2453}), heff_dup(v_sp_241)});
          V v_t_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2454}), heff_dup(v_sp_241)});
          V v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str5)}), heff_dup(v_sp_241)});
          V v_t_2457 = (g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(heff_dup(v_sp_241)));
          V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2457}), heff_dup(v_sp_241)});
          V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
          V v_t_2460 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2456, v_t_2459));
          V v_t_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_p_240, v_t_2460}), v_sp_241});
          V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_t_2462})});
        }
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_2410, 0ULL, 3);
        heff_drop(v_p_240);
        heff_drop(v_q_242);
        heff_drop(v_c_243);
        heff_drop(v_before_249);
        heff_drop(v_esp_2411);
        V v_t_2466 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_sp_241)});
        V v_t_2467 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2466}), v_sp_241});
        return heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_2410, 0ULL, 3);
        heff_drop(v_p_240);
        heff_drop(v_q_242);
        heff_drop(v_c_243);
        heff_drop(v_before_249);
        heff_drop(v_esp_2411);
        V v_t_2471 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_sp_241)});
        V v_t_2472 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2471}), v_sp_241});
        return heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2472, NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_it11_2410);
      }
    }
    default: return heff_nomatch(v_it1_248);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2esyntax_2epresyntax_2egathered_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2egathered(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str0, 13, "this notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str1, 13, "this notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str2, 8, "a lambda");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str3, 8, "a lambda");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str4, 8, "a lambda");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str5, 5, "a tag");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str6, 8, "a record");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str7, 8, "a `case`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str8, 29, "a `let` whose body is checked");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str9, 19, "a term with `where`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str10, 9, "`abandon`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str11, 13, "this notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str12, 64, " does not infer its type: it must be put where its type is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str13, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str14, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str15, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str16, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str17, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str18, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str19, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str20, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str21, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str22, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str23, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str24, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str25, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etoInferable_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etoInferable(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IsInferable: {
    V v_i_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_i_241;
  }
  case TAG_IsCheckable: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24IsCheckable = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_c_243 = heff_field(v_x11_242, 0);
      V v_sp_244 = heff_field(v_x11_242, 1);
      V v_ru_24x11_242_24At = heff_take_reuse_n(v_x11_242, 3ULL, 2);
      V v_t_2428;
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInf: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str0);
        break;
      }
      case TAG_CType: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str1);
        break;
      }
      case TAG_CLam: {
        heff_take_n(v_c_243, 0ULL, 3);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str2);
        break;
      }
      case TAG_CImplicitLam: {
        heff_take_n(v_c_243, 0ULL, 3);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str3);
        break;
      }
      case TAG_CAnnLam: {
        heff_take_n(v_c_243, 0ULL, 4);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str4);
        break;
      }
      case TAG_CTag: {
        heff_take_n(v_c_243, 0ULL, 3);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str5);
        break;
      }
      case TAG_CStruct: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str6);
        break;
      }
      case TAG_CMatch: {
        heff_take_n(v_c_243, 0ULL, 2);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str7);
        break;
      }
      case TAG_CLetIn: {
        heff_take_n(v_c_243, 0ULL, 2);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str8);
        break;
      }
      case TAG_CLocal: {
        heff_take_n(v_c_243, 0ULL, 2);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str9);
        break;
      }
      case TAG_CAbandon: {
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str10);
        break;
      }
      case TAG_CNominal: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str11);
        break;
      }
      default: heff_nomatch(v_c_243);
      }
      V v_t_2429 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), heff_strAppend(v_t_2428, ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str12)), heff_tag_at_n(v_ru_24x1_240_24IsCheckable, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
      return heff_tag_at_n(v_ru_24x11_242_24At, TAG_At, 2, (V[]){v_t_2429, v_sp_244});
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_IsType: {
    V v_x11_2430 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24IsType = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_At: {
      V v_x111_2431 = heff_dup(heff_field(v_x11_2430, 0));
      V v_sp_2432 = heff_dup(heff_field(v_x11_2430, 1));
      switch (heff_tag_of(v_x111_2431)) {
      case TAG_TPi: {
        V v_ru_24x111_2431_24TPi = heff_take_reuse_n(v_x111_2431, 0ULL, 2);
        heff_drop(v_sp_2432);
        V v_t_2435 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str13), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2438;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2437 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2438 = v_s_2437;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_at_n(v_ru_24x111_2431_24TPi, TAG_At, 2, (V[]){v_t_2435, v_t_2438});
      }
      case TAG_TSig: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop_tag(v_x11_2430, 2);
        heff_drop_cell(v_ru_24x1_240_24IsType, 1);
        V v_t_2440 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str14), NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_sp_2432});
      }
      case TAG_TSum: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop_tag(v_x11_2430, 2);
        heff_drop_cell(v_ru_24x1_240_24IsType, 1);
        V v_t_2442 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str15), NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_sp_2432});
      }
      case TAG_TType: {
        heff_drop(v_sp_2432);
        V v_t_2443 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str16), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2446;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2445 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2446 = v_s_2445;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2443, v_t_2446});
      }
      case TAG_TInt: {
        heff_drop(v_sp_2432);
        V v_t_2447 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str17), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2450;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2449 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2450 = v_s_2449;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2447, v_t_2450});
      }
      case TAG_TFloat: {
        heff_drop(v_sp_2432);
        V v_t_2451 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str18), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2454;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2453 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2451, v_t_2454});
      }
      case TAG_TString: {
        heff_drop(v_sp_2432);
        V v_t_2455 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str19), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2458;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2457 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2455, v_t_2458});
      }
      case TAG_TRune: {
        heff_drop(v_sp_2432);
        V v_t_2459 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str20), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2462;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2461 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2462 = v_s_2461;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2459, v_t_2462});
      }
      case TAG_TArray: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop(v_sp_2432);
        V v_t_2464 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str21), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2467;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2466 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2467 = v_s_2466;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2464, v_t_2467});
      }
      case TAG_TFixed: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop(v_sp_2432);
        V v_t_2469 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str22), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2472;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2471 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2472 = v_s_2471;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2469, v_t_2472});
      }
      case TAG_TInf: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop(v_sp_2432);
        V v_t_2474 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str23), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2477;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2476 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2477 = v_s_2476;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2474, v_t_2477});
      }
      case TAG_TChk: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop(v_sp_2432);
        V v_t_2479 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str24), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2482;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2481 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2482 = v_s_2481;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2479, v_t_2482});
      }
      case TAG_TNominal: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop(v_sp_2432);
        V v_t_2484 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str25), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2487;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2486 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2487 = v_s_2486;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2484, v_t_2487});
      }
      default: return heff_nomatch(v_x111_2431);
      }
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etoInferable(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ealtOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ealtOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_b_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24MkAlt = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_245}));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_244, v_t_2416}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ealtOf(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EImplicitVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBinary: {
    V v_segs_247 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_segs_247}});
  }
  case TAG_ERune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWord: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProject: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENamed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPi: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAnn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESpec: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESig: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESum: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStruct: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUpdate: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetIn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EDo: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELocal: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInvalid: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EIfThen: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBreak: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EContinue: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELazy: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETuple: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETry: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWith: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}