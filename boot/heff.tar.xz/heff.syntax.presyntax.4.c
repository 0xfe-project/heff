// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArrayWord 24229
#define TAG_AsDefinition 21504
#define TAG_At 8900
#define TAG_BadFieldSet 46507
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_ENotationVar 51927
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_EndJump 17665
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_INotationVar 46285
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkEquation 38417
#define TAG_MkTry 8097
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_SetField 47531
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetElse 62884
#define TAG_StmtLetMut 50164
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TSig 38418
#define TAG_TSum 38796
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_cx 9948
#define LBL_depth 296830685
#define LBL_e 319
#define LBL_end 310101
#define LBL_giveBack 2038160732
#define LBL_giving 701566649
#define LBL_guard 300063423
#define LBL_head 9693863
#define LBL_inLam 301681229
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_part 9928890
#define LBL_pure 9948095
#define LBL_run 322821
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_cx__guard[] = {LBL_cx, LBL_guard};
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
static uint32_t shape_muts__inLam[] = {LBL_muts, LBL_inLam};
static uint32_t shape_names__muts__loop__sp__depth__giving[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving};
static uint32_t shape_part__run[] = {LBL_part, LBL_run};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s386636727x1203660589_24cpr(V, V);
HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ealtBy(V, V);
V g_heff_2esyntax_2epresyntax_2ealtBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtBy_clo;
V g_heff_2esyntax_2epresyntax_2ealtOf(V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eappOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_clo;
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955(V, V, V);
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_clo;
V g_heff_2esyntax_2epresyntax_2easAction(V, V, V);
V g_heff_2esyntax_2epresyntax_2easAction_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2easAction_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_clo;
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(V);
HeffT1 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076(V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076_clo;
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026(V, V, V);
V g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo;
V g_heff_2esyntax_2epresyntax_2eboolOf(V);
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo;
V g_heff_2esyntax_2epresyntax_2echeckedWays_get(void);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V, V);
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo;
V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925(V, V, V);
V g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925_clo;
V g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2efirst_244(V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2eparams_245(V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_clo;
V g_heff_2esyntax_2epresyntax_2egathered(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egathered_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egathered_clo;
V g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(V);
V g_heff_2esyntax_2epresyntax_2egathered_2eacc_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egathered_2eacc_240_clo;
V g_heff_2esyntax_2epresyntax_2egathered_2eeach_241(V);
V g_heff_2esyntax_2epresyntax_2egathered_2eeach_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egathered_2eeach_241_clo;
V g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get(void);
V g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881_clo;
V g_heff_2esyntax_2epresyntax_2eifOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eifOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eifOf_clo;
V g_heff_2esyntax_2epresyntax_2einfSpineOf(V);
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2eisControl(V);
V g_heff_2esyntax_2epresyntax_2eisControl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eisControl_clo;
V g_heff_2esyntax_2epresyntax_2ejumpE(V);
V g_heff_2esyntax_2epresyntax_2ejumpE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ejumpE_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eliftE_24cpr(V, V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk(V, V);
V g_heff_2esyntax_2epresyntax_2elistOfChk_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elistOfChk_clo;
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2ereturnOf(V, V, V);
V g_heff_2esyntax_2epresyntax_2ereturnOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ereturnOf_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s1724669254x444492892_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167_clo;
V g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(V);
V g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_clo;
V g_heff_2esyntax_2epresyntax_2ewordOf(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds(V, V, V);
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo;
V g_list_2eany_24s2003678755x1820404042(V);
V g_list_2eany_24s2003678755x1820404042_entry(V self, V *a);
extern Clo g_list_2eany_24s2003678755x1820404042_clo;
V g_list_2eany_24s2077819594x1842428557(V, V);
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a);
extern Clo g_list_2eany_24s2077819594x1842428557_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s958865698x1719976126(V, V, V);
V g_list_2efoldl_24s958865698x1719976126_entry(V self, V *a);
extern Clo g_list_2efoldl_24s958865698x1719976126_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1276400643x126214923(V);
V g_list_2emap_24s1276400643x126214923_entry(V self, V *a);
extern Clo g_list_2emap_24s1276400643x126214923_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s2051429168x672290949(V);
V g_list_2emap_24s2051429168x672290949_entry(V self, V *a);
extern Clo g_list_2emap_24s2051429168x672290949_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
V g_list_2emap_24s942566919x1152393003(V, V);
V g_list_2emap_24s942566919x1152393003_entry(V self, V *a);
extern Clo g_list_2emap_24s942566919x1152393003_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfSpineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2einfSpineOf(V v_i_240) {
top: ;
  switch (heff_tag_of(v_i_240)) {
  case TAG_At: {
    V v_i1_241 = heff_dup(heff_field(v_i_240, 0));
    switch (heff_tag_of(v_i1_241)) {
    case TAG_IVar: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_INotationVar: {
      heff_take_n(v_i1_241, 0ULL, 3);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IInt: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IFloat: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IString: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IBytes: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IPrim: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IRune: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IApp: {
      V v_h_2413 = heff_field(v_i1_241, 0);
      V v_xs_2414 = heff_field(v_i1_241, 1);
      heff_take_n(v_i1_241, 3ULL, 2);
      switch (heff_tag_of(v_i_240)) {
      case TAG_At: {
        heff_take_n(v_i_240, 0ULL, 2);
        return heff_rec_n(2, shape_head__args, (V[]){v_h_2413, v_xs_2414});
      }
      default: return heff_nomatch(v_i_240);
      }
    }
    case TAG_IAnn: {
      heff_take_n(v_i1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_ISpec: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IUpdate: {
      heff_take_n(v_i1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IAnnLam: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IInvalid: {
      heff_take_n(v_i1_241, 0ULL, 3);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_INominal: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_ILitEq: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_ILazy: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_ITuple: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_i1_241);
    }
  }
  default: return heff_nomatch(v_i_240);
  }
}
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfSpineOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elocalFun_str0, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2elocalFun_str1, 6, "MkUnit");
Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elocalFun_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2elocalFun(V v_f_240, V v_sp_241, V v_ps_242, V v_body_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elocalFun_str0)}), heff_dup(v_sp_241)});
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2elocalFun_str1)}), heff_dup(v_sp_241)});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_ty_247 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_244, v_t_246));
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_242)));
  V v_t_249 = (g_list_2efoldl_24s958865698x1719976126(heff_dup(v_sp_241), v_ty_247, v_t_248));
  V v_t_2410 = (g_list_2emap_24s1937570095x2110149801(v_ps_242));
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){heff_dup(v_f_240), heff_dup(v_sp_241), v_t_2410, v_body_243}), heff_dup(v_sp_241)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_DeclEquations, 5, (V[]){v_f_240, heff_dup(v_sp_241), NTAG(TAG_AsDefinition), v_t_249, v_t_2412});
  return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_241});
}
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2elocalFun(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eifOf_str0, 4, "True");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eifOf_str1, 5, "False");
Clo g_heff_2esyntax_2epresyntax_2eifOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eifOf_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2eifOf(V v_sp_240, V v_c_241, V v_a_242, V v_b_243) {
top: ;
  V v_s_244 = (g_heff_2esyntax_2epresyntax_2eboolOf(v_c_241));
  V v_t_245 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_240, 0)), heff_dup(heff_rfield(v_sp_240, 1))});
  V v_t_246 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eifOf_str0), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_247 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, heff_dup(v_t_245)}), heff_dup(v_a_242)});
  V v_t_2410;
  switch (heff_tag_of(v_a_242)) {
  case TAG_At: {
    V v_s_249 = heff_field(v_a_242, 1);
    heff_take_n(v_a_242, 2ULL, 2);
    v_t_2410 = v_s_249;
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  V v_t_2411 = ({ V rv_1 = heff_get_n(v_t_2410, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_245, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_240, 0)), heff_dup(heff_rfield(v_sp_240, 1))});
  V v_t_2413 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eifOf_str1), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_t_2412)}), heff_dup(v_b_243)});
  V v_t_2417;
  switch (heff_tag_of(v_b_243)) {
  case TAG_At: {
    V v_s_2416 = heff_field(v_b_243, 1);
    heff_take_n(v_b_243, 2ULL, 2);
    v_t_2417 = v_s_2416;
    break;
  }
  default: heff_nomatch(v_b_243);
  }
  V v_t_2418 = ({ V rv_1 = heff_get_n(v_t_2417, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2412, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_t_2418}), NTAG(TAG_Nil)});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_t_2411}), v_t_2419});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_244, v_t_2420}), v_sp_240});
}
V g_heff_2esyntax_2epresyntax_2eifOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eifOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epresyntax_2ewrapBinds_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2ewrapBinds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewrapBinds_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ewrapBinds(V v_cx_240, V v_binds_241, V v_inner_242) {
top: ;
  V v_names_243 = heff_take_field(v_cx_240, 0);
  V v_sp_244 = heff_get_n(v_cx_240, 3, 6);
  HEFF_LAST return g_list_2efoldl(heff_clo_n(g_heff_2esyntax_2epresyntax_2ewrapBinds_lam0, 2, 2, (V[]){v_names_243, v_sp_244}), v_inner_242, v_binds_241);
}
V g_heff_2esyntax_2epresyntax_2ewrapBinds_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2ewrapBinds(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2epresyntax_2ewrapBinds_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_b_246 = args[1];
  V v_names_243 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249;
  switch (heff_tag_of(v_b_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_dup(heff_field(v_b_246, 0));
    v_x_249 = v_x_247;
    break;
  }
  default: heff_nomatch(v_b_246);
  }
  V v_t_2412;
  switch (heff_tag_of(v_b_246)) {
  case TAG_MkPair: {
    V v_y_2411 = heff_dup(heff_field(v_b_246, 1));
    v_t_2412 = v_y_2411;
    break;
  }
  default: heff_nomatch(v_b_246);
  }
  V v_xsp_2415;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_At: {
    V v_s_2414 = heff_field(v_t_2412, 1);
    heff_take_n(v_t_2412, 2ULL, 2);
    v_xsp_2415 = v_s_2414;
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V v_t_2416 = heff_tag_n(TAG_EVar, 1, (V[]){heff_get_n(v_names_243, 0, 3)});
  V v_t_2419;
  switch (heff_tag_of(v_b_246)) {
  case TAG_MkPair: {
    V v_y_2418 = heff_field(v_b_246, 1);
    heff_take_n(v_b_246, 2ULL, 2);
    v_t_2419 = v_y_2418;
    break;
  }
  default: heff_nomatch(v_b_246);
  }
  V v_t_2420 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_249, heff_dup(v_xsp_2415)}), heff_dup(v_acc_245)});
  V v_t_2423;
  switch (heff_tag_of(v_acc_245)) {
  case TAG_At: {
    V v_s_2422 = heff_field(v_acc_245, 1);
    heff_take_n(v_acc_245, 2ULL, 2);
    v_t_2423 = v_s_2422;
    break;
  }
  default: heff_nomatch(v_acc_245);
  }
  V v_t_2424 = ({ V rv_1 = heff_get_n(v_t_2423, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_2415, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_t_2424}), NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2416, v_sp_244}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2425})));
}
Clo g_heff_2esyntax_2epresyntax_2easAction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2easAction_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2easAction(V v_lift_240, V v_cx_241, V v_b_242) {
top: ;
  V v_x1_243 = heff_tr(heff_call(v_lift_240, 2, (V[]){NTAG(TAG_Nil), v_b_242}));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_x1_243, 0);
    V v_y_245 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24MkPair = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_cx_241, 0)), 1, 3);
    V v_t_249;
    switch (heff_tag_of(v_y_245)) {
    case TAG_At: {
      V v_s_248 = heff_dup(heff_field(v_y_245, 1));
      v_t_249 = v_s_248;
      break;
    }
    default: heff_nomatch(v_y_245);
    }
    V v_t_2410 = heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_246}), v_t_249});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, NTAG(TAG_Nil)});
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2410, v_t_2411));
    return ({ V a_0 = v_cx_241; V a_1 = v_x_244; V a_2 = v_t_2412; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_244); r_; });
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2esyntax_2epresyntax_2easAction_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2easAction(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2ealtBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ealtBy_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ealtBy(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_b_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24MkAlt = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(v_f_240, 1, (V[]){v_b_245}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_244, v_t_246}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ealtBy_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ealtBy(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2eaccList_24s386636727x1203660589_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_st_240, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x31_244 = heff_field(v_x_242, 0);
      V v_sp_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24At = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x31_244)) {
      case TAG_SetField: {
        V v_x_246 = heff_field(v_x31_244, 0);
        V v_xsp_247 = heff_field(v_x31_244, 1);
        V v_e_248 = heff_field(v_x31_244, 2);
        V v_ru_24x31_244_24SetField = heff_take_reuse_n(v_x31_244, 7ULL, 3);
        V v_x_249;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_249 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_249 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_248)));
        }
        HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2eaccList_24s386636727x1203660589_24cpr(v_x_249, v_xs_243));
        {
          V v_field_2411 = v_t_2410.f[0];
          V v_field_2412 = v_t_2410.f[1];
          V v_x_2413 = v_field_2411;
          V v_y_2414 = v_field_2412;
          V v_t_2415 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_244_24SetField, TAG_SetField, 3, (V[]){v_x_246, v_xsp_247, v_e_248}), v_sp_245});
          return ((HeffT2){{v_x_2413, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2415, v_y_2414})}});
        }
      }
      case TAG_BadFieldSet: {
        V v_e_2416 = heff_field(v_x31_244, 0);
        V v_ru_24x31_244_24BadFieldSet = heff_take_reuse_n(v_x31_244, 1ULL, 1);
        V v_x_2417;
        if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
          heff_drop(v_st_240);
          v_x_2417 = NTAG(TAG_True);
        } else {
          heff_drop(v_st_240);
          v_x_2417 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_2416)));
        }
        HeffT2 v_t_2418 = (g_heff_2esyntax_2epresyntax_2eaccList_24s386636727x1203660589_24cpr(v_x_2417, v_xs_243));
        {
          V v_field_2419 = v_t_2418.f[0];
          V v_field_2420 = v_t_2418.f[1];
          V v_x_2421 = v_field_2419;
          V v_y_2422 = v_field_2420;
          V v_t_2423 = heff_tag_at_n(v_ru_24x_242_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x31_244_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_e_2416}), v_sp_245});
          return ((HeffT2){{v_x_2421, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2423, v_y_2422})}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_244)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_241)}});
  }
}

HeffT3 g_heff_2esyntax_2epresyntax_2estmtAcc_24s1724669254x444492892_24cpr(V v_st_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_At: {
    V v_x31_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24At = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_242)) {
    case TAG_StmtBind: {
      V v_x_244 = heff_field(v_x31_242, 0);
      V v_xsp_245 = heff_field(v_x31_242, 1);
      V v_e_246 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtBind = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_247;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_247 = NTAG(TAG_True);
      } else {
        v_x_247 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_246)));
      }
      return ((HeffT3){{v_x_247, heff_tag_at_n(v_ru_24x31_242_24StmtBind, TAG_StmtBind, 3, (V[]){v_x_244, v_xsp_245, v_e_246}), v_sp_243}});
    }
    case TAG_StmtLet: {
      V v_p_248 = heff_field(v_x31_242, 0);
      V v_e_249 = heff_field(v_x31_242, 1);
      heff_take_n(v_x31_242, 3ULL, 2);
      V v_x_2410;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2410 = NTAG(TAG_True);
      } else {
        v_x_2410 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_249)));
      }
      return ((HeffT3){{v_x_2410, heff_tag_at_n(v_ru_24x3_241_24At, TAG_StmtLet, 2, (V[]){v_p_248, v_e_249}), v_sp_243}});
    }
    case TAG_StmtExpr: {
      V v_e_2411 = heff_field(v_x31_242, 0);
      V v_ru_24x31_242_24StmtExpr = heff_take_reuse_n(v_x31_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2412;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2412 = NTAG(TAG_True);
      } else {
        v_x_2412 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_2411)));
      }
      return ((HeffT3){{v_x_2412, heff_tag_at_n(v_ru_24x31_242_24StmtExpr, TAG_StmtExpr, 1, (V[]){v_e_2411}), v_sp_243}});
    }
    case TAG_StmtLetMut: {
      V v_x_2413 = heff_field(v_x31_242, 0);
      V v_xsp_2414 = heff_field(v_x31_242, 1);
      V v_e_2415 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtLetMut = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2416;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2416 = NTAG(TAG_True);
      } else {
        v_x_2416 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_2415)));
      }
      return ((HeffT3){{v_x_2416, heff_tag_at_n(v_ru_24x31_242_24StmtLetMut, TAG_StmtLetMut, 3, (V[]){v_x_2413, v_xsp_2414, v_e_2415}), v_sp_243}});
    }
    case TAG_StmtLetElse: {
      V v_p_2417 = heff_field(v_x31_242, 0);
      V v_e_2418 = heff_field(v_x31_242, 1);
      V v_ss_2419 = heff_field(v_x31_242, 2);
      V v_ru_24x31_242_24StmtLetElse = heff_take_reuse_n(v_x31_242, 7ULL, 3);
      heff_drop_cell(v_ru_24x3_241_24At, 2);
      V v_x_2420;
      if ((heff_dup(v_st_240) == NTAG(TAG_True))) {
        v_x_2420 = NTAG(TAG_True);
      } else {
        v_x_2420 = (g_heff_2esyntax_2epresyntax_2ejumpE(heff_dup(v_e_2418)));
      }
      HeffT2 v_t_2421 = (g_heff_2esyntax_2epresyntax_2eaccList_24s750049773x2114140088_24cpr(v_x_2420, v_ss_2419));
      {
        V v_field_2422 = v_t_2421.f[0];
        V v_field_2423 = v_t_2421.f[1];
        V v_x_2424 = v_field_2422;
        V v_y_2425 = v_field_2423;
        return ((HeffT3){{v_x_2424, heff_tag_at_n(v_ru_24x31_242_24StmtLetElse, TAG_StmtLetElse, 3, (V[]){v_p_2417, v_e_2418, v_y_2425}), v_sp_243}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x31_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x3_241)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ereturnOf_str0, 4, "Left");
Clo g_heff_2esyntax_2epresyntax_2ereturnOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ereturnOf_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2ereturnOf(V v_cx_240, V v_sp_241, V v_v_242) {
top: ;
  V v_giving_243 = heff_take_field(v_cx_240, 5);
  V v_names_244 = heff_get_n(v_cx_240, 0, 6);
  switch (heff_tag_of(v_giving_243)) {
  case TAG_Nothing: {
    V v_t_245 = heff_tag_n(TAG_EVar, 1, (V[]){heff_get_n(v_names_244, 1, 3)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_242, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_241}), v_t_246));
  }
  case TAG_Just: {
    V v_ru_24giving_243_24Just = heff_take_reuse_n(v_giving_243, 0ULL, 1);
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24giving_243_24Just, TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ereturnOf_str0)}), heff_dup(v_sp_241)});
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_242, NTAG(TAG_Nil)});
    V v_v_2410 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_248, v_t_249));
    V v_t_2411 = heff_tag_n(TAG_EVar, 1, (V[]){heff_get_n(v_names_244, 1, 3)});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_2410, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_241}), v_t_2412));
  }
  default: return heff_nomatch(v_giving_243);
  }
}
V g_heff_2esyntax_2epresyntax_2ereturnOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ereturnOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str0, 12, "builtin.List");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str1, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str2, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str3, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str4, 4, "Cons");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2egathered_str5, 12, "list.reverse");
Clo g_heff_2esyntax_2epresyntax_2egathered_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2egathered_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2egathered(V v_p_240, V v_sp_241, V v_q_242, V v_c_243, V v_body_244) {
top: ;
  V v_it_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_body_244));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    heff_drop(v_q_242);
    heff_drop(v_c_243);
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_sp_241)});
    V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_246}), v_sp_241});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_it1_248 = heff_field(v_it_245, 0);
    V v_before_249 = heff_field(v_it_245, 1);
    V v_ru_24it_245_24Cons = heff_take_reuse_n(v_it_245, 3ULL, 2);
    switch (heff_tag_of(v_it1_248)) {
    case TAG_At: {
      V v_it11_2410 = heff_field(v_it1_248, 0);
      V v_esp_2411 = heff_field(v_it1_248, 1);
      V v_ru_24it1_248_24At = heff_take_reuse_n(v_it1_248, 3ULL, 2);
      switch (heff_tag_of(v_it11_2410)) {
      case TAG_StmtBind: {
        heff_take_n(v_it11_2410, 0ULL, 3);
        heff_drop(v_p_240);
        heff_drop(v_q_242);
        heff_drop(v_c_243);
        heff_drop(v_before_249);
        heff_drop(v_esp_2411);
        V v_t_2415 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_sp_241)});
        V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2415}), v_sp_241});
        return heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      }
      case TAG_StmtLet: {
        V v_ru_24it11_2410_24StmtLet = heff_take_reuse_n(v_it11_2410, 0ULL, 2);
        heff_drop(v_p_240);
        heff_drop(v_q_242);
        heff_drop(v_c_243);
        heff_drop(v_before_249);
        heff_drop(v_esp_2411);
        V v_t_2419 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_sp_241)});
        V v_t_2420 = heff_tag_at_n(v_ru_24it11_2410_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2419}), v_sp_241});
        return heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
      }
      case TAG_StmtExpr: {
        V v_e_2421 = heff_field(v_it11_2410, 0);
        V v_ru_24it11_2410_24StmtExpr = heff_take_reuse_n(v_it11_2410, 1ULL, 1);
        V v_t_2422 = (g_heff_2esyntax_2epresyntax_2eisControl(v_e_2421));
        if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
          heff_drop(v_p_240);
          heff_drop_rec(v_sp_241, 2);
          heff_drop(v_q_242);
          heff_drop(v_c_243);
          heff_drop(v_before_249);
          heff_drop(v_e_2421);
          heff_drop(v_t_2422);
          V v_t_2423 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_esp_2411)});
          V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24it11_2410_24StmtExpr, TAG_StmtExpr, 1, (V[]){v_t_2423}), v_esp_2411});
          return heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
        } else {
          heff_drop(v_t_2422);
          V v_t_2425 = (g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(heff_dup(v_sp_241)));
          V v_t_2426 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str0)}), heff_dup(v_sp_241)});
          V v_t_2427 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str1)}), heff_dup(v_sp_241)});
          V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str2)}), heff_dup(v_sp_241)});
          V v_t_2429 = heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
          V v_t_2430 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2427, v_t_2429));
          V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
          V v_t_2432 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2426, v_t_2431));
          V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str3)}), heff_dup(v_sp_241)});
          V v_t_2436;
          switch (heff_tag_of(v_t_2432)) {
          case TAG_At: {
            V v_s_2435 = heff_dup(heff_field(v_t_2432, 1));
            v_t_2436 = v_s_2435;
            break;
          }
          default: heff_nomatch(v_t_2432);
          }
          V v_t_2437 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_241, 0)); V rr_ = heff_rec_reuse_nf(v_t_2436, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_t_2433, v_t_2432}), v_t_2437});
          V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLetMut, 3, (V[]){v_t_2425, heff_dup(v_sp_241), v_t_2438}), heff_dup(v_sp_241)});
          V v_t_2440 = (g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(heff_dup(v_sp_241)));
          V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str4)}), heff_dup(v_esp_2411)});
          V v_t_2442 = (g_heff_2esyntax_2epresyntax_2egathered_2eeach_241(heff_dup(v_sp_241)));
          V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2442}), heff_dup(v_esp_2411)});
          V v_t_2444 = (g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(heff_dup(v_sp_241)));
          V v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2444}), heff_dup(v_esp_2411)});
          V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
          V v_t_2447 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2441, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, v_t_2446})));
          V v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAssign, 3, (V[]){v_t_2440, heff_dup(v_esp_2411), v_t_2447}), heff_dup(v_esp_2411)});
          V v_t_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24it11_2410_24StmtExpr, TAG_StmtExpr, 1, (V[]){v_t_2448}), heff_dup(v_esp_2411)});
          V v_t_2450 = (g_heff_2esyntax_2epresyntax_2egathered_2eeach_241(heff_dup(v_sp_241)));
          V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtBind, 3, (V[]){v_t_2450, heff_dup(v_esp_2411), v_e_2421}), v_esp_2411});
          V v_xs_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, v_before_249})});
          V v_t_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2452));
          V v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EFor, 3, (V[]){v_q_242, v_c_243, v_t_2453}), heff_dup(v_sp_241)});
          V v_t_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2454}), heff_dup(v_sp_241)});
          V v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2egathered_str5)}), heff_dup(v_sp_241)});
          V v_t_2457 = (g_heff_2esyntax_2epresyntax_2egathered_2eacc_240(heff_dup(v_sp_241)));
          V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2457}), heff_dup(v_sp_241)});
          V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
          V v_t_2460 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2456, v_t_2459));
          V v_t_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_p_240, v_t_2460}), v_sp_241});
          V v_t_2462 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2461, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_t_2462})});
        }
      }
      case TAG_StmtLetMut: {
        heff_take_n(v_it11_2410, 0ULL, 3);
        heff_drop(v_p_240);
        heff_drop(v_q_242);
        heff_drop(v_c_243);
        heff_drop(v_before_249);
        heff_drop(v_esp_2411);
        V v_t_2466 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_sp_241)});
        V v_t_2467 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2466}), v_sp_241});
        return heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2467, NTAG(TAG_Nil)});
      }
      case TAG_StmtLetElse: {
        heff_take_n(v_it11_2410, 0ULL, 3);
        heff_drop(v_p_240);
        heff_drop(v_q_242);
        heff_drop(v_c_243);
        heff_drop(v_before_249);
        heff_drop(v_esp_2411);
        V v_t_2471 = heff_tag_at_n(v_ru_24it1_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2egathered_2eends_242_get())}), heff_dup(v_sp_241)});
        V v_t_2472 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtExpr, 1, (V[]){v_t_2471}), v_sp_241});
        return heff_tag_at_n(v_ru_24it_245_24Cons, TAG_Cons, 2, (V[]){v_t_2472, NTAG(TAG_Nil)});
      }
      default: return heff_nomatch(v_it11_2410);
      }
    }
    default: return heff_nomatch(v_it1_248);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2esyntax_2epresyntax_2egathered_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2egathered(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_str1, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_str2, 7, " := e`)");
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955(V v_cx_240, V v_end_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_p_243 = heff_field(v_x4_242, 0);
    V v_ss_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24MkPair = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_xs_245 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_243)));
    HeffT2 v_t_247 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_lam0, 1, 1, (V[]){heff_dup(v_cx_240)}); V a_1 = v_xs_245; HeffT2 r_ = (g_list_2efind_24cpr(a_0, a_1)); heff_drop(v_xs_245); r_; });
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        heff_drop_rec(v_cx_240, 6);
        heff_drop(v_end_241);
        heff_drop(v_ss_244);
        V v_x_2410 = v_field_249;
        V v_t_2413;
        switch (heff_tag_of(v_p_243)) {
        case TAG_At: {
          V v_s_2412 = heff_dup(heff_field(v_p_243, 1));
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_p_243);
        }
        V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_str0), heff_dup(v_x_2410)), ((V)&g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_str1));
        V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, v_x_2410), ((V)&g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_str2));
        V v_t_2416 = heff_tag_at_n(v_ru_24x4_242_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2415}), heff_dup(v_t_2413)});
        V v_t_2419;
        switch (heff_tag_of(v_p_243)) {
        case TAG_At: {
          V v_s_2418 = heff_dup(heff_field(v_p_243, 1));
          v_t_2419 = v_s_2418;
          break;
        }
        default: heff_nomatch(v_p_243);
        }
        V v_t_2420 = ({ V rv_1 = heff_get_n(v_t_2413, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2419, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_243, v_t_2416}), v_t_2420});
      } else {
        heff_drop(v_field_249);
        V v_e_2421 = ({ V a_0 = v_cx_240; V a_1 = v_ss_244; V a_2 = v_end_241; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_ss_244); r_; });
        V v_t_2424;
        switch (heff_tag_of(v_p_243)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_p_243, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_p_243);
        }
        V v_t_2427;
        switch (heff_tag_of(v_e_2421)) {
        case TAG_At: {
          V v_s_2426 = heff_dup(heff_field(v_e_2421, 1));
          v_t_2427 = v_s_2426;
          break;
        }
        default: heff_nomatch(v_e_2421);
        }
        V v_t_2428 = ({ V rv_1 = heff_get_n(v_t_2427, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2424, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24x4_242_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_243, v_e_2421}), v_t_2428});
      }
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_cx_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_246; V b_1 = heff_get_n(v_cx_240, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_246); heff_drop(b_1); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str0, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str1, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str2, 6, "after#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str3, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str4, 6, "after#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str5, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str6, 6, "after#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str7, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str8, 5, "loop#");
Clo g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_entry, 6, 0};

V g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735(V v_cx_240, V v_sp_241, V v_c_242, V v_body_243, V v_rest_244, V v_end_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 2, 3);
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    HEFF_LAST return g_heff_2esyntax_2epresyntax_2ewhileGiving_24s1645823587x463654167(v_cx_240, v_sp_241, v_c_242, v_body_243, v_rest_244, v_end_245);
  } else {
    heff_drop(v_t_246);
    V v_t_247 = heff_dup(heff_rfield(v_cx_240, 1));
    V v_t_248 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
    V v_t_249 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str0), v_t_248)});
    V v_t_2413;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nil: {
      V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str1)}), heff_dup(v_sp_241)});
      v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      v_t_2413 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_t_247));
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_241)}), v_t_2413));
    V v_t_2415 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
    V v_t_2416 = ({ V a_0 = heff_dup(v_sp_241); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_240, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    V v_t_2417 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(heff_dup(v_cx_240), v_rest_244, v_end_245));
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2elocalFun(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str2), v_t_2415), heff_dup(v_sp_241), v_t_2416, v_t_2417));
    V v_t_2419 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
    V v_t_2420 = ({ V a_0 = heff_dup(v_sp_241); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_240, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    V v_t_2421 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
    HeffT2 v_t_2422 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_2421}), NTAG(TAG_Nil), v_c_242));
    V v_t_2452;
    {
      V v_field_2423 = v_t_2422.f[0];
      V v_field_2424 = v_t_2422.f[1];
      V v_x_2425 = v_field_2423;
      V v_y_2426 = v_field_2424;
      V v_t_2427 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
      V v_t_2428 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str3), v_t_2427)});
      V v_t_2429 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2428, heff_dup(v_sp_241)}), heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_240, 4))});
      V v_t_2430 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
      V v_t_2431 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str4), v_t_2430)});
      V v_t_2432 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2431, heff_dup(v_sp_241)}), heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_240, 4))});
      V v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2429, v_t_2432})});
      V v_cx_2434 = heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){heff_dup(heff_rfield(v_cx_240, 0)), heff_dup(heff_rfield(v_cx_240, 1)), v_t_2433, heff_dup(heff_rfield(v_cx_240, 3)), heff_dup(heff_rfield(v_cx_240, 4)), heff_dup(heff_rfield(v_cx_240, 5))});
      V v_t_2435 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
      V v_t_2436 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str5), v_t_2435)});
      V v_t_2437 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2436, heff_dup(v_sp_241)}), heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_240, 4))});
      V v_t_2442;
      switch (heff_tag_of(v_body_243)) {
      case TAG_Nil: {
        v_t_2442 = (g_heff_2esyntax_2epresyntax_2eendOf_24s1644594133x1961306925(v_t_2437, heff_dup(v_cx_2434), heff_get_n(v_cx_2434, 3, 6)));
        break;
      }
      case TAG_Cons: {
        V v_s_2438 = heff_field(v_body_243, 0);
        V v_x32_2439 = heff_field(v_body_243, 1);
        heff_take_n(v_body_243, 3ULL, 2);
        switch (heff_tag_of(v_x32_2439)) {
        case TAG_Nil: {
          v_t_2442 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_2434, v_s_2438, v_x32_2439, heff_tag_n(TAG_EndJump, 1, (V[]){v_t_2437})));
          break;
        }
        case TAG_Cons: {
          v_t_2442 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtT_24s1178612199x2018882848(v_cx_2434, v_s_2438, v_x32_2439, heff_tag_n(TAG_EndJump, 1, (V[]){v_t_2437})));
          break;
        }
        default: heff_nomatch(v_x32_2439);
        }
        break;
      }
      default: heff_nomatch(v_body_243);
      }
      V v_t_2443 = heff_dup(heff_rfield(v_cx_240, 1));
      V v_t_2444 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
      V v_t_2445 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str6), v_t_2444)});
      V v_t_2449;
      switch (heff_tag_of(v_t_2443)) {
      case TAG_Nil: {
        V v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str7)}), heff_dup(v_sp_241)});
        v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        v_t_2449 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_241), v_t_2443));
        break;
      }
      default: heff_nomatch(v_t_2443);
      }
      V v_t_2450 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2445, heff_dup(v_sp_241)}), v_t_2449));
      V v_t_2451 = (g_heff_2esyntax_2epresyntax_2eifOf(heff_dup(v_sp_241), v_y_2426, v_t_2442, v_t_2450));
      v_t_2452 = ({ V a_0 = v_cx_240; V a_1 = v_x_2425; V a_2 = v_t_2451; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2425); r_; });
    }
    V v_t_2453 = (g_heff_2esyntax_2epresyntax_2elocalFun(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_str8), v_t_2419), heff_dup(v_sp_241), v_t_2420, v_t_2452));
    V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
    V v_t_2455 = heff_tag_n(TAG_ELocal, 2, (V[]){v_t_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2454})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2455, v_sp_241});
  }
}
V g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2esyntax_2epresyntax_2ewhileT_24s866997983x886777735(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str0, 16, "prelude.inferred");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str1, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str2, 9, "iterateOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str3, 5, "coll#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str4, 4, "next");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str5, 6, "after#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str6, 6, "after#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str7, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str8, 5, "coll#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str9, 5, "next#");
V g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216(V v_cx_240, V v_sp_241, V v_p_242, V v_coll_243, V v_body_244, V v_rest_245, V v_end_246) {
top: ;
  V v_t_247 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
  HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_247}), NTAG(TAG_Nil), v_coll_243));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_x_2411 = v_field_249;
    V v_y_2412 = v_field_2410;
    V v_sp_2415;
    switch (heff_tag_of(v_y_2412)) {
    case TAG_At: {
      V v_s_2414 = heff_dup(heff_field(v_y_2412, 1));
      v_sp_2415 = v_s_2414;
      break;
    }
    default: heff_nomatch(v_y_2412);
    }
    V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str0)}), heff_dup(v_sp_2415)});
    V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str1)}), v_sp_2415});
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_t_2419 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2416, v_t_2418));
    V v_t_2422;
    switch (heff_tag_of(v_y_2412)) {
    case TAG_At: {
      V v_s_2421 = heff_dup(heff_field(v_y_2412, 1));
      v_t_2422 = v_s_2421;
      break;
    }
    default: heff_nomatch(v_y_2412);
    }
    V v_v_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_y_2412, v_t_2419}), v_t_2422});
    V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str2)}), heff_dup(v_sp_241)});
    V v_t_2425 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
    V v_t_2426 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str3), v_t_2425)});
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2426, heff_dup(v_sp_241)}), NTAG(TAG_Nil)});
    V v_t_2428 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2424, v_t_2427));
    V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EProject, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str4)}), heff_dup(v_sp_241)});
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    V v_v_2431 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2428, v_t_2430));
    V v_t_2432 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 2, 3);
    V v_body_2465;
    if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
      heff_drop(v_t_2432);
      V v_cx_2433 = heff_dup(v_cx_240);
      V v_sp_2434 = heff_dup(v_sp_241);
      V v_body_2435 = v_body_244;
      V v_p_2436 = v_p_242;
      V v_rest_2437 = v_rest_245;
      V v_end_2438 = v_end_246;
      V v_t_2439 = (g_list_2eany_24s2003678755x1820404042(heff_dup(v_body_2435)));
      V v_t_2440 = (g_heff_2esyntax_2epresyntax_2eforT_2efirst_244(heff_dup(v_sp_2434), heff_dup(v_cx_2433)));
      V v_t_2441 = (g_heff_2esyntax_2epresyntax_2eforT_2eparams_245(heff_dup(v_sp_2434), heff_dup(v_cx_2433)));
      v_body_2465 = ({ V a_0 = heff_dup(v_cx_2433); V a_1 = heff_dup(v_sp_2434); V a_2 = v_t_2439; V a_3 = v_t_2440; V a_4 = v_t_2441; V a_5 = heff_clo_n(g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_lam0, 1, 4, (V[]){v_body_2435, v_cx_2433, v_sp_2434, v_p_2436}); V a_6 = v_rest_2437; V a_7 = v_end_2438; V r_ = (g_heff_2esyntax_2epresyntax_2egivingLoop_24s1443624201x55423881(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2439); heff_drop(v_rest_2437); r_; });
    } else {
      heff_drop(v_t_2432);
      V v_sp_2445 = heff_dup(v_sp_241);
      V v_cx_2446 = heff_dup(v_cx_240);
      V v_rest_2447 = v_rest_245;
      V v_end_2448 = v_end_246;
      V v_p_2449 = v_p_242;
      V v_body_2450 = v_body_244;
      V v_t_2451 = (g_heff_2esyntax_2epresyntax_2eforT_2efirst_244(heff_dup(v_sp_2445), heff_dup(v_cx_2446)));
      V v_t_2452 = heff_intShow(heff_dup(heff_rfield(v_sp_2445, 0)));
      V v_t_2453 = ({ V a_0 = heff_dup(v_sp_2445); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_2446, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      V v_t_2454 = ({ V a_0 = heff_dup(v_cx_2446); V a_1 = v_rest_2447; V a_2 = v_end_2448; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_rest_2447); r_; });
      V v_t_2455 = (g_heff_2esyntax_2epresyntax_2elocalFun(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str5), v_t_2452), heff_dup(v_sp_2445), v_t_2453, v_t_2454));
      V v_t_2456 = heff_intShow(heff_dup(heff_rfield(v_sp_2445, 0)));
      V v_t_2457 = (g_heff_2esyntax_2epresyntax_2eforT_2eparams_245(heff_dup(v_sp_2445), heff_dup(v_cx_2446)));
      V v_t_2458 = heff_intShow(heff_dup(heff_rfield(v_sp_2445, 0)));
      V v_t_2459 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str6), v_t_2458)});
      V v_t_2460 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2459, heff_dup(v_sp_2445)}), heff_dup(heff_rfield(v_cx_2446, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_2446, 4))});
      V v_t_2461 = ({ V a_0 = heff_dup(v_sp_2445); V a_1 = v_p_2449; V a_2 = heff_dup(v_cx_2446); V a_3 = v_body_2450; V a_4 = v_t_2460; V a_5 = v_cx_2446; V r_ = (g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_body_2450); r_; });
      V v_t_2462 = (g_heff_2esyntax_2epresyntax_2elocalFun(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str7), v_t_2456), heff_dup(v_sp_2445), v_t_2457, v_t_2461));
      V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
      V v_t_2464 = heff_tag_n(TAG_ELocal, 2, (V[]){v_t_2451, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2455, v_t_2463})});
      v_body_2465 = heff_tag_n(TAG_At, 2, (V[]){v_t_2464, v_sp_2445});
    }
    V v_t_2468;
    switch (heff_tag_of(v_body_2465)) {
    case TAG_At: {
      V v_s_2467 = heff_dup(heff_field(v_body_2465, 1));
      v_t_2468 = v_s_2467;
      break;
    }
    default: heff_nomatch(v_body_2465);
    }
    V v_t_2469 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_241, 0)); V rr_ = heff_rec_reuse_nf(v_t_2468, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2472;
    switch (heff_tag_of(v_body_2465)) {
    case TAG_At: {
      V v_s_2471 = heff_dup(heff_field(v_body_2465, 1));
      v_t_2472 = v_s_2471;
      break;
    }
    default: heff_nomatch(v_body_2465);
    }
    V v_t_2473 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_241, 0)); V rr_ = heff_rec_reuse_nf(v_t_2472, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2474 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
    V v_t_2475 = heff_tag_n(TAG_PatVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str8), v_t_2474)});
    V v_t_2476 = heff_intShow(heff_dup(heff_rfield(v_sp_241, 0)));
    V v_t_2477 = heff_tag_n(TAG_PatVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_str9), v_t_2476)});
    V v_t_2478 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2477, heff_dup(v_sp_241)}), v_body_2465});
    V v_t_2479 = heff_tag_n(TAG_ELetIn, 2, (V[]){v_v_2431, heff_tag_n(TAG_At, 2, (V[]){v_t_2478, v_t_2469})});
    V v_t_2480 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2475, heff_dup(v_sp_241)}), heff_tag_n(TAG_At, 2, (V[]){v_t_2479, heff_dup(v_t_2473)})});
    V v_t_2481 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_241, 0)), heff_dup(heff_rfield(v_t_2473, 1))});
    V v_t_2482 = heff_tag_n(TAG_ELetIn, 2, (V[]){v_v_2423, heff_tag_n(TAG_At, 2, (V[]){v_t_2480, v_t_2481})});
    V v_t_2483 = ({ V rv_1 = heff_get_n(v_t_2473, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_241, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    return ({ V a_0 = v_cx_240; V a_1 = v_x_2411; V a_2 = heff_tag_n(TAG_At, 2, (V[]){v_t_2482, v_t_2483}); V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
  }
}
V g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2esyntax_2epresyntax_2eforT_24s1008641487x939869216_lam0(V self, V *args) {
  V v_exitJ_2442 = args[0];
  V v_body_2435 = heff_env(self)[0];
  V v_cx_2433 = heff_env(self)[1];
  V v_sp_2434 = heff_env(self)[2];
  V v_p_2436 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_ret_2443 = (g_list_2eany_24s2003678755x1820404042(heff_dup(v_body_2435)));
  V v_t_2444 = heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){heff_dup(heff_rfield(v_cx_2433, 0)), heff_dup(heff_rfield(v_cx_2433, 1)), heff_dup(heff_rfield(v_cx_2433, 2)), heff_dup(heff_rfield(v_cx_2433, 3)), heff_dup(heff_rfield(v_cx_2433, 4)), heff_tag_n(TAG_Just, 1, (V[]){v_ret_2443})});
  return ({ V a_0 = v_sp_2434; V a_1 = v_p_2436; V a_2 = v_cx_2433; V a_3 = v_body_2435; V a_4 = v_exitJ_2442; V a_5 = v_t_2444; V r_ = (g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_body_2435); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str0, 7, "recover");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str1, 64, "`try` needs the exception module's `recover`: `import exception`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str2, 3, "err");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str3, 10, "leaveScope");
Clo g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814(V v_cx_240, V v_sp_241, V v_x4_242, V v_end_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkTry: {
    V v_err_244 = heff_field(v_x4_242, 0);
    V v_body_245 = heff_field(v_x4_242, 1);
    V v_h_246 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24MkTry = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 0, 3);
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_247}), heff_dup(heff_rfield(v_cx_240, 3))});
    V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_sp_241, 0)), MK_INT(3LL));
    V v_t_2410 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_241, 0)), v_t_249});
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x4_242_24MkTry, TAG_ENotationVar, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str0), v_t_2410, ((V)&g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str1)}), heff_dup(v_sp_241)});
    V v_t_2417;
    switch (heff_tag_of(v_err_244)) {
    case TAG_Nothing: {
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_ty_2412 = heff_field(v_err_244, 0);
      heff_take_n(v_err_244, 1ULL, 1);
      V v_t_2415;
      switch (heff_tag_of(v_ty_2412)) {
      case TAG_At: {
        V v_s_2414 = heff_dup(heff_field(v_ty_2412, 1));
        v_t_2415 = v_s_2414;
        break;
      }
      default: heff_nomatch(v_ty_2412);
      }
      V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ENamed, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str2), v_ty_2412}), v_t_2415});
      v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_err_244);
    }
    V v_t_2418 = heff_intAdd(heff_dup(heff_rfield(v_cx_240, 4)), MK_INT(1LL));
    V v_t_2419 = heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){heff_dup(heff_rfield(v_cx_240, 0)), heff_dup(heff_rfield(v_cx_240, 1)), heff_dup(heff_rfield(v_cx_240, 2)), heff_dup(heff_rfield(v_cx_240, 3)), v_t_2418, heff_dup(heff_rfield(v_cx_240, 5))});
    V v_t_2420 = ({ V a_0 = v_t_2419; V a_1 = v_body_245; V a_2 = heff_dup(v_end_243); V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_body_245); r_; });
    V v_t_2426;
    switch (heff_tag_of(v_h_246)) {
    case TAG_MkCatchArm: {
      V v_b_2421 = heff_field(v_h_246, 0);
      V v_ss_2422 = heff_field(v_h_246, 1);
      V v_ru_24h_246_24MkCatchArm = heff_take_reuse_n(v_h_246, 3ULL, 2);
      V v_t_2423 = heff_intAdd(heff_take_field(v_cx_240, 4), MK_INT(1LL));
      V v_t_2424 = ({ V rv_4 = v_t_2423; V rr_ = heff_rec_reuse_nf(v_cx_240, 47ULL, 6, shape_names__muts__loop__sp__depth__giving, 3327u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      V v_t_2425 = ({ V a_0 = v_t_2424; V a_1 = v_ss_2422; V a_2 = v_end_243; V r_ = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(a_0, a_1, a_2)); heff_drop(v_ss_2422); r_; });
      v_t_2426 = heff_tag_at_n(v_ru_24h_246_24MkCatchArm, TAG_At, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_b_2421, v_t_2425}), heff_dup(v_sp_241)});
      break;
    }
    default: heff_nomatch(v_h_246);
    }
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
    V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2427})));
    V v_t_2429 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2411, v_t_2428));
    V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_str3)}), v_sp_241});
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2epresyntax_2eapp(v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_t_2431})));
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etryScope_24s2002610324x1871500814(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_str0, 10, "leaveScope");
Clo g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172(V v_cx_240, V v_sp_241, V v_w_242, V v_x_243, V v_xsp_244, V v_body_245, V v_end_246) {
top: ;
  V v_t_247 = heff_rec_n(2, shape_muts__inLam, (V[]){heff_dup(heff_rfield(v_cx_240, 1)), NTAG(TAG_False)});
  HeffT2 v_t_248 = (g_heff_2esyntax_2epresyntax_2eliftE_24cpr(heff_rec_n(2, shape_cx__guard, (V[]){heff_dup(v_cx_240), v_t_247}), NTAG(TAG_Nil), v_w_242));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_x_2411 = v_field_249;
    V v_y_2412 = v_field_2410;
    V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_cx_240, 0)), 0, 3);
    V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2413}), heff_dup(heff_rfield(v_cx_240, 3))});
    V v_t_2415 = heff_intAdd(heff_dup(heff_rfield(v_cx_240, 4)), MK_INT(1LL));
    V v_t_2416 = heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){heff_dup(heff_rfield(v_cx_240, 0)), heff_dup(heff_rfield(v_cx_240, 1)), heff_dup(heff_rfield(v_cx_240, 2)), heff_dup(heff_rfield(v_cx_240, 3)), v_t_2415, heff_dup(heff_rfield(v_cx_240, 5))});
    V v_e_2417 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(v_t_2416, v_body_245, v_end_246));
    V v_t_2418 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_243, heff_dup(v_xsp_244)}), heff_dup(v_e_2417)});
    V v_t_2421;
    switch (heff_tag_of(v_e_2417)) {
    case TAG_At: {
      V v_s_2420 = heff_field(v_e_2417, 1);
      heff_take_n(v_e_2417, 2ULL, 2);
      v_t_2421 = v_s_2420;
      break;
    }
    default: heff_nomatch(v_e_2417);
    }
    V v_t_2422 = ({ V rv_1 = heff_get_n(v_t_2421, 1, 2); V rr_ = heff_rec_reuse_nf(v_xsp_244, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_t_2422}), NTAG(TAG_Nil)});
    V v_t_2424 = (g_heff_2esyntax_2epresyntax_2eapp(v_y_2412, v_t_2423));
    V v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_str0)}), v_sp_241});
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
    V v_t_2427 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, v_t_2426})));
    return ({ V a_0 = v_cx_240; V a_1 = v_x_2411; V a_2 = v_t_2427; V r_ = (g_heff_2esyntax_2epresyntax_2ewrapBinds(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
  }
}
V g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2esyntax_2epresyntax_2ewithScopeOf_24s1438066643x286566172(a[0], a[1], a[2], a[3], a[4], a5, a[6]); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str0, 13, "this notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str1, 13, "this notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str2, 8, "a lambda");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str3, 8, "a lambda");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str4, 8, "a lambda");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str5, 5, "a tag");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str6, 8, "a record");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str7, 8, "a `case`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str8, 29, "a `let` whose body is checked");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str9, 19, "a term with `where`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str10, 9, "`abandon`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str11, 13, "this notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str12, 64, " does not infer its type: it must be put where its type is known");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str13, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str14, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str15, 98, "a type used as an element does not infer the universe it is in: it must be put where that is known");
Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etoInferable_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etoInferable(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IsInferable: {
    V v_i_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_i_241;
  }
  case TAG_IsCheckable: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24IsCheckable = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_At: {
      V v_c_243 = heff_field(v_x11_242, 0);
      V v_sp_244 = heff_field(v_x11_242, 1);
      V v_ru_24x11_242_24At = heff_take_reuse_n(v_x11_242, 3ULL, 2);
      V v_t_2428;
      switch (heff_tag_of(v_c_243)) {
      case TAG_CInf: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str0);
        break;
      }
      case TAG_CType: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str1);
        break;
      }
      case TAG_CLam: {
        heff_take_n(v_c_243, 0ULL, 3);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str2);
        break;
      }
      case TAG_CImplicitLam: {
        heff_take_n(v_c_243, 0ULL, 3);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str3);
        break;
      }
      case TAG_CAnnLam: {
        heff_take_n(v_c_243, 0ULL, 4);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str4);
        break;
      }
      case TAG_CTag: {
        heff_take_n(v_c_243, 0ULL, 3);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str5);
        break;
      }
      case TAG_CStruct: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str6);
        break;
      }
      case TAG_CMatch: {
        heff_take_n(v_c_243, 0ULL, 2);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str7);
        break;
      }
      case TAG_CLetIn: {
        heff_take_n(v_c_243, 0ULL, 2);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str8);
        break;
      }
      case TAG_CLocal: {
        heff_take_n(v_c_243, 0ULL, 2);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str9);
        break;
      }
      case TAG_CAbandon: {
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str10);
        break;
      }
      case TAG_CNominal: {
        heff_take_n(v_c_243, 0ULL, 1);
        v_t_2428 = ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str11);
        break;
      }
      default: heff_nomatch(v_c_243);
      }
      V v_t_2429 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), heff_strAppend(v_t_2428, ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str12)), heff_tag_at_n(v_ru_24x1_240_24IsCheckable, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
      return heff_tag_at_n(v_ru_24x11_242_24At, TAG_At, 2, (V[]){v_t_2429, v_sp_244});
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  case TAG_IsType: {
    V v_x11_2430 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24IsType = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_2430)) {
    case TAG_At: {
      V v_x111_2431 = heff_dup(heff_field(v_x11_2430, 0));
      switch (heff_tag_of(v_x111_2431)) {
      case TAG_TSig: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24IsType, 1);
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_sp_2435 = heff_field(v_x11_2430, 1);
          V v_ru_24x11_2430_24At = heff_take_reuse_n(v_x11_2430, 2ULL, 2);
          V v_t_2436 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str13), NTAG(TAG_Nothing)});
          return heff_tag_at_n(v_ru_24x11_2430_24At, TAG_At, 2, (V[]){v_t_2436, v_sp_2435});
        }
        default: return heff_nomatch(v_x11_2430);
        }
      }
      case TAG_TSum: {
        heff_take_n(v_x111_2431, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_240_24IsType, 1);
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_sp_2439 = heff_field(v_x11_2430, 1);
          V v_ru_24x11_2430_24At = heff_take_reuse_n(v_x11_2430, 2ULL, 2);
          V v_t_2440 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str14), NTAG(TAG_Nothing)});
          return heff_tag_at_n(v_ru_24x11_2430_24At, TAG_At, 2, (V[]){v_t_2440, v_sp_2439});
        }
        default: return heff_nomatch(v_x11_2430);
        }
      }
      default: {
        heff_drop(v_x111_2431);
        V v_t_2441 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str15), heff_tag_at_n(v_ru_24x1_240_24IsType, TAG_Just, 1, (V[]){heff_dup(g_heff_2esyntax_2epresyntax_2echeckedWays_get())})});
        V v_t_2444;
        switch (heff_tag_of(v_x11_2430)) {
        case TAG_At: {
          V v_s_2443 = heff_field(v_x11_2430, 1);
          heff_take_n(v_x11_2430, 2ULL, 2);
          v_t_2444 = v_s_2443;
          break;
        }
        default: heff_nomatch(v_x11_2430);
        }
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2441, v_t_2444});
      }
      }
    }
    default: return heff_nomatch(v_x11_2430);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etoInferable(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewordOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ewordOf(V v_x1_240, V v_sp_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2esyntax_2epresyntax_2ewordOf_24cpr(v_x1_240, v_sp_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_244, v_field_245})});
    } else {
      if ((v_tag_243 == ((int64_t)1ULL))) {
        heff_drop(v_field_245);
        return heff_tag_n(TAG_IsInferable, 1, (V[]){v_field_244});
      } else {
        return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_field_244, v_field_245})});
      }
    }
  }
}
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewordOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_str0, 22, "`Array` takes one type");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_str1, 22, "`Array` takes one type");
V g_heff_2esyntax_2epresyntax_2eappOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eappOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eappOf_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2eappOf(V v_r_240, V v_h_241, V v_args_242, V v_sp_243) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_At: {
    V v_h1_244 = heff_dup(heff_field(v_h_241, 0));
    switch (heff_tag_of(v_h1_244)) {
    case TAG_ETag: {
      V v_t_246 = heff_field(v_h1_244, 0);
      V v_ru_24h1_244_24ETag = heff_take_reuse_n(v_h1_244, 1ULL, 1);
      switch (heff_tag_of(v_h_241)) {
      case TAG_At: {
        V v_tsp_248 = heff_field(v_h_241, 1);
        V v_ru_24h_241_24At = heff_take_reuse_n(v_h_241, 2ULL, 2);
        V v_t_2420 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2eappOf_lam0, 1, 1, (V[]){v_r_240}), v_args_242));
        V v_t_2421 = heff_tag_at_n(v_ru_24h_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CTag, 3, (V[]){v_t_246, v_tsp_248, v_t_2420}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24ETag, TAG_IsCheckable, 1, (V[]){v_t_2421});
      }
      default: return heff_nomatch(v_h_241);
      }
    }
    case TAG_EWord: {
      V v_h11_2422 = heff_field(v_h1_244, 0);
      V v_ru_24h1_244_24EWord = heff_take_reuse_n(v_h1_244, 1ULL, 1);
      switch (heff_tag_of(v_h11_2422)) {
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_241, 2);
        switch (heff_tag_of(v_args_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_r_240, 2);
          V v_t_2423 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_str0), NTAG(TAG_Nothing)});
          V v_t_2424 = heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, heff_dup(v_sp_243)})});
          return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_sp_243})});
        }
        case TAG_Cons: {
          V v_a_2425 = heff_field(v_args_242, 0);
          V v_args2_2426 = heff_field(v_args_242, 1);
          V v_ru_24args_242_24Cons = heff_take_reuse_n(v_args_242, 3ULL, 2);
          switch (heff_tag_of(v_args2_2426)) {
          case TAG_Nil: {
            V v_x1_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_a_2425}));
            V v_t_2437;
            switch (heff_tag_of(v_x1_2427)) {
            case TAG_IsInferable: {
              V v_i_2428 = heff_field(v_x1_2427, 0);
              heff_take_n(v_x1_2427, 1ULL, 1);
              V v_t_2431;
              switch (heff_tag_of(v_i_2428)) {
              case TAG_At: {
                V v_s_2430 = heff_dup(heff_field(v_i_2428, 1));
                v_t_2431 = v_s_2430;
                break;
              }
              default: heff_nomatch(v_i_2428);
              }
              v_t_2437 = heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){v_i_2428}), v_t_2431});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_2432 = heff_field(v_x1_2427, 0);
              heff_take_n(v_x1_2427, 1ULL, 1);
              V v_t_2435;
              switch (heff_tag_of(v_c_2432)) {
              case TAG_At: {
                V v_s_2434 = heff_dup(heff_field(v_c_2432, 1));
                v_t_2435 = v_s_2434;
                break;
              }
              default: heff_nomatch(v_c_2432);
              }
              v_t_2437 = heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TChk, 1, (V[]){v_c_2432}), v_t_2435});
              break;
            }
            case TAG_IsType: {
              V v_t_2436 = heff_field(v_x1_2427, 0);
              heff_take_n(v_x1_2427, 1ULL, 1);
              heff_drop_cell(v_ru_24h1_244_24EWord, 1);
              heff_drop_cell(v_ru_24args_242_24Cons, 2);
              v_t_2437 = v_t_2436;
              break;
            }
            default: heff_nomatch(v_x1_2427);
            }
            V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TArray, 1, (V[]){v_t_2437}), v_sp_243});
            return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2438});
          }
          case TAG_Cons: {
            V v_ru_24args2_2426_24Cons = heff_take_reuse_n(v_args2_2426, 0ULL, 2);
            heff_drop_rec(v_r_240, 2);
            heff_drop(v_a_2425);
            V v_t_2441 = heff_tag_n(TAG_IInvalid, 3, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_str1), NTAG(TAG_Nothing)});
            V v_t_2442 = heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){v_t_2441, heff_dup(v_sp_243)})});
            return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_at_n(v_ru_24args2_2426_24Cons, TAG_At, 2, (V[]){v_t_2442, v_sp_243})});
          }
          default: return heff_nomatch(v_args2_2426);
          }
        }
        default: return heff_nomatch(v_args_242);
        }
      }
      default: {
        heff_drop(v_h11_2422);
        V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2444 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2443));
        V v_t_2445 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
        V v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2444, v_t_2445}), v_sp_243});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){v_t_2446});
      }
      }
    }
    default: {
      heff_drop(v_h1_244);
      V v_t_2447 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2448 = (g_heff_2esyntax_2epresyntax_2etoInferable(v_t_2447));
      V v_t_2449 = (g_list_2emap_24s942566919x1152393003(v_r_240, v_args_242));
      V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2448, v_t_2449}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2450});
    }
    }
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eappOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epresyntax_2eappOf_lam0(V self, V *args) {
  V v_e_249 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_IsInferable: {
    V v_i_2411 = heff_field(v_x1_2410, 0);
    V v_ru_24x1_2410_24IsInferable = heff_take_reuse_n(v_x1_2410, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_i_2411)) {
    case TAG_At: {
      V v_s_2413 = heff_dup(heff_field(v_i_2411, 1));
      v_t_2414 = v_s_2413;
      break;
    }
    default: heff_nomatch(v_i_2411);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2410_24IsInferable, TAG_CInf, 1, (V[]){v_i_2411}), v_t_2414});
  }
  case TAG_IsCheckable: {
    V v_c_2415 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    return v_c_2415;
  }
  case TAG_IsType: {
    V v_t_2416 = heff_field(v_x1_2410, 0);
    V v_ru_24x1_2410_24IsType = heff_take_reuse_n(v_x1_2410, 1ULL, 1);
    V v_t_2419;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_At: {
      V v_s_2418 = heff_dup(heff_field(v_t_2416, 1));
      v_t_2419 = v_s_2418;
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2410_24IsType, TAG_CType, 1, (V[]){v_t_2416}), v_t_2419});
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ealtOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ealtOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_b_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24MkAlt = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_245}));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        V v_ru_24x1_246_24IsInferable = heff_take_reuse_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_246_24IsInferable, TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        V v_ru_24x1_246_24IsType = heff_take_reuse_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_246_24IsType, TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_244, v_t_2416}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ealtOf(a[0], a[1]);
}

HeffT2 g_heff_2esyntax_2epresyntax_2ebinarySegments_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EImplicitVar: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENotationVar: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EString: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBinary: {
    V v_segs_2410 = heff_field(v_x1_240, 0);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_segs_2410)}});
  }
  case TAG_ERune: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWord: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProject: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENamed: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPi: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAnn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESpec: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESig: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESum: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStruct: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUpdate: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetIn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EDo: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELocal: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInvalid: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EIfThen: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBreak: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EContinue: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELazy: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETuple: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETry: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWith: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str0, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str1, 10, "bitsConcat");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str2, 9, "bitsBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str3, 11, "bitsOfBytes");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str4, 10, "bitsConcat");
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0, 2, 0};
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1, 2, 0};

HeffT1 g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr(V v_lit_240, V v_r_241, V v_segs_242, V v_sp_243, V v_x5_244) {
top: ;
  if ((heff_dup(v_x5_244) == NTAG(TAG_True))) {
    V v_t_245 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo), 2, (V[]){v_lit_240, v_r_241}));
    V v_m_2414 = heff_rec_n(2, shape_part__run, (V[]){v_t_245, ((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0_clo)});
    V v_xs_2415 = (g_heff_2esyntax_2epresyntax_2ebinaryParts(v_m_2414, v_segs_242, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2415));
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2416, heff_dup(v_sp_243)));
    V v_args_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_t_2419 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2418));
    V v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str1)}), heff_dup(v_sp_243)});
    V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2420, v_t_2419}), heff_dup(v_sp_243)});
    V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2421}), heff_dup(v_sp_243)});
    V v_args_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
    V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str2)}), heff_dup(v_sp_243)});
    V v_t_2425 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2423));
    V v_f_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2424, v_t_2425}), v_sp_243});
    return ((HeffT1){{v_f_2426}});
  } else {
    V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ebitsPart_24s539272465x993533026_clo), 2, (V[]){v_lit_240, v_r_241}));
    V v_m_2436 = heff_rec_n(2, shape_part__run, (V[]){v_t_2427, ((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1_clo)});
    V v_xs_2437 = (g_heff_2esyntax_2epresyntax_2ebinaryParts(v_m_2436, v_segs_242, NTAG(TAG_Nothing), NTAG(TAG_Nil)));
    V v_t_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2437));
    V v_t_2439 = (g_heff_2esyntax_2epresyntax_2elistOfChk(v_t_2438, heff_dup(v_sp_243)));
    V v_args_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
    V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str4)}), heff_dup(v_sp_243)});
    V v_t_2442 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_243), v_args_2440));
    V v_f_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2441, v_t_2442}), v_sp_243});
    return ((HeffT1){{v_f_2443}});
  }
}
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_sp_247 = args[1];
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str0)}), heff_dup(v_sp_247)});
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_246}), heff_dup(v_sp_247)});
  V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_249}), heff_dup(v_sp_247)});
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2410}), heff_dup(v_sp_247)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_2412}), heff_dup(v_sp_247)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2413}), v_sp_247});
}
V g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_lam1(V self, V *args) {
  V v_s_2428 = args[0];
  V v_sp_2429 = args[1];
  V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ebitsBinary_24s584659207x1272990093_24cpr_str3)}), heff_dup(v_sp_2429)});
  V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_2428}), heff_dup(v_sp_2429)});
  V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2431}), heff_dup(v_sp_2429)});
  V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2432}), heff_dup(v_sp_2429)});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
  V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2430, v_t_2434}), heff_dup(v_sp_2429)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2435}), v_sp_2429});
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_str0, 19, "prelude.codePointOf");
Clo g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(V v_v_240, V v_sp_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_v_240));
  V v_t_2415;
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_c_246 = heff_tag_n(TAG_At, 2, (V[]){v_field_244, v_field_245});
      v_t_2415 = v_c_246;
    } else {
      if ((v_tag_243 == ((int64_t)1ULL))) {
        heff_drop(v_field_245);
        V v_i_247 = v_field_244;
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
      } else {
        V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){v_field_244, v_field_245});
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_t_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2411}), v_t_2414});
      }
    }
  }
  V v_args_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
  V v_t_2417 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2416));
  V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_str0)}), heff_dup(v_sp_241)});
  V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2418, v_t_2417}), heff_dup(v_sp_241)});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2419}), v_sp_241});
}
V g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ecodePointTerm_24s330389855x1239955329(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178(V v_lit_240, V v_x2_241, V v_run_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_run_242)) {
    case TAG_Nothing: {
      heff_drop(v_lit_240);
      return v_acc_243;
    }
    case TAG_Just: {
      V v_x21_244 = heff_field(v_run_242, 0);
      V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_MkPair: {
        V v_s_245 = heff_field(v_x21_244, 0);
        V v_sp_246 = heff_field(v_x21_244, 1);
        V v_ru_24x21_244_24MkPair = heff_take_reuse_n(v_x21_244, 3ULL, 2);
        V v_t_247 = heff_tag_at_n(v_ru_24x21_244_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_242_24Just, TAG_IPrim, 1, (V[]){v_lit_240}), heff_dup(v_sp_246)});
        V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_245}), heff_dup(v_sp_246)});
        V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_248}), heff_dup(v_sp_246)});
        V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_249}), heff_dup(v_sp_246)});
        V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
        V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_247, v_t_2411}), heff_dup(v_sp_246)});
        V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2412}), v_sp_246});
        return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_acc_243});
      }
      default: return heff_nomatch(v_x21_244);
      }
    }
    default: return heff_nomatch(v_run_242);
    }
  }
  case TAG_Cons: {
    V v_x21_2414 = heff_field(v_x2_241, 0);
    V v_rest_2415 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2414)) {
    case TAG_At: {
      V v_seg_2416 = heff_field(v_x21_2414, 0);
      V v_sp_2417 = heff_field(v_x21_2414, 1);
      V v_ru_24x21_2414_24At = heff_take_reuse_n(v_x21_2414, 3ULL, 2);
      HeffT2 v_t_2418 = (g_heff_2esyntax_2epresyntax_2ewholeSegment_24cpr(v_seg_2416));
      {
        V v_field_2420 = v_t_2418.f[1];
        int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
        if ((v_tag_2419 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_seg_2416);
          heff_drop_cell(v_ru_24x21_2414_24At, 2);
          V v_s_2421 = v_field_2420;
          V v_t_2427;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            v_t_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_s_2421, v_sp_2417})});
            break;
          }
          case TAG_Just: {
            V v_x11_2422 = heff_field(v_run_242, 0);
            V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x11_2422)) {
            case TAG_MkPair: {
              V v_s0_2423 = heff_field(v_x11_2422, 0);
              V v_sp0_2424 = heff_field(v_x11_2422, 1);
              V v_ru_24x11_2422_24MkPair = heff_take_reuse_n(v_x11_2422, 3ULL, 2);
              V v_t_2425 = ({ V rv_1 = heff_get_n(v_sp_2417, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp0_2424, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2426 = heff_tag_at_n(v_ru_24x11_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_strAppend(v_s0_2423, v_s_2421), v_t_2425});
              v_t_2427 = heff_tag_at_n(v_ru_24run_242_24Just, TAG_Just, 1, (V[]){v_t_2426});
              break;
            }
            default: heff_nomatch(v_x11_2422);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_lit_240;
          V t_1 = v_rest_2415;
          V t_2 = v_t_2427;
          V t_3 = v_acc_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        } else {
          heff_drop(v_field_2420);
          V v_t_2428 = (g_heff_2esyntax_2epresyntax_2ebitsPart_24s1746757816x1436273076(heff_tag_at_n(v_ru_24x21_2414_24At, TAG_At, 2, (V[]){v_seg_2416, v_sp_2417})));
          V v_t_2439;
          switch (heff_tag_of(v_run_242)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            v_t_2439 = v_acc_243;
            break;
          }
          case TAG_Just: {
            V v_x21_2429 = heff_field(v_run_242, 0);
            V v_ru_24run_242_24Just = heff_take_reuse_n(v_run_242, 1ULL, 1);
            switch (heff_tag_of(v_x21_2429)) {
            case TAG_MkPair: {
              V v_s_2430 = heff_field(v_x21_2429, 0);
              V v_sp_2431 = heff_field(v_x21_2429, 1);
              V v_ru_24x21_2429_24MkPair = heff_take_reuse_n(v_x21_2429, 3ULL, 2);
              V v_t_2432 = heff_tag_at_n(v_ru_24x21_2429_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24run_242_24Just, TAG_IPrim, 1, (V[]){heff_dup(v_lit_240)}), heff_dup(v_sp_2431)});
              V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_s_2430}), heff_dup(v_sp_2431)});
              V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2433}), heff_dup(v_sp_2431)});
              V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2434}), heff_dup(v_sp_2431)});
              V v_t_2436 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
              V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2432, v_t_2436}), heff_dup(v_sp_2431)});
              V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2437}), v_sp_2431});
              v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, v_acc_243});
              break;
            }
            default: heff_nomatch(v_x21_2429);
            }
            break;
          }
          default: heff_nomatch(v_run_242);
          }
          V t_0 = v_lit_240;
          V t_1 = v_rest_2415;
          V t_2 = NTAG(TAG_Nothing);
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2439});
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          v_run_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        }
      }
    }
    default: return heff_nomatch(v_x21_2414);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ebinaryParts_24s1899067023x275441178(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclEquations: {
      V v_f_243 = heff_field(v_x21_241, 0);
      V v_fsp_244 = heff_field(v_x21_241, 1);
      V v_declared_245 = heff_field(v_x21_241, 2);
      V v_ty_246 = heff_field(v_x21_241, 3);
      V v_eqs_247 = heff_field(v_x21_241, 4);
      V v_ru_24x21_241_24DeclEquations = heff_take_reuse_n(v_x21_241, 31ULL, 5);
      HeffT3 v_t_248 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_ty_246));
      V v_t_2421;
      {
        V v_field_2410 = v_t_248.f[1];
        V v_field_2411 = v_t_248.f[2];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_c_2412 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2410, v_field_2411});
          V v_t_2415;
          switch (heff_tag_of(v_c_2412)) {
          case TAG_At: {
            V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
            v_t_2415 = v_s_2414;
            break;
          }
          default: heff_nomatch(v_c_2412);
          }
          v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        } else {
          if ((v_tag_249 == ((int64_t)1ULL))) {
            heff_drop(v_field_2411);
            V v_i_2416 = v_field_2410;
            V v_t_2419;
            switch (heff_tag_of(v_i_2416)) {
            case TAG_At: {
              V v_s_2418 = heff_dup(heff_field(v_i_2416, 1));
              v_t_2419 = v_s_2418;
              break;
            }
            default: heff_nomatch(v_i_2416);
            }
            v_t_2421 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2416}), v_t_2419});
          } else {
            V v_t_2420 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2410, v_field_2411});
            v_t_2421 = v_t_2420;
          }
        }
      }
      V v_t_2422 = (g_list_2emap_24s1276400643x126214923(v_eqs_247));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_243, v_fsp_244, v_declared_245, v_t_2421, v_t_2422}), v_sp_242});
    }
    case TAG_DeclDefine: {
      V v_x_2423 = heff_field(v_x21_241, 0);
      V v_xsp_2424 = heff_field(v_x21_241, 1);
      V v_ps_2425 = heff_field(v_x21_241, 2);
      V v_u_2426 = heff_field(v_x21_241, 3);
      V v_body_2427 = heff_field(v_x21_241, 4);
      V v_ru_24x21_241_24DeclDefine = heff_take_reuse_n(v_x21_241, 31ULL, 5);
      V v_t_2428 = (g_list_2emap_24s2051429168x672290949(v_ps_2425));
      HeffT3 v_t_2429 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_u_2426));
      V v_t_2442;
      {
        V v_field_2431 = v_t_2429.f[1];
        V v_field_2432 = v_t_2429.f[2];
        int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
        if ((v_tag_2430 == ((int64_t)0ULL))) {
          V v_c_2433 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2431, v_field_2432});
          V v_t_2436;
          switch (heff_tag_of(v_c_2433)) {
          case TAG_At: {
            V v_s_2435 = heff_dup(heff_field(v_c_2433, 1));
            v_t_2436 = v_s_2435;
            break;
          }
          default: heff_nomatch(v_c_2433);
          }
          v_t_2442 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2433}), v_t_2436});
        } else {
          if ((v_tag_2430 == ((int64_t)1ULL))) {
            heff_drop(v_field_2432);
            V v_i_2437 = v_field_2431;
            V v_t_2440;
            switch (heff_tag_of(v_i_2437)) {
            case TAG_At: {
              V v_s_2439 = heff_dup(heff_field(v_i_2437, 1));
              v_t_2440 = v_s_2439;
              break;
            }
            default: heff_nomatch(v_i_2437);
            }
            v_t_2442 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2437}), v_t_2440});
          } else {
            V v_t_2441 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2431, v_field_2432});
            v_t_2442 = v_t_2441;
          }
        }
      }
      HeffT3 v_t_2443 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2427));
      V v_t_2456;
      {
        V v_field_2445 = v_t_2443.f[1];
        V v_field_2446 = v_t_2443.f[2];
        int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
        if ((v_tag_2444 == ((int64_t)0ULL))) {
          V v_c_2447 = heff_tag_n(TAG_At, 2, (V[]){v_field_2445, v_field_2446});
          v_t_2456 = v_c_2447;
        } else {
          if ((v_tag_2444 == ((int64_t)1ULL))) {
            heff_drop(v_field_2446);
            V v_i_2448 = v_field_2445;
            V v_t_2451;
            switch (heff_tag_of(v_i_2448)) {
            case TAG_At: {
              V v_s_2450 = heff_dup(heff_field(v_i_2448, 1));
              v_t_2451 = v_s_2450;
              break;
            }
            default: heff_nomatch(v_i_2448);
            }
            v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2448}), v_t_2451});
          } else {
            V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){v_field_2445, v_field_2446});
            V v_t_2455;
            switch (heff_tag_of(v_t_2452)) {
            case TAG_At: {
              V v_s_2454 = heff_dup(heff_field(v_t_2452, 1));
              v_t_2455 = v_s_2454;
              break;
            }
            default: heff_nomatch(v_t_2452);
            }
            v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2452}), v_t_2455});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2423, v_xsp_2424, v_t_2428, v_t_2442, v_t_2456}), v_sp_242});
    }
    case TAG_DeclTheory: {
      V v_x_2457 = heff_field(v_x21_241, 0);
      V v_xsp_2458 = heff_field(v_x21_241, 1);
      V v_ps_2459 = heff_field(v_x21_241, 2);
      V v_body_2460 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24DeclTheory = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_t_2461 = (g_list_2emap_24s2051429168x672290949(v_ps_2459));
      HeffT3 v_t_2462 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_body_2460));
      V v_t_2475;
      {
        V v_field_2464 = v_t_2462.f[1];
        V v_field_2465 = v_t_2462.f[2];
        int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
        if ((v_tag_2463 == ((int64_t)0ULL))) {
          V v_c_2466 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2464, v_field_2465});
          v_t_2475 = v_c_2466;
        } else {
          if ((v_tag_2463 == ((int64_t)1ULL))) {
            heff_drop(v_field_2465);
            V v_i_2467 = v_field_2464;
            V v_t_2470;
            switch (heff_tag_of(v_i_2467)) {
            case TAG_At: {
              V v_s_2469 = heff_dup(heff_field(v_i_2467, 1));
              v_t_2470 = v_s_2469;
              break;
            }
            default: heff_nomatch(v_i_2467);
            }
            v_t_2475 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2467}), v_t_2470});
          } else {
            V v_t_2471 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2464, v_field_2465});
            V v_t_2474;
            switch (heff_tag_of(v_t_2471)) {
            case TAG_At: {
              V v_s_2473 = heff_dup(heff_field(v_t_2471, 1));
              v_t_2474 = v_s_2473;
              break;
            }
            default: heff_nomatch(v_t_2471);
            }
            v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2471}), v_t_2474});
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2457, v_xsp_2458, v_t_2461, v_t_2475}), v_sp_242});
    }
    case TAG_DeclPrimitive: {
      V v_x_2476 = heff_field(v_x21_241, 0);
      V v_xsp_2477 = heff_field(v_x21_241, 1);
      V v_t_2478 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24DeclPrimitive = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      HeffT3 v_t_2479 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_t_2478));
      V v_t_2492;
      {
        V v_field_2481 = v_t_2479.f[1];
        V v_field_2482 = v_t_2479.f[2];
        int64_t v_tag_2480 = ((int64_t)v_t_2479.f[0]);
        if ((v_tag_2480 == ((int64_t)0ULL))) {
          V v_c_2483 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2481, v_field_2482});
          V v_t_2486;
          switch (heff_tag_of(v_c_2483)) {
          case TAG_At: {
            V v_s_2485 = heff_dup(heff_field(v_c_2483, 1));
            v_t_2486 = v_s_2485;
            break;
          }
          default: heff_nomatch(v_c_2483);
          }
          v_t_2492 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2483}), v_t_2486});
        } else {
          if ((v_tag_2480 == ((int64_t)1ULL))) {
            heff_drop(v_field_2482);
            V v_i_2487 = v_field_2481;
            V v_t_2490;
            switch (heff_tag_of(v_i_2487)) {
            case TAG_At: {
              V v_s_2489 = heff_dup(heff_field(v_i_2487, 1));
              v_t_2490 = v_s_2489;
              break;
            }
            default: heff_nomatch(v_i_2487);
            }
            v_t_2492 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2487}), v_t_2490});
          } else {
            V v_t_2491 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_field_2481, v_field_2482});
            v_t_2492 = v_t_2491;
          }
        }
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2476, v_xsp_2477, v_t_2492}), v_sp_242});
    }
    case TAG_DeclTest: {
      V v_x_2493 = heff_field(v_x21_241, 0);
      V v_xsp_2494 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24DeclTest = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclTest, TAG_DeclTest, 2, (V[]){v_x_2493, v_xsp_2494}), v_sp_242});
    }
    case TAG_DeclWatch: {
      V v_e_2495 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24DeclWatch = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_2496 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_2495));
      V v_t_2497 = (g_heff_2esyntax_2epresyntax_2ewatchOf(v_t_2496));
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclWatch, TAG_DeclWatch, 1, (V[]){v_t_2497}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(a[0]);
}