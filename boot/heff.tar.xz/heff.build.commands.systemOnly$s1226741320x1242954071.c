// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define LBL_path 9928940
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_str1, 12, ".provider.js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_str2, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_str3, 12, ".provider.js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0(V v_s_240, V v_hd_241, V v_k_242, V v_host_243, V v_x_244) {
top: ;
  switch (heff_tag_of(v_x_244)) {
  case TAG_Left: {
    V v_ru_24x_244_24Left = heff_take_reuse_n(v_x_244, 0ULL, 1);
    V v_p_246 = heff_get_n(v_s_240, 2, 8);
    int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_p_246, 0)) - ((int64_t)3ULL));
    V v_t_248 = heff_strSlice_lent(v_p_246, heff_box_word(v_t_247), heff_strLength_lent(v_p_246, 0), 6);
    V v_t_2410;
    if (heff_strEq_c(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_str0))) {
      int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_p_246, 0)) - ((int64_t)3ULL));
      v_t_2410 = heff_strSlice(v_p_246, MK_INT(0LL), heff_box_word(v_t_249));
    } else {
      v_t_2410 = v_p_246;
    }
    V v_s_2411 = heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_str1));
    V v_path_2412 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2411));
    V v_t_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2412; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2412); r_; });
    V v_a_2415 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam0_clo)});
    V v_t_2416 = heff_tag_at_n(v_ru_24x_244_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2420, v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam1, 1, 1, (V[]){v_k_242})));
  }
  case TAG_Right: {
    V v_ru_24x_244_24Right = heff_take_reuse_n(v_x_244, 0ULL, 1);
    V v_p_2427 = heff_get_n(v_s_240, 2, 8);
    int64_t v_t_2428 = (heff_unbox_word(heff_strLength_lent(v_p_2427, 0)) - ((int64_t)3ULL));
    V v_t_2429 = heff_strSlice_lent(v_p_2427, heff_box_word(v_t_2428), heff_strLength_lent(v_p_2427, 0), 6);
    V v_t_2431;
    if (heff_strEq_c(v_t_2429, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_str2))) {
      int64_t v_t_2430 = (heff_unbox_word(heff_strLength_lent(v_p_2427, 0)) - ((int64_t)3ULL));
      v_t_2431 = heff_strSlice(v_p_2427, MK_INT(0LL), heff_box_word(v_t_2430));
    } else {
      v_t_2431 = v_p_2427;
    }
    V v_s_2432 = heff_strAppend(v_t_2431, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_str3));
    V v_path_2433 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2432));
    V v_t_2434 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2433; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2433); r_; });
    V v_a_2436 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam2_clo)});
    V v_t_2437 = heff_tag_at_n(v_ru_24x_244_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2441, v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam3, 1, 2, (V[]){v_k_242, heff_dup(v_host_243)})));
  }
  default: return heff_nomatch(v_x_244);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam0(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_242 = heff_env(self)[0];
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    heff_take_n(v_x_2421, 0ULL, 1);
    heff_clo_take(self, 1);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2423 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    switch (heff_tag_of(v_y_2423)) {
    case TAG_Left: {
      heff_take_n(v_y_2423, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_242;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      heff_take_n(v_y_2423, 0ULL, 1);
      heff_clo_take(self, 1);
      V f_ = v_k_242;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2423);
    }
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam2(V self, V *args) {
  V v_r_2435 = args[0];
  return v_r_2435;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_lam3(V self, V *args) {
  V v_x_2442 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_host_243 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Left: {
    heff_take_n(v_x_2442, 0ULL, 1);
    heff_clo_take(self, 2);
    heff_drop(v_host_243);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2444 = heff_field(v_x_2442, 0);
    heff_take_n(v_x_2442, 1ULL, 1);
    switch (heff_tag_of(v_y_2444)) {
    case TAG_Left: {
      heff_take_n(v_y_2444, 0ULL, 1);
      heff_clo_take(self, 2);
      heff_drop(v_host_243);
      V f_ = v_k_242;
      args[0] = NTAG(TAG_True);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2446 = heff_field(v_y_2444, 0);
      heff_take_n(v_y_2444, 1ULL, 1);
      V v_t_2447 = ({ V a_0 = v_x_2446; V b_1 = ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_str4); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s1226741320x1242954071_2ek_24l0_str5), v_x_2446, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_x_2446); heff_drop(b_1); r_; });
      V v_t_2448 = (g_list_2emap_24s649333309x1802289391(v_t_2447));
      V v_x1_2449 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2448));
      V v_t_2452;
      heff_clo_take(self, 2);
      switch (heff_tag_of(v_x1_2449)) {
      case TAG_Nil: {
        heff_drop(v_host_243);
        v_t_2452 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        V v_x_2450 = heff_field(v_x1_2449, 0);
        heff_take_n(v_x1_2449, 1ULL, 2);
        v_t_2452 = heff_bool(!heff_strEq_c_lent(v_x_2450, v_host_243, 0));
        heff_drop(v_host_243);
        heff_drop(v_x_2450);
        break;
      }
      default: heff_nomatch(v_x1_2449);
      }
      V f_ = v_k_242;
      args[0] = v_t_2452;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2444);
    }
  }
  default: return heff_nomatch(v_x_2442);
  }
}