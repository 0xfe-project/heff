// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArrayGenerate 2390
#define TAG_ArrayKeeps 39370
#define TAG_ArrayKeepsAs 18630
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CDrop 58400
#define TAG_CIf 14188
#define TAG_CInPlace 16708
#define TAG_CJump 43389
#define TAG_CLabel 29664
#define TAG_CLet 49341
#define TAG_CLoop 31741
#define TAG_CLoopTo 26658
#define TAG_CReturn 19985
#define TAG_CRoomed 55551
#define TAG_CSet 56068
#define TAG_CSwitch 58071
#define TAG_CTail 59847
#define TAG_MkCode 2932
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimAt 2075
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
HeffT2 g_heff_2ecompile_2egenerate_2eboxedPlain_24cpr(V);
V g_heff_2ecompile_2egenerate_2eflatPrim(V, V);
V g_heff_2ecompile_2egenerate_2eflatPrim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2eflatPrim_clo;
V g_heff_2ecompile_2egenerate_2eflatPrim_24tok2(V, V, V);
V g_heff_2ecompile_2egenerate_2eflatPrim_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2eflatPrim_24tok2_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_24dps(V, V, V);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_24dps_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_24dps(V, V, V);
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_24dps_clo;
V g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603(V);
V g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603_clo;
V g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837(V);
V g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837_clo;
V g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405(V);
V g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2efoldl_24s366449469x130665619(V, V);
V g_list_2efoldl_24s366449469x130665619_entry(V self, V *a);
extern Clo g_list_2efoldl_24s366449469x130665619_clo;
V g_list_2emap_24s1354671438x1264137843(V);
V g_list_2emap_24s1354671438x1264137843_entry(V self, V *a);
extern Clo g_list_2emap_24s1354671438x1264137843_clo;
V g_list_2emap_24s1429062098x1340918317(V);
V g_list_2emap_24s1429062098x1340918317_entry(V self, V *a);
extern Clo g_list_2emap_24s1429062098x1340918317_clo;
V g_list_2emap_24s1478286876x830244177(V);
V g_list_2emap_24s1478286876x830244177_entry(V self, V *a);
extern Clo g_list_2emap_24s1478286876x830244177_clo;
V g_list_2emap_24s1524528409x1420927362(V);
V g_list_2emap_24s1524528409x1420927362_entry(V self, V *a);
extern Clo g_list_2emap_24s1524528409x1420927362_clo;
V g_list_2emap_24s391650521x1406868658(V);
V g_list_2emap_24s391650521x1406868658_entry(V self, V *a);
extern Clo g_list_2emap_24s391650521x1406868658_clo;
V g_list_2emap_24s537124232x94423304(V);
V g_list_2emap_24s537124232x94423304_entry(V self, V *a);
extern Clo g_list_2emap_24s537124232x94423304_clo;
V g_list_2emap_24s70140105x1635164657(V);
V g_list_2emap_24s70140105x1635164657_entry(V self, V *a);
extern Clo g_list_2emap_24s70140105x1635164657_clo;
V g_list_2emap_24s784191759x2032889081(V);
V g_list_2emap_24s784191759x2032889081_entry(V self, V *a);
extern Clo g_list_2emap_24s784191759x2032889081_clo;

HeffT2 g_heff_2ecompile_2egenerate_2eboxedPlain_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_RLocal: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDup: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RClo: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGet: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetRaw: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RInt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFloat: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RStr: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBytes: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixed: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RNTag: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTag: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTagIn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRec: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RRecIn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RField: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RDupE: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldV: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetN: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFieldU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetNU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RWord: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RTakeField: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RGetLabel: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimFn: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrim: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RLam: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RCall: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RApply: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBool: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RBox: {
    V v_r_2469 = heff_field(v_e_240, 0);
    V v_e2_2470 = heff_field(v_e_240, 1);
    switch (heff_tag_of(v_e2_2470)) {
    case TAG_RLocal: {
      switch (heff_tag_of(v_r_2469)) {
      case TAG_RepV: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_RepFix: {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_r_2469)}});
      }
      case TAG_RepF64: {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_r_2469)}});
      }
      case TAG_RepInt: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_r_2469)}});
      }
    }
    case TAG_RDup: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RClo: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RGet: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RGetRaw: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RInt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RFloat: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RStr: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RBytes: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RFixed: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RF32: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RNTag: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RTag: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RTagIn: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RRec: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RRecIn: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RField: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RDupE: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RFieldV: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RGetN: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RFieldU: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RGetNU: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RWord: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RTakeField: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RGetLabel: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RPrimFn: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RPrim: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RLam: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RCall: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RApply: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RBool: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RAbandon: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RBox: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RUnbox: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RPeek: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RPrimU: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RPrimAt: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RFixU: {
      switch (heff_tag_of(v_r_2469)) {
      case TAG_RepV: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_RepFix: {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_r_2469)}});
      }
      case TAG_RepF64: {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_r_2469)}});
      }
      case TAG_RepInt: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_r_2469)}});
      }
    }
    case TAG_RF32U: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_RF64U: {
      switch (heff_tag_of(v_r_2469)) {
      case TAG_RepV: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_RepFix: {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_r_2469)}});
      }
      case TAG_RepF64: {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_r_2469)}});
      }
      case TAG_RepInt: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_r_2469)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_e2_2470)}});
    }
  }
  case TAG_RUnbox: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPeek: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RPrimAt: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RFixU: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF32U: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_RF64U: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}
V g_heff_2ecompile_2egenerate_2eflatPrim_lam0(V self, V *args);
Clo g_heff_2ecompile_2egenerate_2eflatPrim_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2egenerate_2eflatPrim_entry, 2, 0};

V g_heff_2ecompile_2egenerate_2eflatPrim(V v_p_240, V v_es_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_ArrayGenerate: {
    switch (heff_tag_of(v_es_241)) {
    case TAG_Nil: {
      return heff_tag_n(TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayGenerate), v_es_241});
    }
    case TAG_Cons: {
      V v_es2_243 = heff_dup(heff_field(v_es_241, 1));
      switch (heff_tag_of(v_es2_243)) {
      case TAG_Nil: {
        return heff_tag_n(TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayGenerate), v_es_241});
      }
      case TAG_Cons: {
        V v_f_244 = heff_field(v_es2_243, 0);
        V v_es22_245 = heff_field(v_es2_243, 1);
        V v_ru_24es2_243_24Cons = heff_take_reuse_n(v_es2_243, 3ULL, 2);
        switch (heff_tag_of(v_es22_245)) {
        case TAG_Nil: {
          V v_e_246 = v_f_244;
          V v_x3_2498;
          switch (heff_tag_of(v_e_246)) {
          case TAG_RLocal: {
            heff_take_n(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RDup: {
            heff_take_n(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RClo: {
            heff_take_n(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGet: {
            heff_take_n(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetRaw: {
            heff_take_n(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RInt: {
            heff_take_n(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFloat: {
            heff_take_na(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RStr: {
            heff_take_n(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RBytes: {
            heff_take_n(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFixed: {
            heff_take_n(v_e_246, 0ULL, 2);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RF32: {
            heff_take_na(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RNTag: {
            heff_take_n(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RTag: {
            heff_take_n(v_e_246, 0ULL, 3);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RTagIn: {
            heff_take_n(v_e_246, 0ULL, 4);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RRec: {
            heff_take_n(v_e_246, 0ULL, 3);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RRecIn: {
            heff_take_n(v_e_246, 0ULL, 8);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RField: {
            heff_take_n(v_e_246, 0ULL, 2);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RDupE: {
            heff_take_n(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFieldV: {
            heff_take_n(v_e_246, 0ULL, 2);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetN: {
            heff_take_n(v_e_246, 0ULL, 3);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFieldU: {
            heff_take_n(v_e_246, 0ULL, 4);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetNU: {
            heff_take_n(v_e_246, 0ULL, 5);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RWord: {
            heff_take_n(v_e_246, 0ULL, 2);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RTakeField: {
            heff_take_n(v_e_246, 0ULL, 2);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetLabel: {
            heff_take_n(v_e_246, 0ULL, 2);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrimFn: {
            heff_take_n(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrim: {
            heff_take_n(v_e_246, 0ULL, 2);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RLam: {
            V v_e4_2467 = heff_field(v_e_246, 3);
            heff_take_n(v_e_246, 8ULL, 4);
            switch (heff_tag_of(v_e4_2467)) {
            case TAG_MkCode: {
              V v_body_2468 = heff_field(v_e4_2467, 0);
              V v_ru_24e4_2467_24MkCode = heff_take_reuse_n(v_e4_2467, 1ULL, 1);
              V v_rs_2469 = (g_list_2efoldl_24s366449469x130665619(NTAG(TAG_Nil), v_body_2468));
              switch (heff_tag_of(v_rs_2469)) {
              case TAG_Nil: {
                heff_drop_cell(v_ru_24e4_2467_24MkCode, 1);
                v_x3_2498 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Cons: {
                V v_rs1_2470 = heff_field(v_rs_2469, 0);
                V v_rest_2471 = heff_field(v_rs_2469, 1);
                heff_take_n(v_rs_2469, 3ULL, 2);
                switch (heff_tag_of(v_rs1_2470)) {
                case TAG_Nothing: {
                  heff_drop_cell(v_ru_24e4_2467_24MkCode, 1);
                  heff_drop(v_rest_2471);
                  v_x3_2498 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_r_2472 = heff_field(v_rs1_2470, 0);
                  heff_take_n(v_rs1_2470, 1ULL, 1);
                  V v_t_2475 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2egenerate_2eflatPrim_lam0, 1, 1, (V[]){heff_dup(v_r_2472)}); V a_1 = v_rest_2471; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_rest_2471); r_; });
                  if ((heff_dup(v_t_2475) == NTAG(TAG_True))) {
                    heff_drop(v_t_2475);
                    v_x3_2498 = heff_tag_at_n(v_ru_24e4_2467_24MkCode, TAG_Just, 1, (V[]){v_r_2472});
                  } else {
                    heff_drop_cell(v_ru_24e4_2467_24MkCode, 1);
                    heff_drop(v_r_2472);
                    heff_drop(v_t_2475);
                    v_x3_2498 = NTAG(TAG_Nothing);
                  }
                  break;
                }
                default: heff_nomatch(v_rs1_2470);
                }
                break;
              }
              default: heff_nomatch(v_rs_2469);
              }
              break;
            }
            default: heff_nomatch(v_e4_2467);
            }
            break;
          }
          case TAG_RCall: {
            heff_take_n(v_e_246, 0ULL, 4);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RApply: {
            heff_take_n(v_e_246, 0ULL, 2);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RBool: {
            heff_take_n(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RAbandon: {
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RBox: {
            heff_take_n(v_e_246, 0ULL, 2);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RUnbox: {
            heff_take_n(v_e_246, 0ULL, 2);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPeek: {
            heff_take_n(v_e_246, 0ULL, 2);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrimU: {
            heff_take_n(v_e_246, 0ULL, 2);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrimAt: {
            heff_take_n(v_e_246, 0ULL, 3);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFixU: {
            heff_take_n(v_e_246, 0ULL, 2);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RF32U: {
            heff_take_na(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RF64U: {
            heff_take_na(v_e_246, 0ULL, 1);
            v_x3_2498 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_e_246);
          }
          switch (heff_tag_of(v_x3_2498)) {
          case TAG_Nothing: {
            return heff_tag_at_n(v_ru_24es2_243_24Cons, TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayGenerate), v_es_241});
          }
          case TAG_Just: {
            V v_x_2499 = heff_field(v_x3_2498, 0);
            heff_take_n(v_x3_2498, 1ULL, 1);
            heff_drop_cell(v_ru_24es2_243_24Cons, 2);
            return heff_tag_n(TAG_RPrimAt, 3, (V[]){NTAG(TAG_ArrayGenerate), v_x_2499, v_es_241});
          }
          default: return heff_nomatch(v_x3_2498);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_es22_245, 0ULL, 2);
          heff_drop(v_f_244);
          return heff_tag_at_n(v_ru_24es2_243_24Cons, TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayGenerate), v_es_241});
        }
        default: return heff_nomatch(v_es22_245);
        }
      }
      default: return heff_nomatch(v_es2_243);
      }
    }
    default: return heff_nomatch(v_es_241);
    }
  }
  case TAG_ArrayKeepsAs: {
    V v_es_24102 = v_es_241;
    switch (heff_tag_of(v_es_24102)) {
    case TAG_Nil: {
      return heff_tag_n(TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayKeepsAs), v_es_24102});
    }
    case TAG_Cons: {
      V v_a_24103 = heff_dup(heff_field(v_es_24102, 0));
      V v_es2_24104 = heff_dup(heff_field(v_es_24102, 1));
      switch (heff_tag_of(v_es2_24104)) {
      case TAG_Nil: {
        heff_drop(v_a_24103);
        return heff_tag_n(TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayKeepsAs), v_es_24102});
      }
      case TAG_Cons: {
        V v_x_24105 = heff_field(v_es2_24104, 0);
        V v_es22_24106 = heff_field(v_es2_24104, 1);
        V v_ru_24es2_24104_24Cons = heff_take_reuse_n(v_es2_24104, 3ULL, 2);
        switch (heff_tag_of(v_es22_24106)) {
        case TAG_Nil: {
          heff_drop_tag(v_es_24102, 2);
          HeffT2 v_t_24107 = (g_heff_2ecompile_2egenerate_2eboxedPlain_24cpr(v_x_24105));
          {
            V v_field_24109 = v_t_24107.f[1];
            int64_t v_tag_24108 = ((int64_t)v_t_24107.f[0]);
            if ((v_tag_24108 == ((int64_t)0ULL))) {
              heff_drop(v_x_24105);
              V v_x_24110 = v_field_24109;
              V v_t_24111 = heff_tag_at_n(v_ru_24es2_24104_24Cons, TAG_Cons, 2, (V[]){v_a_24103, NTAG(TAG_Nil)});
              return heff_tag_n(TAG_RPrimAt, 3, (V[]){NTAG(TAG_ArrayKeeps), v_x_24110, v_t_24111});
            } else {
              heff_drop(v_field_24109);
              V v_t_24112 = heff_tag_at_n(v_ru_24es2_24104_24Cons, TAG_Cons, 2, (V[]){v_x_24105, NTAG(TAG_Nil)});
              return heff_tag_n(TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayKeepsAs), heff_tag_n(TAG_Cons, 2, (V[]){v_a_24103, v_t_24112})});
            }
          }
        }
        case TAG_Cons: {
          V v_ru_24es22_24106_24Cons = heff_take_reuse_n(v_es22_24106, 0ULL, 2);
          heff_drop(v_a_24103);
          heff_drop(v_x_24105);
          heff_drop_cell(v_ru_24es2_24104_24Cons, 2);
          return heff_tag_at_n(v_ru_24es22_24106_24Cons, TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayKeepsAs), v_es_24102});
        }
        default: return heff_nomatch(v_es22_24106);
        }
      }
      default: return heff_nomatch(v_es2_24104);
      }
    }
    default: return heff_nomatch(v_es_24102);
    }
  }
  default: {
    return heff_tag_n(TAG_RPrim, 2, (V[]){v_p_240, v_es_241});
  }
  }
}
V g_heff_2ecompile_2egenerate_2eflatPrim_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2egenerate_2eflatPrim(a[0], a[1]);
}
V g_heff_2ecompile_2egenerate_2eflatPrim_lam0(V self, V *args) {
  V v_x2_2473 = args[0];
  V v_r_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2473)) {
  case TAG_Nothing: {
    heff_drop(v_r_2472);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_s_2474 = heff_field(v_x2_2473, 0);
    heff_take_n(v_x2_2473, 1ULL, 1);
    return ({ V a_0 = v_r_2472; V a_1 = v_s_2474; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_r_2472); heff_drop(v_s_2474); r_; });
  }
  default: return heff_nomatch(v_x2_2473);
  }
}
Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_entry, 1, 0};

V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_RLocal: {
    return v_x2_240;
  }
  case TAG_RDup: {
    return v_x2_240;
  }
  case TAG_RClo: {
    return v_x2_240;
  }
  case TAG_RGet: {
    return v_x2_240;
  }
  case TAG_RGetRaw: {
    return v_x2_240;
  }
  case TAG_RInt: {
    return v_x2_240;
  }
  case TAG_RFloat: {
    return v_x2_240;
  }
  case TAG_RStr: {
    return v_x2_240;
  }
  case TAG_RBytes: {
    return v_x2_240;
  }
  case TAG_RFixed: {
    return v_x2_240;
  }
  case TAG_RF32: {
    return v_x2_240;
  }
  case TAG_RNTag: {
    return v_x2_240;
  }
  case TAG_RTag: {
    V v_t_2414 = heff_field(v_x2_240, 0);
    V v_b_2415 = heff_field(v_x2_240, 1);
    V v_es_2416 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24RTag = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2417 = (g_list_2emap_24s1354671438x1264137843(v_es_2416));
    return heff_tag_at_n(v_ru_24x2_240_24RTag, TAG_RTag, 3, (V[]){v_t_2414, v_b_2415, v_t_2417});
  }
  case TAG_RTagIn: {
    V v_e_2418 = heff_field(v_x2_240, 0);
    V v_t_2419 = heff_field(v_x2_240, 1);
    V v_b_2420 = heff_field(v_x2_240, 2);
    V v_es_2421 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24RTagIn = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2422 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2418));
    V v_t_2423 = (g_list_2emap_24s1354671438x1264137843(v_es_2421));
    return heff_tag_at_n(v_ru_24x2_240_24RTagIn, TAG_RTagIn, 4, (V[]){v_t_2422, v_t_2419, v_b_2420, v_t_2423});
  }
  case TAG_RRec: {
    V v_ls_2424 = heff_field(v_x2_240, 0);
    V v_b_2425 = heff_field(v_x2_240, 1);
    V v_es_2426 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24RRec = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2427 = (g_list_2emap_24s1354671438x1264137843(v_es_2426));
    return heff_tag_at_n(v_ru_24x2_240_24RRec, TAG_RRec, 3, (V[]){v_ls_2424, v_b_2425, v_t_2427});
  }
  case TAG_RRecIn: {
    V v_x_2428 = heff_field(v_x2_240, 0);
    V v_n_2429 = heff_field(v_x2_240, 1);
    V v_k_2430 = heff_field(v_x2_240, 2);
    V v_f_2431 = heff_field(v_x2_240, 3);
    V v_s_2432 = heff_field(v_x2_240, 4);
    V v_ls_2433 = heff_field(v_x2_240, 5);
    V v_fs_2434 = heff_field(v_x2_240, 6);
    V v_sure_2435 = heff_field(v_x2_240, 7);
    V v_ru_24x2_240_24RRecIn = heff_take_reuse_n(v_x2_240, 255ULL, 8);
    V v_t_2436 = (g_list_2emap_24s70140105x1635164657(v_fs_2434));
    return heff_tag_at_n(v_ru_24x2_240_24RRecIn, TAG_RRecIn, 8, (V[]){v_x_2428, v_n_2429, v_k_2430, v_f_2431, v_s_2432, v_ls_2433, v_t_2436, v_sure_2435});
  }
  case TAG_RField: {
    V v_e_2437 = heff_field(v_x2_240, 0);
    V v_i_2438 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RField = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2439 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2437));
    return heff_tag_at_n(v_ru_24x2_240_24RField, TAG_RField, 2, (V[]){v_t_2439, v_i_2438});
  }
  case TAG_RDupE: {
    V v_e_2440 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24RDupE = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_cell_2441 = heff_tag_at_n(v_ru_24x2_240_24RDupE, TAG_RDupE, 1, (V[]){heff_hole()});
    V v_u_2442 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_24dps(v_e_2440, heff_dup(v_cell_2441), MK_INT(0LL)));
    heff_drop(v_u_2442);
    return v_cell_2441;
  }
  case TAG_RFieldV: {
    V v_e_2443 = heff_field(v_x2_240, 0);
    V v_i_2444 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RFieldV = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2445 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2443));
    return heff_tag_at_n(v_ru_24x2_240_24RFieldV, TAG_RFieldV, 2, (V[]){v_t_2445, v_i_2444});
  }
  case TAG_RGetN: {
    V v_e_2446 = heff_field(v_x2_240, 0);
    V v_i_2447 = heff_field(v_x2_240, 1);
    V v_n_2448 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24RGetN = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2449 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2446));
    return heff_tag_at_n(v_ru_24x2_240_24RGetN, TAG_RGetN, 3, (V[]){v_t_2449, v_i_2447, v_n_2448});
  }
  case TAG_RFieldU: {
    V v_r_2450 = heff_field(v_x2_240, 0);
    V v_s_2451 = heff_field(v_x2_240, 1);
    V v_e_2452 = heff_field(v_x2_240, 2);
    V v_i_2453 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24RFieldU = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2454 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2452));
    return heff_tag_at_n(v_ru_24x2_240_24RFieldU, TAG_RFieldU, 4, (V[]){v_r_2450, v_s_2451, v_t_2454, v_i_2453});
  }
  case TAG_RGetNU: {
    V v_r_2455 = heff_field(v_x2_240, 0);
    V v_s_2456 = heff_field(v_x2_240, 1);
    V v_e_2457 = heff_field(v_x2_240, 2);
    V v_i_2458 = heff_field(v_x2_240, 3);
    V v_n_2459 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24RGetNU = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_2460 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2457));
    return heff_tag_at_n(v_ru_24x2_240_24RGetNU, TAG_RGetNU, 5, (V[]){v_r_2455, v_s_2456, v_t_2460, v_i_2458, v_n_2459});
  }
  case TAG_RWord: {
    V v_r_2461 = heff_field(v_x2_240, 0);
    V v_e_2462 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RWord = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2463 = heff_tag_at_n(v_ru_24x2_240_24RWord, TAG_RWord, 2, (V[]){v_r_2461, heff_hole()});
    V v_u_2464 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_24dps(v_e_2462, heff_dup(v_cell_2463), MK_INT(1LL)));
    heff_drop(v_u_2464);
    return v_cell_2463;
  }
  case TAG_RTakeField: {
    return v_x2_240;
  }
  case TAG_RGetLabel: {
    V v_e_2467 = heff_field(v_x2_240, 0);
    V v_l_2468 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RGetLabel = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2469 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2467));
    return heff_tag_at_n(v_ru_24x2_240_24RGetLabel, TAG_RGetLabel, 2, (V[]){v_t_2469, v_l_2468});
  }
  case TAG_RPrimFn: {
    return v_x2_240;
  }
  case TAG_RPrim: {
    V v_p_2471 = heff_field(v_x2_240, 0);
    V v_es_2472 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RPrim = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2473 = (g_list_2emap_24s1354671438x1264137843(v_es_2472));
    return (g_heff_2ecompile_2egenerate_2eflatPrim_24tok2(v_ru_24x2_240_24RPrim, v_p_2471, v_t_2473));
  }
  case TAG_RLam: {
    V v_xs_2474 = heff_field(v_x2_240, 0);
    V v_fv_2475 = heff_field(v_x2_240, 1);
    V v_held_2476 = heff_field(v_x2_240, 2);
    V v_x24_2477 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24RLam = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    switch (heff_tag_of(v_x24_2477)) {
    case TAG_MkCode: {
      V v_body_2478 = heff_field(v_x24_2477, 0);
      V v_ru_24x24_2477_24MkCode = heff_take_reuse_n(v_x24_2477, 1ULL, 1);
      V v_t_2479 = (g_list_2emap_24s1354671438x1264137843(v_held_2476));
      V v_t_2480 = (g_list_2emap_24s1478286876x830244177(v_body_2478));
      return heff_tag_at_n(v_ru_24x2_240_24RLam, TAG_RLam, 4, (V[]){v_xs_2474, v_fv_2475, v_t_2479, heff_tag_at_n(v_ru_24x24_2477_24MkCode, TAG_MkCode, 1, (V[]){v_t_2480})});
    }
    default: return heff_nomatch(v_x24_2477);
    }
  }
  case TAG_RCall: {
    V v_g_2481 = heff_field(v_x2_240, 0);
    V v_tr_2482 = heff_field(v_x2_240, 1);
    V v_w_2483 = heff_field(v_x2_240, 2);
    V v_args_2484 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24RCall = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2485 = (g_list_2emap_24s1524528409x1420927362(v_args_2484));
    return heff_tag_at_n(v_ru_24x2_240_24RCall, TAG_RCall, 4, (V[]){v_g_2481, v_tr_2482, v_w_2483, v_t_2485});
  }
  case TAG_RApply: {
    V v_f_2486 = heff_field(v_x2_240, 0);
    V v_es_2487 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RApply = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2488 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_f_2486));
    V v_t_2489 = (g_list_2emap_24s1354671438x1264137843(v_es_2487));
    return heff_tag_at_n(v_ru_24x2_240_24RApply, TAG_RApply, 2, (V[]){v_t_2488, v_t_2489});
  }
  case TAG_RBool: {
    V v_c_2490 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24RBool = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2491 = (g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405(v_c_2490));
    return heff_tag_at_n(v_ru_24x2_240_24RBool, TAG_RBool, 1, (V[]){v_t_2491});
  }
  case TAG_RAbandon: {
    return v_x2_240;
  }
  case TAG_RBox: {
    V v_r_2492 = heff_field(v_x2_240, 0);
    V v_e_2493 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RBox = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2494 = heff_tag_at_n(v_ru_24x2_240_24RBox, TAG_RBox, 2, (V[]){v_r_2492, heff_hole()});
    V v_u_2495 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_24dps(v_e_2493, heff_dup(v_cell_2494), MK_INT(1LL)));
    heff_drop(v_u_2495);
    return v_cell_2494;
  }
  case TAG_RUnbox: {
    V v_r_2496 = heff_field(v_x2_240, 0);
    V v_e_2497 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RUnbox = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2498 = heff_tag_at_n(v_ru_24x2_240_24RUnbox, TAG_RUnbox, 2, (V[]){v_r_2496, heff_hole()});
    V v_u_2499 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_24dps(v_e_2497, heff_dup(v_cell_2498), MK_INT(1LL)));
    heff_drop(v_u_2499);
    return v_cell_2498;
  }
  case TAG_RPeek: {
    V v_r_24100 = heff_field(v_x2_240, 0);
    V v_e_24101 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RPeek = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_24102 = heff_tag_at_n(v_ru_24x2_240_24RPeek, TAG_RPeek, 2, (V[]){v_r_24100, heff_hole()});
    V v_u_24103 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_24dps(v_e_24101, heff_dup(v_cell_24102), MK_INT(1LL)));
    heff_drop(v_u_24103);
    return v_cell_24102;
  }
  case TAG_RPrimU: {
    V v_p_24104 = heff_field(v_x2_240, 0);
    V v_es_24105 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RPrimU = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24106 = (g_list_2emap_24s1354671438x1264137843(v_es_24105));
    return heff_tag_at_n(v_ru_24x2_240_24RPrimU, TAG_RPrimU, 2, (V[]){v_p_24104, v_t_24106});
  }
  case TAG_RPrimAt: {
    V v_p_24107 = heff_field(v_x2_240, 0);
    V v_r_24108 = heff_field(v_x2_240, 1);
    V v_es_24109 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24RPrimAt = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_24110 = (g_list_2emap_24s1354671438x1264137843(v_es_24109));
    return heff_tag_at_n(v_ru_24x2_240_24RPrimAt, TAG_RPrimAt, 3, (V[]){v_p_24107, v_r_24108, v_t_24110});
  }
  case TAG_RFixU: {
    return v_x2_240;
  }
  case TAG_RF32U: {
    return v_x2_240;
  }
  case TAG_RF64U: {
    return v_x2_240;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(a[0]);
}
Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_24dps_entry, 3, 0};

V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_24dps(V v_x2_240, V v_d_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_RLocal: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RDup: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RClo: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RGet: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RGetRaw: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RInt: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RFloat: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RStr: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RBytes: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RFixed: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RF32: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RNTag: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RTag: {
    V v_t_2416 = heff_field(v_x2_240, 0);
    V v_b_2417 = heff_field(v_x2_240, 1);
    V v_es_2418 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2419 = (g_list_2emap_24s1354671438x1264137843(v_es_2418));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RTag, 3, (V[]){v_t_2416, v_b_2417, v_t_2419}));
  }
  case TAG_RTagIn: {
    V v_e_2420 = heff_field(v_x2_240, 0);
    V v_t_2421 = heff_field(v_x2_240, 1);
    V v_b_2422 = heff_field(v_x2_240, 2);
    V v_es_2423 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_t_2424 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2420));
    V v_t_2425 = (g_list_2emap_24s1354671438x1264137843(v_es_2423));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RTagIn, 4, (V[]){v_t_2424, v_t_2421, v_b_2422, v_t_2425}));
  }
  case TAG_RRec: {
    V v_ls_2426 = heff_field(v_x2_240, 0);
    V v_b_2427 = heff_field(v_x2_240, 1);
    V v_es_2428 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2429 = (g_list_2emap_24s1354671438x1264137843(v_es_2428));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RRec, 3, (V[]){v_ls_2426, v_b_2427, v_t_2429}));
  }
  case TAG_RRecIn: {
    V v_x_2430 = heff_field(v_x2_240, 0);
    V v_n_2431 = heff_field(v_x2_240, 1);
    V v_k_2432 = heff_field(v_x2_240, 2);
    V v_f_2433 = heff_field(v_x2_240, 3);
    V v_s_2434 = heff_field(v_x2_240, 4);
    V v_ls_2435 = heff_field(v_x2_240, 5);
    V v_fs_2436 = heff_field(v_x2_240, 6);
    V v_sure_2437 = heff_field(v_x2_240, 7);
    heff_take_n(v_x2_240, 255ULL, 8);
    V v_t_2438 = (g_list_2emap_24s70140105x1635164657(v_fs_2436));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RRecIn, 8, (V[]){v_x_2430, v_n_2431, v_k_2432, v_f_2433, v_s_2434, v_ls_2435, v_t_2438, v_sure_2437}));
  }
  case TAG_RField: {
    V v_e_2439 = heff_field(v_x2_240, 0);
    V v_i_2440 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_2441 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2439));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RField, 2, (V[]){v_t_2441, v_i_2440}));
  }
  case TAG_RDupE: {
    V v_e_2442 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24RDupE = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_cell_2443 = heff_tag_at_n(v_ru_24x2_240_24RDupE, TAG_RDupE, 1, (V[]){heff_hole()});
    V v_u_2444 = heff_setField(v_d_241, v_i_242, heff_dup(v_cell_2443));
    heff_drop(v_u_2444);
    V t_0 = v_e_2442;
    V t_1 = v_cell_2443;
    V t_2 = MK_INT(0LL);
    v_x2_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    goto top;
  }
  case TAG_RFieldV: {
    V v_e_2445 = heff_field(v_x2_240, 0);
    V v_i_2446 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_2447 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2445));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RFieldV, 2, (V[]){v_t_2447, v_i_2446}));
  }
  case TAG_RGetN: {
    V v_e_2448 = heff_field(v_x2_240, 0);
    V v_i_2449 = heff_field(v_x2_240, 1);
    V v_n_2450 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2451 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2448));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RGetN, 3, (V[]){v_t_2451, v_i_2449, v_n_2450}));
  }
  case TAG_RFieldU: {
    V v_r_2452 = heff_field(v_x2_240, 0);
    V v_s_2453 = heff_field(v_x2_240, 1);
    V v_e_2454 = heff_field(v_x2_240, 2);
    V v_i_2455 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_t_2456 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2454));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RFieldU, 4, (V[]){v_r_2452, v_s_2453, v_t_2456, v_i_2455}));
  }
  case TAG_RGetNU: {
    V v_r_2457 = heff_field(v_x2_240, 0);
    V v_s_2458 = heff_field(v_x2_240, 1);
    V v_e_2459 = heff_field(v_x2_240, 2);
    V v_i_2460 = heff_field(v_x2_240, 3);
    V v_n_2461 = heff_field(v_x2_240, 4);
    heff_take_n(v_x2_240, 31ULL, 5);
    V v_t_2462 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2459));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RGetNU, 5, (V[]){v_r_2457, v_s_2458, v_t_2462, v_i_2460, v_n_2461}));
  }
  case TAG_RWord: {
    V v_r_2463 = heff_field(v_x2_240, 0);
    V v_e_2464 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RWord = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2465 = heff_tag_at_n(v_ru_24x2_240_24RWord, TAG_RWord, 2, (V[]){v_r_2463, heff_hole()});
    V v_u_2466 = heff_setField(v_d_241, v_i_242, heff_dup(v_cell_2465));
    heff_drop(v_u_2466);
    V t_0 = v_e_2464;
    V t_1 = v_cell_2465;
    V t_2 = MK_INT(1LL);
    v_x2_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    goto top;
  }
  case TAG_RTakeField: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RGetLabel: {
    V v_e_2469 = heff_field(v_x2_240, 0);
    V v_l_2470 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_2471 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2469));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RGetLabel, 2, (V[]){v_t_2471, v_l_2470}));
  }
  case TAG_RPrimFn: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RPrim: {
    V v_p_2473 = heff_field(v_x2_240, 0);
    V v_es_2474 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RPrim = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2475 = (g_list_2emap_24s1354671438x1264137843(v_es_2474));
    V v_t_2476 = (g_heff_2ecompile_2egenerate_2eflatPrim_24tok2(v_ru_24x2_240_24RPrim, v_p_2473, v_t_2475));
    return heff_setField(v_d_241, v_i_242, v_t_2476);
  }
  case TAG_RLam: {
    V v_xs_2477 = heff_field(v_x2_240, 0);
    V v_fv_2478 = heff_field(v_x2_240, 1);
    V v_held_2479 = heff_field(v_x2_240, 2);
    V v_x24_2480 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24RLam = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    switch (heff_tag_of(v_x24_2480)) {
    case TAG_MkCode: {
      V v_body_2481 = heff_field(v_x24_2480, 0);
      V v_ru_24x24_2480_24MkCode = heff_take_reuse_n(v_x24_2480, 1ULL, 1);
      V v_t_2482 = (g_list_2emap_24s1354671438x1264137843(v_held_2479));
      V v_t_2483 = (g_list_2emap_24s1478286876x830244177(v_body_2481));
      V v_t_2484 = heff_tag_at_n(v_ru_24x2_240_24RLam, TAG_RLam, 4, (V[]){v_xs_2477, v_fv_2478, v_t_2482, heff_tag_at_n(v_ru_24x24_2480_24MkCode, TAG_MkCode, 1, (V[]){v_t_2483})});
      return heff_setField(v_d_241, v_i_242, v_t_2484);
    }
    default: return heff_nomatch(v_x24_2480);
    }
  }
  case TAG_RCall: {
    V v_g_2485 = heff_field(v_x2_240, 0);
    V v_tr_2486 = heff_field(v_x2_240, 1);
    V v_w_2487 = heff_field(v_x2_240, 2);
    V v_args_2488 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_t_2489 = (g_list_2emap_24s1524528409x1420927362(v_args_2488));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RCall, 4, (V[]){v_g_2485, v_tr_2486, v_w_2487, v_t_2489}));
  }
  case TAG_RApply: {
    V v_f_2490 = heff_field(v_x2_240, 0);
    V v_es_2491 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_2492 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_f_2490));
    V v_t_2493 = (g_list_2emap_24s1354671438x1264137843(v_es_2491));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RApply, 2, (V[]){v_t_2492, v_t_2493}));
  }
  case TAG_RBool: {
    V v_c_2494 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2495 = (g_heff_2ecompile_2eowned_2emapCond_24s1211555591x1863775405(v_c_2494));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RBool, 1, (V[]){v_t_2495}));
  }
  case TAG_RAbandon: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RBox: {
    V v_r_2496 = heff_field(v_x2_240, 0);
    V v_e_2497 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RBox = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2498 = heff_tag_at_n(v_ru_24x2_240_24RBox, TAG_RBox, 2, (V[]){v_r_2496, heff_hole()});
    V v_u_2499 = heff_setField(v_d_241, v_i_242, heff_dup(v_cell_2498));
    heff_drop(v_u_2499);
    V t_0 = v_e_2497;
    V t_1 = v_cell_2498;
    V t_2 = MK_INT(1LL);
    v_x2_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    goto top;
  }
  case TAG_RUnbox: {
    V v_r_24100 = heff_field(v_x2_240, 0);
    V v_e_24101 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RUnbox = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_24102 = heff_tag_at_n(v_ru_24x2_240_24RUnbox, TAG_RUnbox, 2, (V[]){v_r_24100, heff_hole()});
    V v_u_24103 = heff_setField(v_d_241, v_i_242, heff_dup(v_cell_24102));
    heff_drop(v_u_24103);
    V t_0 = v_e_24101;
    V t_1 = v_cell_24102;
    V t_2 = MK_INT(1LL);
    v_x2_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    goto top;
  }
  case TAG_RPeek: {
    V v_r_24104 = heff_field(v_x2_240, 0);
    V v_e_24105 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RPeek = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_24106 = heff_tag_at_n(v_ru_24x2_240_24RPeek, TAG_RPeek, 2, (V[]){v_r_24104, heff_hole()});
    V v_u_24107 = heff_setField(v_d_241, v_i_242, heff_dup(v_cell_24106));
    heff_drop(v_u_24107);
    V t_0 = v_e_24105;
    V t_1 = v_cell_24106;
    V t_2 = MK_INT(1LL);
    v_x2_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    goto top;
  }
  case TAG_RPrimU: {
    V v_p_24108 = heff_field(v_x2_240, 0);
    V v_es_24109 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_24110 = (g_list_2emap_24s1354671438x1264137843(v_es_24109));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RPrimU, 2, (V[]){v_p_24108, v_t_24110}));
  }
  case TAG_RPrimAt: {
    V v_p_24111 = heff_field(v_x2_240, 0);
    V v_r_24112 = heff_field(v_x2_240, 1);
    V v_es_24113 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_24114 = (g_list_2emap_24s1354671438x1264137843(v_es_24113));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RPrimAt, 3, (V[]){v_p_24111, v_r_24112, v_t_24114}));
  }
  case TAG_RFixU: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RF32U: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RF64U: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_entry, 1, 0};

V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_RLocal: {
    return v_x2_240;
  }
  case TAG_RDup: {
    return v_x2_240;
  }
  case TAG_RClo: {
    return v_x2_240;
  }
  case TAG_RGet: {
    return v_x2_240;
  }
  case TAG_RGetRaw: {
    return v_x2_240;
  }
  case TAG_RInt: {
    return v_x2_240;
  }
  case TAG_RFloat: {
    return v_x2_240;
  }
  case TAG_RStr: {
    return v_x2_240;
  }
  case TAG_RBytes: {
    return v_x2_240;
  }
  case TAG_RFixed: {
    return v_x2_240;
  }
  case TAG_RF32: {
    return v_x2_240;
  }
  case TAG_RNTag: {
    return v_x2_240;
  }
  case TAG_RTag: {
    V v_t_2414 = heff_field(v_x2_240, 0);
    V v_b_2415 = heff_field(v_x2_240, 1);
    V v_es_2416 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24RTag = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2417 = (g_list_2emap_24s391650521x1406868658(v_es_2416));
    return heff_tag_at_n(v_ru_24x2_240_24RTag, TAG_RTag, 3, (V[]){v_t_2414, v_b_2415, v_t_2417});
  }
  case TAG_RTagIn: {
    V v_e_2418 = heff_field(v_x2_240, 0);
    V v_t_2419 = heff_field(v_x2_240, 1);
    V v_b_2420 = heff_field(v_x2_240, 2);
    V v_es_2421 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24RTagIn = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2422 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2418));
    V v_t_2423 = (g_list_2emap_24s391650521x1406868658(v_es_2421));
    return heff_tag_at_n(v_ru_24x2_240_24RTagIn, TAG_RTagIn, 4, (V[]){v_t_2422, v_t_2419, v_b_2420, v_t_2423});
  }
  case TAG_RRec: {
    V v_ls_2424 = heff_field(v_x2_240, 0);
    V v_b_2425 = heff_field(v_x2_240, 1);
    V v_es_2426 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24RRec = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2427 = (g_list_2emap_24s391650521x1406868658(v_es_2426));
    return heff_tag_at_n(v_ru_24x2_240_24RRec, TAG_RRec, 3, (V[]){v_ls_2424, v_b_2425, v_t_2427});
  }
  case TAG_RRecIn: {
    V v_x_2428 = heff_field(v_x2_240, 0);
    V v_n_2429 = heff_field(v_x2_240, 1);
    V v_k_2430 = heff_field(v_x2_240, 2);
    V v_f_2431 = heff_field(v_x2_240, 3);
    V v_s_2432 = heff_field(v_x2_240, 4);
    V v_ls_2433 = heff_field(v_x2_240, 5);
    V v_fs_2434 = heff_field(v_x2_240, 6);
    V v_sure_2435 = heff_field(v_x2_240, 7);
    V v_ru_24x2_240_24RRecIn = heff_take_reuse_n(v_x2_240, 255ULL, 8);
    V v_t_2436 = (g_list_2emap_24s1429062098x1340918317(v_fs_2434));
    return heff_tag_at_n(v_ru_24x2_240_24RRecIn, TAG_RRecIn, 8, (V[]){v_x_2428, v_n_2429, v_k_2430, v_f_2431, v_s_2432, v_ls_2433, v_t_2436, v_sure_2435});
  }
  case TAG_RField: {
    V v_e_2437 = heff_field(v_x2_240, 0);
    V v_i_2438 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RField = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2439 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2437));
    return heff_tag_at_n(v_ru_24x2_240_24RField, TAG_RField, 2, (V[]){v_t_2439, v_i_2438});
  }
  case TAG_RDupE: {
    V v_e_2440 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24RDupE = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_cell_2441 = heff_tag_at_n(v_ru_24x2_240_24RDupE, TAG_RDupE, 1, (V[]){heff_hole()});
    V v_u_2442 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_24dps(v_e_2440, heff_dup(v_cell_2441), MK_INT(0LL)));
    heff_drop(v_u_2442);
    return v_cell_2441;
  }
  case TAG_RFieldV: {
    V v_e_2443 = heff_field(v_x2_240, 0);
    V v_i_2444 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RFieldV = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2445 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2443));
    return heff_tag_at_n(v_ru_24x2_240_24RFieldV, TAG_RFieldV, 2, (V[]){v_t_2445, v_i_2444});
  }
  case TAG_RGetN: {
    V v_e_2446 = heff_field(v_x2_240, 0);
    V v_i_2447 = heff_field(v_x2_240, 1);
    V v_n_2448 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24RGetN = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2449 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2446));
    return heff_tag_at_n(v_ru_24x2_240_24RGetN, TAG_RGetN, 3, (V[]){v_t_2449, v_i_2447, v_n_2448});
  }
  case TAG_RFieldU: {
    V v_r_2450 = heff_field(v_x2_240, 0);
    V v_s_2451 = heff_field(v_x2_240, 1);
    V v_e_2452 = heff_field(v_x2_240, 2);
    V v_i_2453 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24RFieldU = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2454 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2452));
    return heff_tag_at_n(v_ru_24x2_240_24RFieldU, TAG_RFieldU, 4, (V[]){v_r_2450, v_s_2451, v_t_2454, v_i_2453});
  }
  case TAG_RGetNU: {
    V v_r_2455 = heff_field(v_x2_240, 0);
    V v_s_2456 = heff_field(v_x2_240, 1);
    V v_e_2457 = heff_field(v_x2_240, 2);
    V v_i_2458 = heff_field(v_x2_240, 3);
    V v_n_2459 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24RGetNU = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_2460 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2457));
    return heff_tag_at_n(v_ru_24x2_240_24RGetNU, TAG_RGetNU, 5, (V[]){v_r_2455, v_s_2456, v_t_2460, v_i_2458, v_n_2459});
  }
  case TAG_RWord: {
    V v_r_2461 = heff_field(v_x2_240, 0);
    V v_e_2462 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RWord = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2463 = heff_tag_at_n(v_ru_24x2_240_24RWord, TAG_RWord, 2, (V[]){v_r_2461, heff_hole()});
    V v_u_2464 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_24dps(v_e_2462, heff_dup(v_cell_2463), MK_INT(1LL)));
    heff_drop(v_u_2464);
    return v_cell_2463;
  }
  case TAG_RTakeField: {
    return v_x2_240;
  }
  case TAG_RGetLabel: {
    V v_e_2467 = heff_field(v_x2_240, 0);
    V v_l_2468 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RGetLabel = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2469 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2467));
    return heff_tag_at_n(v_ru_24x2_240_24RGetLabel, TAG_RGetLabel, 2, (V[]){v_t_2469, v_l_2468});
  }
  case TAG_RPrimFn: {
    return v_x2_240;
  }
  case TAG_RPrim: {
    V v_p_2471 = heff_field(v_x2_240, 0);
    V v_es_2472 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RPrim = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2473 = (g_list_2emap_24s391650521x1406868658(v_es_2472));
    return (g_heff_2ecompile_2egenerate_2eflatPrim_24tok2(v_ru_24x2_240_24RPrim, v_p_2471, v_t_2473));
  }
  case TAG_RLam: {
    V v_xs_2474 = heff_field(v_x2_240, 0);
    V v_fv_2475 = heff_field(v_x2_240, 1);
    V v_held_2476 = heff_field(v_x2_240, 2);
    V v_x24_2477 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24RLam = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    switch (heff_tag_of(v_x24_2477)) {
    case TAG_MkCode: {
      V v_body_2478 = heff_field(v_x24_2477, 0);
      V v_ru_24x24_2477_24MkCode = heff_take_reuse_n(v_x24_2477, 1ULL, 1);
      V v_t_2479 = (g_list_2emap_24s391650521x1406868658(v_held_2476));
      V v_t_2480 = (g_list_2emap_24s1478286876x830244177(v_body_2478));
      return heff_tag_at_n(v_ru_24x2_240_24RLam, TAG_RLam, 4, (V[]){v_xs_2474, v_fv_2475, v_t_2479, heff_tag_at_n(v_ru_24x24_2477_24MkCode, TAG_MkCode, 1, (V[]){v_t_2480})});
    }
    default: return heff_nomatch(v_x24_2477);
    }
  }
  case TAG_RCall: {
    V v_g_2481 = heff_field(v_x2_240, 0);
    V v_tr_2482 = heff_field(v_x2_240, 1);
    V v_w_2483 = heff_field(v_x2_240, 2);
    V v_args_2484 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24RCall = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2485 = (g_list_2emap_24s784191759x2032889081(v_args_2484));
    return heff_tag_at_n(v_ru_24x2_240_24RCall, TAG_RCall, 4, (V[]){v_g_2481, v_tr_2482, v_w_2483, v_t_2485});
  }
  case TAG_RApply: {
    V v_f_2486 = heff_field(v_x2_240, 0);
    V v_es_2487 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RApply = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2488 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_f_2486));
    V v_t_2489 = (g_list_2emap_24s391650521x1406868658(v_es_2487));
    return heff_tag_at_n(v_ru_24x2_240_24RApply, TAG_RApply, 2, (V[]){v_t_2488, v_t_2489});
  }
  case TAG_RBool: {
    V v_c_2490 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24RBool = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2491 = (g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837(v_c_2490));
    return heff_tag_at_n(v_ru_24x2_240_24RBool, TAG_RBool, 1, (V[]){v_t_2491});
  }
  case TAG_RAbandon: {
    return v_x2_240;
  }
  case TAG_RBox: {
    V v_r_2492 = heff_field(v_x2_240, 0);
    V v_e_2493 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RBox = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2494 = heff_tag_at_n(v_ru_24x2_240_24RBox, TAG_RBox, 2, (V[]){v_r_2492, heff_hole()});
    V v_u_2495 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_24dps(v_e_2493, heff_dup(v_cell_2494), MK_INT(1LL)));
    heff_drop(v_u_2495);
    return v_cell_2494;
  }
  case TAG_RUnbox: {
    V v_r_2496 = heff_field(v_x2_240, 0);
    V v_e_2497 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RUnbox = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2498 = heff_tag_at_n(v_ru_24x2_240_24RUnbox, TAG_RUnbox, 2, (V[]){v_r_2496, heff_hole()});
    V v_u_2499 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_24dps(v_e_2497, heff_dup(v_cell_2498), MK_INT(1LL)));
    heff_drop(v_u_2499);
    return v_cell_2498;
  }
  case TAG_RPeek: {
    V v_r_24100 = heff_field(v_x2_240, 0);
    V v_e_24101 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RPeek = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_24102 = heff_tag_at_n(v_ru_24x2_240_24RPeek, TAG_RPeek, 2, (V[]){v_r_24100, heff_hole()});
    V v_u_24103 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_24dps(v_e_24101, heff_dup(v_cell_24102), MK_INT(1LL)));
    heff_drop(v_u_24103);
    return v_cell_24102;
  }
  case TAG_RPrimU: {
    V v_p_24104 = heff_field(v_x2_240, 0);
    V v_es_24105 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RPrimU = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_24106 = (g_list_2emap_24s391650521x1406868658(v_es_24105));
    return heff_tag_at_n(v_ru_24x2_240_24RPrimU, TAG_RPrimU, 2, (V[]){v_p_24104, v_t_24106});
  }
  case TAG_RPrimAt: {
    V v_p_24107 = heff_field(v_x2_240, 0);
    V v_r_24108 = heff_field(v_x2_240, 1);
    V v_es_24109 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24RPrimAt = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_24110 = (g_list_2emap_24s391650521x1406868658(v_es_24109));
    return heff_tag_at_n(v_ru_24x2_240_24RPrimAt, TAG_RPrimAt, 3, (V[]){v_p_24107, v_r_24108, v_t_24110});
  }
  case TAG_RFixU: {
    return v_x2_240;
  }
  case TAG_RF32U: {
    return v_x2_240;
  }
  case TAG_RF64U: {
    return v_x2_240;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(a[0]);
}
Clo g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_24dps_entry, 3, 0};

V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_24dps(V v_x2_240, V v_d_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_RLocal: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RDup: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RClo: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RGet: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RGetRaw: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RInt: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RFloat: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RStr: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RBytes: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RFixed: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RF32: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RNTag: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RTag: {
    V v_t_2416 = heff_field(v_x2_240, 0);
    V v_b_2417 = heff_field(v_x2_240, 1);
    V v_es_2418 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2419 = (g_list_2emap_24s391650521x1406868658(v_es_2418));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RTag, 3, (V[]){v_t_2416, v_b_2417, v_t_2419}));
  }
  case TAG_RTagIn: {
    V v_e_2420 = heff_field(v_x2_240, 0);
    V v_t_2421 = heff_field(v_x2_240, 1);
    V v_b_2422 = heff_field(v_x2_240, 2);
    V v_es_2423 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_t_2424 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2420));
    V v_t_2425 = (g_list_2emap_24s391650521x1406868658(v_es_2423));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RTagIn, 4, (V[]){v_t_2424, v_t_2421, v_b_2422, v_t_2425}));
  }
  case TAG_RRec: {
    V v_ls_2426 = heff_field(v_x2_240, 0);
    V v_b_2427 = heff_field(v_x2_240, 1);
    V v_es_2428 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2429 = (g_list_2emap_24s391650521x1406868658(v_es_2428));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RRec, 3, (V[]){v_ls_2426, v_b_2427, v_t_2429}));
  }
  case TAG_RRecIn: {
    V v_x_2430 = heff_field(v_x2_240, 0);
    V v_n_2431 = heff_field(v_x2_240, 1);
    V v_k_2432 = heff_field(v_x2_240, 2);
    V v_f_2433 = heff_field(v_x2_240, 3);
    V v_s_2434 = heff_field(v_x2_240, 4);
    V v_ls_2435 = heff_field(v_x2_240, 5);
    V v_fs_2436 = heff_field(v_x2_240, 6);
    V v_sure_2437 = heff_field(v_x2_240, 7);
    heff_take_n(v_x2_240, 255ULL, 8);
    V v_t_2438 = (g_list_2emap_24s1429062098x1340918317(v_fs_2436));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RRecIn, 8, (V[]){v_x_2430, v_n_2431, v_k_2432, v_f_2433, v_s_2434, v_ls_2435, v_t_2438, v_sure_2437}));
  }
  case TAG_RField: {
    V v_e_2439 = heff_field(v_x2_240, 0);
    V v_i_2440 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_2441 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2439));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RField, 2, (V[]){v_t_2441, v_i_2440}));
  }
  case TAG_RDupE: {
    V v_e_2442 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24RDupE = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_cell_2443 = heff_tag_at_n(v_ru_24x2_240_24RDupE, TAG_RDupE, 1, (V[]){heff_hole()});
    V v_u_2444 = heff_setField(v_d_241, v_i_242, heff_dup(v_cell_2443));
    heff_drop(v_u_2444);
    V t_0 = v_e_2442;
    V t_1 = v_cell_2443;
    V t_2 = MK_INT(0LL);
    v_x2_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    goto top;
  }
  case TAG_RFieldV: {
    V v_e_2445 = heff_field(v_x2_240, 0);
    V v_i_2446 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_2447 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2445));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RFieldV, 2, (V[]){v_t_2447, v_i_2446}));
  }
  case TAG_RGetN: {
    V v_e_2448 = heff_field(v_x2_240, 0);
    V v_i_2449 = heff_field(v_x2_240, 1);
    V v_n_2450 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_2451 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2448));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RGetN, 3, (V[]){v_t_2451, v_i_2449, v_n_2450}));
  }
  case TAG_RFieldU: {
    V v_r_2452 = heff_field(v_x2_240, 0);
    V v_s_2453 = heff_field(v_x2_240, 1);
    V v_e_2454 = heff_field(v_x2_240, 2);
    V v_i_2455 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_t_2456 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2454));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RFieldU, 4, (V[]){v_r_2452, v_s_2453, v_t_2456, v_i_2455}));
  }
  case TAG_RGetNU: {
    V v_r_2457 = heff_field(v_x2_240, 0);
    V v_s_2458 = heff_field(v_x2_240, 1);
    V v_e_2459 = heff_field(v_x2_240, 2);
    V v_i_2460 = heff_field(v_x2_240, 3);
    V v_n_2461 = heff_field(v_x2_240, 4);
    heff_take_n(v_x2_240, 31ULL, 5);
    V v_t_2462 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2459));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RGetNU, 5, (V[]){v_r_2457, v_s_2458, v_t_2462, v_i_2460, v_n_2461}));
  }
  case TAG_RWord: {
    V v_r_2463 = heff_field(v_x2_240, 0);
    V v_e_2464 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RWord = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2465 = heff_tag_at_n(v_ru_24x2_240_24RWord, TAG_RWord, 2, (V[]){v_r_2463, heff_hole()});
    V v_u_2466 = heff_setField(v_d_241, v_i_242, heff_dup(v_cell_2465));
    heff_drop(v_u_2466);
    V t_0 = v_e_2464;
    V t_1 = v_cell_2465;
    V t_2 = MK_INT(1LL);
    v_x2_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    goto top;
  }
  case TAG_RTakeField: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RGetLabel: {
    V v_e_2469 = heff_field(v_x2_240, 0);
    V v_l_2470 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_2471 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_e_2469));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RGetLabel, 2, (V[]){v_t_2471, v_l_2470}));
  }
  case TAG_RPrimFn: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RPrim: {
    V v_p_2473 = heff_field(v_x2_240, 0);
    V v_es_2474 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RPrim = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2475 = (g_list_2emap_24s391650521x1406868658(v_es_2474));
    V v_t_2476 = (g_heff_2ecompile_2egenerate_2eflatPrim_24tok2(v_ru_24x2_240_24RPrim, v_p_2473, v_t_2475));
    return heff_setField(v_d_241, v_i_242, v_t_2476);
  }
  case TAG_RLam: {
    V v_xs_2477 = heff_field(v_x2_240, 0);
    V v_fv_2478 = heff_field(v_x2_240, 1);
    V v_held_2479 = heff_field(v_x2_240, 2);
    V v_x24_2480 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24RLam = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    switch (heff_tag_of(v_x24_2480)) {
    case TAG_MkCode: {
      V v_body_2481 = heff_field(v_x24_2480, 0);
      V v_ru_24x24_2480_24MkCode = heff_take_reuse_n(v_x24_2480, 1ULL, 1);
      V v_t_2482 = (g_list_2emap_24s391650521x1406868658(v_held_2479));
      V v_t_2483 = (g_list_2emap_24s1478286876x830244177(v_body_2481));
      V v_t_2484 = heff_tag_at_n(v_ru_24x2_240_24RLam, TAG_RLam, 4, (V[]){v_xs_2477, v_fv_2478, v_t_2482, heff_tag_at_n(v_ru_24x24_2480_24MkCode, TAG_MkCode, 1, (V[]){v_t_2483})});
      return heff_setField(v_d_241, v_i_242, v_t_2484);
    }
    default: return heff_nomatch(v_x24_2480);
    }
  }
  case TAG_RCall: {
    V v_g_2485 = heff_field(v_x2_240, 0);
    V v_tr_2486 = heff_field(v_x2_240, 1);
    V v_w_2487 = heff_field(v_x2_240, 2);
    V v_args_2488 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 15ULL, 4);
    V v_t_2489 = (g_list_2emap_24s784191759x2032889081(v_args_2488));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RCall, 4, (V[]){v_g_2485, v_tr_2486, v_w_2487, v_t_2489}));
  }
  case TAG_RApply: {
    V v_f_2490 = heff_field(v_x2_240, 0);
    V v_es_2491 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_2492 = (g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494(v_f_2490));
    V v_t_2493 = (g_list_2emap_24s391650521x1406868658(v_es_2491));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RApply, 2, (V[]){v_t_2492, v_t_2493}));
  }
  case TAG_RBool: {
    V v_c_2494 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_t_2495 = (g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837(v_c_2494));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RBool, 1, (V[]){v_t_2495}));
  }
  case TAG_RAbandon: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RBox: {
    V v_r_2496 = heff_field(v_x2_240, 0);
    V v_e_2497 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RBox = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_2498 = heff_tag_at_n(v_ru_24x2_240_24RBox, TAG_RBox, 2, (V[]){v_r_2496, heff_hole()});
    V v_u_2499 = heff_setField(v_d_241, v_i_242, heff_dup(v_cell_2498));
    heff_drop(v_u_2499);
    V t_0 = v_e_2497;
    V t_1 = v_cell_2498;
    V t_2 = MK_INT(1LL);
    v_x2_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    goto top;
  }
  case TAG_RUnbox: {
    V v_r_24100 = heff_field(v_x2_240, 0);
    V v_e_24101 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RUnbox = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_24102 = heff_tag_at_n(v_ru_24x2_240_24RUnbox, TAG_RUnbox, 2, (V[]){v_r_24100, heff_hole()});
    V v_u_24103 = heff_setField(v_d_241, v_i_242, heff_dup(v_cell_24102));
    heff_drop(v_u_24103);
    V t_0 = v_e_24101;
    V t_1 = v_cell_24102;
    V t_2 = MK_INT(1LL);
    v_x2_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    goto top;
  }
  case TAG_RPeek: {
    V v_r_24104 = heff_field(v_x2_240, 0);
    V v_e_24105 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24RPeek = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_24106 = heff_tag_at_n(v_ru_24x2_240_24RPeek, TAG_RPeek, 2, (V[]){v_r_24104, heff_hole()});
    V v_u_24107 = heff_setField(v_d_241, v_i_242, heff_dup(v_cell_24106));
    heff_drop(v_u_24107);
    V t_0 = v_e_24105;
    V t_1 = v_cell_24106;
    V t_2 = MK_INT(1LL);
    v_x2_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    goto top;
  }
  case TAG_RPrimU: {
    V v_p_24108 = heff_field(v_x2_240, 0);
    V v_es_24109 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_24110 = (g_list_2emap_24s391650521x1406868658(v_es_24109));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RPrimU, 2, (V[]){v_p_24108, v_t_24110}));
  }
  case TAG_RPrimAt: {
    V v_p_24111 = heff_field(v_x2_240, 0);
    V v_r_24112 = heff_field(v_x2_240, 1);
    V v_es_24113 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 7ULL, 3);
    V v_t_24114 = (g_list_2emap_24s391650521x1406868658(v_es_24113));
    return heff_setField(v_d_241, v_i_242, heff_tag_n(TAG_RPrimAt, 3, (V[]){v_p_24111, v_r_24112, v_t_24114}));
  }
  case TAG_RFixU: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RF32U: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  case TAG_RF64U: {
    return heff_setField(v_d_241, v_i_242, v_x2_240);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2egenerate_2egenExp_24s2103550560x1916382494_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603_entry, 1, 0};

V g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603(V v_s_240) {
top: ;
  switch (heff_tag_of(v_s_240)) {
  case TAG_CDrop: {
    return v_s_240;
  }
  case TAG_CLet: {
    V v_x_242 = heff_field(v_s_240, 0);
    V v_e_243 = heff_field(v_s_240, 1);
    V v_ru_24s_240_24CLet = heff_take_reuse_n(v_s_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_243));
    return heff_tag_at_n(v_ru_24s_240_24CLet, TAG_CLet, 2, (V[]){v_x_242, v_t_244});
  }
  case TAG_CDecl: {
    return v_s_240;
  }
  case TAG_CSet: {
    V v_x_246 = heff_field(v_s_240, 0);
    V v_e_247 = heff_field(v_s_240, 1);
    V v_ru_24s_240_24CSet = heff_take_reuse_n(v_s_240, 3ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_247));
    return heff_tag_at_n(v_ru_24s_240_24CSet, TAG_CSet, 2, (V[]){v_x_246, v_t_248});
  }
  case TAG_CAbandon: {
    return v_s_240;
  }
  case TAG_CIf: {
    V v_c_249 = heff_field(v_s_240, 0);
    V v_a_2410 = heff_field(v_s_240, 1);
    V v_b_2411 = heff_field(v_s_240, 2);
    V v_ru_24s_240_24CIf = heff_take_reuse_n(v_s_240, 7ULL, 3);
    V v_t_2412 = (g_heff_2ecompile_2eowned_2emapCond_24s1015473648x1953689837(v_c_249));
    V v_t_2413 = (g_list_2emap_24s1478286876x830244177(v_a_2410));
    V v_t_2414 = (g_list_2emap_24s1478286876x830244177(v_b_2411));
    return heff_tag_at_n(v_ru_24s_240_24CIf, TAG_CIf, 3, (V[]){v_t_2412, v_t_2413, v_t_2414});
  }
  case TAG_CSwitch: {
    V v_e_2415 = heff_field(v_s_240, 0);
    V v_arms_2416 = heff_field(v_s_240, 1);
    V v_r_2417 = heff_field(v_s_240, 2);
    V v_ru_24s_240_24CSwitch = heff_take_reuse_n(v_s_240, 7ULL, 3);
    V v_t_2418 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2415));
    V v_t_2419 = (g_list_2emap_24s537124232x94423304(v_arms_2416));
    return heff_tag_at_n(v_ru_24s_240_24CSwitch, TAG_CSwitch, 3, (V[]){v_t_2418, v_t_2419, v_r_2417});
  }
  case TAG_CReturn: {
    V v_e_2420 = heff_field(v_s_240, 0);
    V v_ru_24s_240_24CReturn = heff_take_reuse_n(v_s_240, 1ULL, 1);
    V v_t_2421 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_e_2420));
    return heff_tag_at_n(v_ru_24s_240_24CReturn, TAG_CReturn, 1, (V[]){v_t_2421});
  }
  case TAG_CInPlace: {
    V v_f_2422 = heff_field(v_s_240, 0);
    V v_es_2423 = heff_field(v_s_240, 1);
    V v_ru_24s_240_24CInPlace = heff_take_reuse_n(v_s_240, 3ULL, 2);
    V v_t_2424 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_f_2422));
    V v_t_2425 = (g_list_2emap_24s391650521x1406868658(v_es_2423));
    return heff_tag_at_n(v_ru_24s_240_24CInPlace, TAG_CInPlace, 2, (V[]){v_t_2424, v_t_2425});
  }
  case TAG_CRoomed: {
    V v_f_2426 = heff_field(v_s_240, 0);
    V v_es_2427 = heff_field(v_s_240, 1);
    V v_ru_24s_240_24CRoomed = heff_take_reuse_n(v_s_240, 3ULL, 2);
    V v_t_2428 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_f_2426));
    V v_t_2429 = (g_list_2emap_24s391650521x1406868658(v_es_2427));
    return heff_tag_at_n(v_ru_24s_240_24CRoomed, TAG_CRoomed, 2, (V[]){v_t_2428, v_t_2429});
  }
  case TAG_CTail: {
    V v_f_2430 = heff_field(v_s_240, 0);
    V v_es_2431 = heff_field(v_s_240, 1);
    V v_ru_24s_240_24CTail = heff_take_reuse_n(v_s_240, 3ULL, 2);
    V v_t_2432 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_f_2430));
    V v_t_2433 = (g_list_2emap_24s391650521x1406868658(v_es_2431));
    return heff_tag_at_n(v_ru_24s_240_24CTail, TAG_CTail, 2, (V[]){v_t_2432, v_t_2433});
  }
  case TAG_CLoop: {
    V v_ps_2434 = heff_field(v_s_240, 0);
    V v_es_2435 = heff_field(v_s_240, 1);
    V v_ru_24s_240_24CLoop = heff_take_reuse_n(v_s_240, 3ULL, 2);
    V v_t_2436 = (g_list_2emap_24s391650521x1406868658(v_es_2435));
    return heff_tag_at_n(v_ru_24s_240_24CLoop, TAG_CLoop, 2, (V[]){v_ps_2434, v_t_2436});
  }
  case TAG_CLoopTo: {
    V v_t_2437 = heff_field(v_s_240, 0);
    V v_ps_2438 = heff_field(v_s_240, 1);
    V v_es_2439 = heff_field(v_s_240, 2);
    V v_ru_24s_240_24CLoopTo = heff_take_reuse_n(v_s_240, 7ULL, 3);
    V v_t_2440 = (g_list_2emap_24s391650521x1406868658(v_es_2439));
    return heff_tag_at_n(v_ru_24s_240_24CLoopTo, TAG_CLoopTo, 3, (V[]){v_t_2437, v_ps_2438, v_t_2440});
  }
  case TAG_CLabel: {
    return v_s_240;
  }
  case TAG_CJump: {
    V v_g_2442 = heff_field(v_s_240, 0);
    V v_w_2443 = heff_field(v_s_240, 1);
    V v_es_2444 = heff_field(v_s_240, 2);
    V v_ru_24s_240_24CJump = heff_take_reuse_n(v_s_240, 7ULL, 3);
    V v_t_2445 = (g_list_2emap_24s391650521x1406868658(v_es_2444));
    return heff_tag_at_n(v_ru_24s_240_24CJump, TAG_CJump, 3, (V[]){v_g_2442, v_w_2443, v_t_2445});
  }
  default: return heff_nomatch(v_s_240);
  }
}
V g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2egenerate_2egenSt_24s2087455469x113671603(a[0]);
}
V g_heff_2ecompile_2egenerate_2eflatPrim_24tok2_lam0(V self, V *args);
Clo g_heff_2ecompile_2egenerate_2eflatPrim_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2egenerate_2eflatPrim_24tok2_entry, 3, 0};

V g_heff_2ecompile_2egenerate_2eflatPrim_24tok2(V v_tok_240, V v_p_241, V v_es_242) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_ArrayGenerate: {
    switch (heff_tag_of(v_es_242)) {
    case TAG_Nil: {
      return heff_tag_at_n(v_tok_240, TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayGenerate), v_es_242});
    }
    case TAG_Cons: {
      V v_es2_244 = heff_dup(heff_field(v_es_242, 1));
      switch (heff_tag_of(v_es2_244)) {
      case TAG_Nil: {
        return heff_tag_at_n(v_tok_240, TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayGenerate), v_es_242});
      }
      case TAG_Cons: {
        V v_f_245 = heff_field(v_es2_244, 0);
        V v_es22_246 = heff_field(v_es2_244, 1);
        heff_take_n(v_es2_244, 3ULL, 2);
        switch (heff_tag_of(v_es22_246)) {
        case TAG_Nil: {
          V v_e_247 = v_f_245;
          V v_x3_2499;
          switch (heff_tag_of(v_e_247)) {
          case TAG_RLocal: {
            heff_take_n(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RDup: {
            heff_take_n(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RClo: {
            heff_take_n(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGet: {
            heff_take_n(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetRaw: {
            heff_take_n(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RInt: {
            heff_take_n(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFloat: {
            heff_take_na(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RStr: {
            heff_take_n(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RBytes: {
            heff_take_n(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFixed: {
            heff_take_n(v_e_247, 0ULL, 2);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RF32: {
            heff_take_na(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RNTag: {
            heff_take_n(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RTag: {
            heff_take_n(v_e_247, 0ULL, 3);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RTagIn: {
            heff_take_n(v_e_247, 0ULL, 4);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RRec: {
            heff_take_n(v_e_247, 0ULL, 3);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RRecIn: {
            heff_take_n(v_e_247, 0ULL, 8);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RField: {
            heff_take_n(v_e_247, 0ULL, 2);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RDupE: {
            heff_take_n(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFieldV: {
            heff_take_n(v_e_247, 0ULL, 2);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetN: {
            heff_take_n(v_e_247, 0ULL, 3);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFieldU: {
            heff_take_n(v_e_247, 0ULL, 4);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetNU: {
            heff_take_n(v_e_247, 0ULL, 5);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RWord: {
            heff_take_n(v_e_247, 0ULL, 2);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RTakeField: {
            heff_take_n(v_e_247, 0ULL, 2);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RGetLabel: {
            heff_take_n(v_e_247, 0ULL, 2);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrimFn: {
            heff_take_n(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrim: {
            heff_take_n(v_e_247, 0ULL, 2);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RLam: {
            V v_e4_2468 = heff_field(v_e_247, 3);
            heff_take_n(v_e_247, 8ULL, 4);
            switch (heff_tag_of(v_e4_2468)) {
            case TAG_MkCode: {
              V v_body_2469 = heff_field(v_e4_2468, 0);
              V v_ru_24e4_2468_24MkCode = heff_take_reuse_n(v_e4_2468, 1ULL, 1);
              V v_rs_2470 = (g_list_2efoldl_24s366449469x130665619(NTAG(TAG_Nil), v_body_2469));
              switch (heff_tag_of(v_rs_2470)) {
              case TAG_Nil: {
                heff_drop_cell(v_ru_24e4_2468_24MkCode, 1);
                v_x3_2499 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Cons: {
                V v_rs1_2471 = heff_field(v_rs_2470, 0);
                V v_rest_2472 = heff_field(v_rs_2470, 1);
                heff_take_n(v_rs_2470, 3ULL, 2);
                switch (heff_tag_of(v_rs1_2471)) {
                case TAG_Nothing: {
                  heff_drop_cell(v_ru_24e4_2468_24MkCode, 1);
                  heff_drop(v_rest_2472);
                  v_x3_2499 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Just: {
                  V v_r_2473 = heff_field(v_rs1_2471, 0);
                  heff_take_n(v_rs1_2471, 1ULL, 1);
                  V v_t_2476 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2egenerate_2eflatPrim_24tok2_lam0, 1, 1, (V[]){heff_dup(v_r_2473)}); V a_1 = v_rest_2472; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_rest_2472); r_; });
                  if ((heff_dup(v_t_2476) == NTAG(TAG_True))) {
                    heff_drop(v_t_2476);
                    v_x3_2499 = heff_tag_at_n(v_ru_24e4_2468_24MkCode, TAG_Just, 1, (V[]){v_r_2473});
                  } else {
                    heff_drop_cell(v_ru_24e4_2468_24MkCode, 1);
                    heff_drop(v_r_2473);
                    heff_drop(v_t_2476);
                    v_x3_2499 = NTAG(TAG_Nothing);
                  }
                  break;
                }
                default: heff_nomatch(v_rs1_2471);
                }
                break;
              }
              default: heff_nomatch(v_rs_2470);
              }
              break;
            }
            default: heff_nomatch(v_e4_2468);
            }
            break;
          }
          case TAG_RCall: {
            heff_take_n(v_e_247, 0ULL, 4);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RApply: {
            heff_take_n(v_e_247, 0ULL, 2);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RBool: {
            heff_take_n(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RAbandon: {
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RBox: {
            heff_take_n(v_e_247, 0ULL, 2);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RUnbox: {
            heff_take_n(v_e_247, 0ULL, 2);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPeek: {
            heff_take_n(v_e_247, 0ULL, 2);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrimU: {
            heff_take_n(v_e_247, 0ULL, 2);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RPrimAt: {
            heff_take_n(v_e_247, 0ULL, 3);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RFixU: {
            heff_take_n(v_e_247, 0ULL, 2);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RF32U: {
            heff_take_na(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_RF64U: {
            heff_take_na(v_e_247, 0ULL, 1);
            v_x3_2499 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_e_247);
          }
          switch (heff_tag_of(v_x3_2499)) {
          case TAG_Nothing: {
            return heff_tag_at_n(v_tok_240, TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayGenerate), v_es_242});
          }
          case TAG_Just: {
            V v_x_24100 = heff_field(v_x3_2499, 0);
            heff_take_n(v_x3_2499, 1ULL, 1);
            heff_drop_cell(v_tok_240, 2);
            return heff_tag_n(TAG_RPrimAt, 3, (V[]){NTAG(TAG_ArrayGenerate), v_x_24100, v_es_242});
          }
          default: return heff_nomatch(v_x3_2499);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_es22_246, 0ULL, 2);
          heff_drop(v_f_245);
          return heff_tag_at_n(v_tok_240, TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayGenerate), v_es_242});
        }
        default: return heff_nomatch(v_es22_246);
        }
      }
      default: return heff_nomatch(v_es2_244);
      }
    }
    default: return heff_nomatch(v_es_242);
    }
  }
  case TAG_ArrayKeepsAs: {
    V v_es_24103 = v_es_242;
    switch (heff_tag_of(v_es_24103)) {
    case TAG_Nil: {
      return heff_tag_at_n(v_tok_240, TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayKeepsAs), v_es_24103});
    }
    case TAG_Cons: {
      V v_a_24104 = heff_dup(heff_field(v_es_24103, 0));
      V v_es2_24105 = heff_dup(heff_field(v_es_24103, 1));
      switch (heff_tag_of(v_es2_24105)) {
      case TAG_Nil: {
        heff_drop(v_a_24104);
        return heff_tag_at_n(v_tok_240, TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayKeepsAs), v_es_24103});
      }
      case TAG_Cons: {
        V v_x_24106 = heff_field(v_es2_24105, 0);
        V v_es22_24107 = heff_field(v_es2_24105, 1);
        V v_ru_24es2_24105_24Cons = heff_take_reuse_n(v_es2_24105, 3ULL, 2);
        switch (heff_tag_of(v_es22_24107)) {
        case TAG_Nil: {
          heff_drop_tag(v_es_24103, 2);
          HeffT2 v_t_24108 = (g_heff_2ecompile_2egenerate_2eboxedPlain_24cpr(v_x_24106));
          {
            V v_field_24110 = v_t_24108.f[1];
            int64_t v_tag_24109 = ((int64_t)v_t_24108.f[0]);
            if ((v_tag_24109 == ((int64_t)0ULL))) {
              heff_drop(v_x_24106);
              heff_drop_cell(v_ru_24es2_24105_24Cons, 2);
              V v_x_24111 = v_field_24110;
              V v_t_24112 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_a_24104, NTAG(TAG_Nil)});
              return heff_tag_n(TAG_RPrimAt, 3, (V[]){NTAG(TAG_ArrayKeeps), v_x_24111, v_t_24112});
            } else {
              heff_drop(v_field_24110);
              V v_t_24113 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_24106, NTAG(TAG_Nil)});
              return heff_tag_n(TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayKeepsAs), heff_tag_at_n(v_ru_24es2_24105_24Cons, TAG_Cons, 2, (V[]){v_a_24104, v_t_24113})});
            }
          }
        }
        case TAG_Cons: {
          heff_take_n(v_es22_24107, 0ULL, 2);
          heff_drop(v_a_24104);
          heff_drop(v_x_24106);
          heff_drop_cell(v_ru_24es2_24105_24Cons, 2);
          return heff_tag_at_n(v_tok_240, TAG_RPrim, 2, (V[]){NTAG(TAG_ArrayKeepsAs), v_es_24103});
        }
        default: return heff_nomatch(v_es22_24107);
        }
      }
      default: return heff_nomatch(v_es2_24105);
      }
    }
    default: return heff_nomatch(v_es_24103);
    }
  }
  default: {
    return heff_tag_at_n(v_tok_240, TAG_RPrim, 2, (V[]){v_p_241, v_es_242});
  }
  }
}
V g_heff_2ecompile_2egenerate_2eflatPrim_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2egenerate_2eflatPrim_24tok2(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2egenerate_2eflatPrim_24tok2_lam0(V self, V *args) {
  V v_x2_2474 = args[0];
  V v_r_2473 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2474)) {
  case TAG_Nothing: {
    heff_drop(v_r_2473);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_s_2475 = heff_field(v_x2_2474, 0);
    heff_take_n(v_x2_2474, 1ULL, 1);
    return ({ V a_0 = v_r_2473; V a_1 = v_s_2475; V r_ = (g_heff_2ecompile_2erepr_2ereprEq(a_0, a_1)); heff_drop(v_r_2473); heff_drop(v_s_2475); r_; });
  }
  default: return heff_nomatch(v_x2_2474);
  }
}