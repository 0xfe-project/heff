// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_CInf 46723
#define TAG_CLetIn 34208
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_ExplicitParam 63083
#define TAG_IApp 21275
#define TAG_IInt 28905
#define TAG_IPrim 59489
#define TAG_IVar 40993
#define TAG_ImplicitParam 51130
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_PAs 26446
#define TAG_PBin 33976
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define LBL_anys 9494734
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_bad 306815
#define LBL_bits 9519565
#define LBL_bound 295286168
#define LBL_chk 308000
#define LBL_end 310101
#define LBL_flags 298871457
#define LBL_go 10063
#define LBL_len 316559
#define LBL_msg 317947
#define LBL_order 307364712
#define LBL_pats 9928951
#define LBL_rhs 322423
#define LBL_row 322644
#define LBL_rows 10002080
#define LBL_scrutinee 73860976
#define LBL_size 10026184
#define LBL_sizes 310811820
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tag 324116
#define LBL_terms 311608737
#define LBL_tree 10063973
#define LBL_ty 10476
#define LBL_typ 324869
#define LBL_used 10094724
#define LBL_v 336
#define LBL_value 313331083
#define LBL_x 338
static uint32_t shape_arms__order__anys[] = {LBL_arms, LBL_order, LBL_anys};
static uint32_t shape_bits__terms[] = {LBL_bits, LBL_terms};
static uint32_t shape_go[] = {LBL_go};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_row__bad__rows[] = {LBL_row, LBL_bad, LBL_rows};
static uint32_t shape_scrutinee__tree[] = {LBL_scrutinee, LBL_tree};
static uint32_t shape_span__msg[] = {LBL_span, LBL_msg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_tag__arity__pats__span[] = {LBL_tag, LBL_arity, LBL_pats, LBL_span};
static uint32_t shape_v__bits__len__sizes__used__bound__span[] = {LBL_v, LBL_bits, LBL_len, LBL_sizes, LBL_used, LBL_bound, LBL_span};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eclauses_2eallC(V, V);
V g_heff_2eelab_2eclauses_2eallC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eallC_clo;
V g_heff_2eelab_2eclauses_2eandC(V, V, V);
V g_heff_2eelab_2eclauses_2eandC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eandC_clo;
V g_heff_2eelab_2eclauses_2eanyC(V, V);
V g_heff_2eelab_2eclauses_2eanyC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_clo;
V g_heff_2eelab_2eclauses_2eanyC_24s1724875606x1273504888(V, V);
V g_heff_2eelab_2eclauses_2eanyC_24s1724875606x1273504888_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_24s1724875606x1273504888_clo;
V g_heff_2eelab_2eclauses_2eanyC_24s1988114557x804372153(V, V);
V g_heff_2eelab_2eclauses_2eanyC_24s1988114557x804372153_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_24s1988114557x804372153_clo;
V g_heff_2eelab_2eclauses_2eanyIn(V, V, V);
V g_heff_2eelab_2eclauses_2eanyIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyIn_clo;
V g_heff_2eelab_2eclauses_2eappendC(V, V);
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_clo;
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_clo;
V g_heff_2eelab_2eclauses_2ebinBind(V);
V g_heff_2eelab_2eclauses_2ebinBind_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinBind_clo;
V g_heff_2eelab_2eclauses_2ebinBindGo(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ebinBindGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinBindGo_clo;
HeffT2 g_heff_2eelab_2eclauses_2ebinChecks_24cpr(V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2ebinaryOf_24s1676894398x132520022_24cpr(V, V, V, V, V, V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr(V, V, V, V, V, V, V, V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecaseTreeOf(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecaseTreeOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecaseTreeOf_clo;
V g_heff_2eelab_2eclauses_2ecatMaybesC(V);
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo;
V g_heff_2eelab_2eclauses_2ecolFrom(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecolFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolFrom_clo;
V g_heff_2eelab_2eclauses_2ecolNames(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecolNames_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolNames_clo;
V g_heff_2eelab_2eclauses_2ecolNames_24dps(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecolNames_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolNames_24dps_clo;
HeffT2 g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239_clo;
V g_heff_2eelab_2eclauses_2edropC(V, V);
V g_heff_2eelab_2eclauses_2edropC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropC_clo;
HeffT2 g_heff_2eelab_2eclauses_2efindTagLit_24cpr(V, V);
HeffT2 g_heff_2eelab_2eclauses_2eforC_24cpr(V, V);
V g_heff_2eelab_2eclauses_2efreshIn(V, V, V);
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efreshIn_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2eintRead(V, V, V, V);
V g_heff_2eelab_2eclauses_2eintRead_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eintRead_clo;
V g_heff_2eelab_2eclauses_2eintTest(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2eintTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eintTest_clo;
HeffT2 g_heff_2eelab_2eclauses_2elitChecks_24cpr(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2elitNo(V, V, V);
V g_heff_2eelab_2eclauses_2elitNo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitNo_clo;
V g_heff_2eelab_2eclauses_2elitNoOne(V, V, V, V);
V g_heff_2eelab_2eclauses_2elitNoOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitNoOne_clo;
V g_heff_2eelab_2eclauses_2elitYes(V, V, V, V);
V g_heff_2eelab_2eclauses_2elitYes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitYes_clo;
V g_heff_2eelab_2eclauses_2elitYesOne(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2elitYesOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitYesOne_clo;
V g_heff_2eelab_2eclauses_2emapWithIndexC(V, V, V);
V g_heff_2eelab_2eclauses_2emapWithIndexC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2emapWithIndexC_clo;
V g_heff_2eelab_2eclauses_2enameFits(V, V, V);
V g_heff_2eelab_2eclauses_2enameFits_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enameFits_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll(V, V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_clo;
HeffT2 g_heff_2eelab_2eclauses_2enoRecMix_24cpr(V, V);
HeffT2 g_heff_2eelab_2eclauses_2enthC_24cpr(V, V);
V g_heff_2eelab_2eclauses_2eoffC(V, V);
V g_heff_2eelab_2eclauses_2eoffC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eoffC_clo;
HeffT2 g_heff_2eelab_2eclauses_2epat_24cpr(V);
V g_heff_2eelab_2eclauses_2epatBinds(V);
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_clo;
V g_heff_2eelab_2eclauses_2epatBinds_24dps(V, V);
V g_heff_2eelab_2eclauses_2epatBinds_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_24dps_clo;
V g_heff_2eelab_2eclauses_2epatIdents(V, V);
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_clo;
V g_heff_2eelab_2eclauses_2epeelCols(V, V, V);
V g_heff_2eelab_2eclauses_2epeelCols_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epeelCols_clo;
V g_heff_2eelab_2eclauses_2erecFieldVar(V, V, V);
V g_heff_2eelab_2eclauses_2erecFieldVar_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecFieldVar_clo;
V g_heff_2eelab_2eclauses_2erecSpecialize(V, V, V, V);
V g_heff_2eelab_2eclauses_2erecSpecialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecSpecialize_clo;
V g_heff_2eelab_2eclauses_2erecSubName(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2erecSubName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecSubName_clo;
HeffT2 g_heff_2eelab_2eclauses_2erecordNamed_24s570125606x1378596115_24cpr(V, V, V, V, V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2erecordWith_24s2051940580x1889718143_24cpr(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2erenameDecl(V, V);
V g_heff_2eelab_2eclauses_2erenameDecl_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameDecl_clo;
V g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657(V, V, V);
V g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657_clo;
V g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207(V, V, V);
V g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207_clo;
V g_heff_2eelab_2eclauses_2erenamer(V, V);
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamer_clo;
V g_heff_2eelab_2eclauses_2eresolve(V, V);
V g_heff_2eelab_2eclauses_2eresolve_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eresolve_clo;
V g_heff_2eelab_2eclauses_2esameLit(V, V);
V g_heff_2eelab_2eclauses_2esameLit_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esameLit_clo;
V g_heff_2eelab_2eclauses_2esoleBin(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esoleBin_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esoleBin_clo;
V g_heff_2eelab_2eclauses_2etagArmStep(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etagArmStep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagArmStep_clo;
V g_heff_2eelab_2eclauses_2etagColAt(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etagColAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagColAt_clo;
V g_heff_2eelab_2eclauses_2etakeC(V, V);
V g_heff_2eelab_2eclauses_2etakeC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_clo;
V g_heff_2eelab_2eclauses_2etakeC_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2etakeC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_24dps_clo;
HeffT2 g_heff_2eelab_2eclauses_2etraverseC_24cpr(V, V);
HeffT2 g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_24cpr(V);
HeffT2 g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027_24cpr(V);
V g_heff_2eelab_2eclauses_2ewholeBin(V, V);
V g_heff_2eelab_2eclauses_2ewholeBin_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ewholeBin_clo;
HeffT2 g_heff_2eelab_2eclauses_2ewholeSeg_24cpr(V, V, V, V);
V g_heff_2eelab_2eclauses_2ewidthBy(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ewidthBy_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ewidthBy_clo;
V g_heff_2eelab_2eclauses_2ezipC_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2ezipC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ezipC_24dps_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(V, V);
V g_list_2eall_24s1297075057x1726753756(V, V);
V g_list_2eall_24s1297075057x1726753756_entry(V self, V *a);
extern Clo g_list_2eall_24s1297075057x1726753756_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1116296567x1614305171(V);
V g_list_2eany_24s1116296567x1614305171_entry(V self, V *a);
extern Clo g_list_2eany_24s1116296567x1614305171_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1134745827x519521524(V);
V g_list_2emap_24s1134745827x519521524_entry(V self, V *a);
extern Clo g_list_2emap_24s1134745827x519521524_clo;
V g_list_2emap_24s1230649048x711093514(V, V);
V g_list_2emap_24s1230649048x711093514_entry(V self, V *a);
extern Clo g_list_2emap_24s1230649048x711093514_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s502656580x1955732096(V);
V g_list_2emap_24s502656580x1955732096_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_clo;
V g_list_2emap_24s584558070x895760461(V, V);
V g_list_2emap_24s584558070x895760461_entry(V self, V *a);
extern Clo g_list_2emap_24s584558070x895760461_clo;
V g_list_2emap_24s886389550x1086668531(V);
V g_list_2emap_24s886389550x1086668531_entry(V self, V *a);
extern Clo g_list_2emap_24s886389550x1086668531_clo;
V g_list_2emap_24s939813003x1383013550(V);
V g_list_2emap_24s939813003x1383013550_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2emapValues(V, V);
V g_map_2emapValues_entry(V self, V *a);
extern Clo g_map_2emapValues_clo;

HeffT2 g_heff_2eelab_2eclauses_2etraverseC_24cpr(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x1_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Left: {
      V v_e_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_245}});
    }
    case TAG_Right: {
      V v_x_246 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      HeffT2 v_t_247 = (g_heff_2eelab_2eclauses_2etraverseC_24cpr(v_f_240, v_xs_243));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_x_246);
          V v_e_2411 = v_field_249;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2411}});
        } else {
          V v_x_2412 = v_field_249;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_x_2412})}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_244)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2eelab_2eclauses_2ezipC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ezipC_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2ezipC_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ezipC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ezipC_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2etakeC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etakeC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2etakeC(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_heff_2eelab_2eclauses_2etakeC_24dps(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2etakeC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etakeC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2edropC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edropC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2edropC(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2edropC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2edropC(a[0], a[1]);
}

HeffT2 g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2eelab_2eclauses_2epat_24cpr(v_x_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_xs_242);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        V v_e_247 = v_field_245;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_247}});
      } else {
        V v_x_248 = v_field_245;
        HeffT2 v_t_249 = (g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_24cpr(v_xs_242));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_x_248);
            V v_e_2413 = v_field_2411;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2413}});
          } else {
            V v_x_2414 = v_field_2411;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_248, v_x_2414})}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2epat_24cpr_str0, 86, "a pattern is a variable, a literal, a tag applied to patterns, or a record of patterns");
HEFF_LIT(g_heff_2eelab_2eclauses_2epat_24cpr_str1, 86, "a pattern is a variable, a literal, a tag applied to patterns, or a record of patterns");

HeffT2 g_heff_2eelab_2eclauses_2epat_24cpr(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_dup(heff_field(v_p_240, 0));
    V v_p2_242 = heff_dup(heff_field(v_p_240, 1));
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      V v_ru_24p1_241_24PatVar = heff_take_reuse_n(v_p1_241, 1ULL, 1);
      heff_drop_tag(v_p_240, 2);
      heff_drop(v_p2_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24p1_241_24PatVar, TAG_PVar, 1, (V[]){v_x_243})}});
    }
    case TAG_PatTag: {
      V v_t_244 = heff_field(v_p1_241, 0);
      V v_tsp_245 = heff_field(v_p1_241, 1);
      V v_ps_246 = heff_field(v_p1_241, 2);
      V v_ru_24p1_241_24PatTag = heff_take_reuse_n(v_p1_241, 7ULL, 3);
      heff_drop_tag(v_p_240, 2);
      heff_drop(v_p2_242);
      HeffT2 v_t_247 = (g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_24cpr(v_ps_246));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop(v_t_244);
          heff_drop(v_tsp_245);
          heff_drop_cell(v_ru_24p1_241_24PatTag, 3);
          V v_e_2411 = v_field_249;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2411}});
        } else {
          V v_x_2412 = v_field_249;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24p1_241_24PatTag, TAG_PTag, 3, (V[]){v_t_244, v_x_2412, v_tsp_245})}});
        }
      }
    }
    case TAG_PatOp: {
      heff_take_n(v_p1_241, 0ULL, 3);
      heff_drop(v_p2_242);
      V v_t_2418;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2417 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_t_2418 = v_s_2417;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_f_2419 = heff_rec_n(2, shape_span__msg, (V[]){v_t_2418, ((V)&g_heff_2eelab_2eclauses_2epat_24cpr_str0)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2419}});
    }
    case TAG_PatInt: {
      V v_ru_24p1_241_24PatInt = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24p1_241_24PatInt, TAG_PLit, 1, (V[]){v_p_240})}});
    }
    case TAG_PatFloat: {
      V v_ru_24p1_241_24PatFloat = heff_take_reuse_na(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24p1_241_24PatFloat, TAG_PLit, 1, (V[]){v_p_240})}});
    }
    case TAG_PatString: {
      V v_ru_24p1_241_24PatString = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24p1_241_24PatString, TAG_PLit, 1, (V[]){v_p_240})}});
    }
    case TAG_PatBinary: {
      V v_segs_2423 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop_tag(v_p_240, 2);
      V v_segs_2424 = (g_list_2emap_24s886389550x1086668531(v_segs_2423));
      V v_f_2429;
      switch (heff_tag_of(v_segs_2424)) {
      case TAG_Nil: {
        v_f_2429 = heff_tag_n(TAG_PBin, 2, (V[]){v_segs_2424, v_p2_242});
        break;
      }
      case TAG_Cons: {
        V v_s_2425 = heff_dup(heff_field(v_segs_2424, 0));
        V v_segs2_2426 = heff_dup(heff_field(v_segs_2424, 1));
        switch (heff_tag_of(v_segs2_2426)) {
        case TAG_Nil: {
          heff_drop_tag(v_segs_2424, 2);
          v_f_2429 = ({ V a_0 = heff_dup(v_s_2425); V a_1 = heff_dup(heff_rfield(v_s_2425, 0)); V b_2 = heff_dup(heff_rfield(v_s_2425, 1)); V b_3 = heff_get_n(v_s_2425, 2, 5); V a_4 = v_p2_242; V r_ = (g_heff_2eelab_2eclauses_2esoleBin(a_0, a_1, b_2, b_3, a_4)); heff_drop(b_2); heff_drop(b_3); r_; });
          break;
        }
        case TAG_Cons: {
          V v_ru_24segs2_2426_24Cons = heff_take_reuse_n(v_segs2_2426, 0ULL, 2);
          heff_drop_rec(v_s_2425, 5);
          v_f_2429 = heff_tag_at_n(v_ru_24segs2_2426_24Cons, TAG_PBin, 2, (V[]){v_segs_2424, v_p2_242});
          break;
        }
        default: heff_nomatch(v_segs2_2426);
        }
        break;
      }
      default: heff_nomatch(v_segs_2424);
      }
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2429}});
    }
    case TAG_PatRune: {
      V v_ru_24p1_241_24PatRune = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24p1_241_24PatRune, TAG_PLit, 1, (V[]){v_p_240})}});
    }
    case TAG_PatRecord: {
      V v_fs_2431 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop(v_p2_242);
      HeffT2 v_t_2432 = (g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027_24cpr(v_fs_2431));
      {
        V v_field_2434 = v_t_2432.f[1];
        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
        if ((v_tag_2433 == ((int64_t)0ULL))) {
          heff_drop_tag(v_p_240, 2);
          V v_e_2436 = v_field_2434;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2436}});
        } else {
          V v_x_2437 = v_field_2434;
          V v_t_2440;
          switch (heff_tag_of(v_p_240)) {
          case TAG_At: {
            V v_s_2439 = heff_field(v_p_240, 1);
            heff_take_n(v_p_240, 2ULL, 2);
            v_t_2440 = v_s_2439;
            break;
          }
          default: heff_nomatch(v_p_240);
          }
          V v_f_2441 = heff_tag_n(TAG_PRec, 2, (V[]){v_x_2437, v_t_2440});
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2441}});
        }
      }
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop(v_p2_242);
      V v_t_2445;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2444 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_t_2445 = v_s_2444;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_f_2446 = heff_rec_n(2, shape_span__msg, (V[]){v_t_2445, ((V)&g_heff_2eelab_2eclauses_2epat_24cpr_str1)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2446}});
    }
    case TAG_PatAs: {
      V v_x_2447 = heff_field(v_p1_241, 0);
      V v_q_2449 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 5ULL, 3);
      heff_drop_tag(v_p_240, 2);
      heff_drop(v_p2_242);
      HeffT2 v_t_2450 = (g_heff_2eelab_2eclauses_2epat_24cpr(v_q_2449));
      {
        V v_field_2452 = v_t_2450.f[1];
        int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
        if ((v_tag_2451 == ((int64_t)0ULL))) {
          heff_drop(v_x_2447);
          V v_e_2454 = v_field_2452;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2454}});
        } else {
          V v_x_2455 = v_field_2452;
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_n(TAG_PAs, 2, (V[]){v_x_2447, v_x_2455})}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_p1_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_p_240)}});
  }
}
Clo g_heff_2eelab_2eclauses_2esameLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esameLit_entry, 2, 0};

V g_heff_2eelab_2eclauses_2esameLit(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      return NTAG(TAG_False);
    }
    case TAG_PatTag: {
      return NTAG(TAG_False);
    }
    case TAG_PatOp: {
      return NTAG(TAG_False);
    }
    case TAG_PatInt: {
      V v_x_2411 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2412 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2412)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          V v_y_2421 = heff_field(v_x21_2412, 0);
          return heff_intEq(heff_dup(v_x_2411), heff_dup(v_y_2421));
        }
        case TAG_PatFloat: {
          return NTAG(TAG_False);
        }
        case TAG_PatString: {
          return NTAG(TAG_False);
        }
        case TAG_PatBinary: {
          return NTAG(TAG_False);
        }
        case TAG_PatRune: {
          return NTAG(TAG_False);
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2412);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatFloat: {
      double v_x_2431 = heff_tflat_f64(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2432 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2432)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          return NTAG(TAG_False);
        }
        case TAG_PatFloat: {
          double v_y_2442 = heff_tflat_f64(v_x21_2432, 0);
          return heff_bool((v_x_2431 == v_y_2442));
        }
        case TAG_PatString: {
          return NTAG(TAG_False);
        }
        case TAG_PatBinary: {
          return NTAG(TAG_False);
        }
        case TAG_PatRune: {
          return NTAG(TAG_False);
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2432);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatString: {
      V v_x_2451 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2452 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2452)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          return NTAG(TAG_False);
        }
        case TAG_PatFloat: {
          return NTAG(TAG_False);
        }
        case TAG_PatString: {
          V v_y_2463 = heff_field(v_x21_2452, 0);
          return heff_strEq_lent(v_x_2451, v_y_2463, 0);
        }
        case TAG_PatBinary: {
          return NTAG(TAG_False);
        }
        case TAG_PatRune: {
          return NTAG(TAG_False);
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2452);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatBinary: {
      return NTAG(TAG_False);
    }
    case TAG_PatRune: {
      V v_x_2472 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2473 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2473)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          return NTAG(TAG_False);
        }
        case TAG_PatFloat: {
          return NTAG(TAG_False);
        }
        case TAG_PatString: {
          return NTAG(TAG_False);
        }
        case TAG_PatBinary: {
          return NTAG(TAG_False);
        }
        case TAG_PatRune: {
          V v_y_2486 = heff_field(v_x21_2473, 0);
          return heff_intEq(heff_dup(v_x_2472), heff_dup(v_y_2486));
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2473);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatRecord: {
      return NTAG(TAG_False);
    }
    case TAG_PatWord: {
      return NTAG(TAG_False);
    }
    case TAG_PatAs: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2esameLit_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2esameLit(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_entry, 3, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll(V v_f_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){heff_dup(v_x_243), v_acc_242}));
    V t_0 = v_f_240;
    V t_1 = v_xs_244;
    V t_2 = v_t_245;
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2enamesOfAll(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_t_248 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_a_247), v_acc_241));
        v_t_249 = (g_heff_2eelab_2eclauses_2epatIdents(heff_dup(v_a_246), v_t_248));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_249;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2epatBinds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatBinds_entry, 1, 0};

V g_heff_2eelab_2eclauses_2epatBinds(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 1ULL, 2);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
    }
    case TAG_PatTag: {
      V v_ps_246 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_ps_246; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a_0)); heff_drop(v_ps_246); r_; });
    }
    case TAG_PatOp: {
      V v_ps_249 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_ps_249; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a_0)); heff_drop(v_ps_249); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatBinary: {
      V v_segs_2413 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_segs_2413; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s596291066x984087239(a_0)); heff_drop(v_segs_2413); r_; });
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2415 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_fs_2415; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(a_0)); heff_drop(v_fs_2415); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2417 = heff_field(v_p1_241, 0);
      V v_q_2419 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 5ULL, 3);
      V v_cell_2420 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_2417, heff_hole()});
      V v_u_2421 = (g_heff_2eelab_2eclauses_2epatBinds_24dps(v_q_2419, heff_dup(v_cell_2420)));
      heff_drop(v_u_2421);
      return v_cell_2420;
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatBinds(a[0]);
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameDecl_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameDecl_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameDecl(V v_r_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_d1_242 = heff_dup(heff_field(v_d_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_d_241, 1));
    switch (heff_tag_of(v_d1_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_d1_242, 0);
      V v_fsp_245 = heff_field(v_d1_242, 1);
      V v_declared_246 = heff_field(v_d1_242, 2);
      V v_ty_247 = heff_field(v_d1_242, 3);
      V v_eqs_248 = heff_field(v_d1_242, 4);
      V v_ru_24d1_242_24DeclEquations = heff_take_reuse_n(v_d1_242, 31ULL, 5);
      heff_drop_tag(v_d_241, 2);
      V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 4)), 1, (V[]){v_ty_247}));
      V v_t_2411;
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_240, 0)), heff_dup(v_f_244))) {
        heff_drop_rec(v_r_240, 5);
        v_t_2411 = v_eqs_248;
      } else {
        v_t_2411 = (g_list_2emap_24s584558070x895760461(v_r_240, v_eqs_248));
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_244, v_fsp_245, v_declared_246, v_t_249, v_t_2411}), v_sp_243});
    }
    case TAG_DeclDefine: {
      V v_y_2412 = heff_field(v_d1_242, 0);
      V v_ysp_2413 = heff_field(v_d1_242, 1);
      V v_ps_2414 = heff_field(v_d1_242, 2);
      V v_u_2415 = heff_field(v_d1_242, 3);
      V v_body_2416 = heff_field(v_d1_242, 4);
      V v_ru_24d1_242_24DeclDefine = heff_take_reuse_n(v_d1_242, 31ULL, 5);
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_240, 0)), heff_dup(v_y_2412))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_sp_243);
        heff_drop(v_y_2412);
        heff_drop(v_ysp_2413);
        heff_drop(v_ps_2414);
        heff_drop(v_u_2415);
        heff_drop(v_body_2416);
        heff_drop_cell(v_ru_24d1_242_24DeclDefine, 5);
        return v_d_241;
      } else {
        heff_drop_tag(v_d_241, 2);
        V v_t_2429 = (g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657(heff_dup(heff_rfield(v_r_240, 0)), heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), heff_dup(v_ps_2414)));
        V v_t_2430 = (g_heff_2eelab_2eclauses_2eanyC_24s1724875606x1273504888(heff_dup(heff_rfield(v_r_240, 0)), v_ps_2414));
        V v_t_2431;
        if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
          heff_drop(v_t_2430);
          v_t_2431 = v_u_2415;
        } else {
          heff_drop(v_t_2430);
          v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 4)), 1, (V[]){v_u_2415}));
        }
        V v_t_2432 = ({ V a_0 = heff_take_field(v_r_240, 0); V a_1 = v_ps_2414; V r_ = (g_heff_2eelab_2eclauses_2eanyC_24s1724875606x1273504888(a_0, a_1)); heff_drop(v_ps_2414); r_; });
        V v_t_2433;
        if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
          heff_drop_rec(v_r_240, 5);
          heff_drop(v_t_2432);
          v_t_2433 = v_body_2416;
        } else {
          heff_drop(v_t_2432);
          v_t_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_body_2416}));
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_y_2412, v_ysp_2413, v_t_2429, v_t_2431, v_t_2433}), v_sp_243});
      }
    }
    case TAG_DeclTheory: {
      V v_y_2434 = heff_field(v_d1_242, 0);
      V v_ysp_2435 = heff_field(v_d1_242, 1);
      V v_ps_2436 = heff_field(v_d1_242, 2);
      V v_body_2437 = heff_field(v_d1_242, 3);
      V v_ru_24d1_242_24DeclTheory = heff_take_reuse_n(v_d1_242, 15ULL, 4);
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_240, 0)), heff_dup(v_y_2434))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_sp_243);
        heff_drop(v_y_2434);
        heff_drop(v_ysp_2435);
        heff_drop(v_ps_2436);
        heff_drop(v_body_2437);
        heff_drop_cell(v_ru_24d1_242_24DeclTheory, 4);
        return v_d_241;
      } else {
        heff_drop_tag(v_d_241, 2);
        V v_t_2450 = (g_heff_2eelab_2eclauses_2erenameSeq_24s1085051874x961196657(heff_dup(heff_rfield(v_r_240, 0)), heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam1, 1, 1, (V[]){heff_dup(v_r_240)}), heff_dup(v_ps_2436)));
        V v_t_2451 = ({ V a_0 = heff_take_field(v_r_240, 0); V a_1 = v_ps_2436; V r_ = (g_heff_2eelab_2eclauses_2eanyC_24s1724875606x1273504888(a_0, a_1)); heff_drop(v_ps_2436); r_; });
        V v_t_2452;
        if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
          heff_drop_rec(v_r_240, 5);
          heff_drop(v_t_2451);
          v_t_2452 = v_body_2437;
        } else {
          heff_drop(v_t_2451);
          v_t_2452 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_body_2437}));
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_y_2434, v_ysp_2435, v_t_2450, v_t_2452}), v_sp_243});
      }
    }
    case TAG_DeclPrimitive: {
      V v_y_2453 = heff_field(v_d1_242, 0);
      V v_ysp_2454 = heff_field(v_d1_242, 1);
      V v_t_2455 = heff_field(v_d1_242, 2);
      V v_ru_24d1_242_24DeclPrimitive = heff_take_reuse_n(v_d1_242, 7ULL, 3);
      heff_drop_tag(v_d_241, 2);
      V v_t_2456 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2455}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_y_2453, v_ysp_2454, v_t_2456}), v_sp_243});
    }
    case TAG_DeclTest: {
      heff_take_n(v_d1_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_d_241;
    }
    case TAG_DeclWatch: {
      V v_e_2459 = heff_field(v_d1_242, 0);
      V v_ru_24d1_242_24DeclWatch = heff_take_reuse_n(v_d1_242, 1ULL, 1);
      heff_drop_tag(v_d_241, 2);
      V v_t_2460 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_e_2459}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclWatch, TAG_DeclWatch, 1, (V[]){v_t_2460}), v_sp_243});
    }
    default: return heff_nomatch(v_d1_242);
    }
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameDecl(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam0(V self, V *args) {
  V v_x2_2418 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_At: {
    V v_x21_2419 = heff_field(v_x2_2418, 0);
    V v_sp_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24At = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    switch (heff_tag_of(v_x21_2419)) {
    case TAG_ExplicitParam: {
      V v_y_2421 = heff_field(v_x21_2419, 0);
      V v_ysp_2422 = heff_field(v_x21_2419, 1);
      V v_t_2423 = heff_field(v_x21_2419, 2);
      heff_take_n(v_x21_2419, 7ULL, 3);
      V v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2423}));
      return heff_tag_at_n(v_ru_24x2_2418_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_y_2421, v_ysp_2422, v_t_2424}), v_sp_2420});
    }
    case TAG_ImplicitParam: {
      V v_y_2425 = heff_field(v_x21_2419, 0);
      V v_ysp_2426 = heff_field(v_x21_2419, 1);
      V v_t_2427 = heff_field(v_x21_2419, 2);
      heff_take_n(v_x21_2419, 7ULL, 3);
      V v_t_2428 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2427}));
      return heff_tag_at_n(v_ru_24x2_2418_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ImplicitParam, 3, (V[]){v_y_2425, v_ysp_2426, v_t_2428}), v_sp_2420});
    }
    default: return heff_nomatch(v_x21_2419);
    }
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam1(V self, V *args) {
  V v_x2_2439 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_At: {
    V v_x21_2440 = heff_field(v_x2_2439, 0);
    V v_sp_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24At = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    switch (heff_tag_of(v_x21_2440)) {
    case TAG_ExplicitParam: {
      V v_y_2442 = heff_field(v_x21_2440, 0);
      V v_ysp_2443 = heff_field(v_x21_2440, 1);
      V v_t_2444 = heff_field(v_x21_2440, 2);
      heff_take_n(v_x21_2440, 7ULL, 3);
      V v_t_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2444}));
      return heff_tag_at_n(v_ru_24x2_2439_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_y_2442, v_ysp_2443, v_t_2445}), v_sp_2441});
    }
    case TAG_ImplicitParam: {
      V v_y_2446 = heff_field(v_x21_2440, 0);
      V v_ysp_2447 = heff_field(v_x21_2440, 1);
      V v_t_2448 = heff_field(v_x21_2440, 2);
      heff_take_n(v_x21_2440, 7ULL, 3);
      V v_t_2449 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2448}));
      return heff_tag_at_n(v_ru_24x2_2439_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ImplicitParam, 3, (V[]){v_y_2446, v_ysp_2447, v_t_2449}), v_sp_2441});
    }
    default: return heff_nomatch(v_x21_2440);
    }
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
Clo g_heff_2eelab_2eclauses_2eanyC_24s1988114557x804372153_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eanyC_24s1988114557x804372153_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eanyC_24s1988114557x804372153(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_2426;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_DeclEquations: {
        V v_a_246 = heff_field(v_a_244, 0);
        v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_a_246)});
        break;
      }
      case TAG_DeclDefine: {
        V v_a_2411 = heff_field(v_a_244, 0);
        v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_a_2411)});
        break;
      }
      case TAG_DeclTheory: {
        V v_a_2416 = heff_field(v_a_244, 0);
        v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_a_2416)});
        break;
      }
      case TAG_DeclPrimitive: {
        V v_a_2420 = heff_field(v_a_244, 0);
        v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_a_2420)});
        break;
      }
      case TAG_DeclTest: {
        V v_a_2423 = heff_field(v_a_244, 0);
        v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_a_2423)});
        break;
      }
      case TAG_DeclWatch: {
        v_t_2426 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    switch (heff_tag_of(v_t_2426)) {
    case TAG_Nothing: {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_a_2427 = heff_field(v_t_2426, 0);
      heff_take_n(v_t_2426, 1ULL, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_lit_240, 0)), v_a_2427)) {
        heff_drop_rec(v_lit_240, 5);
        return NTAG(TAG_True);
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eanyC_24s1988114557x804372153_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2eanyC_24s1988114557x804372153(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207_entry, 3, 0};

V g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207(V v_lit_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 5);
    heff_drop(v_f_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){heff_dup(v_m_243)}));
    V v_t_2413;
    switch (heff_tag_of(v_m_243)) {
    case TAG_At: {
      V v_a_246 = heff_field(v_m_243, 0);
      heff_take_n(v_m_243, 1ULL, 2);
      switch (heff_tag_of(v_a_246)) {
      case TAG_DeclareField: {
        V v_a_248 = heff_field(v_a_246, 0);
        heff_take_n(v_a_246, 1ULL, 4);
        v_t_2413 = heff_strEq(heff_dup(heff_rfield(v_lit_240, 0)), v_a_248);
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_a_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_m_243);
    }
    V v_t_2414;
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop_rec(v_lit_240, 5);
      heff_drop(v_f_241);
      heff_drop(v_t_2413);
      v_t_2414 = v_rest_244;
    } else {
      heff_drop(v_t_2413);
      v_t_2414 = (g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207(v_lit_240, v_f_241, v_rest_244));
    }
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_t_2414});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameSeq_24s2087082438x1077832207(a[0], a[1], a[2]);
}

HeffT2 g_heff_2eelab_2eclauses_2efindTagLit_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_p_242)) {
    case TAG_PVar: {
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    case TAG_PTag: {
      v_t_2415 = NTAG(TAG_True);
      break;
    }
    case TAG_PLit: {
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    case TAG_PRec: {
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    case TAG_PAs: {
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    case TAG_PBin: {
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_p_242);
    }
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_p_242);
      heff_drop(v_rest_243);
      heff_drop(v_t_2415);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
    } else {
      heff_drop(v_t_2415);
      V v_t_2427;
      switch (heff_tag_of(v_p_242)) {
      case TAG_PVar: {
        v_t_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_PTag: {
        v_t_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_PLit: {
        v_t_2427 = NTAG(TAG_True);
        break;
      }
      case TAG_PRec: {
        v_t_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_PAs: {
        v_t_2427 = NTAG(TAG_False);
        break;
      }
      case TAG_PBin: {
        v_t_2427 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_p_242);
      }
      if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
        heff_drop(v_p_242);
        heff_drop(v_rest_243);
        heff_drop(v_t_2427);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
      } else {
        heff_drop(v_t_2427);
        V v_t_2439;
        switch (heff_tag_of(v_p_242)) {
        case TAG_PVar: {
          v_t_2439 = NTAG(TAG_False);
          break;
        }
        case TAG_PTag: {
          v_t_2439 = NTAG(TAG_False);
          break;
        }
        case TAG_PLit: {
          v_t_2439 = NTAG(TAG_False);
          break;
        }
        case TAG_PRec: {
          v_t_2439 = NTAG(TAG_True);
          break;
        }
        case TAG_PAs: {
          v_t_2439 = NTAG(TAG_False);
          break;
        }
        case TAG_PBin: {
          v_t_2439 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_p_242);
        }
        if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
          heff_drop(v_p_242);
          heff_drop(v_rest_243);
          heff_drop(v_t_2439);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
        } else {
          heff_drop(v_t_2439);
          V v_t_2451;
          switch (heff_tag_of(v_p_242)) {
          case TAG_PVar: {
            heff_take_n(v_p_242, 0ULL, 1);
            v_t_2451 = NTAG(TAG_False);
            break;
          }
          case TAG_PTag: {
            heff_take_n(v_p_242, 0ULL, 3);
            v_t_2451 = NTAG(TAG_False);
            break;
          }
          case TAG_PLit: {
            heff_take_n(v_p_242, 0ULL, 1);
            v_t_2451 = NTAG(TAG_False);
            break;
          }
          case TAG_PRec: {
            heff_take_n(v_p_242, 0ULL, 2);
            v_t_2451 = NTAG(TAG_False);
            break;
          }
          case TAG_PAs: {
            heff_take_n(v_p_242, 0ULL, 2);
            v_t_2451 = NTAG(TAG_False);
            break;
          }
          case TAG_PBin: {
            heff_take_n(v_p_242, 0ULL, 2);
            v_t_2451 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_p_242);
          }
          if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
            heff_drop(v_rest_243);
            heff_drop(v_t_2451);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
          } else {
            heff_drop(v_t_2451);
            V t_0 = v_rest_243;
            V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
            v_x1_240 = t_0;
            v_i_241 = t_1;
            goto top;
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2etagColAt_str0, 1, "_");
V g_heff_2eelab_2eclauses_2etagColAt_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2etagColAt_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2etagColAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etagColAt_entry, 5, 0};

V g_heff_2eelab_2eclauses_2etagColAt(V v_c_240, V v_v_241, V v_col_242, V v_r_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_PVar: {
    V v_x_245 = heff_field(v_x5_244, 0);
    V v_e_246 = heff_take_field(v_r_243, 1);
    V v_rhs_2410;
    if (heff_strEq_c_lent(v_x_245, ((V)&g_heff_2eelab_2eclauses_2etagColAt_str0), 2)) {
      heff_drop(v_v_241);
      v_rhs_2410 = v_e_246;
    } else {
      if (heff_strEq_c_lent(v_x_245, v_v_241, 0)) {
        heff_drop(v_v_241);
        v_rhs_2410 = v_e_246;
      } else {
        V v_t_249 = (g_heff_2eelab_2eclauses_2erenamer(heff_dup(v_x_245), v_v_241));
        v_rhs_2410 = heff_tr(heff_call(heff_get_n(v_t_249, 3, 5), 1, (V[]){v_e_246}));
      }
    }
    V v_a_2411 = ({ V rv_1 = v_rhs_2410; V rr_ = heff_rec_reuse_nf(v_r_243, 1ULL, 2, shape_pats__rhs, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2416 = (g_map_2emapValues(heff_clo_n(g_heff_2eelab_2eclauses_2etagColAt_lam0, 1, 2, (V[]){v_c_240, heff_dup(v_a_2411)}), heff_take_field(v_col_242, 0)));
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2411, heff_take_field(v_col_242, 2)});
    return ({ V rv_0 = v_t_2416; V rv_2 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_col_242, 2ULL, 3, shape_arms__order__anys, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  }
  case TAG_PTag: {
    V v_t_2418 = heff_field(v_x5_244, 0);
    V v_ps_2419 = heff_field(v_x5_244, 1);
    V v_sp_2420 = heff_field(v_x5_244, 2);
    heff_drop(v_v_241);
    V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ps_2419));
    V v_xs_2422 = heff_take_field(v_r_243, 0);
    V v_t_2423 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2422)));
    V v_t_2424 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2422));
    V v_t_2425 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_ps_2419), v_t_2424));
    V v_pats_2426 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2423, v_t_2425));
    V v_t_2427 = ({ V rv_0 = v_pats_2426; V rr_ = heff_rec_reuse_nf(v_r_243, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2428 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_t_2418), heff_rfield(v_col_242, 0)));
    return ({ V a_0 = v_c_240; V a_1 = v_col_242; V a_2 = heff_rec_n(4, shape_tag__arity__pats__span, (V[]){heff_dup(v_t_2418), v_t_2421, heff_dup(v_ps_2419), heff_dup(v_sp_2420)}); V a_3 = v_t_2427; V a_4 = v_t_2428; V r_ = (g_heff_2eelab_2eclauses_2etagArmStep(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2428); r_; });
  }
  case TAG_PLit: {
    heff_drop(v_v_241);
    V v_t_2434 = (g_map_2emapValues(heff_clo_n(g_heff_2eelab_2eclauses_2etagColAt_lam1, 1, 2, (V[]){v_c_240, heff_dup(v_r_243)}), heff_take_field(v_col_242, 0)));
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243, heff_take_field(v_col_242, 2)});
    return ({ V rv_0 = v_t_2434; V rv_2 = v_t_2435; V rr_ = heff_rec_reuse_nf(v_col_242, 2ULL, 3, shape_arms__order__anys, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  }
  case TAG_PRec: {
    heff_drop(v_c_240);
    heff_drop(v_v_241);
    heff_drop_rec(v_r_243, 2);
    return v_col_242;
  }
  case TAG_PAs: {
    heff_drop(v_c_240);
    heff_drop(v_v_241);
    heff_drop_rec(v_r_243, 2);
    return v_col_242;
  }
  case TAG_PBin: {
    heff_drop(v_c_240);
    heff_drop(v_v_241);
    heff_drop_rec(v_r_243, 2);
    return v_col_242;
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eclauses_2etagColAt_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2etagColAt(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2eelab_2eclauses_2etagColAt_lam0(V self, V *args) {
  V v_arm_2412 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_a_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_arm_2412, 0)), 1, 4);
  V v_t_2414 = (g_heff_2eelab_2eclauses_2eanyIn(v_c_240, v_t_2413, v_a_2411));
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_take_field(v_arm_2412, 2)});
  return ({ V rv_2 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_arm_2412, 3ULL, 3, shape_row__bad__rows, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2eclauses_2etagColAt_lam1(V self, V *args) {
  V v_arm_2430 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_r_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_get_n(heff_dup(heff_rfield(v_arm_2430, 0)), 1, 4);
  V v_t_2432 = (g_heff_2eelab_2eclauses_2eanyIn(v_c_240, v_t_2431, v_r_243));
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, heff_take_field(v_arm_2430, 2)});
  return ({ V rv_2 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_arm_2430, 3ULL, 3, shape_row__bad__rows, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
}
Clo g_heff_2eelab_2eclauses_2elitYes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitYes_entry, 4, 0};

V g_heff_2eelab_2eclauses_2elitYes(V v_c_240, V v_l_241, V v_v_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_v_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_t_246 = (g_heff_2eelab_2eclauses_2elitYes(heff_dup(v_c_240), v_l_241, heff_dup(v_v_242), v_rest_245));
    return (g_heff_2eelab_2eclauses_2elitYesOne(v_c_240, v_l_241, v_v_242, heff_dup(v_r_244), v_t_246));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eclauses_2elitYes_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2eelab_2eclauses_2elitYes(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2eelab_2eclauses_2elitNoOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitNoOne_entry, 4, 0};

V g_heff_2eelab_2eclauses_2elitNoOne(V v_c_240, V v_l_241, V v_r_242, V v_acc_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(heff_rfield(v_r_242, 0)), v_c_240));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_p_248 = v_field_246;
      switch (heff_tag_of(v_p_248)) {
      case TAG_PVar: {
        heff_take_n(v_p_248, 0ULL, 1);
        return heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
      }
      case TAG_PTag: {
        heff_take_n(v_p_248, 0ULL, 3);
        return heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
      }
      case TAG_PLit: {
        V v_l_27_2413 = heff_field(v_p_248, 0);
        heff_take_n(v_p_248, 1ULL, 1);
        V v_t_2414 = ({ V a_0 = v_l_241; V a_1 = v_l_27_2413; V r_ = (g_heff_2eelab_2eclauses_2esameLit(a_0, a_1)); heff_drop(v_l_27_2413); r_; });
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop_rec(v_r_242, 2);
          heff_drop(v_t_2414);
          return v_acc_243;
        } else {
          heff_drop(v_t_2414);
          return heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
        }
      }
      case TAG_PRec: {
        V v_ru_24p_248_24PRec = heff_take_reuse_n(v_p_248, 0ULL, 2);
        return heff_tag_at_n(v_ru_24p_248_24PRec, TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
      }
      case TAG_PAs: {
        V v_ru_24p_248_24PAs = heff_take_reuse_n(v_p_248, 0ULL, 2);
        return heff_tag_at_n(v_ru_24p_248_24PAs, TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
      }
      case TAG_PBin: {
        V v_ru_24p_248_24PBin = heff_take_reuse_n(v_p_248, 0ULL, 2);
        return heff_tag_at_n(v_ru_24p_248_24PBin, TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
      }
      default: return heff_nomatch(v_p_248);
      }
    } else {
      heff_drop(v_field_246);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
    }
  }
}
V g_heff_2eelab_2eclauses_2elitNoOne_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2elitNoOne(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2elitNo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitNo_entry, 3, 0};

V g_heff_2eelab_2eclauses_2elitNo(V v_c_240, V v_l_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2eelab_2eclauses_2elitNo(heff_dup(v_c_240), v_l_241, v_rest_244));
    return (g_heff_2eelab_2eclauses_2elitNoOne(v_c_240, v_l_241, heff_dup(v_r_243), v_t_245));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2elitNo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2elitNo(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_24cpr_str1, 43, "a literal and a tag match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_24cpr_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_24cpr_str3, 46, "a literal and a binary match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_24cpr_str4, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_24cpr_str5, 88, "literals are matched here: one of them must match every other value (a variable, or `_`)");
V g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2elitChecks_24cpr(V v_sp_240, V v_vars_241, V v_rows_242, V v_c_243, V v_l_244) {
top: ;
  V v_t_2423 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam0, 1, 1, (V[]){heff_dup(v_c_243)}), v_rows_242));
  if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
    heff_drop(v_c_243);
    heff_drop(v_t_2423);
    V v_t_2426;
    switch (heff_tag_of(v_l_244)) {
    case TAG_At: {
      V v_s_2425 = heff_field(v_l_244, 1);
      v_t_2426 = heff_dup(v_s_2425);
      break;
    }
    default: heff_nomatch(v_l_244);
    }
    V v_f_2427 = heff_rec_n(2, shape_span__msg, (V[]){v_t_2426, ((V)&g_heff_2eelab_2eclauses_2elitChecks_24cpr_str1)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2427}});
  } else {
    heff_drop(v_t_2423);
    V v_t_2446 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam1, 1, 1, (V[]){heff_dup(v_c_243)}), v_rows_242));
    if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
      heff_drop(v_c_243);
      heff_drop(v_t_2446);
      V v_t_2449;
      switch (heff_tag_of(v_l_244)) {
      case TAG_At: {
        V v_s_2448 = heff_field(v_l_244, 1);
        v_t_2449 = heff_dup(v_s_2448);
        break;
      }
      default: heff_nomatch(v_l_244);
      }
      V v_f_2450 = heff_rec_n(2, shape_span__msg, (V[]){v_t_2449, ((V)&g_heff_2eelab_2eclauses_2elitChecks_24cpr_str3)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2450}});
    } else {
      heff_drop(v_t_2446);
      V v_t_2469 = (g_heff_2eelab_2eclauses_2eallC(heff_clo_n(g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam2, 1, 1, (V[]){v_c_243}), v_rows_242));
      if ((heff_dup(v_t_2469) == NTAG(TAG_True))) {
        heff_drop(v_t_2469);
        V v_t_2472;
        switch (heff_tag_of(v_l_244)) {
        case TAG_At: {
          V v_s_2471 = heff_field(v_l_244, 1);
          v_t_2472 = heff_dup(v_s_2471);
          break;
        }
        default: heff_nomatch(v_l_244);
        }
        V v_f_2473 = heff_rec_n(2, shape_span__msg, (V[]){v_t_2472, ((V)&g_heff_2eelab_2eclauses_2elitChecks_24cpr_str5)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2473}});
      } else {
        heff_drop(v_t_2469);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_MkUnit)}});
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam0(V self, V *args) {
  V v_row_245 = args[0];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_246 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_row_245, 0, 2), v_c_243));
  V v_x1_2411;
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_p_2410 = v_field_248;
      v_x1_2411 = v_p_2410;
    } else {
      heff_drop(v_field_248);
      v_x1_2411 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2elitChecks_24cpr_str0)});
    }
  }
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_PVar: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_2411, 0ULL, 3);
    return NTAG(TAG_True);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_2411, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_2411, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PBin: {
    heff_take_n(v_x1_2411, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
V g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam1(V self, V *args) {
  V v_row_2428 = args[0];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2429 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_row_2428, 0, 2), v_c_243));
  V v_x1_2434;
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      V v_p_2433 = v_field_2431;
      v_x1_2434 = v_p_2433;
    } else {
      heff_drop(v_field_2431);
      v_x1_2434 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2elitChecks_24cpr_str2)});
    }
  }
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_PVar: {
    heff_take_n(v_x1_2434, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_2434, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_2434, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_2434, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_2434, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PBin: {
    heff_take_n(v_x1_2434, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
V g_heff_2eelab_2eclauses_2elitChecks_24cpr_lam2(V self, V *args) {
  V v_row_2451 = args[0];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2452 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_row_2451, 0, 2), v_c_243));
  V v_x1_2457;
  {
    V v_field_2454 = v_t_2452.f[1];
    int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
    if ((v_tag_2453 == ((int64_t)0ULL))) {
      V v_p_2456 = v_field_2454;
      v_x1_2457 = v_p_2456;
    } else {
      heff_drop(v_field_2454);
      v_x1_2457 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2elitChecks_24cpr_str4)});
    }
  }
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_PVar: {
    heff_take_n(v_x1_2457, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_2457, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_2457, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_2457, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_2457, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PBin: {
    heff_take_n(v_x1_2457, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_2457);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2enoRecMix_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2enoRecMix_24cpr_str1, 42, "a record and a tag match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2enoRecMix_24cpr_str2, 46, "a record and a literal match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2enoRecMix_24cpr_str3, 45, "a record and a binary match the same argument");
V g_heff_2eelab_2eclauses_2enoRecMix_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2enoRecMix_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2enoRecMix_24cpr(V v_rows_240, V v_c_241) {
top: ;
  V v_t_2420 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2enoRecMix_24cpr_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_rows_240));
  if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
    heff_drop(v_t_2420);
    HEFF_LAST return g_heff_2eelab_2eclauses_2eforC_24cpr(v_rows_240, heff_clo_n(g_heff_2eelab_2eclauses_2enoRecMix_24cpr_lam1, 1, 1, (V[]){v_c_241}));
  } else {
    heff_drop(v_rows_240);
    heff_drop(v_c_241);
    heff_drop(v_t_2420);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_MkUnit)}});
  }
}
V g_heff_2eelab_2eclauses_2enoRecMix_24cpr_lam0(V self, V *args) {
  V v_row_242 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_243 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_row_242, 0, 2), v_c_241));
  V v_x1_248;
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_p_247 = v_field_245;
      v_x1_248 = v_p_247;
    } else {
      heff_drop(v_field_245);
      v_x1_248 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2enoRecMix_24cpr_str0)});
    }
  }
  switch (heff_tag_of(v_x1_248)) {
  case TAG_PVar: {
    heff_take_n(v_x1_248, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_248, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_248, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_248, 0ULL, 2);
    return NTAG(TAG_True);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_248, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PBin: {
    heff_take_n(v_x1_248, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2eelab_2eclauses_2enoRecMix_24cpr_lam1(V self, V *args) {
  V v_row_2421 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2422 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_row_2421, 0, 2), v_c_241));
  {
    V v_field_2424 = v_t_2422.f[1];
    int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
    if ((v_tag_2423 == ((int64_t)0ULL))) {
      V v_p_2426 = v_field_2424;
      switch (heff_tag_of(v_p_2426)) {
      case TAG_PVar: {
        V v_ru_24p_2426_24PVar = heff_take_reuse_n(v_p_2426, 0ULL, 1);
        return heff_tag_at_n(v_ru_24p_2426_24PVar, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_PTag: {
        V v_sp_2430 = heff_field(v_p_2426, 2);
        heff_take_n(v_p_2426, 4ULL, 3);
        return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_sp_2430, ((V)&g_heff_2eelab_2eclauses_2enoRecMix_24cpr_str1)})});
      }
      case TAG_PLit: {
        V v_l_2431 = heff_field(v_p_2426, 0);
        V v_ru_24p_2426_24PLit = heff_take_reuse_n(v_p_2426, 1ULL, 1);
        V v_t_2434;
        switch (heff_tag_of(v_l_2431)) {
        case TAG_At: {
          V v_s_2433 = heff_field(v_l_2431, 1);
          heff_take_n(v_l_2431, 2ULL, 2);
          v_t_2434 = v_s_2433;
          break;
        }
        default: heff_nomatch(v_l_2431);
        }
        return heff_tag_at_n(v_ru_24p_2426_24PLit, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_t_2434, ((V)&g_heff_2eelab_2eclauses_2enoRecMix_24cpr_str2)})});
      }
      case TAG_PRec: {
        heff_take_n(v_p_2426, 0ULL, 2);
        return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_PAs: {
        heff_take_n(v_p_2426, 0ULL, 2);
        return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_PBin: {
        V v_bsp_2440 = heff_field(v_p_2426, 1);
        heff_take_n(v_p_2426, 2ULL, 2);
        return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_bsp_2440, ((V)&g_heff_2eelab_2eclauses_2enoRecMix_24cpr_str3)})});
      }
      default: return heff_nomatch(v_p_2426);
      }
    } else {
      heff_drop(v_field_2424);
      return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSubName_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2erecSubName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSubName_entry, 6, 0};

V g_heff_2eelab_2eclauses_2erecSubName(V v_used_240, V v_bound_241, V v_rows_242, V v_c_243, V v_x5_244, V v_f_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_c_243);
    return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, v_f_245));
  }
  case TAG_Just: {
    V v_x_246 = heff_field(v_x5_244, 0);
    if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2eelab_2eclauses_2erecSubName_str0), 2)) {
      heff_drop(v_c_243);
      return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, v_f_245));
    } else {
      V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_246)}));
      V v_x1_249 = (g_list_2eany(v_t_248, v_bound_241));
      if ((heff_dup(v_x1_249) == NTAG(TAG_True))) {
        heff_drop(v_c_243);
        heff_drop(v_x1_249);
        return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, v_f_245));
      } else {
        heff_drop(v_x1_249);
        V v_t_2410 = (g_heff_2eelab_2eclauses_2enameFits(heff_dup(v_x_246), v_c_243, v_rows_242));
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_f_245);
          heff_drop(v_t_2410);
          return heff_dup(v_x_246);
        } else {
          heff_drop(v_t_2410);
          return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, v_f_245));
        }
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eclauses_2erecSubName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2erecSubName(a0, a1, a2, a[3], a4, a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ewidthBy_str0, 6, "intMul");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewidthBy_str1, 6, "intMul");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewidthBy_str2, 6, "intMul");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewidthBy_str3, 6, "intMul");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewidthBy_str4, 6, "intMul");
HEFF_LIT(g_heff_2eelab_2eclauses_2ewidthBy_str5, 6, "intMul");
Clo g_heff_2eelab_2eclauses_2ewidthBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ewidthBy_entry, 5, 0};

V g_heff_2eelab_2eclauses_2ewidthBy(V v_env_240, V v_sp_241, V v_ty_242, V v_x4_243, V v_v_244) {
top: ;
  switch (heff_tag_of(v_ty_242)) {
  case TAG_SegmentInteger: {
    switch (heff_tag_of(v_x4_243)) {
    case TAG_SizeDefault: {
      heff_drop(v_sp_241);
      return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(8LL), NTAG(TAG_Nil)});
    }
    case TAG_SizeNumber: {
      V v_n_245 = heff_field(v_x4_243, 0);
      heff_drop(v_sp_241);
      return heff_rec_n(2, shape_bits__terms, (V[]){heff_dup(v_n_245), NTAG(TAG_Nil)});
    }
    case TAG_SizeName: {
      V v_x_246 = heff_field(v_x4_243, 0);
      V v_xsp_247 = heff_field(v_x4_243, 1);
      V v_x43_248 = heff_field(v_x4_243, 2);
      if (heff_intEq_c(heff_dup(v_x43_248), MK_INT(1LL))) {
        heff_drop(v_sp_241);
        V v_x_2410 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_246)));
        V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2410}), heff_dup(v_xsp_247)});
        V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2411}), heff_dup(v_xsp_247)});
        V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2413});
      } else {
        V v_x_2414 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_246)));
        V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2414}), heff_dup(v_xsp_247)});
        V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2415}), heff_dup(v_xsp_247)});
        V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){heff_dup(v_x43_248)}), heff_dup(v_sp_241)});
        V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2417}), heff_dup(v_sp_241)});
        V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
        V v_args_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2419});
        V v_t_2421 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2420));
        V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ewidthBy_str0)}), heff_dup(v_sp_241)});
        V v_t_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2422, v_t_2421}), heff_dup(v_sp_241)});
        V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2423}), v_sp_241});
        V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2425});
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  case TAG_SegmentBinary: {
    switch (heff_tag_of(v_x4_243)) {
    case TAG_SizeDefault: {
      heff_drop(v_sp_241);
      switch (heff_tag_of(v_v_244)) {
      case TAG_At: {
        V v_v1_2426 = heff_field(v_v_244, 0);
        switch (heff_tag_of(v_v1_2426)) {
        case TAG_PatVar: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatTag: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatOp: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatInt: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatFloat: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatString: {
          V v_str_2437 = heff_field(v_v1_2426, 0);
          V v_t_2438 = heff_intMul(MK_INT(8LL), heff_strLength_lent(v_str_2437, 0));
          return heff_rec_n(2, shape_bits__terms, (V[]){v_t_2438, NTAG(TAG_Nil)});
        }
        case TAG_PatBinary: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatRune: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatRecord: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatWord: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        case TAG_PatAs: {
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        }
        default: return heff_nomatch(v_v1_2426);
        }
      }
      default: return heff_nomatch(v_v_244);
      }
    }
    case TAG_SizeNumber: {
      V v_n_2446 = heff_field(v_x4_243, 0);
      heff_drop(v_sp_241);
      return heff_rec_n(2, shape_bits__terms, (V[]){heff_dup(v_n_2446), NTAG(TAG_Nil)});
    }
    case TAG_SizeName: {
      V v_x_2447 = heff_field(v_x4_243, 0);
      V v_xsp_2448 = heff_field(v_x4_243, 1);
      V v_x43_2449 = heff_field(v_x4_243, 2);
      if (heff_intEq_c(heff_dup(v_x43_2449), MK_INT(1LL))) {
        heff_drop(v_sp_241);
        V v_x_2451 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_2447)));
        V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2451}), heff_dup(v_xsp_2448)});
        V v_t_2453 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2452}), heff_dup(v_xsp_2448)});
        V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2454});
      } else {
        V v_x_2455 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_2447)));
        V v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2455}), heff_dup(v_xsp_2448)});
        V v_t_2457 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2456}), heff_dup(v_xsp_2448)});
        V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){heff_dup(v_x43_2449)}), heff_dup(v_sp_241)});
        V v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2458}), heff_dup(v_sp_241)});
        V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, NTAG(TAG_Nil)});
        V v_args_2461 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, v_t_2460});
        V v_t_2462 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2461));
        V v_t_2463 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ewidthBy_str1)}), heff_dup(v_sp_241)});
        V v_t_2464 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2463, v_t_2462}), heff_dup(v_sp_241)});
        V v_t_2465 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2464}), v_sp_241});
        V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2465, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2466});
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  case TAG_SegmentBits: {
    switch (heff_tag_of(v_x4_243)) {
    case TAG_SizeDefault: {
      heff_drop(v_sp_241);
      return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    }
    case TAG_SizeNumber: {
      V v_n_2467 = heff_field(v_x4_243, 0);
      heff_drop(v_sp_241);
      return heff_rec_n(2, shape_bits__terms, (V[]){heff_dup(v_n_2467), NTAG(TAG_Nil)});
    }
    case TAG_SizeName: {
      V v_x_2468 = heff_field(v_x4_243, 0);
      V v_xsp_2469 = heff_field(v_x4_243, 1);
      V v_x43_2470 = heff_field(v_x4_243, 2);
      if (heff_intEq_c(heff_dup(v_x43_2470), MK_INT(1LL))) {
        heff_drop(v_sp_241);
        V v_x_2472 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_2468)));
        V v_t_2473 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2472}), heff_dup(v_xsp_2469)});
        V v_t_2474 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2473}), heff_dup(v_xsp_2469)});
        V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2474, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2475});
      } else {
        V v_x_2476 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_2468)));
        V v_t_2477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2476}), heff_dup(v_xsp_2469)});
        V v_t_2478 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2477}), heff_dup(v_xsp_2469)});
        V v_t_2479 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){heff_dup(v_x43_2470)}), heff_dup(v_sp_241)});
        V v_t_2480 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2479}), heff_dup(v_sp_241)});
        V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2480, NTAG(TAG_Nil)});
        V v_args_2482 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2478, v_t_2481});
        V v_t_2483 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2482));
        V v_t_2484 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ewidthBy_str2)}), heff_dup(v_sp_241)});
        V v_t_2485 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2484, v_t_2483}), heff_dup(v_sp_241)});
        V v_t_2486 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2485}), v_sp_241});
        V v_t_2487 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2486, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2487});
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  case TAG_SegmentFloat: {
    switch (heff_tag_of(v_x4_243)) {
    case TAG_SizeDefault: {
      heff_drop(v_sp_241);
      return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(64LL), NTAG(TAG_Nil)});
    }
    case TAG_SizeNumber: {
      V v_n_2488 = heff_field(v_x4_243, 0);
      heff_drop(v_sp_241);
      return heff_rec_n(2, shape_bits__terms, (V[]){heff_dup(v_n_2488), NTAG(TAG_Nil)});
    }
    case TAG_SizeName: {
      V v_x_2489 = heff_field(v_x4_243, 0);
      V v_xsp_2490 = heff_field(v_x4_243, 1);
      V v_x43_2491 = heff_field(v_x4_243, 2);
      if (heff_intEq_c(heff_dup(v_x43_2491), MK_INT(1LL))) {
        heff_drop(v_sp_241);
        V v_x_2493 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_2489)));
        V v_t_2494 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2493}), heff_dup(v_xsp_2490)});
        V v_t_2495 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2494}), heff_dup(v_xsp_2490)});
        V v_t_2496 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2495, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_2496});
      } else {
        V v_x_2497 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_2489)));
        V v_t_2498 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_2497}), heff_dup(v_xsp_2490)});
        V v_t_2499 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2498}), heff_dup(v_xsp_2490)});
        V v_t_24100 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){heff_dup(v_x43_2491)}), heff_dup(v_sp_241)});
        V v_t_24101 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24100}), heff_dup(v_sp_241)});
        V v_t_24102 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24101, NTAG(TAG_Nil)});
        V v_args_24103 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2499, v_t_24102});
        V v_t_24104 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_24103));
        V v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ewidthBy_str3)}), heff_dup(v_sp_241)});
        V v_t_24106 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24105, v_t_24104}), heff_dup(v_sp_241)});
        V v_t_24107 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24106}), v_sp_241});
        V v_t_24108 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24107, NTAG(TAG_Nil)});
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_24108});
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  case TAG_SegmentUtf: {
    V v_ty1_24109 = heff_field(v_ty_242, 0);
    V v_ru_24ty_242_24SegmentUtf = heff_take_reuse_n(v_ty_242, 1ULL, 1);
    if (heff_intEq_c(v_ty1_24109, MK_INT(32LL))) {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_SizeDefault: {
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24ty_242_24SegmentUtf, 1);
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(32LL), NTAG(TAG_Nil)});
      }
      case TAG_SizeNumber: {
        V v_n_24111 = heff_field(v_x4_243, 0);
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24ty_242_24SegmentUtf, 1);
        return heff_rec_n(2, shape_bits__terms, (V[]){heff_dup(v_n_24111), NTAG(TAG_Nil)});
      }
      case TAG_SizeName: {
        V v_x_24112 = heff_field(v_x4_243, 0);
        V v_xsp_24113 = heff_field(v_x4_243, 1);
        V v_x43_24114 = heff_field(v_x4_243, 2);
        if (heff_intEq_c(heff_dup(v_x43_24114), MK_INT(1LL))) {
          heff_drop(v_sp_241);
          V v_x_24116 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_24112)));
          V v_t_24117 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24ty_242_24SegmentUtf, TAG_IVar, 1, (V[]){v_x_24116}), heff_dup(v_xsp_24113)});
          V v_t_24118 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24117}), heff_dup(v_xsp_24113)});
          V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24118, NTAG(TAG_Nil)});
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_24119});
        } else {
          V v_x_24120 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_24112)));
          V v_t_24121 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24ty_242_24SegmentUtf, TAG_IVar, 1, (V[]){v_x_24120}), heff_dup(v_xsp_24113)});
          V v_t_24122 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24121}), heff_dup(v_xsp_24113)});
          V v_t_24123 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){heff_dup(v_x43_24114)}), heff_dup(v_sp_241)});
          V v_t_24124 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24123}), heff_dup(v_sp_241)});
          V v_t_24125 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24124, NTAG(TAG_Nil)});
          V v_args_24126 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24122, v_t_24125});
          V v_t_24127 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_24126));
          V v_t_24128 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ewidthBy_str4)}), heff_dup(v_sp_241)});
          V v_t_24129 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24128, v_t_24127}), heff_dup(v_sp_241)});
          V v_t_24130 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24129}), v_sp_241});
          V v_t_24131 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24130, NTAG(TAG_Nil)});
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_24131});
        }
      }
      default: return heff_nomatch(v_x4_243);
      }
    } else {
      switch (heff_tag_of(v_x4_243)) {
      case TAG_SizeDefault: {
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24ty_242_24SegmentUtf, 1);
        return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      }
      case TAG_SizeNumber: {
        V v_n_24132 = heff_field(v_x4_243, 0);
        heff_drop(v_sp_241);
        heff_drop_cell(v_ru_24ty_242_24SegmentUtf, 1);
        return heff_rec_n(2, shape_bits__terms, (V[]){heff_dup(v_n_24132), NTAG(TAG_Nil)});
      }
      case TAG_SizeName: {
        V v_x_24133 = heff_field(v_x4_243, 0);
        V v_xsp_24134 = heff_field(v_x4_243, 1);
        V v_x43_24135 = heff_field(v_x4_243, 2);
        if (heff_intEq_c(heff_dup(v_x43_24135), MK_INT(1LL))) {
          heff_drop(v_sp_241);
          V v_x_24137 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_24133)));
          V v_t_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24ty_242_24SegmentUtf, TAG_IVar, 1, (V[]){v_x_24137}), heff_dup(v_xsp_24134)});
          V v_t_24139 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24138}), heff_dup(v_xsp_24134)});
          V v_t_24140 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24139, NTAG(TAG_Nil)});
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_24140});
        } else {
          V v_x_24141 = (g_heff_2eelab_2eclauses_2eresolve(v_env_240, heff_dup(v_x_24133)));
          V v_t_24142 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24ty_242_24SegmentUtf, TAG_IVar, 1, (V[]){v_x_24141}), heff_dup(v_xsp_24134)});
          V v_t_24143 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24142}), heff_dup(v_xsp_24134)});
          V v_t_24144 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){heff_dup(v_x43_24135)}), heff_dup(v_sp_241)});
          V v_t_24145 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24144}), heff_dup(v_sp_241)});
          V v_t_24146 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24145, NTAG(TAG_Nil)});
          V v_args_24147 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24143, v_t_24146});
          V v_t_24148 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_24147));
          V v_t_24149 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ewidthBy_str5)}), heff_dup(v_sp_241)});
          V v_t_24150 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24149, v_t_24148}), heff_dup(v_sp_241)});
          V v_t_24151 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24150}), v_sp_241});
          V v_t_24152 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24151, NTAG(TAG_Nil)});
          return heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), v_t_24152});
        }
      }
      default: return heff_nomatch(v_x4_243);
      }
    }
  }
  default: return heff_nomatch(v_ty_242);
  }
}
V g_heff_2eelab_2eclauses_2ewidthBy_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2ewidthBy(a0, a[1], a[2], a3, a4); heff_drop(a0); heff_drop(a3); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eintRead_str0, 9, "bitsIntAt");
HEFF_LIT(g_heff_2eelab_2eclauses_2eintRead_str1, 10, "bytesIntAt");
Clo g_heff_2eelab_2eclauses_2eintRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eintRead_entry, 4, 0};

V g_heff_2eelab_2eclauses_2eintRead(V v_k_240, V v_off_241, V v_w_242, V v_flags_243) {
top: ;
  V v_sp_244 = heff_dup(heff_rfield(v_k_240, 6));
  V v_t_245 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_240, 0)});
  V v_t_246 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_245, heff_dup(v_sp_244)})});
  V v_t_247 = (g_heff_2eelab_2eclauses_2eoffC(v_off_241, heff_dup(heff_rfield(v_k_240, 6))));
  V v_t_248 = (g_heff_2eelab_2eclauses_2eoffC(v_w_242, heff_dup(heff_rfield(v_k_240, 6))));
  V v_sp_249 = heff_dup(heff_rfield(v_k_240, 6));
  V v_t_2410 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_flags_243}), heff_dup(v_sp_249)});
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2410}), v_sp_249});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2412})});
  V v_args_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_sp_244}), v_t_2413});
  V v_sp_2415 = heff_take_field(v_k_240, 6);
  V v_t_2416 = heff_get_n(v_k_240, 1, 7);
  V v_t_2417;
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop(v_t_2416);
    v_t_2417 = ((V)&g_heff_2eelab_2eclauses_2eintRead_str0);
  } else {
    heff_drop(v_t_2416);
    v_t_2417 = ((V)&g_heff_2eelab_2eclauses_2eintRead_str1);
  }
  V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_t_2417}), heff_dup(v_sp_2415)});
  V v_t_2419 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2415), v_args_2414));
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2418, v_t_2419}), v_sp_2415});
}
V g_heff_2eelab_2eclauses_2eintRead_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eintRead(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eintTest_str0, 4, "Size");
HEFF_LIT(g_heff_2eelab_2eclauses_2eintTest_str1, 4, "Size");
HEFF_LIT(g_heff_2eelab_2eclauses_2eintTest_str2, 5, "intEq");
Clo g_heff_2eelab_2eclauses_2eintTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eintTest_entry, 9, 0};

V g_heff_2eelab_2eclauses_2eintTest(V v_t_240, V v_k_241, V v_env_242, V v_i_243, V v_off_244, V v_s_245, V v_rest_246, V v_w_247, V v_v_248) {
top: ;
  switch (heff_tag_of(v_v_248)) {
  case TAG_At: {
    V v_v1_249 = heff_field(v_v_248, 0);
    V v_ru_24v_248_24At = heff_take_reuse_n(v_v_248, 1ULL, 2);
    switch (heff_tag_of(v_v1_249)) {
    case TAG_PatVar: {
      V v_x_2411 = heff_field(v_v1_249, 0);
      heff_take_n(v_v1_249, 1ULL, 1);
      V v_t_2412 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_2411)}));
      V v_t_2413 = (g_list_2eany(v_t_2412, heff_rfield(v_k_241, 3)));
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_t_2414 = heff_intShow(heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
        V v_t_2415 = heff_strAppend(heff_dup(heff_rfield(v_k_241, 0)), heff_strAppend(((V)&g_heff_2eelab_2eclauses_2eintTest_str0), v_t_2414));
        V v_x_2416 = (g_heff_2eelab_2eclauses_2efreshIn(heff_rfield(v_k_241, 4), heff_rfield(v_k_241, 5), v_t_2415));
        V v_rhs_2417 = (g_heff_2eelab_2eclauses_2eintRead(heff_dup(v_k_241), heff_dup(v_off_244), heff_dup(v_w_247), heff_get_n(v_s_245, 3, 5)));
        V v_t_2418 = heff_intShow(heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
        V v_t_2419 = heff_strAppend(heff_take_field(v_k_241, 0), heff_strAppend(((V)&g_heff_2eelab_2eclauses_2eintTest_str1), v_t_2418));
        V v_t_2420 = (g_heff_2eelab_2eclauses_2efreshIn(heff_rfield(v_k_241, 4), heff_rfield(v_k_241, 5), v_t_2419));
        V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_t_2420}), v_env_242});
        V v_t_2422 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
        V v_t_2423 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
        V v_body_2424 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_t_2421, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2422, v_t_2423}), v_rest_246}));
        V v_sp_2425 = heff_get_n(v_k_241, 6, 7);
        V v_t_2426 = heff_tag_at_n(v_ru_24v_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_2416}), heff_dup(v_sp_2425)});
        V v_t_2429;
        switch (heff_tag_of(v_body_2424)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_body_2424, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_body_2424);
        }
        V v_t_2430 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_2425, 0)); V rr_ = heff_rec_reuse_nf(v_t_2429, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2426, v_body_2424}), v_t_2430});
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhs_2417, v_t_2431}), v_sp_2425});
      } else {
        heff_drop_rec(v_k_241, 7);
        heff_drop_rec(v_s_245, 5);
        heff_drop_cell(v_ru_24v_248_24At, 2);
        heff_drop(v_x_2411);
        heff_drop(v_t_2413);
        V v_t_2432 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
        V v_t_2433 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
        return heff_tail(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2432, v_t_2433}), v_rest_246});
      }
    }
    case TAG_PatTag: {
      heff_take_n(v_v1_249, 0ULL, 3);
      heff_drop_rec(v_k_241, 7);
      heff_drop_rec(v_s_245, 5);
      heff_drop_cell(v_ru_24v_248_24At, 2);
      V v_t_2437 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
      V v_t_2438 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
      return heff_tail(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2437, v_t_2438}), v_rest_246});
    }
    case TAG_PatOp: {
      heff_take_n(v_v1_249, 0ULL, 3);
      heff_drop_rec(v_k_241, 7);
      heff_drop_rec(v_s_245, 5);
      heff_drop_cell(v_ru_24v_248_24At, 2);
      V v_t_2442 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
      V v_t_2443 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
      return heff_tail(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2442, v_t_2443}), v_rest_246});
    }
    case TAG_PatInt: {
      V v_n_2444 = heff_field(v_v1_249, 0);
      V v_ru_24v1_249_24PatInt = heff_take_reuse_n(v_v1_249, 1ULL, 1);
      V v_i_2445 = (g_heff_2eelab_2eclauses_2eintRead(heff_dup(v_k_241), heff_dup(v_off_244), heff_dup(v_w_247), heff_get_n(v_s_245, 3, 5)));
      V v_t_2448;
      switch (heff_tag_of(v_i_2445)) {
      case TAG_At: {
        V v_s_2447 = heff_dup(heff_field(v_i_2445, 1));
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_i_2445);
      }
      V v_t_2449 = heff_tag_at_n(v_ru_24v_248_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2445}), v_t_2448});
      V v_sp_2450 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24v1_249_24PatInt, TAG_IInt, 1, (V[]){v_n_2444}), heff_dup(v_sp_2450)});
      V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2451}), v_sp_2450});
      V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
      V v_args_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, v_t_2453});
      V v_sp_2455 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eintTest_str2)}), heff_dup(v_sp_2455)});
      V v_t_2457 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2455), v_args_2454));
      V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2456, v_t_2457}), v_sp_2455});
      V v_t_2459 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
      V v_t_2460 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
      V v_t_2461 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2459, v_t_2460}), v_rest_246}));
      return (g_heff_2eelab_2eclauses_2eandC(v_t_2458, v_t_2461, heff_get_n(v_k_241, 6, 7)));
    }
    case TAG_PatFloat: {
      heff_take_na(v_v1_249, 0ULL, 1);
      heff_drop_rec(v_k_241, 7);
      heff_drop_rec(v_s_245, 5);
      heff_drop_cell(v_ru_24v_248_24At, 2);
      V v_t_2463 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
      V v_t_2464 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
      return heff_tail(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2463, v_t_2464}), v_rest_246});
    }
    case TAG_PatString: {
      heff_take_n(v_v1_249, 0ULL, 1);
      heff_drop_rec(v_k_241, 7);
      heff_drop_rec(v_s_245, 5);
      heff_drop_cell(v_ru_24v_248_24At, 2);
      V v_t_2466 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
      V v_t_2467 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
      return heff_tail(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2466, v_t_2467}), v_rest_246});
    }
    case TAG_PatBinary: {
      heff_take_n(v_v1_249, 0ULL, 1);
      heff_drop_rec(v_k_241, 7);
      heff_drop_rec(v_s_245, 5);
      heff_drop_cell(v_ru_24v_248_24At, 2);
      V v_t_2469 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
      V v_t_2470 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
      return heff_tail(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2469, v_t_2470}), v_rest_246});
    }
    case TAG_PatRune: {
      heff_take_n(v_v1_249, 0ULL, 1);
      heff_drop_rec(v_k_241, 7);
      heff_drop_rec(v_s_245, 5);
      heff_drop_cell(v_ru_24v_248_24At, 2);
      V v_t_2472 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
      V v_t_2473 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
      return heff_tail(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2472, v_t_2473}), v_rest_246});
    }
    case TAG_PatRecord: {
      heff_take_n(v_v1_249, 0ULL, 1);
      heff_drop_rec(v_k_241, 7);
      heff_drop_rec(v_s_245, 5);
      heff_drop_cell(v_ru_24v_248_24At, 2);
      V v_t_2475 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
      V v_t_2476 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
      return heff_tail(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2475, v_t_2476}), v_rest_246});
    }
    case TAG_PatWord: {
      heff_take_n(v_v1_249, 0ULL, 1);
      heff_drop_rec(v_k_241, 7);
      heff_drop_rec(v_s_245, 5);
      heff_drop_cell(v_ru_24v_248_24At, 2);
      V v_t_2478 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
      V v_t_2479 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
      return heff_tail(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2478, v_t_2479}), v_rest_246});
    }
    case TAG_PatAs: {
      heff_take_n(v_v1_249, 0ULL, 3);
      heff_drop_rec(v_k_241, 7);
      heff_drop_rec(v_s_245, 5);
      heff_drop_cell(v_ru_24v_248_24At, 2);
      V v_t_2483 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
      V v_t_2484 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
      return heff_tail(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2483, v_t_2484}), v_rest_246});
    }
    default: return heff_nomatch(v_v1_249);
    }
  }
  default: return heff_nomatch(v_v_248);
  }
}
V g_heff_2eelab_2eclauses_2eintTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eintTest(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_heff_2eelab_2eclauses_2ewholeBin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ewholeBin_entry, 2, 0};

V g_heff_2eelab_2eclauses_2ewholeBin(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    HeffT2 v_t_244 = (g_heff_2eelab_2eclauses_2ewholeSeg_24cpr(heff_dup(v_s_242), heff_rfield(v_s_242, 1), heff_rfield(v_s_242, 2), heff_dup(heff_rfield(v_s_242, 0))));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_b_248 = v_field_246;
        V t_0 = v_rest_243;
        V t_1 = heff_strAppend(v_acc_241, v_b_248);
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      } else {
        heff_drop(v_acc_241);
        heff_drop(v_field_246);
        return NTAG(TAG_Nothing);
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ewholeBin_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2ewholeBin(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2ebinBind_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2ebinBind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ebinBind_entry, 1, 0};

V g_heff_2eelab_2eclauses_2ebinBind(V v_k_240) {
top: ;
  return heff_rec_n(1, shape_go, (V[]){heff_clo_n(g_heff_2eelab_2eclauses_2ebinBind_lam0, 6, 1, (V[]){v_k_240})});
}
V g_heff_2eelab_2eclauses_2ebinBind_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ebinBind(a[0]);
}
V g_heff_2eelab_2eclauses_2ebinBind_lam0(V self, V *args) {
  V v_env_241 = args[0];
  V v_i_242 = args[1];
  V v_ys_243 = args[2];
  V v_off_244 = args[3];
  V v_segs_245 = args[4];
  V v_body_246 = args[5];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = (g_heff_2eelab_2eclauses_2ebinBind(heff_dup(v_k_240)));
  return (g_heff_2eelab_2eclauses_2ebinBindGo(v_t_247, v_k_240, v_env_241, v_i_242, v_ys_243, v_off_244, v_segs_245, v_body_246));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str1, 42, "a binary and a tag match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str3, 46, "a literal and a binary match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str4, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str5, 45, "a record and a binary match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str6, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str7, 88, "binaries are matched here: one of them must match every other value (a variable, or `_`)");
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam3(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2ebinChecks_24cpr(V v_rows_240, V v_c_241, V v_bsp_242) {
top: ;
  V v_t_2421 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_rows_240));
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop(v_c_241);
    heff_drop(v_t_2421);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_bsp_242, ((V)&g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str1)})}});
  } else {
    heff_drop(v_t_2421);
    V v_t_2440 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam1, 1, 1, (V[]){heff_dup(v_c_241)}), v_rows_240));
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop(v_c_241);
      heff_drop(v_t_2440);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_bsp_242, ((V)&g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str3)})}});
    } else {
      heff_drop(v_t_2440);
      V v_t_2459 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam2, 1, 1, (V[]){heff_dup(v_c_241)}), v_rows_240));
      if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
        heff_drop(v_c_241);
        heff_drop(v_t_2459);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_bsp_242, ((V)&g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str5)})}});
      } else {
        heff_drop(v_t_2459);
        V v_t_2478 = (g_heff_2eelab_2eclauses_2eallC(heff_clo_n(g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam3, 1, 1, (V[]){v_c_241}), v_rows_240));
        if ((heff_dup(v_t_2478) == NTAG(TAG_True))) {
          heff_drop(v_t_2478);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_span__msg, (V[]){v_bsp_242, ((V)&g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str7)})}});
        } else {
          heff_drop(v_bsp_242);
          heff_drop(v_t_2478);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_MkUnit)}});
        }
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam0(V self, V *args) {
  V v_row_243 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_244 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_row_243, 0, 2), v_c_241));
  V v_x1_249;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_p_248 = v_field_246;
      v_x1_249 = v_p_248;
    } else {
      heff_drop(v_field_246);
      v_x1_249 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str0)});
    }
  }
  switch (heff_tag_of(v_x1_249)) {
  case TAG_PVar: {
    heff_take_n(v_x1_249, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_249, 0ULL, 3);
    return NTAG(TAG_True);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_249, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_249, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_249, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PBin: {
    heff_take_n(v_x1_249, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam1(V self, V *args) {
  V v_row_2422 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2423 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_row_2422, 0, 2), v_c_241));
  V v_x1_2428;
  {
    V v_field_2425 = v_t_2423.f[1];
    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
    if ((v_tag_2424 == ((int64_t)0ULL))) {
      V v_p_2427 = v_field_2425;
      v_x1_2428 = v_p_2427;
    } else {
      heff_drop(v_field_2425);
      v_x1_2428 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str2)});
    }
  }
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_PVar: {
    heff_take_n(v_x1_2428, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_2428, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_2428, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_2428, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_2428, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PBin: {
    heff_take_n(v_x1_2428, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_2428);
  }
}
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam2(V self, V *args) {
  V v_row_2441 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2442 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_row_2441, 0, 2), v_c_241));
  V v_x1_2447;
  {
    V v_field_2444 = v_t_2442.f[1];
    int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
    if ((v_tag_2443 == ((int64_t)0ULL))) {
      V v_p_2446 = v_field_2444;
      v_x1_2447 = v_p_2446;
    } else {
      heff_drop(v_field_2444);
      v_x1_2447 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str4)});
    }
  }
  switch (heff_tag_of(v_x1_2447)) {
  case TAG_PVar: {
    heff_take_n(v_x1_2447, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_2447, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_2447, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_2447, 0ULL, 2);
    return NTAG(TAG_True);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_2447, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PBin: {
    heff_take_n(v_x1_2447, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_2447);
  }
}
V g_heff_2eelab_2eclauses_2ebinChecks_24cpr_lam3(V self, V *args) {
  V v_row_2460 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2461 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_row_2460, 0, 2), v_c_241));
  V v_x1_2466;
  {
    V v_field_2463 = v_t_2461.f[1];
    int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
    if ((v_tag_2462 == ((int64_t)0ULL))) {
      V v_p_2465 = v_field_2463;
      v_x1_2466 = v_p_2465;
    } else {
      heff_drop(v_field_2463);
      v_x1_2466 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinChecks_24cpr_str6)});
    }
  }
  switch (heff_tag_of(v_x1_2466)) {
  case TAG_PVar: {
    heff_take_n(v_x1_2466, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_2466, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_2466, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_2466, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_2466, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PBin: {
    heff_take_n(v_x1_2466, 0ULL, 2);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2466);
  }
}
Clo g_heff_2eelab_2eclauses_2ecolNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecolNames_entry, 6, 0};

V g_heff_2eelab_2eclauses_2ecolNames(V v_used_240, V v_params_241, V v_rows_242, V v_i_243, V v_n_244, V v_taken_245) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_244), heff_dup(v_i_243))) {
    heff_drop(v_params_241);
    heff_drop(v_rows_242);
    heff_drop(v_i_243);
    heff_drop(v_n_244);
    heff_drop(v_taken_245);
    return NTAG(TAG_Nil);
  } else {
    HeffT2 v_t_247 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(v_params_241), heff_dup(v_i_243)));
    V v_x_2412;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_p_2411 = v_field_249;
        v_x_2412 = v_p_2411;
      } else {
        heff_drop(v_field_249);
        v_x_2412 = (g_heff_2eelab_2eclauses_2ecolFrom(v_used_240, v_taken_245, heff_dup(v_rows_242), heff_dup(v_i_243)));
      }
    }
    V v_cell_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2412), heff_hole()});
    V v_u_2414 = (g_heff_2eelab_2eclauses_2ecolNames_24dps(v_used_240, v_params_241, v_rows_242, heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL))), v_n_244, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_taken_245}), heff_dup(v_cell_2413)));
    heff_drop(v_u_2414);
    return v_cell_2413;
  }
}
V g_heff_2eelab_2eclauses_2ecolNames_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2ecolNames(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2ecolNames_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecolNames_24dps_entry, 7, 0};

V g_heff_2eelab_2eclauses_2ecolNames_24dps(V v_used_240, V v_params_241, V v_rows_242, V v_i_243, V v_n_244, V v_taken_245, V v_d_246) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_244), heff_dup(v_i_243))) {
    heff_drop(v_params_241);
    heff_drop(v_rows_242);
    heff_drop(v_i_243);
    heff_drop(v_n_244);
    heff_drop(v_taken_245);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    HeffT2 v_t_248 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(v_params_241), heff_dup(v_i_243)));
    V v_x_2413;
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_p_2412 = v_field_2410;
        v_x_2413 = v_p_2412;
      } else {
        heff_drop(v_field_2410);
        v_x_2413 = (g_heff_2eelab_2eclauses_2ecolFrom(v_used_240, v_taken_245, heff_dup(v_rows_242), heff_dup(v_i_243)));
      }
    }
    V v_cell_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2413), heff_hole()});
    V v_u_2415 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2414));
    heff_drop(v_u_2415);
    V t_0 = v_used_240;
    V t_1 = v_params_241;
    V t_2 = v_rows_242;
    V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
    V t_4 = v_n_244;
    V t_5 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_taken_245});
    V t_6 = v_cell_2414;
    v_used_240 = t_0;
    v_params_241 = t_1;
    v_rows_242 = t_2;
    v_i_243 = t_3;
    v_n_244 = t_4;
    v_taken_245 = t_5;
    v_d_246 = t_6;
    goto top;
  }
}
V g_heff_2eelab_2eclauses_2ecolNames_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2ecolNames_24dps(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_str0, 44, " is used with different numbers of arguments");
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_entry, 7, 0};

V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_c_244, V v_arm_245, V v_fs_246) {
top: ;
  V v_t_247 = heff_take_field(v_arm_245, 1);
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_used_240);
    heff_drop(v_bound_241);
    heff_drop(v_sp_242);
    heff_drop(v_vars_243);
    heff_drop(v_c_244);
    heff_drop(v_fs_246);
    heff_drop(v_t_247);
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_arm_245, 0)), 3, 4);
    V v_t_249 = heff_get_n(heff_get_n(v_arm_245, 0, 3), 0, 4);
    V v_t_2410 = heff_rec_n(2, shape_span__msg, (V[]){v_t_248, heff_strAppend(v_t_249, ((V)&g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_str0))});
    return heff_tag_n(TAG_Left, 1, (V[]){v_t_2410});
  } else {
    heff_drop(v_t_247);
    V v_bound_2411 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_fs_246), v_bound_241));
    V v_t_2412 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_244), heff_dup(v_vars_243)));
    V v_t_2413 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_244, MK_INT(1LL)), v_vars_243));
    V v_t_2414 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_fs_246), v_t_2413));
    V v_vars_2415 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2412, v_t_2414));
    V v_rows_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_arm_245, 2)));
    V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam0, 1, 1, (V[]){heff_dup(v_vars_2415)}), v_rows_2416));
    HeffT2 v_t_2419 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(v_used_240, v_bound_2411, heff_dup(v_sp_242), v_vars_2415, v_t_2418));
    {
      V v_field_2421 = v_t_2419.f[1];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        heff_drop(v_sp_242);
        heff_drop_rec(v_arm_245, 3);
        heff_drop(v_fs_246);
        V v_e_2423 = v_field_2421;
        return heff_tag_n(TAG_Left, 1, (V[]){v_e_2423});
      } else {
        V v_x_2424 = v_field_2421;
        V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_arm_245, 0)), 0, 4);
        V v_tsp_2426 = heff_get_n(heff_get_n(v_arm_245, 0, 3), 3, 4);
        V v_ps_2427 = (g_list_2emap_24s1230649048x711093514(v_sp_242, v_fs_246));
        V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_t_2425)}), heff_dup(v_tsp_2426)});
        V v_x1_2429 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2428, v_ps_2427));
        V v_t_2432;
        switch (heff_tag_of(v_x1_2429)) {
        case TAG_At: {
          V v_s_2431 = heff_field(v_x1_2429, 1);
          heff_take_n(v_x1_2429, 2ULL, 2);
          v_t_2432 = v_s_2431;
          break;
        }
        default: heff_nomatch(v_x1_2429);
        }
        V v_t_2433 = ({ V rv_0 = heff_dup(heff_rfield(v_tsp_2426, 0)); V rr_ = heff_rec_reuse_nf(v_t_2432, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_2425, v_tsp_2426, v_ps_2427}), heff_dup(v_t_2433)});
        V v_t_2437;
        switch (heff_tag_of(v_x_2424)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_x_2424, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_x_2424);
        }
        V v_t_2438 = ({ V rv_1 = heff_get_n(v_t_2437, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2433, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2434, v_x_2424}), v_t_2438});
        return heff_tag_n(TAG_Right, 1, (V[]){v_t_2439});
      }
    }
  }
}
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam0(V self, V *args) {
  V v_row_2417 = args[0];
  V v_vars_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_2415, heff_dup(heff_rfield(v_row_2417, 0)), heff_get_n(v_row_2417, 1, 2)));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecordNamed_24s570125606x1378596115_24cpr_str0, 1, "_");
V g_heff_2eelab_2eclauses_2erecordNamed_24s570125606x1378596115_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erecordNamed_24s570125606x1378596115_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2erecordNamed_24s570125606x1378596115_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_fs_246) {
top: ;
  V v_specialized_2414 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erecordNamed_24s570125606x1378596115_24cpr_lam0, 1, 3, (V[]){heff_dup(v_vars_243), heff_dup(v_c_245), heff_dup(v_fs_246)}), heff_dup(v_rows_244)));
  V v_t_2418 = (g_heff_2eelab_2eclauses_2emapWithIndexC(MK_INT(0LL), heff_clo_n(g_heff_2eelab_2eclauses_2erecordNamed_24s570125606x1378596115_24cpr_lam1, 2, 5, (V[]){heff_dup(v_c_245), heff_dup(v_rows_244), heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_specialized_2414)}), heff_dup(v_fs_246)));
  return (g_heff_2eelab_2eclauses_2erecordWith_24s2051940580x1889718143_24cpr(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_fs_246, v_t_2418, v_specialized_2414));
}
V g_heff_2eelab_2eclauses_2erecordNamed_24s570125606x1378596115_24cpr_lam0(V self, V *args) {
  V v_row_247 = args[0];
  V v_vars_243 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_fs_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_248 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_vars_243, heff_dup(v_c_245)));
  V v_t_2413;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_v_2412 = v_field_2410;
      v_t_2413 = v_v_2412;
    } else {
      heff_drop(v_field_2410);
      v_t_2413 = ((V)&g_heff_2eelab_2eclauses_2erecordNamed_24s570125606x1378596115_24cpr_str0);
    }
  }
  return (g_heff_2eelab_2eclauses_2erecSpecialize(v_c_245, v_fs_246, v_t_2413, v_row_247));
}
V g_heff_2eelab_2eclauses_2erecordNamed_24s570125606x1378596115_24cpr_lam1(V self, V *args) {
  V v_i_2415 = args[0];
  V v_f_2416 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_rows_244 = heff_env(self)[1];
  V v_used_240 = heff_env(self)[2];
  V v_bound_241 = heff_env(self)[3];
  V v_specialized_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = (g_heff_2eelab_2eclauses_2erecFieldVar(heff_dup(v_c_245), v_rows_244, heff_dup(v_f_2416)));
  return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_specialized_2414; V a_3 = heff_intAdd(v_c_245, v_i_2415); V a_4 = v_t_2417; V a_5 = v_f_2416; V r_ = (g_heff_2eelab_2eclauses_2erecSubName(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_used_240); heff_drop(v_bound_241); heff_drop(v_specialized_2414); heff_drop(v_t_2417); r_; });
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str1, 7, "Segment");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str3, 6, "AsBits");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str4, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str5, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str6, 4, "Bits");
V g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_segs_246, V v_bsp_247, V v_bits_248, V v_made_249) {
top: ;
  V v_t_2410 = (g_list_2emap_24s502656580x1955732096(heff_dup(v_segs_246)));
  V v_t_2411 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2410));
  V v_t_2412 = (g_list_2emap_24s502656580x1955732096(heff_dup(v_segs_246)));
  V v_t_2413 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2412));
  V v_t_2424 = (g_heff_2eelab_2eclauses_2emapWithIndexC(MK_INT(0LL), heff_clo_n(g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_lam0, 2, 4, (V[]){heff_dup(v_vars_243), heff_dup(v_c_245), heff_dup(v_used_240), heff_dup(v_bound_241)}), v_t_2413));
  V v_t_2436;
  if ((heff_dup(v_made_249) == NTAG(TAG_True))) {
    HeffT2 v_t_2425 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(v_vars_243), heff_dup(v_c_245)));
    V v_t_2430;
    {
      V v_field_2427 = v_t_2425.f[1];
      int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
      if ((v_tag_2426 == ((int64_t)0ULL))) {
        V v_v_2429 = v_field_2427;
        v_t_2430 = v_v_2429;
      } else {
        heff_drop(v_field_2427);
        v_t_2430 = ((V)&g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str2);
      }
    }
    v_t_2436 = (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_t_2430, ((V)&g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str3))));
  } else {
    HeffT2 v_t_2431 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(v_vars_243), heff_dup(v_c_245)));
    {
      V v_field_2433 = v_t_2431.f[1];
      int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
      if ((v_tag_2432 == ((int64_t)0ULL))) {
        V v_v_2435 = v_field_2433;
        v_t_2436 = v_v_2435;
      } else {
        heff_drop(v_field_2433);
        v_t_2436 = ((V)&g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str4);
      }
    }
  }
  HeffT2 v_t_2437 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(v_vars_243), heff_dup(v_c_245)));
  V v_t_2442;
  {
    V v_field_2439 = v_t_2437.f[1];
    int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
    if ((v_tag_2438 == ((int64_t)0ULL))) {
      V v_v_2441 = v_field_2439;
      v_t_2442 = v_v_2441;
    } else {
      heff_drop(v_field_2439);
      v_t_2442 = ((V)&g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str5);
    }
  }
  V v_t_2443 = (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_t_2442, ((V)&g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str6))));
  V v_t_2444 = (g_list_2emap_24s939813003x1383013550(heff_dup(v_segs_246)));
  V v_t_2445 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2444));
  return (g_heff_2eelab_2eclauses_2ebinaryWith_24s375106220x1377484830_24cpr(heff_dup(v_used_240), heff_dup(v_bound_241), v_sp_242, v_vars_243, v_rows_244, v_c_245, v_segs_246, heff_dup(v_bsp_247), v_t_2411, v_t_2424, heff_rec_n(7, shape_v__bits__len__sizes__used__bound__span, (V[]){v_t_2436, v_bits_248, v_t_2443, v_t_2445, v_used_240, v_bound_241, v_bsp_247}), v_made_249));
}
V g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_lam0(V self, V *args) {
  V v_i_2414 = args[0];
  V v_x_2415 = args[1];
  V v_vars_243 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_used_240 = heff_env(self)[2];
  V v_bound_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2415);
  HeffT2 v_t_2416 = (g_heff_2eelab_2eclauses_2enthC_24cpr(v_vars_243, v_c_245));
  V v_t_2421;
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_v_2420 = v_field_2418;
      v_t_2421 = v_v_2420;
    } else {
      heff_drop(v_field_2418);
      v_t_2421 = ((V)&g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str0);
    }
  }
  V v_t_2422 = heff_intShow(heff_intAdd(v_i_2414, MK_INT(1LL)));
  V v_t_2423 = heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr_str1), v_t_2422));
  return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_t_2423; V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_240); heff_drop(v_bound_241); r_; });
}

HeffT2 g_heff_2eelab_2eclauses_2ebinaryOf_24s1676894398x132520022_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_segs_246, V v_bsp_247) {
top: ;
  V v_t_248 = (g_list_2eany_24s1116296567x1614305171(v_segs_246));
  V v_t_2418;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    v_t_2418 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_248);
    V v_t_249 = (g_list_2emap_24s1134745827x519521524(heff_dup(v_segs_246)));
    HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(v_t_249, MK_INT(0LL)));
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_n_2414 = v_field_2412;
        if (heff_intEq_c(v_n_2414, MK_INT(0LL))) {
          V v_x1_2416 = (g_list_2eany_24s1116296567x1614305171(v_segs_246));
          V v_x1_2417;
          if ((heff_dup(v_x1_2416) == NTAG(TAG_True))) {
            heff_drop(v_x1_2416);
            v_x1_2417 = NTAG(TAG_False);
          } else {
            heff_drop(v_x1_2416);
            v_x1_2417 = (g_list_2eall_24s1297075057x1726753756(MK_INT(0LL), v_segs_246));
          }
          v_t_2418 = heff_bool(!(heff_dup(v_x1_2417) == NTAG(TAG_True)));
          heff_drop(v_x1_2417);
        } else {
          v_t_2418 = NTAG(TAG_True);
        }
      } else {
        heff_drop(v_field_2412);
        v_t_2418 = NTAG(TAG_True);
      }
    }
  }
  V v_t_2419 = (g_list_2eany_24s1116296567x1614305171(v_segs_246));
  V v_t_2429;
  if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
    heff_drop(v_t_2419);
    v_t_2429 = NTAG(TAG_False);
  } else {
    heff_drop(v_t_2419);
    V v_t_2420 = (g_list_2emap_24s1134745827x519521524(heff_dup(v_segs_246)));
    HeffT2 v_t_2421 = (g_heff_2esyntax_2epresyntax_2eoddSum_24cpr(v_t_2420, MK_INT(0LL)));
    {
      V v_field_2423 = v_t_2421.f[1];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      if ((v_tag_2422 == ((int64_t)0ULL))) {
        V v_n_2425 = v_field_2423;
        if (heff_intEq_c(v_n_2425, MK_INT(0LL))) {
          V v_x1_2427 = (g_list_2eany_24s1116296567x1614305171(v_segs_246));
          V v_x1_2428;
          if ((heff_dup(v_x1_2427) == NTAG(TAG_True))) {
            heff_drop(v_x1_2427);
            v_x1_2428 = NTAG(TAG_False);
          } else {
            heff_drop(v_x1_2427);
            v_x1_2428 = (g_list_2eall_24s1297075057x1726753756(MK_INT(0LL), v_segs_246));
          }
          v_t_2429 = heff_bool(!(heff_dup(v_x1_2428) == NTAG(TAG_True)));
          heff_drop(v_x1_2428);
        } else {
          v_t_2429 = NTAG(TAG_False);
        }
      } else {
        heff_drop(v_field_2423);
        v_t_2429 = NTAG(TAG_False);
      }
    }
  }
  return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_sp_242; V a_3 = v_vars_243; V a_4 = v_rows_244; V a_5 = v_c_245; V a_6 = v_segs_246; V a_7 = v_bsp_247; V a_8 = v_t_2418; V a_9 = v_t_2429; HeffT2 r_ = (g_heff_2eelab_2eclauses_2ebinaryRead_24s831695165x1260591822_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_t_2429); r_; });
}
V g_heff_2eelab_2eclauses_2ecaseTreeOf_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2ecaseTreeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecaseTreeOf_entry, 4, 0};

V g_heff_2eelab_2eclauses_2ecaseTreeOf(V v_sp_240, V v_rows_241, V v_used_242, V v_x_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_248 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ecaseTreeOf_lam0, 1, 1, (V[]){heff_dup(v_x_243)}), v_rows_241));
  HeffT2 v_t_249 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), v_used_242}), v_t_244, v_sp_240, v_t_245, v_t_248));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      heff_drop(v_x_243);
      V v_e_2413 = v_field_2411;
      return heff_tag_n(TAG_Left, 1, (V[]){v_e_2413});
    } else {
      V v_x_2414 = v_field_2411;
      return heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_scrutinee__tree, (V[]){v_x_243, v_x_2414})});
    }
  }
}
V g_heff_2eelab_2eclauses_2ecaseTreeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ecaseTreeOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eclauses_2ecaseTreeOf_lam0(V self, V *args) {
  V v_row_246 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
  return (g_heff_2eelab_2eclauses_2epeelCols(v_t_247, heff_dup(heff_rfield(v_row_246, 0)), heff_get_n(v_row_246, 1, 2)));
}